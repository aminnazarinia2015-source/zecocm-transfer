<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\AiFinding;
use App\Models\DailyReport;
use App\Models\DailyReportActivity;
use App\Models\MediaItem;
use App\Models\Membership;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleOfValueItem;
use App\Models\ScheduleVersion;
use App\Models\SovScheduleLink;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * TRACE Progress Evidence Cross-Check, surfaced on the Pay Application
 * Review screen (claude/trace-progress-vs-schedule-deviation-design-brief.md).
 * Confirms the design's "keep two separate dimensions" ruling actually holds
 * over HTTP: trace_cross_check never touches findings/blocks_submission/
 * submission, and only an explicit promote call can ever connect a TRACE
 * finding to anything that affects payment.
 */
class PayApplicationTraceCrossCheckSurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $pm;
    private User $viewerOnly;
    private Project $project;
    private PayApplication $application;
    private ScheduleActivity $activity;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->pm = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);

        $this->viewerOnly = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Read Only',
            'email' => 'viewer@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->viewerOnly->id,
            'organization' => 'Northgate Builders', 'seat' => 'viewer', 'capabilities' => ['payment.view' => true]]);

        $sov = ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => '03-200', 'description' => 'Concrete Improvements', 'scheduled_value_cents' => 18000000,
            'original_value_cents' => 18000000]);
        $this->application = PayApplication::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 1, 'period_from' => '2026-07-01', 'period_to' => '2026-07-31']);
        PayApplicationLine::create(['tenant_id' => $this->tenant->id, 'pay_application_id' => $this->application->id,
            'schedule_of_value_item_id' => $sov->id, 'this_period_cents' => 5000000]);

        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => hash('sha256', 'schedule.xer'), 'storage_path' => 'test/schedule.xer',
            'original_name' => 'schedule.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov'), 'confidence' => 'strong',
            'captured_by' => $this->pm->id]);
        $version = ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'kind' => 'lookahead', 'label' => 'Update #4', 'data_date' => '2026-07-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(), 'source_file_media_id' => $media->id,
            'source_format' => 'xer', 'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'schedule.xer'), 'ingest_assumptions' => [], 'security_scan' => [],
            'created_by' => $this->pm->id]);
        $this->activity = ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $version->id,
            'activity_code' => 'A1220', 'name' => 'Pour sidewalk', 'activity_type' => 'CONSTRUCTION',
            'start_planned' => '2026-07-10', 'finish_planned' => '2026-07-20']);
        $link = SovScheduleLink::create(['tenant_id' => $this->tenant->id, 'schedule_of_value_item_id' => $sov->id,
            'schedule_activity_id' => $this->activity->id, 'schedule_version_id' => $version->id,
            'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT, 'mapping_source' => SovScheduleLink::SOURCE_PM]);
        $link->update(['mapping_status' => SovScheduleLink::STATUS_VERIFIED, 'verified_by' => $this->pm->id, 'verified_at' => now()]);
        // No daily report at all - so TRACE-01 will fire.
        (new CapabilityLicense)->grant($this->tenant, 'pay_apps', planReference: 'Test fixture');
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_the_pay_application_envelope_surfaces_a_trace_finding_separately_from_payment_findings(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();

        $this->assertArrayHasKey('trace_cross_check', $body);
        $this->assertSame(1, $body['trace_cross_check']['open_count']);
        $this->assertSame('CORROBORATION_GAP', $body['trace_cross_check']['items'][0]['category']);
        $this->assertSame('OPEN', $body['trace_cross_check']['items'][0]['status']);
        $this->assertNotEmpty($body['trace_cross_check']['items'][0]['evidence']);

        // The strict boundary the design closed on: a TRACE finding never
        // shows up as, or affects, a real payment finding on its own.
        $this->assertFalse($body['blocks_submission']);
        $this->assertArrayNotHasKey('trace_cross_check', array_column($body['findings'], null, 'code'));
    }

    public function test_reloading_the_envelope_does_not_duplicate_the_open_finding(): void
    {
        Sanctum::actingAs($this->pm);

        $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk();
        $second = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();

        $this->assertCount(1, $second['trace_cross_check']['items']);
    }

    public function test_a_pm_can_dismiss_a_finding_with_a_note_and_it_stays_dismissed(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();
        $findingId = $body['trace_cross_check']['items'][0]['id'];

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/dismiss",
            ['note' => 'Confirmed via inspection photo; work was performed under a different cost code entry.'])
            ->assertOk()
            ->assertJsonPath('finding.status', 'DISMISSED');

        $reloaded = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();
        $this->assertSame(0, $reloaded['trace_cross_check']['open_count']);
        $this->assertSame('DISMISSED', $reloaded['trace_cross_check']['items'][0]['status']);
    }

    public function test_dismissing_an_already_resolved_finding_is_rejected(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();
        $findingId = $body['trace_cross_check']['items'][0]['id'];

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/dismiss",
            ['note' => 'first resolution'])->assertOk();

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/dismiss",
            ['note' => 'second attempt'])->assertStatus(422);
    }

    public function test_a_viewer_without_trace_review_capability_cannot_dismiss_or_promote(): void
    {
        Sanctum::actingAs($this->viewerOnly);
        TenantContext::set($this->tenant->id);
        $findingId = AiFinding::where('pay_application_id', $this->application->id)->value('id');
        if ($findingId === null) {
            // The viewer-only request above ran the cross-check itself via the
            // envelope's GET, but as a safety net create directly if needed.
            $findingId = (new \App\Domain\Trace\ProgressEvidenceCrossCheckService)->evaluate($this->application->fresh())[0]->id;
        }
        TenantContext::clear();

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/dismiss",
            ['note' => 'trying anyway'])->assertStatus(403);
        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/promote",
            ['note' => 'trying anyway'])->assertStatus(403);
    }

    public function test_promoting_a_finding_requires_a_note_and_marks_it_promoted(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->getJson('/api/pay-applications/'.$this->application->id)->assertOk()->json();
        $findingId = $body['trace_cross_check']['items'][0]['id'];

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/promote", [])
            ->assertStatus(422); // note is required - promoting is a deliberate act, not a click

        $this->postJson("/api/pay-applications/{$this->application->id}/trace-findings/{$findingId}/promote",
            ['note' => 'Confirmed with the field team; opening a formal review issue for this pay application.'])
            ->assertOk()
            ->assertJsonPath('finding.status', 'PROMOTED');
    }
}
