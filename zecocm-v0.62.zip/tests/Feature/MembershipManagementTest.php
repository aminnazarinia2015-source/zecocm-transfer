<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * "Users & access" was a static mockup with no backing route at all - a
 * `#tb-users` table nothing ever populated, an "Add person" wizard whose
 * "Send invite" button saved nothing. MembershipController is the real
 * thing. See claude/admin-rbac-design.md.
 *
 * The critical correctness property this file pins: a revoked grant must
 * actually stop authorizing (App\Domain\Schedule\ProjectAccess), not just
 * read as revoked on this screen - a status column that only changes what a
 * table cell says would be worse than not having the feature.
 */
class MembershipManagementTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $pm;
    private User $viewerOnly;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->pm = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        $this->viewerOnly = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Viewer', 'email' => 'viewer@northgate.test', 'password' => bcrypt('password')]);

        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->viewerOnly->id,
            'organization' => 'Northgate Builders', 'seat' => 'viewer', 'capabilities' => ['membership.view' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'daily_reports', planReference: 'Test fixture');
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_index_lists_memberships_with_capabilities(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->getJson('/api/memberships?project_id=' . $this->project->id)->assertOk()->json();

        $this->assertCount(2, $body['memberships']);
    }

    public function test_adding_a_brand_new_person_creates_a_user_and_a_membership_with_a_temp_password(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Tom Castillo', 'email' => 'tom@cdmfencing.test',
            'organization' => 'CDM Fencing', 'seat' => 'contractor',
            'capabilities' => ['daily.create' => true],
        ])->assertCreated()->json();

        $this->assertNotEmpty($body['temp_password']);
        $this->assertSame('Tom Castillo', $body['membership']['name']);
        $this->assertSame('active', $body['membership']['status']);
        $this->assertDatabaseHas('users', ['email' => 'tom@cdmfencing.test']);
    }

    public function test_adding_a_person_who_already_has_an_account_attaches_without_a_temp_password(): void
    {
        Sanctum::actingAs($this->pm);
        TenantContext::set($this->tenant->id);
        $existing = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Existing Person', 'email' => 'existing@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::clear();

        $body = $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Existing Person', 'email' => 'existing@northgate.test',
            'organization' => 'Northgate Builders', 'seat' => 'field_engineer', 'capabilities' => [],
        ])->assertCreated()->json();

        $this->assertNull($body['temp_password']);
        $this->assertSame($existing->id, $body['membership']['user_id']);
    }

    public function test_a_person_cannot_be_added_twice_to_the_same_project(): void
    {
        Sanctum::actingAs($this->pm);

        $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Dup', 'email' => 'dup@northgate.test',
            'organization' => 'Northgate Builders', 'seat' => 'contractor', 'capabilities' => [],
        ])->assertCreated();

        $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Dup', 'email' => 'dup@northgate.test',
            'organization' => 'Northgate Builders', 'seat' => 'contractor', 'capabilities' => [],
        ])->assertStatus(422);
    }

    public function test_revoking_a_membership_actually_removes_access_not_just_the_status_label(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Field Sub', 'email' => 'sub@cdm.test',
            'organization' => 'CDM Fencing', 'seat' => 'contractor', 'capabilities' => ['daily.create' => true],
        ])->assertCreated()->json();
        $subUserId = $body['membership']['user_id'];

        $this->postJson('/api/memberships/' . $body['membership']['id'] . '/revoke')
            ->assertOk()->assertJsonPath('status', 'revoked');

        TenantContext::set($this->tenant->id);
        $sub = User::find($subUserId);
        TenantContext::clear();
        Sanctum::actingAs($sub);

        $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15', 'work_performed' => 'Trying anyway.',
        ])->assertStatus(403);
    }

    public function test_reactivating_a_revoked_membership_restores_access(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'Field Sub', 'email' => 'sub2@cdm.test',
            'organization' => 'CDM Fencing', 'seat' => 'contractor', 'capabilities' => ['daily.create' => true],
        ])->assertCreated()->json();
        $this->postJson('/api/memberships/' . $body['membership']['id'] . '/revoke')->assertOk();

        $this->postJson('/api/memberships/' . $body['membership']['id'] . '/reactivate')
            ->assertOk()->assertJsonPath('status', 'active');
    }

    public function test_a_pm_cannot_revoke_their_own_access(): void
    {
        Sanctum::actingAs($this->pm);
        TenantContext::set($this->tenant->id);
        $ownMembership = Membership::where('project_id', $this->project->id)->where('user_id', $this->pm->id)->first();
        TenantContext::clear();

        $this->postJson('/api/memberships/' . $ownMembership->id . '/revoke')->assertStatus(422);
    }

    public function test_a_viewer_without_membership_manage_cannot_add_or_revoke(): void
    {
        Sanctum::actingAs($this->viewerOnly);

        $this->postJson('/api/memberships', [
            'project_id' => $this->project->id, 'name' => 'X', 'email' => 'x@test.test',
            'organization' => 'X', 'seat' => 'contractor', 'capabilities' => [],
        ])->assertStatus(403);
    }
}
