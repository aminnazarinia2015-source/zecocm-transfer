<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\ChangeOrder;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * SEC-3: RBAC negative testing. Codex's framing, not "does role X have
 * permission Y" but "no role can read, mutate, certify, govern, export, or
 * authorize through an alternate path that bypasses the intended permission
 * boundary."
 *
 * ProjectAccess::authorize() is the one mechanism every controller is
 * supposed to route through, and it fails closed by construction
 * (ProjectGrant::allows() requires an explicit true, never falls through to
 * permitted). What was untested is whether every high-impact capability
 * actually reaches that gate, and whether a membership holding an adjacent
 * capability is still refused the one it doesn't hold - not whether the gate
 * itself works, which is unit-level and already implicit in every passing
 * authorized-path test in this suite.
 */
class RbacNegativeTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        (new CapabilityLicense)->grant($this->tenant, 'change_management', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'photos', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'pay_apps', planReference: 'Test fixture');
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function memberWith(array $capabilities): User
    {
        static $n = 0;
        $n++;
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => "Member {$n}",
            'email' => "member{$n}@northgate.test", 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'field', 'capabilities' => $capabilities]);
        TenantContext::clear();

        return $user;
    }

    private function realPdf(string $name = 'photo.pdf'): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'rbac');
        file_put_contents($path, "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF");

        return new UploadedFile($path, $name, 'application/pdf', null, true);
    }

    // ---- capability holder can act; capability-less cannot, on the same endpoint ----

    public function test_media_upload_is_refused_without_media_upload_capability(): void
    {
        $noCapability = $this->memberWith(['media.view' => true]); // adjacent, not the one this needs
        Sanctum::actingAs($noCapability);

        $response = $this->postJson('/api/media', ['project_id' => $this->project->id, 'file' => $this->realPdf()]);

        $response->assertStatus(403);
    }

    public function test_change_order_approval_is_refused_to_a_member_who_can_only_view(): void
    {
        TenantContext::set($this->tenant->id);
        $order = ChangeOrder::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'CO-1', 'title' => 'Added drainage', 'status' => 'draft', 'amount_cents' => 500000,
            'time_extension_days' => 0]);
        TenantContext::clear();

        $viewer = $this->memberWith(['changeorder.view' => true]);
        Sanctum::actingAs($viewer);

        $response = $this->postJson("/api/change-orders/{$order->id}/approve", []);

        $response->assertStatus(403);
    }

    public function test_change_order_approval_succeeds_for_a_member_who_actually_holds_the_capability(): void
    {
        // The other half of the same case: the negative result above is
        // because of the missing capability specifically, not a broken route
        // or a broken fixture.
        TenantContext::set($this->tenant->id);
        $order = ChangeOrder::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'CO-2', 'title' => 'Added drainage', 'status' => 'draft', 'amount_cents' => 500000,
            'time_extension_days' => 0]);
        TenantContext::clear();

        $approver = $this->memberWith(['changeorder.view' => true, 'changeorder.approve' => true]);
        Sanctum::actingAs($approver);

        $response = $this->postJson("/api/change-orders/{$order->id}/approve", [
            'determination' => 'Reviewed and approved; scope and cost are within authority.',
        ]);

        $response->assertStatus(200);
    }

    public function test_a_membership_with_no_capabilities_at_all_is_refused_every_write(): void
    {
        $bystander = $this->memberWith([]);
        Sanctum::actingAs($bystander);

        $this->postJson('/api/change-orders', ['project_id' => $this->project->id, 'number' => 'CO-9',
            'title' => 'x', 'amount_cents' => 100,
            'allocations' => [['amount_cents' => 100]]])->assertStatus(403);
        $this->postJson('/api/document-library/documents', [
            'project_id' => $this->project->id, 'file' => $this->realPdf(),
        ])->assertStatus(403);
        $this->postJson('/api/knowledge/sources', [
            'project_id' => $this->project->id, 'collection' => 'project', 'corpus' => 'project_specs',
            'title' => 'Spec', 'source_type' => 'specification', 'authority_level' => 'project_contract',
            'text' => 'Irrigation trench depth shall be 24 in.',
        ])->assertStatus(403);
    }

    // ---- read does not imply write, on the same resource type ----

    public function test_documents_view_does_not_grant_documents_ingest(): void
    {
        $reader = $this->memberWith(['documents.view' => true]);
        Sanctum::actingAs($reader);

        $response = $this->postJson('/api/document-library/documents', [
            'project_id' => $this->project->id, 'file' => $this->realPdf(),
        ]);

        $response->assertStatus(403);
    }

    // ---- foreign-project resource access is refused/not-found, never authorized by id alone ----

    public function test_a_change_order_from_a_different_project_is_not_reachable_through_this_projects_grant(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['tenant_id' => $this->tenant->id, 'number' => 'P-411', 'name' => 'Other',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $foreignOrder = ChangeOrder::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'number' => 'CO-X', 'title' => 'Other project work', 'status' => 'draft', 'amount_cents' => 100,
            'time_extension_days' => 0]);
        TenantContext::clear();

        // Holds changeorder.approve on THIS project, not the other one - a
        // membership row per project, never a tenant-wide grant.
        $approver = $this->memberWith(['changeorder.approve' => true]);
        Sanctum::actingAs($approver);

        $response = $this->postJson("/api/change-orders/{$foreignOrder->id}/approve", []);

        $response->assertStatus(403);
    }

    // ---- two-person control: holding both permissions is not being two people ----

    public function test_pay_application_certification_refuses_the_preparer_even_holding_the_certify_capability(): void
    {
        TenantContext::set($this->tenant->id);
        $this->project->forceFill(['payment_workflow' => ['requires_separate_certifier' => true]])->save();
        TenantContext::clear();

        $preparer = $this->memberWith(['payment.create' => true, 'payment.certify' => true, 'payment.view' => true]);
        Sanctum::actingAs($preparer);

        $created = $this->postJson('/api/pay-applications', [
            'project_id' => $this->project->id, 'period_from' => '2026-08-01', 'period_to' => '2026-08-31',
        ])->assertStatus(201)->json();
        $applicationId = $created['application']['id'];

        // The endpoint under normal use sets prepared_by when the preparer
        // bills a line (a fact about who last touched the numbers, not a
        // role assignment) - set directly here rather than build a full
        // schedule-of-values fixture just to reach that same field.
        TenantContext::set($this->tenant->id);
        \App\Models\PayApplication::find($applicationId)->forceFill(['prepared_by' => $preparer->id])->save();
        TenantContext::clear();

        $seen = $this->getJson("/api/pay-applications/{$applicationId}")->assertOk()->json('content_hash');

        $response = $this->postJson("/api/pay-applications/{$applicationId}/certify", [
            'certification_accepted' => true, 'content_hash_seen' => $seen,
        ]);

        $response->assertStatus(422);
        $this->assertStringContainsString('someone other than the person who prepared', $response->json('reason'));
    }

    // ---- licensing: only the platform admin or the sponsoring account owner may license an account ----

    public function test_an_ordinary_user_cannot_grant_a_license_to_an_unrelated_tenant(): void
    {
        $unrelatedTenant = Tenant::create(['name' => 'Southgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => [], 'sponsor_role' => 'contractor', 'is_account_owner' => true]);

        $ordinary = $this->memberWith(['*' => true]); // project-scoped admin, still not a licensing authority
        Sanctum::actingAs($ordinary);

        $response = $this->postJson("/api/licensing/customers/{$unrelatedTenant->id}/grant", [
            'capability' => 'schedule_intelligence',
        ]);

        $response->assertStatus(403);
    }

    // ---- structural: no controller infers authority from role name or ownership shortcuts ----

    public function test_no_project_scoped_controller_branches_on_a_hardcoded_seat_or_role_name(): void
    {
        // The defect this guards against: `if ($user->seat === 'pm') { ... }`
        // instead of asking ProjectAccess for the capability. A grep pattern
        // rather than a runtime assertion, because the failure mode is a
        // controller that quietly stops asking the gate and starts guessing
        // from a label - which a positive-path test would not catch, since
        // the label usually happens to be right for whoever wrote the test.
        $offenders = [];

        foreach (glob(app_path('Http/Controllers/*.php')) as $file) {
            $name = basename($file);
            if (in_array($name, ['AccountController.php', 'AuthController.php', 'PlatformController.php'], true)) {
                // Account/auth/platform-staff surfaces are not project-scoped
                // RBAC; they branch on platform_role by design (platform
                // staff vs. tenant users), which is a different axis than
                // ProjectAccess capabilities.
                continue;
            }
            $source = file_get_contents($file);
            if (preg_match('/->seat\s*===?\s*[\'"]|->role\s*===?\s*[\'"]/', $source)) {
                $offenders[] = $name;
            }
        }

        $this->assertSame([], $offenders,
            'A project-scoped controller branches on seat/role name directly: '.implode(', ', $offenders));
    }
}
