<?php

namespace Tests\Feature;

use App\Models\AiFinding;
use App\Models\FindingEvidence;
use App\Models\MediaItem;
use App\Models\PayApplication;
use App\Models\PayApplicationReviewContext;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleOfValueItem;
use App\Models\ScheduleVersion;
use App\Models\SovScheduleLink;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * TRACE Progress Evidence Cross-Check - schema-only first PR for the closed
 * design in claude/trace-progress-vs-schedule-deviation-design-brief.md.
 * No rule logic yet (that is deliberately a later PR) - these tests only
 * establish that the four new tables/models hold the invariants Codex's
 * review closed the design on:
 *
 *   - SovScheduleLink's pairing is fixed at creation; only verification
 *     status may change, and AI-suggested mappings never carry VERIFIED
 *     status until a human sets it.
 *   - PayApplicationReviewContext is frozen at creation and never edited,
 *     so a re-evaluation writes a new context row rather than mutating the
 *     comparison basis of a past one (the "active ScheduleVersion" bug).
 *   - AiFinding can never be created with a finding_class outside
 *     OBSERVATION/DATA_GAP/PROPOSAL - TRACE never persists an adjudication -
 *     and only its resolution status may change after creation.
 *   - FindingEvidence is append-only, matching RetrievalTrace's existing
 *     pattern.
 */
class TraceProgressEvidenceCrossCheckTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    private ScheduleVersion $scheduleVersion;

    private ScheduleActivity $activity;

    private ScheduleOfValueItem $sovItem;

    private PayApplication $payApplication;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);

        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => hash('sha256', 'schedule.xer'), 'storage_path' => 'test/schedule.xer',
            'original_name' => 'schedule.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov'), 'confidence' => 'strong',
            'captured_by' => $this->user->id]);

        $this->scheduleVersion = ScheduleVersion::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'kind' => 'lookahead', 'label' => 'Update #4',
            'data_date' => '2026-07-31', 'submitted_by_org' => 'Northgate', 'submitted_at' => now(),
            'source_file_media_id' => $media->id, 'source_format' => 'xer', 'parser_name' => 'primavera',
            'parser_version' => '1.0', 'source_sha256' => hash('sha256', 'schedule.xer'),
            'ingest_assumptions' => [], 'security_scan' => [], 'created_by' => $this->user->id]);

        $this->activity = ScheduleActivity::create(['tenant_id' => $this->tenant->id,
            'schedule_version_id' => $this->scheduleVersion->id, 'activity_code' => 'A1220',
            'name' => 'Pour sidewalk']);

        $this->sovItem = ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'item_number' => '03-200',
            'description' => 'Concrete Improvements', 'scheduled_value_cents' => 18000000,
            'original_value_cents' => 18000000]);

        $this->payApplication = PayApplication::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'number' => 6, 'period_from' => '2026-07-01',
            'period_to' => '2026-07-31']);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_an_ai_suggested_link_is_not_verified_until_a_human_sets_it(): void
    {
        TenantContext::set($this->tenant->id);
        $link = SovScheduleLink::create([
            'tenant_id' => $this->tenant->id,
            'schedule_of_value_item_id' => $this->sovItem->id,
            'schedule_activity_id' => $this->activity->id,
            'schedule_version_id' => $this->scheduleVersion->id,
            'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_AI_SUGGESTED,
        ]);
        TenantContext::clear();

        $this->assertSame(SovScheduleLink::STATUS_UNVERIFIED, $link->mapping_status);
        $this->assertFalse($link->isVerified());
    }

    public function test_a_human_can_verify_a_suggested_link_but_the_pairing_itself_is_fixed(): void
    {
        TenantContext::set($this->tenant->id);
        $link = SovScheduleLink::create([
            'tenant_id' => $this->tenant->id,
            'schedule_of_value_item_id' => $this->sovItem->id,
            'schedule_activity_id' => $this->activity->id,
            'schedule_version_id' => $this->scheduleVersion->id,
            'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_AI_SUGGESTED,
        ]);

        $link->update([
            'mapping_status' => SovScheduleLink::STATUS_VERIFIED,
            'verified_by' => $this->user->id,
            'verified_at' => now(),
        ]);
        $this->assertTrue($link->fresh()->isVerified());

        $this->expectException(\LogicException::class);
        $link->update(['schedule_activity_id' => $this->activity->id + 999]);
        TenantContext::clear();
    }

    public function test_a_pay_application_review_context_is_frozen_and_never_edited(): void
    {
        TenantContext::set($this->tenant->id);
        $context = PayApplicationReviewContext::create([
            'tenant_id' => $this->tenant->id,
            'pay_application_id' => $this->payApplication->id,
            'period_start' => '2026-07-01',
            'period_end' => '2026-07-31',
            'schedule_version_id' => $this->scheduleVersion->id,
            'schedule_data_date' => $this->scheduleVersion->data_date,
            'created_by' => $this->user->id,
            'frozen_at' => now(),
        ]);

        $this->expectException(\LogicException::class);
        $context->update(['period_end' => '2026-08-01']);
        TenantContext::clear();
    }

    public function test_a_re_evaluation_writes_a_new_context_row_instead_of_mutating_the_old_one(): void
    {
        // The fix for Codex's "active ScheduleVersion" finding: two contexts
        // for the same pay application, each citing its own schedule
        // version, must be able to coexist rather than the second
        // overwriting the first.
        TenantContext::set($this->tenant->id);
        $first = PayApplicationReviewContext::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'period_start' => '2026-07-01', 'period_end' => '2026-07-31',
            'schedule_version_id' => $this->scheduleVersion->id,
            'schedule_data_date' => $this->scheduleVersion->data_date,
            'created_by' => $this->user->id, 'frozen_at' => now(),
        ]);

        $laterVersion = ScheduleVersion::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'parent_version_id' => $this->scheduleVersion->id,
            'kind' => 'lookahead', 'label' => 'Update #5', 'data_date' => '2026-08-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(),
            'source_file_media_id' => $this->scheduleVersion->source_file_media_id, 'source_format' => 'xer',
            'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'schedule2.xer'),
            'ingest_assumptions' => [], 'security_scan' => [], 'created_by' => $this->user->id]);

        $second = PayApplicationReviewContext::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'period_start' => '2026-07-01', 'period_end' => '2026-07-31',
            'schedule_version_id' => $laterVersion->id, 'schedule_data_date' => $laterVersion->data_date,
            'created_by' => $this->user->id, 'frozen_at' => now(),
        ]);
        TenantContext::clear();

        $this->assertNotSame($first->id, $second->id);
        $this->assertSame($this->scheduleVersion->id, $first->fresh()->schedule_version_id,
            'The first context\'s frozen schedule version changed when a second context was created.');
        $this->assertSame($laterVersion->id, $second->schedule_version_id);
    }

    public function test_an_ai_finding_cannot_be_created_with_an_adjudication_class(): void
    {
        TenantContext::set($this->tenant->id);
        $context = $this->makeContext();

        $this->expectException(\LogicException::class);
        AiFinding::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'pay_application_review_context_id' => $context->id, 'rule_id' => 'TRACE-01',
            'rule_version' => '1.0', 'category' => 'CORROBORATION_GAP',
            'finding_class' => 'ADJUDICATION', // not a real allowed value
            'severity' => 'REVIEW', 'summary' => 'The contractor caused a delay.',
            'searched_universe' => [], 'evaluated_at' => now(),
        ]);
        TenantContext::clear();
    }

    public function test_an_ai_finding_records_an_observation_and_only_its_status_may_later_change(): void
    {
        TenantContext::set($this->tenant->id);
        $context = $this->makeContext();

        $finding = AiFinding::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'pay_application_review_context_id' => $context->id, 'rule_id' => 'TRACE-01',
            'rule_version' => '1.0', 'category' => 'CORROBORATION_GAP',
            'finding_class' => AiFinding::CLASSES[0], // OBSERVATION
            'severity' => 'REVIEW',
            'summary' => 'No linked daily-report evidence was found for Activity A1220 within July 1-31.',
            'searched_universe' => ['daily_reports_checked' => 22, 'activities' => ['A1220']],
            'evaluated_at' => now(),
        ]);

        $this->assertSame(AiFinding::STATUS_OPEN, $finding->status);

        $finding->update(['status' => AiFinding::STATUS_DISMISSED, 'resolved_by' => $this->user->id,
            'resolved_at' => now(), 'resolution_note' => 'Activity had float; work confirmed via inspection photo.']);
        $this->assertSame(AiFinding::STATUS_DISMISSED, $finding->fresh()->status);

        $this->expectException(\LogicException::class);
        $finding->update(['summary' => 'A different observation entirely.']);
        TenantContext::clear();
    }

    public function test_finding_evidence_cites_the_specific_source_records_and_is_append_only(): void
    {
        TenantContext::set($this->tenant->id);
        $context = $this->makeContext();
        $finding = AiFinding::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'pay_application_review_context_id' => $context->id, 'rule_id' => 'TRACE-01',
            'rule_version' => '1.0', 'category' => 'CORROBORATION_GAP',
            'finding_class' => 'DATA_GAP', 'severity' => 'REVIEW',
            'summary' => 'No linked daily-report evidence was found for Activity A1220 within July 1-31.',
            'searched_universe' => ['daily_reports_checked' => 22], 'evaluated_at' => now(),
        ]);

        $evidence = FindingEvidence::create([
            'tenant_id' => $this->tenant->id, 'ai_finding_id' => $finding->id,
            'source_type' => 'schedule_activity', 'source_id' => $this->activity->id,
            'evidence_role' => FindingEvidence::ROLE_EXPECTED_BUT_MISSING,
            'locator' => ['period_start' => '2026-07-01', 'period_end' => '2026-07-31'],
        ]);

        $this->assertCount(1, $finding->fresh()->evidence);
        $this->assertSame('schedule_activity', $evidence->source_type);
        $this->assertSame($this->activity->id, $evidence->source_id);

        $this->expectException(\LogicException::class);
        $evidence->update(['evidence_role' => FindingEvidence::ROLE_CONTEXT]);
        TenantContext::clear();
    }

    public function test_finding_evidence_cannot_be_deleted(): void
    {
        TenantContext::set($this->tenant->id);
        $context = $this->makeContext();
        $finding = AiFinding::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'pay_application_review_context_id' => $context->id, 'rule_id' => 'TRACE-01',
            'rule_version' => '1.0', 'category' => 'CORROBORATION_GAP',
            'finding_class' => 'DATA_GAP', 'severity' => 'REVIEW', 'summary' => 'x',
            'searched_universe' => [], 'evaluated_at' => now(),
        ]);
        $evidence = FindingEvidence::create([
            'tenant_id' => $this->tenant->id, 'ai_finding_id' => $finding->id,
            'source_type' => 'schedule_activity', 'source_id' => $this->activity->id,
            'evidence_role' => FindingEvidence::ROLE_EXPECTED_BUT_MISSING,
        ]);

        $this->expectException(\LogicException::class);
        $evidence->delete();
        TenantContext::clear();
    }

    public function test_sov_schedule_links_are_unique_per_pair_per_schedule_version(): void
    {
        TenantContext::set($this->tenant->id);
        SovScheduleLink::create([
            'tenant_id' => $this->tenant->id, 'schedule_of_value_item_id' => $this->sovItem->id,
            'schedule_activity_id' => $this->activity->id, 'schedule_version_id' => $this->scheduleVersion->id,
            'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_PM,
        ]);

        $this->expectException(\Illuminate\Database\QueryException::class);
        SovScheduleLink::create([
            'tenant_id' => $this->tenant->id, 'schedule_of_value_item_id' => $this->sovItem->id,
            'schedule_activity_id' => $this->activity->id, 'schedule_version_id' => $this->scheduleVersion->id,
            'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_AI_SUGGESTED,
        ]);
        TenantContext::clear();
    }

    private function makeContext(): PayApplicationReviewContext
    {
        return PayApplicationReviewContext::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $this->payApplication->id,
            'period_start' => '2026-07-01', 'period_end' => '2026-07-31',
            'schedule_version_id' => $this->scheduleVersion->id,
            'schedule_data_date' => $this->scheduleVersion->data_date,
            'created_by' => $this->user->id, 'frozen_at' => now(),
        ]);
    }
}
