<?php

namespace Tests\Feature;

use App\Models\MediaItem;
use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use App\Models\Tenant;
use App\Models\TimeCard;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Contractor time cards - a first-class feature (see database/migrations/
 * 2026_08_27_070000_create_time_cards_table.php), not the hidden sub-array
 * of Daily Report submission it used to be. Submission and approval are
 * separate acts, the same shape as ChangeOrderControllerTest expects of
 * change orders.
 */
class TimeCardTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $contractor;
    private User $viewerOnly;
    private Project $project;
    private ScheduleActivity $activity;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->contractor = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Foreman', 'email' => 'foreman@northgate.test', 'password' => bcrypt('password')]);
        $this->viewerOnly = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Viewer', 'email' => 'viewer@northgate.test', 'password' => bcrypt('password')]);

        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->contractor->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->viewerOnly->id,
            'organization' => 'Northgate Builders', 'seat' => 'viewer', 'capabilities' => ['timecard.view' => true]]);

        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => hash('sha256', 'schedule.xer'), 'storage_path' => 'test/schedule.xer',
            'original_name' => 'schedule.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov'), 'confidence' => 'strong',
            'captured_by' => $this->contractor->id]);
        $version = ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'kind' => 'lookahead', 'label' => 'Update #4', 'data_date' => '2026-07-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(), 'source_file_media_id' => $media->id,
            'source_format' => 'xer', 'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'schedule.xer'), 'ingest_assumptions' => [], 'security_scan' => [],
            'created_by' => $this->contractor->id]);
        $this->activity = ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $version->id,
            'activity_code' => 'A1220', 'name' => 'Pour sidewalk', 'activity_type' => 'CONSTRUCTION',
            'start_planned' => '2026-07-10', 'finish_planned' => '2026-07-20']);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function validLine(array $overrides = []): array
    {
        return array_merge([
            'schedule_activity_id' => $this->activity->id,
            'work_date' => '2026-07-15',
            'resource_code' => 'OP-4', 'resource_name' => 'J. Alvarez',
            'resource_type' => 'labor', 'pay_class' => 'LA3', 'cost_code' => '6.01',
            'hours' => 8.5,
        ], $overrides);
    }

    public function test_a_time_card_can_be_submitted_with_lines(): void
    {
        Sanctum::actingAs($this->contractor);

        $body = $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine(), $this->validLine(['resource_code' => 'LB-1', 'resource_name' => 'M. Ortiz', 'hours' => 8])],
        ])->assertCreated()->json();

        $this->assertSame('submitted', $body['status']);
        $this->assertCount(2, $body['lines']);
        $this->assertSame('16.50', $body['total_hours']);
        $this->assertSame($this->activity->id, $body['lines'][0]['schedule_activity_id']);
    }

    public function test_a_schedule_activity_id_from_another_project_is_not_attached(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['number' => 'P-600', 'name' => 'Other', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $otherMedia = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'sha256' => hash('sha256', 'o.xer'), 'storage_path' => 'test/o.xer', 'original_name' => 'o.xer',
            'mime' => 'application/octet-stream', 'bytes' => 10, 'provenance' => [], 'provenance_signature' => hash('sha256', 'p2'),
            'confidence' => 'strong', 'captured_by' => $this->contractor->id]);
        $otherVersion = ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'kind' => 'lookahead', 'label' => 'U1', 'data_date' => '2026-07-31', 'submitted_by_org' => 'X',
            'submitted_at' => now(), 'source_file_media_id' => $otherMedia->id, 'source_format' => 'xer',
            'parser_name' => 'primavera', 'parser_version' => '1.0', 'source_sha256' => hash('sha256', 'o2'),
            'ingest_assumptions' => [], 'security_scan' => [], 'created_by' => $this->contractor->id]);
        $otherActivity = ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $otherVersion->id,
            'activity_code' => 'X1', 'name' => 'Other', 'activity_type' => 'CONSTRUCTION',
            'start_planned' => '2026-07-10', 'finish_planned' => '2026-07-20']);
        TenantContext::clear();

        Sanctum::actingAs($this->contractor);
        $body = $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine(['schedule_activity_id' => $otherActivity->id])],
        ])->assertCreated()->json();

        $this->assertNull($body['lines'][0]['schedule_activity_id']);
    }

    public function test_approving_requires_a_determination_and_moves_status(): void
    {
        Sanctum::actingAs($this->contractor);
        $body = $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine()],
        ])->assertCreated()->json();

        $this->postJson('/api/time-cards/' . $body['id'] . '/approve', ['decision' => 'approve'])
            ->assertStatus(422);

        $this->postJson('/api/time-cards/' . $body['id'] . '/approve', [
            'decision' => 'approve', 'determination' => 'Hours match the foreman log.',
        ])->assertOk()->assertJsonPath('status', 'approved');
    }

    public function test_a_time_card_cannot_be_approved_twice(): void
    {
        Sanctum::actingAs($this->contractor);
        $body = $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine()],
        ])->assertCreated()->json();
        $this->postJson('/api/time-cards/' . $body['id'] . '/approve', [
            'decision' => 'approve', 'determination' => 'Approved.',
        ])->assertOk();

        $this->postJson('/api/time-cards/' . $body['id'] . '/approve', [
            'decision' => 'approve', 'determination' => 'Trying again.',
        ])->assertStatus(422);
    }

    public function test_a_viewer_without_timecard_create_cannot_submit_but_can_view(): void
    {
        Sanctum::actingAs($this->viewerOnly);

        $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine()],
        ])->assertStatus(403);

        $this->getJson('/api/time-cards?project_id=' . $this->project->id)->assertOk();
    }

    public function test_index_surfaces_eligible_activities_alongside_the_list(): void
    {
        Sanctum::actingAs($this->contractor);
        $this->postJson('/api/time-cards', [
            'project_id' => $this->project->id,
            'pay_period_start' => '2026-07-13', 'pay_period_end' => '2026-07-19',
            'lines' => [$this->validLine()],
        ])->assertCreated();

        $body = $this->getJson('/api/time-cards?project_id=' . $this->project->id)->assertOk()->json();

        $this->assertCount(1, $body['time_cards']);
        $this->assertCount(1, $body['eligible_activities']);
    }
}
