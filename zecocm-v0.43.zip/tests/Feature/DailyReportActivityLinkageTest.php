<?php

namespace Tests\Feature;

use App\Models\DailyReport;
use App\Models\MediaItem;
use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Daily reports gain: (1) the ability to tag which schedule activities were
 * worked on a given day (App\Models\DailyReportActivity - built for TRACE,
 * but never surfaced anywhere until now), (2) an edit path before lock, and
 * (3) the append-only correction path after lock (App\Models\DailyReport::
 * correct() existed with no route into it).
 */
class DailyReportActivityLinkageTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $pm;
    private Project $project;
    private ScheduleActivity $activity;
    private ScheduleActivity $otherProjectActivity;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->pm = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);

        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);

        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => hash('sha256', 'schedule.xer'), 'storage_path' => 'test/schedule.xer',
            'original_name' => 'schedule.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov'), 'confidence' => 'strong',
            'captured_by' => $this->pm->id]);
        $version = ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'kind' => 'lookahead', 'label' => 'Update #4', 'data_date' => '2026-07-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(), 'source_file_media_id' => $media->id,
            'source_format' => 'xer', 'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'schedule.xer'), 'ingest_assumptions' => [], 'security_scan' => [],
            'created_by' => $this->pm->id]);
        $this->activity = ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $version->id,
            'activity_code' => 'A1220', 'name' => 'Pour sidewalk', 'activity_type' => 'CONSTRUCTION',
            'start_planned' => '2026-07-10', 'finish_planned' => '2026-07-20']);
        ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $version->id,
            'activity_code' => 'M100', 'name' => 'Notice to proceed', 'activity_type' => 'MILESTONE',
            'start_planned' => '2026-07-01', 'finish_planned' => '2026-07-01']);

        // A second project's schedule activity - must never be attachable to
        // the first project's daily report, tenant-scoped or not.
        $otherProject = Project::create(['number' => 'P-600', 'name' => 'Other Project', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $otherMedia = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'sha256' => hash('sha256', 'other.xer'), 'storage_path' => 'test/other.xer',
            'original_name' => 'other.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov2'), 'confidence' => 'strong',
            'captured_by' => $this->pm->id]);
        $otherVersion = ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'kind' => 'lookahead', 'label' => 'Update #1', 'data_date' => '2026-07-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(), 'source_file_media_id' => $otherMedia->id,
            'source_format' => 'xer', 'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'other.xer'), 'ingest_assumptions' => [], 'security_scan' => [],
            'created_by' => $this->pm->id]);
        $this->otherProjectActivity = ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $otherVersion->id,
            'activity_code' => 'X1', 'name' => 'Other project activity', 'activity_type' => 'CONSTRUCTION',
            'start_planned' => '2026-07-10', 'finish_planned' => '2026-07-20']);

        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_index_surfaces_eligible_field_production_activities_only(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->getJson('/api/daily-reports?project_id=' . $this->project->id)->assertOk()->json();

        $this->assertCount(1, $body['eligible_activities']);
        $this->assertSame('A1220', $body['eligible_activities'][0]['activity_code']);
    }

    public function test_store_creates_daily_report_activity_rows_for_eligible_activities(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Poured sidewalk sections 3-5.',
            'activities' => [
                ['schedule_activity_id' => $this->activity->id, 'work_status' => 'performed', 'notes' => 'Sections 3-5 complete.'],
            ],
        ])->assertCreated()->json();

        $this->assertCount(1, $body['activities']);
        $this->assertSame($this->activity->id, $body['activities'][0]['schedule_activity_id']);
        $this->assertSame('performed', $body['activities'][0]['work_status']);
    }

    public function test_store_silently_drops_a_schedule_activity_id_from_another_project(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Poured sidewalk sections 3-5.',
            'activities' => [
                ['schedule_activity_id' => $this->otherProjectActivity->id],
            ],
        ])->assertCreated()->json();

        $this->assertCount(0, $body['activities']);
    }

    public function test_a_report_can_be_edited_before_it_is_locked(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Original text.',
        ])->assertCreated()->json();

        $this->putJson('/api/daily-reports/' . $body['id'], ['work_performed' => 'Corrected before signing.'])
            ->assertOk()->assertJsonPath('work_performed', 'Corrected before signing.');
    }

    public function test_a_locked_report_cannot_be_edited_directly(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Original text.',
        ])->assertCreated()->json();
        $this->postJson('/api/daily-reports/' . $body['id'] . '/lock')->assertOk();

        $this->putJson('/api/daily-reports/' . $body['id'], ['work_performed' => 'Trying to rewrite history.'])
            ->assertStatus(422);
    }

    public function test_a_locked_report_accepts_an_append_only_correction(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Original text.',
        ])->assertCreated()->json();
        $this->postJson('/api/daily-reports/' . $body['id'] . '/lock')->assertOk();

        $corrected = $this->postJson('/api/daily-reports/' . $body['id'] . '/correct', [
            'field' => 'work_performed', 'new_value' => 'Original text, plus the section we missed.',
            'reason' => 'Foreman flagged an omission the next morning.',
        ])->assertOk()->json();

        $this->assertCount(1, $corrected['corrections']);
        $this->assertSame('work_performed', $corrected['corrections'][0]['field']);
        // The locked field itself is untouched - corrections append, they never overwrite.
        $this->assertSame('Original text.', $corrected['work_performed']);
    }

    public function test_a_report_that_is_not_locked_cannot_receive_a_correction(): void
    {
        Sanctum::actingAs($this->pm);
        $body = $this->postJson('/api/daily-reports', [
            'project_id' => $this->project->id, 'report_date' => '2026-07-15',
            'work_performed' => 'Original text.',
        ])->assertCreated()->json();

        $this->postJson('/api/daily-reports/' . $body['id'] . '/correct', [
            'field' => 'work_performed', 'new_value' => 'Too early for this.', 'reason' => 'testing',
        ])->assertStatus(422);
    }
}
