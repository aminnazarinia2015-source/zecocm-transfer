<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * setStatus() already let an admin suspend a customer (CustomerStatusTest). Two
 * gaps remained: no way to edit a customer's own identifying details at all,
 * and no way to remove an account created by mistake (a duplicate, a test
 * entry) that was never actually used - suspension doesn't erase it, and
 * a genuinely mistaken empty record isn't "history" worth preserving.
 * Delete stays narrow: any real project on the account fails it closed.
 */
class CustomerEditAndDeleteTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function admin(): User
    {
        return User::create(['name' => 'Amin', 'email' => 'amin@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'admin']);
    }

    private function technician(): User
    {
        return User::create(['name' => 'Tech', 'email' => 'tech@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'technician']);
    }

    private function tenant(): Tenant
    {
        return Tenant::create(['name' => 'Testco', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
    }

    public function test_admin_can_edit_a_customers_identifying_details(): void
    {
        $tenant = $this->tenant();
        Sanctum::actingAs($this->admin());

        $res = $this->putJson("/api/platform/customers/{$tenant->id}", [
            'name' => 'Testco Corrected',
            'legal_name' => 'Testco Corrected, Inc.',
            'address_lines' => ['100 Main St', 'Fresno, CA'],
        ])->assertOk();

        $this->assertSame('Testco Corrected', $res->json('name'));
        $this->assertSame('Testco Corrected, Inc.', $tenant->fresh()->legal_name);
        $this->assertSame(['100 Main St', 'Fresno, CA'], $tenant->fresh()->address_lines);
    }

    public function test_a_technician_cannot_edit_customer_details(): void
    {
        $tenant = $this->tenant();
        Sanctum::actingAs($this->technician());

        $this->putJson("/api/platform/customers/{$tenant->id}", ['name' => 'Hijacked'])
            ->assertStatus(403);
        $this->assertSame('Testco', $tenant->fresh()->name);
    }

    public function test_an_empty_customer_with_no_projects_can_be_deleted(): void
    {
        $tenant = $this->tenant();
        Sanctum::actingAs($this->admin());

        $this->deleteJson("/api/platform/customers/{$tenant->id}")->assertOk();
        $this->assertDatabaseMissing('tenants', ['id' => $tenant->id]);
    }

    public function test_a_customer_with_any_project_cannot_be_deleted(): void
    {
        $tenant = $this->tenant();
        TenantContext::set($tenant->id);
        Project::create(['number' => 'P-1', 'name' => 'Real project', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        TenantContext::clear();
        Sanctum::actingAs($this->admin());

        $this->deleteJson("/api/platform/customers/{$tenant->id}")->assertStatus(422);
        $this->assertDatabaseHas('tenants', ['id' => $tenant->id]);
    }

    public function test_a_technician_cannot_delete_a_customer(): void
    {
        $tenant = $this->tenant();
        Sanctum::actingAs($this->technician());

        $this->deleteJson("/api/platform/customers/{$tenant->id}")->assertStatus(403);
        $this->assertDatabaseHas('tenants', ['id' => $tenant->id]);
    }
}
