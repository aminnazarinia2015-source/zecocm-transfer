<?php

namespace App\Domain\Schedule;

use App\Models\Membership;
use App\Models\Project;
use App\Models\User;
use App\Tenancy\TenantContext;

final class ProjectAccess
{
    public function authorize(User $user, int $projectId, string $capability, bool $write = false): ProjectGrant
    {
        $project = Project::query()->findOrFail($projectId);

        if ($user->isPlatformStaff()) {
            abort_if(TenantContext::tenantId() !== $project->tenant_id, 403, 'Open the customer workspace before accessing project data.');
            abort_if($write && ! TenantContext::isSupportMode(), 403, 'Technicians are read-only in customer workspaces.');

            $grant = new ProjectGrant(
                project: $project,
                userId: $user->id,
                seat: $user->isPlatformAdmin() ? 'platform_admin_support' : 'platform_technician',
                organization: 'ZecoCM platform',
                capabilities: $user->isPlatformAdmin()
                    ? ['*' => true]
                    : [
                        'project.view' => true,
                        'weather.view' => true,
                        'documents.view' => true,
                        'assistant.use' => true,
                        'records.view' => true,
                        'schedule.view' => true,
                    ],
                platformSupport: true,
            );
        } else {
            $membership = Membership::query()
                ->where('project_id', $project->id)
                ->where('user_id', $user->id)
                ->first();
            abort_if($membership === null, 403, 'No project grant exists for this account.');
            // A revoked grant must actually stop authorizing, not just read as
            // revoked in the Users & Access screen - the status column added
            // for that screen would otherwise be cosmetic.
            abort_if($membership->status === Membership::STATUS_REVOKED, 403, 'This project grant has been revoked.');

            $grant = new ProjectGrant(
                project: $project,
                userId: $user->id,
                seat: $membership->seat,
                organization: $membership->organization,
                capabilities: $membership->capabilities ?? [],
                platformSupport: false,
            );
        }

        abort_unless($grant->allows($capability), 403, 'This project grant does not permit the requested action.');

        return $grant;
    }
}
