<?php

namespace App\Providers;

use App\Domain\Ops\DatabaseWriteHealthCheck;
use App\Domain\Ops\EvidenceStorageHealthCheck;
use App\Domain\Ops\QueueBacklogHealthCheck;
use App\Domain\Ops\QueueHeartbeatHealthCheck;
use App\Domain\Ops\SqlitePragmaHealthCheck;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Events\DiagnosingHealth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by(Str::lower((string) $request->input('email')).'|'.$request->ip());
        });

        // Self-serve contractor onboarding is the one anonymous write surface in the app —
        // throttled by IP to make it a much less useful target for scripted spam registrations.
        RateLimiter::for('registration', function (Request $request) {
            return Limit::perMinute(10)->by($request->ip());
        });

        // OPS-15: makes `/up` dependency-aware, per Codex's explicit ruling -
        // a failing dependency must make `/up` fail, and the check belongs
        // ON `/up` rather than a separate endpoint. Laravel dispatches this
        // event from its own built-in `/up` route before responding; an
        // uncaught exception from a listener turns the response into a 500.
        Event::listen(DiagnosingHealth::class, DatabaseWriteHealthCheck::class);

        // OPS-14: application-side conditions that can make /up truthful,
        // per Codex's ruling - each either passes silently or throws (no
        // new degrade vocabulary in /up's own HTTP contract); severity for
        // alerting purposes is logged separately inside each check. Failed
        // jobs are deliberately NOT here - see ReportFailedJobDelta's doc
        // comment for why that stays alert-only.
        Event::listen(DiagnosingHealth::class, QueueHeartbeatHealthCheck::class);
        Event::listen(DiagnosingHealth::class, QueueBacklogHealthCheck::class);
        Event::listen(DiagnosingHealth::class, EvidenceStorageHealthCheck::class);
        Event::listen(DiagnosingHealth::class, SqlitePragmaHealthCheck::class);
    }
}
