<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\DailyReport;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use App\Services\WeatherService;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DailyReportController
{
    public function __construct(
        private readonly WeatherService $weather,
        private readonly ProjectAccess $access,
    ) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'records.view');

        $reports = DailyReport::where('project_id', $grant->project->id)
            ->with(['timeCardEntries', 'signatureAttestations', 'activities.scheduleActivity'])
            ->orderByDesc('report_date')
            ->paginate(31);

        // Surfaced alongside the list, not as a separate round trip - the "which
        // activities were worked" checklist needs this to render the form at
        // all, and it is cheap: at most one field-production activity list per
        // project's current schedule version.
        return response()->json([
            'data' => $reports->items(),
            'current_page' => $reports->currentPage(),
            'last_page' => $reports->lastPage(),
            'total' => $reports->total(),
            'eligible_activities' => $this->eligibleActivities($grant->project->id),
        ]);
    }

    public function store(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'required|integer',
            'report_date' => 'required|date',
            'work_performed' => 'required|string',
            'site_conditions' => 'nullable|string',
            'delays' => 'nullable|string',
            'cost_code_notes' => 'array',
            'time_card' => 'array',              // [{resource_code,resource_name,resource_type,pay_class,cost_code,hours}]
            'activities' => 'array',              // [{schedule_activity_id,work_status,notes}]
            'activities.*.schedule_activity_id' => 'required_with:activities|integer',
            'activities.*.work_status' => 'nullable|in:performed,no_work_this_visit',
            'activities.*.notes' => 'nullable|string|max:2000',
            'lat' => 'nullable|numeric',
            'lng' => 'nullable|numeric',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'daily.create', write: true);

        // Weather retrieved from an authoritative source WITH attribution
        // (Aspect 2) - attributable, never merely asserted.
        $weather = ($data['lat'] ?? null) !== null
            ? $this->weather->current((float) $data['lat'], (float) $data['lng'])
            : null;

        $report = DB::transaction(function () use ($data, $grant, $weather, $request) {
            $report = DailyReport::create([
                'project_id' => $grant->project->id,
                'report_date' => $data['report_date'],
                'foreman_id' => $request->user()->id,
                'weather' => $weather,
                'work_performed' => $data['work_performed'],
                'site_conditions' => $data['site_conditions'] ?? null,
                'delays' => $data['delays'] ?? null,
                'cost_code_notes' => $data['cost_code_notes'] ?? [],
                'corrections' => [],
            ]);

            foreach ($data['time_card'] ?? [] as $entry) {
                $report->timeCardEntries()->create($entry + ['tenant_id' => $report->tenant_id]);
            }

            foreach ($data['activities'] ?? [] as $activity) {
                // Resolved through the project (via the activity's own schedule
                // version), so an id from another project - or another tenant -
                // simply does not exist here and the row is never created.
                $scheduleActivity = ScheduleActivity::query()
                    ->where('id', $activity['schedule_activity_id'])
                    ->whereIn('schedule_version_id', function ($q) use ($report) {
                        $q->select('id')->from('schedule_versions')->where('project_id', $report->project_id);
                    })
                    ->first();
                if ($scheduleActivity === null) {
                    continue;
                }
                $report->activities()->create([
                    'tenant_id' => $report->tenant_id,
                    'schedule_activity_id' => $scheduleActivity->id,
                    'work_status' => $activity['work_status'] ?? 'performed',
                    'notes' => $activity['notes'] ?? null,
                ]);
            }

            return $report;
        });

        return response()->json($report->load(['timeCardEntries', 'activities.scheduleActivity']), 201);
    }

    /** Editable up to the point of signature - a locked report is edited only through correct(). */
    public function update(Request $request, DailyReport $report)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), $report->project_id, 'daily.create', write: true);
        abort_if($report->locked, 422, 'This report is signed and locked. Use the correction endpoint instead - locked facts append, they do not get rewritten.');

        $data = $request->validate([
            'work_performed' => 'sometimes|required|string',
            'site_conditions' => 'nullable|string',
            'delays' => 'nullable|string',
            'cost_code_notes' => 'array',
        ]);
        $report->update($data);

        return response()->json($report->fresh(['timeCardEntries', 'activities.scheduleActivity']));
    }

    /** The one path into a locked report: append-only, reasoned, and attributed. */
    public function correct(Request $request, DailyReport $report)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), $report->project_id, 'daily.lock', write: true);
        abort_unless($report->locked, 422, 'Corrections are for locked reports - edit the report directly before locking it.');

        $data = $request->validate([
            'field' => 'required|string|max:64',
            'new_value' => 'required|string|max:4000',
            'reason' => 'required|string|max:2000',
        ]);

        $report->correct($data['field'], $data['new_value'], $request->user()->id, $data['reason']);
        $report->save();

        return response()->json($report->fresh());
    }

    public function lock(Request $request, DailyReport $report)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), $report->project_id, 'daily.lock', write: true);

        $report->update([
            'locked' => true,
            'lock_seal' => [
                'by' => $request->user()->id,
                'sealed_at' => now()->toIso8601String(),
            ],
        ]);

        return response()->json($report);   // corrections APPEND from here on
    }

    /** Same "current schedule version" rule TRACE uses - the most recent by data_date. */
    private function eligibleActivities(int $projectId): array
    {
        $version = ScheduleVersion::where('project_id', $projectId)->orderByDesc('data_date')->first();
        if ($version === null) {
            return [];
        }

        return ScheduleActivity::where('schedule_version_id', $version->id)
            ->whereIn('activity_type', ScheduleActivity::FIELD_PRODUCTION_TYPES)
            ->orderBy('activity_code')
            ->limit(500)
            ->get(['id', 'activity_code', 'name'])
            ->all();
    }
}
