<?php

namespace App\Http\Controllers;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\PlatformSuggestion;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;

/**
 * The ZecoCM owner console. Admin-only for mutations; technicians get
 * read access per their permission switches and a suggestions outbox.
 */
class PlatformController
{
    public function customers(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);

        // Counts must bypass tenant scoping - platform staff have no tenant
        // context, and fail-closed scoping would report 0 for everyone.
        return Tenant::orderBy('name')->get()->map(function ($t) {
            $admin = User::where('tenant_id', $t->id)->orderBy('id')->first();

            return [
                'id' => $t->id,
                'name' => $t->name,
                'type' => $t->type,
                'status' => $t->status,
                'entitlements' => $t->entitlements,
                'sections_count' => is_array($t->entitlements) ? count(array_filter($t->entitlements)) : 0,
                'projects_count' => Project::withoutGlobalScopes()->where('tenant_id', $t->id)->count(),
                'users_count' => User::where('tenant_id', $t->id)->count(),
                'admin_name' => $admin?->name,
                'admin_email' => $admin?->email,
                'created_at' => $t->created_at,
            ];
        });
    }

    /** Staff drill-down: a customer's projects, read-only. */
    public function customerProjects(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);

        return Project::withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->orderBy('number')
            ->get(['id', 'number', 'name', 'sector', 'owner_name', 'state']);
    }

    public function storeCustomer(Request $request)
    {
        abort_unless(
            $request->user()->isPlatformAdmin() || $request->user()->can_('create_customers'),
            403, 'Your profile cannot create customers.'
        );

        $data = $request->validate([
            'name' => 'required|string|max:128',
            'type' => 'required|string|max:64',        // extendable - data, not enum
            'entitlements' => 'array',
            'admin_name' => 'required|string|max:128',
            'admin_email' => 'required|email|unique:users,email',
        ]);

        $entitlements = $data['entitlements'] ?? Tenant::defaultEntitlements($data['type']);
        $tenant = Tenant::create([
            'name' => $data['name'],
            'type' => $data['type'],
            'entitlements' => $entitlements,
            'status' => 'trial',
        ]);

        $tempPassword = bin2hex(random_bytes(8));
        User::create([
            'tenant_id' => $tenant->id,
            'name' => $data['admin_name'],
            'email' => $data['admin_email'],
            'password' => bcrypt($tempPassword),
        ]);

        // Entitlements drive presentation; capability grants enforce access and
        // preserve an auditable commercial history. Create both atomically in intent.
        $licenses = app(CapabilityLicense::class);
        foreach ($entitlements as $capability) {
            if (CapabilityCatalog::has($capability) && ! CapabilityCatalog::isFree($capability)) {
                $licenses->grant($tenant, $capability, planReference: 'Initial account configuration',
                    actorUserId: $request->user()->id, reason: 'Granted when account was created');
            }
        }

        // TODO(mail): send invite. Returned once here so the admin can relay it.
        return response()->json(['tenant' => $tenant, 'admin_temp_password' => $tempPassword], 201);
    }

    /**
     * Edit a customer's own identifying details - name, legal name, address,
     * brand. This is distinct from assignSections() (what they're licensed
     * for) and setStatus() (whether they can sign in): those already
     * existed; basic identity fields did not have any edit path at all.
     */
    public function updateCustomer(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin edits customer details.');

        $data = $request->validate([
            'name' => 'sometimes|required|string|max:128',
            'type' => 'sometimes|required|string|max:64',
            'legal_name' => 'nullable|string|max:255',
            'address_lines' => 'nullable|array',
            'address_lines.*' => 'string|max:255',
            'brand_accent' => 'nullable|string|max:16',
            'brand_mark' => 'nullable|string|max:8',
        ]);
        $tenant->update($data);

        return response()->json($tenant->fresh());
    }

    /**
     * Delete a customer record outright - deliberately narrow. The platform's
     * core invariant is that real records are never silently erased (see
     * setStatus() above); a tenant that has ever created a project carries
     * that history and must be suspended, not deleted, if access needs to
     * end. This exists for the one honest case that invariant doesn't cover:
     * an account created by mistake (a duplicate, a test entry) that was
     * never actually used. If it has any project, it fails closed.
     */
    public function deleteCustomer(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin deletes a customer account.');

        $projectCount = Project::withoutGlobalScopes()->where('tenant_id', $tenant->id)->count();
        abort_if($projectCount > 0, 422,
            "This account has {$projectCount} project(s) on it and cannot be deleted - that would erase real "
            .'project history. Suspend it instead (Status), or contact support if it must be removed anyway.');

        User::where('tenant_id', $tenant->id)->delete();
        $tenant->delete();

        return response()->json(['message' => 'Customer account deleted - it had no projects on it.']);
    }

    public function assignSections(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin assigns sections.');
        $data = $request->validate(['entitlements' => 'required|array']);
        $tenant->update(['entitlements' => $data['entitlements']]);

        return response()->json($tenant);
    }

    /**
     * Suspend or reactivate a customer account. This is deliberately NOT a
     * delete: the platform's core design invariant is that records are never
     * silently erased (see the Security & Trust page - "the present never
     * rewrites the past"). Suspending blocks that tenant's users from
     * signing in; it does not touch their projects, documents, or history,
     * and can be reversed by setting status back to 'active'.
     */
    public function setStatus(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin changes account status.');
        $data = $request->validate(['status' => 'required|in:active,trial,suspended']);
        $tenant->update(['status' => $data['status']]);

        return response()->json($tenant);
    }

    /**
     * Read-only queue of self-serve requests from the homepage's "Get
     * started" form (Onboarding\RegistrationController::store). That form
     * only captures an organization profile - no payment happens there -
     * so every row here is 'pending_payment': a human still has to follow
     * up to complete payment setup and provision the account.
     */
    public function registrations(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);

        return \App\Models\ContractorRegistration::orderByDesc('created_at')->limit(200)->get([
            'id', 'registration_id', 'legal_name', 'business_name', 'entity_type', 'plan', 'country',
            'admin_first_name', 'admin_last_name', 'phone', 'email', 'status', 'created_at',
        ]);
    }

    /**
     * Read-only(ish) queue of "show me the full product" leads from the homepage's
     * "Request a full demo" form (Onboarding\DemoController::requestFullDemo). A human follows up
     * and schedules the demo directly; updateDemoRequest() below just tracks that follow-up
     * (contacted/scheduled/closed) — it never provisions anything itself.
     */
    public function demoRequests(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);

        return \App\Models\DemoRequest::orderByDesc('created_at')->limit(200)->get();
    }

    public function updateDemoRequest(Request $request, \App\Models\DemoRequest $demoRequest)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);
        $data = $request->validate(['status' => 'required|in:pending,contacted,scheduled,closed']);
        $demoRequest->update($data);

        return response()->json($demoRequest);
    }

    public function suggestions(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);

        return PlatformSuggestion::orderByDesc('created_at')->paginate(50);
    }

    public function storeSuggestion(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403);
        $data = $request->validate([
            'tenant_id' => 'nullable|integer|exists:tenants,id',
            'about' => 'required|string|max:255',
            'suggestion' => 'required|string',
        ]);

        return response()->json(PlatformSuggestion::create($data + [
            'suggested_by' => $request->user()->id,
        ]), 201);
    }

    public function resolveSuggestion(Request $request, PlatformSuggestion $suggestion)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin resolves suggestions.');
        $data = $request->validate(['status' => 'required|in:approved,dismissed']);
        $suggestion->update($data + [
            'resolved_by' => $request->user()->id,
            'resolved_at' => now(),
        ]);

        return response()->json($suggestion);
    }
}
