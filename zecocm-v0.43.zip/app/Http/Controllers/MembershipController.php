<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\Membership;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * "Users & access" and "Staff & permissions" were static mockups (a `#tb-
 * users` table nothing ever populated, an "Add person" wizard whose fields
 * had no `id` attributes and whose "Send invite" button called a function
 * that saved nothing) - this is the module that had never been connected to
 * a tenant-authorized source at all. See claude/admin-rbac-design.md.
 *
 * Deliberately no fixed capability whitelist here, matching the rest of this
 * codebase (ProjectAccess::authorize takes a free-form string) - a project
 * can invent whatever capability keys its own workflows check for.
 */
class MembershipController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'membership.view')->project;

        $memberships = Membership::query()->where('project_id', $project->id)
            ->with('user')->orderBy('id')->get();

        return response()->json([
            'memberships' => $memberships->map(fn (Membership $m) => $this->digest($m)),
        ]);
    }

    public function store(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'required|integer',
            'name' => 'required|string|max:128',
            'email' => 'required|email|max:255',
            'organization' => 'required|string|max:128',
            'seat' => 'required|string|max:64',
            'capabilities' => 'array',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'membership.manage', write: true);
        $project = $grant->project;

        $tempPassword = null;
        $result = DB::transaction(function () use ($data, $project, &$tempPassword) {
            // Attach an existing tenant user by email when one exists (a
            // person already on another project in this account), otherwise
            // provision a brand new one - same temp-password pattern
            // PlatformController::storeCustomer already uses for a new admin.
            $user = User::query()->where('tenant_id', $project->tenant_id)->where('email', $data['email'])->first();
            if ($user === null) {
                $tempPassword = bin2hex(random_bytes(8));
                $user = User::create([
                    'tenant_id' => $project->tenant_id,
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => bcrypt($tempPassword),
                ]);
            }

            $existing = Membership::query()->where('project_id', $project->id)->where('user_id', $user->id)->first();
            abort_if($existing !== null, 422, 'This person already has a grant on this project - edit it instead of creating a second one.');

            $membership = Membership::create([
                'tenant_id' => $project->tenant_id, 'project_id' => $project->id, 'user_id' => $user->id,
                'organization' => $data['organization'], 'seat' => $data['seat'],
                'capabilities' => $data['capabilities'] ?? [], 'status' => Membership::STATUS_ACTIVE,
            ]);

            return $membership;
        });

        return response()->json([
            'membership' => $this->digest($result->load('user')),
            'temp_password' => $tempPassword,
        ], 201);
    }

    public function update(Request $request, Membership $membership)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), (int) $membership->project_id, 'membership.manage', write: true);

        $data = $request->validate([
            'seat' => 'sometimes|required|string|max:64',
            'organization' => 'sometimes|required|string|max:128',
            'capabilities' => 'array',
        ]);
        $membership->update($data);

        return response()->json($this->digest($membership->fresh('user')));
    }

    public function revoke(Request $request, Membership $membership)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), (int) $membership->project_id, 'membership.manage', write: true);
        abort_if($membership->user_id === $request->user()->id, 422, 'You cannot revoke your own access.');

        $membership->update(['status' => Membership::STATUS_REVOKED, 'revoked_at' => now()]);

        return response()->json($this->digest($membership->fresh('user')));
    }

    public function reactivate(Request $request, Membership $membership)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), (int) $membership->project_id, 'membership.manage', write: true);

        $membership->update(['status' => Membership::STATUS_ACTIVE, 'revoked_at' => null]);

        return response()->json($this->digest($membership->fresh('user')));
    }

    private function digest(Membership $m): array
    {
        return [
            'id' => $m->id, 'user_id' => $m->user_id,
            'name' => $m->user?->name, 'email' => $m->user?->email,
            'organization' => $m->organization, 'seat' => $m->seat,
            'capabilities' => $m->capabilities ?? [],
            'status' => $m->status, 'revoked_at' => optional($m->revoked_at)->toIso8601String(),
        ];
    }
}
