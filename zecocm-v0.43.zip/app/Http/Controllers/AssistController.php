<?php

namespace App\Http\Controllers;

use App\Domain\Licensing\HelpAssistant;
use App\Models\Tenant;
use Illuminate\Http\Request;

/**
 * Ask ZecoCM — the general assistant endpoint behind the floating button.
 * Free tier (no project) is answered directly by HelpAssistant — it never reads project document
 * content, so 'documents.view' does not apply to it. The licensed/project tier is delegated whole
 * to AiRunController, which owns retrieval, licensing, budget-gating, the 'documents.view' read
 * gate, and the suggestion/escalation/no_match result shape — this controller no longer duplicates
 * any of that (see TR-18 / RetrievalTraceTest::test_documents_view_is_the_only_read_gate...).
 */
class AssistController
{
    public function __construct(
        private readonly HelpAssistant $help,
    ) {}

    public function ask(Request $request)
    {
        $data = $request->validate([
            'question' => 'required|string|max:2000',
            'project_id' => 'nullable|integer',
            'category' => 'nullable|string|max:60',
            'mode' => 'nullable|in:help,assist',
        ]);

        $tenant = $request->user()?->tenant_id ? Tenant::find($request->user()->tenant_id) : null;

        // FREE TIER: ZecoCM explaining itself. No project evidence is read, so this is
        // always available to every account and costs nothing to run.
        $mode = $data['mode'] ?? (empty($data['project_id']) ? 'help' : 'assist');
        if ($mode === 'help') {
            return response()->json($this->help->answer($data['question'], $tenant));
        }

        // LICENSED TIER: grounded in this project's own authorised evidence.
        if (empty($data['project_id'])) {
            return response()->json([
                'kind' => 'refused',
                'reason' => 'AI project assistance answers from a specific project\'s records. Open a project first, or ask the free help assistant about how ZecoCM works.',
            ], 422);
        }

        // Paid project assistance is always queued and audited, via AiRunController — the same
        // controller that owns the real suggestion/escalation/no_match handling, retrieval,
        // licensing, and budget-gating logic. This method used to duplicate all of that inline
        // below (synchronous suggest() call, direct kind:suggestion/escalation/no_match JSON), but
        // that code was unreachable dead code sitting after this return — a request could never
        // reach it, yet it was still confusing anyone reading this file, and its
        // 'scope_searched'/'kind' response shape didn't match what AiRunController/RunGovernedAi
        // actually produce (a queued run, later polled) — a real risk if it were ever
        // accidentally un-dead-coded. Removed rather than left as a trap.
        $request->merge([
            'task_type' => 'answer',
            'idempotency_key' => $request->header('Idempotency-Key'),
        ]);
        return app(AiRunController::class)->store($request);
    }
}
