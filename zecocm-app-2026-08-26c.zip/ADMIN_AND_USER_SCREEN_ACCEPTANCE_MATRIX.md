# Admin and User Screen Acceptance Matrix

## Shared acceptance contract

Every screen needs: stable route; authorization recheck; title/context; primary action; search/filter/sort where relevant; truthful total; loading/empty/no-access/error/offline/conflict states; responsive layout; keyboard and screen-reader support; audit semantics; help; and analytics that contain no protected content.

| World | Screen | Primary jobs | Critical acceptance checks |
|---|---|---|---|
| Platform | Owner home | Customers, health, security, release risks | No project selector/count; all totals real and link to filtered lists |
| Platform | Customers | Provision/suspend/support | Creation yields zero projects; credential shown once; support entry audited |
| Platform | Staff | Admin/technician access | Technician writes fail server-side; assignment scope visible |
| Platform | Licensing | Modules/AI/time/quota/budget | Effective dates and immutable history; expiry blocks paid tasks, not free help |
| Platform | Suggestions | Review proposals | Proposal cannot mutate customer data; disposition traceable |
| Platform | Operations | Jobs/outbox/scans/backups | Tenant-safe diagnostics; retry is idempotent; secrets hidden |
| Sponsor | Account home | Portfolio and sponsored portals | Counts scoped; ownership/delegation clearly distinguished |
| Sponsor | Portal tree | Create/delegate/revoke | Cannot exceed ceilings; no inherited data visibility |
| Sponsor | People & roles | Invite/grant/remove | Role separate from contractual authority; immediate revocation |
| Sponsor | Projects | Create/configure/archive | New project empty; lifecycle and legal hold enforced |
| Sponsor | Knowledge | Libraries/review/promotion | Promotion requires steward; supersession and source edition visible |
| Sponsor | AI & usage | Enable tasks/control cost | Mode, allowance, dates, cost and failures/refusals separated |
| Project | Home/brief | Understand today | Role-filtered; cited; fresh; confidence/refusal; actions deep-link |
| Project | Command center | Find/ask/act | Search cannot leak; proposed formal action requires authoritative confirmation |
| Project | Documents/drawings | Version/review/distribute | Immutable editions, hashes, markups separate, delivery/receipt |
| Project | Submittals | Submit/review/stamp | Revision lineage, clocks, authority, response code and transmittal |
| Project | RFIs | Ask/respond/close | References and assertions; formal response authority; cost/time not determined by AI |
| Project | Dailies | Capture/seal/correct | Offline sync; source/weather provenance; locked record; append correction |
| Project | Media vault | Capture/find/export | Original hash/custody/access; signed link rechecks authority |
| Project | Schedule | Import/compare/dispose | Provisional source warnings; run history; units; calendars; append-only disposition |
| Project | Look-ahead | Plan constraints | Separate from contract schedule; responsibility and commitment history |
| Project | Cost/pay apps | Prepare/review/approve | Reconciliation, precision, authority segregation and human payment gate |
| Project | Changes | Develop/authorize | Estimate/time-impact provenance; assertions versus approved order |
| Project | Meetings | Record decisions/actions | Transcript source; minutes review; issue/revision/distribution |
| Project | Correspondence | Draft/issue/receive | Clocks, recipient validation, delivery/receipt and human release |
| Project | Quality | Inspect/NCR/close | Qualified authority, evidence, corrective verification and history |
| Project | Safety | Observe/respond | Emergency language, privacy, competent-person boundary, no AI determination |
| Project | Permits/utilities | Track dependencies | Agency/source/effective date, expiration and schedule links |
| Project | Claims/disputes | Build chronology | Restricted access, disputed classifications, no legal-fault AI claim |
| Project | Closeout | Complete/turn over | Required artifact matrix, acceptance authority, archive verification |
| Project | Reports/Send to City | Assemble/seal/release | Inclusion manifest, redactions, signatures, hash, delivery/receipt |
| Personal | Profile/security | Identity/settings/sessions | Password/MFA/device revoke/logo safety; errors recover without data loss |

## Design review artifacts required per screen

The design team supplies desktop and mobile views for: default, loading, empty-new-portal, populated, no access, partial redaction, validation error, server error/retry, offline/sync, stale/conflict, destructive confirmation, successful completion and audit/provenance view. Components must use the shared Civic Precision system; isolated screen-specific patterns require design-system approval.

## Engineering definition of done per screen

- Real API and persisted data; no demo path in production.
- Policy tests for allowed and denied actors.
- Validation and concurrency behavior.
- Immutable/audited event where required.
- Unit/integration/browser/accessibility tests.
- Observability without sensitive payload leakage.
- Product copy reviewed for truth and authority.
