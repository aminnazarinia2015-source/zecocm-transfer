# Engineering Handoff - v0.19

## Architecture

Knowledge is separated into project, organization, city, regulatory, product-help, and anonymized-learning collections. v0.19 exposes the first four upload collections. Every source begins provisional, retains its sealed bytes and SHA-256 identity, and has immutable versions/passages. Verification and relationships append audit events.

AI calls now enter `ai_runs`. The request captures authenticated authorization scope and server-derived jurisdiction scope. The queued job restores tenant context, retrieves only verified/adopted and clean passages, runs the assistant, records sources and outcome, and settles usage only for a successful cited suggestion. Refusal, no-match, failure, and cancellation are not billed.

## Deployment

1. Back up the application database and sealed-file store.
2. Deploy source without `.env`, `vendor`, `node_modules`, caches, logs, test databases, or generated knowledge files.
3. Install locked PHP dependencies with the deployment PHP version.
4. Configure queue, database, object storage, malware scanner, AI provider/model allowlist, signing keys, and monitoring.
5. Run `php artisan migrate --force`; migrations 000021 and 000022 are additive.
6. Run a persistent queue worker. Do not use `sync` queues in production.
7. Confirm writable `storage/framework/{cache/data,sessions,views}` and `storage/logs`.
8. Run the automated suite and smoke-test login, account restore, knowledge upload/quarantine/review, AI queue/refusal, cancellation, and source reopening.

Existing legacy `document_passages` are deliberately not promoted automatically. Build a one-time migration report, map each row to its original document/hash, and send it through steward review. Records without original immutable bytes must remain provisional.

## Security requirements before production

- Use managed MySQL/PostgreSQL and Redis-backed queues; SQLite is test/development only.
- Configure malware scanning. With no scanner, file uploads remain quarantined outside testing.
- Keep external source fetching in a separate egress-restricted worker; block private/reserved IPs, redirects to unapproved hosts, oversized responses, active content, and unsupported MIME types.
- Allowlist official/licensed sources and preserve license terms, retrieval time, response headers, edition, and snapshot hash.
- Encrypt sealed storage, rotate AI/API/signing keys, apply retention policies, and alert on cross-tenant denials and repeated retrieval failures.
- Do not enable cross-customer learning without explicit contracts, de-identification tests, aggregation thresholds, and opt-out enforcement.

## Next milestone

Build the ingestion plane: resumable multi-file uploads, ZIP manifest inspection without unsafe extraction, OCR/layout/table/drawing workers, duplicate/edition detection, and official-source feed connectors. Add embeddings and reranking only after tenant-aware indexes and retrieval evaluation sets exist. Then deploy an optional private model gateway for classification and drafting style; keep current rules and project facts in governed retrieval.
