# ZecoCM Full-System Team Review Guide

## What this package is

This is the governing, decision-ready design for ZecoCM's complete platform-owner, sponsor/customer-admin and project-user experience, plus the validated v0.19 engineering foundation. It is intended to let product, UX, engineering, security and construction-domain leaders review one coherent system.

## Truthful maturity statement

The **full product is designed and specified; it is not all implemented**. v0.19 is a tested governed-intelligence foundation. Any module not proven against the acceptance criteria remains Preview or Unavailable. The team must not represent the complete catalog as live functionality.

## Review order

1. `FULL_SYSTEM_MASTER_BLUEPRINT.md` — governing product structure and experience.
2. `FULL_MODULE_AND_FUNCTIONALITY_CATALOG.md` — all platform, admin and user modules.
3. `FULL_ROLE_AUTHORITY_AND_DATA_ACCESS_MATRIX.md` — who can see and do what.
4. `ADMIN_AND_USER_SCREEN_ACCEPTANCE_MATRIX.md` — screen-by-screen design and completion contract.
5. `FULL_SYSTEM_AI_AND_DATA_ARCHITECTURE.md` — governed knowledge, retrieval, learning and AI.
6. `FULL_SAFETY_SECURITY_AND_BUG_VERIFICATION_PLAN.md` — adversarial and operational verification.
7. `FULL_SYSTEM_DELIVERY_AND_ACCEPTANCE.md` — staged execution and release gates.
8. `DESIGNER_BUILD_SPEC.md` — Civic Precision visual and interaction specification.
9. `TEAM_REVIEW_SCORECARD.md` — record approvals, objections and evidence.

## Non-negotiable product rules

- One login; the server derives the permitted world. Never trust caller-selected roles.
- Missing tenant context matches nothing. Search, counts, exports, jobs and AI also fail closed.
- Evidence and schedule versions are immutable. Corrections and dispositions append.
- AI cites authorized sources or refuses, identifies confidence/freshness/assumptions, and never declares legal fault.
- Humans authorize notices, payments, signatures, schedule acceptance, design/life-safety and contractual determinations.
- Platform technicians are read only. Platform-admin support writes are explicit, time-bounded and stamped.
- A new portal has zero projects. The platform-owner level contains no projects.
- Every unfinished capability is visibly Limited, Preview or Unavailable.

## Required team decisions before implementation expands

1. Approve the sponsor/portal/project ownership and delegation model.
2. Approve the role, field-access and formal-authority matrix with counsel and customer representatives.
3. Approve the complete module boundaries and release sequence.
4. Approve Civic Precision components and every required screen state on desktop/mobile.
5. Approve AI source authority, city-library promotion, online acquisition and cross-customer learning policies.
6. Approve production architecture, security objectives, recovery objectives and supported integrations.
7. Select pilot projects and measurable success criteria.

## Recommended build order

1. Restore universal trust: identity/session/navigation, tenant isolation, truthful UI, licensing and support mode.
2. Complete one evidence-to-decision vertical slice across submittal, RFI and daily records.
3. Complete schedule import/comparison/provenance and its redesigned seven-surface experience.
4. Deliver the cited Daily Project Success Brief and universal command center within human-authority gates.
5. Deliver mobile/offline field evidence and agency-ready sealed packages.
6. Expand cost/change/quality/safety/closeout modules only through the same completion contract.

## Approval rule

“Looks good” is not acceptance. Each scorecard row needs a named owner, evidence link, result and unresolved risk. No team should implement a screen whose authority, source-of-truth, failure states or audit behavior remain undecided.
