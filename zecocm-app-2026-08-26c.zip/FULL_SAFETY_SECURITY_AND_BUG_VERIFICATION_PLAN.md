# ZecoCM Full Safety, Security and Bug Verification Plan

## Release doctrine

No claim of “fixed” is accepted without reproducible evidence. Each item requires: defect/risk ID, environment and build hash, steps or automated test, expected result, observed result, evidence, owner, disposition and regression test where practical.

## 1. Identity, session and account

- Login, rate limiting, lockout, recovery, MFA, session rotation and token revocation.
- Refresh restores only valid authorization; expiration and suspension fail closed.
- Logout revokes server token, clears local sensitive state and survives Back/refresh.
- Profile/password/logo/avatar flows validate permissions, files and error recovery.
- Concurrent device/session list and revocation are accurate.
- One-time credentials are displayed once, stored hashed, expire, and force replacement.

## 2. Tenant and authorization isolation

- Cross-tenant ID substitution, nested-resource attacks and mass assignment.
- Missing tenant/project context; suspended/expired portals and grants.
- Search, totals, suggestions, autocomplete, recent items, exports and AI retrieval.
- Object storage paths, signed URLs, thumbnails, logs, queues and caches.
- Support mode, technician restrictions, sponsorship ceilings and field redaction.
- Database policy/query-scope tests plus endpoint and job-level tests.

## 3. Record integrity and auditability

- Immutable source/version/evidence hashes; append-only correction and disposition events.
- Optimistic locking/idempotency for double-click, retry and concurrent edits.
- Actor, effective time, recorded time, source, reason and authorization envelope.
- Time-zone/DST behavior and reproducible “as-of” reports.
- No hard deletion of sealed evidence; legal hold and retention enforcement.
- Exports reproduce source versions and reveal omissions/redactions.

## 4. Upload and document safety

- Allowlisted type verified from content, not extension; size/page/pixel limits.
- Malware quarantine; malformed PDF; polyglot; active content; macro; decompression bomb.
- XLSX/XML entity/ZIP expansion; CSV formula injection; encoding and delimiter attacks.
- OCR uncertainty and provisional status; password-protected/encrypted documents.
- Duplicate hashes; filename/path normalization; Unicode confusables.
- Signed download expiry, authorization recheck and secure content disposition.

## 5. AI safety and truth

- Every factual claim maps to an authorized immutable passage and valid page/coordinate.
- Missing, fabricated, out-of-range, superseded or unauthorized citations refuse.
- Fact, assertion, calculation, correlation, inference, dispute, recommendation and determination remain distinct.
- Prompt injection in documents/web sources cannot change system policy or call unauthorized tools.
- Retrieval filters apply before semantic/full-text search and reranking.
- Model/provider timeout, partial response, retry, cancellation and duplicate settlement.
- Full immutable run envelope; no secrets or restricted text in telemetry.
- Human gates for notice, payment, signature, schedule acceptance, design/safety and legal/contractual decisions.
- AI never declares legal fault; confidence is calibrated and not a substitute for authority.

## 6. Schedule and calculation verification

- Relationship types FS/SS/FF/SF, positive/negative lags and elapsed versus working time.
- Full calendars, exceptions, holidays, inheritance, time zones and version changes.
- Constraints, deadlines, actuals, remaining duration, open ends and milestones.
- Out-of-sequence progress and configured schedule options.
- Split/merge mappings and added/deleted/renamed identity ambiguity.
- Float/critical path, multiple paths, near-critical thresholds and completion variance.
- Independent oracle datasets and hand-calculated fixtures.
- PDF rows remain provisional; MPP is unsupported unless a tested parser is present; XML/export is preferred.
- Recovery outputs show sourced cost/time ranges, assumptions and uncertainty.

## 7. Cost and commercial correctness

- Decimal precision, rounding, currency, retainage, stored material, deductions and tax.
- Contract/SOV/change/pay-app reconciliation; overbilling and duplicate invoice checks.
- Authority limits and separation of preparation, review and approval.
- No AI-authorized payment or entitlement; calculations expose inputs and formula version.

## 8. Workflow and contractual clocks

- Versioned workflow and calendar used at event time.
- Pause/resume/extension/escalation reasons; holidays and time-zone boundaries.
- Reassignment, absent user, rejected/returned/revised/withdrawn/cancelled states.
- Delivery versus receipt; failed notifications do not equal contractual delivery.
- Formal issuance requires confirmation and produces a sealed package/event.

## 9. Navigation and UI bug sweep

- Every visible control works or is honestly disabled with explanation.
- Browser Back/Forward, breadcrumb, deep link, refresh, multiple tabs and stale record.
- Loading, empty, no-access, error, timeout, conflict, offline, syncing and success states.
- Unsaved-change protection; double-submit; pagination/filter persistence; truthful counts.
- Keyboard-only, focus order, focus restoration, skip links, accessible names and dialogs.
- 200% zoom, high contrast, color independence, reduced motion and screen reader.
- Phone/tablet/desktop layouts, long names, localization-ready text and slow network.
- No broken image, fake person, hard-coded project/customer count or false toast.

## 10. API, job and integration resilience

- Schema validation, authorization, pagination limits, idempotency and rate limits.
- Stable error envelopes without internal details or record enumeration.
- Queue retry safety, progress, cancellation, poison job quarantine and dead-letter review.
- Transactional outbox; event ordering, deduplication and replay.
- Webhook signature/replay protection; integration least privilege and credential rotation.
- External outage behavior, circuit breaking and reconciliation after recovery.

## 11. Performance, availability and recovery

- Defined service objectives for interactive routes, search, uploads and jobs.
- Load tests with realistic tenant/project/document distribution; noisy-neighbor isolation.
- Database locking/deadlock tests; move production work off synchronous queue/SQLite.
- Encrypted backups, restore drills, point-in-time goals and tenant-scoped restore procedure.
- Deployment migration rehearsal, backward compatibility, canary/rollback and cache-manifest hygiene.
- Monitoring for app, database, storage, queue, scanner, AI gateway, cost and security signals.

## 12. Privacy and governance

- Data inventory, minimization, retention, legal hold, export and deletion policy.
- Sensitive-personal, safety/medical, privileged and commercially sensitive access.
- Cross-customer learning opt-in and contractual authorization; raw tenant records never become shared citations.
- Licensed standards/publications have valid usage and redistribution rights.
- Online acquisition uses approved sources, terms, effective dates, hashes and steward verification.

## 13. Minimum release evidence

Each release package must contain:

1. source/build commit or content hash;
2. migration and rollback instructions;
3. automated test inventory and raw result summary;
4. independent tenant-isolation and AI-citation tests;
5. dependency/vulnerability and secret scan summaries;
6. browser/device/accessibility matrix;
7. backup/restore and queue/outbox validation for production-impacting changes;
8. known limitations stated in product language;
9. named product, engineering, security and construction-domain approvals.

Passing unit tests alone is not release approval.
