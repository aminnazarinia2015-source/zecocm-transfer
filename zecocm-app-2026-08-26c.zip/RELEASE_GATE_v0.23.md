# ZecoCM v0.23 Release Gate

## Must pass before production deployment is called healthy

1. Apply all migrations through `2026_08_25_000023_create_quality_items`.
2. Confirm the deployed RFI controller initializes `ai_dispositions` and
   `routing_history`; create an RFI through the UI and confirm HTTP 201 plus a
   visible register row.
3. Configure `SCHEDULE_MALWARE_SCANNER_BINARY` to a working ClamAV-compatible
   scanner. Upload the EICAR test fixture in a controlled security environment
   and prove it is quarantined; upload a clean PDF and prove it becomes clean.
4. Run the full automated suite against the release artifact.
5. Visually inspect desktop and phone layouts for login, portal home, RFI create,
   document folders/upload/versioning, Quality & Punch and Schedule Intelligence.
6. Verify browser Back/Forward, refresh, logout and protected-page cache behavior.
7. Verify queue worker, outbox, storage permissions, backups and restore.

## Current evidence

- The RFI 500 is fixed in source by explicit initialization of both non-null JSON
  columns and covered by an HTTP creation regression that also checks persistence.
- Document ingestion now invokes the configured scanner. No scanner means an
  explicit `quarantine_only` operating mode displayed in the interface.
- Automated and syntax results are recorded in the final package validation.

## Honest blocker

This environment cannot reach the host-local PHP server from its controlled
browser surface. Therefore visual certification is not claimed. Deployment must
not be called complete until step 5 is performed against the actual release.
