# ZecoCM Role, Authority and Data-Access Matrix

## Governing rule

Authentication identifies the account. Server-side tenant, portal, project, contractual-party, role, section, record and field grants determine access. The client never selects authority. Deny on missing context, ambiguity, expiry, suspension or policy failure.

| Actor | Normal visibility | Permitted actions | Explicit prohibitions |
|---|---|---|---|
| Platform owner admin | Platform metadata; customer data only in declared support mode | Provision, license, administer staff, enter audited support, manage platform policy | No projects at platform level; no silent customer writes |
| Platform technician | Assigned account diagnostics | Read assigned support scope; submit proposal | No customer writes, impersonation, licensing or secret access |
| Purchasing-account admin | Own account, sponsored hierarchy within ceiling | Manage branches, portals, people, projects, entitlements and libraries | Cannot exceed platform/sponsor ceiling or own another party's sealed evidence |
| Portal admin | Own portal and delegated project scope | People, roles, projects, configuration within grant | Cannot alter parent license, hidden parties, platform policy or immutable history |
| Project executive | Granted portfolio/project summaries | Approve business actions within named authority | No inferred authority from job title alone |
| Project manager / CM | Assigned project and sections | Coordinate workflows, draft/route records, recommendations | Cannot perform owner/designer/contractor determinations without explicit grant |
| Resident engineer / inspector | Assigned field/quality scope | Observe, document, inspect and recommend | Cannot rewrite contractor record or approve design beyond authority |
| Contractor / subcontractor | Party-owned records plus distributed/shared scope | Submit, respond, acknowledge, manage own workforce scope | Cannot access owner-only evaluations, competitors or sealed internal notes |
| Designer / discipline reviewer | Assigned design/technical scope | Review/respond/stamp where licensed and authorized | AI or administrator cannot substitute for professional judgment |
| City/owner reviewer | Distributed project scope | Review, comment, accept/reject where delegated | Cannot silently edit originating party record |
| Knowledge steward | Authorized library and review queue | Verify, promote, supersede, quarantine sources | Automatic classification is not adoption; no access beyond source grant |
| Auditor/read-only | Explicit historical scope | View and export authorized evidence | No drafts, writes, workflow actions or hidden fields |
| Integration/service account | Narrow API scope | Defined machine operation with idempotency | No interactive login, broad token or undeclared cross-project access |

## Formal-action authority gates

The following require an authenticated, currently authorized human, explicit intent, authoritative source display, consequence summary, confirmation and immutable event:

- issue a contractual notice or correspondence;
- accept/reject a submittal, RFI response, schedule or change;
- certify/authorize payment;
- execute a signature or professional stamp;
- approve design, code, safety or life-safety judgment;
- change project party authority, workflow or contract clock;
- release an agency-ready package;
- delete/archive where policy allows (immutable evidence is never deleted by routine UI);
- promote a source as authoritative city/organization knowledge.

AI can draft, organize, compare, retrieve and recommend. It cannot cross these gates.

## Field-level access classes

1. Public/project-shared.
2. Party-shared by distribution.
3. Organization internal.
4. Project leadership restricted.
5. Commercially sensitive.
6. Personal/security restricted.
7. Privileged/dispute restricted.
8. Platform operational metadata.

Filtering applies before search, counts, autocomplete, exports, AI retrieval, citations, notifications and analytics. Redacting the final answer after retrieval is insufficient.

## Sponsorship model

- `purchasing_account` owns the commercial subscription.
- `portal` is an operational organization world.
- `portal_sponsorship` describes parent/child delegation, not data ownership.
- `project_party` joins portals to a project with contractual capacity and effective dates.
- `project_grant` gives accounts scoped functional access.
- `authority_delegation` records specific formal-action authority, limit, issuer and expiry.
- A sponsor may reduce delegated permissions but cannot enlarge them beyond its ceiling.
- Revocation ends future access; prior audit events retain historical actor identity.

## Required negative tests

For every endpoint, job, export, search index and AI tool, prove:

- no tenant context returns zero/denied;
- a valid ID from another tenant returns non-enumerating denial;
- a removed project grant stops access immediately;
- a role query/body/header cannot expand permission;
- counts and autocomplete do not leak hidden records;
- background jobs restore and verify the original authorization envelope;
- support-mode expiry blocks later writes;
- technician write attempts fail;
- a sponsor cannot exceed parent ceilings;
- cached pages and browser Back do not reveal protected data after logout.
