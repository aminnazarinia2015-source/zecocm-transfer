<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => response()->file(public_path('home.html')));
Route::get('/status', fn () => response()->json(['app' => 'ZecoCM', 'status' => 'up']));

/*
 * Deep links. Every meaningful location in the application has its own URL:
 *   /platform/customers/12          /portal/projects/2/rfis
 *   /support/customer/1/projects/2/scheduleintel
 *
 * These paths serve the application shell; the shell then restores that exact
 * location and the SERVER authorises the records before anything is shown.
 * No role, tenant or perspective is ever taken from the URL.
 */
Route::get('/{any}', fn () => response()->file(public_path('app.html')))
    ->where('any', '^(platform|portal|support)(/.*)?$');
