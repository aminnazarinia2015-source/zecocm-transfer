<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AiRunController;
use App\Http\Controllers\AssistController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AutonomyPolicyController;
use App\Http\Controllers\BriefController;
use App\Http\Controllers\CapabilityGapController;
use App\Http\Controllers\ChangeOrderController;
use App\Http\Controllers\ClaimClockController;
use App\Http\Controllers\DailyReportController;
use App\Http\Controllers\DecisionController;
use App\Http\Controllers\DocumentLibraryController;
use App\Http\Controllers\HomepageContentController;
use App\Http\Controllers\IntelligenceController;
use App\Http\Controllers\KnowledgeController;
use App\Http\Controllers\LicenseController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\PayApplicationAccountantExportController;
use App\Http\Controllers\PayApplicationController;
use App\Http\Controllers\PaymentSecurityController;
use App\Http\Controllers\PlatformController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\QualityController;
use App\Http\Controllers\RfiController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\SubmittalController;
use App\Http\Controllers\TransmittalController;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:login');

// Public marketing homepage CMS content - no auth, this is exactly what
// public/home.html itself fetches and renders for any visitor.
Route::get('/homepage-content', [HomepageContentController::class, 'show']);

Route::middleware(['auth:sanctum', 'tenant.context'])->group(function () {
    Route::get('/me', [ProjectController::class, 'me']);

    // Account & session management — every signed-in user
    Route::post('/logout', [AccountController::class, 'logout']);
    Route::get('/account', [AccountController::class, 'show']);
    Route::put('/account', [AccountController::class, 'update']);
    Route::post('/account/password', [AccountController::class, 'password']);
    Route::post('/account/photo', [AccountController::class, 'photo']);
    Route::post('/account/logo', [AccountController::class, 'logo']);

    // Ask ZecoCM — live assistant (cited, escalates, never guesses)
    Route::post('/assist', [AssistController::class, 'ask']);

    Route::middleware('capability:ai.assist')->group(function () {
        Route::get('/ai-runs', [AiRunController::class, 'index']);
        Route::post('/ai-runs', [AiRunController::class, 'store']);
        Route::get('/ai-runs/{run}', [AiRunController::class, 'show']);
        Route::post('/ai-runs/{run}/cancel', [AiRunController::class, 'cancel']);
        Route::post('/ai-runs/{run}/feedback', [AiRunController::class, 'feedback']);
    });

    Route::get('/knowledge/sources', [KnowledgeController::class, 'index']);
    Route::post('/knowledge/sources', [KnowledgeController::class, 'store']);
    Route::get('/knowledge/sources/{source}', [KnowledgeController::class, 'show']);
    Route::get('/knowledge/sources/{source}/content', [KnowledgeController::class, 'content']);
    Route::post('/knowledge/sources/{source}/review', [KnowledgeController::class, 'verify']);
    Route::post('/knowledge/sources/{source}/relationships', [KnowledgeController::class, 'relate']);

    // Intelligence layer: live weather, document ingestion, computed my-court
    Route::get('/weather', [IntelligenceController::class, 'weather']);
    Route::post('/documents', [IntelligenceController::class, 'ingest']);
    Route::get('/documents', [IntelligenceController::class, 'documents']);
    Route::get('/document-library', [DocumentLibraryController::class, 'index']);
    Route::post('/document-library/folders', [DocumentLibraryController::class, 'createFolder']);
    Route::post('/document-library/documents', [DocumentLibraryController::class, 'store']);
    Route::post('/document-library/documents/{document}/versions', [DocumentLibraryController::class, 'storeVersion']);
    Route::get('/document-library/documents/{document}/download', [DocumentLibraryController::class, 'download']);
    Route::get('/mycourt', [IntelligenceController::class, 'myCourt']);
    Route::get('/projects', [ProjectController::class, 'index']);
    Route::post('/projects', [ProjectController::class, 'store']);
    Route::get('/rfis', [RfiController::class, 'index']);
    Route::post('/rfis', [RfiController::class, 'store']);
    // Platform console (admin + technicians)
    Route::get('/platform/customers', [PlatformController::class, 'customers']);
    Route::post('/platform/customers', [PlatformController::class, 'storeCustomer']);
    Route::put('/platform/customers/{tenant}/sections', [PlatformController::class, 'assignSections']);
    Route::put('/platform/customers/{tenant}/status', [PlatformController::class, 'setStatus']);
    Route::get('/platform/customers/{tenant}/projects', [PlatformController::class, 'customerProjects']);
    // Decision envelopes: preview a formal action, then authorise it through the
    // same envelope. Nothing formal happens without an accountable human act.
    Route::get('/decisions/{type}/{id}/envelope', [DecisionController::class, 'show'])
        ->where(['type' => 'rfi|submittal|daily|schedule', 'id' => '[0-9]+']);
    Route::post('/decisions/{type}/{id}/authorize', [DecisionController::class, 'authorize'])
        ->where(['type' => 'rfi|submittal|daily|schedule', 'id' => '[0-9]+']);

    // Daily Project Success Brief: deterministic, cited, freshness-stamped, refuses
    // out loud. Licence-gated server-side.
    Route::middleware('capability:daily_brief')->group(function () {
        Route::get('/projects/{project}/brief', [BriefController::class, 'show'])
            ->where('project', '[0-9]+');
    });

    // Branded transmittals: the account owner's document, never ZecoCM's.
    Route::middleware('capability:documents.transmittal')->group(function () {
        Route::get('/transmittals/{type}/{id}', [TransmittalController::class, 'preview'])
            ->where(['type' => 'rfi|submittal', 'id' => '[0-9]+']);
        Route::post('/transmittals/{type}/{id}/issue', [TransmittalController::class, 'issue'])
            ->where(['type' => 'rfi|submittal', 'id' => '[0-9]+']);
    });

    // Capability licensing: per-account, time-bounded, activatable and auditable.
    Route::get('/licensing/catalog', [LicenseController::class, 'catalog']);
    Route::get('/licensing/customers/{tenant}', [LicenseController::class, 'show']);
    Route::post('/licensing/customers/{tenant}/grant', [LicenseController::class, 'grant']);
    Route::put('/licensing/customers/{tenant}/status', [LicenseController::class, 'update']);
    Route::get('/licensing/customers/{tenant}/history', [LicenseController::class, 'history']);
    Route::post('/licensing/customers/{tenant}/portals', [LicenseController::class, 'createPortal']);

    Route::get('/platform/suggestions', [PlatformController::class, 'suggestions']);
    Route::post('/platform/suggestions', [PlatformController::class, 'storeSuggestion']);
    Route::put('/platform/suggestions/{suggestion}', [PlatformController::class, 'resolveSuggestion']);

    // Homepage CMS (admin view + edit) - the public read is unauthenticated, above.
    Route::get('/platform/homepage-content', [HomepageContentController::class, 'adminShow']);
    Route::put('/platform/homepage-content', [HomepageContentController::class, 'update']);

    // TRACE proposing its own next build: what SelfObservation has clustered
    // from no_match/escalation/steward-correction signals, and where a
    // platform person turns a gap into a proposal (or declines it) and an
    // admin authorizes it. Cross-tenant, platform-staff only - see
    // CapabilityGapController's class doc.
    Route::get('/platform/capability-gaps', [CapabilityGapController::class, 'index']);
    Route::get('/platform/capability-gaps/{gap}', [CapabilityGapController::class, 'show']);
    Route::post('/platform/capability-gaps/{gap}/propose', [CapabilityGapController::class, 'propose']);
    Route::post('/platform/capability-gaps/{gap}/decide', [CapabilityGapController::class, 'decide']);

    // Customer workspace
    Route::get('/submittals', [SubmittalController::class, 'index']);
    Route::post('/submittals', [SubmittalController::class, 'store']);
    Route::post('/submittals/{submittal}/stamp', [SubmittalController::class, 'stamp']);

    Route::post('/rfis/{rfi}/assist', [RfiController::class, 'assist']);
    Route::post('/rfis/{rfi}/respond', [RfiController::class, 'respond']);

    Route::get('/daily-reports', [DailyReportController::class, 'index']);
    Route::post('/daily-reports', [DailyReportController::class, 'store']);
    Route::post('/daily-reports/{report}/lock', [DailyReportController::class, 'lock']);

    Route::post('/media', [MediaController::class, 'store']);
    Route::post('/media/{media}/link', [MediaController::class, 'link']);
    // Change orders. Approval and incorporation are deliberately separate
    // routes, because incorporation rewrites the ledger every payment
    // application bills against.
    Route::get('/change-orders', [ChangeOrderController::class, 'index']);
    Route::post('/change-orders', [ChangeOrderController::class, 'store']);
    Route::get('/change-orders/{order}', [ChangeOrderController::class, 'show']);
    Route::post('/change-orders/{order}/approve', [ChangeOrderController::class, 'approve']);
    Route::post('/change-orders/{order}/incorporate', [ChangeOrderController::class, 'incorporate']);

    // The money path. Submission refusal is server-authoritative: a hidden
    // button is not a control.
    Route::get('/pay-applications', [PayApplicationController::class, 'index']);
    Route::post('/pay-applications', [PayApplicationController::class, 'store']);
    Route::get('/pay-applications/{application}', [PayApplicationController::class, 'show']);
    Route::put('/pay-applications/{application}/lines/{line}', [PayApplicationController::class, 'updateLine']);
    Route::post('/pay-applications/{application}/certify', [PayApplicationController::class, 'certify']);
    Route::post('/pay-applications/{application}/submit', [PayApplicationController::class, 'submit']);
    // Accountant export: structured CSV/HTML for the customer's own
    // accounting process, not a live accounting-system integration.
    Route::get('/pay-applications/{application}/accountant-export', [PayApplicationAccountantExportController::class, 'show']);

    // AUTO-2: what the project has authorized the system to do automatically,
    // per action type - separate from any pay-application capability.
    // Configuring automation is not the same authority as performing the
    // underlying certified act.
    Route::get('/autonomy-policies', [AutonomyPolicyController::class, 'index']);
    Route::post('/autonomy-policies', [AutonomyPolicyController::class, 'store']);

    // Claim clocks. A missed 10/15/20-day notice permanently bars a valid
    // claim, so these are kept apart from every administrative clock in the
    // product - and nothing here ever pronounces a forfeiture.
    Route::get('/claim-clocks', [ClaimClockController::class, 'index']);
    Route::post('/claim-clocks/requirements', [ClaimClockController::class, 'storeRequirement']);
    Route::post('/claim-clocks/requirements/{requirement}/confirm', [ClaimClockController::class, 'confirmRequirement']);
    Route::post('/claim-clocks/requirements/{requirement}/compliance', [ClaimClockController::class, 'storeCompliance']);
    Route::post('/claim-clocks/compliance/{event}/determine', [ClaimClockController::class, 'determineCompliance']);
    Route::post('/claim-clocks/triggers', [ClaimClockController::class, 'storeTrigger']);
    Route::post('/claim-clocks/triggers/{trigger}/resolve', [ClaimClockController::class, 'resolveTrigger']);

    // Releases and stop payment notices. Reported together, never netted:
    // a release reduces exposure to a claimant, a notice freezes money.
    Route::get('/payment-security', [PaymentSecurityController::class, 'index']);
    Route::post('/payment-security/releases', [PaymentSecurityController::class, 'storeRelease']);
    Route::post('/payment-security/stop-notices', [PaymentSecurityController::class, 'storeNotice']);
    Route::post('/payment-security/stop-notices/{notice}/resolve', [PaymentSecurityController::class, 'resolveNotice']);

    Route::get('/quality-items', [QualityController::class, 'index']);
    Route::post('/quality-items', [QualityController::class, 'store']);
    Route::post('/quality-items/{item}/transition', [QualityController::class, 'transition']);

    // Deterministic Schedule Intelligence phases A-B. No caller-supplied role.
    // Licence-gated server-side: navigation visibility is never the control.
    Route::middleware('capability:schedule_intelligence')->group(function () {
        Route::post('/schedule-versions', [ScheduleController::class, 'store']);
        Route::get('/schedule-versions', [ScheduleController::class, 'index']);
        Route::get('/schedule-versions/{version}/activities', [ScheduleController::class, 'activities']);
        Route::post('/schedule-versions/{version}/accept', [ScheduleController::class, 'accept']);
        Route::post('/schedule-versions/{version}/reject', [ScheduleController::class, 'reject']);
        Route::get('/schedule/deltas', [ScheduleController::class, 'deltas']);
        Route::get('/schedule/analysis-history', [ScheduleController::class, 'analysisHistory']);
        Route::post('/schedule/match-confirm', [ScheduleController::class, 'confirmMapping']);
        Route::post('/schedule/analyze', [ScheduleController::class, 'analyze']);
        Route::get('/schedule/analysis/{analysis}', [ScheduleController::class, 'analysis']);
        Route::post('/schedule/analysis/{analysis}/cancel', [ScheduleController::class, 'cancel']);
    });
});
