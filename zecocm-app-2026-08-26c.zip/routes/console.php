<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// OPS-14: dispatches a fresh queue heartbeat onto the real production queue
// every interval; QueueHeartbeatHealthCheck reads the result back on /up.
// The `withoutOverlapping` guard matters here specifically because a
// dispatcher that queued up twice would leave an OLDER unhandled row as the
// most recent by id but not by dispatched_at - the health check already
// orders by dispatched_at first, but there's no reason to let duplicates
// happen at all.
Schedule::command('ops:dispatch-queue-heartbeat')
    ->everyMinute()
    ->withoutOverlapping()
    ->name('ops14-dispatch-queue-heartbeat');

// OPS-14: alert-only failed-job delta reporting - never registered on
// DiagnosingHealth, see ReportFailedJobDelta's doc comment.
Schedule::command('ops:report-failed-job-delta')
    ->hourly()
    ->withoutOverlapping()
    ->name('ops14-report-failed-job-delta');
