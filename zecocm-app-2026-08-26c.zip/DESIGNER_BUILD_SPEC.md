# ZecoCM One-Pass Designer Build Specification

Date: 2026-08-24  
Purpose: give product, UX, visual-design, and frontend teams one authoritative direction for redesigning ZecoCM as an evidence-first, AI-native construction-management platform for U.S. public owners and contractors.

## The mandate

ZecoCM should not win by looking more complicated than incumbent software. It should win because every screen makes three things unusually clear:

1. **What is verified?**
2. **What decision needs a human?**
3. **What is the safest next move, and why?**

The defensible product is not a collection of dashboards. It is a verified factual core, an authorization and policy layer, a construction decision system, and a learning system that never confuses advice with authority.

The designer must not use fictional project values in a signed-in experience. Use explicit empty, loading, unavailable, insufficient-evidence, permission-denied, stale, conflict, provisional, offline, and error states. A polished refusal is a core product feature.

## Product north star

> One project truth; many authorized perspectives; accountable human decisions.

ZecoCM serves owners, construction managers, designers, inspectors, general contractors, subcontractors, field crews, executives, and auditors from one evidence graph. Deterministic facts and calculations stay invariant. What each person can see, infer, recommend, or authorize is filtered by project grant, contract policy, jurisdiction, and data classification.

### Product promise

- Capture once; reuse everywhere.
- Originals and schedule versions are immutable; corrections append.
- Every important number opens its source.
- Every AI statement declares its type, confidence, freshness, and evidence.
- Every formal decision shows who is authorized to make it.
- If evidence is insufficient, ZecoCM explains the gap and asks for the smallest missing item.
- The system never declares legal fault.

## Current market benchmark

The redesign must reach baseline parity before claiming category leadership.

| Benchmark | Incumbent strength to respect | ZecoCM requirement |
|---|---|---|
| Procore | Broad project/financial platform and 2026 agentic workflows across drawings, specs, photos, RFIs, submittals, daily logs, and contracts | Match core workflow reliability; exceed with authority envelopes, evidence-state typing, and decision replay |
| Autodesk Forma / ACC | Connected drawings/models/documents, schedule visibility, Construction IQ, and an assistant with referenceable answers | Match document/model context and permissions; exceed with immutable factual snapshots and explicit refusal/approval gates |
| Oracle Primavera Cloud | Enterprise CPM, field schedule, resources, quantitative schedule/cost risk, scenarios, portfolios | Never imply a tabular CPM foundation is equivalent; build reference-tested adapters, advanced logic quality, and risk analysis |
| InEight | Integrated cost/schedule/risk, collaborative look-ahead, historical-data AI, and Monte Carlo | Build range-based, assumption-visible recovery/risk tools; keep team judgment accountable |
| Kahua | Public-sector program controls, government security posture, funding accountability, asset-centric handover | Build owner/program/funding/asset/public-record workflows and a credible security/compliance roadmap |
| Trimble Unity Construct | Owner capital-program lifecycle, cost/schedule/document controls, facility handover, APIs | Connect program delivery to asset operations and data portability |
| Trimble ProjectSight | Fast field/document workflows, mobile/offline, drawings, photos, 360 capture, RFIs/submittals | Deliver a superior offline field capture and source-linked visual evidence experience |
| CMiC | Construction ERP and financial/job-cost integration on a unified database | Integrate, do not fake, accounting/payroll/job-cost depth; maintain financial segregation of duties |

Official product references used for this benchmark:

- Procore AI agents: https://www.procore.com/press/new-procore-ai-experience-embeds-datagrid-into-procore
- Autodesk AI: https://construction.autodesk.com/workflows/artificial-intelligence-construction/
- Autodesk schedule management: https://construction.autodesk.com/workflows/schedule-management/
- Oracle Primavera Cloud: https://www.oracle.com/construction-engineering/primavera-cloud-project-management/
- InEight Schedule: https://ineight.com/products/ineight-schedule/
- InEight risk management: https://ineight.com/process-solutions/risk-management/
- Kahua government: https://www.kahua.com/industries/government/
- Trimble Unity Construct API overview: https://developer.trimble.com/docs/unity-construct/
- Trimble ProjectSight: https://www.trimble.com/en/products/projectsight
- CMiC platform: https://cmicglobal.com/

These are capability references, not an independent ranking.

## Live website audit: design defects to correct

### Critical truth defects

The production Schedule Intelligence screen presented a fixed baseline/update, “Owner-caused” attribution, contract/code conclusions, and about `$10,200` of liquidated-damages exposure without an inspectable version/source/calculation/authorization chain. This is not acceptable for construction decision support. The replacement in this package removes those claims.

The signed-in product mixed server records and browser-only samples. Labels such as “LIVE” appeared near genuine records while fixed rows, dashboard metrics, critical notices, financial values, and assistant statements remained visible elsewhere. Users cannot be expected to infer which are real. Authenticated screens must render only authorized server data or an explicit unavailable/prototype state.

### Mobile failure

At 390 × 844, the fixed 240 px sidebar remained open, leaving roughly 83 px for content and creating horizontal overflow. Tables, forms, and tap targets were unusable. The new CSS foundation makes the nav off-canvas and enforces 44 px mobile targets, but every screen still needs intentional mobile composition.

### Accessibility failure

- Navigation used clickable `div` elements without native semantics or keyboard focus.
- Several controls were roughly 27 px high.
- Status depended too heavily on badge color.
- Dense tables lacked a defined mobile alternative.
- Focus order, skip links, dialogs, error summary, reduced motion, and screen-reader announcements were not systematically designed.

The working copy adds baseline nav roles/keyboard handling, but the target is WCAG 2.2 AA with automated and human testing.

### Interaction contradictions

- “Open project” navigated while a toast said the path was not wired.
- Prototype actions could claim a notice/package was sent without a verified server workflow.
- Account password UI lacked confirmation and differed from server rules.
- File controls did not clearly explain secure accepted formats and scan state.

Every action needs one truthful result state: succeeded on server, queued, pending human approval, saved locally/offline, refused, or failed.

## Information architecture

### Global level

1. Portfolio
2. Programs
3. Projects
4. Decisions
5. Evidence
6. Analytics
7. Standards and policies
8. Administration

### Project workspace

1. Project Success Home
2. Decision Queue
3. Schedule Intelligence
4. Plans / Models / Specifications
5. RFIs
6. Submittals
7. Daily / Field
8. Quality / Inspections / Punch
9. Safety
10. Changes / Notices / Claims
11. Cost / Pay Applications / Funding
12. Meetings / Correspondence / Transmittals
13. Photos / 360 / Reality
14. Labor / Equipment / Certified Payroll
15. Closeout / Assets / Handover
16. Project Evidence Graph
17. Project Settings / Authorities / Contract Clocks

Navigation is entitlement-aware, but hidden navigation must never be the only security control.

## The product shell

### Desktop

- Collapsible left rail: portfolio/project context, primary navigation, favorites, recent records.
- Context header: project/program, data freshness, current evidence snapshot, search/command, notifications, account.
- Main workspace: 12-column responsive grid, max readable width for narrative, full-bleed option for schedules/drawings.
- Right decision sidecar: opens when a user reviews evidence or prepares an accountable action.
- Persistent “Ask ZecoCM” command—not a floating toy chat bubble. It must inherit current context and show what sources it is allowed to use.

### Tablet

- Narrow icon rail or modal navigation.
- Split view for record + evidence when space permits.
- Schedule tables use pinned identity columns and horizontal pan with a visible affordance.

### Mobile

- Bottom navigation: Home, Capture, Decisions, Records, More.
- One primary action per screen.
- Field capture opens in fewer than two taps.
- Tables become cards or purpose-built lists; never shrink a desktop table into unreadable cells.
- Offline state is persistent and unambiguous.
- Sync queue shows item, state, retry, conflict, and source device time vs. server receipt time.

## Visual system

### Tone

Calm, exact, field-legible, civic-grade, and trustworthy. Avoid sci-fi decoration, glassmorphism, unnecessary gradients, neon AI colors, and dashboard confetti. “Coming from Mars” should mean an unprecedented decision model—not a gimmicky visual theme.

### Color roles

- Neutral ink/surfaces for facts.
- Blue: navigational or informational—not automatically “AI.”
- Green: verified success or completed authorized action.
- Amber: provisional, stale, needs review, near-critical.
- Red: safety-critical, blocked, failed, or past an enforced threshold—not blame.
- Purple: inference/recommendation layer, always paired with a type label.

Never encode meaning by color alone. Use icon + label + plain-language state.

### Typography

- UI sans with excellent tabular numerals.
- Monospace only for record IDs, hashes, version numbers, and timestamps.
- Minimum 16 px input text on mobile.
- Four heading levels maximum inside product screens.
- Avoid all-caps paragraphs; reserve all caps for compact data labels if needed.

### Density

Provide Comfortable, Standard, and Dense modes. Field roles default Comfortable; schedulers/controllers may choose Dense. Density cannot reduce targets below accessibility requirements.

### Core component library

- App shell / project switcher / program switcher
- Command palette and global search
- Evidence-state badge
- Freshness badge
- Confidence indicator with explanation
- Source chip and source drawer
- Human-authority badge
- Decision envelope
- Record header and immutable event timeline
- Data table, card list, comparison ledger
- Activity/Gantt row and dependency inspector
- Mapping review card for split/merge identity
- Empty / loading / permission / stale / conflict / refusal / unavailable states
- Approval sheet and signature ceremony
- Offline capture card and sync queue
- Notification center and decision queue
- AI answer block with citations, gaps, alternatives, and escalation

## The epistemic design system

Every consequential statement must carry one structural type. This is not optional visual metadata; it is part of the data contract.

| Type | Meaning | Visual behavior |
|---|---|---|
| Fact | Directly recorded or imported evidence | Neutral “Fact” chip; source opens original/version |
| Party assertion | A named party’s statement | Party name, time, record, and “Assertion” chip |
| Deterministic calculation | Reproducible rule/engine output | Formula/engine version, inputs, assumptions |
| Correlation | Observed association | Explicit “does not establish cause” explanation |
| Inference | Model/rule interpretation | Confidence, counterevidence, freshness, model/prompt |
| Dispute | Conflicting assertions/evidence | Side-by-side sources; never collapse to one truth silently |
| Recommendation | Proposed next action | Alternatives, constraints, reversible/irreversible state |
| Formal determination | Authorized human/agency decision | Signer, capacity, authority, evidence snapshot, timestamp |

Do not label an imported schedule date “truth” without showing the specific immutable version and import confidence.

## The decision envelope

Every material action opens a sidecar with:

1. Action being proposed.
2. Who is acting and in what capacity.
3. Authority required and whether the user has it.
4. Facts and calculations supporting the action.
5. Party assertions and disputes kept separate.
6. Evidence freshness and missing items.
7. AI confidence and refusal boundary, if AI contributed.
8. Contract/jurisdiction policy involved.
9. Reversible vs. irreversible consequences.
10. Required co-review, signature, or segregation of duties.
11. Final human confirmation in plain language.
12. Append-only receipt after completion.

Formal notices, payment approvals, schedule acceptance, signatures, design/life-safety judgments, and contractual decisions always use this pattern. AI may draft or educate; it cannot press the final button.

## Screen specifications

### 1. Project Success Home

The home screen answers, in order:

1. What changed since my last visit?
2. What requires my decision?
3. What could hurt safety, time, cost, compliance, or evidence quality?
4. What is the smallest useful action today?

Desktop composition:

- Daily Project Success Brief with snapshot time and evidence coverage.
- Decision queue: due, authority, consequence, evidence readiness.
- Schedule pulse: current accepted-for-analysis version, data date, health, major deltas—not blame.
- Change/cost pulse with sourced ranges and approval state.
- Field reality: latest verified daily/inspection/photo/360 evidence.
- Evidence health: missing, stale, conflicting, provisional, unlinked.
- Team commitments and handoffs.

No vanity score without decomposition. A “Project Success Index” must open its components, weights, source snapshot, and limitations.

### 2. Daily Project Success Brief

Sections:

- Snapshot: version IDs and retrieval time.
- Facts since yesterday.
- Decisions due today.
- Schedule watch items.
- Cost/change watch items.
- Safety/quality items.
- Evidence gaps.
- Role-specific actions.
- What ZecoCM refused to conclude and why.

The factual computation is invariant. Owner, CM, designer, and contractor payloads differ only by authorized fields/sources and role-specific actions—not by rewriting history.

### 3. Decision Queue

Filters: mine, my organization, project, program, type, due, consequence, evidence readiness, authority.

Each card shows:

- decision/action;
- record and project;
- due basis and clock;
- current holder;
- readiness: ready / missing evidence / disputed / stale / permission blocked;
- consequence of delay;
- accountable action button.

### 4. Schedule Intelligence — Time Machine

Header:

- current project;
- version kind/label;
- data date;
- immutable ID/hash;
- submitted party;
- disposition event;
- parser/engine/rules versions;
- assumptions and scan state.

Primary tabs:

1. Timeline
2. Health
3. Delta Ledger
4. Logic / CPM
5. Identity Mapping
6. Evidence Links
7. Recovery Studio
8. Decision History

#### Timeline

- Vertical or horizontal version lineage.
- Baseline/update/recovery/revised baseline/look-ahead labels.
- Parent/child and supersession relationships.
- Submitted, accepted for analysis, rejected, withdrawn, corrected-by events.
- Never overwrite a version.

#### Health

- Logic quality: open ends, cycles, dangling links, excessive lags, constraints, calendars.
- Progress quality: actuals after data date, out-of-sequence state, invalid remaining duration, missing status.
- Critical/near-critical paths with engine and threshold.
- Evidence coverage and unresolved provisional rows.

Do not compress health into one unexplained red/yellow/green score.

#### Delta Ledger

Rows: activity identity, change class, before, after, magnitude in working time, classification, source, explanation, review state.

Filters: criticality, WBS, organization, change type, magnitude, mapping confidence, evidence state.

Opening a delta shows:

- old/new activities;
- source versions and hashes;
- calendars and logic;
- relationship changes;
- deterministic calculation trace;
- linked records and citations;
- party assertions/disputes kept separate.

#### Identity Mapping

Dedicated human review for:

- exact match;
- likely rename;
- split;
- merge;
- added/deleted;
- uncertain.

Show side-by-side code/name/WBS/dates/duration/logic/resources and why the matcher proposed the relationship. Correction creates a new mapping event and supersedes the prior mapping; it never silently rewrites history.

#### Recovery Studio

Not a promise generator. It is a bounded scenario lab.

Each option shows:

- assumed crew/equipment/calendar/productivity;
- source for cost and production ranges;
- earliest feasible effect;
- time range and confidence;
- cost range and excluded costs;
- safety/quality/permit/design constraints;
- downstream consequences;
- evidence gaps;
- accountable reviewers.

Buttons: Save scenario, Request inputs, Send for review. Never “Accept schedule” or “Issue directive” without the decision envelope.

### 5. Evidence Graph

Provide list, graph, and timeline modes linking:

- schedules/activities;
- RFIs/submittals;
- drawings/spec revisions;
- dailies, inspections, photos/360;
- correspondence/notices;
- changes/costs/payments;
- weather and external sources;
- decisions/signatures.

The graph is not decorative. Selecting an edge explains relationship type, creator/system, time, confidence, and source.

### 6. RFIs

Register columns: number, subject, type, raised by, current holder, contractual due basis, status, linked activities, evidence state.

Detail:

- immutable question/assertion;
- attachments and revisions;
- routing event timeline;
- current ball/clock;
- linked plan/spec areas;
- draft response workspace;
- assistant panel that may summarize/cite or refuse;
- formal response decision envelope.

AI must escalate structural/life-safety ambiguity to the responsible design professional and never manufacture a design resolution.

### 7. Submittals

Register and detail follow the RFI pattern. The compliance coach identifies potential missing requirements with exact project-spec citations and confidence. Human reviewer selects disposition and signs in capacity. Stamps and corrections append.

### 8. Daily / Field

Mobile-first capture:

- weather/source time;
- crews/equipment/cost codes;
- work areas/activities;
- quantities;
- inspections/visitors/deliveries;
- safety/quality observations;
- delay or impact assertions;
- voice, photos, video, 360, sensor metadata;
- attestation and correction.

One factual capture may produce role-appropriate summaries, but the underlying evidence stays one record. Separate a foreman’s assertion from system weather and from a schedule calculation.

Offline states: saved on device, queued, uploaded, scan pending, accepted, conflict, refused. Show device capture time and server receipt time.

### 9. Plans / Models / Specifications

- Revision-first viewer; current vs. superseded is unmistakable.
- Sheet/model/spec navigation and cross-links.
- Markups, RFIs, submittals, photos, issues, activities.
- Assistant cites exact sheet/detail/spec section and revision.
- Conflicting callouts render a conflict card and escalation—not a synthesized guess.

### 10. Change / Notice / Claim workspace

Use lanes, not one blended narrative:

- observed fact;
- party notice/assertion;
- contract clock;
- linked evidence;
- deterministic quantity/time/cost calculation;
- correlation/inference;
- dispute;
- negotiation/decision;
- formal determination.

ZecoCM can teach notice requirements and draft a notice. It cannot decide entitlement or legal fault.

### 11. Cost / Pay Applications / Funding

- Original budget, approved changes, commitments, actuals, forecast, contingency, funding source.
- Every forecast range lists assumptions and source snapshot.
- Pay application review and payment clocks are distinct.
- Approval requires segregation of duties and accountable authority.
- Public-owner views include grant/fund eligibility, encumbrance, board limits, and audit export.

### 12. Portfolio / Program

- Program outcomes, milestones, funding, risk, decisions, evidence health, resource constraints, asset handover.
- Drill from aggregate to project to source.
- Cross-project learning uses anonymized/authorized features; never leak another tenant’s records.

### 13. Closeout / Asset Handover

- Requirements matrix linked to contract/spec.
- O&M, warranties, training, tests, commissioning, as-builts, asset attributes.
- Completeness is calculated with source links.
- Final turnover package is reproducible from an immutable evidence snapshot.

## AI interaction model

Every response uses the same anatomy:

1. **Answer type:** fact summary, calculation, inference, recommendation, education, or refusal.
2. **Short answer.**
3. **Evidence:** source chips with version/revision.
4. **Confidence and freshness.**
5. **Assumptions.**
6. **Contradicting or missing evidence.**
7. **Permitted next actions.**
8. **Human authority required.**

The assistant may:

- find, summarize, compare, calculate, teach, draft, ask for evidence, propose bounded options;
- create a draft record if policy permits and the user explicitly requests it.

The assistant may not:

- declare legal fault or contractual entitlement;
- accept a schedule;
- issue a formal notice;
- approve payment;
- sign;
- make a design, structural, or life-safety judgment;
- reveal unauthorized source content;
- hide uncertainty or fabricate a source.

## “Mars-level” differentiators

### 1. Decision Replay

Reconstruct any recommendation or formal action exactly as it appeared then: source hashes, schedule version, policy, permissions, rules engine, AI model/prompt, assumptions, missing evidence, and human approval.

### 2. Project Time Machine

Move a slider through immutable evidence snapshots and see what each authorized role could know at that time—without rewriting later knowledge into the past.

### 3. Knowledge-Gap Register

Treat missing/contradictory/stale evidence as a managed register. Show consequence, owner, smallest resolving artifact, due date, and downstream decisions blocked.

### 4. Decision Readiness Index

Not a generic AI confidence score. It decomposes authority, evidence completeness, source freshness, dispute status, calculation validation, and required co-review.

### 5. Counterfactual Recovery Studio

Bounded schedule/cost options with sourced ranges and safety/quality/contract constraints. Users compare options; accountable humans choose.

### 6. Multi-Party Truth Room

Shared facts, separated assertions, visible disputes, role-filtered privileged evidence, and one append-only decision timeline. This is the core public-owner/contractor trust advantage.

### 7. Evidence Health Autopilot

Continuously detects unlinked photos, superseded drawings in use, missing schedule versions, stale specifications, orphaned cost impacts, inconsistent dates, and decisions lacking adequate sources—then recommends the smallest repair.

### 8. Field-to-Contract Compiler

Transforms field capture into draft records, schedule links, notice-clock prompts, cost-code candidates, and evidence packets while keeping every transformation traceable and human-reviewed.

### 9. Outcome Learning Without Leakage

Learn productivity/risk patterns from authorized, privacy-preserving features. Show why a historical pattern is comparable. Never expose another tenant’s project details.

### 10. Civic Transparency Mode

For public owners: create an approved, redacted public view of progress, funding, milestones, impacts, and evidence summaries, separate from contractual/private workspaces.

## Role model

Design and test at least these personas:

- Public owner executive
- Agency project manager
- Construction manager
- Inspector
- Designer / architect / engineer of record
- General contractor executive / PM / superintendent
- Subcontractor PM / foreman
- Scheduler / project controls
- Cost controller / accounting / pay approver
- Safety / quality lead
- Program manager
- Platform administrator
- Read-only support technician
- Auditor / public-record reviewer

No query parameter selects a role. Perspective derives from authenticated account, organization, project membership, capability, contract authority, and evidence classification.

## State checklist for every screen

The designer must deliver all applicable states:

- loading / skeleton;
- empty-first-use;
- empty-after-filter;
- offline;
- queued / syncing;
- scan pending / quarantined / rejected;
- provisional;
- verified;
- stale;
- conflicting;
- superseded;
- correction appended;
- insufficient evidence;
- permission denied;
- action requires authority;
- read-only support mode;
- partial service failure;
- validation error;
- destructive/irreversible confirmation;
- success with append-only receipt;
- unavailable/not built.

## Accessibility and responsive acceptance

- WCAG 2.2 AA target.
- All workflows usable with keyboard only.
- Visible focus; logical order; skip navigation.
- Native controls first; ARIA only when necessary.
- Minimum 44 × 44 px touch targets on mobile.
- Status has text/icon, not color alone.
- Screen-reader announcements for async progress, refusal, upload state, and decision completion.
- Data visualizations have table/text alternatives.
- Zoom to 200% without lost actions; reflow at 320 CSS px.
- Reduced motion and high-contrast compatibility.
- English/Spanish expansion tested; dates/units/time zones explicit.

## Designer delivery package

The design team must provide:

1. Product map and role/entitlement map.
2. Responsive design system and tokens.
3. Component library with all epistemic and decision components.
4. Desktop/tablet/mobile prototypes for every P0 and P1 workflow.
5. State matrix for every screen.
6. Accessibility annotations and keyboard flow.
7. Content design glossary and prohibited language.
8. API/data annotations: each displayed field’s type, source, permission, freshness, and empty behavior.
9. Analytics event map that excludes sensitive evidence content.
10. Red-team prototypes: stale data, conflicting evidence, cross-tenant denial, unsupported AI question, unauthorized formal action, offline conflict.
11. User-testing plan across owner, CM, GC, field, scheduler, and auditor roles.
12. Design QA checklist for implemented screens.

## Content rules

Use:

- “Recorded in Update 06”
- “Calculated by CPM engine v1.0 with these assumptions”
- “Party assertion from Zeco Inc.”
- “Possible contributor; causation not determined”
- “Insufficient evidence to answer”
- “Requires schedule reviewer authorization”
- “Draft only—no notice has been issued”

Do not use:

- “Owner-caused” or “contractor-caused” as an AI/system conclusion
- “At fault”
- “Guaranteed completion”
- “Approved” when only an analysis ran
- “Sent” when only a browser preview changed
- “Live” next to any sample or cached value without source/freshness
- “AI says” as evidence

## One-pass acceptance gate

The design is ready for engineering only when reviewers can answer yes to all of these:

1. Can every consequential number open its source and version?
2. Are facts, assertions, calculations, inferences, disputes, recommendations, and determinations visually distinct?
3. Is every formal action bound to a human authority ceremony?
4. Does every AI surface show confidence, freshness, citations, assumptions, and refusal?
5. Can one tenant or role ever infer hidden data through counts, errors, sources, or autocomplete?
6. Do all screens have empty/error/offline/provisional/unavailable states?
7. Does mobile work as a field tool rather than a compressed desktop?
8. Can a scheduler audit identity mapping and every CPM/delta assumption?
9. Can an auditor replay a decision from immutable sources?
10. Are unsupported capabilities unavailable instead of simulated?

## Final direction

The moat is the operating model: verified evidence, immutable time, policy-controlled authorization, reproducible calculation, accountable decisions, and AI that knows when it cannot act. Make that model visible and effortless on every screen. That is how ZecoCM can be genuinely different from a conventional construction dashboard with an AI chat box attached.
