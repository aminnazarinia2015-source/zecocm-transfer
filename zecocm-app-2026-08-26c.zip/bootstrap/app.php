<?php

use App\Http\Middleware\EstablishTenantContext;
use App\Http\Middleware\RequireCapabilityLicense;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'tenant.context' => EstablishTenantContext::class,
            'capability' => RequireCapabilityLicense::class,
        ]);
        // Tenant context must exist before implicit route model binding runs;
        // otherwise tenant-scoped bindings fail closed before authorization.
        $middleware->prependToPriorityList(
            SubstituteBindings::class,
            EstablishTenantContext::class,
        );
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
