# ZecoCM Product Language Standard

## Governing rule

Use the term a public owner, construction manager, designer or contractor
already expects. Brand only a capability that is materially unique. When a
branded name is useful, pair it with a familiar functional label until users
recognize it without training.

## Approved navigation language

| Familiar functional label | Optional ZecoCM identity | Use |
| --- | --- | --- |
| My action items | — | Items requiring the signed-in user's attention |
| Schedule Intelligence | ZecoCM Time Machine in education/marketing only | Immutable versions, CPM validation and deterministic comparisons |
| Documents | — | Project folders, documentary files and immutable versions |
| Quality & Punch List | — | Inspections, observations, deficiencies and punch items |
| Knowledge Library | ZecoCM Atlas | Governed standards, specifications and verified sources |
| AI Activity & Audit Log | — | AI runs, sources, refusals, cost and human feedback |
| Project Team & Routing | ZecoCM Structure Builder | Organizations, disciplines, authority and routing graph |
| Agency Package Export | Send to City | Sealed external submission packages |
| Ask ZecoCM | Search & guidance | Universal record search, workflow help and licensed AI assistance |

## Writing rules

- Prefer “action item” over “in my court” in primary navigation. “Ball in court”
  may appear as a secondary industry field where contract routing requires it.
- Prefer “Documents” over “Documents & Standards”; standards are a document
  type and authority level, not a separate navigation burden.
- Prefer “Quality & Punch List” over “Inspections & Punch” because it includes
  observations, deficiencies, verification and closeout.
- Never invent proprietary synonyms for RFIs, submittals, daily reports, change
  orders, pay applications, transmittals, meeting minutes or closeout.
- Always explain a unique capability in one sentence on first use.
- Keep legal/professional authority explicit: AI drafts, searches, compares and
  recommends; named humans issue, accept, certify, sign and determine.

## The intelligence layer is called TRACE

**TRACE — Traceable Record-Anchored Cited Evidence.** ZecoCM is the product; TRACE is the
reasoning layer inside it — the part that retrieves, cites, refuses, and never decides.

Named jointly by the two build sides. The alternative considered was CORE (Cited
Owner-Recorded Evidence), which was stronger on ownership but carried the ordinary meaning
of "the authoritative brain", implying more authority and judgment than this layer has or
should ever claim. TRACE was chosen because it names provenance rather than intelligence.

Use it in a sentence the way a person would:

- "TRACE could not verify that claim from the project record."
- "TRACE cited the submitted schedule and refused to infer the disposition."
- "TRACE found nothing in this project's documents that answers this."

Never write "TRACE decided", "TRACE approved", "TRACE determined" or "TRACE found that the
contractor was late". TRACE cites, computes, and refuses. People decide.
