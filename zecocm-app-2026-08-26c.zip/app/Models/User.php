<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens;

    protected $fillable = ['tenant_id', 'name', 'email', 'password', 'platform_role', 'platform_permissions'];

    protected $hidden = ['password'];

    protected $casts = ['platform_permissions' => 'array'];

    public function isPlatformAdmin(): bool
    {
        return $this->platform_role === 'admin';
    }

    public function isPlatformStaff(): bool
    {
        return $this->platform_role !== null;
    }

    public function can_(string $permission): bool
    {
        if ($this->isPlatformAdmin()) {
            return true;
        }

        return (bool) ($this->platform_permissions[$permission] ?? false);
    }

    public function memberships()
    {
        return $this->hasMany(Membership::class);
    }
}
