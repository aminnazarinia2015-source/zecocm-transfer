<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class DailyReport extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'report_date', 'foreman_id', 'weather',
        'work_performed', 'site_conditions', 'delays', 'cost_code_notes',
        'locked', 'lock_seal', 'corrections',
    ];

    protected $casts = [
        'report_date' => 'date',
        'weather' => 'array',
        'cost_code_notes' => 'array',
        'locked' => 'boolean',
        'lock_seal' => 'array',
        'corrections' => 'array',
    ];

    public function timeCardEntries()
    {
        return $this->hasMany(TimeCardEntry::class);
    }

    public function signatureAttestations()
    {
        return $this->hasMany(SignatureAttestation::class);
    }

    /** Locked on signature; corrections APPEND, never overwrite (delay-claim evidence). */
    public function correct(string $field, string $newValue, int $userId, string $reason): void
    {
        if (! $this->locked) {
            throw new \LogicException('Corrections are for locked reports; edit directly before locking.');
        }
        $c = $this->corrections ?? [];
        $c[] = [
            'field' => $field, 'new_value' => $newValue, 'reason' => $reason,
            'user_id' => $userId, 'at' => now()->toIso8601String(),
        ];
        $this->corrections = $c;
    }
}
