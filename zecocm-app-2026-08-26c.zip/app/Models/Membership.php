<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Membership extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'user_id', 'organization', 'seat',
        'capabilities', 'discipline_scope',
    ];

    protected $casts = [
        'capabilities' => 'array',
        'discipline_scope' => 'array',
    ];

    public function allows(string $capability): bool
    {
        $capabilities = $this->capabilities ?? [];

        return ($capabilities['*'] ?? false) === true
            || ($capabilities[$capability] ?? false) === true;
    }
}
