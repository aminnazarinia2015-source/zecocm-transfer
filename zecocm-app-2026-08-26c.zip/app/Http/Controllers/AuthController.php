<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController
{
    /** ONE login. The account decides who you are - never a role picker. */
    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $data['email'])->first();
        if ($user === null || ! Hash::check($data['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials.'], 422);
        }

        // Platform staff have no tenant_id and are never blocked here. A
        // customer user whose tenant has been suspended (not deleted - see
        // PlatformController::setStatus) cannot sign in until reactivated.
        if ($user->tenant_id !== null) {
            $tenant = Tenant::find($user->tenant_id);
            if ($tenant !== null && $tenant->status === 'suspended') {
                return response()->json(['message' => 'This account has been suspended. Contact your ZecoCM administrator.'], 403);
            }
        }

        $token = $user->createToken('zecocm')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'platform_role' => $user->platform_role,   // null => customer user
                'tenant_id' => $user->tenant_id,
            ],
        ]);
    }
}
