<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\DailyReport;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Services\WeatherService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * The intelligence layer: live weather bound to the schedule, project
 * document ingestion feeding the cited assistant, and a computed
 * "in my court" that derives urgency from the CONTRACT clocks —
 * never from a hand-typed status field.
 */
class IntelligenceController
{
    public function __construct(private readonly ProjectAccess $access) {}

    /* ---- live weather + 10-day risk flags (Addendum G) ---- */
    public function weather(Request $request, WeatherService $weather)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access
            ->authorize($request->user(), (int) $data['project_id'], 'weather.view')
            ->project;
        $lat = (float) ($project->lat ?? 34.05);
        $lng = (float) ($project->lng ?? -118.24);

        $current = $weather->current($lat, $lng);
        $tenDay = $weather->tenDayPrecipProbability($lat, $lng) ?? [];
        $flags = array_values(array_filter($tenDay, fn ($d) => $d['precip_probability'] >= 50));

        return response()->json([
            'project' => $project->number.' - '.$project->name,
            'current' => $current,
            'ten_day' => $tenDay,
            'flags' => $flags,
            'source' => 'open-meteo.com',
            'retrieved_at' => now()->toIso8601String(),
        ]);
    }

    /* ---- document ingestion: real specs/contracts feed the assistant ---- */
    public function ingest(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'corpus' => 'nullable|in:project_specs,project_plans,project_contract,state_public_contract_code,greenbook_reference',
            'source' => 'nullable|string|max:255',
            'edition' => 'nullable|string|max:64',
            'file' => 'nullable|file|max:51200|mimetypes:application/pdf,text/plain',
            'text' => 'nullable|string',
        ]);

        $project = $this->access
            ->authorize($request->user(), (int) $data['project_id'], 'documents.ingest', write: true)
            ->project;

        // DEAD PATH, CLOSED.
        //
        // This endpoint chunked an uploaded document into `document_passages` and
        // answered: "Ingested - the assistant now answers from this document with
        // citations." Every part of that sentence was false. HybridKnowledgeRetriever
        // reads `knowledge_passages`; it has never read `document_passages` and does
        // not know the table exists. So the document was not retrievable, nothing
        // cited it, and the user was told otherwise.
        //
        // It was also ungoverned in every way the product claims to care about: no
        // malware scan, no sha256 seal, no edition, no authority level, no
        // verification gate, no steward. A second ingestion path that bypasses every
        // control the first one exists to enforce is not a feature, it is a hole.
        //
        // Refusing loudly is the correct behaviour. Silently accepting an upload that
        // goes nowhere is how a superintendent ends up believing the record contains
        // a document it has never held.
        abort(410, 'This ingestion path is closed. It wrote documents to a store the '
            .'assistant never reads, so nothing uploaded here was ever retrievable or '
            .'citable. Use the Knowledge Library, which seals, scans, versions and '
            .'holds each source for a named steward to verify.');
    }

    public function documents(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.view');
        $rows = DB::table('document_passages')
            ->select('source', 'corpus', DB::raw('count(*) as passages'))
            ->where('tenant_id', $grant->project->tenant_id)
            ->where('project_id', $grant->project->id)
            ->groupBy('source', 'corpus')
            ->orderBy('source')
            ->limit(500)
            ->get();

        // Anything in this table predates the closure of the ingest path above and
        // was never retrievable. Say so, rather than listing it beside governed
        // sources as though the assistant can cite it.
        $rows = $rows->map(function ($row) {
            $row->retrievable = false;
            $row->notice = 'Legacy upload - never retrievable or citable. Re-add it through the Knowledge Library.';

            return $row;
        });

        return response()->json($rows);
    }

    /* ---- computed In-My-Court: urgency FROM the contract clocks ---- */
    public function myCourt(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access
            ->authorize($request->user(), (int) $data['project_id'], 'records.view')
            ->project;
        $projectId = $project->id;
        $items = [];
        $today = now();

        $clockFor = function (array $names) use ($project) {
            foreach ($names as $n) {
                try {
                    return $project?->clock($n);
                } catch (\Throwable $e) {
                }
            }

            return null;
        };
        $subClock = $clockFor(['submittal_review']);
        $rfiClock = $clockFor(['rfi_response', 'rfi']);
        $nowImm = new \DateTimeImmutable($today->toDateString());

        foreach (Submittal::where('project_id', $projectId)->whereNotIn('status', ['no_exceptions', 'rejected'])->limit(100)->get() as $s) {
            $due = null;
            $late = null;
            try {
                if ($subClock && $s->submitted_at) {
                    $anchor = new \DateTimeImmutable((string) $s->submitted_at);
                    $due = $subClock->dueFrom($anchor);
                    $late = $subClock->daysLate($anchor, $nowImm);
                }
            } catch (\Throwable $e) {
            }
            $items[] = [
                'kind' => 'submittal', 'id' => $s->id, 'ref' => $s->number, 'title' => $s->title,
                'holder' => $s->ball_in_court, 'due' => $due?->format('Y-m-d'),
                'days_late' => $late !== null ? (int) $late : null, 'view' => 'submittals',
            ];
        }
        foreach (Rfi::where('project_id', $projectId)->where('status', '!=', 'answered')->limit(100)->get() as $r) {
            $due = null;
            $late = null;
            try {
                if ($rfiClock && $r->raised_at) {
                    $anchor = new \DateTimeImmutable((string) $r->raised_at);
                    $due = $rfiClock->dueFrom($anchor);
                    $late = $rfiClock->daysLate($anchor, $nowImm);
                }
            } catch (\Throwable $e) {
            }
            $items[] = [
                'kind' => 'rfi', 'id' => $r->id, 'ref' => $r->number, 'title' => $r->subject,
                'holder' => $r->ball_in_court, 'due' => $due?->format('Y-m-d'),
                'days_late' => $late !== null ? (int) $late : null, 'view' => 'rfis',
            ];
        }
        foreach (DailyReport::where('project_id', $projectId)->where('locked', false)->limit(50)->get() as $d) {
            $items[] = [
                'kind' => 'daily', 'id' => $d->id, 'ref' => (string) $d->report_date, 'title' => 'Daily report unsigned - lock it to seal the record',
                'holder' => 'you', 'due' => (string) $d->report_date, 'days_late' => null, 'view' => 'daily',
            ];
        }

        usort($items, fn ($a, $b) => ($b['days_late'] ?? -999) <=> ($a['days_late'] ?? -999));

        $critical = array_values(array_filter($items, fn ($i) => ($i['days_late'] ?? 0) > 0));

        return response()->json(['items' => $items, 'critical' => $critical, 'computed_at' => $today->toIso8601String()]);
    }
}
