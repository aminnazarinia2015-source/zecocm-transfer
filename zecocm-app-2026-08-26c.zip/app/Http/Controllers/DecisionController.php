<?php

namespace App\Http\Controllers;

use App\Domain\Decisions\EnvelopeBuilder;
use App\Domain\Schedule\ProjectAccess;
use App\Domain\Schedule\ScheduleDispositionService;
use App\Models\DailyReport;
use App\Models\Rfi;
use App\Models\ScheduleVersion;
use App\Models\Submittal;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;

/**
 * Decision envelopes: read the envelope for a formal action, then authorise it.
 *
 * Authorisation runs through the SAME envelope the user was shown. If the envelope
 * is not ready at the moment of authorisation, the action is refused - the preview
 * and the gate can never drift apart.
 */
class DecisionController
{
    public function __construct(
        private readonly ProjectAccess $access,
        private readonly EnvelopeBuilder $builder,
        private readonly ScheduleDispositionService $scheduleDispositions,
    ) {}

    public function show(Request $request, string $type, int $id)
    {
        [$envelope] = $this->resolve($request, $type, $id, write: false);

        return response()->json($envelope->toArray());
    }

    public function authorize(Request $request, string $type, int $id)
    {
        abort_if(TenantContext::writesBlocked(), 403,
            'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');

        [$envelope, $record, $grant] = $this->resolve($request, $type, $id, write: true);

        if (! $envelope->isReady()) {
            return response()->json([
                'message' => $envelope->blockedReason ?: 'This decision is not ready to be authorised.',
                'state' => $envelope->state,
                'envelope' => $envelope->toArray(),
            ], 409);
        }

        $data = $request->validate([
            'confirm' => 'required|accepted',                 // explicit human act, never implicit
            'response' => 'nullable|string',
            'disposition' => 'nullable|string|max:40',
            'note' => 'nullable|string|max:2000',
        ]);

        $user = $request->user();
        $seal = ['by' => $user->id, 'by_name' => $user->name, 'sealed_at' => now()->toIso8601String()];

        switch ($type) {
            case 'rfi':
                $text = trim((string) ($data['response'] ?? ''));
                if ($text === '') {
                    return response()->json(['message' => 'A response is required before this can be sealed.'], 422);
                }
                $record->response = $text;
                $record->status = 'answered';
                $record->response_seal = $seal;
                $record->save();
                break;

            case 'submittal':
                $disposition = $data['disposition'] ?? null;
                $allowed = ['no_exceptions', 'make_corrections', 'revise_resubmit', 'rejected'];
                if (! in_array($disposition, $allowed, true)) {
                    return response()->json(['message' => 'Choose a disposition: '.implode(', ', $allowed).'.'], 422);
                }
                $record->status = $disposition;
                $record->stamp = $seal + ['disposition' => $disposition, 'note' => $data['note'] ?? null];
                $record->save();
                break;

            case 'daily':
                $record->update(['locked' => true, 'lock_seal' => $seal]);
                break;

            case 'schedule':
                $disposition = $this->scheduleDispositionFrom($request);
                $event = $this->scheduleDispositions->append(
                    version: $record,
                    eventType: 'schedule_version.review_disposition',
                    disposition: $disposition,
                    payload: [
                        'note' => $data['note'] ?? null,
                        'authorization_scope' => $grant->auditScope(),
                        'decision_envelope' => true,
                    ],
                    actorId: $user->id,
                );
                $seal['event_id'] = $event->id;
                $seal['event_hash'] = $event->event_hash;
                break;
        }

        $after = $this->buildFor($type, $record->fresh(), $grant, $user);

        return response()->json([
            'sealed' => true,
            'seal' => $seal,
            'record_ref' => $envelope->recordRef,
            'envelope' => $after->toArray(),
            'next' => $this->nextRoute($type, $grant),
        ]);
    }

    /** @return array{0:\App\Domain\Decisions\DecisionEnvelope,1:mixed,2:\App\Domain\Schedule\ProjectGrant} */
    private function resolve(Request $request, string $type, int $id, bool $write): array
    {
        $capability = match ($type) {
            'rfi' => 'rfi.respond',
            'submittal' => 'submittal.stamp',
            'daily' => 'daily.lock',
            'schedule' => 'schedule.review',
            default => abort(404),
        };

        $record = match ($type) {
            'rfi' => Rfi::findOrFail($id),
            'submittal' => Submittal::findOrFail($id),
            'daily' => DailyReport::findOrFail($id),
            'schedule' => ScheduleVersion::findOrFail($id),
        };

        // Reading an envelope needs only view rights; authorising needs write.
        $readCapability = $type === 'schedule' ? 'schedule.view' : 'records.view';
        $grant = $this->access->authorize($request->user(), $record->project_id,
            $write ? $capability : $readCapability, write: $write);

        return [$this->buildFor($type, $record, $grant, $request->user()), $record, $grant];
    }

    private function buildFor(string $type, $record, $grant, $user)
    {
        return match ($type) {
            'rfi' => $this->builder->forRfiResponse($record, $grant, $user),
            'submittal' => $this->builder->forSubmittalStamp($record, $grant, $user),
            'daily' => $this->builder->forDailyLock($record, $grant, $user),
            'schedule' => $this->builder->forScheduleDisposition($record, $grant, $user, $this->scheduleDispositionFrom(request())),
        };
    }

    private function scheduleDispositionFrom(Request $request): string
    {
        $disposition = (string) $request->input('disposition', $request->query('disposition'));
        if (! in_array($disposition, ['accepted', 'rejected'], true)) {
            abort(422, 'Choose a schedule disposition: accepted or rejected.');
        }

        return $disposition;
    }

    /** Every sealed result routes the user somewhere real. */
    private function nextRoute(string $type, $grant): array
    {
        $view = ['rfi' => 'rfis', 'submittal' => 'submittals', 'daily' => 'daily', 'schedule' => 'scheduleintel'][$type];

        return [
            'view' => $view,
            'path' => '/portal/projects/'.$grant->project->id.'/'.$view,
            'label' => $type === 'schedule' ? 'Back to Schedule Intelligence - the disposition event is recorded' : 'Back to the register - the clock and queues have moved',
        ];
    }
}
