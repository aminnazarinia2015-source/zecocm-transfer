<?php

namespace App\Http\Controllers;

use App\Models\Membership;
use App\Models\Project;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProjectController
{
    public function index(Request $request)
    {
        $query = Project::query();
        if (! $request->user()->isPlatformStaff()) {
            $query->whereIn('id', Membership::query()
                ->where('user_id', $request->user()->id)
                ->select('project_id'));
        }

        return $query->orderBy('number')->get(['id', 'number', 'name', 'sector', 'owner_name']);
    }

    public function store(Request $request)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians cannot create projects - suggest it; the admin applies.');
        }
        if (TenantContext::isPlatformStaff() && TenantContext::tenantId() === null) {
            abort(403, 'Open a customer account first - projects always belong to a customer.');
        }
        $data = $request->validate([
            'number' => 'required|string|max:32',
            'name' => 'required|string|max:255',
            'sector' => 'required|in:public,commercial,residential',
            'owner_name' => 'required|string|max:255',
            'state' => 'nullable|string|max:8',
            'funding_source' => 'nullable|in:local,state,federal',
            'ntp_date' => 'nullable|date',
            'duration_days' => 'nullable|integer|min:1',
            'duration_basis' => 'nullable|in:calendar,working',
            'ld_per_day' => 'nullable|numeric|min:0',

            // Contract clocks are terms of THIS contract. They are accepted from the
            // caller, validated, and stored with the clause they came from.
            'contract_clocks' => 'nullable|array',
            'contract_clocks.*.days' => 'required_with:contract_clocks|integer|min:0|max:3650',
            'contract_clocks.*.basis' => 'required_with:contract_clocks|in:working,calendar',
            'contract_clocks.*.source' => 'nullable|string|max:255',
        ]);
        $project = DB::transaction(function () use ($data, $request) {
            /*
             * NEVER invent a contract clock.
             *
             * This previously wrote a fixed set of periods - submittal 14 calendar days,
             * RFI 5 working days - and discarded whatever the caller sent. Downstream, the
             * decision envelope and the issued transmittal then printed those invented
             * numbers under the words "the contract governs, not a system default", and a
             * due date computed from them went out to an owner agency on a real document.
             * A fabricated contract term is the most damaging thing this system could
             * assert, and it was asserting one with a sentence denying that it was.
             *
             * Clocks now come from the caller or they do not exist. With none recorded,
             * every downstream surface already refuses honestly: the brief says it cannot
             * compute what is late, and the transmittal prints "A period is never assumed."
             */
            $clocks = [];
            foreach (($data['contract_clocks'] ?? []) as $name => $clock) {
                $clocks[$name] = array_filter([
                    'days' => (int) $clock['days'],
                    'basis' => $clock['basis'],
                    'source' => $clock['source'] ?? null,
                ], fn ($v) => $v !== null);
            }

            $project = Project::create(array_diff_key($data, ['contract_clocks' => true]) + [
                'state' => $data['state'] ?? 'CA',
                'contract_clocks' => $clocks,
                'org_structure' => [],
            ]);

            if (! $request->user()->isPlatformStaff()) {
                Membership::create([
                    'project_id' => $project->id,
                    'user_id' => $request->user()->id,
                    'organization' => $data['owner_name'] ?? 'Project team',
                    'seat' => 'project_admin',
                    'capabilities' => ['*' => true],
                ]);
            }

            return $project;
        });

        return response()->json($project, 201);
    }

    public function me(Request $request)
    {
        $u = $request->user();

        return response()->json([
            'id' => $u->id, 'name' => $u->name, 'email' => $u->email,
            'platform_role' => $u->platform_role, 'tenant_id' => $u->tenant_id,
        ]);
    }
}
