<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\DailyReport;
use App\Services\WeatherService;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;

class DailyReportController
{
    public function __construct(
        private readonly WeatherService $weather,
        private readonly ProjectAccess $access,
    ) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'records.view');

        return DailyReport::where('project_id', $grant->project->id)
            ->with(['timeCardEntries', 'signatureAttestations'])
            ->orderByDesc('report_date')
            ->paginate(31);
    }

    public function store(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'required|integer',
            'report_date' => 'required|date',
            'work_performed' => 'required|string',
            'site_conditions' => 'nullable|string',
            'delays' => 'nullable|string',
            'cost_code_notes' => 'array',
            'time_card' => 'array',              // [{resource_code,resource_name,resource_type,pay_class,cost_code,hours}]
            'lat' => 'nullable|numeric',
            'lng' => 'nullable|numeric',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'daily.create', write: true);

        // Weather retrieved from an authoritative source WITH attribution
        // (Aspect 2) - attributable, never merely asserted.
        $weather = ($data['lat'] ?? null) !== null
            ? $this->weather->current((float) $data['lat'], (float) $data['lng'])
            : null;

        $report = DailyReport::create([
            'project_id' => $grant->project->id,
            'report_date' => $data['report_date'],
            'foreman_id' => $request->user()->id,
            'weather' => $weather,
            'work_performed' => $data['work_performed'],
            'site_conditions' => $data['site_conditions'] ?? null,
            'delays' => $data['delays'] ?? null,
            'cost_code_notes' => $data['cost_code_notes'] ?? [],
            'corrections' => [],
        ]);

        foreach ($data['time_card'] ?? [] as $entry) {
            $report->timeCardEntries()->create($entry + ['tenant_id' => $report->tenant_id]);
        }

        return response()->json($report->load('timeCardEntries'), 201);
    }

    public function lock(Request $request, DailyReport $report)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), $report->project_id, 'daily.lock', write: true);

        $report->update([
            'locked' => true,
            'lock_seal' => [
                'by' => $request->user()->id,
                'sealed_at' => now()->toIso8601String(),
            ],
        ]);

        return response()->json($report);   // corrections APPEND from here on
    }
}
