<?php

namespace App\Http\Controllers;

use App\Domain\Ai\AiRunLedger;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Evolution\SelfObservation;
use App\Domain\Licensing\BudgetGate;
use App\Domain\Licensing\CapabilityLicense;
use App\Domain\Schedule\ProjectAccess;
use App\Jobs\RunGovernedAi;
use App\Models\AiFeedbackEvent;
use App\Models\AiRun;
use App\Models\CapabilityGrant;
use App\Models\RetrievalTrace;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AiRunController
{
    public function __construct(private readonly ProjectAccess $access, private readonly CapabilityLicense $licenses, private readonly AiRunLedger $ledger) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'assistant.use')->project;

        return response()->json(['runs' => AiRun::query()->where('project_id', $project->id)->latest('id')->limit(100)->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer', 'question' => 'required|string|max:5000',
            'category' => 'nullable|string|max:64', 'task_type' => 'nullable|in:answer,draft,classify,compare,educate',
            'idempotency_key' => 'nullable|string|max:128',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'assistant.use');
        $tenant = Tenant::findOrFail($grant->project->tenant_id);
        abort_unless($this->licenses->allows($tenant, 'ai.assist'), 402, 'AI project assistance is not currently licensed for this account.');
        $license = CapabilityGrant::query()->where('tenant_id', $tenant->id)->where('capability_key', 'ai.assist')->first();
        $task = $data['task_type'] ?? 'answer';
        if ($license?->allowed_tasks && ! in_array($task, $license->allowed_tasks, true)) {
            abort(403, 'This AI task is outside the account licence.');
        }
        // The old check read a counter nothing incremented and was therefore
        // never true. It is now a reservation taken inside a locked transaction:
        // ten runs dispatched in the same second cannot each read the same
        // pre-run figure and each pass.
        $reservation = BudgetGate::reserve($license);
        if (! $reservation['granted']) {
            abort(402, $reservation['state']['message']);
        }

        $key = $data['idempotency_key'] ?? $request->header('Idempotency-Key') ?? hash('sha256', $request->user()->id.'|'.$data['project_id'].'|'.$data['question']);
        $existing = AiRun::query()->where('idempotency_key', $key)->first();
        if ($existing) {
            // A replay runs nothing, so it holds nothing. Without this the
            // reservation taken two lines up would be stranded until somebody
            // noticed the budget shrinking on repeated clicks.
            BudgetGate::release($license);

            return response()->json(['run' => $existing, 'replayed' => true]);
        }

        $run = DB::transaction(function () use ($data, $grant, $request, $tenant, $key, $task, $license) {
            $tier = $license?->model_tier ?: 'standard';
            $run = AiRun::create([
                'tenant_id' => $tenant->id, 'project_id' => $grant->project->id, 'requested_by' => $request->user()->id,
                'public_id' => (string) Str::uuid(), 'idempotency_key' => $key, 'task_type' => $task,
                'category' => $data['category'] ?? 'general_administration', 'question' => $data['question'], 'status' => 'queued',
                'provider' => config('zecocm_ai.provider'), 'model' => config('zecocm_ai.models.'.$tier),
                'prompt_version' => config('zecocm_ai.prompt_version'),
                'retrieval_version' => HybridKnowledgeRetriever::VERSION, 'policy_version' => 'refusal-v1',
                'authorization_scope' => $grant->auditScope(), 'retrieval_scope' => $grant->project->jurisdictionScope()->corpora,
                'assumptions' => ['Historical patterns are not governing requirements.', 'Formal decisions require accountable human authorization.'],
            ]);
            $this->ledger->record($run, 'queued');
            RunGovernedAi::dispatch($run->id);

            return $run;
        });

        return response()->json([
            'run' => $run,
            'replayed' => false,
            // Reported on the way out, so an account can see the budget move
            // rather than discovering it at the 402.
            'budget' => BudgetGate::state($license?->fresh()),
        ], 202);
    }

    public function show(Request $request, AiRun $run)
    {
        if ($run->project_id) {
            $this->access->authorize($request->user(), (int) $run->project_id, 'assistant.use');
        }

        // TR-18: the trace names candidate documents the retriever considered
        // - some of which this run's own requester was authorized to read at
        // execution time, but a viewer here is only proven to hold
        // 'assistant.use', a weaker grant. Naming those candidates to someone
        // who cannot independently open them would be exactly the "internal
        // consideration becomes a side-channel" leak Codex's ruling named.
        // 'documents.view' is re-checked HERE, for THIS viewer, right now -
        // never inherited from whatever the requester held when the run
        // executed - and only that check unlocks locators/reasons/candidates.
        //
        // TR-18, Codex's third finding: this is deliberately project-level,
        // not per-source. It is correct only because 'documents.view' is
        // genuinely the one authoritative document-level gate this codebase
        // has for every KnowledgeSource today - every controller that ever
        // reads document content or metadata (KnowledgeController,
        // DocumentLibraryController, IntelligenceController, AssistController,
        // this one) checks that exact capability and none finer-grained.
        // access_classification ('project_private'/'tenant_private') scopes
        // WHICH sources a project can see at all, never WHO within a project
        // can see them - there is no second, narrower ACL layer to bypass.
        // GovernedContextBuilderTest::test_no_action_executing_code_path_reads_passage_content_as_authorization
        // pins the sibling invariant that no new AiResult type can appear
        // unnoticed; the day a per-source ACL is introduced, this redaction
        // check must be revisited against it rather than assumed to still
        // cover every source.
        $trace = RetrievalTrace::query()->where('ai_run_id', $run->id)->first();
        $mayViewDocuments = false;
        if ($run->project_id) {
            try {
                $mayViewDocuments = $this->access->authorize($request->user(), (int) $run->project_id, 'documents.view')->allows('documents.view');
            } catch (\Throwable) {
                $mayViewDocuments = false;
            }
        }
        $traceOut = null;
        if ($trace !== null) {
            $traceOut = $mayViewDocuments
                ? $trace
                : ['redacted' => true, 'reason' => 'viewer is not authorized for documents.view on this project',
                    'result_kind' => $trace->result_kind, 'sql_candidate_count' => $trace->sql_candidate_count,
                    'stage_count' => count($trace->stages), 'final_candidate_count' => count($trace->final_candidates)];
        }

        return response()->json(['run' => $run, 'trace' => $traceOut, 'events' => DB::table('ai_run_events')->where('tenant_id', $run->tenant_id)->where('ai_run_id', $run->id)->orderBy('id')->get()]);
    }

    public function cancel(Request $request, AiRun $run)
    {
        $this->access->authorize($request->user(), (int) $run->project_id, 'assistant.use', write: true);
        abort_unless(in_array($run->status, ['queued', 'running'], true), 409, 'Only queued or running work can be cancelled.');
        $run->update(['cancel_requested_at' => now()]);
        $this->ledger->record($run, 'cancellation_requested');

        return response()->json(['run' => $run->fresh()]);
    }

    public function feedback(Request $request, AiRun $run)
    {
        $this->access->authorize($request->user(), (int) $run->project_id, 'assistant.use', write: true);
        $data = $request->validate(['label' => 'required|in:accepted,rejected,corrected,outcome_recorded', 'comment' => 'nullable|string|max:4000', 'correction' => 'nullable|array', 'outcome' => 'nullable|array']);
        $event = AiFeedbackEvent::create(['tenant_id' => $run->tenant_id, 'project_id' => $run->project_id, 'ai_run_id' => $run->id,
            'label' => $data['label'], 'comment' => $data['comment'] ?? null, 'correction' => $data['correction'] ?? null,
            'outcome' => $data['outcome'] ?? null, 'actor_user_id' => $request->user()->id]);
        $this->ledger->record($run, 'feedback_appended', ['feedback_id' => $event->id, 'label' => $event->label]);

        // The signal this system would never volunteer about itself: ZecoCM
        // having been confidently wrong. Weighted above every flattering
        // signal in SelfObservation - two occurrences from one steward is
        // enough to earn a person's attention, where a refusal needs five
        // across three people. AiFeedbackEvent stays write-only for the run
        // it corrects (the original AI result is never changed), but the
        // correction itself now feeds the one place ZecoCM tracks what it
        // needs to get better at.
        // Codex's finding: only the run's FIRST correction should count as a
        // signal. Resubmitting the same 'corrected' label on the same run
        // (a double-click, a retried request) must not inflate occurrences -
        // that would make the threshold a measure of retry behavior rather
        // than of how often ZecoCM is actually confidently wrong.
        $isFirstCorrectionOnThisRun = $data['label'] === 'corrected'
            && AiFeedbackEvent::where('ai_run_id', $run->id)->where('label', 'corrected')->count() === 1;
        if ($isFirstCorrectionOnThisRun) {
            SelfObservation::observe(
                signalKind: SelfObservation::STEWARD_CORRECTION,
                clusterKey: SelfObservation::clusterKeyFor($run->question, (string) $run->category),
                title: 'Steward corrected: '.mb_substr($run->question, 0, 120),
                evidence: ['run_id' => $run->id, 'feedback_id' => $event->id, 'comment' => $data['comment'] ?? null, 'correction' => $data['correction'] ?? null],
                tenantId: $run->tenant_id,
                askerKey: (string) $request->user()->id,
                targetCapability: null,
                projectKey: (string) $run->project_id,
            );
        }

        return response()->json(['feedback' => $event, 'notice' => 'Feedback appended; the original AI result was not changed.'], 201);
    }
}
