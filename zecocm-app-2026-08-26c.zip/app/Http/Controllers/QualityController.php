<?php

namespace App\Http\Controllers;

use App\Domain\Provenance\ChainAnchor;
use App\Domain\Provenance\SubjectFingerprint;
use App\Domain\Schedule\ProjectAccess;
use App\Models\MediaItem;
use App\Models\QualityItem;
use App\Models\QualityItemEvent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QualityController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer', 'status' => 'nullable|string|max:32',
            'kind' => 'nullable|string|max:24']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'quality.view')->project;
        $query = QualityItem::query()->where('project_id', $project->id)->withCount('media')->with(['events' => fn ($q) => $q->latest('id')->limit(20)]);
        if ($data['status'] ?? null) $query->where('status', $data['status']);
        if ($data['kind'] ?? null) $query->where('kind', $data['kind']);
        $items = $query->orderByRaw("CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END")
            ->orderBy('due_at')->latest('id')->limit(500)->get();
        return response()->json(['items' => $items, 'counts' => ['total' => $items->count(),
            'open' => $items->whereNotIn('status', ['closed'])->count(), 'critical' => $items->where('severity', 'critical')->where('status', '!=', 'closed')->count()],
            'computed_at' => now()->toIso8601String()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer', 'kind' => 'required|in:inspection,observation,deficiency,punch',
            'title' => 'required|string|max:255', 'description' => 'required|string|max:10000',
            'classification' => 'required|in:fact,party_assertion,dispute,recommendation', 'severity' => 'required|in:low,normal,high,critical',
            'location' => 'nullable|string|max:255', 'spec_section' => 'nullable|string|max:64', 'drawing_reference' => 'nullable|string|max:128',
            'assigned_organization' => 'nullable|string|max:160', 'due_at' => 'nullable|date', 'media_ids' => 'nullable|array|max:50', 'media_ids.*' => 'integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'quality.create', write: true)->project;
        $media = MediaItem::query()->where('project_id', $project->id)->whereIn('id', $data['media_ids'] ?? [])->get();
        abort_if($media->count() !== count(array_unique($data['media_ids'] ?? [])), 422, 'Every evidence item must exist in this authorized project.');
        $item = DB::transaction(function () use ($data, $project, $request, $media) {
            $next = ((int) QualityItem::query()->where('project_id', $project->id)->max('id')) + 1;
            $prefix = ['inspection' => 'INSP', 'observation' => 'OBS', 'deficiency' => 'DEF', 'punch' => 'PUNCH'][$data['kind']];
            $attributes = $data; unset($attributes['media_ids']);
            $item = QualityItem::create(array_merge($attributes, ['tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                'number' => $prefix.'-'.str_pad((string) $next, 4, '0', STR_PAD_LEFT), 'status' => 'open', 'created_by' => $request->user()->id]));
            foreach ($media as $evidence) DB::table('quality_item_media')->insert(['tenant_id' => $project->tenant_id,
                'quality_item_id' => $item->id, 'media_item_id' => $evidence->id, 'linked_by' => $request->user()->id, 'created_at' => now()]);
            $this->append($item, null, 'open', 'created', 'Captured as '.$data['classification'].'.', $data['classification'], $request->user()->id);
            return $item;
        });
        return response()->json(['item' => $item->load('events')->loadCount('media'),
            'notice' => 'Quality record created. Closure requires a separate accountable verification event.'], 201);
    }

    public function transition(Request $request, QualityItem $item)
    {
        $this->access->authorize($request->user(), (int) $item->project_id, 'quality.transition', write: true);
        $data = $request->validate(['to_status' => 'required|in:in_progress,ready_for_verification,closed,reopened,rejected',
            'note' => 'required|string|max:5000', 'classification' => 'required|in:fact,party_assertion,dispute,recommendation,formal_determination']);
        $allowed = ['open' => ['in_progress', 'ready_for_verification', 'rejected'], 'in_progress' => ['ready_for_verification', 'rejected'],
            'ready_for_verification' => ['closed', 'in_progress', 'rejected'], 'closed' => ['reopened'], 'rejected' => ['reopened'], 'reopened' => ['in_progress', 'ready_for_verification']];
        abort_unless(in_array($data['to_status'], $allowed[$item->status] ?? [], true), 422, 'That quality transition is not permitted from the current state.');
        if ($data['to_status'] === 'closed') abort_unless($data['classification'] === 'formal_determination', 422, 'Closure must be recorded as an accountable formal determination.');
        $from = $item->status;
        DB::transaction(function () use ($item, $from, $data, $request) {
            $item->update(['status' => $data['to_status']]);
            $this->append($item, $from, $data['to_status'], 'status_changed', $data['note'], $data['classification'], $request->user()->id);
        });
        return response()->json(['item' => $item->fresh()->load('events')->loadCount('media'),
            'notice' => 'Status event appended. Earlier observations and events remain unchanged.']);
    }

    private function append(QualityItem $item, ?string $from, string $to, string $type, string $note, string $classification, int $actor): void
    {
        $previous = QualityItemEvent::query()->where('quality_item_id', $item->id)->latest('id')->first();
        $payload = ['tenant_id' => $item->tenant_id, 'project_id' => $item->project_id, 'quality_item_id' => $item->id,
            'event_type' => $type, 'from_status' => $from, 'to_status' => $to, 'note' => $note, 'classification' => $classification,
            'actor_user_id' => $actor, 'previous_event_hash' => $previous?->event_hash];
        // EV-13: this ledger never adopted CanonicalPayload (its payload has no
        // Carbon instances to normalise, so the drift that broke the knowledge
        // ledger never applied here) but the digest primitive itself still goes
        // through the one authoritative gateway rather than a direct hash()
        // call, and the algorithm that produced it is recorded beside it.
        $payload['event_hash'] = \App\Domain\Provenance\DigestAlgorithm::digest(json_encode($payload, JSON_THROW_ON_ERROR));
        $payload['hash_algorithm'] = \App\Domain\Provenance\DigestAlgorithm::CURRENT;

        // Fingerprint the subject as it stands right now. Kept OUT of the event
        // hash on purpose: the payload fields are what the chain has always
        // hashed, and changing them would invalidate every record ever written.
        // The fingerprint travels beside the seal rather than inside it.
        $subject = SubjectFingerprint::of(
            $item->fresh()->getAttributes(), SubjectFingerprint::QUALITY_ITEM_FIELDS,
        );

        QualityItemEvent::create($payload + [
            'subject_hash' => $subject,
            'subject_hash_algorithm' => \App\Domain\Provenance\DigestAlgorithm::CURRENT,
        ]);

        // Witness the head from outside the chain. Without this a deleted tail
        // is invisible: what remains still links and still hashes.
        ChainAnchor::record('Quality item events', $item->id,
            QualityItemEvent::query()->where('quality_item_id', $item->id)->count(),
            $payload['event_hash']);
    }
}
