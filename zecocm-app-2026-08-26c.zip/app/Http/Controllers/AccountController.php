<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Basic portal management every signed-in user gets:
 * profile (name, photo), password change, company logo, sign out.
 */
class AccountController
{
    /** Revoke ONLY the token used for this session. */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json(['message' => 'Signed out.']);
    }

    /** Current account, with image URLs the UI can render directly. */
    public function show(Request $request)
    {
        $u = $request->user();

        return response()->json([
            'id' => $u->id,
            'name' => $u->name,
            'email' => $u->email,
            'platform_role' => $u->platform_role,
            'tenant_id' => $u->tenant_id,
            'avatar_url' => $u->avatar_path ? Storage::disk('public')->url($u->avatar_path) : null,
            'logo_url' => $this->logoUrlFor($u),
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate(['name' => 'required|string|max:120']);
        $u = $request->user();
        $u->name = $data['name'];
        $u->save();

        return response()->json(['message' => 'Profile updated.', 'name' => $u->name]);
    }

    /** Change password: current password required, session tokens elsewhere revoked. */
    public function password(Request $request)
    {
        $data = $request->validate([
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:12|confirmed',
        ]);
        $u = $request->user();
        if (! Hash::check($data['current_password'], $u->password)) {
            return response()->json(['message' => 'Current password is incorrect.'], 422);
        }
        $u->password = Hash::make($data['new_password']);
        $u->save();
        // Revoke every OTHER token so a stolen old session dies with the old password.
        $current = $request->user()->currentAccessToken();
        $u->tokens()->when($current, fn ($q) => $q->where('id', '!=', $current->id))->delete();

        return response()->json(['message' => 'Password changed.']);
    }

    /** Profile photo — every user. */
    public function photo(Request $request)
    {
        $request->validate(['photo' => 'required|image|mimes:jpeg,png,webp|max:4096|dimensions:max_width=8000,max_height=8000']);
        $u = $request->user();
        $ext = $this->verifiedRasterExtension($request->file('photo'));
        $old = $u->avatar_path;
        $path = $request->file('photo')->storeAs(
            'profile/avatars/u'.$u->id,
            Str::uuid().'.'.$ext,
            'public'
        );
        abort_if($path === false, 500, 'The profile photo could not be stored.');
        $u->avatar_path = $path;
        $u->save();
        if ($old && $old !== $path) {
            Storage::disk('public')->delete($old);
        }

        return response()->json(['message' => 'Photo updated.', 'avatar_url' => Storage::disk('public')->url($u->avatar_path)]);
    }

    /**
     * Company logo. Platform admin sets the platform logo; a customer user
     * sets their own company's logo. Technicians may not (suggestion flow).
     */
    public function logo(Request $request)
    {
        $request->validate(['logo' => 'required|image|mimes:jpeg,png,webp|max:4096|dimensions:max_width=8000,max_height=8000']);
        $u = $request->user();
        if ($u->platform_role === 'technician') {
            return response()->json(['message' => 'Technicians propose changes; the admin applies them.'], 403);
        }
        $ext = $this->verifiedRasterExtension($request->file('logo'));

        if ($u->platform_role === 'admin' && $u->tenant_id === null) {
            $disk = Storage::disk('public');
            $old = $disk->files('profile/logos/platform');
            $path = $request->file('logo')->storeAs('profile/logos/platform', Str::uuid().'.'.$ext, 'public');
            abort_if($path === false, 500, 'The platform logo could not be stored.');
            $disk->delete(array_values(array_diff($old, [$path])));

            return response()->json(['message' => 'Platform logo updated.', 'logo_url' => $disk->url($path)]);
        }

        if ($u->tenant_id === null) {
            return response()->json(['message' => 'No company on this account.'], 422);
        }
        $tenant = Tenant::withoutGlobalScopes()->findOrFail($u->tenant_id);
        $old = $tenant->logo_path;
        $path = $request->file('logo')->storeAs('profile/logos/t'.$tenant->id, Str::uuid().'.'.$ext, 'public');
        abort_if($path === false, 500, 'The company logo could not be stored.');
        $tenant->logo_path = $path;
        $tenant->save();
        if ($old && $old !== $path) {
            Storage::disk('public')->delete($old);
        }

        return response()->json(['message' => 'Company logo updated.', 'logo_url' => Storage::disk('public')->url($tenant->logo_path)]);
    }

    private function logoUrlFor($u): ?string
    {
        if ($u->platform_role !== null) {
            $disk = Storage::disk('public');
            $found = collect($disk->files('profile/logos/platform'))
                ->sortByDesc(fn ($path) => $disk->lastModified($path))
                ->first();

            return $found ? $disk->url($found) : null;
        }
        if ($u->tenant_id !== null) {
            $tenant = Tenant::withoutGlobalScopes()->find($u->tenant_id);
            if ($tenant && $tenant->logo_path) {
                return Storage::disk('public')->url($tenant->logo_path);
            }
        }

        return null;
    }

    private function verifiedRasterExtension($file): string
    {
        $mime = strtolower((string) $file->getMimeType());
        $extension = match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            default => null,
        };
        abort_if($extension === null, 422, 'Only verified JPG, PNG, and WebP raster images are accepted.');
        $size = @getimagesize($file->getRealPath());
        abort_if($size === false || ($size[0] * $size[1]) > 25000000, 422, 'The image is malformed or expands beyond the safe pixel limit.');

        return $extension;
    }
}
