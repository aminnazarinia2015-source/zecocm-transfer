<?php

namespace App\Http\Controllers;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Schedule\ProjectAccess;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;

class RfiController
{
    public function __construct(
        private readonly AiAssistant $assistant,
        private readonly ProjectAccess $access,
    ) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'records.view');

        return Rfi::where('project_id', $grant->project->id)
            ->orderByDesc('raised_at')->orderByDesc('id')->limit(200)->get();
    }

    public function store(Request $request)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        }
        $data = $request->validate([
            'project_id' => 'required|integer',
            'subject' => 'required|string|max:255',
            'question' => 'required|string',
            'raised_by_org' => 'nullable|string|max:128',
            'spec_section' => 'nullable|string|max:255',
            'plan_sheets' => 'nullable|string|max:255',
            'reference' => 'nullable|string|max:255',
            'linked_submittal_id' => 'nullable|integer',
            'cost_impact_state' => 'nullable|in:yes,no,not_stated',
            'schedule_impact' => 'nullable|in:yes,no,not_stated',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'rfi.create', write: true);

        // Numbering belongs to THIS project's register. A global count would both leak the
        // size of other tenants' registers and hand this project someone else's next number.
        $next = (int) Rfi::query()
            ->where('project_id', $grant->project->id)
            ->selectRaw("max(cast(replace(number, 'RFI-', '') as integer)) as n")
            ->value('n');
        $number = sprintf('RFI-%03d', $next + 1);

        // A linked submittal must belong to THIS project; a foreign id is refused, not ignored.
        $linkedId = null;
        if (! empty($data['linked_submittal_id'])) {
            $linked = Submittal::query()
                ->where('project_id', $grant->project->id)
                ->find((int) $data['linked_submittal_id']);
            abort_if($linked === null, 422, 'That submittal is not on this project.');
            $linkedId = $linked->id;
        }

        $rfi = Rfi::create([
            'project_id' => $grant->project->id,
            'number' => $number,
            'subject' => $data['subject'],
            'question' => $data['question'],
            'raised_by_org' => ($data['raised_by_org'] ?? null) ?: ($grant->organization ?: 'This account'),
            'raised_at' => now(),
            'ball_in_court' => 'architect',
            'spec_section' => $data['spec_section'] ?? null,
            'plan_sheets' => $data['plan_sheets'] ?? null,
            'reference' => $data['reference'] ?? null,
            'linked_submittal_id' => $linkedId,
            'cost_impact_state' => $data['cost_impact_state'] ?? 'not_stated',
            'schedule_impact' => $data['schedule_impact'] ?? 'not_stated',
            'status' => 'open',
            // NOT NULL on the table; omitting it made every API-created RFI fail with a 500.
            'ai_dispositions' => [],
            'routing_history' => [[
                'to' => 'architect', 'at' => now()->toIso8601String(),
                'action' => 'raised', 'by' => $request->user()->id,
            ]],
        ]);

        return response()->json($rfi, 201);
    }

    public function assist(Request $request, Rfi $rfi)
    {
        $this->access->authorize($request->user(), $rfi->project_id, 'rfi.assist', write: true);
        $category = $request->string('category', 'dimension_clarification')->toString();
        $request->attributes->set('authorized_project_id', $rfi->project_id);

        $result = $this->assistant->suggest(
            task: $rfi->subject."\n".$rfi->question,
            category: $category,
            scope: $rfi->project->jurisdictionScope(),   // derived from the project, never user-picked
            policy: new RefusalPolicy,
        );

        // The suggestion/escalation itself becomes part of the record the
        // moment it is shown - before the human even acts on it.
        $rfi->recordAiDisposition(['kind' => $result->kind()], 'presented', $request->user()->id);
        $rfi->save();

        return response()->json(['kind' => $result->kind(), 'result' => $result]);
    }

    public function respond(Request $request, Rfi $rfi)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        }
        $this->access->authorize($request->user(), $rfi->project_id, 'rfi.respond', write: true);

        $data = $request->validate(['response' => 'required|string']);

        // A sealed answer is sealed. Before this guard a second POST silently
        // overwrote both the response and its seal, leaving no trace that a
        // different answer had ever been issued - on the exact record a dispute
        // turns on. A changed answer is a new RFI or a formal revision, never a
        // quiet rewrite of the original.
        abort_if($rfi->response_seal !== null, 409,
            'This RFI response is already sealed. Issue a revision or a new RFI; a sealed answer is never rewritten.');

        $rfi->response = $data['response'];
        $rfi->status = 'answered';
        $rfi->response_seal = [
            'by' => $request->user()->id,
            'sealed_at' => now()->toIso8601String(),
        ];
        $rfi->save();

        return response()->json($rfi);
    }
}
