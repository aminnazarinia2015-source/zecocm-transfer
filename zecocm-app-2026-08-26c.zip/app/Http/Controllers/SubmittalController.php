<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\Submittal;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;

class SubmittalController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'records.view');

        return Submittal::where('project_id', $grant->project->id)
            ->orderByDesc('created_at')
            ->paginate(50);
    }

    public function store(Request $request)
    {
        $this->rejectPlatformStaffWrites();

        $data = $request->validate([
            'project_id' => 'required|integer',
            'number' => 'required|string|max:32',
            'spec_section' => 'required|string|max:32',
            'title' => 'required|string|max:255',
            'type' => 'required|string|max:64',
            'submitted_by_org' => 'required|string|max:128',
            'contact_person' => 'nullable|string|max:128',
            'submitted_at' => 'nullable|date',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'submittal.create', write: true);

        $submittal = new Submittal($data + [
            'project_id' => $grant->project->id,
            'status' => 'draft',
            'routing_history' => [],
        ]);
        $submittal->ball_in_court = $submittal->defaultDiscipline(); // derived, not picked
        $submittal->save();

        return response()->json($submittal, 201);
    }

    public function stamp(Request $request, Submittal $submittal)
    {
        $this->rejectPlatformStaffWrites();
        $this->access->authorize($request->user(), $submittal->project_id, 'submittal.stamp', write: true);

        $data = $request->validate([
            'action' => 'required|in:no_exceptions,revise_resubmit,rejected',
        ]);

        // Stamping seals identity + timestamp + the evidence state at signature,
        // then returns the ball. The seal is append-only - and now actually is.
        // The comment claimed append-only while nothing enforced it: a second
        // stamp overwrote the first, so a 'no exceptions taken' could quietly
        // become a 'rejected' with no record that the reviewer ever said
        // otherwise. A changed disposition is a resubmittal, not a rewrite.
        abort_if($submittal->stamp !== null, 409,
            'This submittal is already stamped. Route a resubmittal; a stamp is never overwritten.');

        $submittal->stamp = [
            'action' => $data['action'],
            'stamped_by' => $request->user()->id,
            'sealed_at' => now()->toIso8601String(),
        ];
        $submittal->status = $data['action'];
        $submittal->route('contractor', ['action' => 'stamp_returned', 'by' => $request->user()->id]);
        $submittal->save();

        return response()->json($submittal);
    }

    /**
     * Server-side enforcement of the read-only rule: platform staff browsing
     * a tenant can NEVER write tenant data, whatever the UI does. Technician
     * proposals go through the platform suggestions endpoint instead.
     */
    private function rejectPlatformStaffWrites(): void
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces. Submit a suggestion instead - the admin applies it.');
        }
    }
}
