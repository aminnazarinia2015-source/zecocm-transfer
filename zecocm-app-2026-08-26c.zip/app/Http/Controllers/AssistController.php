<?php

namespace App\Http\Controllers;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\NoMatch;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Licensing\CapabilityLicense;
use App\Domain\Licensing\HelpAssistant;
use App\Domain\Schedule\ProjectAccess;
use App\Models\Tenant;
use Illuminate\Http\Request;

/**
 * Ask ZecoCM — the general assistant endpoint behind the floating button.
 * Same posture as everywhere: retrieval-first, cited or escalated, never a guess.
 */
class AssistController
{
    public function __construct(
        private readonly AiAssistant $assistant,
        private readonly ProjectAccess $access,
        private readonly CapabilityLicense $license,
        private readonly HelpAssistant $help,
    ) {}

    public function ask(Request $request)
    {
        $data = $request->validate([
            'question' => 'required|string|max:2000',
            'project_id' => 'nullable|integer',
            'category' => 'nullable|string|max:60',
            'mode' => 'nullable|in:help,assist',
        ]);

        $tenant = $request->user()?->tenant_id ? Tenant::find($request->user()->tenant_id) : null;

        // FREE TIER: ZecoCM explaining itself. No project evidence is read, so this is
        // always available to every account and costs nothing to run.
        $mode = $data['mode'] ?? (empty($data['project_id']) ? 'help' : 'assist');
        if ($mode === 'help') {
            return response()->json($this->help->answer($data['question'], $tenant));
        }

        // LICENSED TIER: grounded in this project's own authorised evidence.
        if (empty($data['project_id'])) {
            return response()->json([
                'kind' => 'refused',
                'reason' => 'AI project assistance answers from a specific project\'s records. Open a project first, or ask the free help assistant about how ZecoCM works.',
            ], 422);
        }

        // Paid project assistance is always queued and audited. The legacy endpoint
        // remains as a compatibility facade for existing clients.
        $request->merge([
            'task_type' => 'answer',
            'idempotency_key' => $request->header('Idempotency-Key'),
        ]);
        return app(AiRunController::class)->store($request);

        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'assistant.use');
        $project = $grant->project;
        $projectTenant = Tenant::find($project->tenant_id);

        if ($projectTenant !== null) {
            $state = $this->license->state($projectTenant, 'ai.assist');
            if (! $state->allows()) {
                return response()->json([
                    'kind' => 'not_licensed',
                    'capability' => 'ai.assist',
                    'state' => $state->state,
                    'ends_at' => $state->endsAt,
                    'reason' => match ($state->state) {
                        'expired' => 'The AI project assistance licence for this account ended on '.substr((string) $state->endsAt, 0, 10).'. The free help assistant is still available.',
                        'suspended' => 'AI project assistance is switched off for this account. The free help assistant is still available.',
                        'limit_reached' => 'This account has used its AI project assistance allowance for the current period. The free help assistant is still available.',
                        default => 'This account is not licensed for AI project assistance. The free help assistant answers questions about how ZecoCM works at no cost.',
                    },
                ], 402);
            }
        }

        $request->attributes->set('authorized_project_id', $project->id);
        // Only now, and only if this grant may actually read project documents.
        $request->attributes->set('authorized_evidence_read', $grant->allows('documents.view') === true);
        $scope = $project->jurisdictionScope();
        if ($projectTenant !== null) {
            $this->license->recordUse($projectTenant, 'ai.assist', $request->user()?->id);
        }

        $result = $this->assistant->suggest(
            task: $data['question'],
            category: $data['category'] ?? 'general_administration',
            scope: $scope,
            policy: new RefusalPolicy,
        );

        if ($result instanceof CitedSuggestion) {
            return response()->json([
                'kind' => 'suggestion',
                'text' => $result->text,
                'citations' => array_map(fn ($c) => ['source' => $c->source, 'edition' => $c->edition], $result->citations),
            ]);
        }
        if ($result instanceof Escalation) {
            return response()->json([
                'kind' => 'escalation',
                'reason' => $result->reason,
                'route_to' => $result->routeTo,
            ]);
        }

        /** @var NoMatch $result */
        return response()->json([
            'kind' => 'no_match',
            'scope_searched' => $result->scopeSearched,
        ]);
    }
}
