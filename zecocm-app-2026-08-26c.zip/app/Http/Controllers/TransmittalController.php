<?php

namespace App\Http\Controllers;

use App\Domain\Documents\ComposedDocument;
use App\Domain\Documents\TransmittalComposer;
use App\Domain\Schedule\ProjectAccess;
use App\Models\IssuedDocument;
use App\Models\Rfi;
use App\Models\Submittal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Branded RFI and submittal transmittals.
 *
 * Preview is free to repeat and changes nothing. Issuing appends an immutable row to the
 * issued-document register with the exact fingerprint of the bytes that went out, so the
 * copy in a recipient's inbox can later be proved to be - or not to be - the copy issued.
 */
class TransmittalController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function preview(Request $request, string $type, int $id, TransmittalComposer $composer)
    {
        [$doc, $grant] = $this->compose($request, $type, $id, $composer, write: false);

        if ($request->query('format') === 'html') {
            return response($doc->html, 200, [
                'Content-Type' => 'text/html; charset=UTF-8',
                'Content-Security-Policy' => "default-src 'none'; img-src data:; style-src 'unsafe-inline'",
                'X-Content-Type-Options' => 'nosniff',
            ]);
        }

        return response()->json([
            'document_number' => $doc->documentNumber,
            'fingerprint' => $doc->fingerprint,
            'parties' => $doc->parties,
            'clock' => $doc->clock,
            'attachments' => $doc->attachments,
            'one_page' => true,
            'overflow' => $doc->overflow,
            'overflow_notice' => $doc->overflow
                ? 'This item is longer than one cover sheet. The sheet carries a continuation notice and the full text stays on the record; attach the full statement as the first attachment.'
                : null,
            'issued_history' => $this->history($doc),
            'html' => $doc->html,
            'notice' => 'This is a preview. Nothing has been issued and no register has changed.',
        ]);
    }

    public function issue(Request $request, string $type, int $id, TransmittalComposer $composer)
    {
        $request->validate(['confirm' => 'required|in:confirm,accepted']);

        [$doc, $grant] = $this->compose($request, $type, $id, $composer, write: true);

        $issued = DB::transaction(function () use ($doc, $grant, $request) {
            $revision = IssuedDocument::query()
                ->where('record_type', $doc->recordType)
                ->where('record_id', $doc->recordId)
                ->max('revision');

            return IssuedDocument::create([
                'tenant_id' => $grant->project->tenant_id,
                'project_id' => $grant->project->id,
                'record_type' => $doc->recordType,
                'record_id' => $doc->recordId,
                'document_number' => $doc->documentNumber,
                'revision' => ((int) $revision) + 1,
                'content_sha256' => $doc->fingerprint,
                'parties' => $doc->parties,
                'clock' => $doc->clock,
                'attachments' => $doc->attachments,
                'issued_by' => $request->user()->id,
                'issued_at' => now(),
            ]);
        });

        return response()->json([
            'issued' => true,
            'revision' => $issued->revision,
            'fingerprint' => $doc->fingerprint,
            'issued_at' => $issued->issued_at?->toIso8601String(),
            'notice' => 'Recorded on the issued-document register. This row is immutable; a corrected document is issued as a new revision.',
        ], 201);
    }

    /** @return array{0:ComposedDocument,1:\App\Domain\Schedule\ProjectGrant} */
    private function compose(Request $request, string $type, int $id, TransmittalComposer $composer, bool $write): array
    {
        abort_unless(in_array($type, ['rfi', 'submittal'], true), 404);

        if ($type === 'rfi') {
            $record = Rfi::query()->findOr($id, fn () => abort(404));
        } else {
            $record = Submittal::query()->findOr($id, fn () => abort(404));
        }

        $grant = $this->access->authorize(
            $request->user(),
            (int) $record->project_id,
            $write ? 'records.issue' : 'records.view',
            write: $write,
        );

        $doc = $type === 'rfi'
            ? $composer->rfi($record, $grant->project, $grant)
            : $composer->submittal($record, $grant->project, $grant);

        return [$doc, $grant];
    }

    /** @return array<int,array<string,mixed>> */
    private function history(ComposedDocument $doc): array
    {
        return IssuedDocument::query()
            ->where('record_type', $doc->recordType)
            ->where('record_id', $doc->recordId)
            ->orderBy('revision')
            ->get()
            ->map(fn (IssuedDocument $d) => [
                'revision' => $d->revision,
                'issued_at' => $d->issued_at?->toIso8601String(),
                'fingerprint' => substr((string) $d->content_sha256, 0, 32),
                'matches_current' => $d->content_sha256 === $doc->fingerprint,
            ])->all();
    }
}
