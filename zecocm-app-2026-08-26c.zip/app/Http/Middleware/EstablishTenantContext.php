<?php

namespace App\Http\Middleware;

use App\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;

/**
 * Sets the tenant context from the authenticated user, exactly once per
 * request. Customer users are locked to their own tenant. Platform staff
 * (admin/technician) may browse a tenant READ-ONLY by passing an explicit
 * X-Browse-Tenant header - flagged as staff so every write path rejects.
 */
class EstablishTenantContext
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        abort_if($user === null, 401);

        TenantContext::clear();

        if ($user->isPlatformStaff()) {
            $browse = (int) $request->header('X-Browse-Tenant', '0');
            if ($browse > 0) {
                TenantContext::set($browse, platformStaff: true, platformAdmin: $user->isPlatformAdmin());
            }
            // No header: staff stay in the platform layer; tenant queries
            // resolve to nothing (fail closed) - exactly right.
        } else {
            abort_if($user->tenant_id === null, 403, 'User has no tenant.');
            TenantContext::set($user->tenant_id, platformStaff: false);
        }

        try {
            return $next($request);
        } finally {
            TenantContext::clear();   // never leak context across requests
        }
    }
}
