#!/usr/bin/env bash
# ZecoCM one-paste server bootstrap - run as root on zecocm-app-01
# Prereq: /root/zecocm-app.zip present (see RUNBOOK for transfer options)
set -euo pipefail

apt-get update -y
apt-get install -y php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-xml \
  php8.3-curl php8.3-zip php8.3-gd nginx unzip
command -v composer >/dev/null || { curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer; }

mkdir -p /var/www && cd /var/www
rm -rf zecocm && unzip -q /root/zecocm-app.zip -d /var/www && mv zecocm-deploy zecocm && cd zecocm

composer install --no-dev --optimize-autoloader --no-interaction
composer require laravel/sanctum --no-interaction
cp -n .env.example .env
php artisan key:generate --force
grep -q '^PROVENANCE_SIGNING_KEY=..' .env || sed -i "s/^PROVENANCE_SIGNING_KEY=.*/PROVENANCE_SIGNING_KEY=$(openssl rand -hex 32)/" .env

echo ""
echo ">>> NOW EDIT /var/www/zecocm/.env - set DB_*, AWS_*, ANTHROPIC_API_KEY, SEED_ADMIN_PASSWORD"
echo ">>> then run:  cd /var/www/zecocm && php artisan migrate --force && php artisan db:seed --force"
echo ">>> verify:    php tests/DomainTest.php   (must end: 23 passed, 0 failed)"
echo ">>> serve:     cp deploy/nginx.conf /etc/nginx/sites-enabled/zecocm.conf && nginx -t && systemctl reload nginx php8.3-fpm"
