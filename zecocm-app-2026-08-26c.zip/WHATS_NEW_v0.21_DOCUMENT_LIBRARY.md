# ZecoCM v0.21 Construction Document Library

## Complete module slice

- Familiar computer-folder and SharePoint-style project document experience.
- Project-scoped folder hierarchy and breadcrumbs.
- Folder search, review filters, empty/loading/error/quarantine states.
- Multiple-document upload with sequential, visible results.
- PDF, Word, Excel, PowerPoint, text/CSV and documentary image allowlist.
- Scripts, executables, archives, HTML and SVG active content refused.
- Extension-to-detected-content validation; filenames normalized.
- Files are content-addressed and SHA-256 fingerprinted.
- Non-testing uploads remain quarantined until a configured malware scanner
  reports clean; quarantined content cannot be downloaded or retrieved by AI.
- Immutable version append: revisions never overwrite earlier bytes.
- Duplicate bytes replay safely without creating another document or version.
- Append-only, hash-chained document creation/version events.
- Server-derived project access and fail-closed tenant isolation.
- Authenticated, no-store downloads with content sniffing disabled and a sandbox
  content-security policy.

## Validation

- 73 tests passed, 322 assertions.
- PHP syntax passed for application, routes, migrations and tests.
- Document tests cover folders, upload, documentary-type rejection,
  idempotent duplicate handling, immutable revision history, hash-chained events
  and cross-tenant folder denial.

## Operational requirement

Production must configure and monitor a malware scanner. Until a scan is clean,
the module intentionally leaves uploaded content quarantined. This is a safety
control, not an unfinished user-interface state.
