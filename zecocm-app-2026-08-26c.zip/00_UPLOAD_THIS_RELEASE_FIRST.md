# ZecoCM v0.23 — Production Upload and Verification

This is the upload-ready release candidate. It is not truthful to label the
entire product complete until the production checks below pass and the planned
business modules listed in `FINAL_BUILD_STATUS_v0.22.md` are implemented.

## Before replacing production

1. Create a dated backup of the application, environment configuration,
   database and uploaded files.
2. Prove the database backup can be read and record the rollback owner.
3. Keep the current release available as the rollback target.
4. Confirm production secrets remain on the server. Do not copy `.env` from
   this ZIP.

## Install the release

1. Extract into a new versioned release directory; do not overwrite the active
   directory in place.
2. Install locked production dependencies with development packages disabled.
3. Preserve the production `.env` and private storage configuration.
4. Configure a working ClamAV-compatible scanner using
   `SCHEDULE_MALWARE_SCANNER_BINARY`. Without it, document uploads correctly
   remain quarantined and cannot be released.
5. Put the site into maintenance mode, run the database migrations, clear stale
   framework caches, rebuild optimized production caches, and start/restart the
   queue worker.
6. Switch the web server to the new release and take the site out of
   maintenance mode.

## Mandatory live smoke test

Do not call the deployment successful until all items pass:

- `/up` returns healthy.
- Login, refresh/session restoration, logout and protected-page behavior work.
- Browser Back and Forward work across the platform, customer and project
  worlds.
- A new portal begins with zero projects.
- Platform admin, support mode and technician read-only boundaries are correct.
- Create an RFI and confirm it returns success and appears once in the register.
- Create a document folder, upload a clean PDF, and confirm its scan state.
- In a controlled security test, verify an EICAR fixture remains quarantined.
- Create a Quality & Punch item, transition it, and verify closure requires a
  named formal determination.
- Open Schedule Intelligence and verify versions, comparison history, units,
  baseline-candidate warning and provenance.
- Verify desktop and phone layouts, keyboard focus, dialogs, toasts and readable
  contrast on each critical workflow.
- Confirm queue processing, failed-job visibility, outbox delivery, logs,
  storage permissions and monitoring.

## Roll back immediately if

- login or tenant isolation fails;
- the RFI create request fails;
- migrations or queue jobs fail repeatedly;
- documents bypass quarantine/scanning;
- customer records appear under the wrong portal;
- critical screens return an error or cannot be navigated with Back/Forward.

Rollback means switching the web server to the prior release and restoring the
database only when the migration strategy requires it. Preserve logs and the
failed release for investigation; do not erase evidence.

## What to send back for final verification

Send the live URL and say "uploaded." Keep the signed-in browser session open.
ZecoCM can then be checked screen by screen in production. No real notice,
payment, signature, acceptance, determination or customer-data mutation will be
performed without a separately identified safe test record and authorization.
