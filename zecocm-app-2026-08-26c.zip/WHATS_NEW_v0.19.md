# What's New in ZecoCM v0.19

v0.19 turns the v0.18 cited assistant into a governed intelligence foundation.

- Knowledge Atlas with immutable sources, versions, hashes, authority, access, status, review, and relationships.
- Provisional-by-default extraction and steward-controlled verification/adoption.
- Corpus-enforced tenant-safe retrieval and complete source citations.
- Strict refusal when the model omits or invents passage references.
- Queued, idempotent, cancellable, fully audited AI runs.
- Append-only learning feedback and successful-answer-only metering.
- Model-tier, allowed-task, quota, budget, window, and sponsor-ceiling licence controls.
- Universal command bar and AI run register.
- Full transmittal SHA-256 fingerprint.
- Session/runtime repair required for reliable refresh.

This release is knowledge-ready, not a claim of autonomous web training. See the operating model for the approved external-source and private-model path.
