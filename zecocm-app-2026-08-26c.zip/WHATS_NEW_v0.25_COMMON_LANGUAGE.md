# ZecoCM v0.25 — Common Construction Language

This release includes every v0.24 live-routing/truth fix and adds a controlled
product-language standard for customers arriving from other CM platforms.

- “In my court” becomes “My action items.”
- “Documents & Standards” becomes “Documents.”
- “Inspections & Punch” becomes “Quality & Punch List.”
- “Knowledge Atlas” becomes “Knowledge Library · ZecoCM Atlas.”
- “AI Run Register” becomes “AI Activity & Audit Log.”
- “Structure Builder” becomes “Project Team & Routing,” with ZecoCM Structure
  Builder retained as a secondary branded identity.
- “Send to City” is paired with the familiar “Agency Package Export.”

RFIs, submittals, daily reports, change orders, pay applications, transmittals,
meeting minutes and closeout retain their established construction terms.

Unavailable administration screens now use their full public names and explain
the missing server-backed workflow; internal route names are never displayed.

Validation: 77 tests, 363 assertions, 175 PHP syntax checks.
