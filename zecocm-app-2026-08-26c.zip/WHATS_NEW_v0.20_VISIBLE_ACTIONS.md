# ZecoCM v0.20 Visible Actions and Action Intelligence

## Implemented

- Shared busy-state contract prevents repeat clicks during active requests.
- Sign-in, profile name, password and sign-out show pending and failure states.
- Customer creation, section assignment, suggestion disposition, licensing and
  portal creation now state pending, refused, failed and successful outcomes.
- RFI, submittal and daily-report creation visibly protects active submissions.
- Schedule upload and asynchronous comparison show durable progress and
  uncertain-outcome guidance; comparison submission retains its idempotency key.
- Decision sealing and transmittal issuance report that nothing was formally
  issued when the service cannot be reached.
- Dialogs expose accessible semantics, Escape-to-close and focus restoration.
- Toast feedback is an accessible polite live region.
- A cross-module Action Intelligence strip explains verified scope, the user's
  server-derived authority boundary and the next safe action.
- Unbuilt modules remain honest unavailable states; no sample record becomes a
  project fact.

## Validation

- Application test suite: 68 passed, 296 assertions.
- PHP syntax: application, routes, migrations and tests passed.
- Static visible-action regression coverage added.

## Truthful boundary

This is a hardened functional foundation, not the completed 20-module product.
The next milestone should implement complete evidence-to-decision vertical
slices for each currently unavailable module, beginning with look-ahead,
quality/inspections, cost/change and mobile field evidence.
