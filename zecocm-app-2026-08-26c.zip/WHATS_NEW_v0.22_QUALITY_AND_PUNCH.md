# ZecoCM v0.22 Quality & Punch

- Responsive inspection, observation, deficiency and punch capture.
- Severity, location, specification, drawing, assignment and due-date fields.
- Structural epistemic labels: fact, party assertion, dispute, recommendation.
- Server-derived project authority and fail-closed tenant isolation.
- Relational links to sealed media from the same authorized project.
- Controlled state machine: open, in progress, ready for verification, closed,
  rejected and reopened.
- Closure requires an accountable `formal_determination`; an AI recommendation
  or party assertion cannot close the item.
- Every transition appends a hash-chained event. The current status is only a
  verified projection; history is never overwritten.
- Visible loading, empty, offline, refused and pending states.
