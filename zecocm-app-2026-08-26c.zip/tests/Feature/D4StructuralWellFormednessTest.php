<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Domain\Knowledge\Ocr\StructuralWellFormedness;
use Tests\TestCase;

/**
 * D4 correctness follow-up — structural well-formedness as a confidence-independent
 * reliability signal.
 *
 * Measured in the OCR lab across four rounds (`claude/d4-ocr-round3-findings.md`,
 * `claude/d4-ocr-round4-findings.md`). On a 50-page measured corpus:
 *
 *   page mean confidence < 91.05 alone      sensitivity 0.562, specificity 1.000
 *   structural well-formedness alone        sensitivity 0.500, specificity 1.000
 *   either of the two                       sensitivity 0.875, specificity 1.000
 *
 * The two known limits are pinned as PASSING assertions at the bottom of this file,
 * deliberately, so that this class's silence is never mistaken for coverage.
 */
final class D4StructuralWellFormednessTest extends TestCase
{
    public function test_it_judges_only_tokens_that_announce_a_shape(): void
    {
        foreach (['inclusive', 'Contract', 'shall', 'the', '01', '33', '00', 'DAYS', '28'] as $prose) {
            $this->assertNull(
                StructuralWellFormedness::inspectToken($prose),
                "prose token '{$prose}' must not be judged"
            );
        }
    }

    public function test_it_accepts_well_formed_tokens_of_every_scope(): void
    {
        $wellFormed = [
            '$1,608,540.00' => StructuralWellFormedness::SCOPE_CURRENCY,
            '$0.50' => StructuralWellFormedness::SCOPE_CURRENCY,
            '0.5%' => StructuralWellFormedness::SCOPE_PERCENT,
            '100%' => StructuralWellFormedness::SCOPE_PERCENT,
            '4/L-3' => StructuralWellFormedness::SCOPE_DETAIL_REF,
            'A-101' => StructuralWellFormedness::SCOPE_SHEET_REF,
            'S-201.1' => StructuralWellFormedness::SCOPE_SHEET_REF,
            '3/4"' => StructuralWellFormedness::SCOPE_DIMENSION,
            "12'-6\"" => StructuralWellFormedness::SCOPE_DIMENSION,
            '6"' => StructuralWellFormedness::SCOPE_DIMENSION,
            "12'" => StructuralWellFormedness::SCOPE_DIMENSION,
            '03/15/2026' => StructuralWellFormedness::SCOPE_DATE,
        ];

        foreach ($wellFormed as $token => $scope) {
            $verdict = StructuralWellFormedness::inspectToken((string) $token);

            $this->assertNotNull($verdict, "'{$token}' must announce a shape");
            $this->assertSame($scope, $verdict['scope'], "'{$token}' resolved to the wrong scope");
            $this->assertTrue($verdict['well_formed'], "'{$token}' must be well-formed");
        }
    }

    public function test_it_flags_the_confident_one_million_dollar_corruption(): void
    {
        // Round 3's decisive case: "$1,608,540.00" read as "$:" + "608,540.00". The damaged
        // token carries 84.9 confidence on a page whose mean is 95.2, so no confidence
        // threshold at any granularity sees it. The shape check does.
        $verdict = StructuralWellFormedness::inspectToken('$:');

        $this->assertNotNull($verdict);
        $this->assertSame(StructuralWellFormedness::SCOPE_CURRENCY, $verdict['scope']);
        $this->assertFalse($verdict['well_formed']);
    }

    public function test_it_flags_a_mangled_token_in_each_scope(): void
    {
        foreach (['$1,60B,540.00', '$:', '0.5%%', '4/L-', '03/15/26', "12'-\""] as $token) {
            $verdict = StructuralWellFormedness::inspectToken($token);

            $this->assertNotNull($verdict, "'{$token}' must announce a shape");
            $this->assertFalse($verdict['well_formed'], "'{$token}' must be malformed");
        }
    }

    public function test_it_strips_trailing_sentence_punctuation_but_never_digits(): void
    {
        $this->assertTrue(StructuralWellFormedness::inspectToken('03/15/2026,')['well_formed']);
        $this->assertTrue(StructuralWellFormedness::inspectToken('$1,608,540.00.')['well_formed']);

        // A truncated amount stays truncated — the missing cent digit is evidentiary content,
        // not punctuation.
        $this->assertFalse(StructuralWellFormedness::inspectToken('$1,608,540.0')['well_formed']);
    }

    public function test_it_folds_typographic_quote_marks_before_judging(): void
    {
        // Round 4, found only by running the class against real Tesseract output: the foot
        // mark in 12'-6" is read as U+2019 often enough to matter. An ASCII claim predicate
        // made such a token invisible rather than malformed — and silence reads as "fine".
        $verdict = StructuralWellFormedness::inspectToken("12\u{2019}-6\u{201D}");

        $this->assertNotNull($verdict, 'a typographic foot mark must not make the token invisible');
        $this->assertSame(StructuralWellFormedness::SCOPE_DIMENSION, $verdict['scope']);
        $this->assertTrue($verdict['well_formed']);
    }

    public function test_scope_resolution_order_is_load_bearing(): void
    {
        // "03/15/2026" and "3/4\"" both satisfy the detail-reference claim predicate. Resolving
        // either under the wrong scope makes a correct token look malformed.
        $this->assertSame(
            StructuralWellFormedness::SCOPE_DATE,
            StructuralWellFormedness::inspectToken('03/15/2026')['scope']
        );
        $this->assertSame(
            StructuralWellFormedness::SCOPE_DIMENSION,
            StructuralWellFormedness::inspectToken('3/4"')['scope']
        );
    }

    public function test_it_reports_page_level_results_without_mutating_anything(): void
    {
        $words = [
            ['text' => 'is', 'confidence' => 93.0],
            ['text' => '$:', 'confidence' => 84.9],
            ['text' => '608,540.00,', 'confidence' => 91.4],
            ['text' => 'inclusive', 'confidence' => 93.0],
        ];
        $before = $words;

        $page = StructuralWellFormedness::inspectPage($words);

        $this->assertSame($before, $words, 'inspectPage must never mutate its input');
        $this->assertSame(1, $page['in_scope']);
        $this->assertTrue($page['any_malformed']);
        $this->assertSame('$', $page['malformed'][0]['token']);
        $this->assertEqualsWithDelta(84.9, $page['malformed'][0]['confidence'], 0.01);
    }

    public function test_it_reports_a_clean_page_as_clean(): void
    {
        $page = StructuralWellFormedness::inspectPage([
            ['text' => '$1,608,540.00', 'confidence' => 92.0],
            ['text' => '0.5%', 'confidence' => 96.0],
            ['text' => '4/L-3', 'confidence' => 92.0],
            ['text' => 'A-101.', 'confidence' => 87.0],
            ['text' => '3/4"', 'confidence' => 94.0],
            ['text' => "12'-6\"", 'confidence' => 93.0],
            ['text' => '03/15/2026,', 'confidence' => 96.0],
        ]);

        $this->assertSame(7, $page['in_scope']);
        $this->assertFalse($page['any_malformed']);
        $this->assertSame([], $page['malformed']);
    }

    public function test_known_limit_a_well_formed_but_wrong_value_is_invisible(): void
    {
        // Measured, round 4: 12'-6" read as 12" at token confidence 51 on a page whose mean
        // confidence is 93.8. Twelve feet six inches became twelve inches, and the corrupted
        // token is STRUCTURALLY PERFECT. This assertion passes deliberately. It is the reason
        // an OCR-derived quantity cannot be made safe to cite as definitive by this class
        // alone — it is one signal, not a complete correctness proof.
        $this->assertTrue(StructuralWellFormedness::inspectToken('12"')['well_formed']);
    }

    public function test_known_limit_a_destroyed_claim_predicate_is_invisible(): void
    {
        // Measured, round 4: 4/L-3 read as 4/1-3 at token confidence 46. The 'L' became a '1',
        // so the token no longer announces itself as a detail reference at all. A shape check
        // cannot see a corruption whose whole effect is to destroy the shape announcement.
        $this->assertNull(StructuralWellFormedness::inspectToken('4/1-3'));
    }
}
