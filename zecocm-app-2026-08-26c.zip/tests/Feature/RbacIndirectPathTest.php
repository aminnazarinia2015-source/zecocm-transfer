<?php

namespace Tests\Feature;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\AiRunLedger;
use App\Domain\Licensing\CapabilityLicense;
use App\Jobs\RunGovernedAi;
use App\Models\AiRun;
use App\Models\DailyReport;
use App\Models\Membership;
use App\Models\MediaItem;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * SEC-3, continued. Codex's second pass named the more dangerous surface:
 * not the primary endpoint (already covered by RbacNegativeTest) but the
 * side doors - queued jobs that outlive the permission check that queued
 * them, and child resources reachable by ID alone.
 *
 * Two of Codex's five priority items, attacked directly:
 *
 *   5. Permission revocation after dispatch - a queued job must re-check
 *      current authorization at the moment it touches the privileged side
 *      effect, not merely restore tenant context.
 *
 *   "Possession of an object is never authorization to act on it" - a valid
 *   in-tenant object ID plus an unauthorized actor must still fail, even
 *   when the object itself belongs to the caller's own tenant.
 *
 * Items 1/3/4/2 (bulk, export, nested-route) are not attacked here: this
 * codebase has no bulk-ID or export HTTP endpoints at all (verified by grep
 * across routes/api.php and app/Http/Controllers - EvidenceExport is
 * CLI-only, reachable by no route), so that surface does not exist to
 * attack. Recorded as a scope note rather than silently assumed covered.
 */
class RbacIndirectPathTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config(['queue.default' => 'sync']);
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $this->membership = Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['documents.view' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private Membership $membership;

    // ---- item 5: permission revoked between dispatch and execution -------------

    public function test_a_queued_ai_run_reauthorizes_at_execution_and_refuses_evidence_once_membership_is_revoked(): void
    {
        // Codex's exact sequence: permission at queue time, revoked before the
        // worker reaches the privileged side effect (reading evidence).
        TenantContext::set($this->tenant->id);
        $run = AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'requested_by' => $this->user->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(),
            'idempotency_key' => (string) \Illuminate\Support\Str::uuid(),
            'task_type' => 'answer', 'provider' => 'none', 'model' => 'none',
            'prompt_version' => 'test', 'retrieval_version' => 'test', 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
            'question' => 'What is the minimum trench depth?', 'category' => 'specification',
            'status' => 'queued', 'progress' => 0,
        ]);
        TenantContext::clear();

        // The permission is revoked - the membership that granted
        // documents.view no longer exists - AFTER the run was queued, before
        // the worker picks it up.
        TenantContext::set($this->tenant->id);
        $this->membership->delete();
        TenantContext::clear();

        app(RunGovernedAi::class, ['runId' => $run->id])->handle(
            app(AiAssistant::class), app(AiRunLedger::class),
        );

        $run->refresh();
        // Refused, not completed with a cited answer - the retriever saw
        // authorized_evidence_read=false (ProjectAccess::authorize threw for
        // a user with no membership row) and returned nothing to answer from.
        $this->assertNotSame('completed', $run->status);
        $this->assertContains($run->status, ['refused', 'failed']);
    }

    public function test_a_queued_ai_run_still_succeeds_when_the_membership_survives_to_execution(): void
    {
        // The control case: same sequence, membership left intact. Proves the
        // refusal above is caused by the revocation, not by some unrelated
        // fixture problem (no knowledge to retrieve, license expired, etc).
        TenantContext::set($this->tenant->id);
        $run = AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'requested_by' => $this->user->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(),
            'idempotency_key' => (string) \Illuminate\Support\Str::uuid(),
            'task_type' => 'answer', 'provider' => 'none', 'model' => 'none',
            'prompt_version' => 'test', 'retrieval_version' => 'test', 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
            'question' => 'What is the minimum trench depth?', 'category' => 'specification',
            'status' => 'queued', 'progress' => 0,
        ]);
        TenantContext::clear();

        app(RunGovernedAi::class, ['runId' => $run->id])->handle(
            app(AiAssistant::class), app(AiRunLedger::class),
        );

        $run->refresh();
        // No knowledge is seeded in this fixture, so the honest outcome is a
        // refusal - never a cited suggestion, since nothing to cite exists.
        // The point of the contrast: this run reached the retriever WITH
        // authorized_evidence_read=true and still found nothing, rather than
        // being denied the read outright as in the revoked case above.
        $this->assertSame('refused', $run->status);
        $this->assertContains($run->result['kind'] ?? null, ['no_match', 'escalation']);
    }

    // ---- "possession of an object is never authorization to act on it" --------

    public function test_media_cannot_be_linked_to_a_record_belonging_to_a_different_project(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['tenant_id' => $this->tenant->id, 'number' => 'P-411', 'name' => 'Other',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $foreignReport = DailyReport::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'report_date' => now()->toDateString(), 'foreman_id' => $this->user->id, 'weather' => [],
            'work_performed' => 'Grading', 'cost_code_notes' => [], 'corrections' => []]);
        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => str_repeat('a', 64), 'storage_path' => 'media/sealed/aa/'.str_repeat('a', 64),
            'original_name' => 'photo.jpg', 'mime' => 'image/jpeg', 'bytes' => 10,
            'malware_scan_status' => 'clean', 'provenance' => [], 'provenance_signature' => 'x',
            'confidence' => 'strong', 'server_received_at' => now(), 'receipt_sequence' => 1,
            'capture_time_basis' => 'server_receipt', 'capture_finding' => 'consistent', 'client_claims' => [],
            'captured_by' => $this->user->id]);
        TenantContext::clear();

        // The requester DOES hold media.link on their own project (where the
        // media item lives) - the attack is pointing that valid grant at a
        // record from a project they were never authorized on, by ID alone.
        TenantContext::set($this->tenant->id);
        $this->membership->forceFill(['capabilities' => ['media.link' => true]])->save();
        TenantContext::clear();

        $response = $this->postJson("/api/media/{$media->id}/link", [
            'record_type' => 'daily_report', 'record_id' => $foreignReport->id,
        ]);

        $response->assertStatus(422);
        $this->assertStringContainsString('same authorized project', $response->json('message'));
    }

    // ---- structural: an authorize()-calling job re-checks a real capability, not just tenant context --

    public function test_the_ai_job_asks_project_access_for_a_capability_rather_than_only_restoring_tenant_context(): void
    {
        // Guards the exact regression Codex is worried about: a job that
        // resets TenantContext (so queries scope correctly) but treats that
        // as equivalent to re-authorizing the requester, when it is not -
        // tenant scoping and capability authorization are different checks.
        $source = file_get_contents(app_path('Jobs/RunGovernedAi.php'));
        $this->assertStringContainsString('ProjectAccess::class', $source);
        $this->assertStringContainsString("authorize(\$requester", $source);
    }
}
