<?php

namespace Tests\Feature;

use App\Domain\Provenance\ChainSpec;
use App\Domain\Provenance\ChainVerifier;
use App\Models\Membership;
use App\Models\Project;
use App\Models\QualityItem;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The claim: a sealed record stays historically truthful through every
 * lifecycle operation.
 *
 * That claim is much broader than the sealing tests already cover. The question
 * Codex put, and the right one, is: can anything ADJACENT to the sealed object
 * change its evidentiary meaning without invalidating or recording the change?
 *
 * These are the attacks. Some of them this system already survives. Where it
 * does not, the test says so out loud rather than being quietly omitted, because
 * the whole point of the product is that the record does not lie about itself.
 */
class EvidenceInvariantTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Inspector',
            'email' => 'inspector@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-800', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'inspector', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    // ---- attacks the chain already survives --------------------------------

    public function test_a_database_level_edit_that_bypasses_every_model_hook_is_caught(): void
    {
        // The attacker does not use the API. They have the database.
        $item = $this->itemWithEvents();

        $target = DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderBy('id')->skip(1)->first();
        DB::table('quality_item_events')->where('id', $target->id)
            ->update(['note' => 'The contractor accepted responsibility.']);

        $result = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
    }

    public function test_a_forged_event_hash_does_not_repair_the_chain(): void
    {
        // A more careful attacker edits the note AND recomputes that record's own
        // hash. The record now hashes correctly to its own content - and every
        // record after it still points at the old hash.
        $item = $this->itemWithEvents();

        $target = DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderBy('id')->skip(1)->first();

        $payload = ['tenant_id' => $target->tenant_id, 'project_id' => $target->project_id,
            'quality_item_id' => $target->quality_item_id, 'event_type' => $target->event_type,
            'from_status' => $target->from_status, 'to_status' => $target->to_status,
            'note' => 'Rewritten history.', 'classification' => $target->classification,
            'actor_user_id' => $target->actor_user_id, 'previous_event_hash' => $target->previous_event_hash];

        DB::table('quality_item_events')->where('id', $target->id)->update([
            'note' => 'Rewritten history.',
            'event_hash' => hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR)),
        ]);

        $result = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        // Linkage is what defeats this: the next record's previous_event_hash
        // still names the hash that existed before the edit.
        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
    }

    public function test_a_replayed_event_forks_the_chain_and_is_caught(): void
    {
        $item = $this->itemWithEvents();

        $second = DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderBy('id')->skip(1)->first();

        // Same previous hash as an existing record: two futures from one past.
        DB::table('quality_item_events')->insert((array) tap(clone $second, function ($row) {
            unset($row->id);
        }));

        $result = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
    }

    // ---- the attack this system does NOT yet survive ------------------------

    public function test_deleting_the_tail_of_a_chain_is_caught_by_the_outside_witness(): void
    {
        // This is the attack a hash chain cannot see on its own. A chain proves
        // the records still present are unaltered and in the order they were
        // written. It proves nothing about records that are no longer there.
        //
        // Delete the last event off a deficiency - the one that closed it - and
        // everything remaining links perfectly and hashes correctly. Before the
        // anchor existed, the verifier reported this chain intact.
        $item = $this->itemWithEvents();

        $before = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);
        $this->assertSame(ChainVerifier::OK, $before['status']);
        $this->assertSame(4, $before['records']);

        DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderByDesc('id')->limit(1)->delete();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertSame(3, $after['records']);
        $this->assertStringContainsString('no longer present', implode(' ', $after['findings']));
    }

    public function test_a_cascade_delete_of_the_whole_chain_is_caught_too(): void
    {
        // Nobody has to intend this one. A cascade on the project takes every
        // event with it, and an empty chain is indistinguishable from a chain
        // that never existed - unless something outside it remembers.
        $item = $this->itemWithEvents();

        DB::table('quality_item_events')->where('quality_item_id', $item->id)->delete();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertStringContainsString('4 record(s) recorded by the anchor', implode(' ', $after['findings']));
    }

    public function test_swapping_a_record_rather_than_removing_one_is_caught_by_the_head(): void
    {
        // Count unchanged, content rewritten, that record's own hash recomputed.
        // The head no longer matches what the anchor witnessed.
        $item = $this->itemWithEvents();
        $last = DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderByDesc('id')->first();

        $payload = ['tenant_id' => $last->tenant_id, 'project_id' => $last->project_id,
            'quality_item_id' => $last->quality_item_id, 'event_type' => $last->event_type,
            'from_status' => $last->from_status, 'to_status' => $last->to_status,
            'note' => 'A different closure.', 'classification' => $last->classification,
            'actor_user_id' => $last->actor_user_id, 'previous_event_hash' => $last->previous_event_hash];

        DB::table('quality_item_events')->where('id', $last->id)->update([
            'note' => 'A different closure.',
            'event_hash' => hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR)),
        ]);

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertStringContainsString('not the head the anchor witnessed', implode(' ', $after['findings']));
    }

    public function test_deleting_the_matching_anchor_too_breaks_the_anchor_chain(): void
    {
        // The obvious counter-attack: delete the event AND the anchor that
        // witnessed it. That works only if the anchor is the very last row in
        // the table. Any anchor written afterwards - for any chain, in any
        // tenant - names the deleted one as its predecessor.
        $first = $this->itemWithEvents();
        $this->itemWithEvents();   // anything at all appends after it

        DB::table('quality_item_events')->where('quality_item_id', $first->id)
            ->orderByDesc('id')->limit(1)->delete();
        DB::table('chain_anchors')->where('chain_group', (string) $first->id)
            ->orderByDesc('record_count')->limit(1)->delete();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $first->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertStringContainsString('anchor chain is itself broken', implode(' ', $after['findings']));
    }

    public function test_the_residual_window_is_exactly_one_row_and_is_not_pretended_away(): void
    {
        // The honest boundary. Delete the newest event in the entire system and
        // the anchor that witnessed it, and nothing is left to notice: no anchor
        // follows it, so the anchor chain still verifies, and the count matches
        // the records that remain.
        //
        // This is a real residual hole. It is one row wide, it closes the moment
        // any other append happens anywhere, and closing it properly would need
        // an anchor for the anchors without end. Asserting it here rather than
        // leaving it undiscussed, because a security claim that is approximately
        // true is worse than none.
        $item = $this->itemWithEvents();

        DB::table('quality_item_events')->where('quality_item_id', $item->id)
            ->orderByDesc('id')->limit(1)->delete();
        DB::table('chain_anchors')->orderByDesc('id')->limit(1)->delete();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::OK, $after['status'],
            'Known and documented: the newest record in the system, deleted together with its anchor, leaves no trace. See ChainAnchor.');
    }

    public function test_the_anchor_chain_reports_its_own_tampering(): void
    {
        $this->itemWithEvents();

        // Rewrite an anchor in the middle rather than removing it.
        $middle = DB::table('chain_anchors')->orderBy('id')->skip(1)->first();
        DB::table('chain_anchors')->where('id', $middle->id)->update(['record_count' => 99]);

        $self = \App\Domain\Provenance\ChainAnchor::verifySelf();

        $this->assertSame('broken', $self['status']);
        $this->assertSame((int) $middle->id, $self['first_invalid_id']);
    }

    public function test_an_anchor_with_no_recognised_digest_algorithm_is_cannot_verify_not_silently_checked_against_sha256(): void
    {
        // EV-13: an anchor row's own algorithm tag governs how it gets
        // re-verified. Falling back to sha256 for a row that does not declare
        // it would be exactly the guess DigestAlgorithm refuses to make.
        $this->itemWithEvents();

        $newest = DB::table('chain_anchors')->orderByDesc('id')->first();
        DB::table('chain_anchors')->where('id', $newest->id)->update(['anchor_hash_algorithm' => null]);

        $self = \App\Domain\Provenance\ChainAnchor::verifySelf();

        $this->assertSame('cannot_verify', $self['status']);
        $this->assertSame((int) $newest->id, $self['first_invalid_id']);
    }

    public function test_altering_the_record_a_chain_describes_is_now_caught(): void
    {
        // The chain seals its events. It never sealed the deficiency those
        // events are about. "Measured 24 inches against a specified 36" could
        // become something softer after the fact, and every hash in the chain
        // would still verify - intact, and describing a document that is not the
        // one it described.
        $item = $this->itemWithEvents();

        $this->assertSame(ChainVerifier::OK,
            ChainVerifier::verify(ChainSpec::all()['quality'], $item->id)['status']);

        TenantContext::set($this->tenant->id);
        QualityItem::query()->whereKey($item->id)->update([
            'description' => 'Minor variance noted at STA 14+20.',
            'severity' => 'low',
        ]);
        TenantContext::clear();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertStringContainsString('altered since the last event', implode(' ', $after['findings']));
    }

    public function test_a_legitimate_status_transition_does_not_look_like_tampering(): void
    {
        // The fingerprint deliberately excludes status. Putting it in would make
        // every honest transition read as alteration of the subject, and a
        // warning that fires on normal work teaches people to ignore it.
        $item = $this->itemWithEvents();

        $this->postJson('/api/quality-items/'.$item->id.'/transition', [
            'to_status' => 'reopened', 'note' => 'Reopened after follow-up inspection.',
            'classification' => 'formal_determination',
        ])->assertOk();

        $this->assertSame(ChainVerifier::OK,
            ChainVerifier::verify(ChainSpec::all()['quality'], $item->id)['status']);
    }

    public function test_deleting_the_subject_is_caught_even_though_the_cascade_takes_the_events_with_it(): void
    {
        // Deleting the deficiency cascades to its events, so the chain does not
        // end up orphaned - it ends up empty. Which is the case that used to be
        // invisible, and is now the loudest thing the verifier says.
        //
        // The subject_missing branch stays as defence for the day a schema
        // change stops cascading and events outlive the record they describe.
        $item = $this->itemWithEvents();

        DB::table('quality_items')->where('id', $item->id)->delete();

        $after = ChainVerifier::verify(ChainSpec::all()['quality'], $item->id);

        $this->assertSame(ChainVerifier::BROKEN, $after['status']);
        $this->assertStringContainsString('no longer present in this chain', implode(' ', $after['findings']));
    }

    private function itemWithEvents(): QualityItem
    {
        $id = $this->postJson('/api/quality-items', [
            'project_id' => $this->project->id, 'kind' => 'deficiency',
            'title' => 'Trench depth short of specification',
            'description' => 'Measured 24 inches against a specified 36 inches at STA 14+20.',
            'classification' => 'fact', 'severity' => 'high',
        ])->assertCreated()->json('item.id');

        foreach ([['in_progress', 'party_assertion', 'Contractor acknowledged.'],
            ['ready_for_verification', 'party_assertion', 'Correction reported complete.'],
            ['closed', 'formal_determination', 'Inspector verified the corrected installation.']] as [$to, $class, $note]) {
            $this->postJson('/api/quality-items/'.$id.'/transition',
                ['to_status' => $to, 'note' => $note, 'classification' => $class])->assertOk();
        }

        TenantContext::set($this->tenant->id);
        $item = QualityItem::findOrFail($id);
        TenantContext::clear();

        return $item;
    }
}
