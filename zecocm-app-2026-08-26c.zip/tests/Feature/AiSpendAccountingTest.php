<?php

namespace Tests\Feature;

use App\Domain\Ai\TokenSpend;
use App\Domain\Licensing\BudgetGate;
use App\Models\AiRun;
use App\Models\CapabilityGrant;
use App\Models\Project;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * D8: the spend cap that was checked against a counter nothing incremented.
 *
 * What is being defended: a control that is relied on has to actually do
 * something, and a total that is incomplete has to say so rather than reading
 * as a total.
 */
class AiSpendAccountingTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-700', 'name' => 'Budget Test', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    // ---- the value object ----------------------------------------------------

    public function test_a_measured_call_prices_out_of_the_configured_table(): void
    {
        // 1,000,000 input at $3/Mtok and 1,000,000 output at $15/Mtok = $18.
        $spend = TokenSpend::of(1_000_000, 1_000_000, 'claude-sonnet-4-5');

        $this->assertSame(18_000_000, $spend->micros(config('zecocm_ai.pricing')));
    }

    public function test_an_unmeasured_call_is_null_not_zero(): void
    {
        // The whole point. Zero says "this cost nothing"; null says "nobody
        // knows what this cost", and only one of those is honest here.
        $this->assertNull(TokenSpend::unmeasured('claude-sonnet-4-5')->micros(config('zecocm_ai.pricing')));
        $this->assertSame(0, TokenSpend::none('claude-sonnet-4-5')->micros(config('zecocm_ai.pricing')));
    }

    public function test_a_response_with_no_usage_block_is_unmeasured_not_free(): void
    {
        // The provider has been paid either way.
        $spend = TokenSpend::fromAnthropic(['content' => [['text' => '{}']]], 'claude-sonnet-4-5');

        $this->assertFalse($spend->measured);
    }

    public function test_a_model_nobody_priced_does_not_become_a_free_model(): void
    {
        $spend = TokenSpend::of(500, 500, 'some-model-added-without-a-price');

        $this->assertNull($spend->micros(config('zecocm_ai.pricing')));
        // But a genuinely empty call is still zero, even unpriced.
        $this->assertSame(0, TokenSpend::of(0, 0, 'some-model-added-without-a-price')->micros(config('zecocm_ai.pricing')));
    }

    // ---- the gate ------------------------------------------------------------

    public function test_a_reservation_is_taken_before_the_run_and_counts_against_the_cap(): void
    {
        $grant = $this->grant(BudgetGate::RESERVATION_MICROS * 2);

        $first = BudgetGate::reserve($grant);
        $this->assertTrue($first['granted']);

        // One reservation left, then nothing.
        $this->assertTrue(BudgetGate::reserve($grant->fresh())['granted']);
        $this->assertFalse(BudgetGate::reserve($grant->fresh())['granted']);
    }

    public function test_a_released_reservation_is_available_again(): void
    {
        $grant = $this->grant(BudgetGate::RESERVATION_MICROS);

        BudgetGate::reserve($grant);
        $this->assertFalse(BudgetGate::reserve($grant->fresh())['granted']);

        BudgetGate::release($grant->fresh());
        $this->assertTrue(BudgetGate::reserve($grant->fresh())['granted']);
    }

    public function test_settling_records_the_actual_cost_and_gives_the_reservation_back(): void
    {
        $grant = $this->grant(100_000_000);
        BudgetGate::reserve($grant);
        $run = $this->makeRun();

        BudgetGate::settle($run, TokenSpend::of(1_000_000, 100_000, 'claude-sonnet-4-5'));

        $grant->refresh();
        $this->assertSame(4_500_000, (int) $grant->budget_used_micros);   // $3.00 + $1.50
        $this->assertSame(0, (int) $grant->budget_reserved_micros);
        $this->assertSame(4_500_000, (int) $run->fresh()->cost_micros);
        $this->assertTrue((bool) $run->fresh()->cost_measured);
    }

    public function test_an_unmeasured_run_makes_the_total_a_lower_bound_rather_than_adding_zero(): void
    {
        $grant = $this->grant(100_000_000);
        BudgetGate::reserve($grant);
        $run = $this->makeRun();

        BudgetGate::settle($run, TokenSpend::unmeasured('claude-sonnet-4-5'));

        $grant->refresh();
        $this->assertSame(0, (int) $grant->budget_used_micros);
        $this->assertSame(1, (int) $grant->unmeasured_run_count);
        $this->assertNull($run->fresh()->cost_micros);
        $this->assertFalse((bool) $run->fresh()->cost_measured);

        $state = BudgetGate::state($grant);
        $this->assertFalse($state['complete']);
        $this->assertStringContainsString('lower bound', $state['message']);
    }

    public function test_a_grant_with_no_limit_is_never_refused(): void
    {
        $grant = $this->grant(null);

        $this->assertSame(BudgetGate::UNLIMITED, BudgetGate::state($grant)['state']);
        $this->assertTrue(BudgetGate::reserve($grant)['granted']);
    }

    public function test_settling_twice_does_not_hand_back_budget_that_was_never_held(): void
    {
        // A retry that settles again must not push the reservation negative and
        // manufacture headroom out of nothing.
        $grant = $this->grant(100_000_000);
        BudgetGate::reserve($grant);
        $run = $this->makeRun();

        BudgetGate::settle($run, TokenSpend::none('claude-sonnet-4-5'));
        BudgetGate::settle($run, TokenSpend::none('claude-sonnet-4-5'));

        $this->assertSame(0, (int) $grant->fresh()->budget_reserved_micros);
    }

    public function test_the_exhausted_state_reports_the_reservations_holding_the_money(): void
    {
        $grant = $this->grant(BudgetGate::RESERVATION_MICROS);
        BudgetGate::reserve($grant);

        $state = BudgetGate::state($grant->fresh());
        $this->assertSame(BudgetGate::EXHAUSTED, $state['state']);
        $this->assertSame(BudgetGate::RESERVATION_MICROS, $state['reserved_micros']);
    }

    private function grant(?int $limitMicros): CapabilityGrant
    {
        return CapabilityGrant::create([
            'tenant_id' => $this->tenant->id,
            'capability_key' => 'ai.assist',
            'status' => 'active',
            'starts_at' => now(),
            'budget_limit_micros' => $limitMicros,
        ]);
    }

    private function makeRun(): AiRun
    {
        return AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'idempotency_key' => (string) Str::uuid(),
            'task_type' => 'answer', 'category' => 'general_administration',
            'question' => 'What does the spec require?', 'status' => 'running',
            'provider' => 'anthropic', 'model' => 'claude-sonnet-4-5',
            'prompt_version' => 'v', 'retrieval_version' => 'v', 'policy_version' => 'v',
            'authorization_scope' => [], 'retrieval_scope' => [],
        ]);
    }
}
