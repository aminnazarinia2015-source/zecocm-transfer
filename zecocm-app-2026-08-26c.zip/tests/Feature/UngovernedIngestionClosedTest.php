<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The second ingestion path is closed.
 *
 * POST /documents chunked uploads into `document_passages` and replied
 * "Ingested - the assistant now answers from this document with citations."
 * Every part of that was false: the retriever reads `knowledge_passages` and has
 * never read `document_passages`. The upload was not retrievable, nothing cited
 * it, and the user was told otherwise.
 *
 * It was ungoverned in every way the product claims to care about - no malware
 * scan, no seal, no edition, no authority level, no verification, no steward. A
 * second path that bypasses every control the first exists to enforce is a hole,
 * not a feature.
 */
class UngovernedIngestionClosedTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_the_ungoverned_ingest_path_refuses_and_explains_where_to_go(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'spec').'.txt';
        file_put_contents($path, str_repeat('Irrigation trench depth shall be 24 in. ', 10));

        $response = $this->post('/api/documents', [
            'project_id' => $this->project->id,
            'file' => new UploadedFile($path, 'spec.txt', 'text/plain', null, true),
        ]);

        $response->assertStatus(410);
        $this->assertStringContainsString('Knowledge Library', $response->json('message'));
    }

    public function test_nothing_is_written_to_the_ungoverned_store(): void
    {
        // The important half. A refusal that still wrote the row would be worse
        // than the original bug, because it would look fixed.
        $before = DB::table('document_passages')->count();

        $this->postJson('/api/documents', [
            'project_id' => $this->project->id,
            'text' => str_repeat('Irrigation trench depth shall be 24 in. ', 10),
        ]);

        $this->assertSame($before, DB::table('document_passages')->count());
    }

    public function test_legacy_rows_are_listed_as_not_retrievable(): void
    {
        DB::table('document_passages')->insert([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'corpus' => 'project_specs', 'source' => 'Old upload §1', 'edition' => null,
            'body' => 'Irrigation trench depth shall be 24 in.',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $rows = $this->getJson('/api/documents?project_id='.$this->project->id)->assertOk()->json();

        $this->assertNotEmpty($rows);
        $this->assertFalse($rows[0]['retrievable']);
        $this->assertStringContainsString('never retrievable', $rows[0]['notice']);
    }
}
