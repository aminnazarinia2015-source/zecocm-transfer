<?php

namespace Tests\Feature;

use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\SourceClass;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * Three classes, not one review queue.
 *
 * The problem this solves is arithmetic. A steward can verify four documents. A
 * steward cannot verify five thousand, so at volume the single provisional queue
 * either goes unread — leaving the library inert — or gets bulk-approved, which
 * manufactures attestations and is worse than no gate at all.
 *
 * Codex's rule, adopted: authority determines admission, use determines review
 * depth. Only material that can CONTROL an answer needs a steward, and that tier
 * is small.
 */
class SourceClassTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_classification_separates_what_requires_a_steward_from_what_does_not(): void
    {
        $this->assertSame(SourceClass::GOVERNING, SourceClass::for('contract', 'project_contract'));
        $this->assertSame(SourceClass::GOVERNING, SourceClass::for('addendum', 'project_contract'));
        $this->assertSame(SourceClass::GOVERNING, SourceClass::for('regulation', 'published_regulation'));
        $this->assertSame(SourceClass::GOVERNING, SourceClass::for('specification', 'project_contract'));

        $this->assertSame(SourceClass::REFERENCE, SourceClass::for('standard', 'historical_pattern'));
        $this->assertSame(SourceClass::REFERENCE, SourceClass::for('policy', 'historical_pattern'));

        $this->assertSame(SourceClass::ASSERTION, SourceClass::for('correspondence', 'party_assertion'));
        $this->assertSame(SourceClass::ASSERTION, SourceClass::for('lesson', 'historical_pattern'));

        // A letter attaching a marked-up drawing is still a letter. Governing TYPE
        // plus a mere party assertion is not governing authority.
        $this->assertSame(SourceClass::ASSERTION, SourceClass::for('drawing', 'party_assertion'));

        $this->assertTrue(SourceClass::requiresSteward(SourceClass::GOVERNING));
        $this->assertFalse(SourceClass::requiresSteward(SourceClass::REFERENCE));
        $this->assertFalse(SourceClass::requiresSteward(SourceClass::ASSERTION));
    }

    public function test_governing_material_stays_invisible_until_a_steward_verifies_it(): void
    {
        // The gate that matters does not move. This is the same guarantee the
        // product has always made about contract documents.
        TenantContext::set($this->tenant->id);
        $this->seedSource('contract', 'project_contract', 'provisional', 'Unreviewed Contract',
            'Irrigation mainline trench depth shall be 24 in below finish grade.');
        TenantContext::clear();

        $this->assertSame([], $this->retrieve('irrigation trench depth'));
    }

    public function test_reference_material_is_usable_immediately_but_can_never_control_an_answer(): void
    {
        // This is what makes five thousand documents workable: nobody has to read
        // them, because none of them can decide what the contract requires.
        TenantContext::set($this->tenant->id);
        $this->seedSource('standard', 'historical_pattern', 'provisional', 'Irrigation Installers Manual',
            'Typical irrigation mainline trench depth is 18 in in residential work.');
        TenantContext::clear();

        $found = $this->retrieve('irrigation trench depth');

        $this->assertCount(1, $found);
        $this->assertSame(SourceClass::REFERENCE, $found[0]->sourceClass);
        $this->assertFalse($found[0]->controlsAnswer,
            'Unstewarded reference material was allowed to control an answer.');
    }

    public function test_a_party_assertion_is_evidence_not_authority(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('correspondence', 'party_assertion', 'provisional', 'Letter from the subcontractor',
            'We installed the irrigation trench depth at 18 in as directed on site.');
        TenantContext::clear();

        $found = $this->retrieve('irrigation trench depth');

        $this->assertCount(1, $found);
        $this->assertSame(SourceClass::ASSERTION, $found[0]->sourceClass);
        $this->assertFalse($found[0]->controlsAnswer);
    }

    public function test_a_manual_never_surfaces_above_the_contract_however_well_its_words_match(): void
    {
        TenantContext::set($this->tenant->id);
        // The manual says "trench depth" three times; the contract says it once.
        $this->seedSource('standard', 'historical_pattern', 'provisional', 'Installers Manual',
            'Trench depth guidance. Trench depth varies. Typical trench depth is 18 in.');
        $this->seedSource('contract', 'project_contract', 'verified', 'Executed Contract A-9764',
            'Mainline trench depth shall be 36 in.');
        TenantContext::clear();

        $found = $this->retrieve('trench depth');

        $this->assertNotEmpty($found);
        $this->assertSame('Executed Contract A-9764', $found[0]->source,
            'Reference material outranked the executed contract.');
        $this->assertTrue($found[0]->controlsAnswer);
        $this->assertFalse($found[1]->controlsAnswer);
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function seedSource(string $type, string $authority, string $status, string $title, string $body): void
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project', 'title' => $title,
            'source_type' => $type, 'jurisdiction' => 'CA', 'discipline' => 'landscape',
            'authority_level' => $authority, 'access_classification' => 'project_private',
            'verification_status' => $status, 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$title, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2026', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['project_specs']], 'storage_path' => 'test/'.$title,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
    }
}
