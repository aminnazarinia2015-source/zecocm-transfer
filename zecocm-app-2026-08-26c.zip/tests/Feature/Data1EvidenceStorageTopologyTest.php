<?php

namespace Tests\Feature;

use App\Domain\Ops\EvidenceRelocation;
use App\Domain\Ops\StorageInventory;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

/**
 * DATA-1: evidence storage must be able to live physically outside the
 * application's own deployment tree - the property that would let evidence
 * bytes survive a redeploy script that wipes the app directory (C3), and
 * that EV-14B's eventual destruction executor needs a truthful answer to
 * before it can reason about "governed storage locations" at all.
 */
class Data1EvidenceStorageTopologyTest extends TestCase
{
    private array $tmpDirs = [];

    protected function tearDown(): void
    {
        foreach ($this->tmpDirs as $dir) {
            $this->rrmdir($dir);
        }
        parent::tearDown();
    }

    private function tmpDir(string $suffix): string
    {
        $dir = sys_get_temp_dir().'/data1-'.$suffix.'-'.bin2hex(random_bytes(6));
        mkdir($dir, 0755, true);
        $this->tmpDirs[] = $dir;

        return $dir;
    }

    private function rrmdir(string $dir): void
    {
        if (! is_dir($dir)) {
            return;
        }
        $items = scandir($dir) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir.'/'.$item;
            is_dir($path) ? $this->rrmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }

    /** Default configuration (no EVIDENCE_STORAGE_ROOT set) is inside the app tree - the honest pre-DATA-1 state. */
    public function test_default_root_is_inside_app_tree(): void
    {
        Config::set('filesystems.disks.local.root', base_path('storage/app/private'));

        $report = StorageInventory::report();

        $this->assertFalse($report['outside_app_tree']);
        $this->assertFalse($report['configured_via_env']);
    }

    /** A root configured outside base_path() is correctly reported as outside the app tree. */
    public function test_configured_root_outside_app_tree_is_detected(): void
    {
        $externalRoot = $this->tmpDir('external-root');
        Config::set('filesystems.disks.local.root', $externalRoot);

        $report = StorageInventory::report();

        $this->assertTrue($report['outside_app_tree']);
    }

    /** isWithin() works lexically even when the candidate root does not yet exist on disk. */
    public function test_is_within_handles_a_root_that_does_not_exist_yet(): void
    {
        $base = base_path();
        $notYetCreated = '/tmp/data1-does-not-exist-'.bin2hex(random_bytes(6));

        $this->assertFalse(StorageInventory::isWithin($notYetCreated, $base));
        $this->assertTrue(StorageInventory::isWithin($base.'/storage/app/private', $base));
    }

    /** A relocation copies every file and preserves its sha256 exactly. */
    public function test_relocation_preserves_content_hash(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        file_put_contents($from.'/a.txt', 'evidence bytes, unchanged');
        mkdir($from.'/nested');
        file_put_contents($from.'/nested/b.txt', 'more evidence bytes');

        $expectedA = hash_file('sha256', $from.'/a.txt');
        $expectedB = hash_file('sha256', $from.'/nested/b.txt');

        $result = EvidenceRelocation::run($from, $to, deleteSourceOnVerify: false);

        $this->assertSame(['a.txt', 'nested/b.txt'], $result['copied']);
        $this->assertSame(['a.txt', 'nested/b.txt'], $result['verified']);
        $this->assertSame([], $result['mismatched']);
        $this->assertSame($expectedA, hash_file('sha256', $to.'/a.txt'));
        $this->assertSame($expectedB, hash_file('sha256', $to.'/nested/b.txt'));
        // Dry run: source files must still exist.
        $this->assertFileExists($from.'/a.txt');
        $this->assertFileExists($from.'/nested/b.txt');
    }

    /** Without --commit (deleteSourceOnVerify: false), the source is never touched, even when verification succeeds. */
    public function test_dry_run_never_deletes_source(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        file_put_contents($from.'/keep.txt', 'do not delete me yet');

        $result = EvidenceRelocation::run($from, $to, deleteSourceOnVerify: false);

        $this->assertSame(['keep.txt'], $result['verified']);
        $this->assertSame([], $result['deleted_source']);
        $this->assertFileExists($from.'/keep.txt');
    }

    /** With --commit, the source is deleted only once its destination copy is hash-verified. */
    public function test_commit_deletes_source_only_after_verification(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        file_put_contents($from.'/relocate.txt', 'moved for real this time');

        $result = EvidenceRelocation::run($from, $to, deleteSourceOnVerify: true);

        $this->assertSame(['relocate.txt'], $result['deleted_source']);
        $this->assertFileDoesNotExist($from.'/relocate.txt');
        $this->assertFileExists($to.'/relocate.txt');
    }

    /**
     * The core safety property: if the destination copy does not verify,
     * the source file is left exactly where it was - never deleted based on
     * an unverified copy, even when --commit was requested.
     */
    public function test_mismatched_destination_is_never_deleted_at_source_even_with_commit(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        mkdir($from.'/blocked');
        file_put_contents($from.'/blocked/fragile.txt', 'original content');

        // Pre-place a plain FILE at the path the relocator needs to create
        // as a directory. mkdir(dirname($dest)) then fails regardless of
        // process privilege (a name collision, not a permission check),
        // so copy() fails and the file is correctly reported as
        // unverified - exercising the real "could not relocate" path
        // rather than one this test process can bypass as root.
        file_put_contents($to.'/blocked', 'not a directory');

        $result = EvidenceRelocation::run($from, $to, deleteSourceOnVerify: true);

        $this->assertContains('blocked/fragile.txt', $result['mismatched']);
        $this->assertSame([], $result['deleted_source']);
        $this->assertFileExists($from.'/blocked/fragile.txt');
    }

    /** A second run over the same --from/--to never re-copies or re-deletes a file already relocated. */
    public function test_second_run_skips_already_relocated_files(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        file_put_contents($from.'/once.txt', 'relocate me once');

        EvidenceRelocation::run($from, $to, deleteSourceOnVerify: true);

        // Simulate a leftover source file reappearing (e.g. a second batch
        // upload landed under the same relative path before the operator
        // re-ran the tool) - the already-relocated destination must never
        // be silently overwritten by a second pass.
        file_put_contents($from.'/once.txt', 'a different, later file');

        $result = EvidenceRelocation::run($from, $to, deleteSourceOnVerify: true);

        $this->assertSame(['once.txt'], $result['skipped_existing']);
        $this->assertSame([], $result['copied']);
        $this->assertSame('relocate me once', file_get_contents($to.'/once.txt'));
    }

    /** The console command wires straight through to EvidenceRelocation and reports a clean dry run. */
    public function test_console_command_dry_run_reports_zero_mismatches(): void
    {
        $from = $this->tmpDir('from');
        $to = $this->tmpDir('to');
        file_put_contents($from.'/x.txt', 'evidence');

        $exitCode = Artisan::call('evidence:relocate-storage', [
            '--from' => $from,
            '--to' => $to,
        ]);

        $this->assertSame(0, $exitCode);
        $this->assertFileExists($from.'/x.txt');
        $this->assertFileExists($to.'/x.txt');
    }

    /** The console command refuses to run without both --from and --to. */
    public function test_console_command_requires_from_and_to(): void
    {
        $exitCode = Artisan::call('evidence:relocate-storage', [
            '--from' => $this->tmpDir('from-only'),
        ]);

        $this->assertSame(1, $exitCode);
    }
}
