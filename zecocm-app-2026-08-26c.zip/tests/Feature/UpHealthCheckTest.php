<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

/**
 * OPS-15: `/up` must verify the dependencies required for a meaningful
 * healthy state, and a failing dependency must make it fail - Codex's exact
 * ruling. Before this row `/up` was Laravel's stock, dependency-free route:
 * it returned 200 whenever PHP-FPM could render a response, whatever state
 * the database was actually in.
 *
 * Also proves the specific defect this row exists because of: `/up` had
 * been returning a live 500 in production for at least four hours
 * (`claude/up-health-endpoint-finding.md`) while every deploy's verification
 * echo printed `http=200`, because the echo probed `/`, not the bare `/up`
 * path. That is an operational discipline this test cannot enforce - it
 * proves what `/up` itself does, not what a deploy script chooses to curl -
 * but it does prove `/up` now tells the truth when asked correctly.
 *
 * OPS-14 later added QueueHeartbeatHealthCheck onto this same route - it
 * fails outright when no heartbeat row has ever been recorded
 * (QUEUE_HEARTBEAT_MISSING). This file's own tests are about the DATABASE
 * probe specifically, so setUp() seeds one healthy heartbeat row to keep
 * that check out of their way; Ops14HealthChecksTest is where the
 * heartbeat's own behavior is actually exercised.
 */
class UpHealthCheckTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-baseline', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(2), 'handled_at' => now()->subSecond(),
        ]);

        // Laravel's stock `/up` route re-throws a `DiagnosingHealth` listener
        // exception when debug mode is on, rather than catching and
        // reporting it - the local/testing posture. Production runs with
        // `APP_DEBUG=false` (C2), which is the code path this row's
        // no-leak guarantee actually depends on, so these tests exercise
        // that path explicitly rather than whatever the test environment's
        // own debug setting happens to be.
        config(['app.debug' => false]);
    }

    public function test_up_is_200_when_the_database_probe_succeeds(): void
    {
        $this->get('/up')->assertOk();
    }

    public function test_up_is_200_with_a_query_string_too(): void
    {
        // The exact regression case from up-health-endpoint-finding.md - an
        // nginx cache keyed on the raw request URI treated this as a
        // different request than the bare path. Nothing in this app should
        // ever distinguish them.
        $this->get('/up?probe=1')->assertOk();
    }

    public function test_up_writes_and_reads_back_exactly_one_heartbeat_row(): void
    {
        $this->get('/up')->assertOk();
        $this->get('/up')->assertOk();
        $this->get('/up')->assertOk();

        $this->assertSame(1, DB::table('health_probes')->count(),
            'Repeated polling must upsert the same row, never accumulate one row per request.');
    }

    public function test_up_fails_when_the_database_write_probe_cannot_succeed(): void
    {
        // Simulates the dependency actually being unhealthy - not merely
        // unreachable, but unable to complete the write/read round trip a
        // real request needs. Dropping the table the probe writes to is the
        // most direct way to make that round trip fail without mocking the
        // connection itself.
        Schema::drop('health_probes');

        $response = $this->get('/up');

        $response->assertStatus(500);
    }

    public function test_up_json_reports_down_without_leaking_the_failure_reason(): void
    {
        Schema::drop('health_probes');

        $response = $this->getJson('/up');

        $response->assertStatus(500);
        $response->assertExactJson(['status' => 'down']);
    }

    public function test_up_json_reports_up_when_healthy(): void
    {
        $response = $this->getJson('/up');

        $response->assertOk();
        $response->assertExactJson(['status' => 'up']);
    }
}
