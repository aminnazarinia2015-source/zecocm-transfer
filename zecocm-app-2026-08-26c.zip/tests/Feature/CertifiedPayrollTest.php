<?php

namespace Tests\Feature;

use App\Domain\Compliance\CertifiedPayrollCheck;
use App\Domain\Compliance\PrevailingWageDetermination;
use PHPUnit\Framework\TestCase;

/**
 * Certified payroll as a condition of payment.
 *
 * On California public works this is not paperwork that follows the money - it
 * gates it. A missing or non-compliant weekly record is grounds for withholding
 * the whole progress payment, not the affected worker's hours. That asymmetry is
 * why it belongs beside the pay application: one missing weekly record can hold
 * up a six-figure payment.
 *
 * These produce WITHHOLD findings in Codex's severity scheme - the application
 * may be perfectly proper, and the money is held for a separate compliance
 * reason. Conflating the two would start the wrong statutory clock.
 */
class CertifiedPayrollTest extends TestCase
{
    public function test_a_wage_rate_must_cite_the_determination_it_came_from(): void
    {
        // Underpaying against somebody's recollection is still underpaying.
        $this->expectException(\InvalidArgumentException::class);

        new PrevailingWageDetermination('Laborer', 'Group 1', 3_500, 1_800, '');
    }

    public function test_the_governing_determination_is_the_one_in_effect_at_award(): void
    {
        // A newer rate appearing mid-job does not retroactively change what is
        // owed, and treating it as though it does is a common and expensive error.
        $determination = new PrevailingWageDetermination(
            'Laborer', 'Group 1', 3_500, 1_800, 'DIR LAB-2026-1',
            effectiveFrom: '2026-01-01', expiresAfter: '2026-06-30',
        );

        $this->assertTrue($determination->governsAwardOn('2026-03-15'));
        $this->assertFalse($determination->governsAwardOn('2025-12-31'));
        $this->assertFalse($determination->governsAwardOn('2026-07-01'));
    }

    public function test_underpayment_is_reported_with_the_total_exposure_not_just_the_hourly_gap(): void
    {
        // "$2.15 short" sounds survivable. "$860 over 400 hours, and it holds the
        // whole payment" is the number that gets someone's attention.
        $determinations = ['Group 1' => new PrevailingWageDetermination(
            'Laborer', 'Group 1', 3_500, 1_800, 'DIR LAB-2026-1',
        )];

        $findings = CertifiedPayrollCheck::findings([
            ['worker' => 'A. Worker', 'classification' => 'Group 1',
                'hours' => 400, 'hourly_paid_cents' => 3_285, 'fringe_paid_cents' => 1_800],
        ], $determinations);

        $this->assertCount(1, $findings);
        $this->assertSame('paid_below_determination', $findings[0]['code']);
        $this->assertSame('withhold', $findings[0]['severity']);
        $this->assertStringContainsString('$860.00 in total', $findings[0]['message']);
        $this->assertStringContainsString('not just the difference', $findings[0]['message']);
        $this->assertSame('DIR LAB-2026-1', $findings[0]['citation']);
    }

    public function test_an_unknown_classification_is_flagged_as_unknown_not_as_underpayment(): void
    {
        // Saying "underpaid" with no rate to compare against would be inventing
        // the finding - the same failure mode as an assumed contract clock.
        $findings = CertifiedPayrollCheck::findings([
            ['worker' => 'B. Worker', 'classification' => 'Operator Group 4',
                'hours' => 40, 'hourly_paid_cents' => 5_000],
        ], []);

        $this->assertSame('no_determination_for_classification', $findings[0]['code']);
        $this->assertStringNotContainsString('underpaid', $findings[0]['message']);
        $this->assertNull($findings[0]['citation']);
    }

    public function test_paying_at_or_above_the_determination_produces_nothing(): void
    {
        $determinations = ['Group 1' => new PrevailingWageDetermination(
            'Laborer', 'Group 1', 3_500, 1_800, 'DIR LAB-2026-1',
        )];

        $this->assertSame([], CertifiedPayrollCheck::findings([
            ['worker' => 'A. Worker', 'classification' => 'Group 1',
                'hours' => 40, 'hourly_paid_cents' => 3_500, 'fringe_paid_cents' => 1_800],
            ['worker' => 'C. Worker', 'classification' => 'Group 1',
                'hours' => 40, 'hourly_paid_cents' => 4_000, 'fringe_paid_cents' => 2_000],
        ], $determinations));
    }

    public function test_fringe_counts_toward_the_obligation(): void
    {
        // Base alone is short; base plus fringe meets it. Checking base only would
        // manufacture a violation that is not there.
        $determinations = ['Group 1' => new PrevailingWageDetermination(
            'Laborer', 'Group 1', 3_500, 1_800, 'DIR LAB-2026-1',
        )];

        $this->assertSame([], CertifiedPayrollCheck::findings([
            ['worker' => 'A. Worker', 'classification' => 'Group 1',
                'hours' => 40, 'hourly_paid_cents' => 3_400, 'fringe_paid_cents' => 1_900],
        ], $determinations));
    }

    public function test_a_missing_weekly_record_holds_payment_but_releases_on_the_records_themselves(): void
    {
        // The commonest cause of a held payment and the least dramatic-looking.
        //
        // The first version of this said the missing record holds the ENTIRE
        // progress payment and left it there. Codex attacked it against
        // 8 CCR s. 16435: withholding may not continue on this basis once the
        // required records are produced, so the release condition is evidence,
        // and the amount belongs to the awarding body rather than to us.
        $findings = CertifiedPayrollCheck::findings([], [], [
            'weeks_without_records' => ['2026-08-09'],
        ]);

        $this->assertSame('missing_weekly_record', $findings[0]['code']);
        $this->assertSame(CertifiedPayrollCheck::ESTIMATE_ONLY, $findings[0]['eligibility']);
        $this->assertSame(CertifiedPayrollCheck::RELEASE_EVIDENCE, $findings[0]['release']);
        $this->assertSame('8 CCR s. 16435', $findings[0]['citation']);

        // And we do not price it.
        $this->assertSame([], CertifiedPayrollCheck::monetary($findings));
    }

    public function test_an_uncovered_classification_never_becomes_an_amount(): void
    {
        // There is no rate to compute against. A number here would be an
        // invented violation, and the awarding body may need a special
        // determination before one exists at all.
        $findings = CertifiedPayrollCheck::findings([
            ['worker' => 'A. Worker', 'classification' => 'Drone Operator',
                'hours' => 40, 'hourly_paid_cents' => 3_000, 'fringe_paid_cents' => 0],
        ], []);

        $this->assertSame('no_determination_for_classification', $findings[0]['code']);
        $this->assertSame(CertifiedPayrollCheck::REQUIRES_DETERMINATION, $findings[0]['eligibility']);
        $this->assertNull($findings[0]['exposure_cents']);
        $this->assertSame([], CertifiedPayrollCheck::monetary($findings));
    }

    public function test_a_mid_project_apprentice_shortfall_is_a_trajectory_and_holds_no_money(): void
    {
        // Measured over the project. Curable until it is not.
        $running = CertifiedPayrollCheck::findings([], [], [
            'apprentice_hours' => 50, 'journeyman_hours' => 1000, 'required_apprentice_ratio' => 0.2,
        ]);
        $this->assertSame(CertifiedPayrollCheck::INFORMATIONAL, $running[0]['eligibility']);
        $this->assertStringContainsString('curable', $running[0]['message']);

        $closed = CertifiedPayrollCheck::findings([], [], [
            'apprentice_hours' => 50, 'journeyman_hours' => 1000, 'required_apprentice_ratio' => 0.2,
            'project_complete' => true,
        ]);
        $this->assertSame(CertifiedPayrollCheck::REQUIRES_DETERMINATION, $closed[0]['eligibility']);

        // Even at closeout the penalty is somebody's determination, not our sum.
        $this->assertSame([], CertifiedPayrollCheck::monetary($closed));
    }

    public function test_an_established_underpayment_replaces_the_provisional_estimate_of_the_same_liability(): void
    {
        // The stacking trap: a missing record creates provisional exposure, the
        // record arrives and establishes a $400 underpayment against the same
        // employer, period and legal basis. Summing them would withhold the same
        // wages twice.
        $findings = CertifiedPayrollCheck::collapseOverlappingExposure([
            ['severity' => 'withhold', 'code' => 'missing_weekly_record', 'message' => '', 'citation' => null,
                'eligibility' => CertifiedPayrollCheck::ESTIMATE_ONLY, 'release' => CertifiedPayrollCheck::RELEASE_EVIDENCE,
                'exposure_key' => 'Northgate|underpayment|Group 1', 'exposure_cents' => null],
            ['severity' => 'withhold', 'code' => 'paid_below_determination', 'message' => '', 'citation' => 'DIR',
                'eligibility' => CertifiedPayrollCheck::COMPUTABLE, 'release' => CertifiedPayrollCheck::RELEASE_DETERMINATION,
                'exposure_key' => 'Northgate|underpayment|Group 1', 'exposure_cents' => 400_00],
        ]);

        $this->assertCount(1, $findings);
        $this->assertSame('paid_below_determination', $findings[0]['code']);
        $this->assertSame(400_00, $findings[0]['exposure_cents']);
    }

    public function test_distinct_liabilities_still_stack(): void
    {
        $findings = CertifiedPayrollCheck::collapseOverlappingExposure([
            ['code' => 'a', 'exposure_key' => 'Northgate|underpayment|Group 1', 'exposure_cents' => 400_00],
            ['code' => 'b', 'exposure_key' => 'Northgate|underpayment|Group 2', 'exposure_cents' => 900_00],
        ]);

        $this->assertCount(2, $findings);
    }

    public function test_an_apprentice_ratio_shortfall_is_reported_during_the_work(): void
    {
        // Checked at closeout is too late to fix; the penalty is already earned.
        $findings = CertifiedPayrollCheck::findings([], [], [
            'apprentice_hours' => 50, 'journeyman_hours' => 1000,
            'required_apprentice_ratio' => 0.2,
            'apprentice_citation' => 'Labor Code s. 1777.5',
        ]);

        $this->assertSame('apprentice_ratio_short', $findings[0]['code']);
        $this->assertStringContainsString('5%', $findings[0]['message']);
        $this->assertSame('Labor Code s. 1777.5', $findings[0]['citation']);
    }

    public function test_a_met_apprentice_ratio_produces_nothing(): void
    {
        $this->assertSame([], CertifiedPayrollCheck::findings([], [], [
            'apprentice_hours' => 250, 'journeyman_hours' => 1000,
            'required_apprentice_ratio' => 0.2,
        ]));
    }
}
