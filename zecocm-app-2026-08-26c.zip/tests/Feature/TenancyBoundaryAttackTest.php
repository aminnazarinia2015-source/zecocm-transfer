<?php

namespace Tests\Feature;

use App\Jobs\RunGovernedAi;
use App\Models\AiRun;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

/**
 * Where a global scope does not reach.
 *
 * The scope fails closed - no tenant in context and every model query becomes
 * `where 1=0`. That is the right default and it covers the Eloquent path
 * completely. It covers nothing else, and the gaps are the interesting part:
 *
 *   Raw queries. DB::table has no scope on it at all. Several exist in this
 *   codebase for hash-chain walking and for joins Eloquent makes clumsy, and
 *   each one was safe only because the ids reaching it had been retrieved under
 *   the scope somewhere upstream. That is safety by accident of other code.
 *
 *   Static and request state in a queue worker. TenantContext is a static, and
 *   the request object in a worker is one long-lived instance shared by every
 *   job. On the sync driver it is the user's own request, still running after
 *   the job returns. Anything a job sets there outlives the job.
 */
class TenancyBoundaryAttackTest extends TestCase
{
    use RefreshDatabase;

    public function test_a_raw_supersession_query_returns_nothing_with_no_tenant_in_context(): void
    {
        // Fail closed, like the scope does. The danger here is specific: this
        // query returns another tenant's DOCUMENT TITLE as "replaced by".
        TenantContext::clear();

        $method = new \ReflectionMethod(\App\Domain\Ai\HybridKnowledgeRetriever::class, 'supersededVersions');
        $method->setAccessible(true);

        $this->assertSame([], $method->invoke(null, [1, 2, 3]));
    }

    public function test_a_governed_run_puts_the_evidence_gate_back_exactly_as_it_found_it(): void
    {
        // The gate that decides whether evidence may be read at all lives on the
        // request, not in TenantContext. In a worker that request outlives the
        // job. If a run leaves it set true, the next thing to run on that worker
        // inherits permission nobody granted it.
        [$tenant, $user, $project] = $this->workspace('Northgate', 'pm@northgate.test', 'P-900');

        TenantContext::set($tenant->id);
        $run = AiRun::create([
            'tenant_id' => $tenant->id, 'project_id' => $project->id, 'requested_by' => $user->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(),
            'idempotency_key' => (string) \Illuminate\Support\Str::uuid(),
            'task_type' => 'rfi_draft', 'provider' => 'none', 'model' => 'none',
            'prompt_version' => 'test', 'retrieval_version' => 'test', 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
            'question' => 'What is the minimum trench depth?', 'category' => 'specification',
            'status' => 'queued', 'progress' => 0,
        ]);
        TenantContext::clear();

        request()->attributes->remove('authorized_evidence_read');
        request()->attributes->remove('authorized_project_id');

        try {
            app(RunGovernedAi::class, ['runId' => $run->id])->handle(
                app(\App\Domain\Ai\AiAssistant::class), app(\App\Domain\Ai\AiRunLedger::class),
            );
        } catch (\Throwable) {
            // The run's own outcome is not what this test is about.
        }

        // Absent before, absent after. Not "false" - absent, because putting it
        // back as false is still leaving a value the caller never set.
        $this->assertFalse(request()->attributes->has('authorized_evidence_read'));
        $this->assertFalse(request()->attributes->has('authorized_project_id'));

        // And the tenant is not left behind either.
        $this->assertNull(TenantContext::tenantId());
    }

    public function test_a_run_does_not_leave_another_tenants_context_behind_it(): void
    {
        [$tenantA, $userA, $projectA] = $this->workspace('Northgate', 'a@northgate.test', 'P-901');
        [$tenantB] = $this->workspace('Elsewhere', 'b@elsewhere.test', 'P-902');

        TenantContext::set($tenantA->id);
        $run = AiRun::create([
            'tenant_id' => $tenantA->id, 'project_id' => $projectA->id, 'requested_by' => $userA->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(),
            'idempotency_key' => (string) \Illuminate\Support\Str::uuid(),
            'task_type' => 'rfi_draft', 'provider' => 'none', 'model' => 'none',
            'prompt_version' => 'test', 'retrieval_version' => 'test', 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
            'question' => 'Anything.', 'category' => 'specification', 'status' => 'queued', 'progress' => 0,
        ]);
        TenantContext::clear();

        // A worker in the middle of tenant B's world picks up tenant A's job.
        TenantContext::set($tenantB->id);

        try {
            app(RunGovernedAi::class, ['runId' => $run->id])->handle(
                app(\App\Domain\Ai\AiAssistant::class), app(\App\Domain\Ai\AiRunLedger::class),
            );
        } catch (\Throwable) {
        }

        $this->assertSame($tenantB->id, TenantContext::tenantId());
    }

    public function test_the_scope_fails_closed_rather_than_open_with_no_tenant(): void
    {
        [$tenant] = $this->workspace('Northgate', 'c@northgate.test', 'P-903');

        TenantContext::clear();

        // Not "returns everything". Returns nothing.
        $this->assertSame(0, Project::query()->count());
        $this->assertGreaterThan(0, DB::table('projects')->count());
    }

    public function test_another_tenants_sealed_evidence_bytes_are_not_downloadable(): void
    {
        // The crown jewels. Codex's invariant is that tenant authorization has
        // to be re-established at every boundary where data changes
        // representation, and database-to-file-storage is one of them: the
        // storage path is derived from content, not from who owns it.
        //
        // This path holds today - the model is scoped and ProjectAccess runs
        // again on the resolved project. The test exists so that a refactor
        // cannot quietly stop doing either.
        [$tenantA, $userA, $projectA] = $this->workspace('Northgate', 'own@northgate.test', 'P-910');
        [$tenantB, $userB] = $this->workspace('Elsewhere', 'intruder@elsewhere.test', 'P-911');

        TenantContext::set($tenantA->id);
        Storage::fake('local');
        Storage::disk('local')->put('knowledge/secret.txt', 'Northgate bid strategy.');
        $source = \App\Models\KnowledgeSource::create([
            'tenant_id' => $tenantA->id, 'project_id' => $projectA->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'project',
            'title' => 'Bid strategy', 'source_type' => 'internal_memo',
            'storage_path' => 'knowledge/secret.txt', 'sha256' => str_repeat('a', 64),
            'malware_scan_status' => 'clean', 'mime_type' => 'text/plain',
        ]);
        TenantContext::clear();

        // The owner can read it.
        \Laravel\Sanctum\Sanctum::actingAs($userA);
        $this->get('/api/knowledge/sources/'.$source->id.'/content')->assertOk();

        // Somebody in another account, holding the id, cannot - and gets 404
        // rather than 403, so the id itself does not confirm the record exists.
        \Laravel\Sanctum\Sanctum::actingAs($userB);
        $this->get('/api/knowledge/sources/'.$source->id.'/content')->assertNotFound();
        $this->getJson('/api/knowledge/sources/'.$source->id)->assertNotFound();
    }

    public function test_a_source_version_can_now_defend_itself_without_its_parent(): void
    {
        // Every other child table in this codebase carries tenant_id and the
        // global scope. knowledge_source_versions did not, so its isolation came
        // entirely from whoever loaded it having gone through the parent first.
        //
        // That held everywhere I looked. But the absence of the column is what
        // forced the supersession query to join through to knowledge_sources
        // purely to reach a tenant - and that join is the one that had no filter
        // on it. The column is the structural fix; this is the proof.
        [$tenantA, , $projectA] = $this->workspace('Northgate', 'v@northgate.test', 'P-920');
        [$tenantB] = $this->workspace('Elsewhere', 'w@elsewhere.test', 'P-921');

        TenantContext::set($tenantA->id);
        $source = \App\Models\KnowledgeSource::create([
            'tenant_id' => $tenantA->id, 'project_id' => $projectA->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'project',
            'title' => 'Spec 32 84 00', 'source_type' => 'specification',
            'storage_path' => 'knowledge/spec.txt', 'sha256' => str_repeat('b', 64),
            'malware_scan_status' => 'clean',
        ]);
        $version = $source->versions()->create([
            'version_number' => 1, 'sha256' => str_repeat('c', 64),
            'extraction_method' => 'text', 'parser_version' => 'test',
        ]);
        TenantContext::clear();

        // The trait filled the tenant in from context, without the caller
        // having to remember.
        $this->assertSame($tenantA->id, $version->tenant_id);

        // Reachable by its owner.
        TenantContext::set($tenantA->id);
        $this->assertNotNull(\App\Models\KnowledgeSourceVersion::find($version->id));

        // Not reachable directly by anyone else - and not by no one either.
        TenantContext::set($tenantB->id);
        $this->assertNull(\App\Models\KnowledgeSourceVersion::find($version->id));

        TenantContext::clear();
        $this->assertNull(\App\Models\KnowledgeSourceVersion::find($version->id));
    }

    /** @return array{0: Tenant, 1: User, 2: Project} */
    private function workspace(string $name, string $email, string $number): array
    {
        $tenant = Tenant::create(['name' => $name, 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'User', 'email' => $email,
            'password' => bcrypt('password')]);
        TenantContext::set($tenant->id);
        $project = Project::create(['number' => $number, 'name' => 'Project '.$number, 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $project->id, 'user_id' => $user->id,
            'organization' => $name, 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();

        return [$tenant, $user, $project];
    }
}
