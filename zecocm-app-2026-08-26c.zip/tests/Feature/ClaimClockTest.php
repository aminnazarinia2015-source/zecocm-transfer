<?php

namespace Tests\Feature;

use App\Domain\Claims\ClaimClock;
use PHPUnit\Framework\TestCase;

/**
 * A3: the clocks that decide whether a valid claim survives.
 *
 * Late notice kills more change orders than bad pricing does. A contractor can
 * be completely right about a differing site condition, price it perfectly, and
 * lose the whole claim because nobody counted ten days.
 *
 * Every test here is really the same test: the system refuses to display a date
 * it cannot establish, because a displayed deadline is trusted and somebody
 * relaxes on the strength of it.
 */
class ClaimClockTest extends TestCase
{
    private function requirement(array $overrides = []): array
    {
        return array_merge([
            'title' => 'Written notice of differing site condition',
            'status' => 'confirmed',
            'authority_type' => 'contract',
            'authority_citation' => 'Contract s. 4.03',
            'consequence_class' => ClaimClock::PRESERVATIVE,
            'period_value' => 10,
            'period_unit' => 'calendar_days',
            'calendar_rule' => 'calendar',
        ], $overrides);
    }

    private function trigger(array $overrides = []): array
    {
        return array_merge([
            'status' => ClaimClock::TRIGGER_CONFIRMED,
            'occurred_on' => '2026-08-25',
        ], $overrides);
    }

    // ---- the four things that must all be established -----------------------

    public function test_an_unconfirmed_requirement_produces_no_clock_at_all(): void
    {
        // There is no default notice period anywhere in this system. An assumed
        // ten days that turns out to be five is worse than no clock.
        $result = ClaimClock::calculate($this->requirement(['status' => 'draft']), $this->trigger());

        $this->assertSame(ClaimClock::UNRESOLVED_AUTHORITY, $result['state']);
        $this->assertNull($result['deadline_on']);
        $this->assertStringContainsString('no default notice period', $result['message']);
    }

    public function test_working_days_with_no_confirmed_calendar_refuses_to_guess_monday_to_friday(): void
    {
        // Which days count and which holidays apply is a contract question, not
        // a convention, and assuming it invents a deadline.
        $result = ClaimClock::calculate(
            $this->requirement(['calendar_rule' => 'working', 'period_unit' => 'working_days']),
            $this->trigger(),
            ['confirmed' => false],
        );

        $this->assertSame(ClaimClock::UNRESOLVED_CALENDAR, $result['state']);
        $this->assertStringContainsString('will not quietly assume Monday to Friday', $result['message']);
    }

    public function test_the_calendar_is_checked_before_the_trigger_so_the_right_thing_gets_fixed(): void
    {
        // A working-day rule with no calendar cannot produce a date even from a
        // perfect trigger. Reporting the trigger would send somebody to fix the
        // wrong thing.
        $result = ClaimClock::calculate(
            $this->requirement(['calendar_rule' => 'working']),
            null,
            ['confirmed' => false],
        );

        $this->assertSame(ClaimClock::UNRESOLVED_CALENDAR, $result['state']);
    }

    public function test_no_trigger_means_nothing_to_count_from(): void
    {
        $result = ClaimClock::calculate($this->requirement(), null);

        $this->assertSame(ClaimClock::UNRESOLVED_TRIGGER, $result['state']);
        $this->assertNull($result['deadline_on']);
    }

    public function test_a_confirmed_trigger_and_a_confirmed_requirement_produce_a_date(): void
    {
        $result = ClaimClock::calculate($this->requirement(), $this->trigger());

        $this->assertSame(ClaimClock::ESTABLISHED, $result['state']);
        $this->assertSame('2026-09-04', $result['deadline_on']);
        $this->assertStringContainsString('If the triggering date is', $result['message']);
        $this->assertStringContainsString('may impair or bar the right', $result['message']);
    }

    public function test_working_days_are_counted_against_a_confirmed_calendar(): void
    {
        // 25 Aug 2026 is a Tuesday. Ten working days, weekends off, lands on
        // Tuesday 8 September.
        $result = ClaimClock::calculate(
            $this->requirement(['calendar_rule' => 'working']),
            $this->trigger(),
            ['confirmed' => true, 'holidays' => [], 'saturday_working' => false],
        );

        $this->assertSame(ClaimClock::ESTABLISHED, $result['state']);
        $this->assertSame('2026-09-08', $result['deadline_on']);
    }

    public function test_a_recorded_holiday_pushes_the_deadline_out(): void
    {
        $result = ClaimClock::calculate(
            $this->requirement(['calendar_rule' => 'working']),
            $this->trigger(),
            ['confirmed' => true, 'holidays' => ['2026-09-07'], 'saturday_working' => false],
        );

        $this->assertSame('2026-09-09', $result['deadline_on']);
    }

    // ---- the disputed trigger, which is the case that actually happens ------

    public function test_a_disputed_trigger_produces_a_range_rather_than_a_confident_wrong_date(): void
    {
        // More useful to somebody deciding what to do this week than either
        // inventing precision or saying nothing.
        $result = ClaimClock::calculate($this->requirement(), $this->trigger([
            'status' => ClaimClock::TRIGGER_DISPUTED,
            'occurred_on' => null,
            'earliest_plausible_on' => '2026-08-20',
            'latest_plausible_on' => '2026-08-27',
        ]));

        $this->assertSame(ClaimClock::UNRESOLVED_TRIGGER, $result['state']);
        $this->assertNull($result['deadline_on']);
        $this->assertSame('2026-08-30', $result['earliest_on']);
        $this->assertSame('2026-09-06', $result['latest_on']);
        $this->assertStringContainsString('conservative course', $result['message']);
    }

    public function test_a_disputed_preservative_deadline_still_raises_an_alert(): void
    {
        // Silence is the failure mode. A clock nobody looked at is worse than
        // no clock, because it looks like coverage.
        $result = ClaimClock::calculate($this->requirement(), $this->trigger([
            'status' => ClaimClock::TRIGGER_DISPUTED, 'occurred_on' => null,
            'earliest_plausible_on' => '2026-08-20', 'latest_plausible_on' => '2026-08-27',
        ]));

        $this->assertTrue($result['may_alert']);
    }

    public function test_a_disputed_trigger_with_no_range_establishes_nothing(): void
    {
        $result = ClaimClock::calculate($this->requirement(), $this->trigger([
            'status' => ClaimClock::TRIGGER_DISPUTED, 'occurred_on' => null,
        ]));

        $this->assertSame(ClaimClock::UNRESOLVED_TRIGGER, $result['state']);
        $this->assertNull($result['earliest_on']);
    }

    // ---- the refusal that matters most --------------------------------------

    public function test_a_passed_preservative_deadline_never_says_the_claim_is_waived(): void
    {
        // Whether a right survives turns on facts and law this software does
        // not hold: actual notice, waiver by conduct, equitable tolling, an
        // owner who knew anyway.
        $message = ClaimClock::afterDeadline(
            $this->requirement(),
            ['deadline_on' => '2026-09-04'],
            hasQualifyingCompliance: false,
        );

        $this->assertStringContainsString('POTENTIAL LOSS OF RIGHTS REQUIRES REVIEW', $message);
        $this->assertStringNotContainsString('waived', $message);
        // The word "barred" appears exactly once and only inside the disclaimer.
        // Asserting its absence would be the wrong test - what matters is that
        // the system never CLAIMS a bar, and it says so explicitly.
        $this->assertSame(1, substr_count(strtolower($message), 'barred'));
        $this->assertStringContainsString('is not determining that any claim is barred', $message);
    }

    public function test_a_passed_administrative_deadline_does_not_borrow_preservative_language(): void
    {
        // A contract saying "shall" does not make a step preservative, and
        // panicking somebody over paperwork trains them to ignore the one
        // deadline that matters.
        $message = ClaimClock::afterDeadline(
            $this->requirement(['consequence_class' => ClaimClock::ADMINISTRATIVE]),
            ['deadline_on' => '2026-09-04'],
            hasQualifyingCompliance: false,
        );

        $this->assertStringContainsString('no loss of rights follows', $message);
        $this->assertStringNotContainsString('POTENTIAL LOSS OF RIGHTS', $message);
    }

    public function test_a_recorded_compliance_event_ends_the_matter_for_the_record(): void
    {
        $message = ClaimClock::afterDeadline($this->requirement(), ['deadline_on' => '2026-09-04'], true);

        $this->assertStringContainsString('qualifying compliance event is recorded', $message);
    }

    // ---- the graph ----------------------------------------------------------

    public function test_a_later_stage_has_no_clock_until_the_earlier_one_closes(): void
    {
        // Six unrelated red countdowns tell somebody nothing. "You preserved
        // stage one and stage two has not opened" tells them what to do today.
        $state = ClaimClock::gateState([
            ['depends_on_title' => 'Initial written notice', 'dependency_type' => 'completion', 'satisfied' => true],
            ['depends_on_title' => 'Owner response to claim', 'dependency_type' => 'denial', 'satisfied' => false],
        ]);

        $this->assertFalse($state['open']);
        $this->assertStringContainsString('Owner response to claim', $state['reason']);
        $this->assertStringContainsString('a recorded denial', $state['reason']);
        $this->assertStringContainsString('inventing a deadline', $state['reason']);
    }

    public function test_a_stage_with_every_dependency_met_is_open(): void
    {
        $this->assertTrue(ClaimClock::gateState([
            ['depends_on_title' => 'Initial written notice', 'dependency_type' => 'completion', 'satisfied' => true],
        ])['open']);
    }

    public function test_a_requirement_with_no_dependencies_is_open(): void
    {
        $this->assertTrue(ClaimClock::gateState([])['open']);
    }

    public function test_the_citation_travels_with_every_answer(): void
    {
        // A deadline without its authority is a number somebody made up.
        foreach ([null, $this->trigger(), $this->trigger(['status' => ClaimClock::TRIGGER_UNRESOLVED])] as $trigger) {
            $result = ClaimClock::calculate($this->requirement(), $trigger);
            $this->assertSame('Contract s. 4.03', $result['citation']);
        }
    }
}
