<?php

namespace Tests\Feature;

use App\Domain\Clocks\DeadlineExpression;
use App\Domain\Clocks\NoticeClock;
use DateTimeImmutable;
use Tests\TestCase;

/**
 * The clock that decides whether a valid claim survives.
 *
 * A contractor can be completely right about a differing site condition, price it
 * perfectly, and lose the whole claim because the changes clause required written
 * notice within ten days of discovery and nobody counted. The money is not lost in
 * negotiation; it is lost quietly, weeks earlier, while everyone is building.
 */
class NoticeClockTest extends TestCase
{
    public function test_a_notice_period_without_a_cited_clause_is_refused(): void
    {
        // An assumed ten days that turns out to be five is worse than no clock at
        // all, because a wrong deadline is trusted exactly as much as a real one.
        $this->expectException(\InvalidArgumentException::class);

        new NoticeClock(new DeadlineExpression(10, DeadlineExpression::BASIS_CALENDAR), '');
    }

    public function test_no_clock_is_invented_when_the_contract_recorded_none(): void
    {
        $this->assertNull(NoticeClock::fromContractClock(null));
        $this->assertNull(NoticeClock::fromContractClock([]));
        $this->assertNull(NoticeClock::fromContractClock(['days' => 10]));            // no source
        $this->assertNull(NoticeClock::fromContractClock(['days' => 0, 'source' => 'GC 6.3']));
        $this->assertNull(NoticeClock::fromContractClock(['days' => 10, 'source' => '  ']));
    }

    public function test_calendar_days_run_through_the_weekend(): void
    {
        $clock = new NoticeClock(
            new DeadlineExpression(10, DeadlineExpression::BASIS_CALENDAR),
            'General Conditions 6.3.2',
        );

        // Identified Thursday 6 Aug 2026; ten calendar days lands on Sunday 16th.
        $due = $clock->dueFrom(new DateTimeImmutable('2026-08-06'));

        $this->assertSame('2026-08-16', $due->format('Y-m-d'));
    }

    public function test_working_days_skip_weekends_and_holidays(): void
    {
        $clock = new NoticeClock(
            new DeadlineExpression(5, DeadlineExpression::BASIS_WORKING, ['2026-08-10']),
            'Special Provisions 5-1.16',
        );

        // From Thursday 6 Aug: Fri 7, [Sat/Sun], Mon 10 is a holiday, Tue 11,
        // Wed 12, Thu 13, Fri 14.
        $due = $clock->dueFrom(new DateTimeImmutable('2026-08-06'));

        $this->assertSame('2026-08-14', $due->format('Y-m-d'));
    }

    public function test_a_preservative_clock_says_plainly_that_late_notice_bars_the_claim(): void
    {
        $clock = new NoticeClock(
            new DeadlineExpression(10, DeadlineExpression::BASIS_CALENDAR),
            'General Conditions 6.3.2',
            NoticeClock::EFFECT_PRESERVATIVE,
            'Written notice with supporting records',
        );

        $status = $clock->status(new DateTimeImmutable('2026-08-06'), new DateTimeImmutable('2026-08-20'));

        $this->assertSame('missed', $status['state']);
        $this->assertTrue($status['bars_claim']);
        $this->assertStringContainsString('bars the claim', $status['message']);
        $this->assertStringContainsString('General Conditions 6.3.2', $status['message']);
        // It must not read as though the deadline is still workable.
        $this->assertStringNotContainsString('is due in', $status['message']);
    }

    public function test_an_administrative_clock_does_not_tell_someone_they_lost_their_claim(): void
    {
        // The other half of the danger. Crying forfeiture over paperwork trains
        // people to ignore the warning that actually matters.
        $clock = new NoticeClock(
            new DeadlineExpression(10, DeadlineExpression::BASIS_CALENDAR),
            'General Conditions 4.1',
            NoticeClock::EFFECT_ADMINISTRATIVE,
        );

        $status = $clock->status(new DateTimeImmutable('2026-08-06'), new DateTimeImmutable('2026-08-20'));

        $this->assertSame('missed', $status['state']);
        $this->assertFalse($status['bars_claim']);
        $this->assertStringContainsString('not a forfeiture', $status['message']);
        $this->assertStringNotContainsString('bars the claim', $status['message']);
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('urgencyBands')]
    public function test_the_urgency_band_matches_the_time_left(string $now, string $expected): void
    {
        $clock = new NoticeClock(
            new DeadlineExpression(10, DeadlineExpression::BASIS_CALENDAR),
            'General Conditions 6.3.2',
        );

        $status = $clock->status(new DateTimeImmutable('2026-08-06'), new DateTimeImmutable($now));

        $this->assertSame($expected, $status['state'], "on {$now}");
    }

    public static function urgencyBands(): array
    {
        // Due 2026-08-16.
        return [
            'ten days out' => ['2026-08-06', 'open'],
            'four days out' => ['2026-08-12', 'open'],
            'three days out' => ['2026-08-13', 'urgent'],
            'tomorrow' => ['2026-08-15', 'critical'],
            'today' => ['2026-08-16', 'critical'],
            'a day late' => ['2026-08-17', 'missed'],
        ];
    }

    public function test_the_clause_and_requirement_travel_with_the_status(): void
    {
        // A superintendent asked to give notice needs to know WHAT the clause
        // requires, not just that something is due.
        $clock = NoticeClock::fromContractClock([
            'days' => 10,
            'basis' => 'calendar',
            'source' => 'General Conditions 6.3.2',
            'requirement' => 'Written notice to the Engineer with records of the condition',
        ]);

        $this->assertNotNull($clock);
        $status = $clock->status(new DateTimeImmutable('2026-08-06'), new DateTimeImmutable('2026-08-07'));

        $this->assertSame('General Conditions 6.3.2', $status['clause']);
        $this->assertStringContainsString('records of the condition', $status['requirement']);
        $this->assertTrue($status['bars_claim'], 'Preservative is the safe default when the contract does not say.');
    }
}
