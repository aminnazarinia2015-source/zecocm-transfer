<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * SEC-3, continued again. Codex's third pass asked for exactly this: "the
 * remaining authorize()-calling controllers, preferably via a capability
 * matrix so coverage doesn't depend on remembering individual routes."
 *
 * The two prior slices (RbacNegativeTest, RbacIndirectPathTest) directly
 * attacked 6 of 18 authorize()-calling controllers plus one job. This slice
 * takes the remaining 13: AiRunController, AssistController, BriefController,
 * ClaimClockController, DailyReportController, DecisionController,
 * IntelligenceController, PaymentSecurityController, QualityController,
 * RfiController, ScheduleController, SubmittalController, TransmittalController.
 *
 * AssistController is investigated rather than tested directly: its own
 * ProjectAccess::authorize() call for 'assistant.use' is unreachable dead
 * code - the paid-assistance branch returns app(AiRunController::class)
 * ->store($request) before that line ever runs. The capability check that
 * actually gates paid assistance is AiRunController::store's, already
 * covered below - so AssistController is not a bypass, just a redundant
 * line, and is recorded here rather than silently presented as attacked.
 *
 * DecisionController and TransmittalController get the deeper treatment
 * Codex specifically asked for on "governed determinations" and "exports/
 * packages": read/write separation (the envelope's own read capability
 * does not grant the authorising write capability) and the possession
 * invariant (a record ID from a different project is not reachable even
 * for an actor who holds the right capability on their own project).
 */
class RbacCapabilityMatrixTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config(['queue.default' => 'sync']);
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => [
                'submittal_review' => ['days' => 14, 'basis' => 'working'],
                'rfi_response' => ['days' => 10, 'basis' => 'working'],
            ]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        (new CapabilityLicense)->grant($this->tenant, 'schedule_intelligence');
        (new CapabilityLicense)->grant($this->tenant, 'documents.transmittal');
        (new CapabilityLicense)->grant($this->tenant, 'daily_brief');
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function memberWith(array $capabilities, ?Project $project = null): User
    {
        static $n = 0;
        $n++;
        $project ??= $this->project;
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => "Member {$n}",
            'email' => "member{$n}@northgate.test", 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        Membership::create(['project_id' => $project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'field', 'capabilities' => $capabilities]);
        TenantContext::clear();

        return $user;
    }

    private function realCsv(string $name = 'schedule.csv'): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'sched');
        file_put_contents($path, "activity_id,description,start,finish\nA100,Mobilize,2026-01-01,2026-01-05\n");

        return new UploadedFile($path, $name, 'text/csv', null, true);
    }

    // ---- capability matrix: a member with NO capabilities is refused on the primary write/read
    // endpoint of every one of the 13 remaining authorize()-calling controllers ----

    public function test_capability_less_member_is_refused_across_the_remaining_authorize_calling_controllers(): void
    {
        $bystander = $this->memberWith([]);
        Sanctum::actingAs($bystander);

        $cases = [
            'RfiController::store' => fn () => $this->postJson('/api/rfis', [
                'project_id' => $this->project->id, 'subject' => 'Detail clarification', 'question' => 'Which detail governs?',
            ]),
            'DailyReportController::store' => fn () => $this->postJson('/api/daily-reports', [
                'project_id' => $this->project->id, 'report_date' => now()->toDateString(), 'work_performed' => 'Grading',
            ]),
            'ClaimClockController::storeRequirement' => fn () => $this->postJson('/api/claim-clocks/requirements', [
                'project_id' => $this->project->id, 'requirement_type' => 'notice', 'title' => 'Preliminary notice',
                'authority_type' => 'statute', 'authority_citation' => 'Civ. Code 9300', 'consequence_class' => 'preservative',
                'trigger_type' => 'first_furnish',
            ]),
            'PaymentSecurityController::storeRelease' => fn () => $this->postJson('/api/payment-security/releases', [
                'project_id' => $this->project->id, 'claimant_name' => 'Acme Grading', 'form_type' => 'conditional_progress',
            ]),
            'QualityController::store' => fn () => $this->postJson('/api/quality-items', [
                'project_id' => $this->project->id, 'kind' => 'observation', 'title' => 'Rebar spacing',
                'description' => 'Spacing appears wide in bay 3.', 'classification' => 'party_assertion', 'severity' => 'normal',
            ]),
            'SubmittalController::store' => fn () => $this->postJson('/api/submittals', [
                'project_id' => $this->project->id, 'number' => 'SUB-0100', 'spec_section' => '03 30 00',
                'title' => 'Concrete mix design', 'type' => 'product_data', 'submitted_by_org' => 'Acme Concrete',
            ]),
            'IntelligenceController::ingest' => fn () => $this->postJson('/api/documents', [
                'project_id' => $this->project->id, 'text' => 'Irrigation trench depth shall be 24 in.',
            ]),
            'AiRunController::store' => fn () => $this->postJson('/api/ai-runs', [
                'project_id' => $this->project->id, 'question' => 'What is the minimum trench depth?',
            ]),
            'ScheduleController::store' => fn () => $this->postJson('/api/schedule-versions', [
                'project_id' => $this->project->id, 'file' => $this->realCsv(), 'kind' => 'baseline',
                'label' => 'Baseline v1', 'data_date' => now()->toDateString(),
            ]),
            'BriefController::show' => fn () => $this->getJson("/api/projects/{$this->project->id}/brief"),
        ];

        foreach ($cases as $label => $call) {
            $response = $call();
            $this->assertSame(403, $response->getStatusCode(),
                "{$label}: expected a capability-less member to be refused (403), got {$response->getStatusCode()}. Body: {$response->getContent()}");
        }
    }

    // ---- DecisionController::authorize: read/write separation on a governed determination ----

    public function test_decision_authorize_refuses_a_member_who_only_holds_the_read_capability(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'SUB-0101', 'spec_section' => '03 30 00', 'title' => 'Concrete mix design',
            'type' => 'product_data', 'submitted_by_org' => 'Acme Concrete', 'ball_in_court' => 'architect',
            'status' => 'submitted', 'routing_history' => []]);
        TenantContext::clear();

        // records.view is the capability the envelope's own read side (show/preview) accepts -
        // it must not also unlock authorize(), which requires submittal.stamp specifically.
        $reader = $this->memberWith(['records.view' => true]);
        Sanctum::actingAs($reader);

        $response = $this->postJson("/api/decisions/submittal/{$submittal->id}/authorize", [
            'confirm' => true, 'disposition' => 'no_exceptions',
        ]);

        $response->assertStatus(403);
    }

    public function test_decision_authorize_succeeds_for_a_member_who_actually_holds_the_stamp_capability(): void
    {
        // The other half: the refusal above is the missing capability, not a broken route.
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'SUB-0102', 'spec_section' => '03 30 00', 'title' => 'Concrete mix design',
            'type' => 'product_data', 'submitted_by_org' => 'Acme Concrete', 'ball_in_court' => 'architect',
            'status' => 'submitted', 'submitted_at' => now()->toDateString(), 'routing_history' => []]);
        TenantContext::clear();

        $stamper = $this->memberWith(['records.view' => true, 'submittal.stamp' => true]);
        Sanctum::actingAs($stamper);

        $response = $this->postJson("/api/decisions/submittal/{$submittal->id}/authorize", [
            'confirm' => true, 'disposition' => 'no_exceptions',
        ]);

        $response->assertStatus(200);
    }

    // ---- possession is not authorization: a decision/transmittal record ID from a
    // different project is not reachable through this project's grant ----

    public function test_decision_authorize_is_not_reachable_for_a_submittal_from_a_different_project(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['tenant_id' => $this->tenant->id, 'number' => 'P-411', 'name' => 'Other',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $foreignSubmittal = Submittal::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'number' => 'SUB-0200', 'spec_section' => '03 30 00', 'title' => 'Other project submittal',
            'type' => 'product_data', 'submitted_by_org' => 'Acme Concrete', 'ball_in_court' => 'architect',
            'status' => 'submitted', 'routing_history' => []]);
        TenantContext::clear();

        // Holds submittal.stamp on THIS project only - a membership row per project.
        $stamper = $this->memberWith(['records.view' => true, 'submittal.stamp' => true]);
        Sanctum::actingAs($stamper);

        $response = $this->postJson("/api/decisions/submittal/{$foreignSubmittal->id}/authorize", [
            'confirm' => true, 'disposition' => 'no_exceptions',
        ]);

        $response->assertStatus(403);
    }

    public function test_transmittal_issue_refuses_a_member_without_records_issue(): void
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'RFI-0100', 'subject' => 'Detail clarification', 'question' => 'Which detail governs?',
            'raised_by_org' => 'Acme Concrete', 'raised_at' => now()->toDateString(), 'ball_in_court' => 'architect',
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        // Holds records.view (the preview capability) but not records.issue.
        $reader = $this->memberWith(['records.view' => true]);
        Sanctum::actingAs($reader);

        $response = $this->postJson("/api/transmittals/rfi/{$rfi->id}/issue", ['confirm' => 'confirm']);

        $response->assertStatus(403);
    }

    public function test_transmittal_issue_is_not_reachable_for_an_rfi_from_a_different_project(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['tenant_id' => $this->tenant->id, 'number' => 'P-412', 'name' => 'Other',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $foreignRfi = Rfi::create(['tenant_id' => $this->tenant->id, 'project_id' => $otherProject->id,
            'number' => 'RFI-0200', 'subject' => 'Other project RFI', 'question' => 'n/a',
            'raised_by_org' => 'Acme Concrete', 'raised_at' => now()->toDateString(), 'ball_in_court' => 'architect',
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        // Holds records.issue on THIS project only.
        $issuer = $this->memberWith(['records.view' => true, 'records.issue' => true]);
        Sanctum::actingAs($issuer);

        $response = $this->postJson("/api/transmittals/rfi/{$foreignRfi->id}/issue", ['confirm' => 'confirm']);

        $response->assertStatus(403);
    }

    // ---- structural: AssistController's own authorize() call is unreachable, recorded rather
    // than silently presented as a gap or as attacked ----

    public function test_assist_controllers_paid_tier_delegates_to_the_ai_run_controllers_own_authorization(): void
    {
        $source = file_get_contents(app_path('Http/Controllers/AssistController.php'));
        $this->assertStringContainsString('app(AiRunController::class)->store($request)', $source,
            'AssistController is expected to delegate paid project assistance to AiRunController::store, '.
            'whose authorize() call is the one actually reachable and tested (see RbacCapabilityMatrixTest '.
            'and RbacNegativeTest / RbacIndirectPathTest coverage of ai-runs).');
    }

    // ---- Codex's last closure criterion: no system/admin/support implicit superuser path
    // without an explicit audited capability. Platform staff get a fixed, centrally-defined
    // capability set in ProjectAccess::authorize() itself - never a project Membership row,
    // and never an unrestricted bypass - so this is the gateway's own audited grant, tested
    // under a real request rather than assumed correct because the source reads that way. ----

    public function test_a_platform_technician_is_refused_every_write_even_while_browsing_a_tenant(): void
    {
        $technician = User::create(['tenant_id' => null, 'name' => 'Platform Tech', 'platform_role' => 'technician',
            'email' => 'tech@zecocm.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($technician);

        $response = $this->withHeader('X-Browse-Tenant', (string) $this->tenant->id)
            ->postJson('/api/daily-reports', [
                'project_id' => $this->project->id, 'report_date' => now()->toDateString(), 'work_performed' => 'Grading',
            ]);

        // Two independent layers both refuse this, deliberately: the controller's own
        // TenantContext::writesBlocked() check, and ProjectAccess::authorize()'s
        // abort_if($write && ! isSupportMode()) - a technician is read-only, not merely
        // missing one project capability.
        $response->assertStatus(403);
    }

    public function test_a_platform_technician_can_still_read_while_browsing_a_tenant(): void
    {
        // The contrast that proves the write refusal above is the audited read/write
        // split, not a broken fixture or a technician account that can do nothing at all.
        $technician = User::create(['tenant_id' => null, 'name' => 'Platform Tech', 'platform_role' => 'technician',
            'email' => 'tech2@zecocm.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($technician);

        $response = $this->withHeader('X-Browse-Tenant', (string) $this->tenant->id)
            ->getJson("/api/projects/{$this->project->id}/brief");

        $response->assertStatus(200);
    }

    public function test_a_platform_technician_without_the_browse_header_reaches_no_tenant_data(): void
    {
        // No X-Browse-Tenant header at all: EstablishTenantContext leaves staff with no
        // tenant context whatsoever - queries fail closed rather than resolving to "no
        // tenant filter" (which would be a much worse bug: every tenant's rows at once).
        $technician = User::create(['tenant_id' => null, 'name' => 'Platform Tech', 'platform_role' => 'technician',
            'email' => 'tech3@zecocm.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($technician);

        $response = $this->getJson("/api/projects/{$this->project->id}/brief");

        $this->assertContains($response->getStatusCode(), [403, 404, 422],
            'A platform technician with no browse header reached project data: '.$response->getContent());
    }
}
