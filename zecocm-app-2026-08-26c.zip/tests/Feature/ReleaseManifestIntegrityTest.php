<?php

namespace Tests\Feature;

use App\Domain\Release\JunitTestManifest;
use App\Domain\Release\ReleaseManifestBuilder;
use App\Domain\Release\TarballContentVerifier;
use App\Models\ReleaseDeployment;
use App\Models\ReleaseManifest;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * REL-1: this codebase's own near-miss is the spec. From
 * `claude/closure-progress.md`'s "A near-miss worth recording": a test file
 * was silently overwritten while building TR-17, nine tests vanished, and
 * the suite still reported PASSED - only the hand arithmetic "490 + 15
 * should be 505, the run said 496" caught it. Every test below proves REL-1
 * would have caught that automatically, and would catch the shapes Codex
 * named it must also catch: a tarball whose bytes drifted from what was
 * tested, and a required invariant suite quietly absent from a release.
 */
class ReleaseManifestIntegrityTest extends TestCase
{
    use RefreshDatabase;

    public function test_junit_xml_is_parsed_into_stable_test_ids_and_totals(): void
    {
        $path = sys_get_temp_dir().'/rel1-junit-'.bin2hex(random_bytes(4)).'.xml';
        file_put_contents($path, <<<'XML'
            <?xml version="1.0" encoding="UTF-8"?>
            <testsuites tests="3" assertions="4">
              <testsuite name="Tests\Feature\FooTest">
                <testcase class="Tests\Feature\FooTest" name="test_a" assertions="2"/>
                <testcase class="Tests\Feature\FooTest" name="test_b with data set #0" assertions="1"/>
                <testcase class="Tests\Feature\FooTest" name="test_b with data set #1" assertions="1"/>
              </testsuite>
            </testsuites>
            XML);

        $manifest = JunitTestManifest::fromXmlFile($path);

        $this->assertSame(
            ['Tests\Feature\FooTest::test_a', 'Tests\Feature\FooTest::test_b'],
            $manifest->testIds(),
        );
        $this->assertSame(3, $manifest->totalTests());
        $this->assertSame(4, $manifest->totalAssertions());
        $this->assertTrue($manifest->classIsPresent('Tests\Feature\FooTest'));
        $this->assertFalse($manifest->classIsPresent('Tests\Feature\NoSuchTest'));

        unlink($path);
    }

    public function test_total_tests_counts_every_data_provider_case_even_though_ids_are_deduplicated_by_method(): void
    {
        // A real bug this test would have caught: PHPUnit's root
        // <testsuites> element carries no "tests" attribute of its own -
        // only the nested per-file <testsuite> elements do - so a naive
        // read of the root attributes silently falls through to
        // count(unique ids), UNDERCOUNTING whenever a data provider is in
        // play (one method, N testcases, 1 unique id). Caught by dogfooding
        // REL-1 against this repo's own real junit output (761 vs the true
        // 789) before this fix.
        $path = sys_get_temp_dir().'/rel1-junit-'.bin2hex(random_bytes(4)).'.xml';
        file_put_contents($path, <<<'XML'
            <?xml version="1.0" encoding="UTF-8"?>
            <testsuites>
              <testsuite name="phpunit.xml" tests="3" assertions="5">
                <testcase class="Tests\Unit\FooTest" name="test_a" assertions="1"/>
                <testcase class="Tests\Unit\FooTest" name="test_b with data set #0" assertions="2"/>
                <testcase class="Tests\Unit\FooTest" name="test_b with data set #1" assertions="2"/>
              </testsuite>
            </testsuites>
            XML);

        $manifest = JunitTestManifest::fromXmlFile($path);

        $this->assertSame(3, $manifest->totalTests(), 'must count every testcase, not every unique id');
        $this->assertSame(['Tests\Unit\FooTest::test_a', 'Tests\Unit\FooTest::test_b'], $manifest->testIds());
        $this->assertSame(5, $manifest->totalAssertions());

        unlink($path);
    }

    public function test_a_protected_regression_removed_without_justification_fails_the_manifest(): void
    {
        config(['release_protected_regressions' => [
            'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved' => 'TR-17 near-miss test',
        ]]);

        $baseline = $this->seedManifest('0.10', [
            'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved',
            'Tests\Feature\DocumentPrecedenceTest::test_an_addendum_outranks_the_specification_it_amended_even_when_the_spec_matches_more_words',
        ]);

        $current = JunitTestManifest::fromIds([
            'Tests\Feature\DocumentPrecedenceTest::test_an_addendum_outranks_the_specification_it_amended_even_when_the_spec_matches_more_words',
        ]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.11',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => $baseline,
            'justifications' => [],
            'requiredSuites' => [],
            'dependsOn' => [],
        ]);

        $this->assertFalse($result->passed());
        $this->assertStringContainsString('PROTECTED regression removed without justification', $result->failures[0]);
        $this->assertStringContainsString('TR-17 near-miss test', $result->failures[0]);
        $this->assertSame('failed', $result->manifest->verification_status);
        $this->assertDatabaseHas('release_manifests', ['version' => '0.11', 'verification_status' => 'failed']);
    }

    public function test_a_protected_regression_removed_with_justification_is_allowed_and_recorded(): void
    {
        config(['release_protected_regressions' => [
            'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved' => 'TR-17 near-miss test',
        ]]);

        $baseline = $this->seedManifest('0.20', [
            'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved',
        ]);

        $current = JunitTestManifest::fromIds([]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.21',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => $baseline,
            'justifications' => [
                'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved' => [
                    'reason' => 'Superseded by TR-17 v2 acceptance test',
                    'authorized_by' => 'Codex review, 2026-08-26',
                ],
            ],
            'requiredSuites' => [],
            'dependsOn' => [],
        ]);

        $this->assertTrue($result->passed());
        $this->assertSame('verified', $result->manifest->verification_status);
        $this->assertSame(
            ['Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved'],
            $result->manifest->tests_removed,
        );
        $this->assertSame(
            'Superseded by TR-17 v2 acceptance test',
            $result->manifest->removal_justifications['Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved']['reason'],
        );
    }

    public function test_an_unprotected_test_removed_without_justification_still_fails_the_manifest(): void
    {
        // Codex's own acceptance case: "Test count drops while all remaining
        // tests pass -> fails." Every removal needs a justification, not
        // only ones on the protected list - that is the whole point.
        config(['release_protected_regressions' => []]);

        $baseline = $this->seedManifest('0.30', [
            'Tests\Unit\SomeOrdinaryTest::test_something',
        ]);

        $current = JunitTestManifest::fromIds([]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.31',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => $baseline,
            'justifications' => [],
            'requiredSuites' => [],
            'dependsOn' => [],
        ]);

        $this->assertFalse($result->passed());
        $this->assertStringContainsString('test removed without justification', $result->failures[0]);
    }

    public function test_a_protected_regressions_content_change_without_acknowledgment_fails_the_manifest(): void
    {
        // Codex's first adversarial finding: "same test id, weaker test"
        // must not sail through on identity alone. Uses a REAL protected
        // test id (via genuine Reflection against the real class) so the
        // content hash the builder computes is the real, current one - the
        // baseline below is a deliberately WRONG hash standing in for
        // "this method's body has since changed since that baseline."
        $protectedId = 'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved';
        config(['release_protected_regressions' => [$protectedId => 'TR-17 near-miss test']]);

        $baseline = $this->seedManifest('0.60', [$protectedId], [$protectedId => 'not-the-real-hash']);
        $current = JunitTestManifest::fromIds([$protectedId]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.61',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => $baseline,
            'justifications' => [],
            'requiredSuites' => [],
            'dependsOn' => [],
        ]);

        $this->assertFalse($result->passed());
        $this->assertStringContainsString('PROTECTED regression content changed without acknowledgment', $result->failures[0]);
        $this->assertStringContainsString($protectedId, $result->failures[0]);
    }

    public function test_a_protected_regressions_content_change_with_acknowledgment_is_allowed_and_recorded(): void
    {
        $protectedId = 'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved';
        config(['release_protected_regressions' => [$protectedId => 'TR-17 near-miss test']]);

        $baseline = $this->seedManifest('0.70', [$protectedId], [$protectedId => 'not-the-real-hash']);
        $current = JunitTestManifest::fromIds([$protectedId]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.71',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => $baseline,
            'justifications' => [
                $protectedId => ['reason' => 'Strengthened the assertion, reviewed by Codex', 'authorized_by' => 'Codex review'],
            ],
            'requiredSuites' => [],
            'dependsOn' => [],
        ]);

        $this->assertTrue($result->passed());
        $this->assertArrayHasKey($protectedId, $result->manifest->protected_content_hashes);
    }

    public function test_a_required_suite_absent_from_the_current_snapshot_fails_the_manifest(): void
    {
        $current = JunitTestManifest::fromIds([
            'Tests\Feature\SomeOtherTest::test_x',
        ]);

        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.40',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => $current,
            'baseline' => null,
            'justifications' => [],
            'requiredSuites' => ['Tests\Feature\EvidenceInvariantTest'],
            'dependsOn' => [],
        ]);

        $this->assertFalse($result->passed());
        $this->assertStringContainsString('required suite absent', $result->failures[0]);
        $this->assertStringContainsString('EvidenceInvariantTest', $result->failures[0]);
    }

    public function test_a_failed_build_is_still_persisted_with_its_failures_recorded(): void
    {
        $result = (new ReleaseManifestBuilder)->build([
            'version' => '0.50',
            'sourceCommit' => 'deadbeef',
            'tarballPath' => null,
            'repoPath' => '.',
            'migrationsDir' => sys_get_temp_dir().'/rel1-no-such-dir',
            'currentTests' => JunitTestManifest::fromIds([]),
            'baseline' => null,
            'justifications' => [],
            'requiredSuites' => ['Tests\Feature\NoSuchTestClassAtAll'],
            'dependsOn' => [],
        ]);

        $this->assertFalse($result->passed());
        $stored = ReleaseManifest::where('version', '0.50')->firstOrFail();
        $this->assertSame('failed', $stored->verification_status);
        $this->assertNotEmpty($stored->verification_failures);
    }

    public function test_tarball_content_matching_source_passes(): void
    {
        [$repo, $commit] = $this->makeThrowawayRepoWithFile('src/foo.txt', "hello world\n");
        $tarball = $this->makeTarball($repo, ['src/foo.txt' => "hello world\n"]);

        $mismatches = (new TarballContentVerifier)->verify($tarball, $repo, $commit);

        $this->assertSame([], $mismatches);
    }

    public function test_tarball_content_diverging_from_source_fails(): void
    {
        [$repo, $commit] = $this->makeThrowawayRepoWithFile('src/foo.txt', "hello world\n");
        $tarball = $this->makeTarball($repo, ['src/foo.txt' => "goodbye world\n"]);

        $mismatches = (new TarballContentVerifier)->verify($tarball, $repo, $commit);

        $this->assertNotEmpty($mismatches);
        $this->assertStringContainsString('does not match source', $mismatches[0]);
    }

    public function test_tarball_file_absent_from_source_fails(): void
    {
        [$repo, $commit] = $this->makeThrowawayRepoWithFile('src/foo.txt', "hello world\n");
        $tarball = $this->makeTarball($repo, ['src/bar.txt' => "untracked\n"]);

        $mismatches = (new TarballContentVerifier)->verify($tarball, $repo, $commit);

        $this->assertNotEmpty($mismatches);
        $this->assertStringContainsString('not present in source', $mismatches[0]);
    }

    public function test_verify_artifact_passes_when_the_tarball_matches_the_verified_manifest(): void
    {
        $tarball = sys_get_temp_dir().'/rel1-artifact-'.bin2hex(random_bytes(4)).'.tar.gz';
        file_put_contents($tarball, 'real bytes');

        ReleaseManifest::create($this->manifestAttributes('0.80', hash_file('sha256', $tarball), $tarball));

        $this->artisan('release:verify-artifact', ['version' => '0.80', '--tarball' => $tarball])
            ->assertExitCode(0);

        unlink($tarball);
    }

    public function test_verify_artifact_fails_when_the_tarball_no_longer_matches_the_verified_manifest(): void
    {
        // Codex's second adversarial finding: a tarball swapped or modified
        // after its manifest was verified must be refused, not silently
        // deployed as though nothing changed.
        $tarball = sys_get_temp_dir().'/rel1-artifact-'.bin2hex(random_bytes(4)).'.tar.gz';
        file_put_contents($tarball, 'the bytes that were actually tested');
        $verifiedHash = hash_file('sha256', $tarball);

        ReleaseManifest::create($this->manifestAttributes('0.81', $verifiedHash, $tarball));

        // Simulate a swap: the file at the same path now has different content.
        file_put_contents($tarball, 'a different, untested payload');

        $this->artisan('release:verify-artifact', ['version' => '0.81', '--tarball' => $tarball])
            ->assertExitCode(1);

        unlink($tarball);
    }

    public function test_verify_artifact_fails_when_confirming_the_wrong_version_against_a_mismatched_tarball(): void
    {
        // Codex's third adversarial finding: deploying a genuinely valid
        // package under the WRONG version label. Two different versions'
        // real tarballs necessarily hash differently, so asking to verify
        // version A's manifest against version B's real tarball fails for
        // the same reason as a swap - the content does not match what that
        // version's manifest recorded.
        $tarballA = sys_get_temp_dir().'/rel1-artifact-a-'.bin2hex(random_bytes(4)).'.tar.gz';
        $tarballB = sys_get_temp_dir().'/rel1-artifact-b-'.bin2hex(random_bytes(4)).'.tar.gz';
        file_put_contents($tarballA, 'version A real package contents');
        file_put_contents($tarballB, 'version B real package contents - genuinely different');

        ReleaseManifest::create($this->manifestAttributes('0.90', hash_file('sha256', $tarballA), $tarballA));
        ReleaseManifest::create($this->manifestAttributes('0.92', hash_file('sha256', $tarballB), $tarballB));

        // Someone at the console means to deploy 0.92 but staged 0.90's tarball.
        $this->artisan('release:verify-artifact', ['version' => '0.92', '--tarball' => $tarballA])
            ->assertExitCode(1);

        unlink($tarballA);
        unlink($tarballB);
    }

    public function test_verify_artifact_fails_for_a_manifest_that_was_never_verified(): void
    {
        $tarball = sys_get_temp_dir().'/rel1-artifact-'.bin2hex(random_bytes(4)).'.tar.gz';
        file_put_contents($tarball, 'contents');

        $attrs = $this->manifestAttributes('0.95', hash_file('sha256', $tarball), $tarball);
        $attrs['verification_status'] = 'failed';
        $attrs['verification_failures'] = ['some prior failure'];
        ReleaseManifest::create($attrs);

        $this->artisan('release:verify-artifact', ['version' => '0.95', '--tarball' => $tarball])
            ->assertExitCode(1);

        unlink($tarball);
    }

    private function manifestAttributes(string $version, string $tarballSha256, string $tarballPath): array
    {
        return [
            'version' => $version,
            'source_commit' => 'deadbeef',
            'tarball_path' => $tarballPath,
            'tarball_sha256' => $tarballSha256,
            'migration_files' => [],
            'test_ids' => [],
            'total_tests' => 0,
            'total_assertions' => null,
            'baseline_version' => null,
            'tests_added' => [],
            'tests_removed' => [],
            'removal_justifications' => [],
            'protected_content_hashes' => [],
            'required_suites' => [],
            'depends_on' => [],
            'verification_status' => 'verified',
            'verification_failures' => [],
            'created_at' => now(),
        ];
    }

    public function test_deploy_order_is_satisfied_only_once_a_dependency_has_a_healthy_recorded_deployment(): void
    {
        $missing = ReleaseManifestBuilder::deployOrderSatisfied(['0.90']);
        $this->assertSame(['0.90'], $missing);

        ReleaseDeployment::create([
            'version' => '0.90',
            'release_manifest_id' => null,
            'deployed_at' => now(),
            'deployed_by' => 'test',
            'verify_live_result' => 'V090_LIVE ops14a=yes worker=active up_bare=200',
            'http_healthy' => true,
        ]);

        $this->assertSame([], ReleaseManifestBuilder::deployOrderSatisfied(['0.90']));
    }

    /** @param list<string> $testIds */
    private function seedManifest(string $version, array $testIds, array $protectedContentHashes = []): ReleaseManifest
    {
        return ReleaseManifest::create([
            'version' => $version,
            'source_commit' => 'deadbeef',
            'tarball_path' => null,
            'tarball_sha256' => null,
            'migration_files' => [],
            'test_ids' => $testIds,
            'total_tests' => count($testIds),
            'total_assertions' => null,
            'baseline_version' => null,
            'tests_added' => $testIds,
            'tests_removed' => [],
            'removal_justifications' => [],
            'protected_content_hashes' => $protectedContentHashes,
            'required_suites' => [],
            'depends_on' => [],
            'verification_status' => 'verified',
            'verification_failures' => [],
            'created_at' => now(),
        ]);
    }

    /** @return array{0: string, 1: string} [repoPath, commitSha] */
    private function makeThrowawayRepoWithFile(string $relativePath, string $content): array
    {
        $repo = sys_get_temp_dir().'/rel1-repo-'.bin2hex(random_bytes(6));
        mkdir($repo.'/'.dirname($relativePath), 0700, true);
        file_put_contents($repo.'/'.$relativePath, $content);

        exec('git -C '.escapeshellarg($repo).' init -q 2>&1');
        exec('git -C '.escapeshellarg($repo).' config user.email rel1@example.test');
        exec('git -C '.escapeshellarg($repo).' config user.name "REL-1 Test"');
        exec('git -C '.escapeshellarg($repo).' add -A');
        exec('git -C '.escapeshellarg($repo).' commit -q -m init');
        $commit = trim((string) shell_exec('git -C '.escapeshellarg($repo).' rev-parse HEAD'));

        $this->assertNotEmpty($commit, 'throwaway git repo fixture failed to produce a commit');

        return [$repo, $commit];
    }

    /** @param array<string, string> $files relative path => content */
    private function makeTarball(string $stagingRoot, array $files): string
    {
        $stageDir = sys_get_temp_dir().'/rel1-stage-'.bin2hex(random_bytes(6));

        foreach ($files as $relativePath => $content) {
            @mkdir($stageDir.'/'.dirname($relativePath), 0700, true);
            file_put_contents($stageDir.'/'.$relativePath, $content);
        }

        $tarball = sys_get_temp_dir().'/rel1-tarball-'.bin2hex(random_bytes(6)).'.tar.gz';
        exec('tar -czf '.escapeshellarg($tarball).' -C '.escapeshellarg($stageDir).' '.implode(' ', array_map('escapeshellarg', array_keys($files))));

        return $tarball;
    }
}
