<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The money path over HTTP.
 *
 * The distinction being defended here is the one that decides which statutory
 * clock is running. A structurally improper request must be refused at the
 * server, because sending it costs a payment cycle and starts no clock. A
 * compliance withholding must NOT be refused, because the request is proper and
 * the thirty-day clock should be running while the defect is cured.
 *
 * If those two ever collapse into one another, the contractor is told the wrong
 * date, and being told the wrong date is the failure this whole module exists to
 * prevent.
 */
class PayApplicationSurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private User $controller;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        $this->controller = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Controller',
            'email' => 'controller@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->controller->id,
            'organization' => 'Northgate Builders', 'seat' => 'controller', 'capabilities' => ['*' => true]]);
        $this->sov('001', 100_000_00);
        $this->sov('002', 50_000_00);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_new_application_opens_with_every_schedule_of_values_line_at_zero(): void
    {
        $body = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();

        $this->assertCount(2, $body['application']['lines']);
        $this->assertSame(0, $body['summary']['total_completed_and_stored_cents']);
        $this->assertSame(150_000_00, $body['summary']['scheduled_value_cents']);

        // Nothing billed is returnable, not improper: it is a real reason an
        // agency sends it back, and it is not a reason to refuse to send it.
        $this->assertFalse($body['blocks_submission']);
        $this->assertContains('nothing_billed', array_column($body['findings'], 'code'));
    }

    public function test_billing_a_line_above_its_authorized_value_refuses_submission_at_the_server(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];

        $body = $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 120_000_00])->assertOk()->json();

        $this->assertTrue($body['blocks_submission']);
        $this->assertContains('line_over_authorized', array_column($body['findings'], 'code'));

        $refusal = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified())
            ->assertStatus(422)->json();
        $this->assertTrue($refusal['refused']);

        $this->assertDatabaseHas('pay_applications', ['id' => $created['application']['id'], 'status' => 'draft']);
    }

    public function test_a_certified_payroll_withholding_does_not_refuse_a_proper_request(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        $body = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified([
            'certified_payroll' => ['context' => ['weeks_without_records' => ['2026-08-08']]],
        ]))->assertOk()->json();

        $this->assertStringContainsString('payment clock still runs', $body['notice']);
        $this->assertDatabaseHas('pay_applications', ['id' => $created['application']['id'], 'status' => 'submitted']);
    }

    public function test_previous_completed_value_carries_forward_instead_of_being_retyped(): void
    {
        $first = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $first['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$first['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 30_000_00])->assertOk();
        $this->postJson('/api/pay-applications/'.$first['application']['id'].'/submit', $this->certified())->assertOk();

        $second = $this->postJson('/api/pay-applications', [
            'project_id' => $this->project->id, 'period_from' => '2026-09-01', 'period_to' => '2026-09-30',
        ])->assertCreated()->json();

        $carried = collect($second['application']['lines'])
            ->firstWhere('schedule_of_value_item_id', $line['schedule_of_value_item_id']);
        $this->assertSame(30_000_00, $carried['previous_completed_cents']);

        // And because it was carried rather than retyped, it reconciles.
        $this->assertNotContains('prior_payments_do_not_match', array_column($second['findings'], 'code'));
    }

    public function test_a_submitted_application_cannot_be_edited_afterwards(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 10_000_00])->assertOk();
        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified())->assertOk();

        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 90_000_00])->assertStatus(422);

        $this->assertDatabaseHas('pay_application_lines', ['id' => $line['id'], 'this_period_cents' => 10_000_00]);
    }

    public function test_another_tenants_application_is_not_reachable(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();

        $other = Tenant::create(['name' => 'Elsewhere Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $intruder = User::create(['tenant_id' => $other->id, 'name' => 'Outsider', 'email' => 'out@elsewhere.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($intruder);

        $this->getJson('/api/pay-applications/'.$created['application']['id'])->assertStatus(404);
    }

    public function test_a_finding_without_a_governing_rate_reaches_the_screen_without_an_amount(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        $body = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified([
            'certified_payroll' => [
                'records' => [[
                    'worker' => 'A. Worker', 'classification' => 'Drone Operator',
                    'hours' => 40, 'hourly_paid_cents' => 30_00, 'fringe_paid_cents' => 0,
                ]],
                'determinations' => [],
            ],
        ]))->assertOk()->json();

        // The condition is reported. The amount is not invented.
        $this->assertSame(0, $body['exposure']['computable_cents']);
        $this->assertCount(1, $body['exposure']['awaiting_determination']);
        $this->assertStringContainsString('none of them carries an amount', $body['notice']);
    }

    public function test_the_stored_material_double_carry_refuses_submission_end_to_end(): void
    {
        // Application 1: $20,000 completed, $80,000 stored on line 001.
        $first = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line1 = $first['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$first['application']['id'].'/lines/'.$line1['id'],
            ['this_period_cents' => 20_000_00, 'stored_materials_cents' => 80_000_00])->assertOk();
        $this->postJson('/api/pay-applications/'.$first['application']['id'].'/submit', $this->certified())->assertOk();

        // Application 2: completed rises to $100,000, stored still $80,000.
        $second = $this->postJson('/api/pay-applications', [
            'project_id' => $this->project->id, 'period_from' => '2026-09-01', 'period_to' => '2026-09-30',
        ])->assertCreated()->json();
        $line2 = collect($second['application']['lines'])
            ->firstWhere('schedule_of_value_item_id', $line1['schedule_of_value_item_id']);

        $body = $this->putJson('/api/pay-applications/'.$second['application']['id'].'/lines/'.$line2['id'],
            ['this_period_cents' => 80_000_00, 'stored_materials_cents' => 80_000_00])->assertOk()->json();

        $this->assertContains('stored_material_double_carry', array_column($body['findings'], 'code'));
        $this->assertTrue($body['blocks_submission']);

        $this->postJson('/api/pay-applications/'.$second['application']['id'].'/submit', $this->certified())->assertStatus(422);

        // Saying why both stand resolves it, and the reason is on the record.
        $this->putJson('/api/pay-applications/'.$second['application']['id'].'/lines/'.$line2['id'],
            ['stored_material_adjustment_reason' => 'Completed work is site concrete; the stored pipe is not yet installed.'])->assertOk();

        $this->postJson('/api/pay-applications/'.$second['application']['id'].'/submit', $this->certified())->assertOk();
    }

    public function test_zecocm_will_not_certify_the_application_on_the_users_behalf(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 10_000_00])->assertOk();

        // Everything about the application is fine. It still does not go out,
        // because a pay application is a signed representation and nobody has
        // signed it.
        $refusal = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit')
            ->assertStatus(422)->json();

        $this->assertTrue($refusal['refused']);
        $this->assertStringContainsString('does not make it on anyone', $refusal['reason']);

        // And the statement it refuses without says both halves out loud.
        $this->assertContains('that stated quantities were actually installed;', $refusal['certification']['not_verified']);
    }

    public function test_the_certifier_is_recorded_on_the_application(): void
    {
        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 10_000_00])->assertOk();
        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified())->assertOk();

        $app = \App\Models\PayApplication::withoutGlobalScopes()->find($created['application']['id']);
        $this->assertSame($this->user->id, $app->certified_by);
        $this->assertSame('PM', $app->seal['certified_by_name']);
        $this->assertNotEmpty($app->seal['certification_version']);
        $this->assertNotEmpty($app->certified_content_hash);
    }

    // ---- two-person certification --------------------------------------------

    public function test_the_preparer_cannot_certify_their_own_billing_where_the_project_requires_two_people(): void
    {
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        // Same account holds every capability. Permissions are not people.
        $refusal = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/certify',
            $this->certified())->assertStatus(422)->json();

        $this->assertStringContainsString('You entered the numbers', $refusal['reason']);

        // And it cannot be smuggled through submission either.
        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit', $this->certified())
            ->assertStatus(422);
    }

    public function test_a_second_person_certifies_and_the_application_then_goes_out(): void
    {
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        Sanctum::actingAs($this->controller);
        $this->certifyAsSeen($created['application']['id'])
            ->assertOk()->assertJsonPath('application.status', 'certified');

        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit')->assertOk();

        $app = \App\Models\PayApplication::withoutGlobalScopes()->find($created['application']['id']);
        $this->assertSame($this->user->id, $app->prepared_by);
        $this->assertSame($this->controller->id, $app->certified_by);
    }

    public function test_changing_the_numbers_after_certification_voids_it(): void
    {
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        Sanctum::actingAs($this->controller);
        $this->certifyAsSeen($created['application']['id'])->assertOk();

        // The preparer raises the billing after the controller signed.
        Sanctum::actingAs($this->user);
        $body = $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 90_000_00])->assertOk()->json();

        $this->assertSame('draft', $body['application']['status']);
        $this->assertStringContainsString('certification on this application is void', $body['notice']);

        // A signature that survived the edit would be a signature on a document
        // that changed afterwards, which is the whole failure this prevents.
        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit')->assertStatus(422);

        $app = \App\Models\PayApplication::withoutGlobalScopes()->find($created['application']['id']);
        $this->assertNull($app->certified_by);
        $this->assertNotEmpty($app->seal['certification_voided_at']);
    }

    public function test_a_note_that_cannot_move_money_does_not_void_certification(): void
    {
        // A certifier forced to re-sign for a comment learns to re-sign without
        // reading, and then the control is worse than nothing.
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        Sanctum::actingAs($this->controller);
        $this->certifyAsSeen($created['application']['id'])->assertOk();

        Sanctum::actingAs($this->user);
        $body = $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['stored_material_adjustment_reason' => 'Noted for the file.'])->assertOk()->json();

        $this->assertSame('certified', $body['application']['status']);
    }

    public function test_editing_the_projects_retention_rule_voids_a_certification_it_predates(): void
    {
        // The hole I found by attacking my own hash. The governing retention
        // rule lives on the project, not on the application. Drop the rate from
        // 5% to 3% after certification and the withholding falls by two points
        // of the whole contract - nothing on the application moved, and the
        // signature would have stood over a different amount.
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        Sanctum::actingAs($this->controller);
        $this->certifyAsSeen($created['application']['id'])->assertOk();

        TenantContext::set($this->tenant->id);
        $this->project->forceFill(['payment_terms' => ['basis_points' => 300,
            'source' => 'Special Provisions s. 9-3.2', 'confirmed' => true]])->save();
        TenantContext::clear();

        $refusal = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit')
            ->assertStatus(422)->json();

        $this->assertStringContainsString('changed since this application was certified', $refusal['reason']);
    }

    public function test_a_certifier_cannot_sign_a_version_they_never_saw(): void
    {
        // The worst bug available in this module, and Codex found it in code I
        // had shipped an hour earlier. The certifier opens version A. Before
        // they click, the preparer raises a line to version B. Their screen
        // still shows A. Without this guard the server would apply their
        // signature to B - and ZecoCM would hold a record saying a second
        // person independently certified figures they never saw.
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        // The certifier loads the screen.
        Sanctum::actingAs($this->controller);
        $seen = $this->getJson('/api/pay-applications/'.$created['application']['id'])
            ->assertOk()->json('content_hash');

        // The preparer changes it underneath them.
        Sanctum::actingAs($this->user);
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 95_000_00])->assertOk();

        // The certifier clicks.
        Sanctum::actingAs($this->controller);
        $conflict = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/certify',
            $this->certified(['content_hash_seen' => $seen]));

        // 409, not 422. This is a conflict, not a validation failure, and the
        // difference matters to anyone writing a client against it.
        $conflict->assertStatus(409);
        $this->assertStringContainsString('changed after you opened it', $conflict->json('reason'));

        $this->assertDatabaseHas('pay_applications', [
            'id' => $created['application']['id'], 'status' => 'draft', 'certified_by' => null,
        ]);
    }

    public function test_certification_must_name_the_version_being_certified(): void
    {
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        Sanctum::actingAs($this->controller);
        $this->postJson('/api/pay-applications/'.$created['application']['id'].'/certify', $this->certified())
            ->assertStatus(422);
    }

    public function test_moving_change_order_value_into_the_original_voids_certification_although_the_money_is_identical(): void
    {
        // Codex's attack on my hash, and the subtlest one yet: the dollars do
        // not move at all. A line reading original 60,000 plus an approved
        // change order of 40,000 becomes original 100,000 with no change order.
        // Same total. The change order that authorized the work has vanished,
        // and the line now claims the work was always in the contract.
        $this->requireSeparateCertifier();

        $created = $this->postJson('/api/pay-applications', $this->period())->assertCreated()->json();
        $line = $created['application']['lines'][0];
        $this->putJson('/api/pay-applications/'.$created['application']['id'].'/lines/'.$line['id'],
            ['this_period_cents' => 40_000_00])->assertOk();

        TenantContext::set($this->tenant->id);
        $item = \App\Models\ScheduleOfValueItem::find($line['schedule_of_value_item_id']);
        $item->forceFill(['original_value_cents' => 60_000_00])->save();
        TenantContext::clear();

        Sanctum::actingAs($this->controller);
        $this->certifyAsSeen($created['application']['id'])->assertOk();

        // Rewrite the split. scheduled_value_cents is untouched.
        TenantContext::set($this->tenant->id);
        $item->forceFill(['original_value_cents' => 100_000_00])->save();
        TenantContext::clear();

        $refusal = $this->postJson('/api/pay-applications/'.$created['application']['id'].'/submit')
            ->assertStatus(422)->json();

        $this->assertStringContainsString('changed since this application was certified', $refusal['reason']);
    }

    // ---- helpers ---------------------------------------------------------------

    /** Certify the way a real client does: read the version, then sign that version. */
    private function certifyAsSeen(int $applicationId, array $extra = [])
    {
        $seen = $this->getJson('/api/pay-applications/'.$applicationId)->assertOk()->json('content_hash');

        return $this->postJson('/api/pay-applications/'.$applicationId.'/certify',
            $this->certified(array_merge(['content_hash_seen' => $seen], $extra)));
    }

    private function requireSeparateCertifier(): void
    {
        TenantContext::set($this->tenant->id);
        $this->project->forceFill(['payment_workflow' => ['requires_separate_certifier' => true]])->save();
        TenantContext::clear();
    }

    private function certified(array $extra = []): array
    {
        return array_merge(['certification_accepted' => true], $extra);
    }

    private function period(): array
    {
        return ['project_id' => $this->project->id, 'period_from' => '2026-08-01', 'period_to' => '2026-08-31'];
    }

    private function sov(string $number, int $cents): void
    {
        ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => $number, 'description' => 'Item '.$number,
            'scheduled_value_cents' => $cents, 'original_value_cents' => $cents]);
    }
}
