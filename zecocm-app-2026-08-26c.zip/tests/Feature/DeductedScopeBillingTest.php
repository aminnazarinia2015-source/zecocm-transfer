<?php

namespace Tests\Feature;

use App\Domain\Payment\DeductedScopeBilling;
use App\Domain\Payment\PayApplicationReview;
use Tests\TestCase;

/**
 * Billing on a line a change order already cut.
 *
 * The honest boundary of this check is the interesting part. Deleted scope is
 * decidable. Partially deducted scope is not, from a schedule of values alone,
 * because a schedule-of-values line is a dollar figure and not an inventory of
 * what the dollars are for.
 */
class DeductedScopeBillingTest extends TestCase
{
    public function test_billing_on_a_line_whose_scope_was_deleted_entirely_is_refused(): void
    {
        $findings = DeductedScopeBilling::findings([$this->line(
            scheduled: 0, original: 80_000_00, deducted: 80_000_00, thisPeriod: 12_000_00,
        )]);

        $this->assertSame('billing_against_deleted_scope', $findings[0]['code']);
        $this->assertSame(PayApplicationReview::HARD_INVALID, $findings[0]['severity']);
        $this->assertSame(12_000_00, $findings[0]['invalid_billed_cents']);
        $this->assertStringContainsString('Change Order CO-12', $findings[0]['message']);
    }

    public function test_stored_material_on_deleted_scope_counts_too(): void
    {
        $findings = DeductedScopeBilling::findings([$this->line(
            scheduled: 0, original: 80_000_00, deducted: 80_000_00, thisPeriod: 0, stored: 5_000_00,
        )]);

        $this->assertSame(5_000_00, $findings[0]['invalid_billed_cents']);
    }

    public function test_codexs_case_asks_rather_than_accuses(): void
    {
        // Original 200,000. CO-12 deducts 80,000, leaving 120,000 authorized.
        // 40,000 previously certified, 60,000 billed this period. Cumulative
        // 100,000 - comfortably under the reduced cap, so over-billing is
        // silent and correctly so.
        //
        // That 60,000 may be entirely legitimate remaining work, or 40,000 of
        // remaining work and 20,000 of deleted scope. The money is identical
        // either way. Asserting a number here would be inventing the violation,
        // so the finding asks which remaining scope it is - and carries zero
        // invalid dollars.
        $findings = DeductedScopeBilling::findings([$this->line(
            scheduled: 120_000_00, original: 200_000_00, deducted: 80_000_00,
            previous: 40_000_00, thisPeriod: 60_000_00,
        )]);

        $this->assertSame('billing_on_deducted_line_unattributed', $findings[0]['code']);
        $this->assertSame(PayApplicationReview::RETURNABLE, $findings[0]['severity']);
        $this->assertSame(0, $findings[0]['invalid_billed_cents']);
        $this->assertStringContainsString('this is not over-billing', $findings[0]['message']);
    }

    public function test_recording_what_the_money_is_for_answers_it(): void
    {
        $findings = DeductedScopeBilling::findings([$this->line(
            scheduled: 120_000_00, original: 200_000_00, deducted: 80_000_00,
            previous: 40_000_00, thisPeriod: 60_000_00,
            attribution: 'Remaining 8-inch main between STA 12+00 and 18+00; the deleted reach north of 18+00 is not billed.',
        )]);

        $this->assertSame([], $findings);
    }

    public function test_a_line_no_change_order_touched_is_not_examined(): void
    {
        $this->assertSame([], DeductedScopeBilling::findings([$this->line(
            scheduled: 200_000_00, original: 200_000_00, deducted: 0, thisPeriod: 60_000_00,
        )]));
    }

    public function test_a_deducted_line_with_no_billing_this_period_says_nothing(): void
    {
        $this->assertSame([], DeductedScopeBilling::findings([$this->line(
            scheduled: 120_000_00, original: 200_000_00, deducted: 80_000_00,
            previous: 40_000_00, thisPeriod: 0,
        )]));
    }

    private function line(
        int $scheduled, int $original, int $deducted, int $thisPeriod = 0,
        int $stored = 0, int $previous = 0, ?string $attribution = null,
    ): array {
        return [
            'item_number' => '004', 'scheduled_value_cents' => $scheduled,
            'original_value_cents' => $original, 'deducted_cents' => $deducted,
            'change_order_number' => 'CO-12', 'effective_at' => '2026-08-01',
            'this_period_cents' => $thisPeriod, 'stored_materials_cents' => $stored,
            'previous_completed_cents' => $previous, 'attribution' => $attribution,
        ];
    }
}
