<?php

namespace Tests\Feature;

use App\Models\DocumentFolder;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class DocumentLibraryTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp(); Storage::fake('local');
        $this->tenant = Tenant::create(['name' => 'Document City', 'type' => 'City portal', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('City portal'), 'sponsor_role' => 'city', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Document Manager',
            'email' => 'documents@example.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'DOC-1', 'name' => 'Document Library', 'sector' => 'public',
            'owner_name' => 'Document City', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Document City', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear(); Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear(); parent::tearDown();
    }

    public function test_folder_navigation_and_document_upload_are_project_scoped(): void
    {
        $folder = $this->postJson('/api/document-library/folders', ['project_id' => $this->project->id, 'name' => '01 Contract Documents'])
            ->assertCreated()->json('folder');
        $this->post('/api/document-library/documents', ['project_id' => $this->project->id, 'folder_id' => $folder['id'],
            'title' => 'Executed Agreement', 'file' => UploadedFile::fake()->createWithContent('agreement.pdf', '%PDF-1.4 documentary evidence')],
            ['Accept' => 'application/json'])->assertCreated()->assertJsonPath('document.document_kind', 'pdf');

        $this->getJson('/api/document-library?project_id='.$this->project->id.'&folder_id='.$folder['id'])
            ->assertOk()->assertJsonPath('breadcrumbs.1.name', '01 Contract Documents')
            ->assertJsonPath('documents.0.title', 'Executed Agreement')
            ->assertJsonPath('security.scanner_configured', false)
            ->assertJsonPath('security.upload_mode', 'quarantine_only');
        $this->assertDatabaseCount('knowledge_source_versions', 1);
    }

    public function test_script_and_executable_uploads_are_refused(): void
    {
        $this->post('/api/document-library/documents', ['project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent('payload.js', 'alert(1)')], ['Accept' => 'application/json'])
            ->assertUnprocessable()->assertJsonValidationErrors('file');
        $this->post('/api/document-library/documents', ['project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent('program.exe', 'MZ')], ['Accept' => 'application/json'])
            ->assertUnprocessable()->assertJsonValidationErrors('file');
        $this->assertDatabaseCount('knowledge_sources', 0);
    }

    public function test_library_reports_scanner_operating_mode_truthfully(): void
    {
        config(['schedule.malware_scanner_binary' => '/usr/bin/clamscan']);
        $this->getJson('/api/document-library?project_id='.$this->project->id)
            ->assertOk()->assertJsonPath('security.scanner_configured', true)
            ->assertJsonPath('security.upload_mode', 'scan_before_release');
    }

    public function test_identical_bytes_replay_without_duplicate_document_or_version(): void
    {
        $payload = fn () => ['project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent('same.pdf', '%PDF identical document bytes')];
        $this->post('/api/document-library/documents', $payload(), ['Accept' => 'application/json'])->assertCreated();
        $this->post('/api/document-library/documents', $payload(), ['Accept' => 'application/json'])
            ->assertOk()->assertJsonPath('replayed', true);
        $this->assertDatabaseCount('knowledge_sources', 1);
        $this->assertDatabaseCount('knowledge_source_versions', 1);
    }

    public function test_replacement_file_appends_a_version_and_hash_chained_event(): void
    {
        $id = $this->post('/api/document-library/documents', ['project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent('agreement.pdf', '%PDF first issued document version')],
            ['Accept' => 'application/json'])->assertCreated()->json('document.id');
        $this->post("/api/document-library/documents/{$id}/versions", [
            'revision' => 'Rev 1', 'file' => UploadedFile::fake()->createWithContent('agreement-rev1.pdf', '%PDF revised issued document version')],
            ['Accept' => 'application/json'])->assertCreated()->assertJsonPath('version.version_number', 2);

        $this->assertDatabaseCount('knowledge_source_versions', 2);
        $this->assertDatabaseCount('document_events', 2);
        $this->assertNotNull(DB::table('document_events')->where('action', 'version_appended')->value('previous_event_hash'));
    }

    public function test_folder_from_another_tenant_cannot_be_used_or_enumerated(): void
    {
        TenantContext::set($this->tenant->id);
        $folder = DocumentFolder::create(['project_id' => $this->project->id, 'name' => 'Private', 'created_by' => $this->user->id]);
        $other = Tenant::create(['name' => 'Other', 'type' => 'CM firm', 'status' => 'active', 'entitlements' => [], 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $otherUser = User::create(['tenant_id' => $other->id, 'name' => 'Other', 'email' => 'other-docs@example.test', 'password' => bcrypt('password')]);
        TenantContext::set($other->id);
        $otherProject = Project::create(['number' => 'O-1', 'name' => 'Other', 'sector' => 'public', 'owner_name' => 'Other', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $otherProject->id, 'user_id' => $otherUser->id, 'organization' => 'Other', 'seat' => 'pm', 'capabilities' => ['*' => true]]);
        TenantContext::clear(); Sanctum::actingAs($otherUser);

        $this->getJson('/api/document-library?project_id='.$otherProject->id.'&folder_id='.$folder->id)->assertNotFound();
    }
}
