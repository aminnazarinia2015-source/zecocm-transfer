<?php

namespace Tests\Feature;

use App\Models\HomepageContent;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Homepage CMS: the platform admin edits news and the pilot customer-count
 * showcase from the control panel; the public homepage reads it back with
 * no auth. Per Amin's explicit direction, the public payload never carries
 * the internal "this is pilot/test data" flag - that stays admin-only.
 */
class HomepageContentTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function admin(): User
    {
        return User::create(['name' => 'Amin', 'email' => 'amin@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'admin']);
    }

    private function customerUser(): User
    {
        $tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);

        return User::create(['tenant_id' => $tenant->id, 'name' => 'Rita', 'email' => 'rita@northgate.test', 'password' => bcrypt('x')]);
    }

    /** No signed-in session at all - the public homepage still reads content. */
    public function test_public_show_requires_no_authentication(): void
    {
        $response = $this->getJson('/api/homepage-content');
        $response->assertOk();
        $response->assertJsonStructure(['news', 'customer_counts', 'updated_at']);
    }

    /** The public payload never carries the internal pilot-data flag or who edited it. */
    public function test_public_show_omits_internal_admin_only_fields(): void
    {
        HomepageContent::current();

        $response = $this->getJson('/api/homepage-content');
        $response->assertOk();
        $response->assertJsonMissing(['counts_are_pilot_data' => true]);
        $this->assertArrayNotHasKey('counts_are_pilot_data', $response->json());
        $this->assertArrayNotHasKey('updated_by', $response->json());
    }

    /** A customer (non-platform) user cannot even view the admin payload. */
    public function test_admin_show_rejects_a_customer_user(): void
    {
        Sanctum::actingAs($this->customerUser());
        TenantContext::clear();

        $response = $this->getJson('/api/platform/homepage-content');
        $response->assertStatus(403);
    }

    /** A customer (non-platform) user cannot update the homepage. */
    public function test_update_rejects_a_customer_user(): void
    {
        Sanctum::actingAs($this->customerUser());
        TenantContext::clear();

        $response = $this->putJson('/api/platform/homepage-content', ['customer_counts' => ['contractors' => 5, 'public_entities' => 1, 'construction_managers' => 1]]);
        $response->assertStatus(403);
    }

    /** The platform admin can update the news list and counts, and the public endpoint reflects it immediately. */
    public function test_admin_can_update_news_and_counts_and_public_endpoint_reflects_it(): void
    {
        Sanctum::actingAs($this->admin());

        $response = $this->putJson('/api/platform/homepage-content', [
            'news' => [
                ['title' => 'ZecoCM opens pilot program', 'body' => 'We are onboarding our first public-works pilot accounts.', 'published_at' => '2026-08-26'],
            ],
            'customer_counts' => ['contractors' => 2059, 'public_entities' => 855, 'construction_managers' => 195],
        ]);
        $response->assertOk();

        $public = $this->getJson('/api/homepage-content')->json();
        $this->assertSame('ZecoCM opens pilot program', $public['news'][0]['title']);
        $this->assertSame(2059, $public['customer_counts']['contractors']);
        $this->assertSame(855, $public['customer_counts']['public_entities']);
        $this->assertSame(195, $public['customer_counts']['construction_managers']);
    }

    /** A negative count is rejected - the admin cannot save nonsense into the public page. */
    public function test_update_rejects_a_negative_count(): void
    {
        Sanctum::actingAs($this->admin());

        $response = $this->putJson('/api/platform/homepage-content', [
            'customer_counts' => ['contractors' => -1, 'public_entities' => 1, 'construction_managers' => 1],
        ]);
        $response->assertStatus(422);
    }

    /** The internal pilot-data flag is visible to platform staff, never to the public. */
    public function test_admin_show_exposes_the_pilot_data_flag(): void
    {
        Sanctum::actingAs($this->admin());

        $response = $this->getJson('/api/platform/homepage-content');
        $response->assertOk();
        $this->assertTrue((bool) $response->json('counts_are_pilot_data'));
    }
}
