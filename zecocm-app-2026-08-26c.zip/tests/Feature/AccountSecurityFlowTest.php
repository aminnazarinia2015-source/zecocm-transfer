<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class AccountSecurityFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_profile_password_and_logout_flow_keeps_only_the_current_session(): void
    {
        $user = $this->customerUser('OriginalPassword!23');

        $firstToken = $this->postJson('/api/login', [
            'email' => $user->email,
            'password' => 'OriginalPassword!23',
        ])->assertOk()->json('token');

        $secondToken = $this->postJson('/api/login', [
            'email' => $user->email,
            'password' => 'OriginalPassword!23',
        ])->assertOk()->json('token');

        $this->withToken($firstToken)->putJson('/api/account', ['name' => 'Verified User'])
            ->assertOk()
            ->assertJsonPath('name', 'Verified User');

        $this->withToken($firstToken)->postJson('/api/account/password', [
            'current_password' => 'OriginalPassword!23',
            'new_password' => 'short',
            'new_password_confirmation' => 'short',
        ])->assertUnprocessable();

        $this->withToken($firstToken)->postJson('/api/account/password', [
            'current_password' => 'OriginalPassword!23',
            'new_password' => 'ReplacementPassword!45',
            'new_password_confirmation' => 'does-not-match',
        ])->assertUnprocessable();

        $this->withToken($firstToken)->postJson('/api/account/password', [
            'current_password' => 'OriginalPassword!23',
            'new_password' => 'ReplacementPassword!45',
            'new_password_confirmation' => 'ReplacementPassword!45',
        ])->assertOk();

        $firstTokenId = (int) str($firstToken)->before('|')->toString();
        $secondTokenId = (int) str($secondToken)->before('|')->toString();
        $this->assertDatabaseHas('personal_access_tokens', ['id' => $firstTokenId]);
        $this->assertDatabaseMissing('personal_access_tokens', ['id' => $secondTokenId]);
        $this->postJson('/api/login', [
            'email' => $user->email,
            'password' => 'OriginalPassword!23',
        ])->assertUnprocessable();

        $this->withToken($firstToken)->postJson('/api/logout')->assertOk();
        $this->assertDatabaseMissing('personal_access_tokens', ['id' => $firstTokenId]);
    }

    public function test_profile_and_logo_uploads_accept_verified_rasters_and_refuse_svg(): void
    {
        Storage::fake('public');
        $user = $this->customerUser('OriginalPassword!23');
        $token = $user->createToken('test-session')->plainTextToken;

        $this->withToken($token)->post('/api/account/photo', [
            'photo' => UploadedFile::fake()->createWithContent(
                'active.svg',
                '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'
            ),
        ], ['Accept' => 'application/json'])->assertUnprocessable();

        $this->withToken($token)->post('/api/account/photo', [
            'photo' => UploadedFile::fake()->image('portrait.png', 128, 128),
        ], ['Accept' => 'application/json'])
            ->assertOk()
            ->assertJsonPath('message', 'Photo updated.');

        $user->refresh();
        Storage::disk('public')->assertExists($user->avatar_path);

        $this->withToken($token)->post('/api/account/logo', [
            'logo' => UploadedFile::fake()->image('company.png', 256, 128),
        ], ['Accept' => 'application/json'])
            ->assertOk()
            ->assertJsonPath('message', 'Company logo updated.');

        $tenant = Tenant::findOrFail($user->tenant_id);
        Storage::disk('public')->assertExists($tenant->logo_path);
    }

    private function customerUser(string $password): User
    {
        $tenant = Tenant::create([
            'name' => 'Secure Tenant',
            'type' => 'contractor',
            'entitlements' => Tenant::defaultEntitlements('contractor'),
            'status' => 'active',
        ]);

        return User::create([
            'tenant_id' => $tenant->id,
            'name' => 'Account User',
            'email' => 'account@example.test',
            'password' => Hash::make($password),
            'platform_role' => null,
            'platform_permissions' => [],
        ]);
    }
}
