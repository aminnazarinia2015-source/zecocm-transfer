<?php

namespace Tests\Feature;

use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * A superseded document is history, not the answer.
 *
 * knowledge_source_edges has been written since the beginning - a steward clicks
 * "relate" and records that Addendum 3 supersedes Addendum 2 - and read by
 * absolutely nothing. The supersession was captured and then ignored, so the
 * replaced text was retrieved and cited as current with no warning. Recording a
 * fact and never consulting it is worse than not recording it, because the
 * interface implies the system knows.
 */
class SupersessionTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_superseded_addendum_is_labelled_and_cannot_control_an_answer(): void
    {
        TenantContext::set($this->tenant->id);
        $old = $this->seedSource('addendum', 'Addendum No. 2',
            'Irrigation mainline trench depth shall be 24 in. Trench depth applies to mainline only.');
        $new = $this->seedSource('addendum', 'Addendum No. 3',
            'Irrigation mainline trench depth shall be 36 in.');
        $this->recordSupersession($new, $old);
        TenantContext::clear();

        $found = $this->retrieve('irrigation mainline trench depth');

        $this->assertNotEmpty($found);
        $this->assertSame('Addendum No. 3', $found[0]->source,
            'The superseded addendum was returned as the governing answer.');
        $this->assertNull($found[0]->supersededBy);
        $this->assertTrue($found[0]->controlsAnswer);

        // The old one still comes back - the paper trail matters in a dispute -
        // but it is labelled and stripped of authority.
        $stale = collect($found)->firstWhere('source', 'Addendum No. 2');
        $this->assertNotNull($stale, 'The superseded text vanished; a dispute needs the trail.');
        $this->assertSame('Addendum No. 3', $stale->supersededBy);
        $this->assertFalse($stale->controlsAnswer,
            'A superseded document was still allowed to control an answer.');
    }

    public function test_supersession_outranks_authority(): void
    {
        // A superseded CONTRACT does not beat a current addendum. Being the
        // highest instrument does not make a replaced version current.
        TenantContext::set($this->tenant->id);
        $oldContract = $this->seedSource('contract', 'Original Agreement A-9764',
            'Mainline trench depth shall be 24 in. Trench depth measured at grade.');
        $amendment = $this->seedSource('addendum', 'Amendment 1',
            'Mainline trench depth shall be 36 in.');
        $this->recordSupersession($amendment, $oldContract);
        TenantContext::clear();

        $found = $this->retrieve('mainline trench depth');

        $this->assertSame('Amendment 1', $found[0]->source);
        $this->assertTrue($found[0]->controlsAnswer);
    }

    public function test_an_unconfirmed_edge_does_not_supersede_anything(): void
    {
        // Supersession is a steward's assertion. A draft or proposed relationship
        // must not quietly retire a governing document.
        TenantContext::set($this->tenant->id);
        $old = $this->seedSource('addendum', 'Addendum No. 2', 'Trench depth shall be 24 in.');
        $new = $this->seedSource('addendum', 'Addendum No. 3', 'Trench depth shall be 36 in.');
        $this->recordSupersession($new, $old, status: 'proposed');
        TenantContext::clear();

        $found = $this->retrieve('trench depth');
        $stale = collect($found)->firstWhere('source', 'Addendum No. 2');

        $this->assertNotNull($stale);
        $this->assertNull($stale->supersededBy);
        $this->assertTrue($stale->controlsAnswer);
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function recordSupersession(int $fromVersionId, int $toVersionId, string $status = 'confirmed'): void
    {
        DB::table('knowledge_source_edges')->insert([
            'tenant_id' => $this->tenant->id,
            'from_version_id' => $fromVersionId,
            'to_version_id' => $toVersionId,
            'relationship' => 'supersedes',
            'status' => $status,
            'confirmed_by' => 1,
            'confirmed_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /** @return int the version id */
    private function seedSource(string $type, string $title, string $body): int
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project', 'title' => $title,
            'source_type' => $type, 'jurisdiction' => 'CA', 'discipline' => 'landscape',
            'authority_level' => 'project_contract', 'access_classification' => 'project_private',
            'verification_status' => 'verified', 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$title, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2026', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['project_specs']], 'storage_path' => 'test/'.$title,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);

        return $version->id;
    }

    // ---- D5: which PART was replaced ----------------------------------------

    public function test_a_scoped_modification_leaves_the_untouched_section_governing(): void
    {
        // The failure D5 exists to fix. Addendum 3 replaces section 3.2 of the
        // specification and says nothing about section 5.1. Before the overlay,
        // the confirmed edge retired the WHOLE specification and section 5.1
        // went dark with it - a requirement still in force, uncitable.
        TenantContext::set($this->tenant->id);

        $spec = $this->seedSectionedSource('specification', 'Specification 32 84 00', [
            ['3.2', 'Irrigation mainline trench depth shall be 24 in.'],
            ['5.1', 'Backflow preventer shall be tested before acceptance.'],
        ]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 3',
            'Section 3.2 is deleted and replaced. Irrigation mainline trench depth shall be 36 in.');

        $edgeId = $this->recordSupersessionReturningId($addendum, $spec);
        $this->recordScope($edgeId, 'section', 'replace', '3.2');

        TenantContext::clear();

        // The replaced section is retired and labelled.
        $trench = collect($this->retrieve('irrigation mainline trench depth'))
            ->firstWhere('sectionRef', '3.2');
        $this->assertNotNull($trench);
        $this->assertFalse($trench->controlsAnswer, 'A replaced section was still allowed to control an answer.');
        $this->assertSame('Addendum No. 3', $trench->supersededBy);

        // The section the addendum never mentioned is still the contract.
        $backflow = collect($this->retrieve('backflow preventer tested before acceptance'))
            ->firstWhere('sectionRef', '5.1');
        $this->assertNotNull($backflow, 'An unaffected section vanished with the rest of its document.');
        $this->assertTrue($backflow->controlsAnswer,
            'An unaffected provision of a modified specification lost its authority. That is exactly the D5 defect.');
        $this->assertNull($backflow->supersededBy);
    }

    public function test_an_unscoped_edge_still_means_the_whole_document(): void
    {
        // Backward compatibility, asserted rather than assumed. Every edge a
        // steward confirmed before scopes existed asserted whole-document
        // supersession, because that is all it could assert. Adding the overlay
        // must not silently change what those edges mean.
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Specification 32 84 00', [
            ['3.2', 'Trench depth shall be 24 in.'],
            ['5.1', 'Backflow preventer shall be tested.'],
        ]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 4', 'Trench depth shall be 36 in.');
        $this->recordSupersession($addendum, $spec);
        TenantContext::clear();

        foreach (['3.2' => 'trench depth', '5.1' => 'backflow preventer tested'] as $section => $q) {
            $row = collect($this->retrieve($q))->firstWhere('sectionRef', $section);
            $this->assertNotNull($row);
            $this->assertFalse($row->controlsAnswer,
                "Section {$section} kept authority although the whole document was superseded.");
        }
    }

    public function test_a_proposed_scope_strips_authority_without_asserting_a_replacement(): void
    {
        // TRACE inferred a modification and nobody confirmed its extent. It must
        // not apply the guess, and it must not answer from text the record
        // already suggests may be dead.
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Specification 32 84 00', [
            ['3.2', 'Trench depth shall be 24 in.'],
        ]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 5', 'Trench depth shall be 36 in.');
        $edgeId = $this->recordSupersessionReturningId($addendum, $spec);
        $this->recordScope($edgeId, 'section', 'replace', '3.2', status: 'proposed');
        TenantContext::clear();

        $row = collect($this->retrieve('trench depth'))->firstWhere('sectionRef', '3.2');

        $this->assertNotNull($row);
        $this->assertFalse($row->controlsAnswer,
            'An unresolved modification let the passage control the answer anyway.');
    }

    public function test_a_supplement_leaves_the_earlier_provision_governing(): void
    {
        // An additive addendum is not supersession. Both stand.
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Specification 32 84 00', [
            ['3.2', 'Trench depth shall be 24 in.'],
        ]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 6',
            'Add to section 3.2: trench depth shall be measured at finished grade.');
        $edgeId = $this->recordSupersessionReturningId($addendum, $spec);
        $this->recordScope($edgeId, 'section', 'supplement', '3.2');
        TenantContext::clear();

        $row = collect($this->retrieve('trench depth'))->firstWhere('sectionRef', '3.2');

        $this->assertNotNull($row);
        $this->assertTrue($row->controlsAnswer,
            'A supplement retired the text it was only adding to.');
    }

    private function recordSupersessionReturningId(int $fromVersionId, int $toVersionId): int
    {
        return (int) DB::table('knowledge_source_edges')->insertGetId([
            'tenant_id' => $this->tenant->id, 'from_version_id' => $fromVersionId,
            'to_version_id' => $toVersionId, 'relationship' => 'supersedes', 'status' => 'confirmed',
            'confirmed_by' => 1, 'confirmed_at' => now(), 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    private function recordScope(int $edgeId, string $type, string $relation, string $section,
        string $status = 'confirmed'): void
    {
        DB::table('supersession_scopes')->insert([
            'tenant_id' => $this->tenant->id, 'knowledge_source_edge_id' => $edgeId,
            'scope_type' => $type, 'relation' => $relation, 'label_claimed' => $section,
            'locator_method' => 'section_ref', 'target_section_ref' => $section,
            'status' => $status, 'confirmed_by' => $status === 'confirmed' ? 1 : null,
            'confirmed_at' => $status === 'confirmed' ? now() : null,
            'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    /** @return int the version id */
    private function seedSectionedSource(string $type, string $title, array $sections): int
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project', 'title' => $title,
            'source_type' => $type, 'jurisdiction' => 'CA', 'discipline' => 'landscape',
            'authority_level' => 'project_contract', 'access_classification' => 'project_private',
            'verification_status' => 'verified', 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$title, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2024', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['project_specs']], 'storage_path' => 'test/'.$title,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        $ordinal = 0;
        foreach ($sections as [$ref, $body]) {
            KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
                'knowledge_source_version_id' => $version->id, 'ordinal' => ++$ordinal,
                'section_ref' => $ref, 'body' => $body, 'body_sha256' => hash('sha256', $body)]);
        }

        return $version->id;
    }

    public function test_a_steward_records_the_scope_at_the_moment_they_record_the_relationship(): void
    {
        // The authoring path. Before this, a scope could only be created by
        // reaching into the database, which means in practice it would never
        // have been created and D5 would have stayed open behind a resolver
        // nothing could feed.
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Specification 32 84 00', [
            ['3.2', 'Trench depth shall be 24 in.'],
            ['5.1', 'Backflow preventer shall be tested.'],
        ]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 7', 'Trench depth shall be 36 in.');
        $specSource = KnowledgeSourceVersion::findOrFail($spec)->knowledge_source_id;
        $addendumSource = KnowledgeSourceVersion::findOrFail($addendum)->knowledge_source_id;
        TenantContext::clear();

        \Laravel\Sanctum\Sanctum::actingAs(User::where('email', 'rita@northgate.test')->firstOrFail());

        $body = $this->postJson('/api/knowledge/sources/'.$addendumSource.'/relationships', [
            'to_source_id' => $specSource,
            'relationship' => 'supersedes',
            'scopes' => [[
                'scope_type' => 'section', 'relation' => 'replace',
                'label_claimed' => '3.2', 'target_section_ref' => '3.2',
                'notes' => 'Addendum 7 deletes and replaces section 3.2 in its entirety.',
            ]],
        ])->assertCreated()->json();

        $this->assertCount(1, $body['scope_ids']);
        $this->assertStringContainsString('Provisions outside those scopes remain operative', $body['notice']);

        // And it takes effect in retrieval, which is the only thing that matters.
        $untouched = collect($this->retrieve('backflow preventer tested'))->firstWhere('sectionRef', '5.1');
        $this->assertNotNull($untouched);
        $this->assertTrue($untouched->controlsAnswer);
    }

    public function test_recording_no_scope_warns_that_the_whole_document_was_retired(): void
    {
        // Whole-document supersession stays available and stays the default,
        // because that is what the existing edges mean. But it now says what it
        // just did, since the quiet version of this is how every untouched
        // provision in a specification loses its authority without anyone
        // choosing that.
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Spec B', [['1.1', 'Anything.']]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 8', 'Anything else.');
        $specSource = KnowledgeSourceVersion::findOrFail($spec)->knowledge_source_id;
        $addendumSource = KnowledgeSourceVersion::findOrFail($addendum)->knowledge_source_id;
        TenantContext::clear();

        \Laravel\Sanctum\Sanctum::actingAs(User::where('email', 'rita@northgate.test')->firstOrFail());

        $body = $this->postJson('/api/knowledge/sources/'.$addendumSource.'/relationships', [
            'to_source_id' => $specSource, 'relationship' => 'supersedes',
        ])->assertCreated()->json();

        $this->assertSame([], $body['scope_ids']);
        $this->assertStringContainsString('WHOLE-DOCUMENT', $body['notice']);
        $this->assertStringContainsString('every untouched provision loses its authority', $body['notice']);
    }

    public function test_a_scope_that_does_not_say_where_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $spec = $this->seedSectionedSource('specification', 'Spec C', [['1.1', 'Anything.']]);
        $addendum = $this->seedSource('addendum', 'Addendum No. 9', 'Anything else.');
        $specSource = KnowledgeSourceVersion::findOrFail($spec)->knowledge_source_id;
        $addendumSource = KnowledgeSourceVersion::findOrFail($addendum)->knowledge_source_id;
        TenantContext::clear();

        \Laravel\Sanctum\Sanctum::actingAs(User::where('email', 'rita@northgate.test')->firstOrFail());

        $this->postJson('/api/knowledge/sources/'.$addendumSource.'/relationships', [
            'to_source_id' => $specSource, 'relationship' => 'supersedes',
            'scopes' => [['scope_type' => 'section', 'relation' => 'replace']],
        ])->assertStatus(422);
    }
}
