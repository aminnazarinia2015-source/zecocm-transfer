<?php

namespace Tests\Feature;

use App\Domain\Ai\Escalation;
use App\Domain\Autonomy\AutonomousActionRecorder;
use App\Domain\Autonomy\AutonomyLevel;
use App\Domain\Autonomy\AutonomyPolicyResolver;
use App\Domain\Autonomy\ClaimClockAutonomyEvaluator;
use App\Domain\Autonomy\CloseoutAutonomyEvaluator;
use App\Domain\Autonomy\InsufficientEvidenceReviewEvaluator;
use App\Domain\Claims\ClaimClock;
use App\Domain\Closeout\CloseoutReadiness;
use App\Models\AiRun;
use App\Models\AutonomousAction;
use App\Models\AutonomyObservation;
use App\Models\AutonomyPolicy;
use App\Models\ClaimRequirement;
use App\Models\ClaimTriggerEvent;
use App\Models\CloseoutDeliverable;
use App\Models\CloseoutRequirement;
use App\Models\Project;
use App\Models\ProjectTask;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * AUTO-2: Governed Project Autopilot's authorization/action substrate, per
 * Codex's ruling (claude/auto-1-auto-2-codex-ruling.md). This is
 * deliberately the NARROW first slice: the autonomy_policies/
 * autonomous_actions schema, AutonomyPolicyResolver's ceiling mechanism,
 * AutonomousActionRecorder's NOT_AUTOMATABLE hard stop, and exactly one
 * seeded action end-to-end (claim clock -> reminder task) - not all four
 * examples in the ruling. Per Codex: "keep the first implementation
 * deliberately narrow."
 */
class AutonomyGovernanceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-900', 'name' => 'Autonomy', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    // --- AutonomyLevel ------------------------------------------------

    public function test_stricter_of_picks_the_less_permissive_level(): void
    {
        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, AutonomyLevel::stricterOf(AutonomyLevel::AUTO, AutonomyLevel::APPROVAL_REQUIRED));
        $this->assertSame(AutonomyLevel::NOT_AUTOMATABLE, AutonomyLevel::stricterOf(AutonomyLevel::HUMAN_ONLY, AutonomyLevel::NOT_AUTOMATABLE));
        $this->assertSame(AutonomyLevel::AUTO, AutonomyLevel::stricterOf(AutonomyLevel::AUTO, AutonomyLevel::AUTO));
    }

    // --- AutonomyPolicyResolver ----------------------------------------

    public function test_with_no_policy_row_the_effective_level_defaults_to_approval_required_even_though_the_ceiling_allows_auto(): void
    {
        // claim_clock_reminder's system ceiling is AUTO, but no project has
        // explicitly authorized it here yet - "never automate away
        // accountability" means AUTO must be granted, not assumed.
        $resolver = new AutonomyPolicyResolver;

        $resolution = $resolver->resolve($this->tenant->id, $this->project->id, 'claim_clock_reminder');

        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, $resolution['level']);
        $this->assertNull($resolution['policy']);
    }

    public function test_an_active_policy_narrower_than_the_ceiling_is_honored(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);

        $resolution = (new AutonomyPolicyResolver)->resolve($this->tenant->id, $this->project->id, 'claim_clock_reminder');

        $this->assertSame(AutonomyLevel::AUTO, $resolution['level']);
    }

    public function test_a_policy_cannot_widen_past_the_system_ceiling_even_if_it_tries(): void
    {
        // send_contractual_notice's ceiling is APPROVAL_REQUIRED. A project
        // policy claiming AUTO for it must not win.
        $this->policy('send_contractual_notice', AutonomyLevel::AUTO);

        $resolution = (new AutonomyPolicyResolver)->resolve($this->tenant->id, $this->project->id, 'send_contractual_notice');

        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, $resolution['level']);
    }

    public function test_an_action_type_with_no_ceiling_entry_fails_closed_to_human_only(): void
    {
        $resolver = new AutonomyPolicyResolver;

        $this->assertSame(AutonomyLevel::HUMAN_ONLY, $resolver->ceilingFor('some_future_action_nobody_configured_yet'));
    }

    public function test_an_active_policy_cannot_be_edited_in_place(): void
    {
        $policy = $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);

        $this->expectException(\RuntimeException::class);
        $policy->update(['autonomy_level' => AutonomyLevel::APPROVAL_REQUIRED]);
    }

    public function test_an_active_policy_may_transition_to_superseded(): void
    {
        $policy = $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);

        $policy->update(['status' => 'superseded']);

        $this->assertSame('superseded', $policy->fresh()->status);
    }

    public function test_a_policy_is_never_deleted(): void
    {
        $policy = $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);

        $this->expectException(\RuntimeException::class);
        $policy->delete();
    }

    // --- AutonomousActionRecorder ----------------------------------------

    public function test_not_automatable_creates_no_row_at_all(): void
    {
        $recorder = new AutonomousActionRecorder;

        $action = $recorder->record($this->actionParams('determine_contractor_termination'));

        $this->assertNull($action);
        $this->assertSame(0, AutonomousAction::count());
    }

    public function test_not_automatable_still_leaves_an_observable_trace(): void
    {
        // Codex: "no action object - correct. No historical observation
        // whatsoever - potentially too silent."
        (new AutonomousActionRecorder)->record($this->actionParams('determine_contractor_termination'));

        $observation = AutonomyObservation::first();
        $this->assertNotNull($observation);
        $this->assertSame('determine_contractor_termination', $observation->action_type);
        $this->assertStringContainsString('NOT_AUTOMATABLE', $observation->reason);
    }

    public function test_an_unresolved_trigger_on_a_non_uncertainty_preserving_action_is_forced_to_approval_required_even_under_an_auto_policy(): void
    {
        // The uncertainty-laundering guard: claim_clock_reminder is NOT in
        // config/autonomy_uncertainty_preserving_actions.php, so an
        // unresolved trigger must not auto-execute even with an AUTO policy.
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);

        $action = (new AutonomousActionRecorder)->record($this->actionParams(
            'claim_clock_reminder',
            autoExecute: fn () => ['should' => 'not run'],
        ) + ['epistemic_state' => 'unresolved']);

        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, $action->effective_autonomy_level);
        $this->assertSame('pending_approval', $action->status);
        $this->assertNull($action->executed_change);
    }

    public function test_an_unresolved_trigger_on_an_uncertainty_preserving_action_may_still_auto_execute(): void
    {
        $this->policy('insufficient_evidence_review_request', AutonomyLevel::AUTO);

        $action = (new AutonomousActionRecorder)->record($this->actionParams(
            'insufficient_evidence_review_request',
            autoExecute: fn () => ['created_review_task' => true],
        ) + ['epistemic_state' => 'unresolved']);

        $this->assertSame(AutonomyLevel::AUTO, $action->effective_autonomy_level);
        $this->assertSame('executed', $action->status);
    }

    public function test_reauthorization_refuses_to_execute_once_the_policy_has_been_tightened_since_creation(): void
    {
        // Codex's strongest attack: an action created under AUTO must not
        // execute on that stale authority if the policy was superseded to
        // something stricter before execution actually happens.
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $recorder = new AutonomousActionRecorder;

        // pending_approval starting state simulates a deferred-execution
        // action that hasn't run its auto_execute yet.
        $action = $recorder->record($this->actionParams('claim_clock_reminder'));
        $this->assertSame('proposed', $action->status);

        AutonomyPolicy::where('action_type', 'claim_clock_reminder')->first()->update(['status' => 'superseded']);
        $this->policy('claim_clock_reminder', AutonomyLevel::APPROVAL_REQUIRED);

        $executed = false;
        $recorder->executeIfStillAuthorized($action, function () use (&$executed) {
            $executed = true;

            return ['x' => 1];
        });

        $this->assertFalse($executed);
        $this->assertSame('pending_approval', $action->fresh()->status);
        $this->assertNull($action->fresh()->executed_change);
    }

    public function test_reauthorization_executes_when_authority_still_permits_it(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $recorder = new AutonomousActionRecorder;

        $action = $recorder->record($this->actionParams('claim_clock_reminder'));

        $recorder->executeIfStillAuthorized($action, fn () => ['x' => 1]);

        $this->assertSame('executed', $action->fresh()->status);
        $this->assertSame(['x' => 1], $action->fresh()->executed_change);
    }

    public function test_approval_required_creates_a_pending_row_and_does_not_auto_execute(): void
    {
        $recorder = new AutonomousActionRecorder;
        $executed = false;

        $action = $recorder->record($this->actionParams('send_contractual_notice', autoExecute: function () use (&$executed) {
            $executed = true;

            return ['sent' => true];
        }));

        $this->assertNotNull($action);
        $this->assertSame('pending_approval', $action->status);
        $this->assertNull($action->executed_change);
        $this->assertFalse($executed, 'auto_execute must never run above AUTO/AUTO_NOTIFY');
    }

    public function test_auto_tier_executes_immediately_and_records_the_executed_change(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $recorder = new AutonomousActionRecorder;

        $action = $recorder->record($this->actionParams('claim_clock_reminder', autoExecute: fn () => ['did' => 'the thing']));

        $this->assertSame('executed', $action->status);
        $this->assertSame(['did' => 'the thing'], $action->executed_change);
        $this->assertNotNull($action->executed_at);
    }

    public function test_an_autonomous_actions_identity_fields_are_frozen(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $action = (new AutonomousActionRecorder)->record($this->actionParams('claim_clock_reminder', autoExecute: fn () => ['x' => 1]));

        $this->expectException(\RuntimeException::class);
        $action->update(['rule_id' => 'something-else']);
    }

    public function test_executed_change_cannot_be_overwritten_once_set(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $action = (new AutonomousActionRecorder)->record($this->actionParams('claim_clock_reminder', autoExecute: fn () => ['x' => 1]));

        $this->expectException(\RuntimeException::class);
        $action->update(['executed_change' => ['x' => 2]]);
    }

    public function test_status_and_human_intervention_state_may_still_move_after_creation(): void
    {
        $action = (new AutonomousActionRecorder)->record($this->actionParams('send_contractual_notice'));

        $action->update(['status' => 'approved', 'human_intervention_state' => 'approved', 'approved_by' => $this->user->id, 'approved_at' => now()]);

        $this->assertSame('approved', $action->fresh()->status);
    }

    public function test_an_autonomous_action_is_never_deleted(): void
    {
        $action = (new AutonomousActionRecorder)->record($this->actionParams('send_contractual_notice'));

        $this->expectException(\RuntimeException::class);
        $action->delete();
    }

    public function test_result_hash_is_derived_from_the_actions_identity_and_is_stable(): void
    {
        $action = (new AutonomousActionRecorder)->record($this->actionParams('send_contractual_notice'));

        $this->assertNotEmpty($action->result_hash);
        $this->assertSame(64, strlen($action->result_hash));
    }

    // --- ClaimClockAutonomyEvaluator (the seeded action, end to end) -----

    public function test_a_confirmed_preservative_requirement_past_established_produces_a_reminder_task_when_policy_is_auto(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $requirement = $this->requirementWithConfirmedTrigger();

        $result = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement);

        $this->assertNotNull($result['action']);
        $this->assertSame('executed', $result['action']->status);
        $task = ProjectTask::where('subject_type', ClaimRequirement::class)->where('subject_id', $requirement->id)->first();
        $this->assertNotNull($task, 'expected a ProjectTask to have been created');
        $this->assertSame($result['action']->id, $task->autonomous_action_id);
        $this->assertSame('open', $task->status);
    }

    public function test_without_an_explicit_policy_the_action_is_recorded_pending_approval_and_no_task_is_created_yet(): void
    {
        // Default-closed behavior from AutonomyPolicyResolver, exercised
        // through the real seeded action rather than the resolver directly.
        $requirement = $this->requirementWithConfirmedTrigger();

        $result = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement);

        $this->assertNotNull($result['action']);
        $this->assertSame('pending_approval', $result['action']->status);
        $this->assertSame(0, ProjectTask::count());
    }

    public function test_re_evaluating_an_already_reminded_requirement_returns_the_same_action_and_does_not_create_a_second_task(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $requirement = $this->requirementWithConfirmedTrigger();

        $first = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement);
        $second = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement->fresh());

        // action_key dedup: the same still-current deadline returns the
        // SAME action rather than creating a duplicate.
        $this->assertSame($first['action']->id, $second['action']->id);
        $this->assertSame(1, ProjectTask::where('subject_id', $requirement->id)->count());
        $this->assertSame(1, AutonomousAction::where('action_type', 'claim_clock_reminder')->count());
    }

    public function test_a_materially_recalculated_deadline_produces_a_new_action_rather_than_being_swallowed(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        $requirement = $this->requirementWithConfirmedTrigger();

        $first = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement);

        // The trigger date is corrected -> the deadline recalculates to a
        // different date -> a materially different state_version -> a NEW
        // action, not a silent no-op, per Codex's "trigger materially
        // changes -> new action" acceptance case.
        $requirement->trigger->update(['occurred_on' => now()->subDays(5)->toDateString()]);
        $second = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement->fresh('trigger'));

        $this->assertNotSame($first['action']->id, $second['action']->id);
        $this->assertSame(2, AutonomousAction::where('action_type', 'claim_clock_reminder')->count());
    }

    public function test_a_requirement_whose_clock_does_not_yet_alert_produces_no_action(): void
    {
        $this->policy('claim_clock_reminder', AutonomyLevel::AUTO);
        // Administrative, not preservative/escalation - ClaimClock's own
        // may_alert only fires on an established PRESERVATIVE consequence in
        // this codebase's existing logic path exercised here (a confirmed
        // trigger + established deadline). Using an unconfirmed requirement
        // instead exercises the "no clock at all" path just as validly.
        $requirement = $this->requirement(['status' => 'draft']);

        $result = (new ClaimClockAutonomyEvaluator)->evaluateRequirement($requirement);

        $this->assertNull($result);
    }

    // --- helpers ---------------------------------------------------------

    private function policy(string $actionType, string $level): AutonomyPolicy
    {
        return AutonomyPolicy::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'capability' => 'claims',
            'action_type' => $actionType,
            'autonomy_level' => $level,
            'authority_source' => 'test fixture',
            'set_by' => $this->user->id,
            'set_at' => now(),
            'effective_at' => now(),
            'status' => 'active',
        ]);
    }

    private function actionParams(string $actionType, ?callable $autoExecute = null): array
    {
        return [
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'capability' => 'test',
            'action_type' => $actionType,
            'trigger_type' => 'test_trigger',
            'trigger_record_ids' => [['type' => 'Test', 'id' => 1]],
            'rule_id' => 'test-rule',
            'evidence_used' => ['fact' => 'value'],
            'proposed_change' => ['do' => 'something'],
            'auto_execute' => $autoExecute,
        ];
    }

    private function requirement(array $overrides = []): ClaimRequirement
    {
        return ClaimRequirement::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'requirement_type' => 'differing_site_condition_notice',
            'title' => 'Written notice of differing site condition',
            'authority_type' => 'contract',
            'authority_citation' => 'Contract s. 4.03',
            'consequence_class' => ClaimClock::PRESERVATIVE,
            'trigger_type' => 'differing_condition_encountered',
            'period_value' => 10,
            'period_unit' => 'calendar_days',
            'calendar_rule' => 'calendar',
            'status' => 'confirmed',
            'confirmed_by' => $this->user->id,
            'confirmed_at' => now(),
        ], $overrides));
    }

    private function requirementWithConfirmedTrigger(): ClaimRequirement
    {
        $requirement = $this->requirement();

        $trigger = ClaimTriggerEvent::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'event_type' => 'differing_condition_encountered',
            'occurred_on' => now()->subDays(2)->toDateString(),
            'status' => 'confirmed',
            'confirmed_by' => $this->user->id,
            'confirmed_at' => now(),
        ]);

        $requirement->update(['claim_trigger_event_id' => $trigger->id]);

        return $requirement->fresh('trigger');
    }

    // --- InsufficientEvidenceReviewEvaluator (the second seeded action) --

    public function test_an_insufficient_evidence_ai_run_produces_a_review_task_preserving_the_missing_fact_when_policy_is_auto(): void
    {
        $this->policy('insufficient_evidence_review_request', AutonomyLevel::AUTO);
        $run = $this->insufficientEvidenceRun();

        $action = (new InsufficientEvidenceReviewEvaluator)->evaluateRun($run);

        $this->assertNotNull($action);
        $this->assertSame('executed', $action->status);
        $this->assertSame('unresolved', $action->epistemic_state);
        $task = ProjectTask::where('subject_type', AiRun::class)->where('subject_id', $run->id)->first();
        $this->assertNotNull($task);
        // Preserves the unresolved framing - never asserts the missing fact
        // as settled. Codex's own example: "Review missing acceptance date",
        // never "Confirm acceptance occurred August 12."
        $this->assertStringStartsWith('Review unresolved:', $task->title);
        $this->assertStringContainsString('confirmed acceptance date', $task->detail);
    }

    public function test_an_ai_run_that_is_not_a_refusal_produces_no_action(): void
    {
        $run = $this->insufficientEvidenceRun(['result_classification' => 'answer', 'result' => null]);

        $this->assertNull((new InsufficientEvidenceReviewEvaluator)->evaluateRun($run));
    }

    public function test_a_refusal_on_a_different_basis_produces_no_action(): void
    {
        $run = $this->insufficientEvidenceRun([
            'result' => ['basis' => Escalation::BASIS_CONFLICT, 'reason' => 'two sources disagree'],
        ]);

        $this->assertNull((new InsufficientEvidenceReviewEvaluator)->evaluateRun($run));
    }

    private function insufficientEvidenceRun(array $overrides = []): AiRun
    {
        return AiRun::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(),
            'idempotency_key' => (string) Str::uuid(),
            'task_type' => 'answer',
            'category' => 'general_administration',
            'question' => 'was acceptance confirmed',
            'status' => 'completed',
            'provider' => 'test',
            'model' => 'test-model',
            'prompt_version' => 'v1',
            'retrieval_version' => 'v1',
            'policy_version' => 'refusal-v1',
            'authorization_scope' => [],
            'retrieval_scope' => [],
            'assumptions' => [],
            'result_classification' => 'refusal',
            'confidence' => 'high',
            'result' => [
                'basis' => Escalation::BASIS_INSUFFICIENT_EVIDENCE,
                'reason' => 'no record establishes the acceptance date',
                'missing_fact' => 'confirmed acceptance date',
                'conflict_citations' => [],
            ],
        ], $overrides));
    }

    // --- CloseoutAutonomyEvaluator (the third seeded action) --------------

    public function test_an_unassigned_closeout_requirement_produces_a_deliverable_request_task_when_policy_is_auto(): void
    {
        $this->policy('closeout_deliverable_request', AutonomyLevel::AUTO);
        $requirement = $this->closeoutRequirement(['responsible_party' => null]);

        $result = (new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement);

        $this->assertNotNull($result['action']);
        $this->assertSame('executed', $result['action']->status);
        $task = ProjectTask::where('subject_type', CloseoutRequirement::class)->where('subject_id', $requirement->id)->first();
        $this->assertNotNull($task);
        $this->assertStringContainsString('Nobody is responsible', $task->detail);
    }

    public function test_an_assigned_closeout_requirement_with_no_other_risk_signal_produces_no_action(): void
    {
        $requirement = $this->closeoutRequirement(['responsible_party' => 'Acme Drywall']);
        CloseoutDeliverable::create([
            'tenant_id' => $this->tenant->id,
            'closeout_requirement_id' => $requirement->id,
            'state' => CloseoutReadiness::ASSIGNED,
        ]);

        $this->assertNull((new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement->fresh('deliverable')));
    }

    public function test_an_accepted_closeout_requirement_produces_no_action_even_if_unassigned(): void
    {
        $requirement = $this->closeoutRequirement(['responsible_party' => null]);
        CloseoutDeliverable::create([
            'tenant_id' => $this->tenant->id,
            'closeout_requirement_id' => $requirement->id,
            'state' => CloseoutReadiness::ACCEPTED,
        ]);

        $this->assertNull((new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement->fresh('deliverable')));
    }

    public function test_re_evaluating_the_same_at_risk_requirement_returns_the_same_action(): void
    {
        $this->policy('closeout_deliverable_request', AutonomyLevel::AUTO);
        $requirement = $this->closeoutRequirement(['responsible_party' => null]);

        $first = (new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement);
        $second = (new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement->fresh('deliverable'));

        $this->assertSame($first['action']->id, $second['action']->id);
        $this->assertSame(1, ProjectTask::where('subject_id', $requirement->id)->count());
    }

    public function test_a_requirement_that_becomes_assigned_after_being_flagged_at_risk_produces_no_new_action(): void
    {
        // The old action is not silently mutated - it simply stops being
        // re-detected once the underlying state no longer qualifies as
        // at-risk. It stays exactly as it was (executed, describing the
        // state that WAS true), which is the honest record.
        $this->policy('closeout_deliverable_request', AutonomyLevel::AUTO);
        $requirement = $this->closeoutRequirement(['responsible_party' => null]);
        $first = (new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement);

        $requirement->update(['responsible_party' => 'Acme Drywall']);
        CloseoutDeliverable::create([
            'tenant_id' => $this->tenant->id,
            'closeout_requirement_id' => $requirement->id,
            'state' => CloseoutReadiness::ASSIGNED,
        ]);
        $second = (new CloseoutAutonomyEvaluator)->evaluateRequirement($requirement->fresh('deliverable'));

        $this->assertNull($second);
        $this->assertSame(1, AutonomousAction::where('action_type', 'closeout_deliverable_request')->count());
        $this->assertSame($first['action']->id, AutonomousAction::first()->id);
    }

    private function closeoutRequirement(array $overrides = []): CloseoutRequirement
    {
        return CloseoutRequirement::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'deliverable_type' => 'om_manual',
            'title' => 'HVAC O&M Manual',
            'blocks_final_payment' => false,
            'blocks_retention_release' => true,
            'responsible_party' => 'Acme Drywall',
        ], $overrides));
    }
}
