<?php

namespace Tests\Feature;

use App\Domain\Ops\EvidenceStorageHealthCheck;
use App\Domain\Ops\QueueBacklogHealthCheck;
use App\Domain\Ops\QueueHeartbeatHealthCheck;
use App\Domain\Ops\SqlitePragmaHealthCheck;
use App\Jobs\StampQueueHeartbeat;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * OPS-14: application-side conditions that make /up truthful beyond OPS-15's
 * database write probe - queue-worker heartbeat, oldest-pending-job age,
 * evidence-volume free space, and a live SQLite PRAGMA read-back. Every
 * check here follows the same contract Codex ruled for this row: pass
 * silently, or throw - no new degrade vocabulary inside /up's own response.
 *
 * Codex's review of the first version of this row caught a real gap in
 * QueueHeartbeatHealthCheck (checking dispatch freshness alone cannot prove
 * consumption) and a real bug in QueueBacklogHealthCheck (diffInSeconds()'s
 * absolute-value default plus no floor on available_at would have
 * misreported a job intentionally delayed until tomorrow as ancient
 * backlog). Both are fixed below; since QueueHeartbeatHealthCheck now fails
 * outright when no heartbeat row has EVER been recorded
 * (QUEUE_HEARTBEAT_MISSING), every test that isn't specifically about the
 * heartbeat itself seeds one healthy row in setUp() so /up's other checks
 * can be exercised independently of it.
 */
class Ops14HealthChecksTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
        $this->seedHealthyHeartbeat();
    }

    private function seedHealthyHeartbeat(): void
    {
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-baseline', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(2), 'handled_at' => now()->subSecond(),
            'worker_identity' => 'worker-baseline',
        ]);
    }

    // ---- queue heartbeat ---------------------------------------------------

    public function test_up_fails_when_no_heartbeat_has_ever_been_dispatched(): void
    {
        DB::table('queue_heartbeats')->truncate();

        // QUEUE_HEARTBEAT_MISSING - correct for a genuinely-never-run
        // scheduler. deploy/verify-live.sh now dispatches one heartbeat
        // synchronously before curling /up specifically so a fresh deploy
        // never actually hits this state in practice.
        $this->get('/up')->assertStatus(500);
    }

    public function test_up_passes_when_the_most_recent_heartbeat_was_handled_promptly(): void
    {
        // The baseline row from setUp() is exactly this case.
        $this->get('/up')->assertOk();
    }

    public function test_up_passes_when_an_unhandled_heartbeat_is_still_within_the_handling_grace(): void
    {
        DB::table('queue_heartbeats')->truncate();
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-recent-unhandled', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(10), 'handled_at' => null,
        ]);

        $this->get('/up')->assertOk();
    }

    public function test_up_fails_when_an_unhandled_heartbeat_exceeds_the_handling_grace_even_though_dispatch_is_recent(): void
    {
        // The exact gap Codex's review caught: a heartbeat dispatched
        // recently enough that the SCHEDULER is clearly still running, but
        // sitting unhandled well past a healthy worker's near-instant
        // consumption time - QUEUE_HEARTBEAT_UNHANDLED, not
        // QUEUE_DISPATCH_STALE. Well under dispatch_stale_seconds (180s)
        // but past handling_grace_seconds (45s default).
        DB::table('queue_heartbeats')->truncate();
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-worker-stopped', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(60), 'handled_at' => null,
        ]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_up_fails_when_dispatch_itself_is_stale_even_if_the_last_handled_heartbeat_looked_fine(): void
    {
        // Simulates the SCHEDULER having stopped entirely: the last
        // dispatch was handled fine, but nothing new has been dispatched
        // since - QUEUE_DISPATCH_STALE.
        DB::table('queue_heartbeats')->truncate();
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-old-but-handled', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(500), 'handled_at' => now()->subSeconds(499),
        ]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_up_fails_when_a_heartbeat_was_recorded_handled_before_it_was_dispatched(): void
    {
        // QUEUE_HEARTBEAT_INCONSISTENT - not reachable through this table's
        // own writers, but corrupted data should fail loudly, not silently
        // report healthy.
        DB::table('queue_heartbeats')->truncate();
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-inconsistent', 'queue_name' => 'default',
            'dispatched_at' => now(), 'handled_at' => now()->subMinute(),
        ]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_stamp_queue_heartbeat_job_marks_the_matching_row_handled(): void
    {
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-abc', 'queue_name' => 'default',
            'dispatched_at' => now(), 'handled_at' => null,
        ]);

        (new StampQueueHeartbeat('tok-abc'))->handle();

        $row = DB::table('queue_heartbeats')->where('dispatch_token', 'tok-abc')->first();
        $this->assertNotNull($row->handled_at);
    }

    public function test_stamp_queue_heartbeat_job_throws_when_its_token_has_no_matching_row(): void
    {
        $this->expectException(\RuntimeException::class);
        (new StampQueueHeartbeat('tok-does-not-exist'))->handle();
    }

    public function test_dispatch_queue_heartbeat_command_inserts_and_handles_a_row_end_to_end(): void
    {
        // QUEUE_CONNECTION is 'sync' in the test environment, so the
        // dispatched job runs inline - this proves the whole round trip
        // (insert row -> dispatch -> job stamps handled_at) without a
        // worker process.
        $this->artisan('ops:dispatch-queue-heartbeat')->assertSuccessful();

        $row = DB::table('queue_heartbeats')->orderByDesc('id')->first();
        $this->assertNotNull($row->handled_at, 'The sync-queue job should have stamped this row immediately.');
    }

    public function test_dispatch_queue_heartbeat_command_with_wait_succeeds_once_the_token_is_handled(): void
    {
        // Codex's review: verify-live.sh dispatching then immediately
        // curling /up would race the worker. --wait blocks until the exact
        // dispatched token is handled - on the sync queue that happens
        // inline, so this proves the option's success path without needing
        // a real async worker.
        $this->artisan('ops:dispatch-queue-heartbeat', ['--wait' => 5])->assertSuccessful();
    }

    // ---- queue backlog age --------------------------------------------------

    public function test_up_passes_with_no_pending_jobs(): void
    {
        $this->get('/up')->assertOk();
    }

    public function test_up_passes_when_the_oldest_pending_job_is_within_the_configured_age(): void
    {
        $this->insertPendingJob(availableSecondsAgo: 5);

        $this->get('/up')->assertOk();
    }

    public function test_up_fails_when_the_oldest_pending_job_exceeds_the_configured_max_age(): void
    {
        config(['zecocm_ops.queue_backlog.max_pending_age_seconds' => 60]);
        $this->insertPendingJob(availableSecondsAgo: 600);

        $this->get('/up')->assertStatus(500);
    }

    public function test_a_reserved_job_is_not_counted_as_pending_backlog(): void
    {
        config(['zecocm_ops.queue_backlog.max_pending_age_seconds' => 60]);
        $this->insertPendingJob(availableSecondsAgo: 600, reserved: true);

        // Reserved (actively being worked) is not the same failure as
        // "nobody is consuming this queue at all."
        $this->get('/up')->assertOk();
    }

    public function test_a_job_intentionally_delayed_into_the_future_never_fails_up(): void
    {
        // The exact bug Codex's review caught: diffInSeconds() defaults to
        // an ABSOLUTE value, so a job scheduled for tomorrow (available_at
        // in the future) could otherwise be measured as "ancient" rather
        // than "not due yet." A tiny max age makes this deterministic.
        config(['zecocm_ops.queue_backlog.max_pending_age_seconds' => 1]);
        $this->insertPendingJob(availableSecondsAgo: -86400); // due 24h from now

        $this->get('/up')->assertOk();
    }

    public function test_a_stuck_reservation_logs_a_warning_but_never_fails_up(): void
    {
        // A worker that grabbed a job and then died mid-processing is a
        // real signal worth surfacing, but Codex's ruling is clear this
        // must never be a distinct /up-failing contract - only the
        // "nothing is being consumed at all" case (proven by the
        // heartbeat, not this check) earns that.
        config(['queue.connections.'.config('queue.default').'.retry_after' => 90]);
        DB::table('jobs')->insert([
            'queue' => 'default', 'payload' => json_encode(['displayName' => 'test']),
            'attempts' => 1, 'reserved_at' => now()->subSeconds(1000)->timestamp,
            'available_at' => now()->subSeconds(1000)->timestamp, 'created_at' => now()->subSeconds(1000)->timestamp,
        ]);

        $this->get('/up')->assertOk();
    }

    private function insertPendingJob(int $availableSecondsAgo, bool $reserved = false): void
    {
        DB::table('jobs')->insert([
            'queue' => 'default',
            'payload' => json_encode(['displayName' => 'test']),
            'attempts' => 0,
            'reserved_at' => $reserved ? now()->timestamp : null,
            'available_at' => now()->subSeconds($availableSecondsAgo)->timestamp,
            'created_at' => now()->timestamp,
        ]);
    }

    // ---- evidence storage ---------------------------------------------------

    public function test_up_passes_when_free_space_is_above_both_thresholds(): void
    {
        config([
            'zecocm_ops.evidence_storage.min_free_bytes' => 1,
            'zecocm_ops.evidence_storage.warning_free_bytes' => 1,
        ]);

        $this->get('/up')->assertOk();
    }

    public function test_up_fails_when_free_space_is_below_the_hard_minimum(): void
    {
        // No real disk on any CI/dev box has a petabyte free - this
        // deterministically forces the hard-minimum branch without faking
        // disk_free_space() itself.
        config(['zecocm_ops.evidence_storage.min_free_bytes' => PHP_INT_MAX]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_up_fails_when_the_configured_evidence_root_does_not_exist(): void
    {
        // Codex's review: the first version silently RETURNED (healthy) for
        // a missing root, on the theory a fresh install's directory might
        // not exist yet. That is a false-green path - a missing, unmounted,
        // or typoed root is exactly when this check must fail, not opt out.
        config(['filesystems.disks.'.config('filesystems.default').'.root' => '/nonexistent/path/for/ops14/test']);

        $this->get('/up')->assertStatus(500);
    }

    public function test_up_fails_when_the_evidence_root_is_configured_blank(): void
    {
        config(['filesystems.disks.'.config('filesystems.default').'.root' => '']);

        $this->get('/up')->assertStatus(500);
    }

    public function test_up_fails_when_the_warning_threshold_is_configured_below_the_hard_minimum(): void
    {
        // A reversed configuration is a config error, not a storage
        // condition - Codex's secondary hardening suggestion.
        config([
            'zecocm_ops.evidence_storage.min_free_bytes' => 1000,
            'zecocm_ops.evidence_storage.warning_free_bytes' => 500,
        ]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_evidence_storage_check_never_writes_into_the_evidence_root(): void
    {
        // Codex's explicit instruction: DATA-1 already established the disk
        // topology, and DatabaseWriteHealthCheck already proves actual
        // persistence elsewhere - this check must be a read-only free-space
        // query, never a probe file written into governed evidence storage.
        $root = sys_get_temp_dir().'/zecocm-ops14-evidence-root-'.bin2hex(random_bytes(6));
        mkdir($root);
        config(['filesystems.disks.'.config('filesystems.default').'.root' => $root]);

        try {
            (new EvidenceStorageHealthCheck)->handle();

            $this->assertSame([], scandir($root) === false ? [] : array_values(array_diff(scandir($root), ['.', '..'])),
                'EvidenceStorageHealthCheck must never write any file into the configured evidence root.');
        } finally {
            @rmdir($root);
        }
    }

    // ---- sqlite pragma read-back ---------------------------------------------

    public function test_up_passes_when_live_pragmas_match_configured_expectations(): void
    {
        $this->get('/up')->assertOk();
    }

    public function test_journal_mode_is_never_asserted_against_an_in_memory_connection(): void
    {
        // :memory: forces journal_mode=memory no matter what is requested -
        // asserting WAL against it would fail on every single test run for
        // a reason that has nothing to do with a real defect. Confirms the
        // guard, directly, rather than only through /up passing.
        config(['zecocm_ops.sqlite_pragmas.expected_journal_mode' => 'wal']);

        (new SqlitePragmaHealthCheck)->check();
        $this->addToAssertionCount(1); // did not throw
    }

    public function test_journal_mode_mismatch_fails_against_a_real_file_backed_connection(): void
    {
        // A real file honors WAL, unlike :memory: - open one the way
        // DatabaseConcurrencyTest does, and prove the comparison itself
        // fires when the live PRAGMA disagrees with what is expected.
        $path = sys_get_temp_dir().'/zecocm-ops14-pragma-'.bin2hex(random_bytes(6)).'.sqlite';
        touch($path);
        config(['database.connections.pragma_probe' => array_merge(
            config('database.connections.sqlite'), ['database' => $path],
        )]);
        config(['zecocm_ops.sqlite_pragmas.expected_journal_mode' => 'rollback-journal-that-will-never-match']);

        try {
            $this->expectException(\RuntimeException::class);
            $this->expectExceptionMessage('journal_mode');
            (new SqlitePragmaHealthCheck)->check('pragma_probe');
        } finally {
            DB::connection('pragma_probe')->disconnect();
            foreach ([$path, $path.'-wal', $path.'-shm'] as $f) {
                if (file_exists($f)) {
                    @unlink($f);
                }
            }
        }
    }

    public function test_up_fails_when_the_live_busy_timeout_disagrees_with_configuration(): void
    {
        config(['zecocm_ops.sqlite_pragmas.expected_busy_timeout' => 999999]);

        $this->get('/up')->assertStatus(500);
    }

    public function test_a_second_independently_opened_connection_receives_the_same_pragma_initialization(): void
    {
        // Codex's concern: /up only proves the WEB process's connection is
        // correctly initialized. A queue worker is a separately-booted PHP
        // process with its own connection - this proves the initialization
        // is driven by shared config (applied by Laravel's SQLite connector
        // to any new PDO instance), not by some per-request state that only
        // one process happens to have. Two independently-named connections
        // built from the same config, against the same real file, stand in
        // for "the web process's connection" and "the worker's own
        // connection" without touching (or purging) the actual test
        // database's :memory: connection, which would discard its schema.
        $path = sys_get_temp_dir().'/zecocm-ops14-pragma-shared-'.bin2hex(random_bytes(6)).'.sqlite';
        touch($path);
        config(['database.connections.pragma_probe_web' => array_merge(config('database.connections.sqlite'), ['database' => $path])]);
        config(['database.connections.pragma_probe_worker' => array_merge(config('database.connections.sqlite'), ['database' => $path])]);

        try {
            $webBusyTimeout = (int) (DB::connection('pragma_probe_web')->select('PRAGMA busy_timeout')[0]->timeout ?? -1);
            $workerBusyTimeout = (int) (DB::connection('pragma_probe_worker')->select('PRAGMA busy_timeout')[0]->timeout ?? -1);

            $this->assertSame($webBusyTimeout, $workerBusyTimeout,
                'Two independently-opened connections built from the same config received different busy_timeout initialization.');
            $this->assertSame((int) config('zecocm_ops.sqlite_pragmas.expected_busy_timeout'), $workerBusyTimeout);
        } finally {
            DB::connection('pragma_probe_web')->disconnect();
            DB::connection('pragma_probe_worker')->disconnect();
            foreach ([$path, $path.'-wal', $path.'-shm'] as $f) {
                if (file_exists($f)) {
                    @unlink($f);
                }
            }
        }
    }

    // ---- failed-job delta (alert-only, never gates /up) ----------------------

    public function test_report_failed_job_delta_creates_a_watermark_on_first_run_and_logs_nothing_new(): void
    {
        $this->assertSame(0, DB::table('failed_job_watermarks')->count());

        $this->artisan('ops:report-failed-job-delta')->assertSuccessful();

        $this->assertSame(1, DB::table('failed_job_watermarks')->count());
        $row = DB::table('failed_job_watermarks')->first();
        $this->assertSame('failed_jobs', $row->monitor_name);
        $this->assertSame(0, $row->last_seen_failed_job_id);
    }

    public function test_report_failed_job_delta_advances_the_watermark_past_existing_failures_without_double_counting(): void
    {
        $this->seedFailedJob();
        $this->seedFailedJob();

        $this->artisan('ops:report-failed-job-delta')->assertSuccessful();
        $firstWatermark = DB::table('failed_job_watermarks')->where('monitor_name', 'failed_jobs')->first()->last_seen_failed_job_id;
        $this->assertSame(2, $firstWatermark);

        // A second run with no NEW failures must not re-report the same two,
        // and must never create a second watermark row.
        $this->artisan('ops:report-failed-job-delta')->assertSuccessful();
        $this->assertSame(1, DB::table('failed_job_watermarks')->count());
        $this->assertSame($firstWatermark, DB::table('failed_job_watermarks')->where('monitor_name', 'failed_jobs')->first()->last_seen_failed_job_id);

        $this->seedFailedJob();
        $this->artisan('ops:report-failed-job-delta')->assertSuccessful();
        $this->assertSame(3, DB::table('failed_job_watermarks')->where('monitor_name', 'failed_jobs')->first()->last_seen_failed_job_id);
    }

    public function test_failed_jobs_never_register_on_diagnosing_health_and_therefore_never_gate_up(): void
    {
        // The exact regression this test protects: C5 showed a single
        // permanently-failed job must not keep /up red forever.
        $this->seedFailedJob();

        $this->get('/up')->assertOk();
    }

    private function seedFailedJob(): void
    {
        DB::table('failed_jobs')->insert([
            'uuid' => (string) Str::uuid(),
            'connection' => 'database',
            'queue' => 'default',
            'payload' => json_encode(['displayName' => 'test']),
            'exception' => 'RuntimeException: test failure',
            'failed_at' => now(),
        ]);
    }

    // ---- structural: exactly the checks named above are on /up ---------------

    public function test_ops14_checks_are_all_registered_on_diagnosing_health(): void
    {
        $source = file_get_contents(app_path('Providers/AppServiceProvider.php'));

        foreach ([
            QueueHeartbeatHealthCheck::class,
            QueueBacklogHealthCheck::class,
            EvidenceStorageHealthCheck::class,
            SqlitePragmaHealthCheck::class,
        ] as $class) {
            $this->assertStringContainsString(class_basename($class).'::class', $source,
                "{$class} must be registered on DiagnosingHealth for /up to actually exercise it.");
        }

        // The negative half of the same invariant: failed-job tracking
        // must never be registered as a DiagnosingHealth listener - a doc
        // comment referencing the class by name (as this file's own
        // explanation does) is fine; an actual registration is not.
        $this->assertStringNotContainsString('ReportFailedJobDelta::class', $source,
            'Failed-job delta tracking is alert-only and must never gate /up.');
    }
}
