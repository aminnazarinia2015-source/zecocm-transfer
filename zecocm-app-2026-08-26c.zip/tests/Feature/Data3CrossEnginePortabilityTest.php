<?php

namespace Tests\Feature;

use App\Domain\Evidence\EvidenceDestructionExecutor;
use App\Domain\Evidence\HoldStatus;
use App\Domain\Ops\CrossEnginePortability;
use App\Domain\Ops\StructuralPortabilityCheck;
use App\Domain\Provenance\CanonicalPayload;
use App\Domain\Provenance\ChainSpec;
use App\Domain\Provenance\ChainVerifier;
use App\Domain\Provenance\DigestAlgorithm;
use App\Domain\Provenance\SubjectFingerprint;
use App\Models\EvidenceTombstone;
use App\Models\LegalHoldEvent;
use App\Models\MediaItem;
use App\Models\Project;
use App\Models\QualityItem;
use App\Models\QualityItemEvent;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * DATA-3: cross-database-engine migration safety. Per Codex's ruling, this
 * codebase must be able to move from SQLite to PostgreSQL (or between any two
 * supported engines) WITHOUT re-sealing or rehashing a single record, and
 * without a genuinely healthy chain being reported as broken purely because
 * the storage engine underneath it changed.
 *
 * Three validation levels, exactly as Codex named them:
 *   Level 1 - structural: the same columns exist on both engines.
 *   Level 2 - record equivalence: every row's stored values survive the copy
 *             (booleans, JSON, empty-string-vs-null, Unicode, large integers).
 *   Level 3 - behavioral/evidentiary equivalence: the domain logic that reads
 *             these tables (HoldStatus, EvidenceDestructionExecutor,
 *             ChainVerifier) resolves IDENTICALLY on both engines, including
 *             the "latest event wins" tie-breaker under same-timestamp rows.
 *
 * The default connection (sqlite, :memory:, RefreshDatabase-managed) plays
 * the "before" role. A second connection, pgsql, freshly migrated at the top
 * of every test, plays the "after" role - CrossEnginePortability::copyTable()
 * is the only thing that moves data between them, and it is never asked to
 * fix anything it copies.
 */
class Data3CrossEnginePortabilityTest extends TestCase
{
    use RefreshDatabase;

    private const PG_CONNECTION = 'pgsql';

    private Tenant $tenant;

    private User $actor;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();

        Config::set('database.connections.'.self::PG_CONNECTION, [
            'driver' => 'pgsql',
            'host' => env('DATA3_PG_HOST', '127.0.0.1'),
            'port' => env('DATA3_PG_PORT', '5432'),
            'database' => env('DATA3_PG_DATABASE', 'zecocm_data3_test'),
            'username' => env('DATA3_PG_USERNAME', 'postgres'),
            'password' => env('DATA3_PG_PASSWORD', 'zecocm_test'),
            'charset' => 'utf8',
            'prefix' => '',
            'prefix_indexes' => true,
            'search_path' => 'public',
            'sslmode' => 'prefer',
        ]);
        DB::purge(self::PG_CONNECTION);

        Artisan::call('migrate:fresh', [
            '--database' => self::PG_CONNECTION,
            '--path' => 'database/migrations',
            '--force' => true,
            '--realpath' => false,
        ]);

        $this->tenant = Tenant::create(['name' => 'Data-3 Harbor Authority', 'type' => 'Owner', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Owner'), 'sponsor_role' => 'owner', 'is_account_owner' => true]);
        $this->actor = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Migration Operator',
            'email' => 'migration@harbor.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-903', 'name' => 'Harbor Ünïcödé Terminal — “Pier 7”', 'sector' => 'public',
            'owner_name' => 'Port of Harbor', 'state' => 'WA', 'funding_source' => 'federal', 'org_structure' => [], 'contract_clocks' => []]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    /**
     * Seeds an intentionally ugly, production-shaped dataset on the default
     * (sqlite) connection: nulls, empty strings, Unicode, large integers,
     * a real recomputable ('quality') chain, the pre-existing not-recomputable
     * ('knowledge') chain, and two independent same-timestamp tie-breaker
     * scenarios (legal_hold_events and evidence_tombstone_execution_events).
     */
    private function seedUglyFixture(): array
    {
        $media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => DigestAlgorithm::digest('data-3 fixture bytes'), 'storage_path' => 'media/sealed/aa/fixture',
            'original_name' => 'fixture — évidence.jpg', 'mime' => 'image/jpeg', 'bytes' => 123456789012,
            'malware_scan_status' => 'clean', 'provenance' => ['note' => null, 'unicode' => '検査済み'],
            'provenance_signature' => 'x', 'confidence' => 'strong', 'server_received_at' => now(),
            'receipt_sequence' => 1, 'capture_time_basis' => 'server_receipt', 'capture_finding' => 'consistent',
            'client_claims' => [], 'captured_by' => $this->actor->id, 'retention_class' => null]);

        // A real quality-item event chain, built exactly the way
        // QualityController::append() builds one (V1-style digest, no
        // CanonicalPayload - this ledger never adopted it, per ChainSpec's
        // own comment).
        $item = QualityItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'QC-0001', 'kind' => 'deficiency', 'title' => 'Spalling — north pier',
            'description' => "Concrete spalling observed.\nEmpty-string field below.", 'classification' => 'fact',
            'severity' => 'high', 'location' => '', 'spec_section' => null, 'drawing_reference' => 'S-101',
            'assigned_organization' => 'Harbor Concrete Co.', 'due_at' => null, 'status' => 'open',
            'created_by' => $this->actor->id]);

        $this->appendQualityEvent($item, null, 'open', 'created', 'Initial finding', 'fact');
        $this->appendQualityEvent($item, 'open', 'in_review', 'status_changed', '', 'fact');

        // Legal hold tie-breaker: two events for the SAME hold_id at the
        // IDENTICAL occurred_at timestamp, differing only by id/insert order
        // - exactly the scenario Codex's mandatory test targets.
        $holdId = (string) Str::uuid();
        $tie = now();
        DB::table('legal_hold_events')->insert([
            'tenant_id' => $this->tenant->id, 'hold_id' => $holdId, 'event_type' => LegalHoldEvent::PLACED,
            'scope_type' => LegalHoldEvent::SCOPE_TENANT, 'scope_value' => json_encode(['tenant_id' => $this->tenant->id]),
            'matter_reference' => 'Matter 2026-Ø1', 'actor_id' => $this->actor->id, 'reason' => 'Pending litigation',
            'occurred_at' => $tie, 'created_at' => $tie, 'updated_at' => $tie,
        ]);
        DB::table('legal_hold_events')->insert([
            'tenant_id' => $this->tenant->id, 'hold_id' => $holdId, 'event_type' => LegalHoldEvent::RELEASED,
            'scope_type' => LegalHoldEvent::SCOPE_TENANT, 'scope_value' => json_encode(['tenant_id' => $this->tenant->id]),
            'matter_reference' => null, 'actor_id' => $this->actor->id, 'reason' => 'Matter closed',
            'occurred_at' => $tie, 'created_at' => $tie, 'updated_at' => $tie,
        ]);

        // A knowledge_review_events row, built exactly the way
        // KnowledgeController::event() builds one - CanonicalPayload V2,
        // carrying created_at/updated_at as the documented unrecomputable
        // fields.
        $sourceId = DB::table('knowledge_sources')->insertGetId([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project', 'title' => 'Spec §03 — Concrete',
            'source_type' => 'spec', 'jurisdiction' => null, 'organization' => '', 'discipline' => 'structural',
            'authority_level' => 'party_assertion', 'access_classification' => 'project_private',
            'verification_status' => 'provisional', 'ingestion_status' => 'pending', 'mime_type' => 'application/pdf',
            'storage_path' => 'knowledge/spec03.pdf', 'byte_size' => 9999999999, 'sha256' => DigestAlgorithm::digest('spec-03'),
            'malware_scan_status' => 'clean', 'created_at' => now(), 'updated_at' => now(),
        ]);
        $this->appendKnowledgeEvent($sourceId, 'created', null, 'pending', 'Initial ingestion');
        $this->appendKnowledgeEvent($sourceId, 'reviewed', 'pending', 'verified', null);

        // Execution-ledger tie-breaker: two events for the SAME (fabricated)
        // tombstone id at the identical occurred_at timestamp, differing
        // only by id - EvidenceDestructionExecutor::currentState()'s own
        // tie-break target.
        $destructionRequestId = DB::table('destruction_requests')->insertGetId([
            'tenant_id' => $this->tenant->id, 'media_item_id' => $media->id, 'requested_by' => $this->actor->id,
            'requested_at' => now(), 'reason' => 'no longer needed', 'status' => 'authorized',
            'authorized_by' => $this->actor->id, 'authorized_at' => now(), 'authority_citation' => 'Retention §4.2',
            'hold_check_result' => HoldStatus::NO_HOLD, 'created_at' => now(), 'updated_at' => now(),
        ]);
        $tombstoneId = DB::table('evidence_tombstones')->insertGetId([
            'tenant_id' => $this->tenant->id, 'media_item_id' => $media->id, 'destruction_request_id' => $destructionRequestId,
            'digest' => $media->sha256, 'digest_algorithm' => 'sha256', 'bytes' => $media->bytes, 'mime' => $media->mime,
            'original_name' => $media->original_name, 'authorized_by' => $this->actor->id, 'authorized_at' => now(),
            'authority_citation' => 'Retention §4.2', 'hold_check_result' => HoldStatus::NO_HOLD,
            'state' => 'authorized_pending_execution', 'created_at' => now(), 'updated_at' => now(),
        ]);
        $execTie = now();
        DB::table('evidence_tombstone_execution_events')->insert([
            'tenant_id' => $this->tenant->id, 'evidence_tombstone_id' => $tombstoneId, 'state' => 'execution_in_progress',
            'actor_id' => $this->actor->id, 'detail' => json_encode(['locations' => ['primary']]),
            'occurred_at' => $execTie, 'created_at' => $execTie, 'updated_at' => $execTie,
        ]);
        DB::table('evidence_tombstone_execution_events')->insert([
            'tenant_id' => $this->tenant->id, 'evidence_tombstone_id' => $tombstoneId, 'state' => 'destroyed_within_governed_scope',
            'actor_id' => $this->actor->id, 'detail' => json_encode([]),
            'occurred_at' => $execTie, 'created_at' => $execTie, 'updated_at' => $execTie,
        ]);

        return ['quality_item_id' => $item->id, 'tombstone_id' => $tombstoneId, 'knowledge_source_id' => $sourceId];
    }

    private function appendQualityEvent(QualityItem $item, ?string $from, string $to, string $type, string $note, string $classification): void
    {
        $previous = QualityItemEvent::query()->where('quality_item_id', $item->id)->latest('id')->first();
        $payload = ['tenant_id' => $item->tenant_id, 'project_id' => $item->project_id, 'quality_item_id' => $item->id,
            'event_type' => $type, 'from_status' => $from, 'to_status' => $to, 'note' => $note, 'classification' => $classification,
            'actor_user_id' => $this->actor->id, 'previous_event_hash' => $previous?->event_hash];
        $payload['event_hash'] = DigestAlgorithm::digest(json_encode($payload, JSON_THROW_ON_ERROR));
        $payload['hash_algorithm'] = DigestAlgorithm::CURRENT;
        $subject = SubjectFingerprint::of($item->fresh()->getAttributes(), SubjectFingerprint::QUALITY_ITEM_FIELDS);

        QualityItemEvent::create($payload + ['subject_hash' => $subject, 'subject_hash_algorithm' => DigestAlgorithm::CURRENT]);
    }

    private function appendKnowledgeEvent(int $sourceId, string $action, ?string $from, string $to, ?string $reason): void
    {
        $previous = DB::table('knowledge_review_events')->where('tenant_id', $this->tenant->id)->where('knowledge_source_id', $sourceId)->latest('id')->first();
        $payload = ['tenant_id' => $this->tenant->id, 'knowledge_source_id' => $sourceId, 'action' => $action,
            'from_status' => $from, 'to_status' => $to, 'reason' => $reason, 'actor_user_id' => $this->actor->id,
            'previous_event_hash' => $previous?->event_hash, 'created_at' => now(), 'updated_at' => now()];
        $payload['hash_version'] = CanonicalPayload::CURRENT;
        $payload['hash_algorithm'] = DigestAlgorithm::CURRENT;
        $payload['event_hash'] = CanonicalPayload::hash(Arr::except($payload, ['hash_version', 'hash_algorithm']));
        DB::table('knowledge_review_events')->insert($payload);
    }

    /** Copies every evidentiary table from sqlite to the freshly-migrated pgsql connection. */
    private function copyEverythingToPostgres(): void
    {
        DB::connection(self::PG_CONNECTION)->statement('SET session_replication_role = replica');
        try {
            $tables = CrossEnginePortability::evidentiaryTables('sqlite');
            // migrate:fresh already ran the real migrations on the pgsql
            // connection, and at least one of them (EV-14B's topology table)
            // seeds a row of its own - a fixture-independent row this test
            // never asked for. Clearing every evidentiary table first makes
            // the copy the SOLE source of truth on the destination, exactly
            // as a real cross-engine migration would expect.
            foreach ($tables as $table) {
                DB::connection(self::PG_CONNECTION)->table($table)->truncate();
            }
            foreach ($tables as $table) {
                CrossEnginePortability::copyTable('sqlite', self::PG_CONNECTION, $table);
            }
        } finally {
            DB::connection(self::PG_CONNECTION)->statement('SET session_replication_role = origin');
        }
    }

    // ---- Level 1: structural ---------------------------------------------

    public function test_structural_portability_shows_no_column_drift_across_every_evidentiary_table(): void
    {
        $this->seedUglyFixture();
        $this->copyEverythingToPostgres();

        $tables = CrossEnginePortability::evidentiaryTables('sqlite');
        $this->assertNotEmpty($tables);

        foreach ($tables as $table) {
            $result = StructuralPortabilityCheck::compareColumns('sqlite', self::PG_CONNECTION, $table);
            $this->assertTrue($result['matches'],
                "Column set drift on `{$table}`: missing_here=".json_encode($result['missing_here']).
                ' missing_there='.json_encode($result['missing_there']));
        }
    }

    // ---- Level 3: behavioral / evidentiary equivalence --------------------

    public function test_hold_status_tie_breaker_resolves_identically_after_migration(): void
    {
        $this->seedUglyFixture();
        $media = MediaItem::withoutGlobalScopes()->where('tenant_id', $this->tenant->id)->firstOrFail();

        $before = HoldStatus::forMediaItem($media);
        $this->assertSame(HoldStatus::NO_HOLD, $before['status'],
            'Sanity: the release event must win the tie on the source engine before any migration happens.');

        $this->copyEverythingToPostgres();

        Config::set('database.default', self::PG_CONNECTION);
        try {
            $after = HoldStatus::forMediaItem($media);
        } finally {
            Config::set('database.default', 'sqlite');
        }

        $this->assertSame($before['status'], $after['status'],
            'HoldStatus tie-broke to a different winner after migration - the placed/released tie-breaker is not migration-safe.');
    }

    public function test_destruction_executor_current_state_tie_breaker_resolves_identically_after_migration(): void
    {
        $fixture = $this->seedUglyFixture();
        $tombstone = EvidenceTombstone::withoutGlobalScopes()->findOrFail($fixture['tombstone_id']);

        $before = EvidenceDestructionExecutor::currentState($tombstone);
        $this->assertSame('destroyed_within_governed_scope', $before,
            'Sanity: the later-inserted event must win the same-timestamp tie on the source engine.');

        $this->copyEverythingToPostgres();

        Config::set('database.default', self::PG_CONNECTION);
        try {
            $after = EvidenceDestructionExecutor::currentState($tombstone);
        } finally {
            Config::set('database.default', 'sqlite');
        }

        $this->assertSame($before, $after,
            'EvidenceDestructionExecutor::currentState() tie-broke to a different winner after migration.');
    }

    public function test_quality_chain_recomputes_identically_and_hash_recomputed_is_true_on_both_engines(): void
    {
        $fixture = $this->seedUglyFixture();
        $spec = ChainSpec::all()['quality'];

        $before = ChainVerifier::verify($spec, $fixture['quality_item_id']);
        $this->assertSame(ChainVerifier::OK, $before['status']);
        $this->assertTrue($before['hash_recomputed']);

        $this->copyEverythingToPostgres();

        Config::set('database.default', self::PG_CONNECTION);
        try {
            $after = ChainVerifier::verify($spec, $fixture['quality_item_id']);
        } finally {
            Config::set('database.default', 'sqlite');
        }

        $this->assertSame(ChainVerifier::OK, $after['status'],
            'A migration must never turn a healthy, fully recomputable chain into a reported break.');
        $this->assertTrue($after['hash_recomputed']);
        $this->assertSame($before['head'], $after['head'],
            'The recomputed head hash must be byte-for-byte identical after migration.');
    }

    public function test_knowledge_chain_stays_not_recomputable_never_broken_on_either_engine(): void
    {
        $fixture = $this->seedUglyFixture();
        $spec = ChainSpec::all()['knowledge'];

        $before = ChainVerifier::verify($spec, $fixture['knowledge_source_id']);
        $this->assertNotSame(ChainVerifier::BROKEN, $before['status']);

        $this->copyEverythingToPostgres();

        Config::set('database.default', self::PG_CONNECTION);
        try {
            $after = ChainVerifier::verify($spec, $fixture['knowledge_source_id']);
        } finally {
            Config::set('database.default', 'sqlite');
        }

        // The pre-existing, documented limitation (created_at/updated_at
        // don't serialise identically) must survive migration as exactly
        // what it already was - never manufactured into a false BROKEN
        // finding by a timestamp round-trip through a different engine.
        $this->assertSame($before['status'], $after['status']);
        $this->assertNotSame(ChainVerifier::BROKEN, $after['status'],
            'Migration must never manufacture a false tamper finding out of a timestamp round-trip artifact.');
    }

    // ---- Level 2: record equivalence --------------------------------------

    public function test_booleans_json_null_empty_string_unicode_and_large_integers_survive_the_copy(): void
    {
        $this->seedUglyFixture();
        $this->copyEverythingToPostgres();

        $sourceMedia = DB::connection('sqlite')->table('media_items')->where('tenant_id', $this->tenant->id)->first();
        $copiedMedia = DB::connection(self::PG_CONNECTION)->table('media_items')->where('tenant_id', $this->tenant->id)->first();

        $this->assertSame($sourceMedia->original_name, $copiedMedia->original_name, 'Unicode in a varchar column did not survive the copy.');
        $this->assertEquals((int) $sourceMedia->bytes, (int) $copiedMedia->bytes, 'A large unsigned integer did not survive the copy.');
        $this->assertSame(json_decode($sourceMedia->provenance, true), json_decode($copiedMedia->provenance, true),
            'JSON payload (including a null-valued key) did not survive the copy unchanged.');

        $sourceItem = DB::connection('sqlite')->table('quality_items')->where('tenant_id', $this->tenant->id)->first();
        $copiedItem = DB::connection(self::PG_CONNECTION)->table('quality_items')->where('tenant_id', $this->tenant->id)->first();
        $this->assertSame('', $sourceItem->location, 'Sanity: fixture must actually contain an empty string.');
        $this->assertSame($sourceItem->location, $copiedItem->location, 'Empty string was coerced to NULL (or vice versa) by the copy.');
        $this->assertNull($sourceItem->spec_section);
        $this->assertNull($copiedItem->spec_section, 'NULL was coerced to some other value by the copy.');

        $sourceLoc = DB::connection('sqlite')->table('evidence_storage_locations')->first();
        $copiedLoc = DB::connection(self::PG_CONNECTION)->table('evidence_storage_locations')->first();
        $this->assertNotNull($sourceLoc, 'Sanity: EV-14B seeds a topology row.');
        $this->assertSame((bool) $sourceLoc->governed, (bool) $copiedLoc->governed,
            'Boolean column drifted in meaning (0/1 vs native boolean) across the copy.');
        $this->assertIsBool($copiedLoc->governed, 'Destination boolean column must actually hold a PHP bool after normalisation, not a leftover 0/1.');
    }
}
