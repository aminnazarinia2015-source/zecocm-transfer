<?php

namespace Tests\Feature;

use App\Domain\Provenance\CanonicalPayload;
use App\Domain\Provenance\DigestAlgorithm;
use App\Domain\Provenance\EvidenceExport;
use App\Domain\Provenance\PackageVerifier;
use PHPUnit\Framework\TestCase;

/**
 * EV-15: a package a third party can verify without ZecoCM.
 *
 * The party running the verifier is frequently the party trying to DISPROVE
 * the record. So the tests here are mostly about what the package refuses to
 * claim, and about the ways a naive verifier reports success on a record it
 * never checked.
 */
class EvidenceExportTest extends TestCase
{
    private function chain(array $overrides = []): array
    {
        return array_merge([
            'chain' => 'Quality item events',
            'chain_key' => 'quality',
            'group' => 41,
            'record_count' => 3,
            'head' => 'hash-3',
            'anchor' => ['record_count' => 3, 'head_hash' => 'hash-3'],
            'anchored' => true,
            'entries' => [
                ['sequence' => 1, 'hash' => 'hash-1', 'previous_hash' => null, 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => DigestAlgorithm::CURRENT, 'subject_hash' => 'sub-1'],
                ['sequence' => 2, 'hash' => 'hash-2', 'previous_hash' => 'hash-1', 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => DigestAlgorithm::CURRENT, 'subject_hash' => 'sub-1'],
                ['sequence' => 3, 'hash' => 'hash-3', 'previous_hash' => 'hash-2', 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => DigestAlgorithm::CURRENT, 'subject_hash' => 'sub-1'],
            ],
        ], $overrides);
    }

    private function manifest(array $chains): array
    {
        $manifest = [
            'format' => EvidenceExport::FORMAT,
            'format_version' => EvidenceExport::FORMAT_VERSION,
            'exported_at' => '2026-08-25T22:00:00+00:00',
            'tenant_id' => 1,
            'scope' => ['project_id' => 7, 'completeness' => 'Scoped.'],
            'chains' => $chains,
            'record_identifiers' => [],
            'signing' => ['scheme' => 'hmac-sha256', 'signer_independence' => false, 'limitation' => '...'],
            'canonicalization' => ['current' => CanonicalPayload::CURRENT, 'rule' => '...'],
            'establishes' => [],
            'does_not_establish' => PackageVerifier::DOES_NOT_ESTABLISH,
        ];
        $manifest['manifest_hash'] = EvidenceExport::hashOf($manifest);

        return $manifest;
    }

    // ---- what it refuses to claim -------------------------------------------

    public function test_the_six_refusals_travel_with_every_result_not_just_the_manifest(): void
    {
        // The output is what somebody pastes into a report, so the limits have
        // to be in the output and not only in a file they did not attach.
        $result = PackageVerifier::verify($this->manifest([$this->chain()]));

        $this->assertCount(6, $result['does_not_establish']);
        $joined = implode(' ', $result['does_not_establish']);
        $this->assertStringContainsString('underlying project facts are true', $joined);
        $this->assertStringContainsString('legally correct', $joined);
        $this->assertStringContainsString('never existed', $joined);
        $this->assertStringContainsString('independent signer identity', $joined);
        $this->assertStringContainsString('legal admissibility', $joined);
    }

    public function test_a_clean_package_says_what_it_established_and_immediately_what_it_did_not(): void
    {
        $result = PackageVerifier::verify($this->manifest([$this->chain()]));

        $this->assertSame(PackageVerifier::PASS, $result['status']);
        $this->assertStringContainsString('says nothing about whether the facts it records are true',
            $result['statement']);
    }

    public function test_the_symmetric_signing_limitation_is_machine_readable_and_not_a_footnote(): void
    {
        // B1 is open. A package that implied independent signer identity while
        // the key that verifies is the key that could forge would be the exact
        // approximately-true security claim this codebase refuses to make.
        $result = PackageVerifier::verify($this->manifest([$this->chain()]));

        $this->assertFalse($result['signing']['signer_independence']);
    }

    public function test_scope_travels_so_absence_can_never_read_as_non_existence(): void
    {
        $result = PackageVerifier::verify($this->manifest([$this->chain()]));

        $this->assertSame(7, $result['scope']['project_id']);
    }

    // ---- the manifest is the root of trust ----------------------------------

    public function test_an_altered_manifest_stops_everything_downstream(): void
    {
        // If the list of what should be here is untrustworthy, checking the
        // things that ARE here proves nothing.
        $manifest = $this->manifest([$this->chain()]);
        $manifest['scope']['project_id'] = 9;

        $result = PackageVerifier::verify($manifest);

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertStringContainsString('including the list of which records should be here',
            $result['phases'][0]['finding']);
        $this->assertSame([], $result['chains']);
    }

    public function test_a_manifest_with_no_self_hash_cannot_be_verified(): void
    {
        $manifest = $this->manifest([$this->chain()]);
        unset($manifest['manifest_hash']);

        $result = PackageVerifier::verify($manifest);
        $this->assertSame(PackageVerifier::CANNOT_VERIFY, $result['status']);
    }

    public function test_something_that_is_not_a_zecocm_package_is_refused_outright(): void
    {
        $this->assertSame(PackageVerifier::CANNOT_VERIFY,
            PackageVerifier::verify(['format' => 'something-else'])['status']);
    }

    // ---- no best-effort canonicalization ------------------------------------

    public function test_an_unknown_canonicalization_version_is_cannot_verify_not_a_guess(): void
    {
        // A verifier that guesses the algorithm reports success on records it
        // did not check, which is worse than reporting nothing.
        $chain = $this->chain();
        $chain['entries'][1]['hash_version'] = 'v99-from-the-future';

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::CANNOT_VERIFY, $result['status']);
        $canon = collect($result['phases'])->firstWhere('phase', 'canonicalization');
        $this->assertStringContainsString('no best-effort fallback', $canon['finding']);
        $this->assertStringContainsString('content integrity is not', $canon['finding']);
    }

    public function test_a_missing_version_is_treated_the_same_as_an_unknown_one(): void
    {
        $chain = $this->chain();
        $chain['entries'][0]['hash_version'] = null;

        $this->assertSame(PackageVerifier::CANNOT_VERIFY,
            PackageVerifier::verify($this->manifest([$chain]))['status']);
    }

    public function test_an_unknown_digest_algorithm_is_cannot_verify_even_when_the_encoding_version_is_known(): void
    {
        // EV-13: a second, independent axis from canonicalization. A record can
        // declare a perfectly recognised encoding version and still be
        // unverifiable because nobody recorded which primitive produced its
        // digest - and that must never silently default to sha256.
        $chain = $this->chain();
        $chain['entries'][1]['hash_algorithm'] = 'sha3-256';

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::CANNOT_VERIFY, $result['status']);
        $canon = collect($result['phases'])->firstWhere('phase', 'canonicalization');
        $this->assertStringContainsString('digest algorithm', $canon['finding']);
    }

    public function test_a_missing_digest_algorithm_is_treated_the_same_as_an_unknown_one(): void
    {
        $chain = $this->chain();
        $chain['entries'][2]['hash_algorithm'] = null;

        $this->assertSame(PackageVerifier::CANNOT_VERIFY,
            PackageVerifier::verify($this->manifest([$chain]))['status']);
    }

    // ---- the ways a chain lies ----------------------------------------------

    public function test_records_removed_from_the_front_are_caught_by_genesis(): void
    {
        $chain = $this->chain();
        array_shift($chain['entries']);   // the genesis record is gone
        $chain['anchor'] = ['record_count' => 2, 'head_hash' => 'hash-3'];

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertStringContainsString('removed from the START',
            implode(' ', $result['chains'][0]['findings']));
    }

    public function test_records_removed_from_the_end_are_invisible_without_the_anchor_and_caught_with_it(): void
    {
        // The case that escapes every check inside the chain: what remains
        // links and hashes perfectly.
        $chain = $this->chain();
        array_pop($chain['entries']);
        $chain['head'] = 'hash-2';

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertStringContainsString('precisely why this cannot be seen from inside',
            implode(' ', $result['chains'][0]['findings']));
    }

    public function test_a_replaced_record_is_caught_even_though_the_count_agrees(): void
    {
        $chain = $this->chain();
        $chain['entries'][2]['hash'] = 'hash-3-substituted';
        $chain['head'] = 'hash-3-substituted';

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertStringContainsString('REPLACED rather than removed',
            implode(' ', $result['chains'][0]['findings']));
    }

    public function test_a_broken_link_makes_everything_after_it_untrusted_as_a_block(): void
    {
        // Not "two valid, one invalid". Records after a break each attest to a
        // predecessor whose content can no longer be established.
        $chain = $this->chain();
        $chain['entries'][1]['previous_hash'] = 'hash-that-was-never-here';

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertSame(1, $result['chains'][0]['downstream']);
        $this->assertStringContainsString('DOWNSTREAM-UNTRUSTED', implode(' ', $result['chains'][0]['findings']));
    }

    public function test_an_emptied_chain_the_anchor_remembers_is_reported_as_gone_not_as_empty(): void
    {
        // From inside, an empty chain and a chain that never existed are the
        // same thing.
        $chain = $this->chain(['entries' => [], 'head' => null]);

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::FAIL, $result['status']);
        $this->assertStringContainsString('indistinguishable from a chain that never existed',
            implode(' ', $result['chains'][0]['findings']));
    }

    public function test_an_unanchored_chain_is_cannot_verify_rather_than_pass(): void
    {
        $chain = $this->chain(['anchor' => null, 'anchored' => false]);

        $result = PackageVerifier::verify($this->manifest([$chain]));

        $this->assertSame(PackageVerifier::CANNOT_VERIFY, $result['status']);
        $this->assertStringContainsString('removed from the end without trace',
            implode(' ', $result['chains'][0]['findings']));
    }

    // ---- the format is reimplementable --------------------------------------

    public function test_the_canonical_json_is_key_order_independent(): void
    {
        // The whole spec depends on somebody reproducing this hash in Python on
        // the other side of a dispute. Key order in the file must not matter.
        $a = ['b' => 1, 'a' => ['z' => true, 'y' => null], 'c' => [3, 1, 2]];
        $b = ['a' => ['y' => null, 'z' => true], 'c' => [3, 1, 2], 'b' => 1];

        $this->assertSame(EvidenceExport::canonicalJson($a), EvidenceExport::canonicalJson($b));
        // But list ORDER is meaningful and must not be sorted away.
        $this->assertNotSame(
            EvidenceExport::canonicalJson(['c' => [3, 1, 2]]),
            EvidenceExport::canonicalJson(['c' => [1, 2, 3]]),
        );
    }

    public function test_the_manifest_hash_covers_the_statement_of_limitations(): void
    {
        // Removing the caveats has to change the hash, or somebody strips them
        // and the package still verifies.
        $manifest = $this->manifest([$this->chain()]);
        $stripped = $manifest;
        $stripped['does_not_establish'] = [];

        $this->assertNotSame(EvidenceExport::hashOf($manifest), EvidenceExport::hashOf($stripped));
    }
}
