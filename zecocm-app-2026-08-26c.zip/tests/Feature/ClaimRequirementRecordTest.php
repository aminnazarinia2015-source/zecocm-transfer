<?php

namespace Tests\Feature;

use App\Domain\Claims\ClaimClock;
use App\Models\ClaimClockCalculation;
use App\Models\ClaimRequirement;
use App\Models\ClaimTriggerEvent;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * What the record must still be able to say two years later.
 *
 * The question in a dispute is rarely only "what was the deadline". It is
 * "what did this system tell the project team on 1 September, and on what
 * basis" - and a table that overwrites cannot answer it.
 */
class ClaimRequirementRecordTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;
    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-800', 'name' => 'Claim Clocks', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_confirmed_requirement_cannot_have_its_period_edited(): void
    {
        // Changing what the contract says after somebody relied on it is not an
        // edit. An amendment is a NEW requirement superseding this one.
        $requirement = $this->requirement();

        $this->expectException(\RuntimeException::class);
        $requirement->update(['period_value' => 5]);
    }

    public function test_a_confirmed_requirement_cannot_be_reclassified_as_administrative(): void
    {
        // The most dangerous edit available: quietly downgrading a
        // rights-preserving deadline into paperwork.
        $requirement = $this->requirement();

        $this->expectException(\RuntimeException::class);
        $requirement->update(['consequence_class' => ClaimClock::ADMINISTRATIVE]);
    }

    public function test_a_draft_requirement_is_still_freely_editable(): void
    {
        // The freeze is on confirmation, not on existence - somebody reading a
        // contract has to be able to work.
        $requirement = $this->requirement(['status' => 'draft', 'confirmed_at' => null]);
        $requirement->update(['period_value' => 15]);

        $this->assertSame(15, $requirement->fresh()->period_value);
    }

    public function test_a_clock_calculation_can_never_be_edited_or_deleted(): void
    {
        $calculation = $this->calculation();

        try {
            $calculation->update(['deadline_on' => '2026-12-31']);
            $this->fail('A clock calculation was edited.');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('record of what ZecoCM displayed', $e->getMessage());
        }

        $this->expectException(\RuntimeException::class);
        $calculation->delete();
    }

    public function test_a_corrected_trigger_writes_a_new_calculation_and_leaves_the_old_one_standing(): void
    {
        // The scenario the whole table exists for.
        $original = $this->calculation();

        $superseding = ClaimClockCalculation::create([
            'tenant_id' => $this->tenant->id,
            'claim_requirement_id' => $original->claim_requirement_id,
            'trigger_snapshot' => ['occurred_on' => '2026-08-23', 'status' => 'confirmed'],
            'authority_snapshot' => ['citation' => 'Contract s. 4.03', 'period_value' => 10],
            'authority_hash' => hash('sha256', 'authority-v1'),
            'deadline_on' => '2026-09-02',
            'state' => ClaimClock::ESTABLISHED,
            'reason' => 'The steward corrected the triggering date from 25 August to 23 August.',
            'calculated_at' => now(),
            'supersedes_calculation_id' => $original->id,
        ]);

        // Both survive, and the older one still says what the screen said then.
        $this->assertSame('2026-09-04', $original->fresh()->deadline_on->toDateString());
        $this->assertSame('2026-09-02', $superseding->deadline_on->toDateString());
        $this->assertSame($original->id, $superseding->supersedes_calculation_id);
        $this->assertSame(2, ClaimClockCalculation::where('claim_requirement_id', $original->claim_requirement_id)->count());
    }

    public function test_a_trigger_is_only_countable_once_somebody_confirms_it(): void
    {
        $trigger = ClaimTriggerEvent::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'event_type' => 'differing_condition_encountered',
            'occurred_on' => '2026-08-25',
            'status' => ClaimClock::TRIGGER_UNRESOLVED,
        ]);

        $this->assertFalse($trigger->isCountable());

        $trigger->update(['status' => ClaimClock::TRIGGER_CONFIRMED,
            'confirmed_by' => $this->user->id, 'confirmed_at' => now()]);

        $this->assertTrue($trigger->fresh()->isCountable());
    }

    private function requirement(array $overrides = []): ClaimRequirement
    {
        return ClaimRequirement::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'requirement_type' => 'differing_site_condition_notice',
            'title' => 'Written notice of differing site condition',
            'authority_type' => 'contract',
            'authority_citation' => 'Contract s. 4.03',
            'consequence_class' => ClaimClock::PRESERVATIVE,
            'trigger_type' => 'differing_condition_encountered',
            'period_value' => 10,
            'period_unit' => 'calendar_days',
            'calendar_rule' => 'calendar',
            'status' => 'confirmed',
            'confirmed_by' => $this->user->id,
            'confirmed_at' => now(),
        ], $overrides));
    }

    private function calculation(): ClaimClockCalculation
    {
        return ClaimClockCalculation::create([
            'tenant_id' => $this->tenant->id,
            'claim_requirement_id' => $this->requirement()->id,
            'trigger_snapshot' => ['occurred_on' => '2026-08-25', 'status' => 'confirmed'],
            'authority_snapshot' => ['citation' => 'Contract s. 4.03', 'period_value' => 10],
            'authority_hash' => hash('sha256', 'authority-v1'),
            'deadline_on' => '2026-09-04',
            'state' => ClaimClock::ESTABLISHED,
            'reason' => 'Confirmed trigger, confirmed requirement.',
            'calculated_at' => now(),
        ]);
    }
}
