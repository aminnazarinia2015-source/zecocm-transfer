<?php

namespace Tests\Feature;

use App\Models\DailyReport;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\SignatureAttestation;
use App\Models\Submittal;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * A seal that can be quietly rewritten is not a seal.
 *
 * Three records in this codebase carried the word "sealed" or "append-only" in
 * their own comments while nothing enforced it: an RFI response, a submittal
 * stamp, and a worker's signature attestation. Each is a record a dispute turns
 * on, and each was silently mutable. These tests are the enforcement.
 */
class SealIntegrityTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Constructors', 'type' => 'Contractor',
            'status' => 'active', 'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend Levee Rehabilitation',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA',
            'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_sealed_rfi_response_cannot_be_silently_overwritten(): void
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(['project_id' => $this->project->id, 'number' => 'RFI-001',
            'subject' => 'Governing trench detail', 'question' => 'Which detail governs?',
            'raised_by_org' => 'Northgate Constructors', 'raised_at' => '2026-08-07',
            'ball_in_court' => 'City of Riverbend', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        $this->postJson("/api/rfis/{$rfi->id}/respond", ['response' => 'Detail 4 on sheet L-3 governs.'])->assertOk();

        // The second answer is refused outright. It does not land, and it does not
        // replace the first - which is the whole point.
        $this->postJson("/api/rfis/{$rfi->id}/respond", ['response' => 'Actually, detail 7 governs.'])
            ->assertStatus(409);

        TenantContext::set($this->tenant->id);
        $fresh = Rfi::find($rfi->id);
        $this->assertSame('Detail 4 on sheet L-3 governs.', $fresh->response);
        $this->assertNotNull($fresh->response_seal);
    }

    public function test_a_stamped_submittal_cannot_be_restamped(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['project_id' => $this->project->id, 'number' => 'SUB-001',
            'title' => 'Irrigation controller', 'spec_section' => '32 84 00', 'type' => 'product_data',
            'submitted_by_org' => 'Northgate Constructors', 'status' => 'under_review',
            'ball_in_court' => 'City of Riverbend', 'routing_history' => []]);
        TenantContext::clear();

        $this->postJson("/api/submittals/{$submittal->id}/stamp", ['action' => 'no_exceptions'])->assertOk();

        // Without the guard, this quietly turned a 'no exceptions taken' into a
        // 'rejected' with no record the reviewer ever said otherwise.
        $this->postJson("/api/submittals/{$submittal->id}/stamp", ['action' => 'rejected'])
            ->assertStatus(409);

        TenantContext::set($this->tenant->id);
        $fresh = Submittal::find($submittal->id);
        $this->assertSame('no_exceptions', $fresh->stamp['action']);
        $this->assertSame('no_exceptions', $fresh->status);
    }

    public function test_a_signature_attestation_cannot_be_updated_after_the_fact(): void
    {
        TenantContext::set($this->tenant->id);
        $report = DailyReport::create(['project_id' => $this->project->id, 'report_date' => '2026-08-07',
            'foreman_id' => $this->user->id, 'work_performed' => 'Trenching in landscape area.',
            'cost_code_notes' => [], 'corrections' => []]);
        $attestation = SignatureAttestation::create(['tenant_id' => $this->tenant->id,
            'daily_report_id' => $report->id, 'worker_code' => 'W-118', 'worker_name' => 'A. Worker',
            'language' => 'en', 'safety_training_received' => true, 'breaks_and_lunch_taken' => true,
            'signature_data' => 'signature-bytes', 'seal' => ['sealed_at' => '2026-08-07T15:04:00-07:00']]);

        // This is the exact mutation a wage-and-hour expert probes for: flipping a
        // break attestation after a claim is filed.
        $this->expectException(\LogicException::class);
        $attestation->update(['breaks_and_lunch_taken' => false]);
    }

    public function test_a_signature_attestation_cannot_be_deleted(): void
    {
        TenantContext::set($this->tenant->id);
        $report = DailyReport::create(['project_id' => $this->project->id, 'report_date' => '2026-08-08',
            'foreman_id' => $this->user->id, 'work_performed' => 'Backfill.',
            'cost_code_notes' => [], 'corrections' => []]);
        $attestation = SignatureAttestation::create(['tenant_id' => $this->tenant->id,
            'daily_report_id' => $report->id, 'worker_code' => 'W-119', 'worker_name' => 'B. Worker',
            'language' => 'es', 'safety_training_received' => true, 'breaks_and_lunch_taken' => true,
            'signature_data' => 'signature-bytes', 'seal' => []]);

        $this->expectException(\LogicException::class);
        $attestation->delete();
    }
}
