<?php

namespace Tests\Feature;

use App\Domain\Knowledge\Ocr\ExtractionReliability;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourcePage;
use App\Models\Membership;
use App\Models\OcrExtractionAttempt;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\Support\BuildsOcrFixtures;
use Tests\TestCase;

/**
 * VIS-1 (low-quality scan recovery), per Codex's ruling on
 * claude/trace-visual-drawing-reading-design-brief.md: a poor scan gets
 * multiple bounded, deterministic recovery attempts, every attempt is
 * recorded (never overwritten), and a deterministic rule - never "whichever
 * ran last" - selects the winner. These tests run the real `convert`
 * (ImageMagick) and `tesseract` binaries against real degraded fixtures, the
 * same discipline D4OcrIngestionTest already established for this pipeline.
 */
class Vis1ScanRecoveryTest extends TestCase
{
    use BuildsOcrFixtures, RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        $this->tearDownOcrFixtures();
        TenantContext::clear();
        parent::tearDown();
    }

    private function ingest(string $path, string $mime, string $clientName = 'upload.png'): array
    {
        $response = $this->postJson('/api/knowledge/sources', [
            'project_id' => $this->project->id, 'collection' => 'project', 'corpus' => 'project_plans',
            'title' => 'Test document', 'source_type' => 'drawing', 'authority_level' => 'project_contract',
            'file' => $this->uploadedFile($path, $clientName, $mime),
        ]);
        $response->assertStatus(201);

        return $response->json();
    }

    private function resolveSource(array $result): KnowledgeSource
    {
        TenantContext::set($this->tenant->id);

        return KnowledgeSource::query()->findOrFail($result['source']['id']);
    }

    /** A degraded scan produces MULTIPLE recorded recovery attempts, never just the one that happened to win. */
    public function test_degraded_scan_produces_multiple_recorded_attempts(): void
    {
        $image = $this->degradedScannedImage('Retention basis five percent per section 00700 verified for pay application fourteen');
        $result = $this->ingest($image, 'image/png');
        $source = $this->resolveSource($result);
        $version = $source->versions()->firstOrFail();

        $attempts = OcrExtractionAttempt::query()
            ->where('knowledge_source_version_id', $version->id)
            ->orderBy('attempt_ordinal')
            ->get();

        // The degraded fixture is tuned to NOT be reliable on the very first
        // (baseline) attempt, so the pipeline must have kept going rather
        // than stopping after one try.
        $this->assertGreaterThan(1, $attempts->count());

        // Every attempt is append-only and ordinal-ordered, starting at 1
        // with no gaps - the full chain is reconstructable, not just the
        // winner.
        foreach ($attempts as $i => $attempt) {
            $this->assertSame($i + 1, $attempt->attempt_ordinal);
            $this->assertNotNull($attempt->reliability);
        }

        // Exactly one attempt is marked selected - a single, deterministic
        // winner, never zero and never more than one.
        $this->assertSame(1, $attempts->where('selected', true)->count());
    }

    /** The winning attempt is the one the page's own fields were actually populated from - traceable, not just asserted. */
    public function test_selected_attempt_matches_the_pages_own_recorded_fields(): void
    {
        $image = $this->degradedScannedImage('Retention basis five percent per section 00700 verified for pay application fourteen');
        $result = $this->ingest($image, 'image/png');
        $source = $this->resolveSource($result);
        $version = $source->versions()->firstOrFail();

        $page = KnowledgeSourcePage::query()->where('knowledge_source_version_id', $version->id)->firstOrFail();
        $this->assertSame('ocr', $page->extraction_method);
        $this->assertNotNull($page->ocr_extraction_attempt_id);

        $selected = OcrExtractionAttempt::query()->findOrFail($page->ocr_extraction_attempt_id);
        $this->assertTrue((bool) $selected->selected);
        $this->assertSame(round((float) $page->extraction_confidence, 4), round((float) $selected->mean_confidence, 4));
        $this->assertNotNull($selected->image_sha256);

        // VIS-1C: the winning attempt carries the "VisualPageAsset" facts
        // (exact image bytes hash, dimensions, transform chain, DPI) a later
        // vision-model feature needs to resolve coordinates against - this is
        // the abstraction Codex asked to be exposed now.
        $this->assertNotNull($selected->image_width);
        $this->assertNotNull($selected->image_height);
        $this->assertIsArray($selected->transform_sequence);
    }

    /** A clean scan reads reliably on the first attempt - recovery never runs attempts it doesn't need. */
    public function test_clean_scan_stops_after_the_first_reliable_attempt(): void
    {
        $image = $this->scannedImage('GENERAL NOTES All work per contract documents applies here today.');
        $result = $this->ingest($image, 'image/png');
        $source = $this->resolveSource($result);
        $version = $source->versions()->firstOrFail();

        $attempts = OcrExtractionAttempt::query()->where('knowledge_source_version_id', $version->id)->get();

        $this->assertCount(1, $attempts);
        $this->assertSame('baseline', $attempts->first()->label);
        $this->assertTrue((bool) $attempts->first()->selected);
        $this->assertSame('reliable', $attempts->first()->reliability);
    }

    /** The final classification is always one of D4's three real reliability tiers - never something invented to make a hard case look resolved. */
    public function test_recovered_page_still_classifies_as_one_of_the_three_real_reliability_tiers(): void
    {
        $image = $this->degradedScannedImage('Retention basis five percent per section 00700 verified for pay application fourteen');
        $result = $this->ingest($image, 'image/png');
        $source = $this->resolveSource($result);
        $version = $source->versions()->firstOrFail();
        $page = KnowledgeSourcePage::query()->where('knowledge_source_version_id', $version->id)->firstOrFail();

        $reliability = ExtractionReliability::classify(
            $page->extraction_method,
            $page->extraction_confidence !== null ? (float) $page->extraction_confidence : null,
            (bool) $page->has_structural_defect,
        );

        $this->assertContains($reliability, ['reliable', 'review_recommended', 'unreliable']);
    }
}
