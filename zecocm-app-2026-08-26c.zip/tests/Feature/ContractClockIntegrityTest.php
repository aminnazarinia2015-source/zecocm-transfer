<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * A contract clock is a term of somebody's contract. ZecoCM may read it, compute with it
 * and print it — it may never invent one.
 *
 * This guards a defect found during the first live sweep: project creation discarded the
 * clocks the caller sent and wrote a fixed set of its own (submittal 14 calendar days,
 * RFI 5 working days). The decision envelope and the issued transmittal then printed those
 * invented periods under the words "the contract governs, not a system default", and a due
 * date computed from them would have gone to an owner agency on a real document.
 */
class ContractClockIntegrityTest extends TestCase
{
    use RefreshDatabase;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $tenant = Tenant::create(['name' => 'Clock CM', 'type' => 'CM firm', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('CM firm'), 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $tenant->id, 'name' => 'PM',
            'email' => 'pm@clock.test', 'password' => bcrypt('password')]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    private function payload(array $extra = []): array
    {
        return array_merge([
            'number' => 'C-1', 'name' => 'Clock Project', 'sector' => 'public',
            'owner_name' => 'City of Clocks',
        ], $extra);
    }

    public function test_the_clocks_the_caller_states_are_the_clocks_that_are_stored(): void
    {
        $id = $this->postJson('/api/projects', $this->payload(['contract_clocks' => [
            'rfi_response' => ['days' => 10, 'basis' => 'working', 'source' => 'Special Provisions 3-7.2'],
            'submittal_review' => ['days' => 21, 'basis' => 'calendar', 'source' => 'General Conditions 5.4'],
        ]]))->assertStatus(201)->json('id');

        TenantContext::set($this->user->tenant_id);
        $clocks = Project::findOrFail($id)->contract_clocks;
        TenantContext::clear();

        $this->assertSame(10, $clocks['rfi_response']['days']);
        $this->assertSame('working', $clocks['rfi_response']['basis']);
        $this->assertSame('Special Provisions 3-7.2', $clocks['rfi_response']['source']);
        $this->assertSame(21, $clocks['submittal_review']['days']);
        $this->assertSame('calendar', $clocks['submittal_review']['basis']);
    }

    public function test_no_clock_is_invented_when_none_is_stated(): void
    {
        $id = $this->postJson('/api/projects', $this->payload(['number' => 'C-2']))
            ->assertStatus(201)->json('id');

        TenantContext::set($this->user->tenant_id);
        $project = Project::findOrFail($id);
        TenantContext::clear();

        $this->assertSame([], $project->contract_clocks,
            'A project with no stated contract clocks must have none. Inventing a period and '.
            'then printing it as a contract term is the worst thing this system can do.');

        $this->expectException(\RuntimeException::class);
        $project->clock('rfi_response');
    }

    public function test_a_malformed_clock_is_refused_rather_than_silently_normalised(): void
    {
        $this->postJson('/api/projects', $this->payload(['number' => 'C-3', 'contract_clocks' => [
            'rfi_response' => ['days' => 10, 'basis' => 'lunar'],
        ]]))->assertStatus(422);

        $this->postJson('/api/projects', $this->payload(['number' => 'C-4', 'contract_clocks' => [
            'rfi_response' => ['basis' => 'working'],
        ]]))->assertStatus(422);
    }
}
