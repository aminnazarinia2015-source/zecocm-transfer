<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Change orders over HTTP, and the two separations that matter.
 *
 * Approving a change order is a decision about the contract. Incorporating it
 * rewrites the schedule of values that every payment application bills against.
 * One click for both would mean nobody ever saw what the second one did.
 *
 * And adjusting an existing line has to say why the work belongs to that line's
 * scope, because added scope folded into a base line raises the cap - after
 * which the extra work is invisible, since cumulative billing looks normal
 * against a ceiling that moved.
 */
class ChangeOrderSurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;
    private ScheduleOfValueItem $line;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-700', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        $this->line = ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => '001', 'description' => 'Site utilities',
            'scheduled_value_cents' => 100_000_00, 'original_value_cents' => 100_000_00]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_approval_does_not_touch_the_schedule_of_values(): void
    {
        $id = $this->newOrder()['order']['id'];

        $body = $this->postJson('/api/change-orders/'.$id.'/approve',
            ['determination' => 'Approved at the 14 August progress meeting; differing site condition documented.'])
            ->assertOk()->json();

        $this->assertStringContainsString('has NOT changed yet', $body['notice']);
        $this->assertFalse($body['order']['incorporated']);

        // The billing ledger is untouched until somebody says so separately.
        $this->assertSame(100_000_00, $this->line->fresh()->scheduled_value_cents);
    }

    public function test_incorporation_moves_the_cap_and_leaves_the_original_visible(): void
    {
        $id = $this->newOrder()['order']['id'];
        $this->postJson('/api/change-orders/'.$id.'/approve', ['determination' => 'Approved.'])->assertOk();

        $body = $this->postJson('/api/change-orders/'.$id.'/incorporate')->assertOk()->json();

        $this->assertSame(1, $body['result']['created']);
        $this->assertSame(20_000_00, $body['result']['contract_delta_cents']);

        // The base line did not move, because the added scope got its own line.
        $this->assertSame(100_000_00, $this->line->fresh()->scheduled_value_cents);

        $index = $this->getJson('/api/change-orders?project_id='.$this->project->id)->assertOk()->json();
        $this->assertSame(100_000_00, $index['contract']['original_cents']);
        $this->assertSame(20_000_00, $index['contract']['approved_change_cents']);
        $this->assertSame(120_000_00, $index['contract']['current_cents']);
    }

    public function test_an_unapproved_change_order_cannot_be_incorporated(): void
    {
        $id = $this->newOrder()['order']['id'];

        $refusal = $this->postJson('/api/change-orders/'.$id.'/incorporate')->assertStatus(422)->json();

        $this->assertTrue($refusal['refused']);
        $this->assertStringContainsString('Only an approved change order', $refusal['reason']);
    }

    public function test_incorporating_twice_changes_nothing(): void
    {
        $id = $this->newOrder()['order']['id'];
        $this->postJson('/api/change-orders/'.$id.'/approve', ['determination' => 'Approved.'])->assertOk();
        $this->postJson('/api/change-orders/'.$id.'/incorporate')->assertOk();

        $again = $this->postJson('/api/change-orders/'.$id.'/incorporate')->assertOk()->json();

        $this->assertStringContainsString('Already incorporated', $again['notice']);
        $this->assertSame(0, $again['result']['created']);

        // Applying twice would inflate the contract sum silently, and the pay
        // application would then report a reconciliation failure nobody could
        // account for.
        $index = $this->getJson('/api/change-orders?project_id='.$this->project->id)->assertOk()->json();
        $this->assertSame(120_000_00, $index['contract']['current_cents']);
    }

    public function test_adjusting_a_base_line_without_saying_why_is_refused(): void
    {
        // The refusal that keeps the contract legible. Folded into a base line,
        // added scope raises the cap and stops being visible to every check
        // downstream.
        $created = $this->postJson('/api/change-orders', [
            'project_id' => $this->project->id, 'number' => 'CO-02', 'title' => 'Extra excavation',
            'amount_cents' => 15_000_00,
            'allocations' => [[
                'schedule_of_value_item_id' => $this->line->id, 'amount_cents' => 15_000_00,
            ]],
        ])->assertCreated()->json();

        $this->assertNotSame([], $created['refusals']);
        $this->assertStringContainsString('why the work belongs', implode(' ', $created['refusals']));

        $this->postJson('/api/change-orders/'.$created['order']['id'].'/approve', ['determination' => 'Approved.'])->assertOk();
        $this->postJson('/api/change-orders/'.$created['order']['id'].'/incorporate')->assertStatus(422);
    }

    public function test_allocations_must_account_for_every_dollar(): void
    {
        $created = $this->postJson('/api/change-orders', [
            'project_id' => $this->project->id, 'number' => 'CO-03', 'title' => 'Partial',
            'amount_cents' => 50_000_00,
            'allocations' => [['new_item_number' => '900', 'amount_cents' => 30_000_00]],
        ])->assertCreated()->json();

        $this->assertStringContainsString('Every dollar of a change order must land somewhere',
            implode(' ', $created['refusals']));
    }

    public function test_another_tenants_change_order_is_not_reachable(): void
    {
        $id = $this->newOrder()['order']['id'];

        $other = Tenant::create(['name' => 'Elsewhere', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        Sanctum::actingAs(User::create(['tenant_id' => $other->id, 'name' => 'Outsider',
            'email' => 'out@elsewhere.test', 'password' => bcrypt('password')]));

        $this->getJson('/api/change-orders/'.$id)->assertStatus(404);
    }

    private function newOrder(): array
    {
        return $this->postJson('/api/change-orders', [
            'project_id' => $this->project->id, 'number' => 'CO-01',
            'title' => 'Additional storm drain inlet', 'origin_reason' => 'differing site condition',
            'amount_cents' => 20_000_00, 'time_extension_days' => 3,
            'allocations' => [[
                'new_item_number' => '801',
                'new_item_description' => 'Storm drain inlet at STA 22+10',
                'amount_cents' => 20_000_00,
            ]],
        ])->assertCreated()->json();
    }
}
