<?php

namespace Tests\Feature;

use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\RefusalPolicy;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * The evaluation harness that did not exist.
 *
 * Every other knowledge test in this suite proves that gated content is
 * EXCLUDED. Not one proved that relevant content is FOUND - which is why a
 * four-character token filter shipped and silently deleted 'PVC', 'psi', every
 * dimension, and every segment of a CSI section number from every query.
 *
 * These are golden questions: a small corpus with known-correct answers, asked
 * the way a superintendent actually types. A change to tokenizing, chunking or
 * ranking that regresses recall fails here.
 */
class RetrievalQualityTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Constructors', 'type' => 'Contractor',
            'status' => 'active', 'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend Levee',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA',
            'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);

        $this->seedPassages([
            'Section 32 84 00 - Planting Irrigation. Mainline piping shall be PVC Schedule 40 '
                .'conforming to ASTM D1785, pressure rated at 200 psi minimum.',
            'Trenches for irrigation mainline shall be excavated to a depth of 24 in below finish '
                .'grade. Lateral lines shall have 12 in of cover.',
            'Detail 4 on sheet L-3 governs unsleeved piping crossings in landscape areas. Where a '
                .'crossing occurs under paving, sleeve per detail 7.',
            'Turfgrass establishment period shall be 90 calendar days from the date of acceptance '
                .'of the hydroseeding operation.',
            'Section 03 30 00 - Cast-in-Place Concrete. Compressive strength shall be 4000 psi at '
                .'28 days unless noted otherwise on the structural drawings.',
        ]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('goldenQuestions')]
    public function test_a_real_question_finds_the_passage_that_answers_it(string $question, string $mustContain): void
    {
        $found = $this->retrieve($question);

        $this->assertNotEmpty($found, "Nothing at all was retrieved for: {$question}");
        $bodies = array_map(fn ($p) => $p->text, $found);
        $hit = false;
        foreach ($bodies as $body) {
            if (str_contains(mb_strtolower($body), mb_strtolower($mustContain))) {
                $hit = true;
                break;
            }
        }
        $this->assertTrue($hit, "Retrieved {$question} but no result contained '{$mustContain}'. Got: ".implode(' || ', $bodies));
    }

    public static function goldenQuestions(): array
    {
        return [
            // Every one of these returned NOTHING under the four-character filter.
            'CSI section number' => ['what does section 32 84 00 require', '32 84 00'],
            'three-letter material' => ['what PVC schedule is the mainline', 'PVC Schedule 40'],
            'three-letter unit' => ['what psi rating is required for the mainline', '200 psi'],
            'dimension with short unit' => ['how deep is the irrigation trench in in', '24 in'],
            'sheet reference' => ['which detail governs on sheet L-3', 'sheet L-3'],
            // These worked before and must keep working.
            'ordinary words' => ['irrigation trench depth', 'excavated to a depth'],
            'establishment period' => ['how long is the turfgrass establishment period', '90 calendar days'],
        ];
    }

    public function test_the_right_section_outranks_a_section_that_merely_shares_a_unit(): void
    {
        // Both concrete and irrigation passages mention 'psi'. Asking by section
        // number must put the named section first, not whichever matched more words.
        $found = $this->retrieve('section 03 30 00 compressive strength');

        $this->assertNotEmpty($found);
        $this->assertStringContainsString('03 30 00', $found[0]->text,
            'A query naming a CSI section did not rank that section first.');
    }

    public function test_a_query_of_pure_stop_words_retrieves_nothing_rather_than_everything(): void
    {
        $this->assertSame([], $this->retrieve('what is it about'));
    }

    public function test_the_categories_that_decide_money_and_liability_are_escalated(): void
    {
        $policy = new RefusalPolicy;

        foreach (['structural_adequacy', 'life_safety', 'code_equivalency',
            'differing_site_conditions', 'means_and_methods', 'cost_quantum',
            'schedule_causation', 'safety_direction'] as $category) {
            $this->assertTrue($policy->mustEscalate($category), "{$category} must escalate.");
        }

        $this->assertFalse($policy->mustEscalate('document_lookup'));
    }

    /**
     * Codex's attack table for SEC-1, run as tests rather than taken on trust.
     * A gate that opens on the string "false" is not a gate.
     */
    #[\PHPUnit\Framework\Attributes\DataProvider('nonAuthorizingValues')]
    public function test_only_a_real_boolean_true_opens_the_evidence_gate(mixed $value): void
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        if ($value !== '__absent__') {
            request()->attributes->set('authorized_evidence_read', $value);
        }
        $found = (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $this->project->jurisdictionScope());
        TenantContext::clear();

        $this->assertSame([], $found, 'A non-true value opened the evidence gate.');
    }

    public static function nonAuthorizingValues(): array
    {
        return [
            'key absent entirely' => ['__absent__'],
            'boolean false' => [false],
            'null' => [null],
            'string false' => ['false'],
            'string zero' => ['0'],
            'integer zero' => [0],
            'integer one' => [1],
            'string yes' => ['yes'],
            'string true' => ['true'],
            'non-empty array' => [['documents.view']],
            'object' => [new \stdClass],
        ];
    }

    public function test_retrieval_returns_nothing_unless_evidence_reading_was_explicitly_authorized(): void
    {
        // Being allowed to ASK is not being allowed to READ. A caller that
        // authorizes the project but never authorizes a document read gets
        // nothing - the gate fails closed, so a future caller cannot obtain
        // evidence by forgetting to check.
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', false);
        $found = (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $this->project->jurisdictionScope());
        TenantContext::clear();

        $this->assertSame([], $found);
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    /** @param list<string> $bodies */
    private function seedPassages(array $bodies): void
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'project',
            'title' => 'Riverbend Project Specifications', 'source_type' => 'specification',
            'jurisdiction' => 'CA', 'discipline' => 'landscape', 'authority_level' => 'project_contract',
            'access_classification' => 'project_private', 'verification_status' => 'verified',
            'ingestion_status' => 'ready', 'mime_type' => 'text/plain', 'storage_path' => 'test/spec',
            'byte_size' => 1, 'sha256' => str_repeat('a', 64), 'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create([
            'knowledge_source_id' => $source->id, 'version_number' => 1, 'edition' => '2026',
            'sha256' => str_repeat('a', 64), 'extraction_method' => 'plain-text', 'extraction_confidence' => 1.0,
            'parser_version' => 'test', 'classification' => ['corpora' => ['project_specs']],
            'storage_path' => 'test/spec', 'mime_type' => 'text/plain', 'byte_size' => 1,
            'malware_scan_status' => 'clean']);

        foreach ($bodies as $i => $body) {
            KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
                'knowledge_source_version_id' => $version->id, 'ordinal' => $i + 1, 'body' => $body,
                'body_sha256' => hash('sha256', $body)]);
        }
    }
}
