<?php

namespace Tests\Feature;

use App\Domain\Compliance\PrevailingWageDetermination;
use App\Domain\Payment\PayApplicationReview;
use App\Domain\Payment\RetentionRule;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Why an application gets bounced, sorted by what bouncing it means.
 *
 * The severity split is legal, not cosmetic. Under Public Contract Code
 * s. 20104.50 an agency must return an IMPROPER payment request with written
 * reasons within seven days; an otherwise proper, undisputed request starts the
 * thirty-day payment clock. So whether a defect makes the request improper,
 * merely returnable, or simply reduces the amount decides which clock is running -
 * and a contractor who believes the thirty-day clock started when it did not will
 * wait a month for money that was never coming.
 */
class PayApplicationReviewTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_an_application_with_no_schedule_of_values_basis_is_structurally_improper(): void
    {
        $app = $this->application();

        $findings = PayApplicationReview::findings($app);

        $this->assertSame('no_sov_basis', $findings[0]['code']);
        $this->assertSame(PayApplicationReview::HARD_INVALID, $findings[0]['severity']);
        $this->assertTrue(PayApplicationReview::blocksSubmission($findings));
    }

    public function test_a_contract_sum_that_does_not_reconcile_is_caught_before_the_agency_catches_it(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $findings = PayApplicationReview::findings($app, null, [
            'original_contract_cents' => 10_000_000,
            'approved_change_orders_cents' => 500_000,
            'current_contract_cents' => 11_000_000,   // $5,000 unaccounted for
        ]);

        $codes = array_column($findings, 'code');
        $this->assertContains('contract_sum_does_not_reconcile', $codes);
        $finding = collect($findings)->firstWhere('code', 'contract_sum_does_not_reconcile');
        $this->assertStringContainsString('$5,000.00', $finding['message']);
    }

    public function test_change_order_work_billed_before_approval_is_refused(): void
    {
        // Caltrans does not pay added item work before the change order is
        // executed, and hiding it inside an original line is how an honest change
        // turns into a false-claim allegation.
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $findings = PayApplicationReview::findings($app, null, [
            'unapproved_change_order_line_numbers' => ['004'],
        ]);

        $finding = collect($findings)->firstWhere('code', 'unapproved_change_billed');
        $this->assertNotNull($finding);
        $this->assertSame(PayApplicationReview::HARD_INVALID, $finding['severity']);
        $this->assertStringContainsString('worse than billing it openly', $finding['message']);
    }

    public function test_billing_that_silently_decreases_must_be_recorded_as_an_adjustment(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, previous: 3_000_000, thisPeriod: 500_000);

        $findings = PayApplicationReview::findings($app, null, [
            'previous_application_completed_cents' => 4_000_000,
        ]);

        $finding = collect($findings)->firstWhere('code', 'billing_decreased_without_adjustment');
        $this->assertNotNull($finding);
        $this->assertStringContainsString('reads as concealment', $finding['message']);
    }

    public function test_retention_that_disagrees_with_the_governing_rule_is_structurally_improper(): void
    {
        // The application says 10%; the governing rule says 5%. The agency will
        // reconcile this line and return the request.
        $app = $this->application(retentionBasisPoints: 1000);
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $findings = PayApplicationReview::findings($app, RetentionRule::californiaPublicWorksDefault());

        $finding = collect($findings)->firstWhere('code', 'retention_basis_inconsistent');
        $this->assertNotNull($finding);
        $this->assertSame(PayApplicationReview::HARD_INVALID, $finding['severity']);
    }

    public function test_retention_above_the_statutory_cap_is_a_finding_not_a_preference(): void
    {
        $app = $this->application(retentionBasisPoints: 1000);
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $findings = PayApplicationReview::findings($app, new RetentionRule(1000, 'General Conditions 9.3', confirmed: true));

        $finding = collect($findings)->firstWhere('code', 'retention_above_statutory_cap');
        $this->assertNotNull($finding);
        $this->assertStringContainsString('7201', $finding['citation']);
    }

    public function test_an_unconfirmed_retention_rule_is_returnable_not_fatal(): void
    {
        // Worth stopping someone over. Not worth telling them their application is
        // structurally improper.
        $app = $this->application(retentionBasisPoints: 500);
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $findings = PayApplicationReview::findings($app, RetentionRule::californiaPublicWorksDefault());

        $finding = collect($findings)->firstWhere('code', 'retention_rule_unconfirmed');
        $this->assertNotNull($finding);
        $this->assertSame(PayApplicationReview::RETURNABLE, $finding['severity']);
        $this->assertFalse(PayApplicationReview::blocksSubmission([$finding]));
    }

    public function test_unsupported_stored_material_is_returnable(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000, stored: 200_000);

        $findings = PayApplicationReview::findings($app, null, [
            'stored_material_line_numbers_without_evidence' => ['002'],
            'stored_material_line_numbers_without_sov' => ['003'],
        ]);

        $codes = array_column($findings, 'code');
        $this->assertContains('stored_material_unsupported', $codes);
        $this->assertContains('stored_material_untied', $codes);
        foreach ($findings as $f) {
            if (str_starts_with($f['code'], 'stored_material')) {
                $this->assertSame(PayApplicationReview::RETURNABLE, $f['severity']);
            }
        }
    }

    public function test_a_clean_application_with_a_confirmed_rule_has_no_findings(): void
    {
        $app = $this->application(retentionBasisPoints: 500);
        $this->line($app, scheduled: 10_000_000, thisPeriod: 1_000_000);

        $rule = new RetentionRule(500, 'General Conditions 9.3.1', confirmed: true);

        $this->assertSame([], PayApplicationReview::findings($app, $rule));
    }

    /**
     * Codex's test, written to its numbers.
     *
     * "Base SOV line has $100,000 authorized. Contractor has earned $70,000 of
     * original scope and performed $20,000 of pending CO work. Application
     * attempts to bill $90,000 against the original line. Reject $20,000 as
     * unauthorized change value even though cumulative billing remains below the
     * $100,000 line cap. That catches a real-world abuse that a simple overbilling
     * validator will miss."
     */
    public function test_unapproved_change_value_hidden_below_the_line_cap_is_caught(): void
    {
        $app = $this->application();
        $item = ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => '100', 'description' => 'Site concrete',
            'scheduled_value_cents' => 10_000_000,   // $100,000 authorized
            'original_value_cents' => 10_000_000,
        ]);
        PayApplicationLine::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $app->id,
            'schedule_of_value_item_id' => $item->id,
            'previous_completed_cents' => 0,
            'this_period_cents' => 9_000_000,        // $90,000 billed
            'pending_change_value_cents' => 2_000_000, // of which $20,000 is unapproved change work
        ]);
        $app->load('lines.item');

        $findings = PayApplicationReview::findings($app);

        // The over-billing validator is silent, and correctly so: $90,000 is under
        // the $100,000 cap. That is precisely why the cumulative check cannot be
        // the only check.
        $this->assertNotContains('line_over_authorized', array_column($findings, 'code'));

        $finding = collect($findings)->firstWhere('code', 'unauthorized_change_value_in_line');
        $this->assertNotNull($finding, 'Unapproved change value hid successfully inside an original line.');
        $this->assertSame(PayApplicationReview::HARD_INVALID, $finding['severity']);
        $this->assertStringContainsString('$20,000.00', $finding['message']);
        $this->assertStringContainsString('inside an original contract line', $finding['message']);
        $this->assertTrue(PayApplicationReview::blocksSubmission($findings));
    }

    public function test_the_same_work_billed_on_its_own_change_order_line_is_still_refused_until_approved(): void
    {
        // Putting it on the right line is better practice, but the work is still
        // not payable before the change order is executed.
        $app = $this->application();
        $item = ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => 'CO-1', 'description' => 'Added drainage',
            'scheduled_value_cents' => 2_000_000, 'original_value_cents' => 0,
            'change_order_id' => 42,
        ]);
        PayApplicationLine::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $app->id,
            'schedule_of_value_item_id' => $item->id,
            'this_period_cents' => 2_000_000, 'pending_change_value_cents' => 2_000_000,
        ]);
        $app->load('lines.item');

        $finding = collect(PayApplicationReview::findings($app))
            ->firstWhere('code', 'unauthorized_change_value_in_line');

        $this->assertNotNull($finding);
        // But it does not accuse them of hiding it.
        $this->assertStringNotContainsString('inside an original contract line', $finding['message']);
    }

    // ---- certified payroll reaches the payment review -------------------------

    public function test_a_missing_weekly_payroll_record_holds_the_payment_without_making_the_request_improper(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 100_000_00, thisPeriod: 40_000_00);

        $findings = PayApplicationReview::findings($app, null, [
            'certified_payroll' => ['context' => ['weeks_without_records' => ['2026-08-08']]],
        ]);

        $codes = array_column($findings, 'code');
        $this->assertContains('missing_weekly_record', $codes);

        $held = PayApplicationReview::withholdings($findings);
        $this->assertCount(1, $held);
        $this->assertSame(PayApplicationReview::WITHHOLD, $held[0]['severity']);

        // The whole point of the severity split: the money is held, the request
        // is still proper, and the thirty-day clock keeps running.
        $this->assertFalse(PayApplicationReview::blocksSubmission($findings));
    }

    public function test_underpayment_against_a_determination_is_reported_with_its_citation(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 100_000_00, thisPeriod: 10_000_00);

        $findings = PayApplicationReview::findings($app, null, [
            'certified_payroll' => [
                'records' => [[
                    'worker' => 'Worker A', 'classification' => 'Laborer Group 1',
                    'hours' => 40.0, 'hourly_paid_cents' => 3_000_00, 'fringe_paid_cents' => 500_00,
                ]],
                'determinations' => [
                    'Laborer Group 1' => new PrevailingWageDetermination(
                        craft: 'Laborer', classification: 'Laborer Group 1',
                        baseRateCents: 3_400_00, fringeCents: 900_00,
                        source: 'DIR determination LA-2026-1',
                    ),
                ],
            ],
        ]);

        $held = PayApplicationReview::withholdings($findings);
        $this->assertSame('paid_below_determination', $held[0]['code']);
        $this->assertSame('DIR determination LA-2026-1', $held[0]['citation']);
    }

    public function test_a_clean_payroll_adds_nothing_to_the_review(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 100_000_00, thisPeriod: 10_000_00);

        $findings = PayApplicationReview::findings($app, null, [
            'certified_payroll' => [
                'records' => [[
                    'worker' => 'Worker A', 'classification' => 'Laborer Group 1',
                    'hours' => 40.0, 'hourly_paid_cents' => 3_400_00, 'fringe_paid_cents' => 900_00,
                ]],
                'determinations' => [
                    'Laborer Group 1' => new PrevailingWageDetermination(
                        craft: 'Laborer', classification: 'Laborer Group 1',
                        baseRateCents: 3_400_00, fringeCents: 900_00,
                        source: 'DIR determination LA-2026-1',
                    ),
                ],
            ],
        ]);

        $this->assertSame([], PayApplicationReview::withholdings($findings));
    }

    private function application(int $retentionBasisPoints = 500): PayApplication
    {
        static $n = 0;
        $n++;

        return PayApplication::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => $n, 'period_from' => '2026-08-01', 'period_to' => '2026-08-31',
            'retention_basis_points' => $retentionBasisPoints,
        ]);
    }

    private function line(PayApplication $app, int $scheduled, int $previous = 0, int $thisPeriod = 0, int $stored = 0): void
    {
        static $i = 0;
        $i++;

        $item = ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => str_pad((string) $i, 3, '0', STR_PAD_LEFT),
            'description' => 'Line '.$i, 'scheduled_value_cents' => $scheduled,
            'original_value_cents' => $scheduled,
        ]);

        PayApplicationLine::create([
            'tenant_id' => $this->tenant->id, 'pay_application_id' => $app->id,
            'schedule_of_value_item_id' => $item->id,
            'previous_completed_cents' => $previous, 'this_period_cents' => $thisPeriod,
            'stored_materials_cents' => $stored,
        ]);

        $app->load('lines.item');
    }
}
