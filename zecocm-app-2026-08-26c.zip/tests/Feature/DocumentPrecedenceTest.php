<?php

namespace Tests\Feature;

use App\Domain\Ai\DocumentPrecedence;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * Which document governs when two of them disagree - at the RETRIEVAL layer.
 *
 * This is the integration half of authority resolution and it predates
 * AuthorityResolution, which is the unit half. Keep both: this one proves the
 * ranking actually reaches the retriever and that a governing document is not
 * buried by one that merely mentions the subject more often. The other proves
 * the three-condition decision procedure - operative, applicable, authorised to
 * prevail - on which the ranking is only one input.
 *
 * (Renamed from AuthorityResolutionTest when TR-17 landed, because the name was
 * needed for the decision procedure and this file was very nearly lost to that
 * collision.)
 *
 * Raised by Codex: "Construction records frequently contain simultaneously valid
 * but hierarchically different documents. The system has to distinguish newer from
 * controlling." Specified by Zeco's own Greenbook AI Deployment Policy section 5.
 *
 * The failure this prevents is concrete: an addendum changes a trench depth, the
 * original spec still says the old number, and lexical retrieval returns the spec
 * because it says "trench depth" more often. The contractor builds to the
 * superseded requirement and pays for it.
 */
class DocumentPrecedenceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_an_addendum_outranks_the_specification_it_amended_even_when_the_spec_matches_more_words(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Riverbend Project Specifications',
            'Irrigation mainline trench depth shall be 24 in below finish grade. Trench depth for '
            .'laterals is 18 in. Trench depth measurements are taken at finish grade.');
        $this->seedSource('addendum', 'Addendum No. 2',
            'Section 32 84 00 is revised: irrigation mainline trench depth shall be 36 in.');
        TenantContext::clear();

        $found = $this->retrieve('irrigation mainline trench depth');

        $this->assertNotEmpty($found);
        $this->assertSame('Addendum No. 2', $found[0]->source,
            'The superseded specification outranked the addendum that amended it.');
        $this->assertStringContainsString('36 in', $found[0]->text);
    }

    public function test_the_conflict_is_reported_rather_than_silently_resolved(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Riverbend Project Specifications', 'Trench depth shall be 24 in.');
        $this->seedSource('addendum', 'Addendum No. 2', 'Trench depth shall be 36 in.');
        TenantContext::clear();

        $found = $this->retrieve('trench depth');
        $verdict = HybridKnowledgeRetriever::precedenceConflict($found);

        // Both documents come back. The lower-ranked one is not dropped - a human
        // has to see that the spec still says something different.
        $this->assertTrue($verdict['conflict']);
        $this->assertSame('Addendum No. 2', $verdict['governing']->source);
        $this->assertCount(1, $verdict['subordinate']);
        $this->assertSame('Riverbend Project Specifications', $verdict['subordinate'][0]->source);
    }

    public function test_the_contracts_own_order_of_precedence_governs_over_our_default(): void
    {
        // This contract puts Standard Specifications ABOVE the plans - unusual, and
        // exactly the sort of term that decides a dispute. The contract wins.
        TenantContext::set($this->tenant->id);
        $this->project->update(['org_structure' => ['precedence' => [
            'Addenda', 'Standard Specifications', 'Plans',
        ]]]);
        $precedence = DocumentPrecedence::forProject($this->project->fresh());
        TenantContext::clear();

        $this->assertTrue($precedence->governs('specification', 'drawing'));
        $this->assertTrue($precedence->governs('addendum', 'specification'));
        $this->assertTrue($precedence->contractSpecified($this->project->fresh()));
    }

    public function test_the_default_order_applies_when_the_contract_recorded_none(): void
    {
        $precedence = new DocumentPrecedence;

        $this->assertTrue($precedence->governs('contract', 'addendum'));
        $this->assertTrue($precedence->governs('addendum', 'specification'));
        $this->assertTrue($precedence->governs('drawing', 'specification'));
        $this->assertTrue($precedence->governs('specification', 'manufacturer'));
        $this->assertFalse($precedence->contractSpecified($this->project));
    }

    public function test_an_unrecognised_document_type_never_outranks_a_known_one(): void
    {
        // Silence is not promotion. A document we cannot classify sorts last.
        $precedence = new DocumentPrecedence;

        $this->assertTrue($precedence->governs('correspondence', 'something_we_have_never_seen'));
        $this->assertTrue($precedence->governs('contract', null));
    }

    /**
     * Codex's attack list, run as tests. Every one of these is language that
     * actually appears in public works contracts.
     */
    public function test_real_contract_labels_map_to_the_right_instrument(): void
    {
        $cases = [
            'Supplementary Conditions' => 'special_provisions',
            'Special Conditions' => 'special_provisions',
            'General Conditions' => 'special_provisions',
            'Technical Specifications' => 'specification',
            'Project Manual' => 'specification',
            'Standard Specifications and Standard Plans' => 'specification',
            'Issued-for-Construction Drawings' => 'drawing',
            'Approved Shop Drawings' => 'drawing',
            'Construction Change Directives' => 'rfi_response',
            'Field Orders' => 'rfi_response',
            'Owner Directives' => 'rfi_response',
            'Division 00' => 'contract',
            'The Agreement' => 'contract',
            'Addenda' => 'addendum',
            'Written interpretations' => 'addendum',
        ];

        foreach ($cases as $label => $expected) {
            [$type, $method, $confidence] = DocumentPrecedence::classifyLabel($label);
            $this->assertSame($expected, $type, "'{$label}' mapped to '{$type}', expected '{$expected}'");
            $this->assertSame('exact_alias', $method, "'{$label}' was guessed at rather than known.");
            $this->assertSame(1.0, $confidence);
        }
    }

    public function test_contract_drawings_is_a_drawing_and_not_the_executed_agreement(): void
    {
        // The bug Codex caught. Matching "contract" before "drawing" classified
        // "Contract Drawings" as the executed agreement, which would have ranked
        // every plan sheet at the very top of precedence - above the addenda that
        // amend them.
        [$type, $method] = DocumentPrecedence::classifyLabel('Contract Drawings');

        $this->assertSame('drawing', $type);
        $this->assertSame('exact_alias', $method);
    }

    public function test_a_label_we_cannot_map_is_flagged_for_a_steward_not_guessed_into_the_order(): void
    {
        TenantContext::set($this->tenant->id);
        $this->project->update(['org_structure' => ['precedence' => [
            'Addenda', 'Some Bespoke Instrument Nobody Has Seen', 'Plans',
        ]]]);
        $precedence = DocumentPrecedence::forProject($this->project->fresh());
        TenantContext::clear();

        $this->assertContains('Some Bespoke Instrument Nobody Has Seen', $precedence->needsClassification());
        // The labels we DID recognise still order correctly around it.
        $this->assertTrue($precedence->governs('addendum', 'drawing'));
    }

    public function test_a_governing_document_that_merely_mentions_the_subject_does_not_bury_the_one_that_answers(): void
    {
        // Codex's silence case: nothing in the contract addresses PVC solvent weld
        // curing; the incorporated manufacturer instructions do. Authority must not
        // promote a passing mention above the only responsive document.
        TenantContext::set($this->tenant->id);
        $this->seedSource('contract', 'Executed Contract A-9764',
            'The Contractor shall furnish all PVC pipe in accordance with the specifications.');
        $this->seedSource('manufacturer', 'Solvent Weld Manufacturer Instructions',
            'Solvent weld joints require a minimum curing time of 24 hours before pressure '
            .'testing. Curing time for solvent weld joints increases below 60 degrees. Do not '
            .'disturb solvent weld curing joints during the curing period.');
        TenantContext::clear();

        $found = $this->retrieve('solvent weld curing time');

        $this->assertNotEmpty($found);
        $this->assertSame('Solvent Weld Manufacturer Instructions', $found[0]->source,
            'A contract that merely mentions PVC buried the only document that answers the question.');
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function seedSource(string $sourceType, string $title, string $body): void
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project', 'title' => $title,
            'source_type' => $sourceType, 'jurisdiction' => 'CA', 'discipline' => 'landscape',
            'authority_level' => 'project_contract', 'access_classification' => 'project_private',
            'verification_status' => 'verified', 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$sourceType, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2026', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['project_specs']], 'storage_path' => 'test/'.$sourceType,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
    }
}
