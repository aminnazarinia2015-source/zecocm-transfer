<?php

namespace Tests\Feature;

use App\Domain\Autonomy\AutonomyLevel;
use App\Domain\Autonomy\PayAppRollforwardEvaluator;
use App\Models\AutonomousAction;
use App\Models\AutonomyPolicy;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * AUTO-2's fourth seeded action, built on Amin's direct product override
 * (2026-08-26) of the "wait for PN 851 usage evidence" sequencing, per
 * Codex's narrowed ruling: "create draft shell from last certified
 * application... organizational work, not financial judgment." See
 * claude/auto2-pay-app-automation-design-brief.md.
 *
 * What this test suite defends: the shell this action creates carries
 * forward exactly one settled fact (each line's previous-completed total)
 * and nothing else - no invented current-period billing, no carried-forward
 * stored material, no pending change-order amounts. And the trigger fires
 * only on an observed, already-true fact (the prior cycle closed), never on
 * a guess about a billing calendar.
 */
class PayAppRollforwardEvaluatorTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-851', 'name' => 'Rollforward', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_with_no_prior_pay_application_at_all_no_action_is_produced(): void
    {
        $this->policy(AutonomyLevel::AUTO);

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNull($result);
        $this->assertSame(0, AutonomousAction::count());
    }

    public function test_a_draft_latest_application_produces_no_action(): void
    {
        $this->policy(AutonomyLevel::AUTO);
        $this->application(status: 'draft');

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNull($result);
        $this->assertSame(1, PayApplication::count(), 'no second application should be created');
    }

    public function test_a_rejected_latest_application_produces_no_action(): void
    {
        // A rejection needs a human to look at why before another shell is
        // stacked on top of it - excluded from CLOSED_STATUSES on purpose.
        $this->policy(AutonomyLevel::AUTO);
        $this->application(status: 'rejected');

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNull($result);
        $this->assertSame(1, PayApplication::count());
    }

    public function test_a_certified_latest_application_with_no_policy_is_recorded_pending_approval_and_no_shell_is_created(): void
    {
        // Default-closed: pay_app_draft_rollforward's system ceiling is AUTO,
        // but with no explicit project policy row the resolver still fails
        // to APPROVAL_REQUIRED - "never automate away accountability."
        $prior = $this->application(status: 'certified');
        $this->line($prior, scheduled: 10_000_000, previous: 4_000_000, thisPeriod: 2_000_000, stored: 500_000);

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNotNull($result['action']);
        $this->assertSame('pending_approval', $result['action']->status);
        $this->assertSame(1, PayApplication::count(), 'no shell should be created above APPROVAL_REQUIRED');
    }

    public function test_a_certified_latest_application_with_auto_policy_creates_the_next_draft_shell(): void
    {
        $this->policy(AutonomyLevel::AUTO);
        $prior = $this->application(status: 'certified', to: '2026-07-31');
        $this->line($prior, scheduled: 10_000_000, previous: 4_000_000, thisPeriod: 2_000_000, stored: 500_000);

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNotNull($result['action']);
        $this->assertSame('executed', $result['action']->status);

        $shell = PayApplication::where('project_id', $this->project->id)->where('number', $prior->number + 1)->first();
        $this->assertNotNull($shell, 'expected a new draft pay application to have been created');
        $this->assertSame('draft', $shell->status);
        $this->assertSame($result['action']->id, $shell->autonomous_action_id);
        $this->assertSame((int) $prior->retention_basis_points, (int) $shell->retention_basis_points);

        // Placeholder 30-day window starting the day after the prior period
        // closed - editable, not asserted.
        $this->assertSame('2026-08-01', $shell->period_from->toDateString());
        $this->assertSame('2026-08-30', $shell->period_to->toDateString());

        $shellLine = PayApplicationLine::where('pay_application_id', $shell->id)->first();
        $this->assertNotNull($shellLine);
        // The only figure carried forward: previous (4,000,000) + this_period
        // (2,000,000) from the closed cycle = 6,000,000. Nothing invented.
        $this->assertSame(6_000_000, (int) $shellLine->previous_completed_cents);
        $this->assertSame(0, (int) $shellLine->this_period_cents, 'no current-period billing may be invented');
        $this->assertSame(0, (int) $shellLine->stored_materials_cents, 'stored material is not carried forward as newly earned');
    }

    public function test_re_evaluating_after_the_shell_exists_produces_no_further_action(): void
    {
        $this->policy(AutonomyLevel::AUTO);
        $prior = $this->application(status: 'certified');
        $this->line($prior, scheduled: 10_000_000, previous: 4_000_000, thisPeriod: 2_000_000, stored: 0);

        $first = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);
        $second = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertNotNull($first['action']);
        // The newly created shell is itself a 'draft' application, so the
        // next evaluation's own "latest" lookup no longer qualifies -
        // exactly the same "no longer at-risk" shape CloseoutAutonomyEvaluator
        // already relies on, not a special case added for this action.
        $this->assertNull($second);
        $this->assertSame(1, AutonomousAction::where('action_type', PayAppRollforwardEvaluator::ACTION_TYPE)->count());
        $this->assertSame(2, PayApplication::count());
    }

    public function test_the_shells_autonomous_action_id_cannot_be_changed_once_set(): void
    {
        $this->policy(AutonomyLevel::AUTO);
        $prior = $this->application(status: 'certified');
        $this->line($prior, scheduled: 10_000_000, previous: 0, thisPeriod: 0, stored: 0);

        (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);
        $shell = PayApplication::where('number', $prior->number + 1)->firstOrFail();

        $this->expectException(\RuntimeException::class);
        $shell->update(['autonomous_action_id' => 999999]);
    }

    // ---- helpers ----------------------------------------------------------

    private function policy(string $level): AutonomyPolicy
    {
        return AutonomyPolicy::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'capability' => 'payment',
            'action_type' => PayAppRollforwardEvaluator::ACTION_TYPE,
            'autonomy_level' => $level,
            'authority_source' => 'test fixture',
            'set_by' => $this->user->id,
            'set_at' => now(),
            'effective_at' => now(),
            'status' => 'active',
        ]);
    }

    private function application(string $status = 'draft', string $from = '2026-07-01', string $to = '2026-07-31'): PayApplication
    {
        static $n = 0;
        $n++;

        return PayApplication::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'number' => $n,
            'period_from' => $from,
            'period_to' => $to,
            'status' => $status,
            'retention_basis_points' => 500,
        ]);
    }

    private function line(PayApplication $app, int $scheduled, int $previous, int $thisPeriod, int $stored): void
    {
        static $i = 0;
        $i++;

        $item = ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'item_number' => str_pad((string) $i, 3, '0', STR_PAD_LEFT),
            'description' => 'Line item '.$i,
            'scheduled_value_cents' => $scheduled,
            'original_value_cents' => $scheduled,
        ]);

        PayApplicationLine::create([
            'tenant_id' => $this->tenant->id,
            'pay_application_id' => $app->id,
            'schedule_of_value_item_id' => $item->id,
            'previous_completed_cents' => $previous,
            'this_period_cents' => $thisPeriod,
            'stored_materials_cents' => $stored,
        ]);
    }
}
