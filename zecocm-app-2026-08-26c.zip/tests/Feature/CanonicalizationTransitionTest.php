<?php

namespace Tests\Feature;

use App\Domain\Provenance\CanonicalizationTransition;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use RuntimeException;
use Tests\TestCase;

/**
 * Who is allowed to say why the evidence cannot be checked.
 *
 * The verifier may state that historical serialization cannot be reproduced
 * under the current protocol. It may not state that this was only a writer
 * defect and that no tampering occurred - that sentence requires knowing what
 * did NOT happen, and the only check that could establish it is the one that is
 * unavailable. A system that writes it anyway is authoring its own alibi.
 */
class CanonicalizationTransitionTest extends TestCase
{
    use RefreshDatabase;

    private User $steward;

    protected function setUp(): void
    {
        parent::setUp();
        $tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->steward = User::create(['tenant_id' => $tenant->id, 'name' => 'A. Steward',
            'email' => 'steward@northgate.test', 'password' => bcrypt('password')]);
    }

    public function test_a_finding_explains_nothing_until_a_named_person_signs_one(): void
    {
        $finding = $this->finding();

        $this->assertFalse($finding->isExplained());
        $this->assertSame('unavailable', $finding->content_verification_result);

        // The row records what was observed and carries no cause field at all -
        // there is nowhere for a machine to put a conclusion.
        $this->assertArrayNotHasKey('cause_classification', $finding->getAttributes());
    }

    public function test_re_running_the_verifier_re_observes_rather_than_multiplies(): void
    {
        $first = $this->finding();
        $second = $this->finding();

        $this->assertSame($first->id, $second->id);
        $this->assertSame(1, \App\Models\CanonicalizationFinding::count());
    }

    public function test_a_steward_supplies_the_part_the_machine_may_not(): void
    {
        $record = CanonicalizationTransition::explain(
            $this->finding(), $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_WRITER_DEFECT,
            'created_at and updated_at were not serialised identically on write and read before v2. Reviewed the writer at the releases spanning these records.',
            'v2',
            supportingReleaseEvidence: 'EV-13 canonicalization, v0.41',
        );

        $this->assertSame($this->steward->id, $record->authored_by);
        $this->assertNotEmpty($record->record_hash);
        $this->assertTrue($record->finding->isExplained());
    }

    public function test_undetermined_is_an_available_answer(): void
    {
        $record = CanonicalizationTransition::explain(
            $this->finding(), $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_UNDETERMINED,
            'The writer history for this period is not available to me. I am not able to establish the cause.',
            'v2',
        );

        $this->assertSame(CanonicalizationTransition::CAUSE_UNDETERMINED, $record->cause_classification);
    }

    public function test_a_recomputed_hash_is_stored_as_a_diagnostic_and_never_as_a_seal(): void
    {
        $record = CanonicalizationTransition::explain(
            $this->finding(), $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_WRITER_DEFECT, 'Reviewed.', 'v2',
            diagnosticRecomputedHash: str_repeat('a', 64),
        );

        // It lives on the transition record, which is a separate object from the
        // chain. Nothing about this writes into the ledger, and the original
        // seal is untouched.
        $this->assertSame(str_repeat('a', 64), $record->diagnostic_recomputed_hash);
        $this->assertDatabaseMissing('canonicalization_findings', ['content_verification_result' => 'verified']);
    }

    public function test_a_narrative_is_required(): void
    {
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('explains nothing');

        CanonicalizationTransition::explain($this->finding(), $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_WRITER_DEFECT, '   ', 'v2');
    }

    public function test_a_conclusion_that_changed_is_a_new_record_not_an_edited_one(): void
    {
        $finding = $this->finding();
        CanonicalizationTransition::explain($finding, $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_UNDER_INVESTIGATION, 'Looking into it.', 'v2');

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('already carries a transition record');

        CanonicalizationTransition::explain($finding->fresh(), $this->steward, 'Evidence steward',
            CanonicalizationTransition::CAUSE_WRITER_DEFECT, 'Now I am sure.', 'v2');
    }

    public function test_an_invented_cause_is_refused(): void
    {
        $this->expectException(RuntimeException::class);

        CanonicalizationTransition::explain($this->finding(), $this->steward, 'Evidence steward',
            'definitely_not_tampering', 'Trust me.', 'v2');
    }

    private function finding()
    {
        return CanonicalizationTransition::record([
            'chain_name' => 'Knowledge review events',
            'chain_group' => '2',
            'record_count' => 2,
            'mismatch_type' => 'payload_not_recomputable',
            'linkage_result' => 'verified',
            'content_verification_result' => 'unavailable',
            'verifier_version' => 'v2',
            'detected_at' => now(),
        ]);
    }
}
