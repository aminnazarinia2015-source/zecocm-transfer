<?php

namespace Tests\Feature;

use App\Domain\Evidence\DestructionCertificate;
use App\Domain\Evidence\EvidenceDestructionExecutor;
use App\Domain\Evidence\EvidenceDestructionService;
use App\Domain\Evidence\UnclassifiedRetentionException;
use App\Domain\Provenance\DigestAlgorithm;
use App\Models\DestructionLocationResult;
use App\Models\EvidenceStorageLocation;
use App\Models\EvidenceTombstone;
use App\Models\LegalHoldEvent;
use App\Models\MediaItem;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * EV-14B: verified destruction execution. Per Codex's ruling in the DATA-1
 * closure conversation and the design brief (claude/ev-14b-design-brief.md),
 * these are his own required cases, adapted to this codebase's actual
 * mechanics (an append-only execution ledger, not a mutable tombstone
 * state - EvidenceTombstone stays fixed forever per EV-14A's own guard).
 */
class Ev14bDestructionExecutionTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $actor;

    private Project $project;

    private string $storageRoot;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Riverbend GC', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->actor = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Records Officer',
            'email' => 'records@riverbend.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Levee', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        TenantContext::clear();

        $this->storageRoot = sys_get_temp_dir().'/ev14b-primary-'.bin2hex(random_bytes(6));
        mkdir($this->storageRoot, 0755, true);
        Config::set('filesystems.disks.local.root', $this->storageRoot);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        $this->rrmdir($this->storageRoot);
        parent::tearDown();
    }

    private function rrmdir(string $dir): void
    {
        if (! is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) ?: [] as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir.'/'.$item;
            is_dir($path) ? $this->rrmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }

    /**
     * Creates a media item AND writes its real bytes into the primary disk
     * at its storage_path, so the executor's own file operations are real.
     */
    private function mediaWithBytes(string $content, ?string $retentionClass = 'project_records:7_years'): MediaItem
    {
        $hash = DigestAlgorithm::digest($content);
        $path = 'media/sealed/'.substr($hash, 0, 2).'/'.$hash;
        Storage::disk('local')->put($path, $content);

        return MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => $hash, 'storage_path' => $path,
            'original_name' => 'evidence.jpg', 'mime' => 'image/jpeg', 'bytes' => strlen($content),
            'malware_scan_status' => 'clean', 'provenance' => [], 'provenance_signature' => 'x',
            'confidence' => 'strong', 'server_received_at' => now(), 'receipt_sequence' => 1,
            'capture_time_basis' => 'server_receipt', 'capture_finding' => 'consistent', 'client_claims' => [],
            'captured_by' => $this->actor->id, 'retention_class' => $retentionClass]);
    }

    /** Requests and authorizes destruction (no hold present), returning the resulting tombstone. */
    private function authorizedTombstone(MediaItem $media): EvidenceTombstone
    {
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'no longer needed');
        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2');

        return EvidenceTombstone::where('destruction_request_id', $result->id)->firstOrFail();
    }

    private function placeHold(): void
    {
        DB::table('legal_hold_events')->insert([
            'tenant_id' => $this->tenant->id,
            'hold_id' => (string) Str::uuid(),
            'event_type' => LegalHoldEvent::PLACED,
            'scope_type' => LegalHoldEvent::SCOPE_TENANT,
            'scope_value' => json_encode(['tenant_id' => $this->tenant->id]),
            'matter_reference' => 'Matter 2026-01',
            'actor_id' => $this->actor->id,
            'reason' => 'Pending litigation',
            'occurred_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    // ---- E14B-1: hold between authorization and execution --------------

    public function test_hold_between_authorization_and_execution_blocks_destruction(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes one');
        $tombstone = $this->authorizedTombstone($media);

        $this->placeHold();

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_BLOCKED_HOLD, $result['state']);
        $this->assertDatabaseCount('evidence_destruction_location_results', 0);
        $this->assertTrue(Storage::disk('local')->exists($media->storage_path));
    }

    // ---- E14B-2: hold after partial progress stops the rest, honestly --

    public function test_hold_after_partial_progress_stops_remaining_locations(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes two');
        $tombstone = $this->authorizedTombstone($media);

        // Simulate a prior pass having already cleared the primary location.
        DestructionLocationResult::create([
            'tenant_id' => $this->tenant->id,
            'evidence_tombstone_id' => $tombstone->id,
            'location_key' => 'primary',
            'attempted_at' => now(),
            'expected_digest' => $tombstone->digest,
            'pre_delete_presence' => true,
            'delete_result' => DestructionLocationResult::DELETED,
            'post_delete_presence' => false,
            'verification_method' => 'sha256_absence_check',
            'verified_at' => now(),
        ]);

        $this->placeHold();

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_STOPPED_PARTIAL_HOLD, $result['state']);
        // The earlier progress is preserved, not re-processed or lost.
        $this->assertDatabaseCount('evidence_destruction_location_results', 1);
    }

    // ---- E14B-3: fresh content-digest check before deleting -------------

    public function test_content_digest_mismatch_refuses_destruction(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('original evidence bytes');
        $tombstone = $this->authorizedTombstone($media);

        // Content at the path changed after authorization - must never be deleted as-if verified.
        Storage::disk('local')->put($media->storage_path, 'a different file entirely');

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_BLOCKED_CONTENT_MISMATCH, $result['state']);
        $this->assertTrue(Storage::disk('local')->exists($media->storage_path));
        $this->assertSame('a different file entirely', Storage::disk('local')->get($media->storage_path));
    }

    // ---- E14B-4: unexpectedly absent bytes are a discrepancy, not a success --

    public function test_unexpectedly_absent_file_is_flagged_not_treated_as_success(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes four');
        $tombstone = $this->authorizedTombstone($media);

        Storage::disk('local')->delete($media->storage_path);

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_DISCREPANCY_UNEXPECTED_ABSENCE, $result['state']);
        $this->assertNotSame(EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, $result['state']);
        $row = DestructionLocationResult::first();
        $this->assertFalse($row->pre_delete_presence);
        $this->assertNull($row->post_delete_presence);
    }

    // ---- E14B-5/6: the aggregation itself - residual vs. primary-removed --

    public function test_final_state_is_residual_copy_exists_when_primary_itself_is_still_present(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes five');
        $tombstone = $this->authorizedTombstone($media);

        // Primary never resolved absent (no result row at all yet).
        $outcome = EvidenceDestructionExecutor::determineFinalState($tombstone, ['primary']);

        $this->assertSame(EvidenceTombstone::RESIDUAL_COPY_EXISTS, $outcome['state']);
    }

    public function test_final_state_is_primary_removed_when_other_governed_location_remains_unresolved(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes six');
        $tombstone = $this->authorizedTombstone($media);

        DestructionLocationResult::create([
            'tenant_id' => $this->tenant->id,
            'evidence_tombstone_id' => $tombstone->id,
            'location_key' => 'primary',
            'attempted_at' => now(),
            'expected_digest' => $tombstone->digest,
            'pre_delete_presence' => true,
            'delete_result' => DestructionLocationResult::DELETED,
            'post_delete_presence' => false,
            'verification_method' => 'sha256_absence_check',
            'verified_at' => now(),
        ]);

        $outcome = EvidenceDestructionExecutor::determineFinalState($tombstone, ['primary', 'replica']);

        $this->assertSame(EvidenceTombstone::PRIMARY_REMOVED, $outcome['state']);
        $this->assertSame(['replica'], $outcome['detail']['pending_locations']);
    }

    public function test_final_state_is_destroyed_within_governed_scope_when_every_location_resolves_absent(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes seven');
        $tombstone = $this->authorizedTombstone($media);

        foreach (['primary', 'replica'] as $key) {
            DestructionLocationResult::create([
                'tenant_id' => $this->tenant->id,
                'evidence_tombstone_id' => $tombstone->id,
                'location_key' => $key,
                'attempted_at' => now(),
                'expected_digest' => $tombstone->digest,
                'pre_delete_presence' => true,
                'delete_result' => DestructionLocationResult::DELETED,
                'post_delete_presence' => false,
                'verification_method' => 'sha256_absence_check',
                'verified_at' => now(),
            ]);
        }

        $outcome = EvidenceDestructionExecutor::determineFinalState($tombstone, ['primary', 'replica']);

        $this->assertSame(EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, $outcome['state']);
    }

    // ---- E14B-7: unknown storage topology refuses execution -------------

    public function test_unknown_storage_topology_refuses_execution(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes eight');
        $tombstone = $this->authorizedTombstone($media);

        // No governed locations effective at all - the seeded row is marked ungoverned.
        EvidenceStorageLocation::where('location_key', 'primary')->update(['governed' => false]);

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_BLOCKED_TOPOLOGY_UNKNOWN, $result['state']);
        $this->assertTrue(Storage::disk('local')->exists($media->storage_path));
    }

    // ---- E14B-8: unclassified retention never reaches execution at all --

    public function test_unclassified_retention_never_produces_a_tombstone_to_execute(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes nine', null);

        $this->expectException(UnclassifiedRetentionException::class);
        EvidenceDestructionService::requestDestruction($media, $this->actor, 'seems old');
    }

    // ---- E14B-9/10: the happy path never touches the tombstone's own identity --

    public function test_full_destruction_never_mutates_the_tombstone_and_retains_its_digest(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes ten');
        $tombstone = $this->authorizedTombstone($media);
        $originalDigest = $tombstone->digest;
        $originalState = $tombstone->state;

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, $result['state']);
        $this->assertFalse(Storage::disk('local')->exists($media->storage_path));

        $fresh = $tombstone->fresh();
        $this->assertSame($originalDigest, $fresh->digest);
        $this->assertSame($originalState, $fresh->state);
        $this->assertSame(EvidenceTombstone::AUTHORIZED_PENDING_EXECUTION, $fresh->state);
    }

    // ---- E14B-11: a retried worker is idempotent after full destruction --

    public function test_retried_worker_after_full_destruction_is_a_no_op(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes eleven');
        $tombstone = $this->authorizedTombstone($media);

        EvidenceDestructionExecutor::execute($tombstone, $this->actor);
        $countAfterFirst = DestructionLocationResult::count();

        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, $result['state']);
        $this->assertSame($countAfterFirst, DestructionLocationResult::count());
    }

    // ---- E14B-12: a tombstone cannot be executed against a foreign tenant's item --

    public function test_media_item_unreachable_under_tombstones_own_tenant_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes twelve');
        $tombstone = $this->authorizedTombstone($media);

        // Simulate the tombstone somehow pointing at an id under a different tenant.
        $otherTenant = Tenant::create(['name' => 'Other GC', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        DB::table('evidence_tombstones')->where('id', $tombstone->id)
            ->update(['tenant_id' => $otherTenant->id]);
        TenantContext::clear();

        $tombstone = EvidenceTombstone::withoutGlobalScopes()->find($tombstone->id);
        $result = EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $this->assertSame(EvidenceTombstone::EXECUTION_BLOCKED_HOLD, $result['state']);
        $this->assertSame('media_item_unreachable_under_tombstone_tenant', $result['detail']['reason']);
    }

    // ---- E14B-13: the certificate's language never overclaims -----------

    public function test_certificate_names_governed_scope_not_universal_absence(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes thirteen');
        $tombstone = $this->authorizedTombstone($media);
        EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $certificate = DestructionCertificate::render($tombstone->fresh());

        $this->assertStringContainsString('governed storage locations', $certificate);
        $this->assertStringNotContainsStringIgnoringCase('no copy exists anywhere', $certificate);
    }

    public function test_certificate_never_claims_destroyed_for_blocked_or_in_progress_states(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes fourteen');
        $tombstone = $this->authorizedTombstone($media);
        $this->placeHold();
        EvidenceDestructionExecutor::execute($tombstone, $this->actor);

        $certificate = DestructionCertificate::render($tombstone->fresh());

        $this->assertStringNotContainsStringIgnoringCase('ZecoCM verified', $certificate);
        $this->assertStringContainsString('does NOT state that the object has been destroyed', $certificate);
    }

    // ---- the console entry point wires straight through to the executor --

    public function test_console_command_executes_and_prints_a_certificate(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes fifteen');
        $tombstone = $this->authorizedTombstone($media);
        TenantContext::clear();

        $exitCode = Artisan::call('evidence:execute-destruction', [
            'tombstone' => $tombstone->id,
            '--actor' => $this->actor->id,
        ]);

        $this->assertSame(0, $exitCode);
        $output = Artisan::output();
        $this->assertStringContainsString(EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, $output);
        $this->assertStringContainsString('ZecoCM verified', $output);
    }

    public function test_console_command_requires_an_actor(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->mediaWithBytes('evidence bytes sixteen');
        $tombstone = $this->authorizedTombstone($media);
        TenantContext::clear();

        $exitCode = Artisan::call('evidence:execute-destruction', [
            'tombstone' => $tombstone->id,
        ]);

        $this->assertSame(1, $exitCode);
    }
}
