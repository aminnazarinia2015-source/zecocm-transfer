<?php

namespace Tests\Feature;

use App\Domain\Payment\PayApplicationReview;
use App\Domain\Payment\SubmissionPolicy;
use Tests\TestCase;

/**
 * What the submit button is allowed to say.
 *
 * The question Codex and I could not resolve from the finding alone: an
 * application has a returnable defect and nothing structurally improper. Does
 * the control read "Submit With Outstanding Items" or "Complete Required Items"?
 *
 * It depends on the contract, which means it cannot be a global default and
 * cannot be a user preference. And when no governing rule is on file, the answer
 * is neither of those two - it is that this software does not know, said out
 * loud, because an unknown rule silently becoming the permissive one is the
 * software telling the user something about the agency that nobody established.
 */
class SubmissionPolicyTest extends TestCase
{
    public function test_a_structural_defect_outranks_every_rule(): void
    {
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::HARD_INVALID, 'code' => 'line_over_authorized', 'message' => '', 'citation' => null],
        ], []);

        $this->assertSame('cannot_submit', $policy['state']);
        $this->assertSame('Correct Submission Errors', $policy['control']);
        $this->assertFalse($policy['submittable']);
    }

    public function test_an_unknown_rule_does_not_become_the_permissive_one(): void
    {
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::RETURNABLE, 'code' => 'stored_material_unsupported',
                'message' => '', 'citation' => null, 'gate' => 'agency'],
        ], []);

        $this->assertSame('requirement_unresolved', $policy['state']);
        $this->assertSame('Review Submission Requirement', $policy['control']);
        $this->assertFalse($policy['submittable']);
        $this->assertSame(['stored_material_unsupported'], $policy['unresolved_codes']);
    }

    public function test_a_rule_the_contract_makes_mandatory_blocks_submission(): void
    {
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::RETURNABLE, 'code' => 'stored_material_unsupported',
                'message' => '', 'citation' => null, 'gate' => 'agency'],
        ], ['stored_material_unsupported' => ['submission_effect' => SubmissionPolicy::RETURNABLE_BLOCKING,
            'status' => SubmissionPolicy::CONFIRMED, 'source_citation' => 'Special Provisions s. 9-3.2']]);

        $this->assertSame('cannot_submit', $policy['state']);
    }

    public function test_a_rule_the_contract_permits_lets_it_go_out_with_the_item_named(): void
    {
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::RETURNABLE, 'code' => 'stored_material_unsupported',
                'message' => '', 'citation' => null, 'gate' => 'agency'],
        ], ['stored_material_unsupported' => ['submission_effect' => SubmissionPolicy::RETURNABLE_PERMITTED,
            'status' => SubmissionPolicy::CONFIRMED, 'source_citation' => 'Special Provisions s. 9-3.2']]);

        $this->assertSame('returnable_permitted', $policy['state']);
        $this->assertSame('Submit With Outstanding Items', $policy['control']);
        $this->assertTrue($policy['submittable']);
    }

    public function test_an_unconfirmed_rule_is_treated_as_no_rule(): void
    {
        // A row somebody drafted and nobody confirmed is a proposal, not a rule.
        // Reading it as governing would be the same failure as the automated
        // knowledge verification we already fixed once.
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::RETURNABLE, 'code' => 'stored_material_unsupported',
                'message' => '', 'citation' => null, 'gate' => 'agency'],
        ], ['stored_material_unsupported' => ['submission_effect' => SubmissionPolicy::RETURNABLE_PERMITTED,
            'status' => SubmissionPolicy::UNRESOLVED, 'source_citation' => 'proposed from Addendum 2']]);

        $this->assertSame('requirement_unresolved', $policy['state']);
    }

    public function test_an_internal_readiness_warning_never_gates_submission(): void
    {
        // A retention rate nobody has confirmed against the contract is worth
        // saying loudly. It is not something an agency returns a payment request
        // over, and gating on it would be this software inventing a rule.
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::RETURNABLE, 'code' => 'retention_rule_unconfirmed',
                'message' => '', 'citation' => null, 'gate' => 'internal'],
        ], []);

        $this->assertSame('clean', $policy['state']);
        $this->assertSame('Submit Pay Application', $policy['control']);
        $this->assertTrue($policy['submittable']);
    }

    public function test_a_withholding_never_reaches_the_submit_control_at_all(): void
    {
        $policy = SubmissionPolicy::resolve([
            ['severity' => PayApplicationReview::WITHHOLD, 'code' => 'missing_weekly_record', 'message' => '', 'citation' => null],
        ], []);

        $this->assertSame('clean', $policy['state']);
        $this->assertTrue($policy['submittable']);
    }
}
