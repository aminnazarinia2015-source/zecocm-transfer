<?php

namespace Tests\Feature;

use App\Domain\Evidence\DestructionCertificate;
use App\Domain\Evidence\EvidenceDestructionService;
use App\Domain\Evidence\EvidenceLinkService;
use App\Domain\Evidence\HoldStatus;
use App\Domain\Evidence\LegalHoldService;
use App\Domain\Evidence\UnclassifiedRetentionException;
use App\Models\DailyReport;
use App\Models\EvidenceLink;
use App\Models\EvidenceTombstone;
use App\Models\LegalHoldEvent;
use App\Models\MediaItem;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * EV-14A: retention/legal-hold/tombstone governance. Codex split this row in
 * two - eligibility and governance close now (this file); verified
 * destruction execution is EV-14B, gated on DATA-1's storage topology.
 *
 * Acceptance cases are Codex's own, from the design brief's battery and his
 * direct rulings in conversation. E14-2 (hold status cannot be determined)
 * is written first, per his explicit instruction: "it is the case a naive
 * implementation gets wrong, and the one that produces spoliation."
 */
class Ev14RetentionAndHoldGovernanceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $actor;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Riverbend GC', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->actor = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Records Officer',
            'email' => 'records@riverbend.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Levee', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    /** Caller must already have TenantContext set - this helper does not manage it. */
    private function media(?string $retentionClass = null): MediaItem
    {
        return MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => str_repeat('b', 64), 'storage_path' => 'media/sealed/bb/'.str_repeat('b', 64),
            'original_name' => 'evidence.jpg', 'mime' => 'image/jpeg', 'bytes' => 2048,
            'malware_scan_status' => 'clean', 'provenance' => [], 'provenance_signature' => 'x',
            'confidence' => 'strong', 'server_received_at' => now(), 'receipt_sequence' => 1,
            'capture_time_basis' => 'server_receipt', 'capture_finding' => 'consistent', 'client_claims' => [],
            'captured_by' => $this->actor->id, 'retention_class' => $retentionClass]);
    }

    // ---- E14-2: hold status cannot be determined - written first, per Codex ----

    public function test_an_unreadable_hold_scope_value_makes_status_cannot_determine_not_no_hold(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        \Illuminate\Support\Facades\DB::table('legal_hold_events')->insert([
            'tenant_id' => $this->tenant->id, 'hold_id' => (string) \Illuminate\Support\Str::uuid(),
            'event_type' => 'placed', 'scope_type' => 'project', 'scope_value' => 'not valid json{{{',
            'matter_reference' => null, 'actor_id' => $this->actor->id, 'reason' => 'test',
            'occurred_at' => now(), 'created_at' => now(), 'updated_at' => now(),
        ]);

        $status = HoldStatus::forMediaItem($media->fresh());
        TenantContext::clear();

        $this->assertSame(HoldStatus::CANNOT_DETERMINE, $status['status'],
            'An unreadable hold record must never resolve to "no hold" - the fail-closed direction matters more here than anywhere else in this codebase.');
    }

    public function test_authorization_refuses_when_hold_status_cannot_be_determined(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'Retention period elapsed.');
        \Illuminate\Support\Facades\DB::table('legal_hold_events')->insert([
            'tenant_id' => $this->tenant->id, 'hold_id' => (string) \Illuminate\Support\Str::uuid(),
            'event_type' => 'placed', 'scope_type' => 'unrecognised_scope_type', 'scope_value' => json_encode(['x' => 1]),
            'matter_reference' => null, 'actor_id' => $this->actor->id, 'reason' => 'test',
            'occurred_at' => now(), 'created_at' => now(), 'updated_at' => now(),
        ]);

        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2');
        TenantContext::clear();

        $this->assertSame('refused', $result->status);
        $this->assertSame(EvidenceDestructionService::REFUSAL_CANNOT_DETERMINE_HOLD, $result->refusal_reason);
        $this->assertDatabaseCount('evidence_tombstones', 0);
    }

    // ---- E14-1: an active hold refuses destruction, naming the hold --------

    public function test_destruction_is_refused_while_an_active_hold_covers_the_project(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        LegalHoldService::place(LegalHoldEvent::SCOPE_PROJECT, ['project_id' => $this->project->id], $this->actor,
            'Anticipated claim on the levee failure.', 'Matter 2026-CV-118');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'Retention period elapsed.');

        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2');
        TenantContext::clear();

        $this->assertSame('refused', $result->status);
        $this->assertSame(EvidenceDestructionService::REFUSAL_HELD, $result->refusal_reason);
        $this->assertDatabaseCount('evidence_tombstones', 0);
    }

    // ---- E14-11: hold placed after request but before authorization still blocks ----

    public function test_a_hold_placed_after_the_request_but_before_authorization_still_blocks(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'Retention period elapsed.');
        $this->assertSame(HoldStatus::NO_HOLD, $request->hold_check_result, 'Control: no hold existed at request time.');

        LegalHoldService::place(LegalHoldEvent::SCOPE_MEDIA_ITEM, ['media_item_id' => $media->id], $this->actor,
            'A dispute was opened after the request was filed.');

        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2');
        TenantContext::clear();

        $this->assertSame('refused', $result->status,
            'The hold check at authorization time must win over whatever was true when the request was filed - E14-11.');
        $this->assertSame(EvidenceDestructionService::REFUSAL_HELD, $result->refusal_reason);
    }

    // ---- E14-8 / happy path: authorized, tombstone written, still not destroyed ----

    public function test_authorization_with_no_hold_writes_a_tombstone_that_is_authorized_not_executed(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'Retention period elapsed.');

        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2, adopted 2024.');
        $tombstone = EvidenceTombstone::where('destruction_request_id', $result->id)->firstOrFail();
        TenantContext::clear();

        $this->assertSame('authorized', $result->status);
        $this->assertSame(EvidenceTombstone::AUTHORIZED_PENDING_EXECUTION, $tombstone->state);
        $this->assertSame($media->sha256, $tombstone->digest, 'The digest is retained forever, per Codex\'s ruling - it is the evidentiary commitment, not the content.');
        $this->assertSame('sha256', $tombstone->digest_algorithm);
    }

    // ---- E14-6 / the certificate can never overclaim -----------------------

    public function test_the_certificate_never_claims_destroyed_for_an_authorized_pending_tombstone(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'Retention period elapsed.');
        $result = EvidenceDestructionService::authorize($request, $this->actor, 'Retention schedule §4.2');
        $tombstone = EvidenceTombstone::where('destruction_request_id', $result->id)->firstOrFail();

        $certificate = DestructionCertificate::render($tombstone);
        TenantContext::clear();

        $this->assertStringContainsString('AUTHORIZED', $certificate);
        $this->assertStringContainsString('does NOT state that the object has been destroyed', $certificate);
        $this->assertStringNotContainsStringIgnoringCase('the object was destroyed', $certificate);
    }

    /**
     * As of EV-14B, DestructionCertificate reads execution state from the
     * append-only `evidence_tombstone_execution_events` ledger, not the
     * tombstone's own fixed `state` column (which the append-only guard
     * below already proves can never change). So the "unrecognised state"
     * case is simulated by an execution-ledger row this codebase's own
     * executor never writes - the certificate must still refuse it.
     */
    public function test_the_certificate_refuses_to_render_an_unrecognised_state(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'x');
        $result = EvidenceDestructionService::authorize($request, $this->actor, 'y');
        $tombstone = EvidenceTombstone::where('destruction_request_id', $result->id)->firstOrFail();
        \Illuminate\Support\Facades\DB::table('evidence_tombstone_execution_events')->insert([
            'tenant_id' => $this->tenant->id,
            'evidence_tombstone_id' => $tombstone->id,
            'state' => 'some_future_state_this_codebase_does_not_know',
            'occurred_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->expectException(\LogicException::class);
        DestructionCertificate::render($tombstone->fresh());
        TenantContext::clear();
    }

    // ---- E14-7: unclassified record generates no proposal at all ----------

    public function test_an_unclassified_record_refuses_even_a_pending_request(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media(null);

        $this->expectException(UnclassifiedRetentionException::class);
        try {
            EvidenceDestructionService::requestDestruction($media, $this->actor, 'Old file, seems safe to remove.');
        } finally {
            $this->assertDatabaseCount('destruction_requests', 0);
            TenantContext::clear();
        }
    }

    // ---- tombstones and destruction requests are append-only --------------

    public function test_a_tombstone_cannot_be_updated_or_deleted(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $request = EvidenceDestructionService::requestDestruction($media, $this->actor, 'x');
        $result = EvidenceDestructionService::authorize($request, $this->actor, 'y');
        $tombstone = EvidenceTombstone::where('destruction_request_id', $result->id)->firstOrFail();

        try {
            $this->expectException(\LogicException::class);
            $tombstone->state = EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE;
            $tombstone->save();
        } finally {
            TenantContext::clear();
        }
    }

    // ---- B9: evidence links are append-only; unlinking is a superseding event ----

    public function test_evidence_link_cannot_be_deleted_only_unlinked(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media();
        $report = DailyReport::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'report_date' => now()->toDateString(), 'foreman_id' => $this->actor->id, 'weather' => [],
            'work_performed' => 'Grading', 'cost_code_notes' => [], 'corrections' => []]);
        $link = EvidenceLink::create(['tenant_id' => $this->tenant->id, 'media_item_id' => $media->id,
            'record_type' => 'daily_report', 'record_id' => $report->id, 'linked_by' => $this->actor->id]);

        $this->assertFalse($link->isUnlinked());

        $this->expectException(\LogicException::class);
        try {
            $link->delete();
        } finally {
            TenantContext::clear();
        }
    }

    public function test_unlinking_appends_an_event_and_leaves_the_original_link_intact(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media();
        $report = DailyReport::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'report_date' => now()->toDateString(), 'foreman_id' => $this->actor->id, 'weather' => [],
            'work_performed' => 'Grading', 'cost_code_notes' => [], 'corrections' => []]);
        $link = EvidenceLink::create(['tenant_id' => $this->tenant->id, 'media_item_id' => $media->id,
            'record_type' => 'daily_report', 'record_id' => $report->id, 'linked_by' => $this->actor->id]);

        EvidenceLinkService::unlink($link, $this->actor, 'Attached to the wrong daily report by mistake.');

        $this->assertDatabaseHas('evidence_links', ['id' => $link->id]);
        $this->assertTrue($link->fresh()->isUnlinked());
        TenantContext::clear();
    }

    public function test_unlinking_without_a_reason_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media();
        $report = DailyReport::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'report_date' => now()->toDateString(), 'foreman_id' => $this->actor->id, 'weather' => [],
            'work_performed' => 'Grading', 'cost_code_notes' => [], 'corrections' => []]);
        $link = EvidenceLink::create(['tenant_id' => $this->tenant->id, 'media_item_id' => $media->id,
            'record_type' => 'daily_report', 'record_id' => $report->id, 'linked_by' => $this->actor->id]);

        $this->expectException(\InvalidArgumentException::class);
        try {
            EvidenceLinkService::unlink($link, $this->actor, '   ');
        } finally {
            TenantContext::clear();
        }
    }

    // ---- legal holds: release is an event, not an expiry -------------------

    public function test_a_released_hold_no_longer_covers_the_project(): void
    {
        TenantContext::set($this->tenant->id);
        $media = $this->media('project_records:7_years');
        $hold = LegalHoldService::place(LegalHoldEvent::SCOPE_PROJECT, ['project_id' => $this->project->id], $this->actor, 'Anticipated claim.');
        $this->assertSame(HoldStatus::HELD, HoldStatus::forMediaItem($media)['status']);

        LegalHoldService::release($hold->hold_id, $this->actor, 'Matter settled and closed.');

        $this->assertSame(HoldStatus::NO_HOLD, HoldStatus::forMediaItem($media->fresh())['status']);
        TenantContext::clear();
    }

    public function test_a_hold_event_cannot_be_edited_in_place(): void
    {
        TenantContext::set($this->tenant->id);
        $hold = LegalHoldService::place(LegalHoldEvent::SCOPE_PROJECT, ['project_id' => $this->project->id], $this->actor, 'Anticipated claim.');

        $this->expectException(\LogicException::class);
        try {
            $hold->reason = 'edited after the fact';
            $hold->save();
        } finally {
            TenantContext::clear();
        }
    }

    public function test_releasing_a_hold_that_was_never_placed_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $this->expectException(\RuntimeException::class);
        try {
            LegalHoldService::release((string) \Illuminate\Support\Str::uuid(), $this->actor, 'no such hold');
        } finally {
            TenantContext::clear();
        }
    }

    // ---- a media-item-scoped hold does not leak to an unrelated project ----

    public function test_a_media_item_scoped_hold_does_not_cover_a_different_media_item_in_the_same_project(): void
    {
        TenantContext::set($this->tenant->id);
        $held = $this->media('project_records:7_years');
        $unrelated = $this->media('project_records:7_years');
        LegalHoldService::place(LegalHoldEvent::SCOPE_MEDIA_ITEM, ['media_item_id' => $held->id], $this->actor, 'Specific item disputed.');

        $this->assertSame(HoldStatus::HELD, HoldStatus::forMediaItem($held->fresh())['status']);
        $this->assertSame(HoldStatus::NO_HOLD, HoldStatus::forMediaItem($unrelated->fresh())['status']);
        TenantContext::clear();
    }
}
