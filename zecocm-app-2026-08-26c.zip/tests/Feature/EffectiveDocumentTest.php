<?php

namespace Tests\Feature;

use App\Domain\Ai\EffectiveDocument;
use Tests\TestCase;

/**
 * D5's closure list, as Codex specified it.
 *
 * The question is never "is this PDF old". It is "is this particular
 * requirement currently operative" - and the difference is a spec section
 * nobody touched going dark because an addendum changed two paragraphs
 * somewhere else in the same document.
 */
class EffectiveDocumentTest extends TestCase
{
    public function test_whole_document_replacement_retires_everything(): void
    {
        $state = EffectiveDocument::stateOf(
            $this->passage(sectionRef: '1.1'),
            [$this->scope(type: 'document', relation: 'replace')],
        );

        $this->assertSame(EffectiveDocument::SUPERSEDED, $state['state']);
        $this->assertFalse(EffectiveDocument::mayControl($state['state']));
    }

    public function test_a_section_replacement_leaves_every_other_section_operative(): void
    {
        // The case D5 exists for. Addendum 3 replaces 3.2 and says nothing about
        // 1.1, so 1.1 is still the contract.
        $scopes = [$this->scope(type: 'section', relation: 'replace', section: '3.2')];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2'), $scopes)['state']);

        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sectionRef: '1.1'), $scopes)['state']);
    }

    public function test_a_clause_replacement_reaches_only_that_clause(): void
    {
        $scopes = [$this->scope(type: 'clause', relation: 'replace', section: '3.2.B')];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.B'), $scopes)['state']);

        // Its siblings under the same section survive.
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.A'), $scopes)['state']);
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.C'), $scopes)['state']);
    }

    public function test_a_section_scope_reaches_its_children_but_not_a_lookalike(): void
    {
        // Deleting 3.2 deletes what is inside it. It must never touch 3.20,
        // which is a different section that merely starts the same way.
        $scopes = [$this->scope(type: 'section', relation: 'replace', section: '3.2')];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.B.1'), $scopes)['state']);
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.20'), $scopes)['state']);
    }

    public function test_deletion_without_replacement_does_not_resurrect_the_old_requirement(): void
    {
        $state = EffectiveDocument::stateOf(
            $this->passage(sectionRef: '3.2.B'),
            [$this->scope(type: 'clause', relation: 'delete', section: '3.2.B')],
        );

        $this->assertSame(EffectiveDocument::DELETED, $state['state']);
        $this->assertFalse(EffectiveDocument::mayControl($state['state']));
        $this->assertStringContainsString('will not treat the deleted requirement as current', $state['note']);
    }

    public function test_a_supplement_retires_nothing_and_both_sources_stand(): void
    {
        $state = EffectiveDocument::stateOf(
            $this->passage(sectionRef: '3.2.B'),
            [$this->scope(type: 'clause', relation: 'supplement', section: '3.2.B')],
        );

        $this->assertSame(EffectiveDocument::SUPPLEMENTED, $state['state']);
        $this->assertTrue(EffectiveDocument::mayControl($state['state']));
        $this->assertStringContainsString('combination of both', $state['note']);
    }

    public function test_a_clarification_also_retires_nothing(): void
    {
        $state = EffectiveDocument::stateOf(
            $this->passage(sectionRef: '3.2.B'),
            [$this->scope(type: 'clause', relation: 'clarify', section: '3.2.B')],
        );

        $this->assertTrue(EffectiveDocument::mayControl($state['state']));
    }

    public function test_silence_is_not_supersession(): void
    {
        // The rule the whole overlay rests on. A later document exists; it says
        // nothing about this passage; the passage is still the contract.
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sectionRef: '5.4'), [])['state']);
    }

    public function test_an_unconfirmed_scope_refuses_rather_than_applying_or_being_ignored(): void
    {
        // A scope TRACE inferred from wording is a proposal. Applying it would
        // make AI interpretation into contract amendment; ignoring it would
        // answer from text the record suggests may be dead.
        $state = EffectiveDocument::stateOf(
            $this->passage(sectionRef: '3.2.B'),
            [$this->scope(type: 'clause', relation: 'replace', section: '3.2.B', status: 'proposed')],
        );

        $this->assertSame(EffectiveDocument::UNRESOLVED, $state['state']);
        $this->assertFalse(EffectiveDocument::mayControl($state['state']));
        $this->assertStringContainsString('will not select a governing requirement', $state['note']);
    }

    public function test_a_sheet_replacement_reaches_only_that_sheet(): void
    {
        $scopes = [$this->scope(type: 'sheet', relation: 'replace', sheet: 'L-3')];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(sheetRef: 'L-3'), $scopes)['state']);
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(sheetRef: 'L-4'), $scopes)['state']);
    }

    public function test_a_passage_range_scope_covers_its_range_and_nothing_else(): void
    {
        // The fallback where a document has no reliable structure at all.
        $scopes = [array_merge($this->scope(type: 'passage_range', relation: 'replace'),
            ['start_passage_id' => 100, 'end_passage_id' => 104])];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(id: 102), $scopes)['state']);
        $this->assertSame(EffectiveDocument::CURRENT,
            EffectiveDocument::stateOf($this->passage(id: 105), $scopes)['state']);
    }

    public function test_overlapping_modifications_let_the_stronger_relation_control(): void
    {
        // One addendum supplements the clause, a later one deletes it. Deletion
        // is the operative fact; reporting "supplemented" would be citing a
        // requirement that no longer exists.
        $state = EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.B'), [
            $this->scope(type: 'clause', relation: 'supplement', section: '3.2.B'),
            $this->scope(type: 'clause', relation: 'delete', section: '3.2.B'),
        ]);

        $this->assertSame(EffectiveDocument::DELETED, $state['state']);
    }

    public function test_a_re_extracted_passage_will_not_have_a_stale_overlay_applied_to_it(): void
    {
        // The locator drift guard. If the text under the locator is not the text
        // the scope was confirmed against, the overlay may now point somewhere
        // else entirely, and applying it silently would retire the wrong clause.
        $scope = array_merge($this->scope(type: 'clause', relation: 'replace', section: '3.2.B'),
            ['target_content_hash' => str_repeat('a', 64)]);

        $state = EffectiveDocument::stateOf(
            array_merge($this->passage(sectionRef: '3.2.B'), ['body_sha256' => str_repeat('b', 64)]),
            [$scope],
        );

        $this->assertSame(EffectiveDocument::UNRESOLVED, $state['state']);
        $this->assertStringContainsString('remapped', $state['note']);
    }

    public function test_trailing_punctuation_is_formatting_and_not_identity(): void
    {
        $scopes = [$this->scope(type: 'clause', relation: 'replace', section: '3.2.B.')];

        $this->assertSame(EffectiveDocument::SUPERSEDED,
            EffectiveDocument::stateOf($this->passage(sectionRef: '3.2.b'), $scopes)['state']);
    }

    private function passage(int $id = 1, ?string $sectionRef = null, ?string $sheetRef = null): array
    {
        return ['id' => $id, 'section_ref' => $sectionRef, 'sheet_ref' => $sheetRef, 'body_sha256' => null];
    }

    private function scope(string $type, string $relation, ?string $section = null,
        ?string $sheet = null, string $status = 'confirmed'): array
    {
        return ['scope_type' => $type, 'relation' => $relation, 'target_section_ref' => $section,
            'target_sheet_ref' => $sheet, 'status' => $status, 'superseding_title' => 'Addendum 3',
            'start_passage_id' => null, 'end_passage_id' => null, 'target_content_hash' => null];
    }
}
