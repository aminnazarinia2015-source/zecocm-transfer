<?php

namespace Tests\Feature;

use App\Domain\Ai\Citation;
use App\Domain\Ai\CitationAnchor;
use App\Domain\Ai\ClaudeAssistant;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\RetrievalClient;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * TR-14: citation addressability - the anchor a citation carries must still
 * resolve after it leaves this database. Before this row a `Citation`'s only
 * locator was `passage_id`, the autoincrement `knowledge_passages.id` -
 * meaningless once restored from a backup, migrated to a new database, or
 * handed to a party running their own copy of the source documents.
 *
 * This proves the whole path end to end: a passage seeded through the real
 * schema, retrieved through the real `HybridKnowledgeRetriever`, cited through
 * the real `ClaudeAssistant::parse()` (via reflection - it is private and the
 * HTTP call above it is out of scope here, see the class's own doc comment),
 * and the resulting anchor recomputed independently from the passage's own
 * text rather than trusted from the stored column.
 */
class Tr14CitationAddressabilityTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Constructors', 'type' => 'Contractor',
            'status' => 'active', 'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend Levee',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA',
            'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_retrieved_passage_carries_the_portable_locators_from_its_own_database_rows(): void
    {
        $body = 'The retention rate on public works contracts shall be 5 percent.';
        [$source, $version, $passage] = $this->seedProjectSource($body);

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertNotEmpty($found);
        $hit = $found[0];
        $this->assertSame($source->public_id, $hit->sourcePublicId);
        $this->assertSame($version->version_number, $hit->versionNumber);
        $this->assertSame($passage->ordinal, $hit->ordinal);
        $this->assertSame($passage->body_sha256, $hit->bodyHash);
        // Recomputed independently, not merely echoed back from the column -
        // proves the anchor is genuinely content-addressed, not just a stored
        // value that happens to be present.
        $this->assertSame(hash('sha256', $body), $hit->bodyHash);
    }

    public function test_the_anchor_survives_the_passage_row_being_deleted_and_recreated_with_a_new_id(): void
    {
        // Simulates exactly the TR-14 scenario: the same content, re-ingested
        // into what is effectively a fresh set of rows (a restored backup, a
        // migrated database) where autoincrement assigns a different id.
        $body = 'Retainage shall not exceed 5 percent of the contract sum.';
        [$source, $version, $passageOne] = $this->seedProjectSource($body);
        $anchorBefore = CitationAnchor::build(
            $source->public_id, $version->version_number, $passageOne->ordinal, $passageOne->body_sha256,
        );

        TenantContext::set($this->tenant->id);
        // knowledge_passages is guarded against Eloquent deletes
        // (ImmutableImportedScheduleRecord) - correctly, for production. This
        // test needs to simulate "the same content landed on a different row
        // id," which is exactly what a restored backup or a re-ingested copy
        // looks like, so it drops to the query builder rather than the model.
        \Illuminate\Support\Facades\DB::table('knowledge_passages')->where('id', $passageOne->id)->delete();
        $passageTwo = KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => $passageOne->ordinal, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
        TenantContext::clear();

        $this->assertNotSame($passageOne->id, $passageTwo->id, 'The fixture must actually get a new row id.');

        $anchorAfter = CitationAnchor::build(
            $source->public_id, $version->version_number, $passageTwo->ordinal, $passageTwo->body_sha256,
        );

        $this->assertSame($anchorBefore, $anchorAfter, 'A new internal row id must never change the anchor.');
    }

    public function test_a_cited_suggestion_built_through_claudeassistant_carries_the_anchor(): void
    {
        $body = 'The retention rate on public works contracts shall be 5 percent.';
        [$source, $version, $passage] = $this->seedProjectSource($body);
        $passages = $this->retrieve('what is the retention rate on public works contracts');
        $this->assertNotEmpty($passages);

        $raw = json_encode([
            'content' => [['text' => json_encode([
                'kind' => 'suggestion',
                'text' => 'The retention rate is 5 percent.',
                'passage_refs' => [0],
            ])]],
        ]);

        $assistant = new ClaudeAssistant('test-key', $this->nullRetrievalClient());
        $method = new \ReflectionMethod(ClaudeAssistant::class, 'parse');
        $method->setAccessible(true);
        /** @var \App\Domain\Ai\CitedSuggestion $result */
        $result = $method->invoke($assistant, $raw, $passages);

        $this->assertInstanceOf(\App\Domain\Ai\CitedSuggestion::class, $result);
        /** @var Citation $citation */
        $citation = $result->citations[0];
        $expectedAnchor = CitationAnchor::build(
            $source->public_id, $version->version_number, $passage->ordinal, $passage->body_sha256,
        );
        $this->assertSame($expectedAnchor, $citation->toArray()['anchor']);
        $this->assertNotNull($citation->toArray()['anchor'], 'A citation built from a real retrieved passage must be addressable.');
    }

    /** @return array{0: KnowledgeSource, 1: KnowledgeSourceVersion, 2: KnowledgePassage} */
    private function seedProjectSource(string $body): array
    {
        TenantContext::set($this->tenant->id);
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'project',
            'title' => 'Riverbend Project Specifications', 'source_type' => 'specification',
            'jurisdiction' => 'CA', 'discipline' => 'civil', 'authority_level' => 'project_contract',
            'access_classification' => 'project_private', 'verification_status' => 'verified',
            'ingestion_status' => 'ready', 'mime_type' => 'text/plain', 'storage_path' => 'test/spec',
            'byte_size' => 1, 'sha256' => str_repeat('a', 64), 'malware_scan_status' => 'clean']);
        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'sha256' => str_repeat('a', 64), 'extraction_method' => 'plain-text', 'extraction_confidence' => 1.0,
            'parser_version' => 'test', 'classification' => ['corpora' => ['project_specs']],
            'storage_path' => 'test/spec', 'mime_type' => 'text/plain', 'byte_size' => 1,
            'malware_scan_status' => 'clean']);
        $passage = KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
        TenantContext::clear();

        return [$source, $version, $passage];
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function nullRetrievalClient(): RetrievalClient
    {
        return new class implements RetrievalClient
        {
            public function retrieve(string $query, \App\Domain\Ai\JurisdictionScope $scope): array
            {
                return [];
            }
        };
    }
}
