<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\KnowledgePassage;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * D3: chunking used to be a private method inside the controller that no
 * test ever exercised at the ingest boundary. This proves the wiring, not
 * just the chunker in isolation - PassageChunkerTest covers the algorithm;
 * this covers that KnowledgeController actually persists what it returns.
 */
class PassageChunkingIngestTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Atlas CM', 'type' => 'CM firm', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('CM firm'), 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Knowledge Steward',
            'email' => 'steward@atlas.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'A-1', 'name' => 'Atlas Library', 'sector' => 'public',
            'owner_name' => 'City of Atlas', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Atlas CM', 'seat' => 'knowledge_steward', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_section_header_ingests_as_its_own_passage_carrying_the_section_ref(): void
    {
        $text = "Preliminary general notes for the whole project unrelated to any single trade.\n\n"
            ."SECTION 32 84 00 - IRRIGATION\n\nTrench depth shall be eighteen inches minimum below finish grade.";

        $id = $this->postJson('/api/knowledge/sources', [
            'project_id' => $this->project->id, 'collection' => 'project', 'corpus' => 'project_contract',
            'title' => 'Irrigation Specification', 'source_type' => 'specification', 'authority_level' => 'project_contract',
            'edition' => '2026', 'jurisdiction' => 'City of Atlas', 'text' => $text,
        ])->assertCreated()->json('source.id');

        TenantContext::set($this->tenant->id);
        $passages = KnowledgePassage::query()
            ->whereHas('version', fn ($q) => $q->where('knowledge_source_id', $id))
            ->orderBy('ordinal')->get();
        TenantContext::clear();

        $this->assertGreaterThanOrEqual(2, $passages->count());
        $headerPassage = $passages->firstWhere('boundary_rule', 'header');
        $this->assertNotNull($headerPassage, 'expected one ingested passage to carry boundary_rule=header');
        $this->assertSame('32 84 00', $headerPassage->section_ref);
        $this->assertStringContainsString('Trench depth', $headerPassage->body);

        // Every passage is traceable to the chunking process version that drew
        // its boundary, not only to the source it came from — Codex's D3
        // closure criterion, checked at the persistence layer rather than
        // just in the chunker's own unit tests.
        foreach ($passages as $passage) {
            $this->assertSame(\App\Domain\Knowledge\PassageChunker::VERSION, $passage->classification['chunking_version'] ?? null);
        }
    }
}
