<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\StopPaymentNotice;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Releases and stop payment notices over HTTP.
 *
 * What is being defended: the two never become one number. A signed release is
 * not an answer to a served notice, and an owner who is shown a single net
 * figure will pay somebody twice.
 */
class PaymentSecuritySurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($tenant->id);
        $this->project = Project::create(['number' => 'P-600', 'name' => 'Civic Center Reroof', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_served_notice_reports_its_statutory_withholding_on_creation(): void
    {
        $body = $this->postJson('/api/payment-security/stop-notices', [
            'project_id' => $this->project->id,
            'claimant_name' => 'Sierra Rebar',
            'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10',
            'preliminary_notice_on_file' => true,
        ])->assertCreated()->json();

        $this->assertSame(50_000_00, $body['withhold_cents']);
        $this->assertSame('open', $body['notice']['status']);
    }

    public function test_a_notice_cannot_be_created_already_resolved(): void
    {
        $body = $this->postJson('/api/payment-security/stop-notices', [
            'project_id' => $this->project->id, 'claimant_name' => 'Sierra Rebar',
            'claimed_amount_cents' => 1_000_00, 'served_on' => '2026-08-10',
            'status' => 'released',
        ])->assertCreated()->json();

        $this->assertSame('open', $body['notice']['status']);
    }

    public function test_bonding_around_without_the_bond_on_file_is_refused(): void
    {
        $notice = $this->makeNotice();

        $this->postJson('/api/payment-security/stop-notices/'.$notice['id'].'/resolve', [
            'status' => 'bonded_around', 'resolved_on' => '2026-09-01',
        ])->assertStatus(422)
            ->assertJsonPath('citation', 'Civil Code s. 9364');

        // And the money is still frozen.
        $this->assertSame(50_000_00, $this->index()['frozen']['total_withheld_cents']);
    }

    public function test_bonding_around_with_the_bond_on_file_frees_the_funds(): void
    {
        $notice = $this->makeNotice();

        $this->postJson('/api/payment-security/stop-notices/'.$notice['id'].'/resolve', [
            'status' => 'bonded_around', 'resolved_on' => '2026-09-01',
            'release_bond_on_file' => true, 'resolution_reference' => 'Bond 44-119',
        ])->assertOk()->assertJsonPath('still_freezes_funds', false);

        $this->assertSame(0, $this->index()['frozen']['total_withheld_cents']);
    }

    public function test_exceptions_written_on_a_release_are_recorded_even_if_the_client_omits_the_flag(): void
    {
        $this->postJson('/api/payment-security/releases', [
            'project_id' => $this->project->id,
            'claimant_name' => 'Valley Electric',
            'form_type' => 'unconditional_progress',
            'through_date' => '2026-07-31',
            'document_on_file' => true,
            'exceptions' => 'Except disputed backcharge of $12,400',
        ])->assertCreated();

        $release = $this->index()['releases'][0];
        $this->assertTrue($release['exceptions_stated']);
        $this->assertTrue($release['has_taken_effect']);
    }

    public function test_a_conditional_release_reports_that_it_has_not_taken_effect(): void
    {
        $this->postJson('/api/payment-security/releases', [
            'project_id' => $this->project->id,
            'claimant_name' => 'Valley Electric',
            'form_type' => 'conditional_progress',
            'through_date' => '2026-07-31',
            'document_on_file' => true,
        ])->assertCreated();

        $release = $this->index()['releases'][0];
        $this->assertTrue($release['conditional']);
        $this->assertFalse($release['has_taken_effect']);
        $this->assertSame('Civil Code s. 8132', $release['citation']);
    }

    public function test_the_payload_reports_releases_and_frozen_funds_as_separate_facts(): void
    {
        $this->makeNotice();
        $this->postJson('/api/payment-security/releases', [
            'project_id' => $this->project->id, 'claimant_name' => 'Valley Electric',
            'form_type' => 'unconditional_progress', 'through_date' => '2026-07-31',
            'amount_cents' => 90_000_00, 'document_on_file' => true,
        ])->assertCreated();

        $body = $this->index();

        // A $90,000 release does not touch the $50,000 that is frozen.
        $this->assertSame(50_000_00, $body['frozen']['total_withheld_cents']);
        $this->assertCount(1, $body['releases']);
        $this->assertStringContainsString('unpayable, not deducted', $body['frozen']['note']);
    }

    public function test_another_tenants_notice_is_not_visible(): void
    {
        $this->makeNotice();

        $other = Tenant::create(['name' => 'Rival Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $stranger = User::create(['tenant_id' => $other->id, 'name' => 'Stranger',
            'email' => 'stranger@rival.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($stranger);

        // 404 rather than 403, and deliberately so: the project is invisible
        // outside its tenant, so the stranger is not even told it exists. The
        // scope is fail-closed at the query, not at a permission check.
        $this->getJson('/api/payment-security?project_id='.$this->project->id)->assertNotFound();
        $this->assertSame(1, StopPaymentNotice::withoutGlobalScopes()->count());
    }

    private function makeNotice(): array
    {
        return $this->postJson('/api/payment-security/stop-notices', [
            'project_id' => $this->project->id, 'claimant_name' => 'Sierra Rebar',
            'claimed_amount_cents' => 40_000_00, 'served_on' => '2026-08-10',
            'preliminary_notice_on_file' => true,
        ])->assertCreated()->json()['notice'];
    }

    private function index(): array
    {
        return $this->getJson('/api/payment-security?project_id='.$this->project->id)->assertOk()->json();
    }
}
