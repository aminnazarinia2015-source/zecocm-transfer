<?php

namespace Tests\Feature;

use App\Domain\Provenance\ChainSpec;
use App\Domain\Provenance\CanonicalPayload;
use App\Domain\Provenance\ChainVerifier;
use App\Domain\Provenance\DigestAlgorithm;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use App\Models\Project;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Tests\TestCase;

/**
 * B2 - the chain walker.
 *
 * Until this existed, nothing in this codebase had ever verified a hash chain.
 * The product told people the record was tamper-evident, and the evidence for
 * that claim was that the writing code looked correct. Recording a hash and never
 * checking it is not tamper evidence; it is a hash.
 *
 * The clause that does the real work, Codex's: when a link breaks, everything
 * downstream is UNTRUSTED, not valid. A verifier that mutates record 37 of a
 * hundred and reports "99 valid, 1 invalid" has misunderstood what a chain is -
 * and that misunderstanding is exactly how an altered ledger passes an audit.
 */
class ChainVerifierTest extends TestCase
{
    use RefreshDatabase;

    private ChainSpec $spec;

    protected function setUp(): void
    {
        parent::setUp();
        $tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        \App\Models\User::create(['tenant_id' => $tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($tenant->id);
        $project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        DB::table('quality_items')->insert(['id' => 1, 'tenant_id' => $tenant->id,
            'project_id' => $project->id, 'number' => 'Q-1', 'kind' => 'observation',
            'title' => 'Chain fixture', 'description' => 'Fixture for chain verification',
            'created_at' => now(), 'updated_at' => now()]);
        DB::table('knowledge_sources')->insert(['id' => 7, 'tenant_id' => $tenant->id,
            'project_id' => $project->id, 'public_id' => (string) \Illuminate\Support\Str::uuid(),
            'collection' => 'project', 'title' => 'Chain fixture source', 'source_type' => 'specification',
            'authority_level' => 'project_contract', 'sha256' => str_repeat('a', 64),
            'storage_path' => 'test/chain-fixture', 'byte_size' => 1, 'mime_type' => 'text/plain',
            'created_at' => now(), 'updated_at' => now()]);
        TenantContext::clear();
        $this->spec = ChainSpec::all()['quality'];
    }

    public function test_a_hundred_record_chain_verifies_intact(): void
    {
        $this->seedChain(itemId: 1, count: 100);

        $result = ChainVerifier::verify($this->spec, 1);

        $this->assertSame(ChainVerifier::OK, $result['status']);
        $this->assertSame(100, $result['records']);
        $this->assertNull($result['first_invalid_sequence']);
        $this->assertTrue($result['hash_recomputed']);
    }

    public function test_mutating_record_37_reports_37_and_treats_38_to_100_as_untrusted(): void
    {
        // Codex's critical test, to its numbers. The wrong answer here -
        // "99 valid, 1 invalid" - is the one that lets a tampered ledger pass.
        $ids = $this->seedChain(itemId: 1, count: 100);

        DB::table('quality_item_events')->where('id', $ids[36])->update([
            'note' => 'Quietly changed after the fact',
        ]);

        $result = ChainVerifier::verify($this->spec, 1);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertSame($ids[36], $result['first_invalid_sequence'], 'Record 37 must be named as the FIRST invalid record.');
        $this->assertStringContainsString('Content altered', $result['first_invalid_reason']);
        $this->assertSame(63, $result['downstream_untrusted'], 'Records 38 to 100 must be reported as downstream-untrusted.');

        $joined = implode(' ', $result['findings']);
        $this->assertStringContainsString('DOWNSTREAM-UNTRUSTED', $joined);
        $this->assertStringContainsString('none of them is evidence', $joined);
    }

    public function test_breaking_the_linkage_is_caught_even_when_every_payload_still_hashes(): void
    {
        // Re-pointing an event at a different predecessor leaves every individual
        // record self-consistent. Only the walk catches it.
        $ids = $this->seedChain(itemId: 1, count: 10);

        DB::table('quality_item_events')->where('id', $ids[5])->update([
            'previous_event_hash' => hash('sha256', 'not the real predecessor'),
        ]);

        $result = ChainVerifier::verify($this->spec, 1);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertSame($ids[5], $result['first_invalid_sequence']);
        $this->assertStringContainsString('Linkage broken', $result['first_invalid_reason']);
        $this->assertSame(4, $result['downstream_untrusted']);
    }

    public function test_deleting_the_oldest_records_is_caught_at_the_genesis_check(): void
    {
        // Truncating from the front is the quietest attack: what remains is a
        // perfectly valid chain that simply starts later. The genesis rule is the
        // only thing standing between that and an intact verdict.
        $ids = $this->seedChain(itemId: 1, count: 10);

        DB::table('quality_item_events')->whereIn('id', array_slice($ids, 0, 3))->delete();

        $result = ChainVerifier::verify($this->spec, 1);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertStringContainsString('removed from the start', $result['first_invalid_reason']);
    }

    public function test_a_deleted_record_in_the_middle_breaks_the_linkage(): void
    {
        $ids = $this->seedChain(itemId: 1, count: 10);

        DB::table('quality_item_events')->where('id', $ids[4])->delete();

        $result = ChainVerifier::verify($this->spec, 1);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertSame($ids[5], $result['first_invalid_sequence']);
    }

    public function test_an_unexpected_chain_head_is_reported(): void
    {
        // Appending to the end is the other quiet attack. The caller who knows
        // what the head should be is the only one who can catch it.
        $this->seedChain(itemId: 1, count: 5);

        $result = ChainVerifier::verify($this->spec, 1, expectedHead: hash('sha256', 'some other head'));

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertStringContainsString('Chain head does not match', implode(' ', $result['findings']));
    }

    public function test_an_empty_chain_is_reported_as_empty_rather_than_intact(): void
    {
        // "No records" and "records that verify" are different answers, and
        // collapsing them is how an emptied table reads as healthy.
        $result = ChainVerifier::verify($this->spec, 999);

        $this->assertSame(ChainVerifier::EMPTY_CHAIN, $result['status']);
        $this->assertSame(0, $result['records']);
    }

    public function test_a_chain_whose_hashes_cannot_be_recomputed_says_so_instead_of_passing(): void
    {
        // The knowledge ledger hashes Carbon instances on write and stores strings.
        // The two do not serialise identically, so content integrity cannot be
        // checked from stored data. A verifier that quietly skipped that check and
        // returned "intact" would be worse than having no verifier at all.
        $spec = ChainSpec::all()['knowledge'];
        $this->assertNotSame([], $spec->unrecomputableFields);

        $previous = null;
        for ($i = 1; $i <= 3; $i++) {
            $payload = [
                'tenant_id' => 1, 'knowledge_source_id' => 7, 'action' => 'verify',
                'from_status' => 'provisional', 'to_status' => 'verified', 'reason' => 'Reviewed',
                'actor_user_id' => 1, 'previous_event_hash' => $previous,
                'created_at' => now(), 'updated_at' => now(),
            ];
            $payload['event_hash'] = hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR));
            DB::table('knowledge_review_events')->insert($payload);
            $previous = $payload['event_hash'];
        }

        $result = ChainVerifier::verify($spec, 7);

        $this->assertSame(ChainVerifier::NOT_RECOMPUTABLE, $result['status']);
        $this->assertFalse($result['hash_recomputed']);
        $this->assertStringContainsString('content integrity is NOT', implode(' ', $result['findings']));
        $this->assertStringContainsString('does not establish the cause', implode(' ', $result['findings']));
    }

    public function test_a_canonicalized_record_verifies_end_to_end_where_the_legacy_one_could_not(): void
    {
        // Same ledger, same fields, same walk - the only difference is that the
        // writer now serialises dates and integers one way instead of whichever
        // way the value happened to arrive. That is the entire fix, and without a
        // version marker shipping it would have made every existing record look
        // tampered.
        $spec = ChainSpec::all()['knowledge'];

        $previous = null;
        for ($i = 1; $i <= 5; $i++) {
            $payload = [
                'tenant_id' => 1, 'knowledge_source_id' => 7, 'action' => 'verify',
                'from_status' => 'provisional', 'to_status' => 'verified',
                'reason' => 'Checked against the issued specification',
                'actor_user_id' => 1, 'previous_event_hash' => $previous,
                'created_at' => now(), 'updated_at' => now(),
            ];
            $hash = CanonicalPayload::hash($payload, CanonicalPayload::V2);
            DB::table('knowledge_review_events')->insert($payload + [
                'event_hash' => $hash, 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => DigestAlgorithm::CURRENT,
            ]);
            $previous = $hash;
        }

        $result = ChainVerifier::verify($spec, 7);

        $this->assertSame(ChainVerifier::OK, $result['status'],
            'Canonicalized records must verify end to end, not just for linkage.');
        $this->assertSame(5, $result['records']);
    }

    public function test_a_v2_record_with_no_recognised_digest_algorithm_is_not_recomputable_even_though_its_encoding_version_is_known(): void
    {
        // EV-13's sharpest case: hash_version says the payload was canonicalized
        // correctly, but hash_algorithm is absent - the write is incomplete, not
        // old. A verifier that treated a known encoding version as sufficient on
        // its own would be recomputing under an assumed algorithm it was never
        // told was used, which is exactly the guess this row exists to forbid.
        $spec = ChainSpec::all()['knowledge'];

        $payload = [
            'tenant_id' => 1, 'knowledge_source_id' => 7, 'action' => 'verify',
            'from_status' => 'provisional', 'to_status' => 'verified',
            'reason' => 'Checked against the issued specification',
            'actor_user_id' => 1, 'previous_event_hash' => null,
            'created_at' => now(), 'updated_at' => now(),
        ];
        $hash = CanonicalPayload::hash($payload, CanonicalPayload::V2);
        DB::table('knowledge_review_events')->insert($payload + [
            'event_hash' => $hash, 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => null,
        ]);

        $result = ChainVerifier::verify($spec, 7);

        $this->assertSame(ChainVerifier::NOT_RECOMPUTABLE, $result['status']);
        $this->assertFalse($result['hash_recomputed']);
    }

    public function test_a_v2_record_declaring_an_unrecognised_digest_algorithm_is_not_recomputable(): void
    {
        // Sharper still: the algorithm field is present but names something
        // this verifier does not know. That must never fall back to sha256 and
        // report success on a record it did not actually check.
        $spec = ChainSpec::all()['knowledge'];

        $payload = [
            'tenant_id' => 1, 'knowledge_source_id' => 7, 'action' => 'verify',
            'from_status' => 'provisional', 'to_status' => 'verified',
            'reason' => 'Checked against the issued specification',
            'actor_user_id' => 1, 'previous_event_hash' => null,
            'created_at' => now(), 'updated_at' => now(),
        ];
        $hash = CanonicalPayload::hash($payload, CanonicalPayload::V2);
        DB::table('knowledge_review_events')->insert($payload + [
            'event_hash' => $hash, 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => 'sha3-256',
        ]);

        $result = ChainVerifier::verify($spec, 7);

        $this->assertSame(ChainVerifier::NOT_RECOMPUTABLE, $result['status']);
        $this->assertFalse($result['hash_recomputed']);
    }

    public function test_tampering_with_a_canonicalized_record_is_caught_on_content(): void
    {
        // The check that legacy records cannot have. This is what content
        // integrity actually buys.
        $spec = ChainSpec::all()['knowledge'];

        $previous = null;
        $ids = [];
        for ($i = 1; $i <= 5; $i++) {
            $payload = [
                'tenant_id' => 1, 'knowledge_source_id' => 7, 'action' => 'verify',
                'from_status' => 'provisional', 'to_status' => 'verified',
                'reason' => 'Reason '.$i, 'actor_user_id' => 1,
                'previous_event_hash' => $previous,
                'created_at' => now(), 'updated_at' => now(),
            ];
            $hash = CanonicalPayload::hash($payload, CanonicalPayload::V2);
            $ids[] = DB::table('knowledge_review_events')->insertGetId($payload + [
                'event_hash' => $hash, 'hash_version' => CanonicalPayload::V2, 'hash_algorithm' => DigestAlgorithm::CURRENT,
            ]);
            $previous = $hash;
        }

        DB::table('knowledge_review_events')->where('id', $ids[2])
            ->update(['reason' => 'A justification nobody wrote']);

        $result = ChainVerifier::verify($spec, 7);

        $this->assertSame(ChainVerifier::BROKEN, $result['status']);
        $this->assertSame($ids[2], $result['first_invalid_sequence']);
        $this->assertStringContainsString('Content altered', $result['first_invalid_reason']);
        $this->assertSame(2, $result['downstream_untrusted']);
    }

    public function test_canonicalization_survives_the_round_trip_that_broke_the_original(): void
    {
        // A Carbon instance and the string the database returns for it must hash
        // identically. That single mismatch is what made the entire knowledge
        // ledger unverifiable.
        $written = ['at' => now(), 'n' => 7];
        $readBack = ['at' => now()->format('Y-m-d H:i:s'), 'n' => '7'];

        $this->assertSame(
            CanonicalPayload::hash($written, CanonicalPayload::V2),
            CanonicalPayload::hash($readBack, CanonicalPayload::V2),
        );

        // And the old rule demonstrably did not.
        $this->assertNotSame(
            CanonicalPayload::hash($written, CanonicalPayload::V1),
            CanonicalPayload::hash($readBack, CanonicalPayload::V1),
        );
    }

    /** @return list<int> inserted ids in order */
    private function seedChain(int $itemId, int $count): array
    {
        $ids = [];
        $previous = null;

        for ($i = 1; $i <= $count; $i++) {
            $payload = [
                'tenant_id' => 1,
                'project_id' => 1,
                'quality_item_id' => $itemId,
                'event_type' => 'status',
                'from_status' => 'open',
                'to_status' => 'in_progress',
                'note' => 'Event '.$i,
                'classification' => 'assertion',
                'actor_user_id' => 1,
                'previous_event_hash' => $previous,
            ];
            $payload['event_hash'] = hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR));
            $payload['created_at'] = now();
            $payload['updated_at'] = now();

            $ids[] = (int) DB::table('quality_item_events')->insertGetId($payload + ['project_id' => 1]);
            $previous = $payload['event_hash'];
        }

        return $ids;
    }
}
