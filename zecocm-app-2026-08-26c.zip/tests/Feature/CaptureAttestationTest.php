<?php

namespace Tests\Feature;

use App\Domain\Provenance\CaptureAttestation;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

/**
 * B5 / EV-11: what the server actually knows about when a photograph was taken.
 *
 * Codex's line about the old implementation, which these tests exist to make
 * impossible to earn again:
 *
 *   "Your 'strong confidence' badge means someone typed consistent numbers into
 *   three form fields."
 */
class CaptureAttestationTest extends TestCase
{
    private DateTimeImmutable $received;

    protected function setUp(): void
    {
        parent::setUp();
        $this->received = new DateTimeImmutable('2026-08-25T14:00:00+00:00');
    }

    public function test_a_consistent_liar_no_longer_earns_the_strongest_label(): void
    {
        // A client supplying perfectly self-consistent numbers gets a finding
        // that says "the device asserts this", not a grade that reads as
        // verification.
        $attestation = CaptureAttestation::attest($this->received, [
            'device_wall_clock' => '2026-08-25T13:59:58+00:00',
            'monotonic_at_capture' => 1000.0,
            'monotonic_at_transmit' => 1002.0,
        ]);

        $this->assertSame(CaptureAttestation::CLAIM_CONSISTENT, $attestation['finding']);
        $this->assertStringContainsString('Consistency is not verification', $attestation['message']);
        $this->assertStringContainsString('remains the device\'s assertion', $attestation['message']);
    }

    public function test_the_capture_time_is_never_established_by_this_system(): void
    {
        // Written as a function rather than left to judgement, so the next
        // person writing a report has something to call.
        foreach ([
            ['device_wall_clock' => '2026-08-25T13:59:58+00:00'],
            ['device_wall_clock' => null],
            ['device_wall_clock' => '2026-08-25T23:00:00+00:00'],
        ] as $claims) {
            $this->assertFalse(CaptureAttestation::captureTimeIsEstablished(
                CaptureAttestation::attest($this->received, $claims)
            ));
        }
    }

    public function test_what_is_established_is_an_upper_bound_and_it_is_physics(): void
    {
        $attestation = CaptureAttestation::attest($this->received, []);

        $this->assertSame('2026-08-25T14:00:00+00:00', $attestation['established']['captured_no_later_than']);
        $this->assertSame(CaptureAttestation::CLAIM_ABSENT, $attestation['finding']);
        $this->assertSame(CaptureAttestation::BASIS_SERVER_RECEIPT, $attestation['capture_time_basis']);
    }

    public function test_a_claim_later_than_receipt_is_reported_without_alleging_a_forgery(): void
    {
        // The only finding the server can make on its own authority - and an
        // unsynchronised phone clock produces exactly this signature, so the
        // wording is about the record rather than about the person.
        $attestation = CaptureAttestation::attest($this->received, [
            'device_wall_clock' => '2026-08-25T16:30:00+00:00',
        ]);

        $this->assertSame(CaptureAttestation::CLAIM_IMPOSSIBLE, $attestation['finding']);
        $this->assertStringContainsString('cannot postdate its own upload', $attestation['message']);
        $this->assertStringContainsString('not an allegation about any person', $attestation['message']);
        $this->assertStringContainsString('unsynchronised device clock produces the same result', $attestation['message']);
    }

    public function test_an_impossible_claim_does_not_destroy_the_bound_that_still_holds(): void
    {
        // The photograph is still evidence. What it is evidence OF narrows.
        $attestation = CaptureAttestation::attest($this->received, [
            'device_wall_clock' => '2026-08-25T16:30:00+00:00',
        ]);

        $this->assertSame('2026-08-25T14:00:00+00:00', $attestation['established']['captured_no_later_than']);
        $this->assertStringContainsString('no later than receipt', $attestation['message']);
    }

    public function test_everything_the_client_said_is_preserved_verbatim_and_unpromoted(): void
    {
        // Evidence, never truth. Including EXIF when it arrives, for the same
        // reason: it is evidence of what a file says about itself.
        $claims = [
            'device_wall_clock' => '2026-08-25T13:00:00+00:00',
            'monotonic_at_capture' => 42.5,
            'exif' => ['DateTimeOriginal' => '2026:08:25 06:00:00', 'Make' => 'Acme'],
        ];

        $attestation = CaptureAttestation::attest($this->received, $claims);

        $this->assertSame($claims, $attestation['client_claims']);
        $this->assertSame('2026-08-25T13:00:00+00:00', $attestation['claimed_captured_at']);
    }

    public function test_the_rendered_statement_never_offers_a_one_word_grade(): void
    {
        // "strong" beside a photograph in a claim package will be read as
        // "verified". The label has to say what it means in the space where
        // somebody would otherwise assume.
        $statement = CaptureAttestation::statement(
            CaptureAttestation::attest($this->received, ['device_wall_clock' => '2026-08-25T13:00:00+00:00'])
        );

        $this->assertStringContainsString('Captured no later than', $statement);
        $this->assertStringContainsString('not independently verified', $statement);
        $this->assertStringNotContainsString('strong', strtolower($statement));
    }

    public function test_the_statement_for_an_impossible_claim_says_so_on_the_document(): void
    {
        $statement = CaptureAttestation::statement(
            CaptureAttestation::attest($this->received, ['device_wall_clock' => '2026-08-26T09:00:00+00:00'])
        );

        $this->assertStringContainsString('inconsistent with that', $statement);
        $this->assertStringContainsString('recorded unaltered for review', $statement);
    }

    public function test_receipt_ordering_is_recorded_because_it_is_a_fact(): void
    {
        // Whatever two devices claim about when their photographs were taken,
        // the sequence in which they reached this server is not in dispute.
        $first = CaptureAttestation::attest($this->received, [], 7);

        $this->assertSame(7, $first['established']['receipt_sequence']);
    }

    public function test_the_limits_travel_with_every_attestation(): void
    {
        $attestation = CaptureAttestation::attest($this->received, []);
        $limits = implode(' ', $attestation['does_not_establish']);

        $this->assertStringContainsString('device clock was correct', $limits);
        $this->assertStringContainsString('person who uploaded it took it', $limits);
        $this->assertStringContainsString('depicts what its caption says', $limits);
    }

    public function test_an_unparseable_claim_is_treated_as_no_claim_rather_than_as_zero(): void
    {
        $attestation = CaptureAttestation::attest($this->received, ['device_wall_clock' => 'yesterday-ish']);

        $this->assertSame(CaptureAttestation::CLAIM_ABSENT, $attestation['finding']);
        $this->assertNull($attestation['claimed_captured_at']);
    }
}
