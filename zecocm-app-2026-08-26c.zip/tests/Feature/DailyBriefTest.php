<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\DailyReport;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The Daily Project Success Brief: deterministic, cited, freshness-stamped, and
 * explicit about what it will not say.
 */
class DailyBriefTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config(['queue.default' => 'sync']);

        $this->tenant = Tenant::create([
            'name' => 'Brief CM', 'type' => 'CM firm', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('CM firm'),
            'sponsor_role' => 'cm_firm', 'is_account_owner' => true,
        ]);
        $this->user = User::create([
            'tenant_id' => $this->tenant->id, 'name' => 'Sam Ortiz',
            'email' => 'sam@brief.test', 'password' => bcrypt('password'),
        ]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create([
            'number' => 'P-700', 'name' => 'Brief Park', 'sector' => 'public', 'owner_name' => 'City of Testing',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [],
            'contract_clocks' => ['rfi_response' => ['days' => 5, 'basis' => 'working']],
        ]);
        Membership::create([
            'project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Brief CM', 'seat' => 'project_manager', 'capabilities' => ['*' => true],
        ]);
        (new CapabilityLicense)->grant($this->tenant, 'daily_brief', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    public function test_brief_refuses_schedule_position_when_no_version_is_accepted(): void
    {
        $res = $this->getJson('/api/projects/'.$this->project->id.'/brief')->assertOk();

        $this->assertSame('deterministic', $res->json('method'));
        $questions = array_column($res->json('refusals'), 'question');
        $this->assertContains('Where does the schedule say this project stands?', $questions);

        $standing = collect($res->json('sections'))->firstWhere('key', 'standing');
        $this->assertSame([], $standing['lines'], 'Position must not be reported without an accepted version.');
    }

    public function test_an_overdue_rfi_is_reported_as_a_calculation_with_its_arithmetic(): void
    {
        TenantContext::set($this->tenant->id);
        Rfi::create([
            'project_id' => $this->project->id, 'number' => 'RFI-001', 'subject' => 'Trench depth',
            'question' => 'Which detail governs?', 'raised_by_org' => 'Brief CM',
            'raised_at' => now()->subDays(30)->toDateString(), 'ball_in_court' => 'City of Testing',
            'status' => 'open', 'ai_dispositions' => [], 'routing_history' => [],
        ]);
        TenantContext::clear();

        $res = $this->getJson('/api/projects/'.$this->project->id.'/brief')->assertOk();
        $decisions = collect($res->json('sections'))->firstWhere('key', 'decisions');
        $line = collect($decisions['lines'])->first(fn ($l) => str_contains($l['text'], 'RFI-001'));

        $this->assertNotNull($line, 'An RFI past its contract clock must appear.');
        $this->assertSame('deterministic_calculation', $line['classification']);
        $this->assertNotEmpty($line['citations']);
        $this->assertStringContainsString('working days elapsed', $line['working_out']);
        $this->assertStringContainsString('does not attribute responsibility', $line['working_out']);
    }

    public function test_a_line_can_never_exist_without_a_citation(): void
    {
        $this->expectException(\LogicException::class);
        \App\Domain\Brief\BriefLine::make(
            'Something confident.',
            \App\Domain\Brief\BriefLine::FACT,
            [],
            \App\Domain\Brief\Freshness::eventDriven('nothing'),
        );
    }

    public function test_stale_evidence_lowers_confidence_and_says_why(): void
    {
        $stale = \App\Domain\Brief\Freshness::cadence('daily reports', new \DateTimeImmutable('-9 days'), 48, 'every working day');
        $line = \App\Domain\Brief\BriefLine::make(
            'A daily report exists.',
            \App\Domain\Brief\BriefLine::FACT,
            [['kind' => 'daily_report', 'ref' => '1 Jan', 'id' => 1, 'route' => 'daily']],
            $stale,
        );

        $this->assertSame('medium', $line->confidence);
        $this->assertStringContainsString('expected every working day', $line->confidenceReason);
    }

    public function test_an_unsigned_daily_report_is_flagged_as_not_yet_evidence(): void
    {
        TenantContext::set($this->tenant->id);
        DailyReport::create([
            'project_id' => $this->project->id, 'report_date' => now()->toDateString(),
            'work_performed' => 'Trenching', 'locked' => false, 'foreman_id' => $this->user->id,
            'cost_code_notes' => [], 'corrections' => [],
        ]);
        TenantContext::clear();

        $res = $this->getJson('/api/projects/'.$this->project->id.'/brief')->assertOk();
        $decisions = collect($res->json('sections'))->firstWhere('key', 'decisions');
        $line = collect($decisions['lines'])->first(fn ($l) => str_contains($l['text'], 'not sealed'));

        $this->assertNotNull($line);
        $this->assertSame('policy', $line['classification']);
        $this->assertStringContainsString('it is not evidence', $line['text']);
    }

    public function test_the_brief_is_licence_gated(): void
    {
        (new CapabilityLicense)->revoke($this->tenant, 'daily_brief', null, 'Test');

        $this->getJson('/api/projects/'.$this->project->id.'/brief')->assertStatus(402);
    }

    public function test_another_tenants_project_fails_closed(): void
    {
        $other = Tenant::create([
            'name' => 'Other', 'type' => 'City', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('City'), 'sponsor_role' => 'owner_agency', 'is_account_owner' => true,
        ]);
        TenantContext::set($other->id);
        $foreign = Project::create([
            'number' => 'X-1', 'name' => 'Not yours', 'sector' => 'public', 'owner_name' => 'Other City',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => [],
        ]);
        TenantContext::clear();

        $this->getJson('/api/projects/'.$foreign->id.'/brief')->assertStatus(404);
    }
}
