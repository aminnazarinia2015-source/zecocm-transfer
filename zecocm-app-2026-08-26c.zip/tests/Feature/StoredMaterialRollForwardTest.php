<?php

namespace Tests\Feature;

use App\Domain\Payment\PayApplicationReview;
use App\Domain\Payment\StoredMaterialRollForward;
use Tests\TestCase;

/**
 * The two ways stored material goes wrong that nothing else in this system can
 * see, because both leave the current application's arithmetic perfectly valid.
 */
class StoredMaterialRollForwardTest extends TestCase
{
    public function test_the_double_carry_is_caught_although_every_total_is_under_the_cap(): void
    {
        // Codex's case. PA-3: $20,000 completed, $80,000 stored. PA-4: $100,000
        // completed, still $80,000 stored. Completed work rose by exactly the
        // stored balance and the stored balance never moved. Cumulative billing
        // on a $200,000 line is still under the cap, so the over-billing
        // validator is silent - correctly. It cannot see composition.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 80_000_00, 'completed_cents' => 100_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => null]],
        );

        $this->assertCount(1, $findings);
        $this->assertSame('stored_material_double_carry', $findings[0]['code']);
        $this->assertSame(PayApplicationReview::HARD_INVALID, $findings[0]['severity']);
        $this->assertSame(80_000_00, $findings[0]['unreconciled_cents']);

        // "Potential", because the arithmetic is certain and the intent is not.
        $this->assertStringContainsString('Potential duplicate billing', $findings[0]['message']);
    }

    public function test_declaring_the_separate_scope_resolves_the_double_carry(): void
    {
        // A line can legitimately hold stored material while unrelated scope on
        // the same line is installed. The cure is to say so, not to be believed
        // by default.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 80_000_00, 'completed_cents' => 100_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => 'Completed work is site concrete; the stored pipe is not yet installed.']],
        );

        $this->assertSame([], $findings);
    }

    public function test_installing_the_stored_material_reconciles(): void
    {
        // The honest path: stored falls by what moved, completed rises by it.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 100_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => null]],
        );

        $this->assertSame([], $findings);
    }

    public function test_stored_material_that_simply_disappears_is_refused(): void
    {
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 20_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => null]],
        );

        $this->assertSame('stored_material_rollforward_unreconciled', $findings[0]['code']);
        $this->assertSame(80_000_00, $findings[0]['unreconciled_cents']);
    }

    public function test_a_declared_credit_accounts_for_removed_material(): void
    {
        // Material left the job and the money comes back, said out loud.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 20_000_00,
                'adjustment_cents' => -80_000_00, 'adjustment_reason' => 'Pipe returned to supplier; credit issued on invoice 4471.']],
        );

        $this->assertSame([], $findings);
    }

    public function test_an_adjustment_with_no_reason_does_not_account_for_anything(): void
    {
        // A silent credit is the same evidentiary problem as a silent charge.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 20_000_00,
                'adjustment_cents' => -80_000_00, 'adjustment_reason' => '   ']],
        );

        $this->assertSame('stored_material_rollforward_unreconciled', $findings[0]['code']);
        $this->assertStringContainsString('no reason given', $findings[0]['message']);
    }

    public function test_a_line_that_vanishes_carrying_paid_stored_material_is_refused(): void
    {
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [],
        );

        $this->assertSame('stored_material_rollforward_unreconciled', $findings[0]['code']);
        $this->assertStringContainsString('does not appear on this one at all', $findings[0]['message']);
    }

    public function test_a_partial_installation_reports_only_the_gap(): void
    {
        // $80,000 stored, $30,000 installed, stored drops to zero. $50,000 is
        // unaccounted for - and the finding says $50,000, not $80,000.
        $findings = StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 80_000_00, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 50_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => null]],
        );

        $this->assertSame(50_000_00, $findings[0]['unreconciled_cents']);
    }

    public function test_a_line_that_never_carried_stored_material_is_not_examined(): void
    {
        $this->assertSame([], StoredMaterialRollForward::findings(
            [7 => ['stored_cents' => 0, 'completed_cents' => 20_000_00]],
            [7 => ['item_number' => '004', 'stored_cents' => 0, 'completed_cents' => 90_000_00,
                'adjustment_cents' => 0, 'adjustment_reason' => null]],
        ));
    }
}
