<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleVersionEvent;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Schedule Intelligence surfaces 1-3: the version timeline, the disposition gate, and
 * the durable analysis-run history.
 */
class ScheduleIntelligenceSurfacesTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'app.provenance_key' => 'test-provenance-signing-key',
            'schedule.require_malware_scan' => false,
            'queue.default' => 'sync',
        ]);
        Storage::fake(config('filesystems.default'));

        $this->tenant = Tenant::create(['name' => 'Surface CM', 'type' => 'CM firm', 'entitlements' => Tenant::defaultEntitlements('CM firm')]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Reviewer', 'email' => 'reviewer@example.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create([
            'number' => 'PN-851', 'name' => 'Schedule Surface Test', 'sector' => 'public', 'owner_name' => 'City',
            'state' => 'CA', 'funding_source' => 'local', 'contract_clocks' => [], 'org_structure' => [],
        ]);
        Membership::create([
            'project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Surface CM', 'seat' => 'project_manager', 'capabilities' => ['*' => true],
        ]);
        (new CapabilityLicense)->grant($this->tenant, 'schedule_intelligence', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_submitter_label_never_becomes_a_formal_disposition(): void
    {
        $this->upload('Approved Baseline', 'baseline', null, 480);

        $version = $this->getJson('/api/schedule-versions?project_id='.$this->project->id)
            ->assertOk()->json('versions.0');

        $this->assertSame('Approved Baseline', $version['label']);
        $this->assertSame('submitted', $version['review_status']);
        $this->assertContains('no_acceptance_disposition', array_column($version['anomalies'], 'code'));
    }

    public function test_schedule_disposition_envelope_previews_without_acting_and_requires_explicit_confirmation(): void
    {
        $id = $this->upload('Update 01', 'update', null, 480);

        $this->getJson('/api/decisions/schedule/'.$id.'/envelope?disposition=accepted')
            ->assertOk()
            ->assertJsonPath('action', 'schedule.disposition.accepted')
            ->assertJsonPath('clock.configured', false);
        $this->assertSame(0, $this->dispositionEvents($id), 'Previewing an envelope must record nothing.');

        $this->postJson('/api/decisions/schedule/'.$id.'/authorize', ['disposition' => 'accepted'])
            ->assertStatus(422);
        $this->assertSame(0, $this->dispositionEvents($id), 'An unconfirmed authorisation must record nothing.');
    }

    public function test_schedule_disposition_authorization_appends_and_preserves_prior_event(): void
    {
        $id = $this->upload('Update 02', 'update', null, 480);

        $first = $this->postJson('/api/decisions/schedule/'.$id.'/authorize', [
            'confirm' => true, 'disposition' => 'accepted', 'note' => 'Human review completed.',
        ])->assertOk();
        $firstEvent = $first->json('seal.event_id');

        $second = $this->postJson('/api/decisions/schedule/'.$id.'/authorize', [
            'confirm' => true, 'disposition' => 'rejected', 'note' => 'Later human determination.',
        ])->assertOk();

        $this->assertSame(2, $this->dispositionEvents($id));
        $this->assertDatabaseHas('schedule_version_events', ['id' => $firstEvent, 'disposition' => 'accepted']);
        $this->assertNotSame($firstEvent, $second->json('seal.event_id'));
    }

    public function test_analysis_history_shows_supersession_without_erasing_earlier_runs(): void
    {
        $baseline = $this->upload('Baseline', 'baseline', null, 480);
        $update = $this->upload('Update 03', 'update', $baseline, 960);

        $first = $this->withHeader('Idempotency-Key', 'surface-run-1')->postJson('/api/schedule/analyze', [
            'project_id' => $this->project->id, 'from_version_id' => $baseline, 'to_version_id' => $update,
        ])->json('id');
        $second = $this->withHeader('Idempotency-Key', 'surface-run-2')->postJson('/api/schedule/analyze', [
            'project_id' => $this->project->id, 'from_version_id' => $baseline, 'to_version_id' => $update,
        ])->json('id');

        $runs = $this->getJson('/api/schedule/analysis-history?project_id='.$this->project->id.'&from_version_id='.$baseline.'&to_version_id='.$update)
            ->assertOk()->json('runs');

        $this->assertCount(2, $runs);
        $this->assertSame($second, $runs[0]['id']);
        $this->assertSame($first, $runs[0]['supersedes_run_id']);
        $this->assertFalse($runs[0]['superseded']);
        $this->assertSame($first, $runs[1]['id']);
        $this->assertTrue($runs[1]['superseded']);
        $this->assertSame($second, $runs[1]['superseded_by_run_id']);
        $this->assertDatabaseHas('analysis_runs', ['id' => $first]);
        $this->assertDatabaseHas('analysis_runs', ['id' => $second]);

        // Supersession is a presentation relationship. It must never acquire the language
        // of fault: a later reading is not an accusation about the earlier one.
        $this->assertStringNotContainsString('fault', strtolower(json_encode($runs)));
        $this->assertStringNotContainsString('responsible for delay', strtolower(json_encode($runs)));
    }

    /**
     * The one rule the ledger cannot bend: a magnitude whose basis cannot be named is
     * never divided by either constant. 1440 and 480 are not interchangeable, and
     * guessing between them is how "+25 calendar days" once printed as "+75 work days".
     */
    public function test_a_magnitude_with_no_nameable_basis_is_reported_as_basis_unknown(): void
    {
        $presenter = new \App\Domain\Schedule\SchedulePresenter;

        $this->assertNull(\App\Domain\Schedule\SchedulePresenter::inferredBasis(null, 'logic'),
            'A logic change has no time basis to infer.');

        $grant = new \App\Domain\Schedule\ProjectGrant(
            project: $this->project, userId: $this->user->id, seat: 'project_manager',
            organization: 'Surface CM', capabilities: ['*' => true], platformSupport: false,
        );

        $delta = new \App\Models\ScheduleDelta;
        $delta->forceFill([
            'id' => 1, 'delta_type' => 'logic', 'field' => 'predecessors',
            'magnitude_minutes' => 4321, 'magnitude_basis' => null,
            'classification' => 'deterministic_calculation', 'explanation' => 'Ambiguous magnitude.',
        ]);

        $row = $presenter->delta($delta, $grant);

        $this->assertSame('basis_unknown', $row['magnitude_basis_status']);
        $this->assertNull($row['magnitude_calendar_days'], 'Never divided by 1440 on a guess.');
        $this->assertNull($row['magnitude_standard_work_days'], 'Never divided by 480 on a guess.');
        $this->assertSame(4321, $row['magnitude_minutes'], 'The raw quantity is still reported.');
    }

    /** Formal accept/reject events only - the ingest itself also appends an event. */
    private function dispositionEvents(int $versionId): int
    {
        TenantContext::set($this->tenant->id);
        $count = ScheduleVersionEvent::query()
            ->where('schedule_version_id', $versionId)
            ->whereIn('disposition', ['accepted', 'rejected'])
            ->count();
        TenantContext::clear();

        return $count;
    }

    private function upload(string $label, string $kind, ?int $parentId, int $secondDuration): int
    {
        $csv = implode("\n", [
            'activity_code,name,duration_minutes,planned_start,planned_finish,predecessors,calendar',
            'A100,Mobilize,480,2026-08-24 08:00,2026-08-24 17:00,,Standard',
            'A200,Excavate,'.$secondDuration.',2026-08-25 08:00,2026-08-27 17:00,A100 FS,Standard',
        ]);
        $payload = [
            'project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent(str_replace(' ', '-', strtolower($label)).'.csv', $csv),
            'kind' => $kind, 'label' => $label, 'data_date' => '2026-08-24',
        ];
        if ($parentId !== null) {
            $payload['parent_version_id'] = $parentId;
        }

        return (int) $this->post('/api/schedule-versions', $payload, ['Accept' => 'application/json'])
            ->assertCreated()->json('id');
    }
}
