<?php

namespace Tests\Feature;

use App\Domain\Evolution\SelfObservation;
use App\Domain\Knowledge\AcquisitionGate;
use App\Models\AcquiredDocument;
use App\Models\AcquisitionWindow;
use App\Models\CapabilityGap;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use DateTimeImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * The sealed corpus, and the system proposing its own next build.
 *
 * Two subsystems, one principle: ZecoCM asks, a named person authorises, and
 * nothing the machine wants happens because the machine wanted it.
 */
class GovernedEvolutionTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Steward',
            'email' => 'steward@northgate.test', 'password' => bcrypt('password')]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    // ---- the sealed corpus ---------------------------------------------------

    public function test_with_no_window_at_all_nothing_outside_the_record_may_be_read(): void
    {
        // The resting state. Not "sealed unless configured otherwise" - sealed.
        $verdict = AcquisitionGate::permits(null, 'https://www.dir.ca.gov/rates.pdf');

        $this->assertFalse($verdict['permitted']);
        $this->assertStringContainsString('ZecoCM is sealed', $verdict['reason']);
    }

    public function test_an_expired_window_is_refused_at_the_moment_of_the_reach(): void
    {
        // Checked at USE, not trusted from the status column and not waiting
        // for a scheduled task to notice. This codebase has been bitten by a
        // job that read its authorisation at dispatch instead of execution.
        $window = $this->window(['expires_at' => now()->subMinute()]);

        $verdict = AcquisitionGate::permits($window, 'https://www.dir.ca.gov/rates.pdf');

        $this->assertFalse($verdict['permitted']);
        $this->assertStringContainsString('The reach it granted is gone', $verdict['reason']);
    }

    public function test_an_empty_allowlist_is_a_window_onto_nowhere(): void
    {
        // The single most common way an allowlist becomes decorative is
        // defaulting an empty one to "everything".
        $window = $this->window(['source_allowlist' => []]);

        $this->assertFalse(AcquisitionGate::permits($window, 'https://anything.example')['permitted']);
    }

    public function test_a_lookalike_host_does_not_satisfy_the_allowlist(): void
    {
        // dir.ca.gov.attacker.example is not dir.ca.gov, and both a
        // str_contains and a loose suffix check would say otherwise.
        $allowlist = ['dir.ca.gov'];

        $this->assertTrue(AcquisitionGate::allowed('https://www.dir.ca.gov/x.pdf', $allowlist));
        $this->assertTrue(AcquisitionGate::allowed('https://dir.ca.gov/x.pdf', $allowlist));
        $this->assertFalse(AcquisitionGate::allowed('https://dir.ca.gov.attacker.example/x.pdf', $allowlist));
        $this->assertFalse(AcquisitionGate::allowed('https://notdir.ca.gov/x.pdf', $allowlist));
    }

    public function test_a_window_that_needs_two_people_does_nothing_with_one(): void
    {
        $window = $this->window(['requires_two_person' => true, 'confirmed_at' => null]);

        $verdict = AcquisitionGate::permits($window, 'https://www.dir.ca.gov/rates.pdf');
        $this->assertFalse($verdict['permitted']);
        $this->assertStringContainsString('second named person', $verdict['reason']);
    }

    public function test_the_document_count_is_a_real_limit_not_a_suggestion(): void
    {
        // Reservations rather than a count: read-then-fetch lets two workers
        // both see the last slot free and both take it.
        $window = $this->window(['max_documents' => 1]);

        $this->assertTrue(AcquisitionGate::reserveSlot($window, 'https://www.dir.ca.gov/first.pdf')['granted']);

        $second = AcquisitionGate::reserveSlot($window->fresh(), 'https://www.dir.ca.gov/second.pdf');
        $this->assertFalse($second['granted']);
        $this->assertStringContainsString('limit of 1 document', $second['reason']);

        // And a reach that never happened gives its slot back.
        AcquisitionGate::releaseSlot($window->fresh());
        $this->assertTrue(AcquisitionGate::reserveSlot($window->fresh(), 'https://www.dir.ca.gov/third.pdf')['granted']);
    }

    public function test_an_open_window_within_its_shape_permits_the_reach(): void
    {
        $this->assertTrue(AcquisitionGate::permits($this->window(), 'https://www.dir.ca.gov/rates.pdf')['permitted']);
    }

    public function test_quarantined_material_is_not_reachable_at_all(): void
    {
        // Not ranked low. Unreachable, on the same fail-closed principle as
        // tenancy - including for states nobody has invented yet.
        $window = $this->window();
        $quarantined = $this->document($window);
        $this->assertFalse(AcquisitionGate::isRetrievable($quarantined));

        $quarantined->update(['quarantine_state' => AcquisitionGate::VERIFIED, 'verified_by' => $this->user->id, 'verified_at' => now()]);
        $this->assertTrue(AcquisitionGate::isRetrievable($quarantined->fresh()));

        $quarantined->update(['quarantine_state' => 'some_state_invented_later']);
        $this->assertFalse(AcquisitionGate::isRetrievable($quarantined->fresh()));
    }

    public function test_the_shape_of_an_open_window_cannot_be_widened_after_the_fact(): void
    {
        // Widening an authorisation somebody already granted is the same act as
        // granting a new one without asking.
        $window = $this->window();

        $this->expectException(\RuntimeException::class);
        $window->update(['source_allowlist' => ['dir.ca.gov', 'anything-else.example']]);
    }

    public function test_retraction_stops_the_reach_without_erasing_what_was_believed(): void
    {
        // The hard case. Deleting it would destroy the record of what the
        // system believed when it answered, which is the whole product.
        $window = $this->window();
        $doc = $this->document($window);
        $doc->update(['quarantine_state' => AcquisitionGate::VERIFIED, 'verified_by' => $this->user->id, 'verified_at' => now()]);

        AcquisitionGate::retract($doc, 'The window was opened without the second confirmation it required.');

        $this->assertFalse(AcquisitionGate::isRetrievable($doc->fresh()));
        $this->assertNotNull($doc->fresh()->retracted_at);
        $this->assertNotNull($doc->fresh()->verified_at, 'The fact that it was once verified must survive.');
    }

    public function test_the_refusal_asks_rather_than_reaching(): void
    {
        $text = AcquisitionGate::requestText('current DIR prevailing wage determinations for Los Angeles County');

        $this->assertStringContainsString('sealed and will not go looking', $text);
        $this->assertStringContainsString('acquisition window', $text);
    }

    // ---- governed self-improvement -------------------------------------------

    public function test_one_person_asking_five_times_is_not_a_missing_capability(): void
    {
        // Occurrences alone rewards a single enthusiastic user.
        $gap = null;
        for ($i = 0; $i < 6; $i++) {
            $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|stop-notice-deadline',
                'Questions about stop notice deadlines return nothing', ['question' => 'q'], $this->tenant->id, 'user-1');
        }

        $this->assertSame(6, $gap->occurrences);
        $this->assertSame(1, $gap->distinct_askers);
        $this->assertFalse(SelfObservation::readyToPropose($gap));
    }

    public function test_several_people_hitting_the_same_wall_earns_attention(): void
    {
        $gap = null;
        foreach (['a', 'b', 'c', 'a', 'b'] as $asker) {
            $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|stop-notice-deadline',
                'Questions about stop notice deadlines return nothing', ['question' => 'q'], $this->tenant->id, $asker);
        }

        $this->assertTrue(SelfObservation::readyToPropose($gap));
    }

    public function test_being_confidently_wrong_earns_attention_far_sooner_than_refusing(): void
    {
        // A refusal is the system working. A steward correction is not, and the
        // thresholds say so.
        $this->assertLessThan(
            SelfObservation::PROPOSAL_THRESHOLD[SelfObservation::NO_MATCH]['occurrences'],
            SelfObservation::PROPOSAL_THRESHOLD[SelfObservation::STEWARD_CORRECTION]['occurrences'],
        );

        $gap = null;
        for ($i = 0; $i < 2; $i++) {
            $gap = SelfObservation::observe(SelfObservation::STEWARD_CORRECTION, 'k|retention-answer-wrong',
                'A steward corrected our retention answer', [], $this->tenant->id, 'steward-1');
        }

        $this->assertTrue(SelfObservation::readyToPropose($gap));
    }

    public function test_somebody_paying_for_something_unbuilt_is_worth_hearing_once(): void
    {
        $gap = SelfObservation::observe(SelfObservation::UNBUILT_CAPABILITY_LICENSED, 'lic|closeout',
            'An account is licensed for closeout, which is not built', [], $this->tenant->id, 'account-9');

        $this->assertTrue(SelfObservation::readyToPropose($gap));
    }

    public function test_a_gap_below_the_bar_cannot_be_pushed_onto_somebody_desk(): void
    {
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|rare', 'Rare thing', [], $this->tenant->id, 'a');

        $this->expectException(\RuntimeException::class);
        SelfObservation::propose($gap, 'Build the rare thing.');
    }

    public function test_observing_a_protected_capability_is_never_refused(): void
    {
        // Refusing to NOTICE is not a control, it is blindness. The observation
        // is recorded; what is refused is turning it into a proposal.
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|refusal-friction',
            'Users report the system is too conservative when documents disagree', [],
            $this->tenant->id, 'a', 'refusal_policy', 'p1');

        $this->assertSame('refusal_policy', $gap->target_capability);
        $this->assertTrue(SelfObservation::isProtected($gap->target_capability));
    }

    public function test_a_protected_capability_never_becomes_an_actionable_proposal(): void
    {
        // And it is caught by WHAT IS TOUCHED, not by the words used. Nothing
        // in this title contains the string "refusal_policy" - a substring
        // match would have let it straight through, which is why the substring
        // version was theatre.
        $gap = null;
        foreach (['a', 'b', 'c'] as $asker) {
            for ($i = 0; $i < 2; $i++) {
                $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|refusal-friction',
                    'Users report the system is too conservative when documents disagree', ['q' => 'x'],
                    $this->tenant->id, $asker, 'refusal_policy', 'p'.$asker);
            }
        }

        $this->assertTrue(SelfObservation::readyToPropose($gap));
        $this->expectException(\RuntimeException::class);
        SelfObservation::propose($gap, 'Loosen the conflict-refusal threshold.');
    }

    public function test_the_protection_is_enforced_again_at_authorization(): void
    {
        // A control enforced only at creation is one control wearing two hats:
        // anything that writes a row directly then walks in through the second
        // door.
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|t', 'T', [],
            $this->tenant->id, 'a', 'tenancy', 'p1');
        $gap->forceFill(['status' => SelfObservation::PROPOSED])->save();

        $this->expectException(\RuntimeException::class);
        SelfObservation::decide($gap->fresh(), $this->user->id, true, 'Looks reasonable.');
    }

    public function test_three_people_on_one_broken_project_is_one_incident_not_three(): void
    {
        // Distinct askers alone would read this as three independent reports.
        $gap = null;
        foreach (['a', 'b', 'c'] as $asker) {
            $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|same-project',
                'Same wall', [], $this->tenant->id, $asker, null, 'project-7');
        }

        $this->assertSame(3, $gap->distinct_askers);
        $this->assertSame(1, $gap->distinct_projects);
    }

    public function test_a_gap_records_whether_any_of_it_came_from_outside_the_builders(): void
    {
        // Counts drawn from us testing our own known gaps are false
        // sophistication dressed as market signal.
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|internal', 'Internal', [],
            $this->tenant->id, 'dev-1', null, 'p1', false);
        $this->assertFalse((bool) $gap->includes_external_usage);

        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|internal', 'Internal', [],
            $this->tenant->id, 'real-user', null, 'p1', true);
        $this->assertTrue((bool) $gap->fresh()->includes_external_usage);
    }

    public function test_somebody_leaving_the_designed_path_is_the_strongest_signal_there_is(): void
    {
        // A no_match says the assistant could not answer. A workflow escape
        // says a competent person went around the product.
        $gap = null;
        foreach (['a', 'b', 'a'] as $i => $asker) {
            $gap = SelfObservation::observe(SelfObservation::WORKFLOW_ESCAPE, 'k|parallel-spreadsheet',
                'Users keep a spreadsheet for something ZecoCM claims to handle', ['note' => 'export then edit offline'],
                $this->tenant->id, $asker, null, 'p'.$i, true);
        }

        $this->assertTrue(SelfObservation::readyToPropose($gap));
        $this->assertLessThan(
            SelfObservation::PROPOSAL_THRESHOLD[SelfObservation::NO_MATCH]['occurrences'],
            SelfObservation::PROPOSAL_THRESHOLD[SelfObservation::WORKFLOW_ESCAPE]['occurrences'],
        );
    }

    public function test_a_declined_proposal_is_recorded_as_deliberately_as_an_authorized_one(): void
    {
        // A gap that keeps recurring after somebody decided against it is a
        // different and more interesting fact than one nobody has looked at.
        $gap = null;
        foreach (['a', 'b', 'c'] as $asker) {
            for ($i = 0; $i < 2; $i++) {
                $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|thing',
                    'A thing', ['question' => 'q'], $this->tenant->id, $asker);
            }
        }

        SelfObservation::propose($gap, 'Build the thing.', 'A7');
        SelfObservation::decide($gap, $this->user->id, false, 'Out of scope until the pilot is done.');

        $fresh = $gap->fresh();
        $this->assertSame(SelfObservation::DECLINED, $fresh->status);
        $this->assertSame('Out of scope until the pilot is done.', $fresh->decision_reason);
        $this->assertSame('A7', $fresh->register_row);
    }

    public function test_nothing_may_be_decided_that_was_never_proposed(): void
    {
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|x', 'X', [], $this->tenant->id, 'a');

        $this->expectException(\RuntimeException::class);
        SelfObservation::decide($gap, $this->user->id, true, 'Sure.');
    }

    public function test_the_clustering_rule_is_readable_and_forgiving_of_phrasing(): void
    {
        // Two people never phrase a question identically, and a key that
        // demanded they do would make a thousand clusters of one.
        $a = SelfObservation::clusterKeyFor('What is the deadline for a stop payment notice?', 'ca-public');
        $b = SelfObservation::clusterKeyFor('stop payment notice deadline - what is it', 'ca-public');

        $this->assertSame($a, $b);
        // And scope separates otherwise-identical questions.
        $this->assertNotSame($a, SelfObservation::clusterKeyFor('stop payment notice deadline', 'nv-public'));
    }

    public function test_evidence_keeps_examples_but_never_becomes_a_transcript(): void
    {
        $gap = null;
        for ($i = 0; $i < 20; $i++) {
            $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'k|many',
                'Many', ['question' => 'question '.$i], $this->tenant->id, 'asker-'.($i % 4));
        }

        $this->assertSame(20, $gap->occurrences);
        $this->assertSame(4, $gap->distinct_askers);
        $this->assertCount(5, $gap->evidence['samples']);
    }

    // ---- helpers -------------------------------------------------------------

    private function window(array $overrides = []): AcquisitionWindow
    {
        return AcquisitionWindow::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'subject' => 'DIR prevailing wage determinations',
            'justification' => 'TRACE refused a wage question for want of the governing determination.',
            'source_allowlist' => ['dir.ca.gov'],
            'max_documents' => 25,
            'max_total_bytes' => 52_428_800,
            'status' => AcquisitionGate::OPEN,
            'opened_by' => $this->user->id,
            'opened_at' => now(),
            'expires_at' => now()->addHour(),
        ], $overrides));
    }

    private function document(AcquisitionWindow $window): AcquiredDocument
    {
        return AcquiredDocument::create([
            'tenant_id' => $this->tenant->id,
            'acquisition_window_id' => $window->id,
            'source_identifier' => 'https://www.dir.ca.gov/first.pdf',
            'retrieved_at' => now(),
            'content_hash' => hash('sha256', 'first'.$window->id),
            'byte_size' => 1024,
        ]);
    }
}
