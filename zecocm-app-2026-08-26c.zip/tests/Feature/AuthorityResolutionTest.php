<?php

namespace Tests\Feature;

use App\Domain\Ai\AuthorityResolution;
use PHPUnit\Framework\TestCase;

/**
 * TR-17: which source CONTROLS, as opposed to which one matched best.
 *
 * The four scenarios below are Codex's own acceptance tests, and its note on
 * them was: if those four pass, TR-17 is doing actual authority resolution
 * rather than document sorting.
 */
class AuthorityResolutionTest extends TestCase
{
    private array $confirmedOrder = ['status' => 'confirmed', 'citation' => 'General Conditions s. 2.4'];

    // ---- Codex's four acceptance scenarios ----------------------------------

    public function test_the_addendum_controls_where_it_applies(): void
    {
        // "Electrical trench depth?" -> 30", because the addendum applies to
        // that system and outranks the plan sheet.
        $result = AuthorityResolution::resolve([
            $this->source('addendum-2', 'Addendum 2', rank: 1, tags: [
                $this->tag('system', 'electrical'),
            ]),
            $this->source('sheet-e1', 'Sheet E-1', rank: 5),
        ], ['system' => 'electrical'], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
        $this->assertSame('Addendum 2', $result['controlling']['label']);
    }

    public function test_a_change_order_that_does_not_reach_the_area_does_not_control_it(): void
    {
        // "Irrigation trench depth in Area A?" -> the plan sheet, because
        // CO-7's scope is Area C and does not apply.
        $result = AuthorityResolution::resolve([
            $this->source('co-7', 'Change Order 7', rank: 1, tags: [
                $this->tag('area', 'Area C'),
            ]),
            $this->source('sheet-l3', 'Sheet L-3', rank: 5),
        ], ['area' => 'Area A', 'system' => 'irrigation'], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
        $this->assertSame('Sheet L-3', $result['controlling']['label']);

        $co7 = collect($result['considered'])->firstWhere('label', 'Change Order 7');
        $this->assertSame(AuthorityResolution::NOT_APPLICABLE, $co7['state']);
        $this->assertStringContainsString('not to "Area A"', $co7['reason']);
    }

    public function test_removing_the_confirmed_scope_produces_a_refusal_not_the_next_source(): void
    {
        // Codex's sharpest case. With CO-7's area scope unconfirmed, the right
        // answer is REFUSE — not the plan sheet's number, and certainly not
        // CO-7's. Ranking around an unresolved scope silently answers a
        // question the record can no longer settle.
        $result = AuthorityResolution::resolve([
            $this->source('co-7', 'Change Order 7', rank: 1, tags: [
                $this->tag('area', 'Area C', status: 'proposed'),
            ]),
            $this->source('sheet-l3', 'Sheet L-3', rank: 5),
        ], ['area' => 'Area A'], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::UNRESOLVED_APPLICABILITY, $result['state']);
        $this->assertNull($result['controlling']);
        $this->assertStringContainsString('will not answer past it', $result['message']);
        $this->assertStringContainsString('not ranking around it', $result['message']);
    }

    public function test_an_express_exclusion_is_honoured(): void
    {
        // "Applies everywhere except Area C" is how change orders are actually
        // written, and modelling only inclusion would force somebody to
        // enumerate the whole site to say it.
        $result = AuthorityResolution::resolve([
            $this->source('co-9', 'Change Order 9', rank: 1, tags: [
                $this->tag('area', 'Area C', mode: 'excludes'),
            ]),
            $this->source('sheet-l3', 'Sheet L-3', rank: 5),
        ], ['area' => 'Area C'], $this->confirmedOrder);

        $this->assertSame('Sheet L-3', $result['controlling']['label']);
        $co9 = collect($result['considered'])->firstWhere('label', 'Change Order 9');
        $this->assertStringContainsString('expressly excludes', $co9['reason']);
    }

    // ---- relevance is not authority -----------------------------------------

    public function test_silence_on_a_dimension_means_site_wide_rather_than_nowhere(): void
    {
        // A specification with no area tag applies everywhere. That is the sane
        // default and the common case, and requiring a tag would make every
        // untagged source invisible.
        $result = AuthorityResolution::resolve([
            $this->source('spec-3284', 'Section 32 84 00', rank: 2),
        ], ['area' => 'Area B'], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
    }

    public function test_a_source_scoped_by_a_dimension_the_question_ignores_cannot_control(): void
    {
        // The question has to get more specific before this can control. Not a
        // failure — an unanswered question.
        $result = AuthorityResolution::resolve([
            $this->source('co-7', 'Change Order 7', rank: 1, tags: [$this->tag('area', 'Area C')]),
        ], ['system' => 'irrigation'], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::UNRESOLVED_APPLICABILITY, $result['state']);
    }

    public function test_newer_but_lower_ranked_is_context_rather_than_conflict(): void
    {
        // Recency is a SECONDARY axis. Refusing every time a later document
        // mentions the same subject would make the system useless.
        $result = AuthorityResolution::resolve([
            $this->source('addendum-2', 'Addendum 2', rank: 1, issued: '2026-02-01'),
            $this->source('sheet-l3', 'Sheet L-3', rank: 5, issued: '2026-06-01'),
        ], [], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
        $this->assertSame('Addendum 2', $result['controlling']['label']);
        $this->assertStringContainsString('Being newer does not make a source controlling', $result['message']);
        $this->assertStringContainsString('shown as context', $result['message']);
    }

    // ---- instrument semantics ------------------------------------------------

    public function test_an_rfi_that_directs_changed_work_is_not_a_modification_on_its_own(): void
    {
        // The distinction Codex called huge. It is evidence of what was said,
        // not a change to what is required — unless the contract gives that
        // instrument that effect or a change order formalises it.
        $result = AuthorityResolution::resolve([
            $this->source('rfi-114', 'RFI 114 response', rank: 1,
                effect: AuthorityResolution::EFFECT_DIRECTIVE, conferred: false),
            $this->source('spec-3284', 'Section 32 84 00', rank: 3),
        ], [], $this->confirmedOrder);

        $this->assertSame('Section 32 84 00', $result['controlling']['label']);
        $rfi = collect($result['considered'])->firstWhere('label', 'RFI 114 response');
        $this->assertSame(AuthorityResolution::CONTEXT, $rfi['state']);
        $this->assertStringContainsString('evidence of what was said, not a modification', $rfi['reason']);
    }

    public function test_the_same_directive_controls_once_a_change_order_formalises_it(): void
    {
        $result = AuthorityResolution::resolve([
            $this->source('rfi-114', 'RFI 114 response', rank: 1,
                effect: AuthorityResolution::EFFECT_DIRECTIVE, conferred: false, formalised: 42),
        ], [], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
    }

    public function test_an_interpretation_controls_without_needing_conferred_authority(): void
    {
        // "Detail 4/L-3 governs" clarifies without changing anything, so it is
        // not caught by the modification rule.
        $result = AuthorityResolution::resolve([
            $this->source('rfi-118', 'RFI 118 response', rank: 2,
                effect: AuthorityResolution::EFFECT_INTERPRET, conferred: false),
        ], [], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONTROLS, $result['state']);
    }

    public function test_evidence_only_material_never_states_a_requirement(): void
    {
        $result = AuthorityResolution::resolve([
            $this->source('photo-log', 'Photo log', rank: 1,
                effect: AuthorityResolution::EFFECT_EVIDENCE_ONLY),
            $this->source('spec-3284', 'Section 32 84 00', rank: 3),
        ], [], $this->confirmedOrder);

        $this->assertSame('Section 32 84 00', $result['controlling']['label']);
    }

    // ---- the rule for reading the contract is governed like the contract ----

    public function test_an_unconfirmed_precedence_order_will_not_settle_a_contest(): void
    {
        // The hole this closes: falling back to Zeco's default order and
        // presenting it as project-specific authority.
        $result = AuthorityResolution::resolve([
            $this->source('addendum-2', 'Addendum 2', rank: 1),
            $this->source('sheet-l3', 'Sheet L-3', rank: 5),
        ], [], ['status' => 'unresolved']);

        $this->assertSame(AuthorityResolution::CONFLICT, $result['state']);
        $this->assertNull($result['controlling']);
        $this->assertStringContainsString('labelled reference heuristic', $result['message']);
        $this->assertStringContainsString('NOT a substitute', $result['message']);
    }

    public function test_two_sources_of_equal_precedence_are_an_ambiguity_not_a_choice(): void
    {
        $result = AuthorityResolution::resolve([
            $this->source('spec-a', 'Section 32 84 00', rank: 3),
            $this->source('spec-b', 'Section 33 11 00', rank: 3),
        ], [], $this->confirmedOrder);

        $this->assertSame(AuthorityResolution::CONFLICT, $result['state']);
        $this->assertStringContainsString('not something this software may settle by choosing', $result['message']);
    }

    public function test_a_superseded_passage_is_out_before_anything_else_is_considered(): void
    {
        $result = AuthorityResolution::resolve([
            $this->source('spec-old', 'Section 32 84 00 (superseded)', rank: 1, operative: false),
            $this->source('addendum-2', 'Addendum 2', rank: 4),
        ], [], $this->confirmedOrder);

        $this->assertSame('Addendum 2', $result['controlling']['label']);
    }

    public function test_the_invariant_travels_with_every_answer(): void
    {
        $result = AuthorityResolution::resolve([$this->source('a', 'A', rank: 1)], [], $this->confirmedOrder);

        $this->assertStringContainsString('relevance is not authority', $result['invariant']);
        $this->assertStringContainsString('higher precedence is not controlling outside its scope', $result['invariant']);
    }

    // ---- helpers -------------------------------------------------------------

    private function source(string $id, string $label, int $rank, array $tags = [],
        bool $operative = true, string $effect = AuthorityResolution::EFFECT_ORIGINAL,
        bool $conferred = true, ?int $formalised = null, string $issued = '2026-01-01'): array
    {
        return [
            'id' => $id,
            'label' => $label,
            'citation' => $label,
            'operative' => $operative,
            'applicability_tags' => $tags,
            'authority_effect' => $effect,
            'effect_conferred_by_contract' => $conferred,
            'formalised_by_change_order_id' => $formalised,
            'precedence_rank' => $rank,
            'issued_on' => $issued,
        ];
    }

    private function tag(string $dimension, string $value, string $mode = 'includes', string $status = 'confirmed'): array
    {
        return compact('dimension', 'value', 'mode', 'status');
    }
}
