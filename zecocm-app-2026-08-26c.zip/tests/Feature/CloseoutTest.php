<?php

namespace Tests\Feature;

use App\Domain\Closeout\CloseoutReadiness;
use App\Domain\Closeout\CompletionState;
use App\Domain\Closeout\WarrantyClock;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

/**
 * A7: the back half of the contract lifecycle.
 *
 * The separation being defended, which Codex told me to protect above anything
 * else in this row: what happened, what was recorded, what is required to
 * close, and what remains alive afterwards are four different things. Collapse
 * any two and the system produces a confident wrong answer.
 */
class CloseoutTest extends TestCase
{
    // ---- what happened is not what was recorded -----------------------------

    public function test_a_notice_of_completion_in_a_drawer_has_started_no_clock(): void
    {
        // The whole reason completion events and recorded instruments are two
        // tables. Civil Code s. 9356 is 30 days or 90 depending on recordation,
        // so this distinction is worth sixty days.
        $state = CompletionState::recordation([
            'instrument_type' => 'notice_of_completion',
            'recording_county' => null,
            'instrument_number' => null,
            'recorded_on' => null,
            'recordation_state' => 'unresolved',
        ]);

        $this->assertSame(CompletionState::RECORDATION_UNRESOLVED, $state['state']);
        $this->assertFalse($state['usable_as_anchor']);
        $this->assertStringContainsString('thirty days against ninety', $state['message']);
    }

    public function test_a_properly_recorded_instrument_can_anchor_a_clock(): void
    {
        $state = CompletionState::recordation([
            'recording_county' => 'Los Angeles',
            'instrument_number' => '2026-0918442',
            'recorded_on' => '2026-09-14',
            'recordation_state' => 'recorded',
        ]);

        $this->assertSame(CompletionState::RECORDED, $state['state']);
        $this->assertTrue($state['usable_as_anchor']);
    }

    public function test_nobody_checked_is_not_the_same_as_nothing_was_recorded(): void
    {
        // Only one of these supports counting from the alternative statutory
        // event, and defaulting to the wrong one picks a window silently.
        $unchecked = CompletionState::recordation(null);
        $this->assertSame(CompletionState::RECORDATION_UNRESOLVED, $unchecked['state']);
        $this->assertStringContainsString('NOT the same as knowing', $unchecked['message']);

        $searched = CompletionState::recordation(['recordation_state' => CompletionState::NOT_RECORDED]);
        $this->assertSame(CompletionState::NOT_RECORDED, $searched['state']);
    }

    // ---- a fact is not a determination --------------------------------------

    public function test_substantial_completion_asserted_by_one_side_cannot_anchor_anything(): void
    {
        // "We were substantially complete in June" is a position, not a date.
        $verdict = CompletionState::anchorable([
            'event_type' => 'substantial_completion',
            'nature' => CompletionState::DETERMINATION,
            'status' => CompletionState::ASSERTED,
            'occurred_on' => '2026-06-30',
        ]);

        $this->assertFalse($verdict['usable']);
        $this->assertStringContainsString('treat one side\'s position as settled', $verdict['reason']);
    }

    public function test_the_same_event_once_determined_can_anchor(): void
    {
        $this->assertTrue(CompletionState::anchorable([
            'event_type' => 'substantial_completion',
            'nature' => CompletionState::DETERMINATION,
            'status' => CompletionState::DETERMINED,
            'occurred_on' => '2026-06-30',
        ])['usable']);
    }

    public function test_cessation_of_labour_is_a_fact_and_needs_no_determination(): void
    {
        // Observable. Nobody has to opine about whether people stopped working.
        $this->assertTrue(CompletionState::anchorable([
            'event_type' => 'cessation_of_labor',
            'nature' => CompletionState::FACT,
            'status' => CompletionState::ASSERTED,
            'occurred_on' => '2026-07-15',
        ])['usable']);

        $this->assertFalse(CompletionState::isDetermination('cessation_of_labor'));
        $this->assertTrue(CompletionState::isDetermination('substantial_completion'));
    }

    public function test_a_disputed_completion_date_anchors_nothing(): void
    {
        $this->assertFalse(CompletionState::anchorable([
            'event_type' => 'final_completion', 'nature' => CompletionState::DETERMINATION,
            'status' => CompletionState::DISPUTED, 'occurred_on' => '2026-08-01',
        ])['usable']);
    }

    // ---- closeout debt, visible early ---------------------------------------

    public function test_the_output_is_an_at_risk_list_rather_than_a_percentage(): void
    {
        $result = CloseoutReadiness::assess($this->requirements());

        $this->assertArrayHasKey('at_risk_items', $result);
        $this->assertStringContainsString('single completion percentage hides', $result['note']);
    }

    public function test_a_demobilising_party_is_the_top_risk_because_leverage_ends_with_payment(): void
    {
        // The signal that turns a paperwork problem into a money problem.
        $result = CloseoutReadiness::assess($this->requirements());
        $top = $result['at_risk_items'][0];

        $this->assertSame('O&M manuals — HVAC', $top['title']);
        $this->assertStringContainsString('nothing left to withhold', implode(' ', $top['reasons']));
    }

    public function test_an_unassigned_deliverable_is_flagged_before_anybody_is_late(): void
    {
        $result = CloseoutReadiness::assess([[
            'title' => 'As-built drawings', 'deliverable_type' => 'as_built',
            'state' => CloseoutReadiness::REQUIRED, 'responsible_party' => null,
        ]]);

        $this->assertSame(1, $result['at_risk']);
        $this->assertStringContainsString('nobody\'s problem until it is everybody\'s',
            implode(' ', $result['at_risk_items'][0]['reasons']));
    }

    public function test_broken_submittal_lineage_is_reported_as_debt_already_incurred(): void
    {
        // The month-four signal. A submittal approved for construction that
        // never becomes installed, tested, documented and warranted.
        $result = CloseoutReadiness::assess([[
            'title' => 'Pump startup report', 'deliverable_type' => 'test_report',
            'state' => CloseoutReadiness::ASSIGNED, 'responsible_party' => 'Valley Mechanical',
            'lineage_gap' => 'submittal 15-04 was approved and installed, and no test or startup record followed',
        ]]);

        $this->assertStringContainsString('closeout debt already incurred',
            implode(' ', $result['at_risk_items'][0]['reasons']));
    }

    public function test_a_provisional_condition_is_a_blocker_now_rather_than_at_closeout(): void
    {
        $result = CloseoutReadiness::assess([[
            'title' => 'Roof warranty certificate', 'deliverable_type' => 'warranty_document',
            'state' => CloseoutReadiness::ASSIGNED, 'responsible_party' => 'Summit Roofing',
            'provisional_condition' => 'a temporary repair at grid C-4 was never made permanent',
        ]]);

        $this->assertStringContainsString('closeout blocker now, not at closeout',
            implode(' ', $result['at_risk_items'][0]['reasons']));
    }

    public function test_accepted_items_are_not_at_risk_however_late_they_were(): void
    {
        $result = CloseoutReadiness::assess([[
            'title' => 'Keys', 'state' => CloseoutReadiness::ACCEPTED,
            'responsible_party' => null, 'partner_demobilising' => true,
        ]]);

        $this->assertSame(0, $result['at_risk']);
        $this->assertSame(1, $result['accepted']);
    }

    public function test_the_ladder_counts_cumulatively_so_each_rung_means_at_least_this_far(): void
    {
        $result = CloseoutReadiness::assess($this->requirements());

        $this->assertSame(4, $result['required']);
        $this->assertGreaterThanOrEqual($result['submitted'], $result['evidence_ready']);
        $this->assertGreaterThanOrEqual($result['accepted'], $result['submitted']);
    }

    public function test_it_never_says_the_project_is_complete(): void
    {
        $disclaimer = CloseoutReadiness::disclaimer();

        $this->assertStringContainsString('does not determine that the project is complete', $disclaimer);
        $this->assertStringContainsString('start statutory clocks', $disclaimer);
    }

    // ---- the clock that runs the wrong way ----------------------------------

    public function test_a_warranty_will_not_start_from_a_date_nobody_determined(): void
    {
        $state = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24],
            ['event_type' => 'acceptance_by_governing_body', 'nature' => CompletionState::DETERMINATION,
                'status' => CompletionState::ASSERTED, 'occurred_on' => '2026-09-01'],
        );

        $this->assertSame(WarrantyClock::UNRESOLVED_ANCHOR, $state['state']);
        $this->assertNull($state['ends_on']);
    }

    public function test_a_determined_acceptance_starts_the_period(): void
    {
        $state = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24],
            $this->acceptance(),
            [],
            new DateTimeImmutable('2027-01-01'),
        );

        $this->assertSame(WarrantyClock::RUNNING, $state['state']);
        $this->assertSame('2026-09-01', $state['starts_on']);
        $this->assertSame('2028-09-01', $state['ends_on']);
    }

    public function test_a_repair_restarts_the_period_for_that_item_only_and_only_if_the_contract_says_so(): void
    {
        $events = [
            ['event_type' => 'repair_completed', 'occurred_on' => '2027-06-15',
                'item_reference' => 'Grid C-4 flashing', 'restarts_period_for_item' => true],
        ];

        $without = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24, 'repair_restarts_period' => false],
            $this->acceptance(), $events, new DateTimeImmutable('2027-07-01'),
        );
        $this->assertSame([], $without['item_restarts']);

        $with = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24, 'repair_restarts_period' => true,
                'restart_rule_source' => 'Spec 07 50 00 s. 1.8'],
            $this->acceptance(), $events, new DateTimeImmutable('2027-07-01'),
        );

        $this->assertCount(1, $with['item_restarts']);
        $this->assertSame('Grid C-4 flashing', $with['item_restarts'][0]['item']);
        $this->assertSame('2029-06-15', $with['item_restarts'][0]['ends_on']);
    }

    public function test_an_unsourced_restart_rule_says_so_rather_than_assuming_either_way(): void
    {
        // Assuming it restarts inflates the contractor's exposure; assuming it
        // does not discards a right the owner paid for.
        $state = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24, 'repair_restarts_period' => false],
            $this->acceptance(), [], new DateTimeImmutable('2027-01-01'),
        );

        $this->assertStringContainsString('no source for that rule is recorded', $state['message']);
    }

    public function test_final_exposure_is_the_latest_of_everything_not_the_general_period(): void
    {
        // What a retention policy must use. Destroying a record while an item
        // is still under warranty makes a defect claim unanswerable.
        $state = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 24, 'repair_restarts_period' => true],
            $this->acceptance(),
            [['occurred_on' => '2027-06-15', 'item_reference' => 'Grid C-4', 'restarts_period_for_item' => true]],
            new DateTimeImmutable('2027-07-01'),
        );

        $this->assertSame('2028-09-01', $state['ends_on']);
        $this->assertSame('2029-06-15', WarrantyClock::finalExposureDate($state));
    }

    public function test_the_latest_restart_for_an_item_wins_over_earlier_ones(): void
    {
        $state = WarrantyClock::state(
            ['title' => 'Roofing system', 'duration_months' => 12, 'repair_restarts_period' => true],
            $this->acceptance(),
            [
                ['occurred_on' => '2027-01-10', 'item_reference' => 'Grid C-4', 'restarts_period_for_item' => true],
                ['occurred_on' => '2027-05-20', 'item_reference' => 'Grid C-4', 'restarts_period_for_item' => true],
            ],
            new DateTimeImmutable('2027-06-01'),
        );

        $this->assertCount(1, $state['item_restarts']);
        $this->assertSame('2028-05-20', $state['item_restarts'][0]['ends_on']);
    }

    private function acceptance(): array
    {
        return ['event_type' => 'acceptance_by_governing_body', 'nature' => CompletionState::DETERMINATION,
            'status' => CompletionState::DETERMINED, 'occurred_on' => '2026-09-01'];
    }

    /** @return list<array<string,mixed>> */
    private function requirements(): array
    {
        return [
            ['title' => 'As-built drawings', 'deliverable_type' => 'as_built',
                'state' => CloseoutReadiness::EVIDENCE_READY, 'responsible_party' => 'Northgate',
                'blocks_final_payment' => true],
            ['title' => 'O&M manuals — HVAC', 'deliverable_type' => 'om_manual',
                'state' => CloseoutReadiness::ASSIGNED, 'responsible_party' => 'Valley Mechanical',
                'blocks_retention_release' => true, 'partner_demobilising' => true, 'partner_percent_paid' => 96.0],
            ['title' => 'Owner training', 'deliverable_type' => 'training',
                'state' => CloseoutReadiness::SUBMITTED, 'responsible_party' => 'Valley Mechanical'],
            ['title' => 'Spare parts', 'deliverable_type' => 'spare_parts',
                'state' => CloseoutReadiness::ACCEPTED, 'responsible_party' => 'Northgate'],
        ];
    }
}
