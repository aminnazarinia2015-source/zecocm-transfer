<?php

namespace Tests\Feature;

use App\Domain\Payment\ChangeOrderIncorporation;
use App\Models\ChangeOrder;
use App\Models\ChangeOrderAllocation;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * What an approved change order does to the schedule of values.
 *
 * Codex's rule: a change order may adjust an EXISTING line only when the change
 * genuinely belongs to that line's scope; distinct added scope gets its own line.
 *
 * The reason is not tidiness. Fold added scope into a base line and the line's
 * authorized value rises, so the extra work becomes invisible - cumulative
 * billing against it looks perfectly normal because the cap moved. That is the
 * same blindness the hidden-change check catches, except baked into the schedule
 * of values itself, where no downstream check could ever see it.
 */
class ChangeOrderIncorporationTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_distinct_added_scope_gets_its_own_line_with_zero_original_value(): void
    {
        // The zero is the point: it tells anyone reading the schedule that this
        // scope was not in the contract as bid.
        $order = $this->order(amountCents: 2_500_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'new_item_number' => 'CO1-001', 'new_item_description' => 'Added storm drain',
            'amount_cents' => 2_500_000,
        ]);

        $result = ChangeOrderIncorporation::incorporate($order->fresh());

        $this->assertSame(1, $result['created']);
        $line = ScheduleOfValueItem::where('item_number', 'CO1-001')->first();
        $this->assertNotNull($line);
        $this->assertSame(0, $line->original_value_cents);
        $this->assertSame(2_500_000, $line->scheduled_value_cents);
        $this->assertSame($order->id, $line->change_order_id);
    }

    public function test_adjusting_an_existing_line_moves_the_scheduled_value_and_never_the_original(): void
    {
        // original_value_cents is the record of what the contract started as. It
        // is the only thing that keeps contract growth visible once values move.
        $item = $this->item('100', 10_000_000);
        $order = $this->order(amountCents: 1_500_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'schedule_of_value_item_id' => $item->id, 'amount_cents' => 1_500_000,
            'same_scope_justification' => 'Additional depth on the same trench run, same pay item.',
        ]);

        ChangeOrderIncorporation::incorporate($order->fresh());

        $item->refresh();
        $this->assertSame(11_500_000, $item->scheduled_value_cents);
        $this->assertSame(10_000_000, $item->original_value_cents, 'The original contract value must never move.');
    }

    public function test_adjusting_a_line_without_saying_why_the_work_belongs_to_it_is_refused(): void
    {
        // "It is roughly the same area of work" is how added scope disappears into
        // a base line. Make someone write the reason down.
        $item = $this->item('100', 10_000_000);
        $order = $this->order(amountCents: 2_000_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'schedule_of_value_item_id' => $item->id, 'amount_cents' => 2_000_000,
        ]);

        $refusals = ChangeOrderIncorporation::refusals($order->fresh());

        $this->assertNotEmpty($refusals);
        $this->assertStringContainsString('becomes invisible', $refusals[0]);
    }

    public function test_a_change_order_that_is_not_approved_cannot_be_incorporated(): void
    {
        $order = $this->order(amountCents: 1_000_000, status: 'under_review');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'new_item_number' => 'CO1-001', 'amount_cents' => 1_000_000,
        ]);

        $refusals = ChangeOrderIncorporation::refusals($order->fresh());

        $this->assertStringContainsString('under_review', $refusals[0]);
        $this->expectException(\RuntimeException::class);
        ChangeOrderIncorporation::incorporate($order->fresh());
    }

    public function test_every_dollar_must_land_somewhere(): void
    {
        // A change order whose allocations do not sum to its value leaves money
        // unaccounted for, and the pay application will report exactly that as a
        // reconciliation failure nobody can explain.
        $order = $this->order(amountCents: 2_000_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'new_item_number' => 'CO1-001', 'amount_cents' => 1_500_000,
        ]);

        $refusals = ChangeOrderIncorporation::refusals($order->fresh());

        $this->assertStringContainsString('must land somewhere', implode(' ', $refusals));
    }

    public function test_incorporating_twice_does_not_inflate_the_contract(): void
    {
        // Silent double-application is the defect that would surface later as an
        // unexplainable contract sum.
        $item = $this->item('100', 10_000_000);
        $order = $this->order(amountCents: 1_000_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'schedule_of_value_item_id' => $item->id, 'amount_cents' => 1_000_000,
            'same_scope_justification' => 'Same pay item, extended quantity.',
        ]);

        ChangeOrderIncorporation::incorporate($order->fresh());
        $second = ChangeOrderIncorporation::incorporate($order->fresh());

        $this->assertSame(0, $second['adjusted']);
        $this->assertSame(11_000_000, $item->fresh()->scheduled_value_cents);
    }

    public function test_the_contract_sum_is_computed_from_the_record_not_stored(): void
    {
        // Storing it is how it drifts from the thing it is supposed to summarise.
        $this->item('100', 10_000_000);
        $this->item('200', 5_000_000);

        $approved = $this->order(amountCents: 1_500_000, status: 'approved');
        $this->order(amountCents: 9_900_000, status: 'under_review');   // must not count

        $sum = ChangeOrderIncorporation::contractSum($this->project->id);

        $this->assertSame(15_000_000, $sum['original_contract_cents']);
        $this->assertSame(1_500_000, $sum['approved_change_orders_cents']);
        $this->assertSame(16_500_000, $sum['current_contract_cents']);
    }

    public function test_a_deductive_change_order_reduces_the_line(): void
    {
        // Changes go both ways, and a credit that silently failed to apply would
        // overstate what the contractor is owed.
        $item = $this->item('100', 10_000_000);
        $order = $this->order(amountCents: -2_000_000, status: 'approved');
        ChangeOrderAllocation::create([
            'tenant_id' => $this->tenant->id, 'change_order_id' => $order->id,
            'schedule_of_value_item_id' => $item->id, 'amount_cents' => -2_000_000,
            'same_scope_justification' => 'Quantity reduced on the same pay item.',
        ]);

        ChangeOrderIncorporation::incorporate($order->fresh());

        $this->assertSame(8_000_000, $item->fresh()->scheduled_value_cents);
        $this->assertSame(10_000_000, $item->fresh()->original_value_cents);
    }

    private function item(string $number, int $cents): ScheduleOfValueItem
    {
        return ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => $number, 'description' => 'Line '.$number,
            'scheduled_value_cents' => $cents, 'original_value_cents' => $cents,
        ]);
    }

    private function order(int $amountCents, string $status): ChangeOrder
    {
        static $n = 0;
        $n++;

        return ChangeOrder::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'CO-'.$n, 'title' => 'Change '.$n, 'status' => $status,
            'amount_cents' => $amountCents,
        ]);
    }
}
