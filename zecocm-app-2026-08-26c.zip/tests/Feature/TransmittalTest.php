<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Branded transmittals. The document belongs to the account owner and its counterparty.
 * ZecoCM's name must never appear on it, parties and clocks must be derived rather than
 * typed, and issuing must be provable after the fact.
 */
class TransmittalTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    private Rfi $rfi;

    protected function setUp(): void
    {
        parent::setUp();

        $this->tenant = Tenant::create([
            'name' => 'Northgate Constructors', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true,
            'legal_name' => 'Northgate Constructors, Inc.',
            'address_lines' => ['1400 Foundry Road, Unit C', 'Fresno, CA 93706'],
            'brand_accent' => '#1d4e4e', 'brand_mark' => 'NC',
        ]);
        $this->user = User::create([
            'tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password'),
        ]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create([
            'number' => 'P-410', 'name' => 'Riverbend Levee Rehabilitation',
            'sector' => 'public', 'owner_name' => 'City of Riverbend',
            'owner_address_lines' => ['500 Civic Center Drive', 'Riverbend, CA 93720'],
            'site_address' => '2200 Levee Road, Riverbend, CA',
            'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => ['precedence' => ['Addenda', 'Special Provisions', 'Plans', 'Standard Specifications']],
            'contract_clocks' => ['rfi_response' => ['days' => 10, 'basis' => 'working', 'source' => 'Special Provisions 5-1.16']],
        ]);
        Membership::create([
            'project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true],
        ]);
        $this->rfi = Rfi::create([
            'project_id' => $this->project->id, 'number' => 'RFI-009', 'subject' => 'Trench detail — governing depth',
            'question' => 'Which detail governs unsleeved irrigation piping in landscape areas?',
            'raised_by_org' => 'Northgate Constructors', 'raised_at' => '2026-08-07',
            'ball_in_court' => 'City of Riverbend', 'cost_impact' => true, 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ]);
        (new CapabilityLicense)->grant($this->tenant, 'documents.transmittal', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    public function test_the_document_carries_the_account_owners_identity_and_never_the_platforms(): void
    {
        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');

        $this->assertStringContainsString('Northgate Constructors, Inc.', $html);
        $this->assertStringContainsString('City of Riverbend', $html);
        $this->assertStringContainsString('1400 Foundry Road, Unit C', $html);

        foreach (['ZecoCM', 'Zeco', 'zecocm'] as $forbidden) {
            $this->assertStringNotContainsString($forbidden, $html,
                'A transmittal must carry no trace of the platform that produced it.');
        }
    }

    public function test_the_contract_clock_is_computed_and_shows_its_arithmetic_and_its_clause(): void
    {
        $res = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk();

        $this->assertSame('Special Provisions 5-1.16', $res->json('clock.source'));
        $this->assertNotNull($res->json('clock.due'));
        $this->assertStringContainsString('Special Provisions 5-1.16', $res->json('html'));
        $this->assertStringContainsString('10 working days', $res->json('html'));
    }

    public function test_order_of_precedence_is_printed_when_recorded_and_refused_when_not(): void
    {
        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');
        $this->assertStringContainsString('ORDER OF PRECEDENCE', $html);
        $this->assertStringContainsString('Special Provisions', $html);

        TenantContext::set($this->tenant->id);
        $bare = Project::create([
            'number' => 'P-411', 'name' => 'No precedence', 'sector' => 'public', 'owner_name' => 'City of Riverbend',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => [],
        ]);
        Membership::create([
            'project_id' => $bare->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true],
        ]);
        $bareRfi = Rfi::create([
            'project_id' => $bare->id, 'number' => 'RFI-001', 'subject' => 'Anything',
            'question' => 'A question.', 'raised_by_org' => 'Northgate Constructors',
            'raised_at' => '2026-08-07', 'ball_in_court' => 'City', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ]);
        TenantContext::clear();

        $bareHtml = $this->getJson('/api/transmittals/rfi/'.$bareRfi->id)->assertOk()->json('html');
        $this->assertStringContainsString('will not infer which document governs', $bareHtml);
        $this->assertStringContainsString('A period is never assumed', $bareHtml);
    }

    public function test_a_cost_impact_is_printed_as_an_assertion_not_a_finding(): void
    {
        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');

        $this->assertStringContainsString('ASSERTED BY THE ORIGINATOR', $html);
        $this->assertStringContainsString('not adopted as a finding, and no responsibility is assigned', $html);
    }

    public function test_an_unanswered_rfi_leaves_the_response_block_deliberately_blank(): void
    {
        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');

        $this->assertStringContainsString('deliberately blank rather than pre-filled', $html);
    }

    public function test_preview_changes_nothing_and_issuing_seals_a_revision(): void
    {
        $first = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk();
        $this->assertSame([], $first->json('issued_history'));

        $this->postJson('/api/transmittals/rfi/'.$this->rfi->id.'/issue')->assertStatus(422);

        $issued = $this->postJson('/api/transmittals/rfi/'.$this->rfi->id.'/issue', ['confirm' => 'confirm'])
            ->assertStatus(201);
        $this->assertSame(1, $issued->json('revision'));
        $this->assertSame($first->json('fingerprint'), $issued->json('fingerprint'));

        $again = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk();
        $this->assertCount(1, $again->json('issued_history'));
        $this->assertTrue($again->json('issued_history.0.matches_current'));
    }

    public function test_an_issued_record_is_immutable(): void
    {
        $this->postJson('/api/transmittals/rfi/'.$this->rfi->id.'/issue', ['confirm' => 'confirm'])->assertStatus(201);

        TenantContext::set($this->tenant->id);
        $row = \App\Models\IssuedDocument::query()->firstOrFail();
        TenantContext::clear();

        $this->expectException(\LogicException::class);
        $row->update(['document_number' => 'RFI-999']);
    }

    public function test_the_sheet_is_one_letter_page_and_never_silently_truncates(): void
    {
        $res = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk();
        $html = $res->json('html');

        $this->assertTrue($res->json('one_page'));
        $this->assertFalse($res->json('overflow'), 'This RFI should fit one sheet.');
        $this->assertStringContainsString('@page{size:letter', $html);
        $this->assertStringContainsString('height:11in', $html);
        $this->assertStringNotContainsString('continues in the attached statement', $html);

        // The whole question must be physically present on the sheet, whatever the density.
        $this->assertStringContainsString('Which detail governs unsleeved irrigation piping', $html);
    }

    public function test_an_over_long_item_declares_a_continuation_rather_than_losing_text(): void
    {
        TenantContext::set($this->tenant->id);
        $long = Rfi::create([
            'project_id' => $this->project->id, 'number' => 'RFI-010', 'subject' => 'Very long item',
            'question' => str_repeat('The contractor requests written clarification of the governing detail. ', 220)."\nFINAL SENTENCE MARKER.",
            'raised_by_org' => 'Northgate Constructors', 'raised_at' => '2026-08-07',
            'ball_in_court' => 'City of Riverbend', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ]);
        TenantContext::clear();

        $res = $this->getJson('/api/transmittals/rfi/'.$long->id)->assertOk();

        $this->assertTrue($res->json('overflow'));
        $this->assertStringContainsString('continues in the attached statement', $res->json('html'));
        $this->assertStringContainsString('Nothing has been shortened on the record', $res->json('html'));
        $this->assertStringContainsString('FINAL SENTENCE MARKER', $res->json('html'),
            'The full text must still be in the document, never cut out of it.');
        $this->assertNotNull($res->json('overflow_notice'));
    }

    public function test_the_reference_block_prints_spec_sheets_linked_submittal_and_both_impacts(): void
    {
        TenantContext::set($this->tenant->id);
        $sub = \App\Models\Submittal::create([
            'project_id' => $this->project->id, 'number' => 'SUB-014', 'spec_section' => '32 84 00',
            'title' => 'Irrigation sleeving', 'type' => 'shop_drawing', 'submitted_by_org' => 'Northgate Constructors',
            'contact_person' => 'R. Salas', 'submitted_at' => '2026-07-20', 'ball_in_court' => 'City of Riverbend',
            'status' => 'under_review', 'routing_history' => [],
        ]);
        $this->rfi->forceFill([
            'spec_section' => '32 84 00 §3.4.A / §3.4.C',
            'plan_sheets' => 'L2.01-L2.05; Detail I-14',
            'reference' => 'Q&A 4.20; RFI-008',
            'linked_submittal_id' => $sub->id,
            'cost_impact_state' => 'yes',
            'schedule_impact' => 'no',
        ])->save();
        TenantContext::clear();

        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');

        $this->assertStringContainsString('32 84 00', $html);
        $this->assertStringContainsString('L2.01-L2.05; Detail I-14', $html);
        $this->assertStringContainsString('SUB-014', $html);
        $this->assertStringContainsString('Irrigation sleeving', $html);
        $this->assertStringContainsString('Cost impact', $html);
        $this->assertStringContainsString('Time impact', $html);
    }

    public function test_an_unanswered_impact_prints_not_stated_rather_than_no(): void
    {
        $html = $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertOk()->json('html');

        $this->assertStringContainsString('Not stated', $html,
            'Silence must never be rendered as "No".');
        $this->assertStringContainsString('Not cited', $html);
        $this->assertStringContainsString('None linked', $html);
    }

    public function test_an_rfi_cannot_link_a_submittal_from_another_project(): void
    {
        TenantContext::set($this->tenant->id);
        $elsewhere = Project::create([
            'number' => 'P-412', 'name' => 'Elsewhere', 'sector' => 'public', 'owner_name' => 'City of Riverbend',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => [],
        ]);
        $foreignSub = \App\Models\Submittal::create([
            'project_id' => $elsewhere->id, 'number' => 'SUB-001', 'spec_section' => '01 00 00',
            'title' => 'Other project item', 'type' => 'product_data', 'submitted_by_org' => 'Northgate Constructors',
            'submitted_at' => '2026-07-20', 'ball_in_court' => 'City', 'status' => 'under_review', 'routing_history' => [],
        ]);
        TenantContext::clear();

        $this->postJson('/api/rfis', [
            'project_id' => $this->project->id,
            'subject' => 'Cross-link attempt',
            'question' => 'Does this link?',
            'linked_submittal_id' => $foreignSub->id,
        ])->assertStatus(422);
    }

    public function test_rfi_numbering_follows_this_projects_register(): void
    {
        $created = $this->postJson('/api/rfis', [
            'project_id' => $this->project->id,
            'subject' => 'Next in the register',
            'question' => 'What number do I get?',
            'spec_section' => '32 84 00',
            'cost_impact_state' => 'no',
            'schedule_impact' => 'yes',
        ])->assertStatus(201);

        // RFI-009 already exists on this project, so the next one is 010 - not a global count.
        $this->assertSame('RFI-010', $created->json('number'));
        $this->assertSame('no', $created->json('cost_impact_state'));
        $this->assertSame('yes', $created->json('schedule_impact'));
        $this->assertSame([], $created->json('ai_dispositions'));
        $this->assertSame('raised', $created->json('routing_history.0.action'));
        $this->assertDatabaseHas('rfis', ['id' => $created->json('id'), 'number' => 'RFI-010', 'status' => 'open']);
    }

    public function test_the_transmittal_is_licence_gated(): void
    {
        (new CapabilityLicense)->revoke($this->tenant, 'documents.transmittal', null, 'Test');

        $this->getJson('/api/transmittals/rfi/'.$this->rfi->id)->assertStatus(402);
    }

    public function test_another_tenants_record_fails_closed(): void
    {
        $other = Tenant::create([
            'name' => 'Other Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true,
        ]);
        TenantContext::set($other->id);
        $p = Project::create([
            'number' => 'Z-1', 'name' => 'Theirs', 'sector' => 'public', 'owner_name' => 'Somewhere',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => [],
        ]);
        $theirs = Rfi::create([
            'project_id' => $p->id, 'number' => 'RFI-001', 'subject' => 'Theirs', 'question' => 'q',
            'raised_by_org' => 'Other Co', 'raised_at' => '2026-08-01', 'ball_in_court' => 'x', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ]);
        TenantContext::clear();

        $this->getJson('/api/transmittals/rfi/'.$theirs->id)->assertStatus(404);
    }
}
