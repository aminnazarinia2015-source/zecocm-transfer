<?php

namespace Tests\Feature;

use App\Domain\Evolution\SelfObservation;
use App\Models\CapabilityGap;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The surface that closes the last gap in "make TRACE functional": a
 * capability_gaps row SelfObservation records is now readable, and a
 * platform person can turn it into a proposal (or decline it) and an admin
 * can authorize it. Before this controller existed, the wiring added in
 * SelfObservationWiringTest recorded rows nobody could ever see.
 *
 * What this suite defends: platform-staff-only, cross-tenant read; a gap
 * below threshold refuses to become a proposal (422, not silently ignored);
 * a proposal touching a protected capability is refused even though the gap
 * itself was recorded; only an admin (not any technician) decides; and a
 * decision is refused on a gap that was never proposed.
 */
class CapabilityGapSurfaceTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private User $technician;

    private User $ordinary;

    private int $tenantOneId;

    private int $tenantTwoId;

    protected function setUp(): void
    {
        parent::setUp();
        $this->admin = User::create(['tenant_id' => null, 'name' => 'Admin', 'email' => 'admin@zecocm.test',
            'password' => bcrypt('password'), 'platform_role' => 'admin']);
        $this->technician = User::create(['tenant_id' => null, 'name' => 'Tech', 'email' => 'tech@zecocm.test',
            'password' => bcrypt('password'), 'platform_role' => 'technician']);
        $this->ordinary = User::create(['tenant_id' => null, 'name' => 'Nobody', 'email' => 'nobody@zecocm.test',
            'password' => bcrypt('password'), 'platform_role' => null]);

        // CapabilityGap.tenant_id is a real foreign key, so these tests need
        // actual tenant rows to attach observations to - the point of the
        // surface is that it reads ACROSS tenants, so two are used.
        $this->tenantOneId = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true])->id;
        $this->tenantTwoId = Tenant::create(['name' => 'Second Tenant', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true])->id;
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function observeUntilReady(string $clusterKey = 'paint-sheen', int $times = 5): CapabilityGap
    {
        // CapabilityGap uses BelongsToTenant, so observe()'s own find-or-create
        // lookup is itself tenant-scoped and fail-closed - without an active
        // TenantContext, its query for "does this cluster already exist"
        // always sees zero rows, and a second call collides on the unique
        // (tenant_id, cluster_key) index instead of updating the first row.
        // Production call sites never hit this: RunGovernedAi sets the
        // context from the run, and the feedback endpoint runs inside
        // request middleware that already set it.
        TenantContext::set($this->tenantOneId);
        $gap = null;
        for ($i = 0; $i < $times; $i++) {
            $gap = SelfObservation::observe(
                signalKind: SelfObservation::NO_MATCH,
                clusterKey: $clusterKey,
                title: 'No match: paint sheen requirement',
                evidence: ['n' => $i],
                tenantId: $this->tenantOneId,
                askerKey: 'asker-'.$i,
            );
        }
        TenantContext::clear();

        return $gap;
    }

    public function test_a_non_platform_user_cannot_list_gaps(): void
    {
        Sanctum::actingAs($this->ordinary);
        $this->getJson('/api/platform/capability-gaps')->assertStatus(403);
    }

    public function test_the_listing_never_carries_raw_evidence(): void
    {
        // Codex's finding: cross-tenant product observation may aggregate
        // behaviour, it does not inherit permission to aggregate customer
        // evidence - the index listing must never carry a run's actual
        // question text or a steward's correction comment.
        SelfObservation::observe(SelfObservation::NO_MATCH, 'evidence-check', 'A specific customer question',
            evidence: ['question' => 'What is the exact retention on the Palmdale contract, sensitive detail here?'],
            tenantId: $this->tenantOneId, askerKey: 'a1');

        Sanctum::actingAs($this->admin);
        $body = $this->getJson('/api/platform/capability-gaps')->assertOk()->json();

        $this->assertArrayNotHasKey('evidence', $body['gaps'][0]);
        $this->assertSame(1, $body['gaps'][0]['sample_count']);
    }

    public function test_show_withholds_evidence_by_default_even_for_an_admin(): void
    {
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'evidence-check-2', 'A specific customer question',
            evidence: ['question' => 'sensitive'], tenantId: $this->tenantOneId, askerKey: 'a1');

        Sanctum::actingAs($this->admin);
        $body = $this->getJson('/api/platform/capability-gaps/'.$gap->id)->assertOk()->json();

        $this->assertArrayNotHasKey('evidence', $body['gap']);
    }

    public function test_show_reveals_evidence_only_to_an_admin_who_explicitly_asks(): void
    {
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'evidence-check-3', 'A specific customer question',
            evidence: ['question' => 'sensitive'], tenantId: $this->tenantOneId, askerKey: 'a1');

        Sanctum::actingAs($this->technician);
        $asTechnician = $this->getJson('/api/platform/capability-gaps/'.$gap->id.'?with_evidence=1')->assertOk()->json();
        $this->assertArrayNotHasKey('evidence', $asTechnician['gap'], 'a technician must never receive raw evidence, even if asked');

        Sanctum::actingAs($this->admin);
        $asAdmin = $this->getJson('/api/platform/capability-gaps/'.$gap->id.'?with_evidence=1')->assertOk()->json();
        $this->assertArrayHasKey('evidence', $asAdmin['gap']);
    }

    public function test_a_platform_technician_can_list_gaps_across_tenants(): void
    {
        SelfObservation::observe(SelfObservation::NO_MATCH, 'cluster-a', 'Gap A', tenantId: $this->tenantOneId);
        SelfObservation::observe(SelfObservation::NO_MATCH, 'cluster-b', 'Gap B', tenantId: $this->tenantTwoId);

        Sanctum::actingAs($this->technician);
        $body = $this->getJson('/api/platform/capability-gaps')->assertOk()->json();

        $this->assertCount(2, $body['gaps']);
    }

    public function test_a_gap_below_threshold_cannot_be_proposed(): void
    {
        $gap = SelfObservation::observe(SelfObservation::NO_MATCH, 'below-threshold', 'Only asked once', tenantId: $this->tenantOneId, askerKey: 'a1');

        Sanctum::actingAs($this->technician);
        $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/propose', ['proposal' => 'Add a paint-sheen field.'])
            ->assertStatus(422)
            ->assertJson(['refused' => true]);
    }

    public function test_a_gap_at_threshold_can_be_proposed_and_then_authorized(): void
    {
        $gap = $this->observeUntilReady();

        Sanctum::actingAs($this->technician);
        $proposed = $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/propose',
            ['proposal' => 'Add a structured paint-sheen field to the spec intake form.', 'register_row' => 'D13'])
            ->assertOk()->json('gap');
        $this->assertSame('proposed', $proposed['status']);
        $this->assertSame('D13', $proposed['register_row']);

        Sanctum::actingAs($this->admin);
        $decided = $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/decide',
            ['authorized' => true, 'reason' => 'Confirmed real need across five projects.'])
            ->assertOk()->json('gap');
        $this->assertSame('authorized', $decided['status']);
        $this->assertSame($this->admin->id, $decided['authorized_by']);
    }

    public function test_a_technician_cannot_decide_only_propose(): void
    {
        $gap = $this->observeUntilReady('technician-cannot-decide');
        Sanctum::actingAs($this->technician);
        $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/propose', ['proposal' => 'A real fix.'])->assertOk();

        $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/decide', ['authorized' => true, 'reason' => 'Looks fine to me.'])
            ->assertStatus(403);
    }

    public function test_deciding_a_gap_that_was_never_proposed_is_refused(): void
    {
        $gap = $this->observeUntilReady('never-proposed');
        Sanctum::actingAs($this->admin);

        $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/decide', ['authorized' => true, 'reason' => 'Skipping ahead.'])
            ->assertStatus(422)
            ->assertJson(['refused' => true]);
    }

    public function test_a_proposal_touching_a_protected_capability_is_refused_even_though_the_gap_was_recorded(): void
    {
        TenantContext::set($this->tenantOneId);
        $gap = null;
        for ($i = 0; $i < 5; $i++) {
            $gap = SelfObservation::observe(
                signalKind: SelfObservation::ESCALATION,
                clusterKey: 'tenancy-friction',
                title: 'Tenancy scoping keeps blocking a cross-project report',
                tenantId: $this->tenantOneId,
                askerKey: 'asker-'.$i,
                targetCapability: 'tenancy',
            );
        }
        TenantContext::clear();

        Sanctum::actingAs($this->technician);
        $this->postJson('/api/platform/capability-gaps/'.$gap->id.'/propose', ['proposal' => 'Loosen tenancy scoping for reporting.'])
            ->assertStatus(422)
            ->assertJson(['refused' => true]);

        // The observation itself is never refused - only the proposal.
        $this->assertSame('observed', CapabilityGap::withoutGlobalScopes()->find($gap->id)->status);
    }
}
