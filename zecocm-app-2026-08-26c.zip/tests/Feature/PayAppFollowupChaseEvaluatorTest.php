<?php

namespace Tests\Feature;

use App\Domain\Autonomy\AutonomyLevel;
use App\Domain\Autonomy\PayAppFollowupChaseEvaluator;
use App\Models\AutonomousAction;
use App\Models\AutonomyPolicy;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * AUTO-2's fifth seeded action: `pay_app_followup_chase`, Codex's explicit
 * split of "pay-app chasing" into two actions - this one is the EXTERNAL
 * communication half, and its system ceiling
 * (config/autonomy_action_ceilings.php) is hardcoded APPROVAL_REQUIRED, not
 * AUTO like its sibling `pay_app_draft_rollforward`.
 *
 * What this suite defends, per Codex's own warning: "do not let 'automatic
 * pay-app chasing' quietly reuse the safer shell-creation ceiling." Even a
 * project policy explicitly set to AUTO for this action_type must never
 * resolve to an executable level, because the ceiling wins - and this
 * evaluator never passes an auto_execute callback in the first place, so
 * there is no code path that could send anything even if the ceiling were
 * misconfigured.
 */
class PayAppFollowupChaseEvaluatorTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-862', 'name' => 'Chase Evaluator', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function withReviewClock(int $days = 10): void
    {
        $this->project->forceFill(['contract_clocks' => array_merge(
            (array) $this->project->contract_clocks, ['pay_app_review' => ['days' => $days, 'basis' => 'calendar']],
        )])->save();
    }

    private function withPaymentClock(int $days = 30): void
    {
        $this->project->forceFill(['contract_clocks' => array_merge(
            (array) $this->project->contract_clocks, ['pay_app_payment' => ['days' => $days, 'basis' => 'calendar']],
        )])->save();
    }

    private function application(array $overrides): PayApplication
    {
        return PayApplication::create(array_merge([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'number' => 1,
            'period_from' => '2026-07-01',
            'period_to' => '2026-07-31',
        ], $overrides));
    }

    public function test_no_confirmed_clock_produces_no_action(): void
    {
        // contract_clocks is empty - project has never configured either
        // clock - so this must not guess a period.
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(90)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNull($result);
        $this->assertSame(0, AutonomousAction::count());
    }

    public function test_a_submitted_application_still_inside_its_review_period_produces_no_action(): void
    {
        $this->withReviewClock(days: 10);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(2)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNull($result);
    }

    public function test_a_submitted_application_past_its_review_period_is_recorded(): void
    {
        $this->withReviewClock(days: 10);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(20)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNotNull($result);
        $this->assertNotNull($result['action']);
        $this->assertSame(PayAppFollowupChaseEvaluator::ACTION_TYPE, $result['action']->action_type);
        // No project policy exists, so the resolver's own "never AUTO by
        // omission" default applies on top of the hardcoded ceiling.
        $this->assertSame('pending_approval', $result['action']->status);
    }

    public function test_an_approved_application_past_its_payment_due_date_is_recorded(): void
    {
        $this->withPaymentClock(days: 30);
        $app = $this->application(['status' => 'approved', 'submitted_at' => now()->subDays(60), 'approved_at' => now()->subDays(45)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNotNull($result['action']);
        $this->assertSame('pending_approval', $result['action']->status);
    }

    public function test_an_approved_application_still_inside_its_payment_period_produces_no_action(): void
    {
        $this->withPaymentClock(days: 30);
        $app = $this->application(['status' => 'approved', 'submitted_at' => now()->subDays(10), 'approved_at' => now()->subDays(5)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNull($result);
    }

    public function test_re_evaluating_the_same_overdue_condition_does_not_duplicate_the_action(): void
    {
        $this->withReviewClock(days: 10);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(20)]);

        $first = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());
        $second = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertSame($first['action']->id, $second['action']->id);
        $this->assertSame(1, AutonomousAction::where('action_type', PayAppFollowupChaseEvaluator::ACTION_TYPE)->count());
    }

    public function test_an_application_that_moves_from_submitted_to_approved_stops_producing_a_review_chase(): void
    {
        // Codex's invariant: a chase follows the CURRENT obligation state,
        // not merely the fact that a deadline was once exceeded. Once the
        // application is approved, the review clock no longer applies to
        // it at all - evaluateApplication branches on current status only.
        $this->withReviewClock(days: 10);
        $this->withPaymentClock(days: 30);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(20)]);

        $reviewChase = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());
        $this->assertNotNull($reviewChase, 'the still-submitted application is past its review clock');

        // The application is approved shortly after - well inside its
        // payment window.
        $app->forceFill(['status' => 'approved', 'approved_at' => now()->subDay()])->save();
        $afterApproval = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNull($afterApproval, 'the stale review-clock condition must not still fire once approved');
        // The original review-chase action is untouched history, not deleted
        // or silently reused for the new state.
        $this->assertSame(1, AutonomousAction::where('action_type', PayAppFollowupChaseEvaluator::ACTION_TYPE)->count());
    }

    public function test_an_approved_application_that_is_paid_stops_producing_a_payment_chase(): void
    {
        $this->withPaymentClock(days: 30);
        $app = $this->application(['status' => 'approved', 'submitted_at' => now()->subDays(60), 'approved_at' => now()->subDays(45)]);

        $paymentChase = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());
        $this->assertNotNull($paymentChase, 'the still-unpaid application is past its payment clock');

        $app->forceFill(['status' => 'paid'])->save();
        $afterPayment = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNull($afterPayment, 'a paid application must never be evaluated for a payment chase');
    }

    public function test_a_later_overdue_recheck_with_a_different_due_date_produces_a_distinct_action(): void
    {
        // Codex's invariant: clock recalculation must produce a new
        // state_version rather than silently reusing an old chase. Changing
        // the confirmed clock's period changes the computed due date for the
        // SAME application/status, which must not collide with the action
        // already recorded under the old due date.
        $this->withReviewClock(days: 10);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(20)]);

        $first = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->withReviewClock(days: 5);
        $second = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNotSame($first['action']->id, $second['action']->id);
        $this->assertSame(2, AutonomousAction::where('action_type', PayAppFollowupChaseEvaluator::ACTION_TYPE)->count());
    }

    public function test_draft_rejected_and_paid_applications_are_excluded_from_the_project_scan(): void
    {
        $this->withReviewClock(days: 10);
        $this->withPaymentClock(days: 30);
        $this->application(['status' => 'draft']);
        $this->application(['number' => 2, 'status' => 'rejected', 'submitted_at' => now()->subDays(90)]);
        $this->application(['number' => 3, 'status' => 'paid', 'submitted_at' => now()->subDays(90), 'approved_at' => now()->subDays(80)]);

        $results = (new PayAppFollowupChaseEvaluator)->evaluateProject($this->tenant->id, $this->project->fresh()->id);

        $this->assertSame([], $results);
        $this->assertSame(0, AutonomousAction::count());
    }

    public function test_a_project_policy_set_to_auto_does_not_let_this_action_execute(): void
    {
        // Codex's explicit warning: the ceiling must win regardless of any
        // project policy. This proves it structurally, not just by
        // convention - even an AUTO policy row for this action_type must
        // resolve no more permissively than APPROVAL_REQUIRED, and nothing
        // is ever sent.
        AutonomyPolicy::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'capability' => 'payment',
            'action_type' => PayAppFollowupChaseEvaluator::ACTION_TYPE,
            'autonomy_level' => AutonomyLevel::AUTO,
            'authority_source' => 'test fixture',
            'set_by' => $this->user->id,
            'set_at' => now(),
            'effective_at' => now(),
            'status' => 'active',
        ]);
        $this->withReviewClock(days: 10);
        $app = $this->application(['status' => 'submitted', 'submitted_at' => now()->subDays(20)]);

        $result = (new PayAppFollowupChaseEvaluator)->evaluateApplication($app, $this->project->fresh());

        $this->assertNotNull($result['action']);
        $this->assertSame('pending_approval', $result['action']->status, 'the ceiling must win even over an explicit AUTO project policy');
        $this->assertNull($result['action']->executed_change);
    }
}
