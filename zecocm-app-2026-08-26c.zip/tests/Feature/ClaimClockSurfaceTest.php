<?php

namespace Tests\Feature;

use App\Domain\Claims\ClaimClock;
use App\Models\ClaimClockCalculation;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Claim clocks over HTTP.
 *
 * The property being defended: this surface never tells anybody their claim is
 * gone, and never shows a date it cannot establish.
 */
class ClaimClockSurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Project $project;
    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($tenant->id);
        $this->project = Project::create(['number' => 'P-900', 'name' => 'Claim Clock Surface', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_requirement_arrives_as_a_draft_no_matter_what_the_client_says(): void
    {
        // A requirement that arrives confirmed is a requirement nobody read.
        $body = $this->postJson('/api/claim-clocks/requirements',
            $this->requirementPayload(['status' => 'confirmed']))->assertCreated()->json();

        $this->assertSame('draft', $body['requirement']['status']);
    }

    public function test_a_requirement_with_no_period_cannot_be_confirmed(): void
    {
        $id = $this->postJson('/api/claim-clocks/requirements',
            $this->requirementPayload(['period_value' => null]))->assertCreated()->json()['requirement']['id'];

        $this->postJson('/api/claim-clocks/requirements/'.$id.'/confirm')
            ->assertStatus(422)
            ->assertJsonFragment(['message' => 'A requirement cannot be confirmed without the period it allows. '
                .'Confirming an empty period would create a clock with nothing to count.']);
    }

    public function test_a_working_day_rule_cannot_be_confirmed_without_saying_where_it_comes_from(): void
    {
        // Whether weekends count is a contract question, and an unsourced
        // counting rule is an invented deadline.
        $id = $this->postJson('/api/claim-clocks/requirements', $this->requirementPayload([
            'calendar_rule' => 'working', 'calendar_rule_source' => null,
        ]))->assertCreated()->json()['requirement']['id'];

        $this->postJson('/api/claim-clocks/requirements/'.$id.'/confirm')->assertStatus(422);
    }

    public function test_a_confirmed_requirement_cannot_be_confirmed_twice(): void
    {
        $id = $this->confirmedRequirement();

        $this->postJson('/api/claim-clocks/requirements/'.$id.'/confirm')
            ->assertStatus(409);
    }

    public function test_a_trigger_arrives_unresolved_and_a_clock_will_not_run_from_it(): void
    {
        $requirementId = $this->confirmedRequirement();
        $trigger = $this->postJson('/api/claim-clocks/triggers', [
            'project_id' => $this->project->id,
            'event_type' => 'differing_condition_encountered',
            'occurred_on' => '2026-08-25',
        ])->assertCreated()->json()['trigger'];

        $this->assertSame(ClaimClock::TRIGGER_UNRESOLVED, $trigger['status']);

        // Attach it and confirm no date is shown.
        \App\Models\ClaimRequirement::withoutGlobalScopes()->find($requirementId)
            ->forceFill(['claim_trigger_event_id' => $trigger['id']])->save();

        $row = $this->index()['requirements'][0];
        $this->assertSame(ClaimClock::UNRESOLVED_TRIGGER, $row['state']);
        $this->assertNull($row['deadline_on']);
    }

    public function test_confirming_a_trigger_without_a_date_is_refused(): void
    {
        $trigger = $this->postJson('/api/claim-clocks/triggers', [
            'project_id' => $this->project->id, 'event_type' => 'owner_directive_received',
        ])->assertCreated()->json()['trigger'];

        $this->postJson('/api/claim-clocks/triggers/'.$trigger['id'].'/resolve', [
            'status' => 'confirmed',
        ])->assertStatus(422);
    }

    public function test_a_confirmed_pair_produces_a_date_and_records_why(): void
    {
        $requirementId = $this->confirmedRequirement();
        $triggerId = $this->confirmedTrigger();

        \App\Models\ClaimRequirement::withoutGlobalScopes()->find($requirementId)
            ->forceFill(['claim_trigger_event_id' => $triggerId])->save();

        $row = $this->index()['requirements'][0];

        $this->assertSame(ClaimClock::ESTABLISHED, $row['state']);
        $this->assertSame('2026-09-04', $row['deadline_on']);
        $this->assertSame('Contract s. 4.03', $row['authority']);

        // And the reason it said that is now a durable record.
        $calculation = ClaimClockCalculation::withoutGlobalScopes()
            ->where('claim_requirement_id', $requirementId)->latest('id')->first();
        $this->assertNotNull($calculation);
        $this->assertSame('2026-09-04', $calculation->deadline_on->toDateString());
        $this->assertNotSame('', $calculation->authority_hash);
    }

    public function test_refreshing_the_screen_does_not_write_a_new_calculation_every_time(): void
    {
        $requirementId = $this->confirmedRequirement();
        \App\Models\ClaimRequirement::withoutGlobalScopes()->find($requirementId)
            ->forceFill(['claim_trigger_event_id' => $this->confirmedTrigger()])->save();

        $this->index();
        $this->index();
        $this->index();

        // Complete enough to reconstruct, shallow enough that nobody has to
        // read a thousand identical rows to find the two that matter.
        $this->assertSame(1, ClaimClockCalculation::withoutGlobalScopes()
            ->where('claim_requirement_id', $requirementId)->count());
    }

    public function test_a_deficient_notice_cannot_be_recorded_as_satisfying_the_requirement(): void
    {
        // Timely does not mean compliant, and the API will not let somebody
        // record that it does.
        $requirementId = $this->confirmedRequirement();

        $compliance = $this->postJson('/api/claim-clocks/requirements/'.$requirementId.'/compliance', [
            'sent_at' => '2026-08-28T10:00:00Z',
            'recipient' => 'Project Inspector',
        ])->assertCreated()->json();

        $this->assertSame('unresolved', $compliance['compliance']['satisfaction']);
        $this->assertStringContainsString('not as compliance', $compliance['note']);

        $this->postJson('/api/claim-clocks/compliance/'.$compliance['compliance']['id'].'/determine', [
            'timeliness' => 'timely',
            'content_completeness' => 'deficient',
            'satisfaction' => 'satisfied',
            'determination_basis' => 'It went out on time.',
        ])->assertStatus(422)
            ->assertJsonPath('error', 'A notice recorded as deficient in content cannot be recorded as satisfying the '
                .'requirement. Timeliness and completeness are separate findings, and a requirement is not met by a '
                .'document that arrived on time without what the clause demands.');
    }

    public function test_the_payload_carries_the_disclaimer_on_its_face(): void
    {
        $body = $this->index();

        $this->assertStringContainsString('does not determine that any claim is barred', $body['disclaimer']);
        $this->assertFalse($body['calendar']['confirmed']);
        $this->assertStringContainsString('rather than assume a Monday-to-Friday week', $body['calendar']['note']);
    }

    private function requirementPayload(array $overrides = []): array
    {
        return array_merge([
            'project_id' => $this->project->id,
            'requirement_type' => 'differing_site_condition_notice',
            'title' => 'Written notice of differing site condition',
            'authority_type' => 'contract',
            'authority_citation' => 'Contract s. 4.03',
            'consequence_class' => 'preservative',
            'trigger_type' => 'differing_condition_encountered',
            'period_value' => 10,
            'period_unit' => 'calendar_days',
            'calendar_rule' => 'calendar',
        ], $overrides);
    }

    private function confirmedRequirement(): int
    {
        $id = $this->postJson('/api/claim-clocks/requirements', $this->requirementPayload())
            ->assertCreated()->json()['requirement']['id'];
        $this->postJson('/api/claim-clocks/requirements/'.$id.'/confirm')->assertOk();

        return $id;
    }

    private function confirmedTrigger(): int
    {
        $trigger = $this->postJson('/api/claim-clocks/triggers', [
            'project_id' => $this->project->id,
            'event_type' => 'differing_condition_encountered',
        ])->assertCreated()->json()['trigger'];

        $this->postJson('/api/claim-clocks/triggers/'.$trigger['id'].'/resolve', [
            'status' => 'confirmed', 'occurred_on' => '2026-08-25',
        ])->assertOk();

        return $trigger['id'];
    }

    private function index(): array
    {
        return $this->getJson('/api/claim-clocks?project_id='.$this->project->id)->assertOk()->json();
    }
}
