<?php

namespace Tests\Feature;

use App\Domain\Compliance\CredentialStanding;
use DateTimeImmutable;
use Tests\TestCase;

/**
 * Was it good on the day the work was done?
 *
 * The whole point of this class, and the reason a status column would not have
 * done. A subcontractor whose licence lapsed in March and was reinstated in May
 * looks perfectly current today and was unlicensed for the April pour.
 */
class CredentialStandingTest extends TestCase
{
    public function test_a_licence_that_lapsed_during_the_work_is_caught_although_it_is_current_today(): void
    {
        // Reinstated in May. Today it reads fine. The April work does not.
        $lapsed = $this->credential('cslb_license', '2020-01-01', '2026-03-31');

        $duringTheGap = CredentialStanding::on($lapsed, new DateTimeImmutable('2026-04-15'));

        $this->assertSame(CredentialStanding::EXPIRED, $duringTheGap['state']);
        $this->assertTrue($duringTheGap['statutory']);
        $this->assertStringContainsString('not cured by the credential being current again now',
            $duringTheGap['message']);
    }

    public function test_the_same_licence_is_valid_for_work_inside_its_window(): void
    {
        $this->assertSame(CredentialStanding::VALID,
            CredentialStanding::on($this->credential('cslb_license', '2020-01-01', '2026-03-31'),
                new DateTimeImmutable('2026-02-10'))['state']);
    }

    public function test_a_credential_issued_after_the_work_does_not_cover_it(): void
    {
        // The retroactive certificate. Common, and it does not work.
        $standing = CredentialStanding::on(
            $this->credential('general_liability', '2026-06-01', '2027-06-01'),
            new DateTimeImmutable('2026-04-15'),
        );

        $this->assertSame(CredentialStanding::NOT_YET_EFFECTIVE, $standing['state']);
    }

    public function test_a_credential_with_no_dates_is_unknown_and_not_assumed_good(): void
    {
        // Treating a missing date as probably fine is how an expired certificate
        // sits in a file for a year looking like compliance.
        $standing = CredentialStanding::on(
            ['credential_type' => 'workers_comp', 'effective_from' => null, 'expires_on' => null],
            new DateTimeImmutable('2026-04-15'),
        );

        $this->assertSame(CredentialStanding::UNKNOWN, $standing['state']);
        $this->assertStringContainsString('cannot be established from the record', $standing['message']);
    }

    public function test_a_statutory_lapse_is_hard_invalid_and_an_insurance_lapse_withholds(): void
    {
        // The distinction that matters. An unlicensed pour may be unenforceable
        // work under B&P 7031 - the contract itself is in question. An insurance
        // gap means the work happened, may be perfectly good, and somebody
        // carried a risk they should not have.
        $findings = CredentialStanding::findings([
            $this->credential('cslb_license', '2020-01-01', '2026-03-31'),
            $this->credential('general_liability', '2020-01-01', '2026-03-31'),
        ], new DateTimeImmutable('2026-04-15'));

        $bySeverity = [];
        foreach ($findings as $f) {
            $bySeverity[$f['severity']][] = $f['code'];
        }

        $this->assertContains('statutory_credential_lapsed', $bySeverity['hard_invalid']);
        $this->assertContains('insurance_credential_lapsed', $bySeverity['withhold']);
    }

    public function test_dir_registration_cites_the_labor_code(): void
    {
        $findings = CredentialStanding::findings(
            [$this->credential('dir_registration', '2020-01-01', '2026-03-31')],
            new DateTimeImmutable('2026-04-15'),
        );

        $this->assertSame('California Labor Code s. 1725.5', $findings[0]['citation']);
    }

    public function test_a_required_credential_that_was_never_recorded_is_reported(): void
    {
        $findings = CredentialStanding::findings([], new DateTimeImmutable('2026-04-15'),
            required: ['cslb_license', 'workers_comp']);

        $codes = array_column($findings, 'code');
        $this->assertSame(['credential_missing', 'credential_missing'], $codes);
        $this->assertSame('hard_invalid', $findings[0]['severity']);
        $this->assertSame('withhold', $findings[1]['severity']);
    }

    public function test_a_number_in_a_box_is_not_a_certificate(): void
    {
        // In force, in date, and nobody has ever seen the document.
        $findings = CredentialStanding::findings(
            [$this->credential('general_liability', '2026-01-01', '2027-01-01', onFile: false)],
            new DateTimeImmutable('2026-04-15'),
        );

        $this->assertSame('credential_document_missing', $findings[0]['code']);
        $this->assertStringContainsString('not a certificate', $findings[0]['message']);
    }

    public function test_a_fully_good_credential_produces_no_finding(): void
    {
        $this->assertSame([], CredentialStanding::findings(
            [$this->credential('general_liability', '2026-01-01', '2027-01-01', onFile: true)],
            new DateTimeImmutable('2026-04-15'),
        ));
    }

    public function test_expiries_are_surfaced_before_they_bite(): void
    {
        $soon = CredentialStanding::expiringWithin([
            $this->credential('general_liability', '2026-01-01', '2026-05-01'),
            $this->credential('workers_comp', '2026-01-01', '2027-01-01'),
        ], new DateTimeImmutable('2026-04-15'), days: 30);

        $this->assertCount(1, $soon);
        $this->assertSame('general_liability', $soon[0]['credential_type']);
        $this->assertSame(16, $soon[0]['days_remaining']);
    }

    private function credential(string $type, ?string $from, ?string $until, bool $onFile = true): array
    {
        return ['credential_type' => $type, 'effective_from' => $from,
            'expires_on' => $until, 'document_on_file' => $onFile];
    }
}
