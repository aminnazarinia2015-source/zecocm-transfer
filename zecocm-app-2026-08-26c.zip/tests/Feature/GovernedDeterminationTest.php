<?php

namespace Tests\Feature;

use App\Domain\Governance\GovernedDetermination;
use App\Domain\Schedule\ProjectAccess;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Tests\TestCase;

/**
 * The half nobody was watching.
 *
 * Everything in this system defers to an accountable person, which is correct
 * design and the reason the machine refuses rather than guesses. It also means
 * human judgment is part of the trusted computing base.
 *
 * The failure: TRACE refuses correctly - "I cannot tell whether Addendum 4
 * replaces 3.2.B" - and then somebody confirms the wrong scope. From that
 * moment the machine is confident, internally consistent and wrong. Every
 * retrieval test passes, every hash verifies, every chain links, every tenant
 * boundary holds. The false answer's source is a human determination that
 * entered the trusted state correctly.
 */
class GovernedDeterminationTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $steward;
    private User $reviewer;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->steward = User::create(['tenant_id' => $this->tenant->id, 'name' => 'A. Steward',
            'email' => 'steward@northgate.test', 'password' => bcrypt('password')]);
        $this->reviewer = User::create(['tenant_id' => $this->tenant->id, 'name' => 'B. Reviewer',
            'email' => 'reviewer@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-600', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        foreach ([$this->steward, $this->reviewer] as $u) {
            Membership::create(['project_id' => $this->project->id, 'user_id' => $u->id,
                'organization' => 'Northgate', 'seat' => 'knowledge_steward', 'capabilities' => ['*' => true]]);
        }
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_determination_records_the_authority_actually_held_at_the_time(): void
    {
        // Grants get widened and narrowed. The record of what somebody could do
        // when they did it must not move with them.
        $id = $this->determine('knowledge_verification', 7, 'Reviewed against the executed contract, page 14.');

        $row = DB::table('governed_determinations')->find($id);

        $this->assertSame($this->steward->id, (int) $row->determined_by);
        $this->assertStringContainsString('knowledge_steward', $row->determiner_role);
        $this->assertNotNull($row->determiner_authority);
        $this->assertNotEmpty($row->decision_hash);
        $this->assertSame(GovernedDetermination::ACTIVE, $row->status);
    }

    public function test_a_determination_without_a_reason_is_refused(): void
    {
        // The PN 851 shape exactly: a source promoted to verified on a reason
        // nobody wrote. A determination with no basis is a click.
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('has to say why');

        $this->determine('knowledge_verification', 7, '   ');
    }

    public function test_a_wrong_determination_is_corrected_by_a_new_one_and_never_by_editing(): void
    {
        $first = $this->determine('supersession_scope', 42, 'Addendum 4 replaces 3.2.B in its entirety.');
        $second = $this->determine('supersession_scope', 42, 'Re-read the addendum: it replaces 3.2.C, not 3.2.B.',
            supersedes: $first);

        $this->assertSame(GovernedDetermination::SUPERSEDED,
            DB::table('governed_determinations')->find($first)->status);
        $this->assertSame(GovernedDetermination::ACTIVE,
            DB::table('governed_determinations')->find($second)->status);

        // The wrong one stays, with its author's name on it. That it was
        // believed for a while is part of the history somebody may need.
        $this->assertNotNull(DB::table('governed_determinations')->find($first));
        $this->assertSame($this->steward->id, (int) DB::table('governed_determinations')->find($first)->determined_by);

        // And only the current one is standing.
        $standing = GovernedDetermination::standingFor('supersession_scope', 42);
        $this->assertCount(1, $standing);
        $this->assertSame($second, (int) $standing[0]['id']);
    }

    public function test_withdrawing_says_this_should_never_have_been_asserted(): void
    {
        // Distinct from superseding. Superseding offers a better answer;
        // withdrawing says nothing replaces it. My own PN 851 error is this
        // shape - four sources promoted to verified on a fabricated reason.
        $first = $this->determine('knowledge_verification', 851, 'Verified.');

        $withdrawal = GovernedDetermination::withdraw($this->steward, $this->grant(), $first,
            'Promoted without a human review actually having taken place. The verification is retracted; '
            .'no replacement determination is offered and the sources return to provisional.');

        $this->assertSame(GovernedDetermination::WITHDRAWN,
            DB::table('governed_determinations')->find($first)->status);
        $this->assertSame('withdrawal',
            DB::table('governed_determinations')->find($withdrawal)->determination_type);

        // Nothing stands on that subject any more.
        $this->assertSame([], array_filter(
            GovernedDetermination::standingFor('knowledge_verification', 851),
            fn ($d) => $d['determination_type'] === 'knowledge_verification',
        ));
    }

    public function test_a_determination_cannot_be_reviewed_by_the_person_who_made_it(): void
    {
        $id = $this->determine('knowledge_verification', 9, 'Reviewed against the specification.',
            review: GovernedDetermination::REVIEW_SECOND_PERSON);

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('not the same as being two people');

        GovernedDetermination::review($this->steward, $id);
    }

    public function test_a_second_person_reviews_and_it_leaves_the_queue(): void
    {
        $id = $this->determine('knowledge_verification', 9, 'Reviewed against the specification.',
            review: GovernedDetermination::REVIEW_SECOND_PERSON);

        $this->assertCount(1, GovernedDetermination::awaitingReview($this->tenant->id));

        GovernedDetermination::review($this->reviewer, $id);

        $this->assertSame([], GovernedDetermination::awaitingReview($this->tenant->id));
        $this->assertSame($this->reviewer->id, (int) DB::table('governed_determinations')->find($id)->reviewed_by);
    }

    public function test_a_determination_already_superseded_cannot_be_superseded_again(): void
    {
        $first = $this->determine('supersession_scope', 42, 'First reading.');
        $this->determine('supersession_scope', 42, 'Corrected reading.', supersedes: $first);

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('already superseded');

        $this->determine('supersession_scope', 42, 'Third reading.', supersedes: $first);
    }


    public function test_verifying_a_source_writes_a_determination_awaiting_a_second_person(): void
    {
        // The end-to-end shape. Promoting a source changes what TRACE may treat
        // as authoritative, so it lands in the same layer as every other act of
        // that kind - and it does not stand on one person.
        TenantContext::set($this->tenant->id);
        $source = \App\Models\KnowledgeSource::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'project',
            'title' => 'Special Provisions', 'source_type' => 'specification',
            'storage_path' => 'k/sp.txt', 'sha256' => str_repeat('e', 64),
            'malware_scan_status' => 'clean', 'ingestion_status' => 'ready',
        ]);
        $version = $source->versions()->create(['version_number' => 1, 'sha256' => str_repeat('f', 64),
            'extraction_method' => 'text', 'parser_version' => 'test']);
        \App\Models\KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1,
            'body' => 'Trench depth shall be 36 in.', 'body_sha256' => str_repeat('g', 64)]);
        TenantContext::clear();

        \Laravel\Sanctum\Sanctum::actingAs($this->steward);

        $body = $this->postJson('/api/knowledge/sources/'.$source->id.'/review', [
            'action' => 'verify',
            'reason' => 'Compared against the executed Special Provisions, page 14, section 3.2.',
        ])->assertOk()->json();

        $this->assertNotNull($body['determination_id']);
        $this->assertStringContainsString('awaiting a second person', $body['notice']);
        $this->assertCount(1, GovernedDetermination::awaitingReview($this->tenant->id));

        // And returning it to provisional withdraws that determination rather
        // than deleting it. This is the PN 851 correction path.
        $back = $this->postJson('/api/knowledge/sources/'.$source->id.'/review', [
            'action' => 'return_to_provisional',
            'reason' => 'Promoted without a second review actually taking place. Retracted.',
        ])->assertOk()->json();

        $this->assertNotNull($back['withdrawal_determination_id']);
        $this->assertStringContainsString('withdrawn rather than removed', $back['notice']);
        $this->assertSame(GovernedDetermination::WITHDRAWN,
            DB::table('governed_determinations')->find($body['determination_id'])->status);
    }

    private function determine(string $type, int $subjectId, string $reason,
        ?int $supersedes = null, string $review = GovernedDetermination::REVIEW_NONE): int
    {
        TenantContext::set($this->tenant->id);
        $id = GovernedDetermination::record(
            actor: $this->steward, grant: $this->grant(), type: $type,
            subjectType: $type, subjectId: $subjectId, reason: $reason,
            reviewRequirement: $review, supersedes: $supersedes,
        );
        TenantContext::clear();

        return $id;
    }

    private function grant()
    {
        TenantContext::set($this->tenant->id);
        $grant = app(ProjectAccess::class)->authorize($this->steward, $this->project->id, 'knowledge.verify');
        TenantContext::clear();

        return $grant;
    }
}