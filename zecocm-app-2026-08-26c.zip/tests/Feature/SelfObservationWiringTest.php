<?php

namespace Tests\Feature;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\AiResult;
use App\Domain\Ai\AiRunLedger;
use App\Domain\Ai\Citation;
use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\NoMatch;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Evolution\SelfObservation;
use App\Domain\Licensing\CapabilityLicense;
use App\Jobs\RunGovernedAi;
use App\Models\AiFeedbackEvent;
use App\Models\AiRun;
use App\Models\CapabilityGap;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * TRACE proposing its own next build (trace-independence.md, Part 3):
 * `SelfObservation` existed with nothing calling it - every no_match,
 * escalation and steward correction went nowhere. This suite defends the
 * wiring added to close that gap: three signal sources now actually reach
 * `SelfObservation::observe()`, and it defends the boundary just as hard as
 * the wiring - this never applies anything on its own, it only clusters and
 * counts, and a person still reads a proposal before anything changes.
 */
class SelfObservationWiringTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-863', 'name' => 'Observation Wiring', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function makeRun(string $question, int $requestedBy, string $category = 'general_administration'): AiRun
    {
        return AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'requested_by' => $requestedBy,
            'public_id' => (string) Str::uuid(), 'idempotency_key' => Str::random(32), 'task_type' => 'answer',
            'category' => $category, 'question' => $question, 'status' => 'queued',
            'provider' => 'anthropic', 'model' => 'test-model', 'prompt_version' => 'v1', 'retrieval_version' => 'v1',
            'policy_version' => 'refusal-v1', 'authorization_scope' => [], 'retrieval_scope' => [],
        ]);
    }

    private function bindAssistant(AiResult $result): void
    {
        $this->app->bind(AiAssistant::class, fn () => new class($result) implements AiAssistant
        {
            public function __construct(private readonly AiResult $result) {}

            public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): AiResult
            {
                return $this->result;
            }
        });
    }

    private function handle(AiRun $run): void
    {
        (new RunGovernedAi($run->id))->handle(app(AiAssistant::class), app(AiRunLedger::class));
    }

    public function test_an_escalation_is_observed_as_a_capability_gap(): void
    {
        $this->bindAssistant(new Escalation(
            reason: 'Two SOV lines conflict on retention basis.',
            routeTo: 'project accountant',
            basis: Escalation::BASIS_CONFLICT,
        ));
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);

        $this->handle($run);

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::ESCALATION)->first();
        TenantContext::clear();

        $this->assertNotNull($gap);
        $this->assertSame(1, $gap->occurrences);
        $this->assertSame(1, $gap->distinct_askers);
        $this->assertSame(SelfObservation::OBSERVED, $gap->status);
    }

    public function test_a_no_match_is_observed_as_a_capability_gap(): void
    {
        $this->bindAssistant(new NoMatch('project_specs, project_contract'));
        $run = $this->makeRun('does the contract require a specific paint sheen', $this->user->id);

        $this->handle($run);

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::NO_MATCH)->first();
        TenantContext::clear();

        $this->assertNotNull($gap);
        $this->assertSame(1, $gap->occurrences);
    }

    public function test_a_cited_suggestion_records_no_capability_gap(): void
    {
        $this->bindAssistant(new CitedSuggestion(
            text: 'Retention is withheld at 5% per Section 00700.',
            citations: [new Citation(
                source: 'Agreement A-9764', edition: null, retrievedAt: new \DateTimeImmutable,
            )],
        ));
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);

        $this->handle($run);

        $this->assertSame(0, CapabilityGap::withoutGlobalScopes()->count());
    }

    public function test_the_same_question_asked_by_two_different_people_counts_two_distinct_askers(): void
    {
        $this->bindAssistant(new NoMatch('project_specs'));
        $other = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Super',
            'email' => 'super@northgate.test', 'password' => bcrypt('password')]);

        $this->handle($this->makeRun('does the contract require a specific paint sheen', $this->user->id));
        $this->handle($this->makeRun('does contract require specific paint sheen', $other->id));

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::NO_MATCH)->first();
        TenantContext::clear();

        $this->assertSame(2, $gap->occurrences);
        $this->assertSame(2, $gap->distinct_askers);
    }

    public function test_a_steward_correction_is_observed_via_the_feedback_endpoint(): void
    {
        TenantContext::set($this->tenant->id);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'pm', 'capabilities' => ['assistant.use' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear();
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);
        Sanctum::actingAs($this->user);

        $this->postJson('/api/ai-runs/'.$run->id.'/feedback', ['label' => 'corrected', 'comment' => 'Retention is 5%, not 10%.'])
            ->assertStatus(201);

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::STEWARD_CORRECTION)->first();
        $feedbackCount = AiFeedbackEvent::count();
        TenantContext::clear();

        $this->assertNotNull($gap, 'a corrected label should produce a steward_correction capability gap');
        $this->assertSame(1, $feedbackCount);
    }

    public function test_an_accepted_feedback_label_records_no_capability_gap(): void
    {
        TenantContext::set($this->tenant->id);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'pm', 'capabilities' => ['assistant.use' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear();
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);
        Sanctum::actingAs($this->user);

        $this->postJson('/api/ai-runs/'.$run->id.'/feedback', ['label' => 'accepted'])->assertStatus(201);

        TenantContext::set($this->tenant->id);
        $count = CapabilityGap::query()->where('signal_kind', SelfObservation::STEWARD_CORRECTION)->count();
        TenantContext::clear();

        $this->assertSame(0, $count);
    }

    public function test_resubmitting_a_corrected_label_on_the_same_run_does_not_double_count(): void
    {
        // Codex's finding: a double-click or a retried request must not make
        // the capability-gap threshold a measure of retry behavior rather
        // than of how often ZecoCM is actually confidently wrong. Only the
        // run's FIRST correction should count as a signal.
        TenantContext::set($this->tenant->id);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'pm', 'capabilities' => ['assistant.use' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear();
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);
        Sanctum::actingAs($this->user);

        $this->postJson('/api/ai-runs/'.$run->id.'/feedback', ['label' => 'corrected', 'comment' => 'Retention is 5%.'])
            ->assertStatus(201);
        $this->postJson('/api/ai-runs/'.$run->id.'/feedback', ['label' => 'corrected', 'comment' => 'Retention is 5%.'])
            ->assertStatus(201);

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::STEWARD_CORRECTION)->first();
        $feedbackCount = AiFeedbackEvent::count();
        TenantContext::clear();

        $this->assertSame(2, $feedbackCount, 'both feedback events are still recorded');
        $this->assertSame(1, $gap->occurrences, 'but only the first correction produced an observation');
    }

    public function test_an_escalation_never_produces_a_proposal_by_itself(): void
    {
        // The hard boundary: observation is automatic, a proposal never is.
        // Even after wiring, nothing in this codebase calls
        // SelfObservation::propose() from inside the job or the controller -
        // that remains a deliberate, separate human-facing act.
        $this->bindAssistant(new Escalation(reason: 'conflict', routeTo: 'PM', basis: Escalation::BASIS_CONFLICT));
        $run = $this->makeRun('what is the retention rate on this contract', $this->user->id);

        $this->handle($run);

        TenantContext::set($this->tenant->id);
        $gap = CapabilityGap::query()->where('signal_kind', SelfObservation::ESCALATION)->first();
        TenantContext::clear();

        $this->assertSame(SelfObservation::OBSERVED, $gap->status);
        $this->assertNull($gap->proposal);
    }
}
