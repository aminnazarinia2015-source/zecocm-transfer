<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class QualityWorkflowTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant; private User $user; private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Quality City', 'type' => 'City portal', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('City portal'), 'sponsor_role' => 'city', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Inspector', 'email' => 'inspector@example.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'Q-1', 'name' => 'Quality Project', 'sector' => 'public', 'owner_name' => 'Quality City', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id, 'organization' => 'Quality City', 'seat' => 'inspector', 'capabilities' => ['*' => true]]);
        TenantContext::clear(); Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void { TenantContext::clear(); parent::tearDown(); }

    public function test_quality_record_and_status_history_are_append_only(): void
    {
        $item = $this->postJson('/api/quality-items', $this->payload())->assertCreated()
            ->assertJsonPath('item.status', 'open')->json('item');
        $this->postJson('/api/quality-items/'.$item['id'].'/transition', ['to_status' => 'in_progress',
            'note' => 'Contractor acknowledged correction.', 'classification' => 'party_assertion'])->assertOk();
        $this->postJson('/api/quality-items/'.$item['id'].'/transition', ['to_status' => 'ready_for_verification',
            'note' => 'Correction reported complete.', 'classification' => 'party_assertion'])->assertOk();
        $this->postJson('/api/quality-items/'.$item['id'].'/transition', ['to_status' => 'closed',
            'note' => 'Inspector verified the corrected installation in the field.', 'classification' => 'formal_determination'])->assertOk();
        $this->assertDatabaseCount('quality_item_events', 4);
        $this->assertDatabaseHas('quality_items', ['id' => $item['id'], 'status' => 'closed']);
        $this->assertNotNull(\DB::table('quality_item_events')->latest('id')->value('previous_event_hash'));
    }

    public function test_closure_requires_formal_human_determination(): void
    {
        $id = $this->postJson('/api/quality-items', $this->payload())->assertCreated()->json('item.id');
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'ready_for_verification',
            'note' => 'Reported ready.', 'classification' => 'party_assertion'])->assertOk();
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'closed',
            'note' => 'AI thinks this is closed.', 'classification' => 'recommendation'])->assertUnprocessable();
        $this->assertDatabaseHas('quality_items', ['id' => $id, 'status' => 'ready_for_verification']);
    }

    /**
     * Independent adversarial checks written on the build side. The closure rule is the
     * whole point of this module: if a party's claim or a machine recommendation could
     * ever close a deficiency, the register would be worthless as evidence.
     */
    public function test_closure_cannot_be_reached_by_skipping_verification(): void
    {
        $id = $this->postJson('/api/quality-items', $this->payload())->assertCreated()->json('item.id');

        // Straight from open to closed, with the correct classification, must still refuse.
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'closed',
            'note' => 'Closing it directly.', 'classification' => 'formal_determination'])->assertUnprocessable();
        $this->assertDatabaseHas('quality_items', ['id' => $id, 'status' => 'open']);

        // In progress is also not a closable state.
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'in_progress',
            'note' => 'Work started.', 'classification' => 'party_assertion'])->assertOk();
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'closed',
            'note' => 'Closing from in progress.', 'classification' => 'formal_determination'])->assertUnprocessable();
        $this->assertDatabaseHas('quality_items', ['id' => $id, 'status' => 'in_progress']);
    }

    public function test_a_reopened_item_cannot_be_closed_again_without_a_fresh_determination(): void
    {
        $id = $this->postJson('/api/quality-items', $this->payload())->assertCreated()->json('item.id');
        foreach ([['ready_for_verification', 'party_assertion'], ['closed', 'formal_determination'], ['reopened', 'dispute']] as [$to, $cls]) {
            $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => $to,
                'note' => 'Step to '.$to.'.', 'classification' => $cls])->assertOk();
        }

        // Reopened must walk the ladder again; it cannot jump straight back to closed.
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'closed',
            'note' => 'Re-closing without re-verifying.', 'classification' => 'formal_determination'])->assertUnprocessable();
        $this->assertDatabaseHas('quality_items', ['id' => $id, 'status' => 'reopened']);
    }

    public function test_the_event_chain_is_continuous_and_every_link_verifies(): void
    {
        $id = $this->postJson('/api/quality-items', $this->payload())->assertCreated()->json('item.id');
        foreach ([['in_progress', 'party_assertion'], ['ready_for_verification', 'party_assertion'], ['closed', 'formal_determination']] as [$to, $cls]) {
            $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => $to,
                'note' => 'Moving to '.$to.'.', 'classification' => $cls])->assertOk();
        }

        $events = \DB::table('quality_item_events')->where('quality_item_id', $id)->orderBy('id')->get();
        $this->assertCount(4, $events);
        $this->assertNull($events[0]->previous_event_hash, 'The first event must anchor the chain.');
        for ($i = 1; $i < count($events); $i++) {
            $this->assertSame($events[$i - 1]->event_hash, $events[$i]->previous_event_hash,
                'Event '.$i.' does not link to the event before it; the chain is broken.');
        }
    }

    public function test_cross_tenant_quality_identifier_fails_closed(): void
    {
        $id = $this->postJson('/api/quality-items', $this->payload())->assertCreated()->json('item.id');
        $other = Tenant::create(['name' => 'Other', 'type' => 'CM firm', 'status' => 'active', 'entitlements' => [], 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $otherUser = User::create(['tenant_id' => $other->id, 'name' => 'Other', 'email' => 'quality-other@example.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($otherUser);
        $this->postJson("/api/quality-items/{$id}/transition", ['to_status' => 'in_progress', 'note' => 'Attack', 'classification' => 'fact'])->assertNotFound();
    }

    private function payload(): array
    {
        return ['project_id' => $this->project->id, 'kind' => 'deficiency', 'title' => 'Concrete honeycombing at wall',
            'description' => 'Observed voids at the north wall lift near grid B-4.', 'classification' => 'fact', 'severity' => 'high',
            'location' => 'North wall, grid B-4', 'spec_section' => '03 30 00', 'drawing_reference' => 'S-401',
            'assigned_organization' => 'Prime Contractor'];
    }
}
