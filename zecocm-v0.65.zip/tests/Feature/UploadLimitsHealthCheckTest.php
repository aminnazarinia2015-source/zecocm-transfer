<?php

namespace Tests\Feature;

use App\Domain\Ops\UploadLimitsHealthCheck;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

/**
 * OPS-17: found during a real-world audit that actually uploaded a real 5MB
 * test photo through the real endpoint - it failed with a bare "The file
 * failed to upload" 422. PHP's stock upload_max_filesize/post_max_size
 * (2M/8M) silently cap every upload below what nginx and this app's
 * own validation rules already promise, and nothing in deploy/bootstrap.sh
 * ever raised them before this fix. This locks in the same fail-loudly
 * pattern as MalwareScannerHealthCheck (OPS-16) and EvidenceStorageHealthCheck
 * (OPS-14) for this gap.
 *
 * Threshold raised from 100MB to 750MB after Amin flagged that real project drawing sets
 * routinely run 300-500MB - the original 100MB ceiling (set from the first real bug found, a
 * 5MB test photo) was never meant to be the app's final ceiling, just the first proof the
 * pipeline (nginx/php/validation) agreed with itself at all.
 *
 * ini_set() cannot change upload_max_filesize/post_max_size at runtime (both
 * are PHP_INI_PERDIR) - these tests call the check's own ini-parsing helper
 * indirectly by asserting against whatever this test process's actual php.ini
 * has, and directly unit-test the byte-parsing behavior everything else
 * depends on via a small reflection-free public seam.
 */
class UploadLimitsHealthCheckTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => 'tok-baseline', 'queue_name' => 'default',
            'dispatched_at' => now()->subSeconds(2), 'handled_at' => now()->subSecond(),
            'worker_identity' => 'worker-baseline',
        ]);
    }

    public function test_up_passes_when_this_test_runners_own_php_ini_already_meets_the_requirement(): void
    {
        // This sandbox's CLI php.ini was raised to upload_max_filesize=800M /
        // post_max_size=820M while diagnosing this exact issue - proves the
        // check reads the true, live ini_get() value rather than some cached
        // or hardcoded assumption.
        $uploadMax = ini_get('upload_max_filesize');
        $postMax = ini_get('post_max_size');
        $this->assertNotFalse($uploadMax);
        $this->assertNotFalse($postMax);

        $this->get('/up')->assertOk();
    }

    public function test_the_health_check_is_registered_on_diagnosing_health(): void
    {
        $source = file_get_contents(app_path('Providers/AppServiceProvider.php'));

        $this->assertStringContainsString(class_basename(UploadLimitsHealthCheck::class).'::class', $source,
            'UploadLimitsHealthCheck must be registered on DiagnosingHealth for /up to actually exercise it.');
    }

    public function test_bootstrap_ships_a_php_ini_dropin_that_matches_the_apps_own_limits(): void
    {
        $script = file_get_contents(base_path('deploy/bootstrap.sh'));

        $this->assertStringContainsString('99-zecocm-uploads.ini', $script,
            'bootstrap.sh must ship a php.ini drop-in raising upload limits - otherwise every fresh '.
            'deploy starts back at PHP\'s 2M/8M stock defaults.');
        $this->assertMatchesRegularExpression('/upload_max_filesize\s*=\s*([7-9][0-9]{2}|[1-9][0-9]{3,})M/', $script,
            'The shipped upload_max_filesize must be at least 750M to match DocumentLibraryController\'s own max:768000 rule.');
    }

    public function test_document_library_controller_still_validates_up_to_750mb(): void
    {
        // Guards the OTHER half of the invariant this check enforces: if
        // DocumentLibraryController's own max: rule is ever lowered below what this health check
        // requires, the two would silently drift apart again.
        $path = app_path('Http/Controllers/DocumentLibraryController.php');
        $this->assertSame(2, substr_count(file_get_contents($path), 'max:768000'),
            'DocumentLibraryController must still validate both store() and storeVersion() up to '.
            '750MB (max:768000) - UploadLimitsHealthCheck\'s required threshold is derived from this rule.');
    }

    public function test_media_controller_stays_at_the_smaller_100mb_evidence_ceiling(): void
    {
        // Evidence photos/media don't need the 750MB drawing-set ceiling - this is a deliberate,
        // smaller cap, not an oversight, and this locks that choice in so it isn't silently
        // "fixed" to match the document ceiling later.
        $this->assertStringContainsString('max:102400', file_get_contents(app_path('Http/Controllers/MediaController.php')),
            'MediaController should keep its own smaller 100MB evidence-media ceiling.');
    }
}
