<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\ChangeOrder;
use App\Models\ChangeOrderAllocation;
use App\Models\Membership;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * AUTO-2's third missing piece over HTTP: a structured export of a pay
 * application for the customer's own accountant. This suite defends the
 * things Codex was explicit about: the export is a reshaping of data the
 * user can already see (gated on the existing payment.view capability, not
 * a new grant), the CSV and HTML come from the exact same snapshot, and
 * nothing outside that snapshot's scope (payroll PII, internal reasoning,
 * unrelated evidence) is anywhere in the output because none of it is ever
 * assembled in the first place.
 */
class PayApplicationAccountantExportTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    private PayApplication $application;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Controller',
            'email' => 'controller@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-861', 'name' => 'Accountant Export', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);

        $item = ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'item_number' => '001', 'description' => 'Sitework', 'scheduled_value_cents' => 11_000_00,
            'original_value_cents' => 10_000_00]);

        $co = ChangeOrder::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 'CO-1', 'title' => 'Added sitework scope', 'status' => 'approved',
            'amount_cents' => 1_000_00, 'approved_at' => now()]);
        ChangeOrderAllocation::create(['tenant_id' => $this->tenant->id, 'change_order_id' => $co->id,
            'schedule_of_value_item_id' => $item->id, 'amount_cents' => 1_000_00,
            'same_scope_justification' => 'Same sitework area.']);

        $this->application = PayApplication::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 1, 'period_from' => '2026-07-01', 'period_to' => '2026-07-31', 'status' => 'certified',
            'certified_at' => now()]);
        PayApplicationLine::create(['tenant_id' => $this->tenant->id, 'pay_application_id' => $this->application->id,
            'schedule_of_value_item_id' => $item->id, 'previous_completed_cents' => 2_000_00,
            'this_period_cents' => 3_000_00, 'stored_materials_cents' => 500_00]);

        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate Builders', 'seat' => 'controller',
            'capabilities' => ['payment.view' => true, 'changeorder.view' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'pay_apps', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_user_without_payment_view_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $bystander = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Nobody',
            'email' => 'nobody@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $bystander->id,
            'organization' => 'Northgate Builders', 'seat' => 'guest', 'capabilities' => []]);
        TenantContext::clear();
        Sanctum::actingAs($bystander);

        $this->getJson('/api/pay-applications/'.$this->application->id.'/accountant-export')->assertStatus(403);
    }

    public function test_the_json_envelope_carries_the_snapshot_csv_and_html_from_one_source(): void
    {
        $body = $this->getJson('/api/pay-applications/'.$this->application->id.'/accountant-export')
            ->assertOk()->json();

        $this->assertArrayHasKey('snapshot', $body);
        $this->assertArrayHasKey('csv', $body);
        $this->assertArrayHasKey('html', $body);
        $this->assertArrayHasKey('fingerprint', $body);
        // The fingerprint is computed over the document BEFORE it is stamped into
        // that same document (identical convention to TransmittalComposer), so it
        // is a stable 64-character sha256 hex digest embedded in the html, not a
        // hash of the html's own final bytes.
        $this->assertSame(64, strlen($body['fingerprint']));
        $this->assertStringContainsString($body['fingerprint'], $body['html']);
        $this->assertCount(1, $body['snapshot']['lines']);
    }

    public function test_the_csv_has_one_row_per_sov_line_with_the_reconciled_change_order_amount(): void
    {
        $csv = $this->get('/api/pay-applications/'.$this->application->id.'/accountant-export?format=csv')
            ->assertOk()
            ->assertHeader('Content-Type', 'text/csv; charset=UTF-8')
            ->getContent();

        $rows = array_map('str_getcsv', explode("\n", trim($csv)));
        $header = array_shift($rows);

        $this->assertContains('approved_co_delta', $header);
        $this->assertContains('balance_to_finish', $header);
        $this->assertCount(1, $rows);

        $row = array_combine($header, $rows[0]);
        $this->assertSame('001', $row['sov_item_number']);
        $this->assertSame('1000.00', $row['approved_co_delta']);
        // scheduled 11,000 - current completed (2,000 + 3,000) = 6,000.
        $this->assertSame('6000.00', $row['balance_to_finish']);
        $this->assertSame('CO-1', $row['change_order_references']);
    }

    public function test_the_html_export_is_self_contained_and_carries_a_matching_fingerprint(): void
    {
        $html = $this->get('/api/pay-applications/'.$this->application->id.'/accountant-export?format=html')
            ->assertOk()
            ->assertHeader('Content-Type', 'text/html; charset=UTF-8')
            ->getContent();

        $this->assertStringContainsString('<!doctype html>', $html);
        $this->assertStringNotContainsString('<script', $html);
        $this->assertStringContainsString('DOCUMENT FINGERPRINT', $html);
        $this->assertStringContainsString('CO-1', $html);
    }

    public function test_a_system_created_application_names_the_autonomous_action_in_the_trace_section(): void
    {
        TenantContext::set($this->tenant->id);
        $this->application->forceFill(['autonomous_action_id' => 4242])->save();
        TenantContext::clear();

        $body = $this->getJson('/api/pay-applications/'.$this->application->id.'/accountant-export')->assertOk()->json();

        $this->assertTrue($body['snapshot']['trace']['created_by_automation']);
        $this->assertSame(4242, $body['snapshot']['trace']['autonomous_action_id']);
    }

    public function test_a_manually_created_application_names_that_in_the_trace_section(): void
    {
        $body = $this->getJson('/api/pay-applications/'.$this->application->id.'/accountant-export')->assertOk()->json();

        $this->assertFalse($body['snapshot']['trace']['created_by_automation']);
        $this->assertNull($body['snapshot']['trace']['autonomous_action_id']);
    }

    public function test_a_viewer_without_changeorder_view_never_receives_the_co_reference(): void
    {
        // Codex's finding: payment.view alone must not become a side channel
        // around SEC-3's changeorder.view gate. A viewer who can see this pay
        // application but not change orders directly must not learn CO
        // numbers through this export.
        TenantContext::set($this->tenant->id);
        $restricted = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Bookkeeper',
            'email' => 'bookkeeper@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $restricted->id,
            'organization' => 'Northgate Builders', 'seat' => 'bookkeeper', 'capabilities' => ['payment.view' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($restricted);

        $body = $this->getJson('/api/pay-applications/'.$this->application->id.'/accountant-export')->assertOk()->json();
        $this->assertNull($body['snapshot']['lines'][0]['change_order_references']);
        // The dollar delta a CO contributes is not itself a change-order
        // identifier, and stays - it is already implicit in the pay
        // application's own math.
        $this->assertSame(1_000_00, $body['snapshot']['lines'][0]['approved_co_delta_cents']);

        $csv = $this->get('/api/pay-applications/'.$this->application->id.'/accountant-export?format=csv')
            ->assertOk()->getContent();
        $this->assertStringContainsString('restricted', $csv);
        $this->assertStringNotContainsString('CO-1', $csv);

        $html = $this->get('/api/pay-applications/'.$this->application->id.'/accountant-export?format=html')
            ->assertOk()->getContent();
        $this->assertStringNotContainsString('CO-1', $html);
    }
}
