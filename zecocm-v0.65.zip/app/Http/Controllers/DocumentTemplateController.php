<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\DocumentTemplate;
use App\Models\Signature;
use App\Models\TemplateAssignment;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Generic per-party document templates + signatures - the capability the
 * audit flagged as missing entirely: "adding of each party's template and
 * sign." See database/migrations/2026_08_27_090000_create_document_
 * templates_table.php for the schema rationale.
 *
 * A template is the reusable shape; an assignment is one template handed to
 * one party on one project; a signature is an immutable, polymorphic
 * attestation that a specific person signed a specific set of values at a
 * specific time. Submission (filling in values) and signing are allowed in
 * the same call here - unlike pay applications or change orders, a template
 * assignment has no separate "review" step by design (a safety plan
 * acknowledgment or a sign-in sheet is signed by the party filling it in,
 * not approved by someone else afterward) - but the hash-bind and
 * immutability rules are identical in spirit to certification elsewhere in
 * this codebase.
 */
class DocumentTemplateController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'template.view')->project;

        // A template library is either project-specific or, with
        // project_id null, reusable across every project in the tenant.
        $templates = DocumentTemplate::query()
            ->where(function ($q) use ($project) {
                $q->where('project_id', $project->id)->orWhereNull('project_id');
            })
            ->orderBy('name')->get();

        return response()->json(['templates' => $templates->map(fn (DocumentTemplate $t) => $this->templateDigest($t))]);
    }

    public function store(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'nullable|integer',
            'name' => 'required|string|max:128',
            'document_type' => 'required|string|max:64',
            'party_role' => 'nullable|string|max:64',
            'fields' => 'required|array|min:1|max:64',
            'fields.*.key' => 'required|string|max:64',
            'fields.*.label' => 'required|string|max:128',
            'fields.*.type' => 'required|in:text,textarea,checkbox,date,number',
            'fields.*.required' => 'boolean',
            'body' => 'nullable|string|max:20000',
        ]);

        $project = null;
        if (! empty($data['project_id'])) {
            $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'template.manage', write: true)->project;
        } else {
            // An org-wide template still has to be authorized against
            // *some* project the requester belongs to, so this can't be
            // used to write into a tenant the caller has no grant on at
            // all - but it is deliberately not tied to that one project.
            abort_if($request->user()->tenant_id === null && ! $request->user()->isPlatformStaff(), 403, 'A project_id is required.');
        }

        $template = DocumentTemplate::create([
            'tenant_id' => $project->tenant_id ?? $request->user()->tenant_id,
            'project_id' => $project->id ?? null,
            'name' => $data['name'], 'document_type' => $data['document_type'],
            'party_role' => $data['party_role'] ?? null, 'fields' => $data['fields'],
            'body' => $data['body'] ?? null, 'created_by' => $request->user()->id,
        ]);

        return response()->json($this->templateDigest($template), 201);
    }

    public function assignments(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'template.view')->project;

        $assignments = TemplateAssignment::query()->where('project_id', $project->id)
            ->with(['template', 'assignedTo'])->orderByDesc('id')->get();

        return response()->json(['assignments' => $assignments->map(fn (TemplateAssignment $a) => $this->assignmentDigest($a))]);
    }

    public function assign(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'required|integer',
            'document_template_id' => 'required|integer',
            'party_label' => 'required|string|max:128',
            'assigned_to_user_id' => 'nullable|integer',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'template.manage', write: true)->project;

        // A template can only be assigned within the project it belongs to,
        // or a tenant-wide (project_id null) one - never a template that
        // belongs to a different project entirely.
        $template = DocumentTemplate::query()->where('id', $data['document_template_id'])
            ->where(function ($q) use ($project) {
                $q->where('project_id', $project->id)->orWhereNull('project_id');
            })->first();
        abort_if($template === null, 422, 'That template is not available on this project.');

        $assignment = TemplateAssignment::create([
            'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
            'document_template_id' => $template->id, 'party_label' => $data['party_label'],
            'assigned_to_user_id' => $data['assigned_to_user_id'] ?? null,
            'status' => TemplateAssignment::STATUS_PENDING,
        ]);

        return response()->json($this->assignmentDigest($assignment->load('template', 'assignedTo')), 201);
    }

    public function sign(Request $request, TemplateAssignment $assignment)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), (int) $assignment->project_id, 'template.sign', write: true);
        abort_unless($assignment->status === TemplateAssignment::STATUS_PENDING, 422,
            'This assignment is already signed. Void the existing signature first if it needs to be redone.');

        $data = $request->validate([
            'values' => 'required|array',
            'signature_data' => 'nullable|array',
        ]);

        $template = $assignment->template;
        foreach ($template->fields as $field) {
            if (($field['required'] ?? false) === true) {
                $value = $data['values'][$field['key']] ?? null;
                abort_if($value === null || $value === '', 422, "The field \"{$field['label']}\" is required before this can be signed.");
            }
        }

        $contentHash = hash('sha256', json_encode([
            'template_id' => $template->id, 'assignment_id' => $assignment->id, 'values' => $data['values'],
        ]));

        DB::transaction(function () use ($assignment, $data, $request, $contentHash) {
            $assignment->forceFill(['values' => $data['values'], 'status' => TemplateAssignment::STATUS_COMPLETED, 'completed_at' => now()])->save();

            Signature::create([
                'tenant_id' => $assignment->tenant_id,
                'signable_type' => TemplateAssignment::class, 'signable_id' => $assignment->id,
                'signer_id' => $request->user()->id, 'signer_name' => $request->user()->name,
                'content_hash' => $contentHash, 'signed_at' => now(),
                'signature_data' => $data['signature_data'] ?? null,
            ]);
        });

        return response()->json($this->assignmentDigest($assignment->fresh(['template', 'assignedTo'])));
    }

    public function voidSignature(Request $request, TemplateAssignment $assignment)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        $this->access->authorize($request->user(), (int) $assignment->project_id, 'template.manage', write: true);

        $data = $request->validate(['reason' => 'required|string|max:500']);
        $active = $assignment->activeSignature();
        abort_if($active === null, 422, 'There is no active signature on this assignment to void.');

        // Void, never delete or rewrite - the signature row that existed
        // stays exactly as it was signed; only its void_at/void_reason are
        // ever touched, and the model itself refuses any other mutation.
        $active->update(['void_at' => now(), 'void_reason' => $data['reason']]);
        $assignment->forceFill(['status' => TemplateAssignment::STATUS_PENDING, 'completed_at' => null])->save();

        return response()->json($this->assignmentDigest($assignment->fresh(['template', 'assignedTo'])));
    }

    private function templateDigest(DocumentTemplate $t): array
    {
        return [
            'id' => $t->id, 'project_id' => $t->project_id, 'name' => $t->name,
            'document_type' => $t->document_type, 'party_role' => $t->party_role,
            'fields' => $t->fields, 'body' => $t->body,
        ];
    }

    private function assignmentDigest(TemplateAssignment $a): array
    {
        $active = $a->activeSignature();

        return [
            'id' => $a->id, 'project_id' => $a->project_id,
            'template_id' => $a->document_template_id, 'template_name' => $a->template?->name,
            'party_label' => $a->party_label,
            'assigned_to_user_id' => $a->assigned_to_user_id, 'assigned_to_name' => $a->assignedTo?->name,
            'status' => $a->status, 'values' => $a->values,
            'completed_at' => optional($a->completed_at)->toIso8601String(),
            'signed_by' => $active?->signer_name, 'signed_at' => optional($active?->signed_at)->toIso8601String(),
            'content_hash' => $active?->content_hash,
        ];
    }
}
