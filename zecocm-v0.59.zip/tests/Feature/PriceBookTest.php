<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\PriceBook;
use PHPUnit\Framework\TestCase;

/**
 * The back-of-house price book.
 *
 * What is being defended: a price below the loaded floor is refused by code
 * rather than noticed later. Discounting into a loss has to be somebody's
 * deliberate decision, never a number that slipped through a form.
 */
class PriceBookTest extends TestCase
{
    public function test_every_priced_tier_clears_its_own_floor(): void
    {
        // If this ever goes red, the price book is selling something at a loss
        // and the failure is the point.
        foreach (PriceBook::tiers() as $key => $tier) {
            if ($key === PriceBook::DEMO || $tier['monthly_micros'] === null) {
                continue;
            }

            $this->assertTrue(PriceBook::tier($key)['above_floor'],
                $tier['label'].' is priced below its loaded floor.');
        }
    }

    public function test_a_price_below_the_floor_is_refused_with_the_number_said_out_loud(): void
    {
        $verdict = PriceBook::mayQuote(PriceBook::PROJECT, 99_000_000);

        $this->assertFalse($verdict['allowed']);
        $this->assertStringContainsString('below the loaded floor', $verdict['reason']);
        $this->assertGreaterThan(0, $verdict['shortfall_micros']);
        // And it names the cost to serve separately, so the reader can see how
        // much of the floor is servers and how much is people.
        $this->assertStringContainsString('Cost to serve alone', $verdict['reason']);
    }

    public function test_a_price_at_exactly_the_floor_is_allowed(): void
    {
        $floor = PriceBook::floorMicros(PriceBook::FIELD);

        $this->assertTrue(PriceBook::mayQuote(PriceBook::FIELD, $floor)['allowed']);
        $this->assertFalse(PriceBook::mayQuote(PriceBook::FIELD, $floor - 1)['allowed']);
    }

    public function test_a_priced_demonstration_is_refused_as_a_category_error(): void
    {
        // Charging for the demo makes it a paid pilot, which belongs on a paid
        // tier where the floor applies to it.
        $this->assertTrue(PriceBook::mayQuote(PriceBook::DEMO, 0)['allowed']);
        $this->assertFalse(PriceBook::mayQuote(PriceBook::DEMO, 50_000_000)['allowed']);
    }

    public function test_the_cost_model_says_which_lines_are_measured_and_which_are_guesses(): void
    {
        $lines = PriceBook::costToServe(PriceBook::PROJECT);

        // Exactly one line is real today: D8 put token accounting behind it.
        $this->assertTrue($lines['model_spend']['measured']);
        $this->assertFalse($lines['support']['measured']);
        foreach ($lines as $line) {
            $this->assertNotSame('', trim($line['basis']), 'Every cost line must name its basis.');
        }
    }

    public function test_the_free_demonstration_still_costs_something_and_the_model_says_how_much(): void
    {
        // "Free" is free to the prospect, not free to Zeco. Knowing the number
        // is the difference between a marketing decision and a leak.
        $this->assertGreaterThan(0, PriceBook::costToServeMicros(PriceBook::DEMO));
    }

    public function test_the_demonstration_may_never_produce_something_that_looks_like_evidence(): void
    {
        $demo = PriceBook::demo();
        $marking = implode(' ', $demo['marking']);

        $this->assertStringContainsString('DISABLED', $marking);
        $this->assertStringContainsString('demonstration flag in the record itself', $marking);
        // And conversion discards rather than promotes.
        $this->assertStringContainsString('discards', $demo['conversion']);
    }

    public function test_the_demonstration_offers_everything_that_actually_works(): void
    {
        // The catalogue is the authority on what works. A demo tier that
        // enumerated its own list would drift from it within a week.
        $this->assertStringContainsString('operational', PriceBook::demo()['capabilities']);
        $this->assertNotSame([], array_filter(CapabilityCatalog::all(), fn ($c) => $c['operational'] ?? false));
    }

    /**
     * timesheets was found marked operational=false while TimeCardController
     * (index/store/show/approve, real time_cards migration, tenant-scoped
     * ProjectAccess authorization) was fully shipped and reachable live in
     * app.html's 'timesheets' view - the same "catalogue lying about itself"
     * class of bug that previously hid inspections and change_management.
     * This guards against the catalogue drifting back out of sync with a
     * capability that genuinely has a working controller/routes/UI behind it.
     */
    public function test_timesheets_is_marked_operational_now_that_time_card_controller_is_shipped(): void
    {
        $catalog = CapabilityCatalog::all();

        $this->assertArrayHasKey('timesheets', $catalog);
        $this->assertTrue($catalog['timesheets']['operational'] ?? false);
    }

    /**
     * trade_partners was found marked operational=true with no route, no
     * controller, and no nav view behind it - only a model and migration.
     * The opposite-direction version of the catalogue-lying bug: this guards
     * against selling something nobody can actually reach.
     */
    public function test_trade_partners_is_not_marked_operational_until_it_actually_ships(): void
    {
        $catalog = CapabilityCatalog::all();

        $this->assertArrayHasKey('trade_partners', $catalog);
        $this->assertFalse($catalog['trade_partners']['operational'] ?? true);
    }

    public function test_an_unknown_tier_is_refused_rather_than_defaulted(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        PriceBook::tier('enterprise_platinum');
    }

    public function test_margins_are_reported_over_cost_to_serve_not_over_the_floor(): void
    {
        // The two answer different questions and conflating them would flatter
        // the model. Floor asks "may we sell it"; margin asks "what does it earn".
        $tier = PriceBook::tier(PriceBook::PROJECT);
        $expected = (int) round((($tier['monthly_micros'] - $tier['cost_to_serve_micros']) / $tier['monthly_micros']) * 10_000);

        $this->assertSame($expected, $tier['gross_margin_basis_points']);
        $this->assertGreaterThan($tier['cost_to_serve_micros'], $tier['floor_micros']);
    }
}
