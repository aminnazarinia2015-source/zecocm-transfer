<?php

namespace App\Http\Controllers;

use App\Domain\Ai\ScreenContextResolver;
use App\Domain\Licensing\HelpAssistant;
use App\Domain\Licensing\PlatformAssistant;
use App\Domain\Schedule\ProjectAccess;
use App\Models\Tenant;
use Illuminate\Http\Request;

/**
 * Ask ZecoCM — the general assistant endpoint behind the floating button.
 * Free tier (no project) is answered directly by HelpAssistant — it never reads project document
 * content, so 'documents.view' does not apply to it. The licensed/project tier is delegated whole
 * to AiRunController, which owns retrieval, licensing, budget-gating, the 'documents.view' read
 * gate, and the suggestion/escalation/no_match result shape — this controller no longer duplicates
 * any of that (see TR-18 / RetrievalTraceTest::test_documents_view_is_the_only_read_gate...).
 *
 * Platform staff asking a "help" question first get a chance at PlatformAssistant, which answers
 * live cross-tenant business questions ("how many customers are active", "how many projects do
 * we have in total") from the real database — see that class's doc. It returns null for anything
 * that isn't a platform-stats question, and this always falls through to the ordinary
 * HelpAssistant in that case, so platform staff keep getting the normal free-help answers for
 * everything else. A tenant/customer user never reaches PlatformAssistant at all — gated on
 * isPlatformStaff() below, same fail-closed pattern as every other cross-tenant read in this app.
 */
class AssistController
{
    public function __construct(
        private readonly HelpAssistant $help,
        private readonly PlatformAssistant $platform,
        private readonly ProjectAccess $access,
    ) {}

    public function ask(Request $request)
    {
        $data = $request->validate([
            'question' => 'required|string|max:2000',
            'project_id' => 'nullable|integer',
            'category' => 'nullable|string|max:60',
            'mode' => 'nullable|in:help,assist',
            // TRACE-as-educator, step 1: what screen/record the caller is looking at.
            // This is untrusted client-reported state - App\Domain\Ai\ScreenContextResolver
            // is the only thing allowed to turn it into something TRACE can reference, and
            // it can only ever narrow what TRACE sees, never grant access beyond what the
            // caller's own project grant already permits.
            'screen_context' => 'nullable|array',
            'screen_context.view' => 'nullable|string|max:60',
            'screen_context.record_type' => 'nullable|string|in:rfi,submittal',
            'screen_context.record_id' => 'nullable|integer',
        ]);

        $tenant = $request->user()?->tenant_id ? Tenant::find($request->user()->tenant_id) : null;

        // FREE TIER: ZecoCM explaining itself. No project evidence is read, so this is
        // always available to every account and costs nothing to run.
        $mode = $data['mode'] ?? (empty($data['project_id']) ? 'help' : 'assist');
        if ($mode === 'help') {
            if ($request->user()?->isPlatformStaff()) {
                $platformAnswer = $this->platform->answer($data['question']);
                if ($platformAnswer !== null) {
                    return response()->json($platformAnswer);
                }
            }

            // A record reference is only resolved when a project was actually
            // named AND the caller genuinely holds a grant on it - the free
            // tier never requires a project, so an unauthorized or bogus
            // project_id here must silently fall back to "no record", never
            // a 403 that would turn the always-available help tier into
            // something gated.
            $screenContext = null;
            if (! empty($data['screen_context'])) {
                $project = null;
                if (! empty($data['project_id'])) {
                    try {
                        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'assistant.use')->project;
                    } catch (\Throwable) {
                        $project = null;
                    }
                }
                $screenContext = $project !== null
                    // Authorized on this project: the record half may resolve too.
                    ? ScreenContextResolver::resolve($data['screen_context'], $project)
                    // No project, or not authorized on the one named: the view
                    // label alone carries no access implication and is kept;
                    // any record reference is dropped rather than resolved
                    // against a project this caller was never proven to hold.
                    : (! empty($data['screen_context']['view'])
                        ? ['view' => mb_substr((string) $data['screen_context']['view'], 0, 60), 'record_type' => null, 'record_id' => null, 'record_label' => null]
                        : null);
            }

            return response()->json($this->help->answer($data['question'], $tenant, $screenContext));
        }

        // LICENSED TIER: grounded in this project's own authorised evidence.
        if (empty($data['project_id'])) {
            return response()->json([
                'kind' => 'refused',
                'reason' => 'AI project assistance answers from a specific project\'s records. Open a project first, or ask the free help assistant about how ZecoCM works.',
            ], 422);
        }

        // Paid project assistance is always queued and audited, via AiRunController — the same
        // controller that owns the real suggestion/escalation/no_match handling, retrieval,
        // licensing, and budget-gating logic. This method used to duplicate all of that inline
        // below (synchronous suggest() call, direct kind:suggestion/escalation/no_match JSON), but
        // that code was unreachable dead code sitting after this return — a request could never
        // reach it, yet it was still confusing anyone reading this file, and its
        // 'scope_searched'/'kind' response shape didn't match what AiRunController/RunGovernedAi
        // actually produce (a queued run, later polled) — a real risk if it were ever
        // accidentally un-dead-coded. Removed rather than left as a trap.
        $request->merge([
            'task_type' => 'answer',
            'idempotency_key' => $request->header('Idempotency-Key'),
        ]);
        return app(AiRunController::class)->store($request);
    }
}
