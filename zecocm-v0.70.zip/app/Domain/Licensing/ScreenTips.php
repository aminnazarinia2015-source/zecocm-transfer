<?php

namespace App\Domain\Licensing;

/**
 * TRACE-as-educator, step 1: a small, deterministic, screen-aware tip TRACE
 * can show immediately - alongside or ahead of any AI-generated answer -
 * once it knows which screen a request came from (screen_context.view).
 *
 * Costs nothing to run and cannot leak tenant data, same posture as
 * HelpAssistant: this is a static lookup keyed by the view-name vocabulary
 * public/app.html already uses in openView()/WIRED_VIEWS, not a retrieval or
 * a model call. Deliberately small - this is the first step of a much larger
 * "TRACE as educator" initiative (see the design brief), not a replacement
 * for app.html's own ASKDB dictionary. Grow it view by view as that
 * replacement actually happens, rather than trying to cover every screen now.
 */
final class ScreenTips
{
    private const TIPS = [
        'dashboard' => 'This is everything waiting on you, computed from the project\'s real records and clocks. An empty court means nothing is late in your name today.',
        'rfis' => 'Every RFI clock comes from this project\'s contract settings - the badge on each row names who is holding it and for how long.',
        'rfi-detail' => 'Read the plan-reading suggestions first (each cites the sheet and detail it came from), then write or accept a response. A plan conflict routes to the engineer instead of guessing.',
        'submittals' => 'Numbering is automatic. Attach the PDF and assign a reviewer - the review clock starts the moment it is submitted, not when someone opens it.',
        'submittal-detail' => 'The stamp you choose here is sealed with your identity and timestamp the moment you apply it, and the ball returns to whoever submitted it.',
        'scheduleintel' => 'This lines up the baseline against every uploaded update and flags date/float movement automatically - no AI judgment involved in the comparison itself.',
        'changeorders' => 'Anything that might become a change starts as a free Change Event the moment it is discovered - the notice clock starts there, not when it is priced.',
        'payapps' => 'Two clocks run here: the reviewer\'s review period, then a separate payment-term clock that only starts after approval.',
        'orgs' => 'The tree you build here is the actual routing - drag a box under whoever it reports to and that becomes how work moves.',
        'docs' => 'Everything here is sealed on upload: hashed, author- and time-bound, and never silently replaced. A correction appends a new version instead of overwriting the old one.',
        'knowledge' => 'This is what TRACE is actually allowed to cite from for this project - only verified sources in scope are retrievable.',
        'users' => 'A grant here controls exactly what a person can see and do on this project - revoking it takes effect immediately, not on next login.',
        'project' => 'The contract clocks you set here drive every deadline badge across the whole project - there is no separate per-screen default.',
    ];

    /** @return array{view: string, tip: string}|null */
    public static function forView(?string $view): ?array
    {
        if ($view === null || ! isset(self::TIPS[$view])) {
            return null;
        }

        return ['view' => $view, 'tip' => self::TIPS[$view]];
    }
}
