<?php

namespace App\Domain\Ai;

use App\Models\Project;
use App\Models\Rfi;
use App\Models\Submittal;

/**
 * TRACE-as-educator, step 1: turns the caller-supplied `screen_context` on an
 * assist request into something TRACE may actually reference.
 *
 * The one rule this class exists to enforce: screen_context can only ever
 * NARROW what TRACE can see, never grant it anything beyond what the calling
 * user's existing project authorization already permits. The view name is
 * free text describing client-side UI state and is trusted as a label only -
 * it never changes what evidence is retrieved. A record reference
 * (record_type/record_id) is trusted only after this resolver proves that
 * exact record belongs to the SAME project the caller was already
 * authorized on for this run (see ProjectAccess::authorize() in
 * AiRunController::store(), which runs before this). A record from another
 * project, another tenant, or one that does not exist at all is silently
 * dropped rather than trusted or refused - the same "narrow, never trust
 * blindly" posture RfiController::store() already applies to
 * linked_submittal_id, except ambient screen state is optional context, not
 * a request the caller must correct, so an invalid reference is ignored
 * rather than a 422.
 */
final class ScreenContextResolver
{
    /** @var array<string,class-string> */
    private const RECORD_MODELS = [
        'rfi' => Rfi::class,
        'submittal' => Submittal::class,
    ];

    /**
     * @param  array<string,mixed>|null  $raw  the validated-shape but not-yet-trusted request payload
     * @return array{view: ?string, record_type: ?string, record_id: ?int, record_label: ?string}|null
     */
    public static function resolve(?array $raw, Project $project): ?array
    {
        if ($raw === null) {
            return null;
        }

        $view = isset($raw['view']) ? mb_substr(trim((string) $raw['view']), 0, 60) : null;
        $view = $view !== '' ? $view : null;

        $recordType = isset($raw['record_type']) ? (string) $raw['record_type'] : null;
        $recordId = isset($raw['record_id']) ? (int) $raw['record_id'] : null;

        $resolvedType = null;
        $resolvedId = null;
        $recordLabel = null;

        if ($recordType !== null && $recordId !== null && isset(self::RECORD_MODELS[$recordType])) {
            $model = self::RECORD_MODELS[$recordType]::query()
                ->where('project_id', $project->id)
                ->find($recordId);

            // Belongs to a different project (or tenant, or does not exist at
            // all) - the record half of screen_context is dropped. The view
            // name is not evidence of anything and is kept regardless.
            if ($model !== null) {
                $resolvedType = $recordType;
                $resolvedId = $model->id;
                $recordLabel = $model->number ?? null;
            }
        }

        if ($view === null && $resolvedType === null) {
            return null;
        }

        return [
            'view' => $view,
            'record_type' => $resolvedType,
            'record_id' => $resolvedId,
            'record_label' => $recordLabel,
        ];
    }
}
