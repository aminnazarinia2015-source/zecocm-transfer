<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Round 12: the race a real deployment actually has that a single PHPUnit
 * process cannot reproduce by simple timing - two PHP-FPM workers handling
 * two people's near-simultaneous "raise an RFI" / "start a new pay
 * application" clicks. Both read the same max(number) before either insert
 * commits; the table's own (project_id, number) unique constraint (see
 * 2026_08_24_000008_create_rfis_table.php and
 * 2026_08_25_000024_create_pay_applications.php) then means whichever writes
 * second throws a unique-constraint violation, not a silent duplicate.
 *
 * Before RfiController::store()/PayApplicationController::store() learned to
 * retry, that throw was never caught anywhere in the stack (grep confirms
 * app/ had exactly one catch(\Illuminate\Database\QueryException) in the
 * whole codebase, in RegistrationProvisioner, unrelated to either
 * controller) - it crossed DB::transaction (for the pay application) or the
 * bare Rfi::create() call (for the RFI) uncaught, surfacing to the second,
 * entirely well-formed submitter as a raw 500. That is the worst possible
 * outcome for an honest double-click or two PMs opening "new application"
 * within the same second: the record silently did not save and the app gave
 * no explanation why.
 *
 * A real second HTTP worker cannot be spun up inside one synchronous test
 * process, so these tests reproduce the SAME race deterministically: an
 * Eloquent 'creating' listener plants a competing row - using the exact
 * number our own request is about to compute - at the moment our request's
 * own create() fires, exactly as a second worker's already-committed insert
 * would appear from this request's point of view.
 */
class ConcurrentNumberingRaceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'rfis', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'pay_apps', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    public function test_two_people_raising_an_rfi_in_the_same_instant_both_end_up_with_a_saved_rfi(): void
    {
        // A "second worker" wins the race for RFI-001 the instant our own
        // request tries to create it, then stops interfering (unshift not
        // needed - real() fires once and unregisters itself).
        $fired = false;
        Rfi::creating(function (Rfi $rfi) use (&$fired) {
            if (! $fired && $rfi->number === 'RFI-001') {
                $fired = true;
                TenantContext::set($this->tenant->id);
                \DB::table('rfis')->insert([
                    'tenant_id' => $this->tenant->id,
                    'project_id' => $this->project->id,
                    'number' => 'RFI-001',
                    'subject' => 'Beat you to it',
                    'question' => 'x',
                    'raised_by_org' => 'Other Co',
                    'raised_at' => now(),
                    'ball_in_court' => 'architect',
                    'status' => 'open',
                    'ai_dispositions' => '[]',
                    'routing_history' => '[]',
                    'created_at' => now(), 'updated_at' => now(),
                ]);
            }
        });

        $resp = $this->postJson('/api/rfis', [
            'project_id' => $this->project->id,
            'subject' => 'Second submitter',
            'question' => 'Real question',
        ]);

        $resp->assertCreated();
        $this->assertSame('RFI-002', $resp->json('number'));
        $this->assertDatabaseCount('rfis', 2);
        $this->assertDatabaseHas('rfis', ['number' => 'RFI-001', 'subject' => 'Beat you to it']);
        $this->assertDatabaseHas('rfis', ['number' => 'RFI-002', 'subject' => 'Second submitter']);
    }

    public function test_a_pay_application_creation_that_collides_with_a_concurrent_writer_retries_instead_of_500ing(): void
    {
        // Unlike the RFI controller, pay-application creation carries on inside
        // one DB::transaction (it also seeds a schedule-of-values line per
        // item) - a competing insert made through the SAME connection while
        // that transaction is open would itself be rolled back the instant our
        // own insert collides with it, which would prove nothing about a real
        // second, already-committed worker's row. So here the second worker's
        // effect is reproduced directly, the way it actually reaches this
        // code: PayApplication::create() throwing the exact exception class
        // Postgres/MySQL/SQLite all normalize a duplicate-key insert to,
        // exactly once, on the number the controller was about to use.
        $fired = false;
        PayApplication::creating(function (PayApplication $app) use (&$fired) {
            if (! $fired && (int) $app->number === 1) {
                $fired = true;
                throw new \Illuminate\Database\UniqueConstraintViolationException(
                    'sqlite',
                    'insert into "pay_applications" ...',
                    [],
                    new \PDOException('UNIQUE constraint failed: pay_applications.project_id, pay_applications.number')
                );
            }
        });

        $resp = $this->postJson('/api/pay-applications', [
            'project_id' => $this->project->id,
            'period_from' => now()->toDateString(),
            'period_to' => now()->toDateString(),
        ]);

        $resp->assertCreated();
        $this->assertSame(1, $resp->json('application.number'));
        $this->assertDatabaseCount('pay_applications', 1);
        $this->assertDatabaseHas('pay_applications', ['project_id' => $this->project->id, 'number' => 1]);
    }
}
