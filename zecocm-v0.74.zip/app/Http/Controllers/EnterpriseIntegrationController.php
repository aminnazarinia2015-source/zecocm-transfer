<?php

namespace App\Http\Controllers;

use App\Domain\Innovation\InnovationCapabilityCatalog;
use App\Domain\Integrations\EnterpriseProviderCatalog;
use App\Domain\Integrations\AccountingIntegrationEngine;
use App\Models\IntegrationConnection;
use App\Models\IntegrationExchangeItem;
use App\Models\IntegrationFieldMapping;
use App\Models\IntegrationReconciliationFinding;
use App\Models\IntegrationOauthState;
use App\Models\TenantIntegrationConfiguration;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class EnterpriseIntegrationController
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_if($user->tenant_id === null, 403, 'Open a customer account to view its integration marketplace.');
        $configured = TenantIntegrationConfiguration::query()->get()->keyBy('provider');
        $connections = IntegrationConnection::query()->get()->groupBy('provider');

        return response()->json([
            'can_manage' => $user->isTenantAdministrator(),
            'providers' => collect(EnterpriseProviderCatalog::all())->map(function (array $provider, string $key) use ($configured, $connections) {
                $configuration = $configured->get($key);
                $providerConnections = $connections->get($key, collect());
                $connected = $providerConnections->firstWhere('status', 'connected');
                $authorized = $providerConnections->firstWhere('status', 'authorized');
                $connection = $connected ?? $authorized ?? $providerConnections->first();

                return [
                    'key' => $key,
                    'label' => $provider['label'],
                    'category' => $provider['category'],
                    'authorization' => $provider['authorization'],
                    'required_fields' => $provider['fields'],
                    'capabilities' => $provider['capabilities'],
                    'adapter_state' => $provider['adapter_state'],
                    'configuration_state' => $configuration?->status ?? 'not_configured',
                    'environment' => $configuration?->environment,
                    'validated_at' => $configuration?->validated_at?->toIso8601String(),
                    'connection_state' => $connected ? 'connected' : ($authorized ? 'provider_authorized_account_selection_required' : ($providerConnections->isNotEmpty() ? 'authorization_pending' : 'not_connected')),
                    'connected_account' => ($connected ?? $authorized)?->external_account_name,
                    'health' => $connection?->publicHealth() ?? ['state' => 'disconnected', 'color' => 'red', 'label' => 'Disconnected', 'live' => false, 'detail' => 'No provider account is connected.'],
                    'last_successful_transfer_at' => $connection?->last_successful_transfer_at?->toIso8601String(),
                    'operating_model' => EnterpriseProviderCatalog::operatingModel($key),
                ];
            })->values(),
            'capability_groups' => [
                ['key' => 'drawing_coordination', 'label' => 'Drawing viewing, markup, comparison & coordination', 'state' => 'zecocm_core_available'],
                ['key' => 'financial_management', 'label' => 'Financial management & accounting exchange', 'state' => 'core_available_connectors_configurable'],
                ['key' => 'integration_marketplace', 'label' => 'Integration marketplace & custom connector framework', 'state' => 'available'],
                ['key' => 'portfolio_enterprise', 'label' => 'Portfolio reporting & enterprise administration', 'state' => 'foundation_available_enhancement_required'],
                ['key' => 'identity_lifecycle', 'label' => 'SSO, SCIM & identity lifecycle', 'state' => 'configuration_ready_provider_adapter_required'],
                ['key' => 'mobile_offline', 'label' => 'Mobile/PWA & offline field resilience', 'state' => 'enhancement_required'],
                ['key' => 'independent_acceptance', 'label' => 'Real-user adoption & independent acceptance evidence', 'state' => 'external_evidence_required'],
            ],
            'notice' => 'Green is reserved for a verified provider account with a recent successful transfer. Configuration and OAuth authorization alone remain amber; disconnected or failing connections are red.',
            'innovation_capabilities' => InnovationCapabilityCatalog::all(),
        ]);
    }

    public function accountingWorkspace(Request $request, string $provider)
    {
        $definition = EnterpriseProviderCatalog::get($provider);
        abort_if(($definition['category'] ?? null) !== 'accounting_erp', 404, 'Accounting provider not found.');
        $connection = IntegrationConnection::query()->where('provider', $provider)->first();

        return response()->json([
            'provider' => $provider,
            'operating_model' => EnterpriseProviderCatalog::operatingModel($provider),
            'connection' => $connection ? ['id' => $connection->id, 'status' => $connection->status, 'account' => $connection->external_account_name, 'last_synced_at' => $connection->last_synced_at, 'last_successful_transfer_at' => $connection->last_successful_transfer_at, 'health' => $connection->publicHealth()] : null,
            'mappings' => $connection ? IntegrationFieldMapping::query()->where('integration_connection_id', $connection->id)->orderBy('object_type')->get() : [],
            'exchange_queue' => $connection ? IntegrationExchangeItem::query()->where('integration_connection_id', $connection->id)->latest()->limit(100)->get() : [],
            'reconciliation_findings' => $connection ? IntegrationReconciliationFinding::query()->where('integration_connection_id', $connection->id)->where('status', 'open')->latest()->limit(100)->get() : [],
            'can_manage' => $request->user()->isTenantAdministrator(),
            'notice' => 'Financial posting requires a completed dry run and explicit administrator approval. Provider execution remains disabled until its transaction adapter passes sandbox validation.',
        ]);
    }

    public function saveMappings(Request $request, string $provider, AccountingIntegrationEngine $engine)
    {
        $this->authorizeAdmin($request);
        $connection = $this->accountingConnection($provider);
        $data = $request->validate(['mappings' => 'required|array|min:1|max:250', 'mappings.*.object_type' => 'required|string|max:48', 'mappings.*.direction' => ['required', Rule::in(['inbound', 'outbound'])], 'mappings.*.source_field' => 'required|string|max:128', 'mappings.*.target_field' => 'required|string|max:128', 'mappings.*.required' => 'sometimes|boolean', 'mappings.*.transform' => 'sometimes|nullable|array']);
        $count = $engine->saveMappings($connection, $data['mappings'], $request->user()->id);
        return response()->json(['message' => "{$count} approved mapping(s) saved.", 'count' => $count]);
    }

    public function dryRun(Request $request, string $provider, AccountingIntegrationEngine $engine)
    {
        $this->authorizeAdmin($request);
        $connection = $this->accountingConnection($provider);
        $data = $request->validate(['direction' => ['required', Rule::in(['inbound', 'outbound'])], 'object_type' => 'required|string|max:48', 'records' => 'required|array|min:1|max:500', 'records.*' => 'required|array']);
        $items = $engine->dryRun($connection, $data['direction'], $data['object_type'], $data['records']);
        return response()->json(['message' => count($items).' item(s) prepared without posting to the provider.', 'items' => $items], 201);
    }

    public function approveExchange(Request $request, string $provider, IntegrationExchangeItem $item, AccountingIntegrationEngine $engine)
    {
        $this->authorizeAdmin($request);
        $connection = $this->accountingConnection($provider);
        abort_unless($item->integration_connection_id === $connection->id, 404, 'Exchange item not found for this provider connection.');
        return response()->json(['message' => 'Exchange item approved. Provider posting still requires an installed, sandbox-validated transaction adapter.', 'item' => $engine->approve($item, $request->user()->id)]);
    }

    public function reconcile(Request $request, string $provider, AccountingIntegrationEngine $engine)
    {
        $this->authorizeAdmin($request);
        $connection = $this->accountingConnection($provider);
        $data = $request->validate(['object_type' => 'required|string|max:48', 'pairs' => 'required|array|min:1|max:1000', 'pairs.*.local_amount' => 'required|numeric', 'pairs.*.external_amount' => 'required|numeric', 'pairs.*.local_reference' => 'nullable|string|max:255', 'pairs.*.external_reference' => 'nullable|string|max:255']);
        $findings = $engine->reconcile($connection, $data['object_type'], $data['pairs']);
        return response()->json(['message' => count($findings).' variance finding(s) created.', 'findings' => $findings]);
    }

    public function configure(Request $request, string $provider)
    {
        $this->authorizeAdmin($request);
        $definition = EnterpriseProviderCatalog::get($provider);
        abort_if($definition === null, 404, 'Unknown integration provider.');
        $data = $request->validate([
            'environment' => ['required', Rule::in(['sandbox', 'production'])],
            'credentials' => 'required|array',
            'credentials.*' => 'nullable|string|max:8192',
            'settings' => 'sometimes|array|max:30',
        ]);
        $credentials = Arr::only($data['credentials'], $definition['fields']);
        $missing = array_values(array_filter($definition['fields'], fn (string $field) => trim((string) ($credentials[$field] ?? '')) === ''));
        if ($missing !== []) {
            return response()->json(['message' => 'Complete every required provider field.', 'missing_fields' => $missing], 422);
        }
        foreach ($credentials as $field => $value) {
            if ((str_ends_with($field, '_url') || str_ends_with($field, '_uri'))
                && (! filter_var($value, FILTER_VALIDATE_URL) || strtolower((string) parse_url($value, PHP_URL_SCHEME)) !== 'https')) {
                return response()->json(['message' => $field.' must be a valid HTTPS URL.'], 422);
            }
        }
        if ($provider === 'zoho_books' && ! in_array(strtolower($credentials['data_center']), ['com', 'eu', 'in', 'com.au', 'au', 'jp', 'ca'], true)) {
            return response()->json(['message' => 'Select a supported Zoho data center.'], 422);
        }

        $configuration = TenantIntegrationConfiguration::query()->firstOrNew([
            'tenant_id' => $request->user()->tenant_id, 'provider' => $provider,
        ]);
        $configuration->fill([
            'environment' => $data['environment'], 'status' => 'configured',
            'settings' => $data['settings'] ?? [], 'validated_at' => null,
            'validation_summary' => 'Credentials stored; provider authorization and adapter validation remain pending.',
            'configured_by' => $request->user()->id,
        ]);
        $configuration->setCredentials($credentials);
        $configuration->save();

        return response()->json([
            'message' => 'Provider configuration encrypted and saved. This does not represent a connected account.',
            'provider' => $provider, 'configuration_state' => 'configured', 'environment' => $configuration->environment,
        ]);
    }

    public function destroy(Request $request, string $provider)
    {
        $this->authorizeAdmin($request);
        abort_if(EnterpriseProviderCatalog::get($provider) === null, 404, 'Unknown integration provider.');
        TenantIntegrationConfiguration::query()->where('provider', $provider)->delete();

        return response()->json(['message' => 'Stored provider configuration removed. Existing provider-side authorization must also be revoked.']);
    }

    public function beginAuthorization(Request $request, string $provider)
    {
        $this->authorizeAdmin($request);
        $configuration = TenantIntegrationConfiguration::query()->where('provider', $provider)->firstOrFail();
        $credentials = $configuration->credentials();
        $oauth = EnterpriseProviderCatalog::oauth($provider, $credentials);
        abort_if($oauth === null, 409, 'This provider is listed, but its live authorization adapter is not installed yet.');
        $state = Str::random(64);
        IntegrationOauthState::query()->create([
            'tenant_id' => $request->user()->tenant_id, 'user_id' => $request->user()->id,
            'provider' => $provider, 'state_hash' => hash('sha256', $state), 'expires_at' => now()->addMinutes(10),
        ]);
        $parameters = array_merge([
            'client_id' => $credentials['client_id'], 'redirect_uri' => $credentials['redirect_uri'],
            'response_type' => 'code', 'scope' => implode(' ', $oauth['scopes']), 'state' => $state,
        ], $oauth['extra_authorize']);

        return response()->json([
            'authorization_url' => $oauth['authorization_url'].'?'.http_build_query($parameters, '', '&', PHP_QUERY_RFC3986),
            'expires_in_seconds' => 600,
            'notice' => 'The provider will authenticate the customer directly. ZecoCM never receives the provider password.',
        ]);
    }

    public function callback(Request $request, string $provider)
    {
        $data = $request->validate(['state' => 'required|string|max:256', 'code' => 'required|string|max:4096']);
        $state = DB::transaction(function () use ($data, $provider) {
            $record = IntegrationOauthState::query()->where('state_hash', hash('sha256', $data['state']))
                ->where('provider', $provider)->lockForUpdate()->first();
            abort_if($record === null || $record->used_at !== null || $record->expires_at->isPast(), 403,
                'The provider authorization state is invalid, expired, or already used.');
            $record->update(['used_at' => now()]);
            return $record;
        });
        $configuration = TenantIntegrationConfiguration::withoutGlobalScopes()->where('tenant_id', $state->tenant_id)
            ->where('provider', $provider)->firstOrFail();
        $credentials = $configuration->credentials();
        $oauth = EnterpriseProviderCatalog::oauth($provider, $credentials);
        abort_if($oauth === null, 409, 'Provider authorization adapter is unavailable.');
        $payload = [
            'grant_type' => 'authorization_code', 'code' => $data['code'],
            'redirect_uri' => $credentials['redirect_uri'],
        ];
        $client = Http::asForm()->acceptJson()->timeout(20)->retry(2, 250, throw: false);
        if ($oauth['client_auth'] === 'basic') {
            $client = $client->withBasicAuth($credentials['client_id'], $credentials['client_secret']);
        } else {
            $payload += ['client_id' => $credentials['client_id'], 'client_secret' => $credentials['client_secret']];
        }
        $tokenResponse = $client->post($oauth['token_url'], $payload);
        if (! $tokenResponse->successful() || ! is_string($tokenResponse->json('access_token'))) {
            $configuration->update(['status' => 'authorization_failed', 'validation_summary' => 'Provider token exchange failed; no account was connected.']);
            return redirect('/app.html#enterprise-integration=authorization_failed');
        }
        $expiresIn = max(60, (int) $tokenResponse->json('expires_in', 3600));
        $realm = $provider === 'quickbooks_online' ? (string) $request->query('realmId', '') : '';
        $connection = IntegrationConnection::withoutGlobalScopes()->firstOrNew([
            'tenant_id' => $state->tenant_id, 'project_id' => null, 'provider' => $provider,
        ]);
        $connection->fill([
            'status' => $realm !== '' ? 'connected' : 'authorized',
            'external_account_id' => $realm !== '' ? $realm : null,
            'external_account_name' => $realm !== '' ? 'QuickBooks company '.$realm : 'Provider authorization completed; select an organization',
            'scopes' => preg_split('/\s+/', trim((string) $tokenResponse->json('scope', implode(' ', $oauth['scopes'])))) ?: [],
            'token_expires_at' => now()->addSeconds($expiresIn), 'authorized_by' => $state->user_id,
            'last_verified_at' => $realm !== '' ? now() : null,
            'last_health_check_at' => now(),
        ]);
        $refreshToken = $tokenResponse->json('refresh_token');
        $connection->setTokens($tokenResponse->json('access_token'), is_string($refreshToken) ? $refreshToken : null);
        $connection->save();
        $configuration->update([
            'status' => $connection->status === 'connected' ? 'connected' : 'authorized',
            'validated_at' => now(), 'validation_summary' => $connection->status === 'connected'
                ? 'Provider OAuth completed and an external account was identified.'
                : 'Provider OAuth completed; external organization selection remains required.',
        ]);

        return redirect('/app.html#enterprise-integration='.$connection->status);
    }

    private function authorizeAdmin(Request $request): void
    {
        abort_unless($request->user()?->isTenantAdministrator(), 403,
            'Only the organization account administrator can configure provider applications.');
    }

    private function accountingConnection(string $provider): IntegrationConnection
    {
        $definition = EnterpriseProviderCatalog::get($provider);
        abort_if(($definition['category'] ?? null) !== 'accounting_erp', 404, 'Accounting provider not found.');
        return IntegrationConnection::query()->where('provider', $provider)->firstOrFail();
    }
}
