<?php

namespace App\Domain\Innovation;

/**
 * Product truth register for advanced capabilities. A catalogue entry is not
 * an entitlement and never makes an unfinished workflow available. Promotion
 * to operational requires every proof gate to be retained as release evidence.
 */
final class InnovationCapabilityCatalog
{
    /** @return array<int,array<string,mixed>> */
    public static function all(): array
    {
        return [
            self::item('offline_crdt', 'Offline convergence engine', 'designed',
                'Encrypted local field records converge without losing concurrent draft edits.',
                ['daily-log drafts', 'punch observations', 'inspection answers', 'drawing annotations'],
                ['signatures', 'approvals', 'payment actions', 'formal responses'],
                ['algebraic merge tests', '14-day offline soak', 'device revocation', 'attachment retry', 'cross-tenant wipe verification']),
            self::item('scope_drift_radar', 'Scope Drift Radar', 'foundation_available',
                'Continuously correlate governed drawing/specification changes with schedule, cost and field evidence.',
                ['detect cited changes', 'identify affected activities', 'draft an RFI or notice', 'show sourced exposure ranges'],
                ['declare causation', 'invent cost', 'issue correspondence', 'direct field work'],
                ['geometry-diff validation', 'citation precision benchmark', 'cost-basis traceability', 'false-positive pilot threshold']),
            self::item('decision_twin', 'Proof-carrying Decision Twin', 'foundation_available',
                'Preview deterministic schedule, budget and notice consequences before a consequential seal.',
                ['run CPM scenarios', 'calculate allowance effects', 'surface applicable notice clocks', 'preserve assumptions'],
                ['approve the decision', 'certify legal compliance', 'convert uncertain causation into fact'],
                ['golden scenario suite', 'baseline isolation', 'calculation reproducibility', 'human sign-off pilot']),
            self::item('dispute_packet', 'Continuous dispute-readiness packet', 'foundation_available',
                'Assemble a scoped chronology with source versions, custody, hashes and timely-notice evidence.',
                ['assemble evidence-ready PDF/A and machine manifest', 'verify hashes', 'show gaps and contradictions'],
                ['promise admissibility', 'call an export judge-ready', 'omit adverse evidence silently'],
                ['PDF/A validation', 'independent hash verification', 'counsel review', 'redaction and privilege testing']),
            self::item('spatial_reality', 'Spatial reality-to-record sync', 'designed',
                'Anchor photos, 360 capture and future LiDAR meshes to sheets, locations, activities and SOV lines.',
                ['flag unsupported progress', 'compare cited captures', 'propose quantity-review targets'],
                ['certify installed quantity from imagery alone', 'release payment', 'hide uncertainty'],
                ['camera calibration', 'location accuracy', 'model registration benchmark', 'quantity-review field pilot']),
            self::item('multiparty_privacy', 'Multi-party confidential collaboration', 'designed',
                'Share one governed project context while separating private financial and draft material.',
                ['field-level encryption', 'purpose grants', 'selective disclosure', 'narrow zero-knowledge assertions'],
                ['claim universal zero knowledge', 'leak metadata across parties', 'bypass discovery or hold policy'],
                ['formal threat model', 'cryptographic review', 'collusion tests', 'key rotation and recovery drill']),
            self::item('universal_clients', 'Universal web, desktop and field clients', 'designed',
                'Use one evidence protocol across web, Windows/macOS and iOS/Android with platform-native secure storage.',
                ['responsive review', 'desktop bulk processing', 'offline field capture', 'sync health receipts'],
                ['equate a web wrapper with offline readiness', 'store unencrypted tenant data', 'seal while authority is stale'],
                ['Windows/macOS/iOS/Android matrix', 'accessibility', 'background sync', 'lost-device response']),
            self::item('notice_autopilot', 'Notice Preservation Autopilot', 'foundation_available',
                'Detect supported notice triggers, calculate candidate deadlines and prepare cited drafts for an authorized person.',
                ['identify possible triggers', 'calculate from confirmed clauses', 'assemble evidence', 'draft and route'],
                ['give legal advice', 'serve notice autonomously', 'assume an uncited clause applies', 'waive rights'],
                ['clause/date golden set', 'jurisdiction review', 'service receipt verification', 'attorney and contractor pilot']),
        ];
    }

    private static function item(string $key, string $label, string $stage, string $outcome, array $traceMay, array $traceMustNot, array $proofGates): array
    {
        return compact('key', 'label', 'stage', 'outcome', 'traceMay', 'traceMustNot', 'proofGates') + [
            'operational' => false,
            'stage_label' => match ($stage) {
                'foundation_available' => 'Foundation built — workflow validation required',
                default => 'Designed — implementation required',
            },
        ];
    }
}
