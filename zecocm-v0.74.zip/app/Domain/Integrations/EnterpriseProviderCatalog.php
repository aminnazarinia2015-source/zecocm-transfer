<?php

namespace App\Domain\Integrations;

final class EnterpriseProviderCatalog
{
    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        return [
            'autodesk' => self::p('Autodesk Construction Cloud / APS', 'drawings_bim', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['drawings', 'models', 'issues', 'files', 'webhooks']),
            'procore' => self::p('Procore', 'construction_platforms', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['projects', 'drawings', 'documents', 'rfis', 'submittals', 'financials']),
            'bluebeam' => self::p('Bluebeam', 'drawings_bim', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['pdf_documents', 'studio_sessions', 'markups']),
            'bentley_itwin' => self::p('Bentley iTwin', 'drawings_bim', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['models', 'digital_twins', 'issues']),
            'trimble_connect' => self::p('Trimble Connect', 'drawings_bim', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['models', 'files', 'coordination']),
            'esri_arcgis' => self::p('Esri ArcGIS', 'drawings_bim', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['maps', 'features', 'field_assets']),
            'quickbooks_online' => self::p('QuickBooks Online', 'accounting_erp', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['vendors', 'customers', 'commitments', 'invoices', 'payments'], 'oauth_adapter_available'),
            'zoho_books' => self::p('Zoho Books', 'accounting_erp', 'oauth2', ['data_center', 'client_id', 'client_secret', 'redirect_uri'], ['contacts', 'projects', 'purchase_orders', 'invoices', 'payments'], 'oauth_adapter_available'),
            'xero' => self::p('Xero', 'accounting_erp', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['contacts', 'projects', 'purchase_orders', 'invoices', 'payments'], 'oauth_adapter_available'),
            'freshbooks' => self::p('FreshBooks', 'accounting_erp', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['clients', 'projects', 'expenses', 'invoices', 'payments']),
            'sage_intacct' => self::p('Sage Intacct', 'accounting_erp', 'api_credentials', ['company_id', 'sender_id', 'sender_password', 'user_id', 'user_password'], ['jobs', 'cost_codes', 'commitments', 'invoices', 'payments']),
            'sage_300_cre' => self::p('Sage 300 Construction and Real Estate', 'accounting_erp', 'connector', ['connector_url', 'client_id', 'client_secret'], ['jobs', 'job_cost', 'vendors', 'contracts']),
            'viewpoint_vista' => self::p('Trimble Viewpoint Vista', 'accounting_erp', 'api_credentials', ['base_url', 'client_id', 'client_secret'], ['jobs', 'job_cost', 'payables', 'payroll']),
            'cmic' => self::p('CMiC', 'accounting_erp', 'oauth2', ['base_url', 'client_id', 'client_secret', 'redirect_uri'], ['projects', 'costs', 'contracts', 'payables']),
            'oracle_netsuite' => self::p('Oracle NetSuite', 'accounting_erp', 'oauth2', ['account_id', 'client_id', 'client_secret', 'redirect_uri'], ['projects', 'vendors', 'purchase_orders', 'invoices']),
            'microsoft_dynamics' => self::p('Microsoft Dynamics 365', 'accounting_erp', 'oauth2', ['tenant_id', 'client_id', 'client_secret', 'redirect_uri'], ['projects', 'finance', 'vendors', 'invoices']),
            'sap' => self::p('SAP S/4HANA', 'accounting_erp', 'oauth2', ['base_url', 'client_id', 'client_secret', 'token_url'], ['projects', 'costs', 'procurement', 'payments']),
            'primavera_p6' => self::p('Oracle Primavera P6', 'scheduling', 'api_credentials', ['base_url', 'username', 'password'], ['projects', 'wbs', 'activities', 'relationships', 'baselines']),
            'microsoft_project' => self::p('Microsoft Project / Project Online', 'scheduling', 'oauth2', ['tenant_id', 'client_id', 'client_secret', 'redirect_uri'], ['projects', 'tasks', 'resources']),
            'microsoft365' => self::p('Microsoft 365 / SharePoint / OneDrive', 'documents_productivity', 'oauth2', ['tenant_id', 'client_id', 'client_secret', 'redirect_uri'], ['files', 'folders', 'permissions', 'webhooks']),
            'google_workspace' => self::p('Google Workspace / Drive', 'documents_productivity', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['files', 'folders', 'permissions']),
            'box' => self::p('Box', 'documents_productivity', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['files', 'folders', 'collaboration']),
            'dropbox' => self::p('Dropbox', 'documents_productivity', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['files', 'folders', 'webhooks']),
            'docusign' => self::p('DocuSign', 'documents_productivity', 'oauth2', ['integration_key', 'client_secret', 'redirect_uri'], ['envelopes', 'signatures', 'templates']),
            'microsoft_entra' => self::p('Microsoft Entra ID', 'identity_security', 'oidc_scim', ['tenant_id', 'client_id', 'client_secret', 'redirect_uri'], ['sso', 'mfa_policy', 'group_claims', 'scim']),
            'okta' => self::p('Okta', 'identity_security', 'oidc_scim', ['issuer_url', 'client_id', 'client_secret', 'redirect_uri'], ['sso', 'mfa_policy', 'groups', 'scim']),
            'auth0' => self::p('Auth0', 'identity_security', 'oidc', ['domain', 'client_id', 'client_secret', 'redirect_uri'], ['sso', 'mfa_policy', 'organizations']),
            'onelogin' => self::p('OneLogin', 'identity_security', 'oidc_scim', ['issuer_url', 'client_id', 'client_secret', 'redirect_uri'], ['sso', 'groups', 'scim']),
            'openspace' => self::p('OpenSpace', 'field_reality_capture', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['captures', 'locations', 'issues']),
            'dronedeploy' => self::p('DroneDeploy', 'field_reality_capture', 'oauth2', ['client_id', 'client_secret', 'redirect_uri'], ['maps', 'photos', 'progress']),
            'earthcam' => self::p('EarthCam', 'field_reality_capture', 'api_credentials', ['account_id', 'api_key'], ['cameras', 'images', 'timelapse']),
            'generic_rest' => self::p('Custom REST API', 'developer_platform', 'api_credentials', ['base_url', 'authentication_type', 'credential'], ['versioned_api', 'mapping', 'sync', 'health_check']),
            'generic_webhook' => self::p('Custom Webhook', 'developer_platform', 'webhook', ['endpoint_url', 'signing_secret'], ['outbound_events', 'delivery_retries', 'signatures']),
            'sftp_exchange' => self::p('SFTP Data Exchange', 'developer_platform', 'sftp', ['host', 'port', 'username', 'private_key'], ['scheduled_import', 'scheduled_export', 'receipts']),
        ];
    }

    public static function get(string $key): ?array
    {
        return self::all()[$key] ?? null;
    }

    public static function operatingModel(string $key): ?array
    {
        $provider = self::get($key);
        if (($provider['category'] ?? null) !== 'accounting_erp') {
            return null;
        }

        return [
            'purpose' => 'Exchange approved construction financial records with the customer accounting system while preserving approval, source ownership, idempotency, and audit evidence.',
            'inbound' => [
                ['object' => 'vendors_customers', 'system_of_record' => 'accounting', 'use' => 'Match authorized business parties without duplicating accounting masters.'],
                ['object' => 'chart_of_accounts_cost_codes', 'system_of_record' => 'accounting', 'use' => 'Map ZecoCM project cost structures to posting accounts.'],
                ['object' => 'actual_costs_bills_payments', 'system_of_record' => 'accounting', 'use' => 'Reconcile committed, billed, paid, and remaining values.'],
                ['object' => 'payroll_summary', 'system_of_record' => 'accounting', 'use' => 'Support cost and certified-payroll exception review without moving bank data.'],
            ],
            'outbound' => [
                ['object' => 'approved_commitments_purchase_orders', 'approval_required' => true],
                ['object' => 'approved_change_orders', 'approval_required' => true],
                ['object' => 'approved_pay_applications_invoices', 'approval_required' => true],
                ['object' => 'retainage_release', 'approval_required' => true],
            ],
            'controls' => ['dry_run', 'explicit_posting_approval', 'idempotency', 'field_mapping_approval', 'immutable_sync_history', 'variance_reconciliation', 'safe_retry', 'tenant_isolation'],
            'trace' => [
                'may' => ['recommend mappings', 'explain errors', 'identify the affected record', 'reconcile totals', 'retry transient failures', 'alert on expired authorization'],
                'must_not_without_approval' => ['post financial transactions', 'create vendors', 'change bank details', 'release payments', 'overwrite accounting records'],
            ],
        ];
    }

    public static function oauth(string $key, array $credentials): ?array
    {
        return match ($key) {
            'quickbooks_online' => [
                'authorization_url' => 'https://appcenter.intuit.com/connect/oauth2',
                'token_url' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
                'scopes' => ['com.intuit.quickbooks.accounting', 'openid', 'profile', 'email'],
                'client_auth' => 'basic', 'extra_authorize' => [],
            ],
            'zoho_books' => [
                'authorization_url' => 'https://accounts.zoho.'.self::zohoSuffix($credentials['data_center'] ?? 'com').'/oauth/v2/auth',
                'token_url' => 'https://accounts.zoho.'.self::zohoSuffix($credentials['data_center'] ?? 'com').'/oauth/v2/token',
                'scopes' => ['ZohoBooks.fullaccess.all'], 'client_auth' => 'body',
                'extra_authorize' => ['access_type' => 'offline', 'prompt' => 'consent'],
            ],
            'xero' => [
                'authorization_url' => 'https://login.xero.com/identity/connect/authorize',
                'token_url' => 'https://identity.xero.com/connect/token',
                'scopes' => ['openid', 'profile', 'email', 'accounting.transactions', 'accounting.contacts', 'offline_access'],
                'client_auth' => 'basic', 'extra_authorize' => [],
            ],
            default => null,
        };
    }

    private static function p(string $label, string $category, string $authorization, array $fields, array $capabilities, ?string $adapterState = null): array
    {
        return compact('label', 'category', 'authorization', 'fields', 'capabilities') + [
            'adapter_state' => $adapterState ?? (in_array($label, ['Custom REST API', 'Custom Webhook', 'SFTP Data Exchange'], true)
                ? 'connector_framework_ready' : 'provider_adapter_required'),
        ];
    }

    private static function zohoSuffix(string $dataCenter): string
    {
        return match (strtolower(trim($dataCenter))) {
            'eu' => 'eu', 'in' => 'in', 'com.au', 'au' => 'com.au', 'jp' => 'jp', 'ca' => 'ca', default => 'com',
        };
    }
}
