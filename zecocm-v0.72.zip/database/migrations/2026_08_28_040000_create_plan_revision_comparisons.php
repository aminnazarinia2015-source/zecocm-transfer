<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('plan_revision_comparisons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_id')->constrained()->restrictOnDelete();
            $table->foreignId('from_plan_sheet_version_id')->constrained('plan_sheet_versions')->restrictOnDelete();
            $table->foreignId('to_plan_sheet_version_id')->constrained('plan_sheet_versions')->restrictOnDelete();
            $table->string('status', 32);
            $table->string('comparison_basis', 48);
            $table->string('from_sha256', 64);
            $table->string('to_sha256', 64);
            $table->json('result');
            $table->string('result_sha256', 64);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(
                ['plan_sheet_id', 'from_plan_sheet_version_id', 'to_plan_sheet_version_id'],
                'plan_comparison_unique_pair'
            );
            $table->index(['tenant_id', 'project_id', 'plan_sheet_id'], 'plan_comparison_scope_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plan_revision_comparisons');
    }
};
