<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Self-initiated feature: ZecoCM-hosted subdomains (acme.zecocm.com) and
 * client-owned custom domains (cm.acmecorp.com), both resolving to a tenant
 * and swapping platform branding for the tenant's own - see
 * App\Http\Middleware\ResolveTenantDomain for the resolution rule and
 * App\Http\Controllers\TenantDomainController for custom-domain verification.
 *
 * `logo_path` already exists (2026_08_24_000012_add_profile_media_columns.php)
 * so tenant branding for the resolved-domain flow reuses it rather than
 * adding a second logo column.
 *
 * A custom domain is never trusted just because a tenant typed it in - ZecoCM
 * does not own that DNS. `custom_domain_verification_token` is generated on
 * submission and `custom_domain_verified_at` is set ONLY after a live DNS TXT
 * lookup finds it (TenantDomainController::verify). The resolution middleware
 * checks verified_at, never custom_domain alone.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            // Lowercase slug, e.g. "acme" for acme.zecocm.com. Nullable/unique:
            // most tenants (portals, internal accounts) never get one.
            $table->string('subdomain')->nullable()->unique()->after('legal_name');
            $table->string('custom_domain')->nullable()->unique()->after('subdomain');
            $table->string('custom_domain_verification_token')->nullable()->after('custom_domain');
            $table->timestamp('custom_domain_verified_at')->nullable()->after('custom_domain_verification_token');
        });
    }

    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn([
                'subdomain', 'custom_domain', 'custom_domain_verification_token', 'custom_domain_verified_at',
            ]);
        });
    }
};
