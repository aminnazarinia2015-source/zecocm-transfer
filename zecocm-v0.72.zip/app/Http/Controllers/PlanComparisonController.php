<?php

namespace App\Http\Controllers;

use App\Domain\Plans\PlanRevisionComparator;
use App\Domain\Schedule\ProjectAccess;
use App\Models\PlanRevisionComparison;
use App\Models\PlanSheet;
use App\Models\PlanSheetVersion;
use App\Models\Project;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PlanComparisonController
{
    public function __construct(
        private readonly ProjectAccess $access,
        private readonly PlanRevisionComparator $comparator,
    ) {}

    public function store(Request $request, PlanSheet $sheet)
    {
        $this->writesAllowed();
        $data = $request->validate([
            'from_version_id' => 'required|integer|different:to_version_id',
            'to_version_id' => 'required|integer',
        ]);
        $this->access->authorize($request->user(), (int) $sheet->project_id, 'plans.compare', write: true);
        $this->access->authorize($request->user(), (int) $sheet->project_id, 'documents.view');

        $comparison = DB::transaction(function () use ($sheet, $data, $request) {
            $locked = PlanSheet::query()->lockForUpdate()->findOrFail($sheet->id);
            $from = PlanSheetVersion::query()->where('plan_sheet_id', $locked->id)->find($data['from_version_id']);
            $to = PlanSheetVersion::query()->where('plan_sheet_id', $locked->id)->find($data['to_version_id']);
            abort_if($from === null || $to === null, 422, 'Both revisions must belong to this exact sheet.');

            $existing = PlanRevisionComparison::query()
                ->where('plan_sheet_id', $locked->id)
                ->where('from_plan_sheet_version_id', $from->id)
                ->where('to_plan_sheet_version_id', $to->id)
                ->first();
            if ($existing !== null) {
                return $existing;
            }

            $result = $this->comparator->compare($from, $to);
            $encoded = json_encode($result, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);

            $comparison = PlanRevisionComparison::create([
                'tenant_id' => $locked->tenant_id,
                'project_id' => $locked->project_id,
                'plan_sheet_id' => $locked->id,
                'from_plan_sheet_version_id' => $from->id,
                'to_plan_sheet_version_id' => $to->id,
                'status' => $result['status'],
                'comparison_basis' => PlanRevisionComparator::BASIS,
                'from_sha256' => $from->sha256,
                'to_sha256' => $to->sha256,
                'result' => $result,
                'result_sha256' => hash('sha256', $encoded),
                'created_by' => $request->user()->id,
            ]);
            $this->event($locked, $from, $to, $comparison, $request->user()->id);

            return $comparison;
        });

        return response()->json(['comparison' => $this->digest($comparison), 'replayed' => ! $comparison->wasRecentlyCreated], $comparison->wasRecentlyCreated ? 201 : 200);
    }

    public function show(Request $request, PlanRevisionComparison $comparison)
    {
        $this->access->authorize($request->user(), (int) $comparison->project_id, 'plans.view');
        $this->access->authorize($request->user(), (int) $comparison->project_id, 'documents.view');

        return response()->json(['comparison' => $this->digest($comparison)]);
    }

    /** @return array<string,mixed> */
    private function digest(PlanRevisionComparison $comparison): array
    {
        $comparison->loadMissing(['sheet', 'fromVersion', 'toVersion']);
        $encoded = json_encode($comparison->result, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        $sourceHashesValid = hash_equals((string) $comparison->from_sha256, (string) $comparison->fromVersion?->sha256)
            && hash_equals((string) $comparison->to_sha256, (string) $comparison->toVersion?->sha256);

        return [
            'id' => $comparison->id,
            'project_id' => $comparison->project_id,
            'plan_sheet_id' => $comparison->plan_sheet_id,
            'sheet_number' => $comparison->sheet?->sheet_number,
            'from_revision' => $comparison->fromVersion?->revision,
            'to_revision' => $comparison->toVersion?->revision,
            'status' => $comparison->status,
            'comparison_basis' => $comparison->comparison_basis,
            'from_sha256' => $comparison->from_sha256,
            'to_sha256' => $comparison->to_sha256,
            'result' => $comparison->result,
            'result_sha256' => $comparison->result_sha256,
            'integrity_valid' => $sourceHashesValid && hash_equals((string) $comparison->result_sha256, hash('sha256', $encoded)),
            'created_by' => $comparison->created_by,
            'created_at' => optional($comparison->created_at)->toIso8601String(),
        ];
    }

    /**
     * Same hash-chained plan_events ledger PlanController writes to for
     * every sheet/version/markup mutation - a comparison is a Plans write
     * too, and the sheet's event_chain_valid check in PlanController::show()
     * walks every plan_events row for the project, so leaving this out would
     * silently make a real mutation invisible to that audit trail.
     */
    private function event(PlanSheet $sheet, PlanSheetVersion $from, PlanSheetVersion $to, PlanRevisionComparison $comparison, int $actor): void
    {
        Project::query()->whereKey($sheet->project_id)->lockForUpdate()->firstOrFail();
        $previous = DB::table('plan_events')->where('tenant_id', $sheet->tenant_id)->where('project_id', $sheet->project_id)->latest('id')->first();
        $details = ['from_revision' => $from->revision, 'to_revision' => $to->revision, 'comparison_id' => $comparison->id];
        $payload = [
            'tenant_id' => $sheet->tenant_id,
            'project_id' => $sheet->project_id,
            'plan_sheet_id' => $sheet->id,
            'plan_sheet_version_id' => $to->id,
            'plan_markup_id' => null,
            'action' => 'comparison_created',
            'details' => json_encode($details, JSON_THROW_ON_ERROR),
            'actor_user_id' => $actor,
            'previous_event_hash' => $previous?->event_hash,
            'created_at' => now(),
            'updated_at' => now(),
        ];
        $payload['event_hash'] = $this->eventHash($payload, $details);
        DB::table('plan_events')->insert($payload);
    }

    private function eventHash(array $payload, array $details): string
    {
        $canonical = [
            'tenant_id' => (int) $payload['tenant_id'],
            'project_id' => (int) $payload['project_id'],
            'plan_sheet_id' => isset($payload['plan_sheet_id']) ? (int) $payload['plan_sheet_id'] : null,
            'plan_sheet_version_id' => isset($payload['plan_sheet_version_id']) ? (int) $payload['plan_sheet_version_id'] : null,
            'plan_markup_id' => isset($payload['plan_markup_id']) ? (int) $payload['plan_markup_id'] : null,
            'action' => (string) $payload['action'],
            'details' => $this->canonicalize($details),
            'actor_user_id' => isset($payload['actor_user_id']) ? (int) $payload['actor_user_id'] : null,
            'previous_event_hash' => $payload['previous_event_hash'] ?? null,
        ];

        return hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private function canonicalize(array $value): array
    {
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $item) {
            if (is_array($item)) {
                $value[$key] = $this->canonicalize($item);
            }
        }

        return $value;
    }

    private function writesAllowed(): void
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces.');
    }
}
