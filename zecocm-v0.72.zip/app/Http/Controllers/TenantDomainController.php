<?php

namespace App\Http\Controllers;

use App\Domain\Tenancy\DomainVerifier;
use App\Domain\Tenancy\TenantDomainResolver;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/**
 * Self-initiated feature: ZecoCM-hosted subdomains and client custom
 * domains. See App\Http\Middleware\ResolveTenantDomain for how a request
 * resolves to a tenant, and App\Domain\Tenancy\DomainVerifier for the DNS
 * lookup this controller's verify() depends on.
 */
class TenantDomainController
{
    /**
     * Public bootstrap the frontend calls on every page load (before login
     * included) - the ONLY way branding for a resolved domain reaches the
     * browser. No auth: same reasoning as HomepageContentController::show()
     * - this is exactly the branding a plain visitor to that domain sees.
     */
    public function branding(Request $request)
    {
        $tenant = $request->attributes->get('resolved_tenant');
        if (! $tenant instanceof Tenant) {
            return response()->json(['resolved' => false]);
        }

        return response()->json([
            'resolved' => true,
            'tenant_name' => $tenant->name,
            'logo_url' => $tenant->logo_path ? Storage::disk('public')->url($tenant->logo_path) : null,
        ]);
    }

    /** Current tenant's own subdomain + custom-domain settings, for the settings screen. */
    public function show(Request $request)
    {
        $tenant = $this->ownTenant($request);

        return response()->json([
            'subdomain' => $tenant->subdomain,
            'root_domain' => TenantDomainResolver::rootDomain(),
            'custom_domain' => $tenant->custom_domain,
            'custom_domain_verified' => $tenant->custom_domain_verified_at !== null,
            'custom_domain_verified_at' => $tenant->custom_domain_verified_at,
            'verification_record' => $tenant->custom_domain && $tenant->custom_domain_verification_token
                ? $this->txtRecordFor($tenant)
                : null,
        ]);
    }

    /** Set (or change) this tenant's ZecoCM-hosted subdomain, e.g. "acme". */
    public function setSubdomain(Request $request)
    {
        $tenant = $this->ownTenant($request);
        $data = $request->validate([
            // Lowercase slug only - matches how ResolveTenantDomain reads the
            // host label (it is already lowercased there, but a mixed-case
            // stored value would just never match, silently).
            'subdomain' => [
                'required', 'string', 'max:63',
                'regex:/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/',
                Rule::unique('tenants', 'subdomain')->ignore($tenant->id),
                Rule::notIn(\App\Domain\Tenancy\TenantDomainResolver::RESERVED_SUBDOMAINS),
            ],
        ]);

        $tenant->subdomain = $data['subdomain'];
        $tenant->save();

        return response()->json([
            'message' => 'Subdomain saved.',
            'subdomain' => $tenant->subdomain,
            'hostname' => $tenant->subdomain.'.'.TenantDomainResolver::rootDomain(),
        ]);
    }

    /**
     * Submit a client-owned custom domain. Generates a fresh verification
     * token and returns the exact TXT record to add - the domain does NOT
     * resolve to this tenant until verify() below confirms it by live DNS
     * lookup. Re-submitting resets verification (a changed domain is an
     * unverified domain, full stop).
     */
    public function submitCustomDomain(Request $request)
    {
        $tenant = $this->ownTenant($request);
        $data = $request->validate([
            'custom_domain' => [
                'required', 'string', 'max:255',
                'regex:/^(?=.{1,255}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/i',
                Rule::unique('tenants', 'custom_domain')->ignore($tenant->id),
            ],
        ]);
        $domain = strtolower($data['custom_domain']);
        abort_if(
            $domain === TenantDomainResolver::rootDomain() || str_ends_with($domain, '.'.TenantDomainResolver::rootDomain()),
            422,
            'That is a ZecoCM-hosted address, not an external domain. Use the subdomain field instead.'
        );

        $tenant->custom_domain = $domain;
        $tenant->custom_domain_verification_token = Str::random(40);
        $tenant->custom_domain_verified_at = null;
        $tenant->save();

        return response()->json([
            'message' => 'Custom domain saved. Add the TXT record below, then verify.',
            'custom_domain' => $tenant->custom_domain,
            'verification_record' => $this->txtRecordFor($tenant),
        ]);
    }

    /**
     * Check ownership now, by live DNS TXT lookup. Marks
     * custom_domain_verified_at ONLY when the exact token is found -
     * never on a partial match, a missing record, or a lookup failure.
     */
    public function verifyCustomDomain(Request $request, DomainVerifier $verifier)
    {
        $tenant = $this->ownTenant($request);
        abort_if($tenant->custom_domain === null, 422, 'No custom domain has been submitted yet.');

        $record = $this->txtRecordFor($tenant);
        $found = $verifier->lookupTxtRecords($record['name']);
        $verified = in_array($tenant->custom_domain_verification_token, $found, true);

        if ($verified) {
            $tenant->custom_domain_verified_at = now();
            $tenant->save();

            return response()->json([
                'message' => 'Domain verified. It will start resolving to your account once DNS/TLS is live.',
                'custom_domain_verified' => true,
                'custom_domain_verified_at' => $tenant->custom_domain_verified_at,
            ]);
        }

        return response()->json([
            'message' => 'That TXT record was not found yet. DNS changes can take a while to propagate - try again shortly.',
            'custom_domain_verified' => false,
        ], 422);
    }

    private function txtRecordFor(Tenant $tenant): array
    {
        return [
            'name' => '_zecocm-verify.'.$tenant->custom_domain,
            'type' => 'TXT',
            'value' => $tenant->custom_domain_verification_token,
        ];
    }

    /**
     * Same authorization line AccountController::logo() already draws for
     * tenant branding: platform staff have no tenant of their own here, and
     * technicians propose changes rather than apply them directly.
     */
    private function ownTenant(Request $request): Tenant
    {
        $u = $request->user();
        abort_if($u->platform_role === 'technician', 403, 'Technicians propose changes; the admin applies them.');
        abort_if($u->tenant_id === null, 422, 'No company on this account.');

        return Tenant::withoutGlobalScopes()->findOrFail($u->tenant_id);
    }
}
