<?php

namespace App\Http\Middleware;

use App\Domain\Tenancy\TenantDomainResolver;
use Closure;
use Illuminate\Http\Request;

/**
 * Self-initiated feature: ZecoCM-hosted subdomains and verified client
 * custom domains. Runs globally, before routing (see bootstrap/app.php),
 * and inspects only the Host header - it never requires or assumes an
 * authenticated user, because the LOGIN screen itself needs to show the
 * resolved tenant's branding before anyone signs in.
 *
 * On a match it stashes the resolved tenant on the request attributes as
 * 'resolved_tenant' - read by the public /api/domain-branding endpoint
 * (TenantDomainController::branding) that public/app.html's bootstrap
 * fetches. It intentionally does NOT set App\Tenancy\TenantContext -
 * see TenantDomainResolver's class doc for why that stays untouched.
 *
 * On no match (app.zecocm.com, zecocm.com, www.zecocm.com, localhost, an
 * unrecognized/unverified domain, or anything else) this is a complete
 * no-op: the request proceeds exactly as it did before this middleware
 * existed. That "no match -> no-op" path is the one every existing
 * route/test runs through, and it must never change behavior.
 */
class ResolveTenantDomain
{
    public function handle(Request $request, Closure $next)
    {
        $host = $request->getHost();

        if (TenantDomainResolver::couldBeBranded($host)) {
            $tenant = TenantDomainResolver::resolve($host);
            if ($tenant !== null) {
                $request->attributes->set('resolved_tenant', $tenant);
            }
        }

        return $next($request);
    }
}
