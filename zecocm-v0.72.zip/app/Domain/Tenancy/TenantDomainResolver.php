<?php

namespace App\Domain\Tenancy;

use App\Models\Tenant;

/**
 * Resolves an inbound Host header to a branded tenant - either a ZecoCM-
 * hosted subdomain (acme.zecocm.com) or a verified client-owned custom
 * domain (cm.acmecorp.com). Shared by ResolveTenantDomain (per-request) and
 * TenantDomainController (so "is this domain still free" checks use the
 * exact same rule the middleware resolves with).
 *
 * Deliberately does NOT touch App\Tenancy\TenantContext - that static is
 * set exactly once, from the authenticated user, by EstablishTenantContext,
 * and its own doc comment is explicit that it has no alternate-source
 * escape hatch. Domain resolution runs before authentication even exists
 * (the login screen itself needs branding), so it stays a separate,
 * request-scoped signal the frontend bootstrap reads - never a stand-in
 * for "this is the authorized active customer".
 */
class TenantDomainResolver
{
    /**
     * Subdomains of the tenant-root domain that are never a tenant slug -
     * the generic app shell (app.zecocm.com), the bare/www root, and the
     * path-based portal prefixes already used elsewhere in this app
     * (routes/web.php: /platform, /portal, /support) kept reserved here too
     * so a tenant can never register a subdomain that collides with them.
     */
    public const RESERVED_SUBDOMAINS = ['app', 'www', 'api', 'admin', 'platform', 'portal', 'support', 'mail', 'ns1', 'ns2'];

    public static function rootDomain(): string
    {
        return strtolower((string) config('app.tenant_root_domain', 'zecocm.com'));
    }

    /** The tenant a raw Host header resolves to, or null for "no change - behave as today". */
    public static function resolve(string $host): ?Tenant
    {
        $host = strtolower(trim($host));
        // Strip a port if the caller passed one (Request::getHost() already
        // strips it, but this is also called with raw config/test values).
        $host = preg_replace('/:\d+$/', '', $host) ?? $host;
        if ($host === '') {
            return null;
        }

        $root = self::rootDomain();

        if ($host === $root || $host === 'www.'.$root) {
            return null;
        }

        if (str_ends_with($host, '.'.$root)) {
            $subdomain = substr($host, 0, -1 * (strlen($root) + 1));
            // A tenant subdomain is exactly one label - "acme.zecocm.com", not
            // "a.b.zecocm.com" - so a deeper label never resolves.
            if ($subdomain === '' || str_contains($subdomain, '.') || in_array($subdomain, self::RESERVED_SUBDOMAINS, true)) {
                return null;
            }

            return Tenant::where('subdomain', $subdomain)->first();
        }

        // Not under the ZecoCM root at all - only a verified custom domain
        // may resolve. An unverified/never-submitted custom_domain NEVER
        // resolves - ownership is not assumed, only checked.
        return Tenant::whereNotNull('custom_domain_verified_at')
            ->where('custom_domain', $host)
            ->first();
    }

    /** Fast pre-check so the middleware skips a DB hit for the overwhelming majority of requests. */
    public static function couldBeBranded(string $host): bool
    {
        $host = strtolower(preg_replace('/:\d+$/', '', trim($host)) ?? trim($host));
        if ($host === '' || $host === 'localhost' || $host === '127.0.0.1') {
            return false;
        }
        $root = self::rootDomain();

        return $host !== $root && $host !== 'www.'.$root;
    }
}
