<?php

namespace App\Domain\Tenancy;

/**
 * Performs the live DNS TXT lookup that custom-domain verification depends
 * on. A thin wrapper around dns_get_record() rather than a call inline in
 * the controller so a test can bind a fake in the container (same pattern
 * as AiAssistant elsewhere in this codebase) instead of hitting real DNS.
 *
 * Never mock this to make verification "just pass" in production code -
 * TenantDomainController::verify() only ever marks a domain verified when
 * this returns the exact expected token.
 */
class DomainVerifier
{
    /**
     * @return list<string> every TXT record value found at $hostname (empty on
     *                       no record, NXDOMAIN, or a resolver failure - never throws)
     */
    public function lookupTxtRecords(string $hostname): array
    {
        $records = @dns_get_record($hostname, DNS_TXT);
        if (! is_array($records)) {
            return [];
        }

        return array_values(array_filter(array_map(
            fn ($record) => $record['txt'] ?? null,
            $records
        )));
    }
}
