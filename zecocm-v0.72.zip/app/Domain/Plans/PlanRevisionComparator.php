<?php

namespace App\Domain\Plans;

use App\Models\KnowledgePassage;
use App\Models\PlanSheetVersion;
use Illuminate\Support\Collection;

/**
 * Deterministic, evidence-addressable text comparison for two immutable plan
 * revisions. This deliberately does not infer visual/geometry changes.
 */
final class PlanRevisionComparator
{
    public const BASIS = 'extracted_text_v1';

    /** @return array<string,mixed> */
    public function compare(PlanSheetVersion $from, PlanSheetVersion $to): array
    {
        $from->loadMissing('sourceVersion.source');
        $to->loadMissing('sourceVersion.source');
        $fromFacts = $this->facts($from);
        $toFacts = $this->facts($to);
        $sufficient = $fromFacts->isNotEmpty()
            && $toFacts->isNotEmpty()
            && $from->sourceVersion?->source?->ingestion_status === 'ready'
            && $to->sourceVersion?->source?->ingestion_status === 'ready';

        $fromByFingerprint = $fromFacts->keyBy('fingerprint');
        $toByFingerprint = $toFacts->keyBy('fingerprint');

        $limitations = [
            'This result compares extracted native text or OCR evidence only. It does not compare geometry, dimensions, linework, colors, symbols, layers, or image pixels.',
            'A zero-change result does not prove that the drawings are visually identical. A qualified reviewer must confirm visual and constructability impacts.',
            'TRACE must cite the underlying governed source passage before relying on an extracted statement for a project decision.',
        ];
        if (! $sufficient) {
            $limitations[] = 'Comparison refused: both revisions require addressable extracted passages. Complete extraction and steward review before retrying.';
        }

        $metadata = [];
        foreach (['revision', 'issue_status', 'issued_at', 'page_number', 'source_provider', 'external_id'] as $field) {
            $before = $this->scalar($from->{$field});
            $after = $this->scalar($to->{$field});
            if ($before !== $after) {
                $metadata[] = ['field' => $field, 'before' => $before, 'after' => $after];
            }
        }

        return [
            'basis' => self::BASIS,
            'status' => $sufficient ? 'complete' : 'insufficient_evidence',
            'from' => $this->versionDigest($from, $fromFacts->count()),
            'to' => $this->versionDigest($to, $toFacts->count()),
            'metadata_changes' => $metadata,
            'added' => $sufficient ? $toByFingerprint->diffKeys($fromByFingerprint)->values()->all() : [],
            'removed' => $sufficient ? $fromByFingerprint->diffKeys($toByFingerprint)->values()->all() : [],
            'unchanged_statement_count' => $sufficient ? $fromByFingerprint->intersectByKeys($toByFingerprint)->count() : 0,
            'limitations' => $limitations,
        ];
    }

    /** @return Collection<int,array<string,mixed>> */
    private function facts(PlanSheetVersion $version): Collection
    {
        $query = KnowledgePassage::query()
            ->where('knowledge_source_version_id', $version->knowledge_source_version_id)
            ->orderBy('ordinal');

        if ($version->page_number !== null) {
            $page = (int) $version->page_number;
            $query->where(function ($q) use ($page) {
                $q->where(function ($range) use ($page) {
                    $range->where('page_from', '<=', $page)->where('page_to', '>=', $page);
                })->orWhere(function ($unpaged) {
                    $unpaged->whereNull('page_from')->whereNull('page_to');
                });
            });
        }

        $facts = collect();
        foreach ($query->get() as $passage) {
            foreach ($this->statements((string) $passage->body) as $statement) {
                $normalized = mb_strtolower(preg_replace('/\s+/u', ' ', trim($statement)) ?? trim($statement));
                if (mb_strlen($normalized) < 12) {
                    continue;
                }
                $fingerprint = hash('sha256', $normalized);
                if ($facts->contains('fingerprint', $fingerprint)) {
                    continue;
                }
                $facts->push([
                    'fingerprint' => $fingerprint,
                    'excerpt' => mb_substr(trim($statement), 0, 1000),
                    'passage_id' => $passage->id,
                    'ordinal' => $passage->ordinal,
                    'body_sha256' => $passage->body_sha256,
                    'page_from' => $passage->page_from,
                    'page_to' => $passage->page_to,
                    'section_ref' => $passage->section_ref,
                    'sheet_ref' => $passage->sheet_ref,
                ]);
            }
        }

        return $facts;
    }

    /** @return list<string> */
    private function statements(string $body): array
    {
        $parts = preg_split('/(?<=[.!?;])\s+|\R+/u', trim($body)) ?: [];

        return array_values(array_filter(array_map('trim', $parts), fn (string $value) => $value !== ''));
    }

    /** @return array<string,mixed> */
    private function versionDigest(PlanSheetVersion $version, int $passages): array
    {
        return [
            'version_id' => $version->id,
            'revision' => $version->revision,
            'sha256' => $version->sha256,
            'page_number' => $version->page_number,
            'passage_statement_count' => $passages,
            'ingestion_status' => $version->sourceVersion?->source?->ingestion_status,
            'verification_status' => $version->sourceVersion?->source?->verification_status,
            'extraction_method' => $version->sourceVersion?->extraction_method,
            'extraction_confidence' => $version->sourceVersion?->extraction_confidence,
        ];
    }

    private function scalar(mixed $value): mixed
    {
        return $value instanceof \DateTimeInterface ? $value->format('Y-m-d') : $value;
    }
}
