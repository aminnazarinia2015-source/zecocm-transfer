<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanSheet extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    public function set()
    {
        return $this->belongsTo(PlanSet::class, 'plan_set_id');
    }

    public function versions()
    {
        return $this->hasMany(PlanSheetVersion::class);
    }

    public function currentVersion()
    {
        return $this->belongsTo(PlanSheetVersion::class, 'current_version_id');
    }

    public function comparisons()
    {
        return $this->hasMany(PlanRevisionComparison::class);
    }
}
