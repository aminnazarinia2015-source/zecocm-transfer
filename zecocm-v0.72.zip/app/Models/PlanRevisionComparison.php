<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanRevisionComparison extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = ['result' => 'array'];

    public function sheet()
    {
        return $this->belongsTo(PlanSheet::class, 'plan_sheet_id');
    }

    public function fromVersion()
    {
        return $this->belongsTo(PlanSheetVersion::class, 'from_plan_sheet_version_id');
    }

    public function toVersion()
    {
        return $this->belongsTo(PlanSheetVersion::class, 'to_plan_sheet_version_id');
    }

    public function getNumberAttribute(): string
    {
        $this->loadMissing(['sheet', 'fromVersion', 'toVersion']);
        $added = count($this->result['added'] ?? []);
        $removed = count($this->result['removed'] ?? []);

        return sprintf(
            '%s revision %s to %s (%d added, %d removed; extracted-text evidence)',
            $this->sheet?->sheet_number ?? 'Plan sheet',
            $this->fromVersion?->revision ?? '?',
            $this->toVersion?->revision ?? '?',
            $added,
            $removed,
        );
    }
}
