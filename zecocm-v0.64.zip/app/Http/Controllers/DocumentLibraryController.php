<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Domain\Security\SecureUploadGate;
use App\Models\DocumentFolder;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class DocumentLibraryController
{
    private const EXTENSIONS = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'jpg', 'jpeg', 'png', 'tif', 'tiff'];

    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'folder_id' => 'nullable|integer',
            'q' => 'nullable|string|max:160',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.view')->project;
        $folderId = isset($data['folder_id']) ? (int) $data['folder_id'] : null;
        if ($folderId !== null) {
            DocumentFolder::query()->where('project_id', $project->id)->findOrFail($folderId);
        }

        $folders = DocumentFolder::query()->where('project_id', $project->id)->where('parent_id', $folderId)
            ->withCount(['children', 'documents'])->orderBy('name')->get();
        $documents = KnowledgeSource::query()->where('project_id', $project->id)->where('document_folder_id', $folderId)
            ->when($data['q'] ?? null, fn ($query, $q) => $query->where('title', 'like', '%'.addcslashes($q, '%_\\').'%'))
            ->with(['versions' => fn ($query) => $query->latest('version_number')])->orderBy('title')->limit(500)->get();

        return response()->json([
            'folder' => $folderId ? DocumentFolder::query()->find($folderId) : null,
            'breadcrumbs' => $this->breadcrumbs($project->id, $folderId),
            'folders' => $folders,
            'documents' => $documents,
            'allowed_extensions' => self::EXTENSIONS,
            'security' => ['scanner_configured' => $this->scannerConfigured(),
                'upload_mode' => $this->scannerConfigured() ? 'scan_before_release' : 'quarantine_only'],
            'notice' => 'Only documentary formats are accepted. Executables, scripts, archives and active web content are refused.',
        ]);
    }

    public function createFolder(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer', 'parent_id' => 'nullable|integer',
            'name' => ['required', 'string', 'max:160', 'regex:/^[^\\\\\/:*?"<>|\x00-\x1F]+$/u'],
            'classification' => 'nullable|in:project_private,tenant_private,party_shared,restricted',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.ingest', write: true)->project;
        $parentId = isset($data['parent_id']) ? (int) $data['parent_id'] : null;
        if ($parentId !== null) DocumentFolder::query()->where('project_id', $project->id)->findOrFail($parentId);
        $exists = DocumentFolder::query()->where('project_id', $project->id)->where('parent_id', $parentId)->where('name', trim($data['name']))->exists();
        if ($exists) throw ValidationException::withMessages(['name' => 'A folder with this name already exists here.']);
        $folder = DocumentFolder::create(['tenant_id' => $project->tenant_id, 'project_id' => $project->id,
            'parent_id' => $parentId, 'name' => trim($data['name']), 'classification' => $data['classification'] ?? 'project_private',
            'created_by' => $request->user()->id]);
        return response()->json(['folder' => $folder, 'notice' => 'Folder created. It contains no documents until authorized uploads are added.'], 201);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            // Found when Amin flagged that real project drawing sets routinely run 300-500MB -
            // the prior 100MB ceiling (102400 KB) rejected exactly the files this feature exists
            // to hold. Raised to 750MB (768000 KB) for real headroom above that; see
            // UploadLimitsHealthCheck (OPS-17) and deploy/bootstrap.sh, which must both raise
            // PHP's own limits to match, and SecureUploadGate::timeoutForSize(), which scales the
            // malware-scan deadline to the file's actual size.
            'project_id' => 'required|integer', 'folder_id' => 'nullable|integer', 'file' => 'required|file|max:768000',
            'title' => 'nullable|string|max:255', 'classification' => 'nullable|in:project_private,tenant_private,party_shared,restricted',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.ingest', write: true)->project;
        $folderId = isset($data['folder_id']) ? (int) $data['folder_id'] : null;
        if ($folderId !== null) DocumentFolder::query()->where('project_id', $project->id)->findOrFail($folderId);
        $file = $request->file('file');
        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);
        if (! $decision->admitted) {
            throw ValidationException::withMessages(['file' => 'Only documentary files are accepted; scripts, executables and archives are prohibited ('.$decision->rejectionReason.').']);
        }
        $original = $decision->safeName;
        $extension = (string) $decision->extension;
        $hash = hash_file('sha256', $file->getRealPath());
        abort_if($hash === false, 422, 'The document could not be hashed.');
        $duplicate = KnowledgeSource::query()->where('project_id', $project->id)->where('sha256', $hash)->first();
        if ($duplicate) return response()->json(['document' => $duplicate->load('versions'), 'replayed' => true,
            'notice' => 'Identical bytes already exist. The immutable copy was reused; no duplicate was created.']);
        $scan = SecureUploadGate::scan($file->getRealPath(), SecureUploadGate::timeoutForSize($file->getSize()));
        $storagePath = 'documents/'.($scan === 'clean' ? 'sealed' : 'quarantine').'/'.$project->tenant_id.'/'.$project->id.'/'.$hash;
        Storage::disk('local')->put($storagePath, file_get_contents($file->getRealPath()));
        $document = DB::transaction(function () use ($data, $project, $request, $file, $folderId, $original, $extension, $hash, $scan, $storagePath) {
            $document = KnowledgeSource::create(['tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                'document_folder_id' => $folderId, 'public_id' => (string) Str::uuid(), 'collection' => 'project',
                'title' => trim($data['title'] ?? '') ?: pathinfo($original, PATHINFO_FILENAME), 'original_filename' => $original,
                'source_type' => $this->sourceType($extension), 'document_kind' => $this->kind($extension),
                'authority_level' => 'party_assertion', 'access_classification' => $data['classification'] ?? 'project_private',
                'verification_status' => 'provisional', 'ingestion_status' => $scan === 'clean' ? 'review_required' : 'quarantined',
                'mime_type' => (string) ($file->getMimeType() ?: 'application/octet-stream'), 'storage_path' => $storagePath,
                'byte_size' => $file->getSize(), 'sha256' => $hash, 'malware_scan_status' => $scan,
                'quarantine_reason' => $scan === 'clean' ? null : 'Awaiting configured malware scanning.', 'uploaded_by' => $request->user()->id]);
            KnowledgeSourceVersion::create(['knowledge_source_id' => $document->id, 'version_number' => 1, 'sha256' => $hash,
                'storage_path' => $storagePath, 'mime_type' => (string) ($file->getMimeType() ?: 'application/octet-stream'),
                'byte_size' => $file->getSize(), 'uploaded_by' => $request->user()->id, 'malware_scan_status' => $scan,
                'extraction_method' => 'not_extracted', 'extraction_confidence' => null, 'parser_version' => 'document-library-v1',
                'classification' => ['extension' => $extension, 'documentary_only' => true]]);
            $this->event($document, 'created', ['version' => 1, 'sha256' => $hash], $request->user()->id);
            return $document;
        });
        return response()->json(['document' => $document->load('versions'),
            'notice' => $scan === 'clean' ? 'Immutable document version stored and queued for review.' : 'Upload quarantined pending malware scanning; it cannot be opened or retrieved by AI.'], 201);
    }

    public function storeVersion(Request $request, KnowledgeSource $document)
    {
        // Same 750MB ceiling as store() above, and for the same reason - a new version of an
        // existing document is exactly as likely to be a full-size drawing-set revision.
        $data = $request->validate(['file' => 'required|file|max:768000', 'revision' => 'nullable|string|max:96']);
        $project = $this->access->authorize($request->user(), (int) $document->project_id, 'documents.ingest', write: true)->project;
        $file = $request->file('file');
        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);
        if (! $decision->admitted) {
            throw ValidationException::withMessages(['file' => 'Only documentary files are accepted; scripts, executables and archives are prohibited ('.$decision->rejectionReason.').']);
        }
        $original = $decision->safeName;
        $extension = (string) $decision->extension;
        $hash = hash_file('sha256', $file->getRealPath()); abort_if($hash === false, 422, 'The document could not be hashed.');
        if ($document->versions()->where('sha256', $hash)->exists()) return response()->json(['document' => $document->load('versions'),
            'replayed' => true, 'notice' => 'These exact bytes already exist in this document history; no duplicate version was created.']);
        $scan = SecureUploadGate::scan($file->getRealPath(), SecureUploadGate::timeoutForSize($file->getSize()));
        $storagePath = 'documents/'.($scan === 'clean' ? 'sealed' : 'quarantine').'/'.$project->tenant_id.'/'.$project->id.'/'.$hash;
        Storage::disk('local')->put($storagePath, file_get_contents($file->getRealPath()));
        $version = DB::transaction(function () use ($data, $document, $request, $file, $original, $extension, $hash, $scan, $storagePath) {
            $number = ((int) $document->versions()->max('version_number')) + 1;
            $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $document->id, 'version_number' => $number,
                'revision' => $data['revision'] ?? null, 'sha256' => $hash, 'storage_path' => $storagePath,
                'mime_type' => (string) ($file->getMimeType() ?: 'application/octet-stream'), 'byte_size' => $file->getSize(),
                'uploaded_by' => $request->user()->id, 'malware_scan_status' => $scan, 'extraction_method' => 'not_extracted',
                'extraction_confidence' => null, 'parser_version' => 'document-library-v1',
                'classification' => ['extension' => $extension, 'documentary_only' => true, 'original_filename' => $original]]);
            $document->update(['original_filename' => $original, 'document_kind' => $this->kind($extension),
                'mime_type' => $version->mime_type, 'storage_path' => $storagePath, 'byte_size' => $file->getSize(),
                'sha256' => $hash, 'malware_scan_status' => $scan, 'ingestion_status' => $scan === 'clean' ? 'review_required' : 'quarantined',
                'verification_status' => 'provisional', 'verified_by' => null, 'verified_at' => null,
                'quarantine_reason' => $scan === 'clean' ? null : 'Awaiting configured malware scanning.']);
            $this->event($document, 'version_appended', ['version' => $number, 'sha256' => $hash], $request->user()->id);
            return $version;
        });
        return response()->json(['version' => $version, 'document' => $document->fresh()->load('versions'),
            'notice' => 'Revision appended as immutable version '.$version->version_number.'; prior bytes remain preserved.'], 201);
    }

    public function download(Request $request, KnowledgeSource $document)
    {
        $this->access->authorize($request->user(), (int) $document->project_id, 'documents.view');
        abort_unless($document->malware_scan_status === 'clean', 423, 'This document is quarantined and cannot be opened.');
        abort_unless(Storage::disk('local')->exists($document->storage_path), 404, 'That file is no longer on disk - it may have been removed outside the app.');
        return Storage::disk('local')->download($document->storage_path, $document->original_filename ?: $document->title,
            ['Content-Type' => $document->mime_type ?: 'application/octet-stream', 'X-Content-Type-Options' => 'nosniff',
                'Content-Security-Policy' => "default-src 'none'; sandbox", 'Cache-Control' => 'private, no-store']);
    }

    private function breadcrumbs(int $projectId, ?int $folderId): array
    {
        $items = []; $seen = [];
        while ($folderId !== null) {
            abort_if(isset($seen[$folderId]), 409, 'Folder lineage is invalid.'); $seen[$folderId] = true;
            $folder = DocumentFolder::query()->where('project_id', $projectId)->findOrFail($folderId);
            array_unshift($items, ['id' => $folder->id, 'name' => $folder->name]); $folderId = $folder->parent_id;
        }
        array_unshift($items, ['id' => null, 'name' => 'Documents']); return $items;
    }

    // SEC-5: the per-controller allowlist and safeName helper that used to
    // live here moved to SecureUploadGate, the one gateway every upload path
    // now shares. See SecureUploadGate for why this stopped being a
    // per-controller convention.

    private function kind(string $extension): string { return match ($extension) { 'pdf' => 'pdf', 'doc', 'docx' => 'word', 'xls', 'xlsx', 'csv' => 'spreadsheet', 'ppt', 'pptx' => 'presentation', 'jpg', 'jpeg', 'png', 'tif', 'tiff' => 'image', default => 'text' }; }
    private function sourceType(string $extension): string { return in_array($extension, ['jpg', 'jpeg', 'png', 'tif', 'tiff'], true) ? 'drawing' : 'correspondence'; }

    private function scannerConfigured(): bool
    {
        return trim((string) config('schedule.malware_scanner_binary', '')) !== '';
    }

    // scan() moved to SecureUploadGate::scan(), which now bounds the scanner
    // process with a timeout (BoundedProcess) - the unbounded proc_open that
    // used to live here could hang the request on a crafted file.

    private function event(KnowledgeSource $document, string $action, array $details, int $actor): void
    {
        $previous = DB::table('document_events')->where('knowledge_source_id', $document->id)->latest('id')->first();
        $payload = ['tenant_id' => $document->tenant_id, 'project_id' => $document->project_id,
            'knowledge_source_id' => $document->id, 'action' => $action, 'details' => json_encode($details, JSON_THROW_ON_ERROR),
            'actor_user_id' => $actor, 'previous_event_hash' => $previous?->event_hash, 'created_at' => now(), 'updated_at' => now()];
        $payload['event_hash'] = hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR)); DB::table('document_events')->insert($payload);
    }
}
