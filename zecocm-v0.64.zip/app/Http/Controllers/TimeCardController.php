<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use App\Models\TimeCard;
use App\Models\TimeCardLine;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Contractor time cards - see database/migrations/2026_08_27_070000_create_
 * time_cards_table.php for why this is a separate concept from the
 * pre-existing per-day time_card_entries embedded in a Daily Report.
 *
 * Submission and approval are separate acts, the same shape as change
 * orders: a contractor submits what they are asserting; a PM/foreman
 * approval is a distinct, attributed decision, never implied by submission.
 */
class TimeCardController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'timecard.view')->project;

        $cards = TimeCard::query()->where('project_id', $project->id)
            ->with(['lines.scheduleActivity', 'submittedBy', 'approvedBy'])
            ->orderByDesc('pay_period_start')
            ->limit(200)->get();

        return response()->json([
            'time_cards' => $cards->map(fn (TimeCard $c) => $this->digest($c)),
            'eligible_activities' => $this->eligibleActivities($project->id),
        ]);
    }

    public function store(Request $request)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');

        $data = $request->validate([
            'project_id' => 'required|integer',
            'pay_period_start' => 'required|date',
            'pay_period_end' => 'required|date|after_or_equal:pay_period_start',
            'lines' => 'required|array|min:1|max:200',
            'lines.*.schedule_activity_id' => 'nullable|integer',
            'lines.*.work_date' => 'required|date',
            'lines.*.resource_code' => 'required|string|max:64',
            'lines.*.resource_name' => 'required|string|max:255',
            'lines.*.resource_type' => 'required|in:labor,equipment',
            'lines.*.pay_class' => 'nullable|string|max:32',
            'lines.*.cost_code' => 'required|string|max:32',
            'lines.*.hours' => 'required|numeric|min:0|max:24',
            'lines.*.notes' => 'nullable|string|max:2000',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'timecard.create', write: true)->project;

        $card = DB::transaction(function () use ($data, $project, $request) {
            $card = TimeCard::create([
                'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                'submitted_by' => $request->user()->id,
                'pay_period_start' => $data['pay_period_start'], 'pay_period_end' => $data['pay_period_end'],
                'status' => TimeCard::STATUS_SUBMITTED, 'submitted_at' => now(),
            ]);

            foreach ($data['lines'] as $line) {
                // Same rule as DailyReportActivity: an activity id is only
                // ever attached if it belongs to THIS project's own schedule
                // versions - an id from another project simply does not
                // exist here, silently, rather than trusted from the client.
                $scheduleActivityId = null;
                if (! empty($line['schedule_activity_id'])) {
                    $scheduleActivityId = ScheduleActivity::query()
                        ->where('id', $line['schedule_activity_id'])
                        ->whereIn('schedule_version_id', function ($q) use ($project) {
                            $q->select('id')->from('schedule_versions')->where('project_id', $project->id);
                        })
                        ->value('id');
                }

                $card->lines()->create([
                    'tenant_id' => $card->tenant_id,
                    'schedule_activity_id' => $scheduleActivityId,
                    'work_date' => $line['work_date'],
                    'resource_code' => $line['resource_code'],
                    'resource_name' => $line['resource_name'],
                    'resource_type' => $line['resource_type'],
                    'pay_class' => $line['pay_class'] ?? null,
                    'cost_code' => $line['cost_code'],
                    'hours' => $line['hours'],
                    'notes' => $line['notes'] ?? null,
                ]);
            }

            return $card;
        });

        return response()->json($this->digest($card->fresh(['lines.scheduleActivity', 'submittedBy'])), 201);
    }

    public function show(Request $request, TimeCard $card)
    {
        $this->access->authorize($request->user(), (int) $card->project_id, 'timecard.view');
        $card->loadMissing(['lines.scheduleActivity', 'submittedBy', 'approvedBy']);

        return response()->json($this->digest($card));
    }

    /**
     * Editable only while still awaiting review - the same edit-before-seal
     * precedent used across the app. Found missing during a real-world
     * audit: a wrong hour count entered before anyone reviewed it had no
     * fix path except abandoning the whole card and resubmitting from
     * scratch. Once a determination is recorded (approved or rejected) the
     * card is a dated decision and is never rewritten.
     */
    public function update(Request $request, TimeCard $card)
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only - submit a suggestion; the admin applies it.');
        $project = $this->access->authorize($request->user(), (int) $card->project_id, 'timecard.create', write: true)->project;
        abort_if($card->status !== TimeCard::STATUS_SUBMITTED, 422,
            'This time card already has a determination recorded. Correct the hours on the next pay period\'s card instead of rewriting a decided one.');

        $data = $request->validate([
            'pay_period_start' => 'sometimes|required|date',
            'pay_period_end' => 'sometimes|required|date|after_or_equal:pay_period_start',
            'lines' => 'sometimes|required|array|min:1|max:200',
            'lines.*.id' => 'nullable|integer',
            'lines.*.schedule_activity_id' => 'nullable|integer',
            'lines.*.work_date' => 'required_with:lines|date',
            'lines.*.resource_code' => 'required_with:lines|string|max:64',
            'lines.*.resource_name' => 'required_with:lines|string|max:255',
            'lines.*.resource_type' => 'required_with:lines|in:labor,equipment',
            'lines.*.pay_class' => 'nullable|string|max:32',
            'lines.*.cost_code' => 'required_with:lines|string|max:32',
            'lines.*.hours' => 'required_with:lines|numeric|min:0|max:24',
            'lines.*.notes' => 'nullable|string|max:2000',
        ]);

        // Same edit-audit-trail pattern as RfiController::update()/
        // SubmittalController::update() (added after an independent Gemini
        // cross-check flagged the general gap): record what the card used to
        // say before applying the correction. Skip entirely on a true no-op
        // (only unrecognized fields in the body, or a body with neither
        // header fields nor lines) so the log doesn't lie about how many
        // times the record was genuinely edited.
        if (empty($data)) {
            return response()->json($this->digest($card->fresh(['lines.scheduleActivity', 'submittedBy'])));
        }

        DB::transaction(function () use ($card, $data, $project, $request) {
            $before = array_intersect_key($card->getAttributes(), array_intersect_key($data, array_flip(['pay_period_start', 'pay_period_end'])));
            if (array_key_exists('lines', $data)) {
                $before['lines'] = $card->lines()->get()->map(fn ($l) => $l->only([
                    'schedule_activity_id', 'work_date', 'resource_code', 'resource_name',
                    'resource_type', 'pay_class', 'cost_code', 'hours', 'notes',
                ]))->all();
            }
            $history = $card->edit_history ?? [];
            $history[] = ['action' => 'edited', 'by' => $request->user()->id, 'at' => now()->toIso8601String(), 'before' => $before];
            $card->edit_history = $history;

            $card->update(array_filter([
                'pay_period_start' => $data['pay_period_start'] ?? null,
                'pay_period_end' => $data['pay_period_end'] ?? null,
            ], fn ($v) => $v !== null));

            if (array_key_exists('lines', $data)) {
                $card->lines()->delete();
                foreach ($data['lines'] as $line) {
                    $scheduleActivityId = null;
                    if (! empty($line['schedule_activity_id'])) {
                        $scheduleActivityId = ScheduleActivity::query()
                            ->where('id', $line['schedule_activity_id'])
                            ->whereIn('schedule_version_id', function ($q) use ($project) {
                                $q->select('id')->from('schedule_versions')->where('project_id', $project->id);
                            })
                            ->value('id');
                    }

                    $card->lines()->create([
                        'tenant_id' => $card->tenant_id,
                        'schedule_activity_id' => $scheduleActivityId,
                        'work_date' => $line['work_date'],
                        'resource_code' => $line['resource_code'],
                        'resource_name' => $line['resource_name'],
                        'resource_type' => $line['resource_type'],
                        'pay_class' => $line['pay_class'] ?? null,
                        'cost_code' => $line['cost_code'],
                        'hours' => $line['hours'],
                        'notes' => $line['notes'] ?? null,
                    ]);
                }
            }
        });

        return response()->json($this->digest($card->fresh(['lines.scheduleActivity', 'submittedBy'])));
    }

    public function approve(Request $request, TimeCard $card)
    {
        $this->access->authorize($request->user(), (int) $card->project_id, 'timecard.approve', write: true);
        abort_unless($card->status === TimeCard::STATUS_SUBMITTED, 422, 'Only a submitted time card awaiting review can be approved or rejected.');

        $data = $request->validate([
            'decision' => 'required|in:approve,reject',
            'determination' => 'required|string|max:2000',
        ]);

        $card->forceFill([
            'status' => $data['decision'] === 'approve' ? TimeCard::STATUS_APPROVED : TimeCard::STATUS_REJECTED,
            'approved_by' => $request->user()->id,
            'approved_at' => now(),
            'determination' => $data['determination'],
        ])->save();

        return response()->json($this->digest($card->fresh(['lines.scheduleActivity', 'submittedBy', 'approvedBy'])));
    }

    private function eligibleActivities(int $projectId): array
    {
        $version = ScheduleVersion::where('project_id', $projectId)->orderByDesc('data_date')->first();
        if ($version === null) {
            return [];
        }

        return ScheduleActivity::where('schedule_version_id', $version->id)
            ->whereIn('activity_type', ScheduleActivity::FIELD_PRODUCTION_TYPES)
            ->orderBy('activity_code')
            ->limit(500)
            ->get(['id', 'activity_code', 'name'])
            ->all();
    }

    private function digest(TimeCard $card): array
    {
        return [
            'id' => $card->id, 'project_id' => $card->project_id,
            'pay_period_start' => optional($card->pay_period_start)->toDateString(),
            'pay_period_end' => optional($card->pay_period_end)->toDateString(),
            'status' => $card->status,
            'submitted_by_name' => $card->submittedBy?->name,
            'submitted_at' => optional($card->submitted_at)->toIso8601String(),
            'approved_by_name' => $card->approvedBy?->name,
            'approved_at' => optional($card->approved_at)->toIso8601String(),
            'determination' => $card->determination,
            'total_hours' => number_format((float) $card->lines->sum('hours'), 2, '.', ''),
            'lines' => $card->lines->map(fn (TimeCardLine $l) => [
                'id' => $l->id,
                'work_date' => optional($l->work_date)->toDateString(),
                'resource_code' => $l->resource_code,
                'resource_name' => $l->resource_name,
                'resource_type' => $l->resource_type,
                'pay_class' => $l->pay_class,
                'cost_code' => $l->cost_code,
                'hours' => (string) $l->hours,
                'notes' => $l->notes,
                'schedule_activity_id' => $l->schedule_activity_id,
                'schedule_activity_code' => $l->scheduleActivity?->activity_code,
            ])->all(),
        ];
    }
}
