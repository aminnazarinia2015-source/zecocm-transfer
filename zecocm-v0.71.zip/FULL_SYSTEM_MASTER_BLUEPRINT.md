# ZecoCM Full-System Master Blueprint

## Executive direction

ZecoCM is a policy-controlled construction evidence, education, and decision operating system for public owners and their delivery partners. It is not a generic document repository with a chatbot. Its competitive advantage is one verified factual core, immutable time, contract-aware workflows, accountable human decisions, and AI that cites or refuses.

The product must feel simple enough for a first-day inspector and deep enough for a program executive, scheduler, contract administrator, auditor, and designer of record. Complexity stays in the evidence and policy layers; each user sees the smallest correct next action.

## Governing hierarchy

1. **ZecoCM platform owner** - customers, platform staff, product policy, capability catalogue, billing controls, security, model releases, and suggestions. No customer projects exist at this level.
2. **Purchasing account** - a city, CM, contractor, designer, or other organization that bought the system and controls its own world.
3. **Sponsored portals and branches** - counterparties created by the purchaser. They cannot receive authority, data, or AI capability above the sponsor's ceiling.
4. **Programs and projects** - sector-first workspaces with explicit owner, funding, contract, location, calendars, structures, organizations, and grants.
5. **People and assignments** - authenticated identity plus organization, project membership, section assignment, discipline, authority, and capability. There is never a role picker.
6. **Evidence and records** - immutable media, documents, field observations, correspondence, RFIs, submittals, schedules, costs, and decisions.
7. **Decision layer** - deterministic calculations, review queues, authority ceremonies, issued documents, receipts, and append-only corrections.
8. **Intelligence layer** - help, retrieval, classification, comparison, drafting, education, recommendations, and refusals.

Tenant context is mandatory. No context matches nothing. Support-mode writes are limited to the platform administrator and stamped on the customer's record. Technicians remain read-only and propose changes through the suggestions inbox.

## Product surfaces

### Platform console

- Customer accounts, status, plans, branches, sponsored portals, active capabilities, usage, budgets, security posture, and health.
- Platform staff, assignments, read-only technician access, support-mode sessions, and immutable support receipts.
- Capability catalogue, model tiers, quotas, time windows, monetary ceilings, feature availability, and billing references.
- Knowledge-source connector catalogue, provider/model allowlist, prompt releases, evaluation gates, incident controls, and system settings.
- Suggestions inbox, customer support queue, security events, audit exports, retention jobs, and operational monitoring.

### Purchasing-account administration

- Organization profile, branding, legal identity, branches, departments, and contacts.
- People, seats, disciplines, project assignments, authority limits, substitutes, and separation-of-duties rules.
- Portal creation and one-time credential handoff.
- Project templates, structures, numbering, routing, clocks, calendars, terminology, and required evidence.
- Licence book, delegated capabilities, usage, budget, expiry, and renewal.
- City/organization Knowledge Atlas and named knowledge stewards.

### Portfolio and program

- Cross-project success brief, milestone outlook, funding, exposure ranges, decisions due, schedule health, evidence health, and closeout readiness.
- Program standards, reusable structures, controlled templates, shared city knowledge, and approved lessons.
- Authorization-filtered comparisons; no hidden project may leak through counts, search, trends, or autocomplete.

### Project Success Home

- One sentence: where the project stands, with evidence timestamp and confidence.
- In My Court: only actionable items authorized for the signed-in person.
- Today/next-seven-days milestones, constraints, inspections, deliveries, weather risks, and contract clocks.
- Decision Readiness Index, evidence gaps, unresolved conflicts, recent sealed activity, and AI refusals.
- Universal command center for navigation, search, education, reports, and safe draft actions.

### Core project modules

1. **Directory and structure** - organizations, people, disciplines, distribution groups, responsibility matrix, work breakdown, areas, assets, cost codes, specification sections, and drawing sets.
2. **Documents and standards** - controlled documents, revisions, transmittals, distribution, acknowledgements, supersession, city standards, specifications, plans, models, and Knowledge Atlas.
3. **Submittals** - requirements register, packages, lead times, workflow, review stamps, resubmittals, substitutions, procurement links, and schedule links.
4. **RFIs** - structured references, questions, originator assertions, clock, routing, response authority, clarification media, impacts as declarations, related records, and immutable issuance.
5. **Daily/field** - labor, equipment, work performed, quantities, deliveries, visitors, inspections, safety, weather, delays as assertions, photos, signatures, offline queue, and locked report.
6. **Plans/models** - revision control, sheet comparison, markups, locations, linked field records, superseded-in-use warnings, and model viewpoints.
7. **Quality/inspections** - inspection plans, hold/witness points, test results, deficiencies, NCRs, punch, verification, and closure evidence.
8. **Safety** - observations, toolbox talks, incidents, corrective actions, permits, training, attestations, and authority escalation. AI never makes life-safety judgments.
9. **Schedule intelligence** - immutable versions, calendars, CPM validation, identity mapping, deltas, narratives, hypotheses, bounded recovery options, accepted-version gate, and decision history.
10. **Look-ahead/production** - pull planning, commitments, constraints, percent-plan-complete, reasons for variance, quantities, crew/resource plans, weather, and schedule reconciliation.
11. **Change/notices/claims** - potential changes, notice clocks, entitlement positions as party assertions, quotations, independent estimates, TIA links, negotiations, determinations, and executed modifications.
12. **Cost/payments/funding** - budget, commitments, forecasts, quantities, stored materials, pay applications, retainage, compliance holds, approvals, payments, funding sources, and audit reconciliation.
13. **Meetings/correspondence** - agendas, minutes, action items, decisions, objections, distribution, email capture, letters, and linked evidence.
14. **Labor compliance** - certified payroll intake, classifications, prevailing-wage references, apprenticeship, exceptions, review, and export. Legal determinations remain human.
15. **Closeout/assets** - warranties, O&M, training, tests, as-builts, commissioning, permits, punch, final payment dependencies, asset handover, and public-record package.
16. **Send to City** - agency-ready, redacted, sealed packages with manifest, hashes, versions, authority, delivery receipt, and correction chain.

## Universal command center

The command center is present on every authenticated screen. It supports keyboard-first use and four explicit modes:

- **Open/find**: navigation and authorization-filtered search.
- **Explain/teach**: free product help and approved public-works education.
- **Analyze**: deterministic calculation or cited project intelligence.
- **Prepare**: paid drafting assistance that creates a draft, never a formal act.

Example commands: “Show RFIs waiting on the City,” “What changed since Friday?”, “Compare Update 7 to the accepted baseline,” “Prepare today's report,” and “Teach me this city's traffic-control submittal process.” Results are action cards with links, source state, freshness, confidence, assumptions, and refusal—not an unstructured chat transcript.

## Evidence and epistemic contract

Every consequential statement has exactly one primary classification:

- fact;
- party assertion;
- deterministic calculation;
- correlation;
- inference;
- dispute;
- recommendation;
- formal determination.

The interface uses consistent labels, icons, language, and source drawers. A value without an authorized source shows “Not established,” not zero, no, or blank. A source drawer exposes document/version, page/sheet/section, hash, authority, freshness, access, and retrieval time.

## Human authority contract

AI and deterministic engines may prepare, compare, explain, identify gaps, and recommend. They never independently:

- issue a notice;
- approve or certify payment;
- apply a signature;
- accept a schedule;
- approve a submittal;
- answer an RFI as the design professional;
- make design, code-equivalency, or life-safety judgments;
- modify a contract;
- determine legal fault, causation, entitlement, or responsibility.

Formal actions open a Decision Envelope containing record identity, completeness, sources, calculations, assertions, conflicts, missing evidence, authority, consequences, distribution, and deliberate confirmation. The completed act receives an immutable receipt.

## Visual and interaction direction

Use Civic Precision: calm, authoritative, modern, and evidence-first. Avoid playful construction clichés, decorative dashboards, unexplained red/green scoring, excessive cards, and dense enterprise menus.

- Desktop: 240 px collapsible rail, global command, project context, content canvas, contextual evidence drawer.
- Tablet: compact rail, two-pane workflows, touch-first review.
- Mobile: field capture first; bottom actions, offline state, camera/audio/markup, 44 px targets, no compressed desktop tables.
- Typography: highly legible sans-serif plus restrained monospaced treatment for IDs, hashes, clocks, and schedule values.
- Status uses text and icon, never color alone.
- Motion is short and functional; reduced-motion is supported.

## Nonfunctional product requirements

- WCAG 2.2 AA, keyboard complete, 200% zoom, 320 CSS px reflow, screen-reader async announcements, English/Spanish expansion.
- Tenant isolation tested at query, cache, queue, search, count, export, autocomplete, source, error, and analytics layers.
- Append-only audit for evidence, issued documents, dispositions, licences, AI runs, feedback, support actions, and formal decisions.
- Resumable and idempotent workflows; retry-safe jobs and outbox delivery.
- Malware scanning, quarantine, MIME/content validation, archive defenses, formula/encoding defenses, and OCR confidence gates.
- Encryption, key rotation, backups, restore tests, retention/legal-hold policy, monitoring, incident response, and disaster recovery.
- Performance budgets: interactive shell under 2.5 seconds on typical broadband, command suggestions under 300 ms from local indexes, API p95 under 750 ms excluding queued work, explicit progress for longer operations.

## Definition of “top system”

ZecoCM is market-leading when users can complete real work faster while an auditor can replay every consequential conclusion; when field evidence becomes contract-ready without re-keying; when schedule/cost/document truth stays versioned; when public owners and contractors collaborate without collapsing their separate authority; and when AI improves outcomes without disguising uncertainty or making unauthorized decisions.
