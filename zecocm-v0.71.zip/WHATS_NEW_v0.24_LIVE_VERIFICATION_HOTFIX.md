# ZecoCM v0.24 — Live Verification Hotfix

Production verification of v0.23 exposed three interface truth/routing defects.
This hotfix corrects them without changing project records.

- Documents & Standards now opens the server-backed document library instead of
  the legacy unavailable screen.
- Inspections & Punch now opens the server-backed Quality & Punch workflow.
- Platform administrators entering a customer project are labeled as audited
  Support Mode, while technicians remain read-only.
- Removed the blanket button listener that displayed a false “not wired” toast
  after successful customer/project navigation.
- Project entry wording now distinguishes administrator Support Mode from
  technician read-only review.

Validation: 77 tests passed with 356 assertions. Production must still be
rechecked after upload, including scanner state, document routing, Quality &
Punch navigation, RFI creation with an authorized test record, and phone layout.
