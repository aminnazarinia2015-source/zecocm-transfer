# ZecoCM Full Module and Functionality Catalog

## Status language (mandatory)

Every screen and release note must use one of these states:

- **Operational:** connected to authorized persisted data and covered by acceptance tests.
- **Limited:** operational only for the named scope; limitations are visible.
- **Preview:** design/prototype only; it cannot create a formal record.
- **Unavailable:** intentionally blocked with an explanation and next step.

No placeholder, hard-coded count, demo toast, or simulated AI response may appear operational.

## A. Platform-owner administration

The ZecoCM platform level contains no projects and no customer project records in normal mode.

1. **Customer accounts** — create/suspend/restore purchasing accounts; account type; legal name; contacts; billing state; data region; retention; contract dates; portal allowance.
2. **Portal provisioning** — City, CM firm, contractor, designer, or other sponsor; one-time credential handoff; no email unless enabled; zero-project invariant.
3. **Licensing and entitlements** — module flags, AI task permissions, model tier, start/end time, quotas, monetary budget, concurrency, grace state, delegated ceilings, immutable entitlement history.
4. **Platform staff** — admin and technician assignments; technicians read only; least privilege; MFA and session controls.
5. **Support mode** — explicit entry reason, customer banner, time limit, write gate, actor stamp, before/after audit record; no silent impersonation.
6. **Suggestions inbox** — technician/customer proposals; triage, disposition, link to issue/release; proposals never mutate production records.
7. **System settings** — approved integrations/models, feature-release controls, security policies, maintenance notices, retention defaults.
8. **Operations center** — service health, queues, failed jobs, outbox, storage, malware scanner, backup status, tenant-safe diagnostics.
9. **Security center** — access anomalies, failed logins, token revocation, export events, privilege changes, incident holds.
10. **Release governance** — migration readiness, test evidence, rollout rings, rollback plan, known limitations, release approvals.

## B. Purchasing-account / sponsor administration

Whoever buys the system administers their world within platform-defined ceilings. A city may sponsor CMs and contractors; a CM may sponsor city/contractor portals; a contractor may sponsor collaborators. Sponsorship never grants ownership of another party's sealed records.

1. Organization profile, branches, branding, domains, data policies.
2. Sponsored portal tree with visible ownership, delegation, limits, and revocation.
3. People, invitations, employment/organization relationships, role templates, section assignments, project grants.
4. Project portfolio, lifecycle, archive/legal hold, templates, numbering rules.
5. Module and AI entitlements delegated within sponsor ceilings.
6. City/organization knowledge libraries and named knowledge stewards.
7. Usage, cost, allowance, expiry, forecast, and overage controls.
8. Integration management with scoped credentials and health status.
9. Audit/export center with authorization-filtered packages.

## C. Project setup and control

1. **Project charter** — owner, sponsor, delivery method, contract, funding, location, jurisdiction, contacts, dates, value, risk class.
2. **Structure builder** — program/project/contract/area/discipline/specification/WBS hierarchy; versioned and effective-dated.
3. **Project parties** — contractual role is separate from application role; effective dates and authority limits.
4. **Workflow builder** — routing, reviews, clocks, escalation, quorum, response requirements; versioned; no retroactive mutation.
5. **Numbering and templates** — project-specific formats with collision checks and immutable issued numbers.
6. **Calendars** — full working periods, exceptions, holidays, time zone, inheritance, version lineage.
7. **Distribution and notification rules** — recipients derived server-side; delivery and receipt recorded.
8. **Project health setup** — KPIs, thresholds, reporting periods, risk appetite, required evidence.

## D. Core user modules

### 1. Home and Daily Project Success Brief

Role-filtered commitments, clocks, safety, schedule, cost, quality, decisions, missing evidence, and recommended next actions. Every claim shows source, freshness, confidence, and epistemic class. Insufficient evidence produces a refusal or a request for missing material.

### 2. Universal command center

Natural language and keyboard search across permitted records and help. It can navigate, explain, retrieve, compare, and draft. It may propose a transaction but never execute a formal action without showing the authoritative form, consequences, required evidence, and human confirmation.

### 3. Documents and drawings

Immutable versions, transmittals, revisions, supersession, OCR confidence, page coordinates, markups, review status, distribution, receipt, hashes, retention and legal hold.

### 4. Submittals

Register, specification linkage, packages/items, routing, revisions, review stamps, response codes, overdue clocks, distribution, downstream procurement/schedule impact. The system must distinguish recommendation from the design professional's formal action.

### 5. RFIs

Question, context, references, attachments, routing, responsible party, responses, revisions, cost/schedule assertions, closure, transmittal. AI drafts and finds conflicts but never declares responsibility or legal fault.

### 6. Daily reports and field capture

Weather source, labor, equipment, work areas, quantities, visitors, inspections, delays/assertions, safety observations, photos/video, signatures, offline capture, sync conflicts, sealing and append-only corrections.

### 7. Photos and evidence vault

Original media hash, capture/import metadata, location accuracy, timestamp provenance, custody events, annotations as separate layers, duplicate detection, access classification, export verification.

### 8. Schedule Intelligence

Immutable imports and lineage; provisional PDF extraction; XML/XLSX/CSV validation; full calendars; predecessor/resource joins; split/merge mapping; CPM checks; version comparison; delta ledger; dispositions as append-only events; run provenance; bounded recovery scenarios with sourced ranges and assumptions.

### 9. Look-ahead planning

Contract schedule linkage, constraints, commitments, weather, permits, inspections, materials, responsibility, weekly planning and variance. Look-ahead edits do not rewrite the contract schedule.

### 10. Cost, pay applications and funding

Contract/SOV, commitments, progress, stored materials, retainage, deductions, allowances, change linkage, budget/funding, review workflow, reconciliation and export. AI may detect inconsistencies and draft notes; accountable approvers authorize payment.

### 11. Change management

Potential change, notice, estimate, quotation, negotiation history, independent estimate, time-impact reference, funding, change order, signatures and incorporation. Assertions and approved determinations remain structurally distinct.

### 12. Meetings, decisions and action items

Agenda, attendance, transcript provenance, minutes, decisions, open items, owners, due dates, objections, revisions and distribution. AI-generated minutes require review before issue.

### 13. Correspondence, notices and transmittals

Drafting, contractual clock, authority, recipient validation, delivery method, receipt, attachments, package seal, revision/correction. Formal notice requires authorized human release.

### 14. Quality, inspections and nonconformance

Inspection plans, checklists, hold/witness points, tests, deficiencies, NCRs, corrective actions, verification and closure. Life-safety/design acceptance remains with qualified personnel.

### 15. Safety

Plans, observations, incidents, toolbox talks, permits, corrective actions and restricted medical/personal data. The product can alert and organize; it must never imply that software replaces the competent person or emergency procedures.

### 16. Permits, utilities and third parties

Agency requirements, submissions, comments, expiration, inspection dependencies, utility conflicts and commitments.

### 17. Claims and disputes workspace

Chronology, evidence, party assertions, disputed facts, notices, schedule/cost analyses, privilege/access markings and exports. ZecoCM never declares legal fault or entitlement.

### 18. Closeout and turnover

Punch lists, commissioning, training, warranties, O&M manuals, as-builts, asset data, final quantities, releases, acceptance milestones and archive verification.

### 19. Reports and agency-ready packages

Saved report definitions, provenance, as-of time, included/excluded scope, signatures, package hash, delivery/receipt and reproducible export. “Send to City” is a deliberate authorized release, not a generic download.

### 20. Knowledge and learning

Project, organization, city, regulatory, help and anonymized-learning libraries; immutable sources/passages; review queue; promotion; supersession; city atlas; AI runs; feedback; evaluations and usage.

## E. Personal and account functionality

1. One login; account determines the world; no role picker or role query parameter.
2. Profile, verified contact methods, password, MFA, trusted sessions, device/session revocation.
3. Accessible avatar/logo upload with type, size, malware and image validation; crop preview and removal.
4. Notification preferences bounded by mandatory contractual/security notifications.
5. Saved views, favorites, recent work and drafts without cross-tenant leakage.
6. Correct sign-out: revoke server token, clear local sensitive state, return to login; Back must not reopen protected data.

## F. Navigation contract

- Browser Back/Forward restores URL-addressable state without losing unsaved work silently.
- Refresh restores the authorized session and route; stale/unauthorized routes fail closed.
- Every list supports server-side search, filters, sort, pagination and truthful totals.
- Deep links re-check tenant, project, role, section, record and field access.
- Breadcrumbs represent hierarchy; they do not substitute for browser history.
- Unsaved edits trigger an accessible confirmation; completed saves return a stable record URL.

## G. Release completeness rule

A module is not operational until its permissions, data model, workflow, audit trail, error/empty/loading/offline states, notifications, exports, accessibility, security tests, migration and rollback are complete. A visually finished screen alone is not a finished module.
