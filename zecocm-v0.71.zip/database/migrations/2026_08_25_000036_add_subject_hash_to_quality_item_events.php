<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * What the record said at the moment the event was written.
 *
 * The events on a deficiency are sealed. The deficiency itself was not. None of
 * its own text lives in any event payload, so its description could be rewritten
 * after the fact - "measured 24 inches against a specified 36" becoming something
 * softer - and every hash in the chain would still verify. The chain would be
 * telling the truth about a document that had changed underneath it.
 *
 * Each event now fingerprints the subject as it stood when the event was
 * written. Comparing the newest event's fingerprint against the record as it
 * stands today answers the question the chain could not: has the thing this
 * evidence describes been altered since anybody last said anything about it?
 *
 * Nullable, because events written before this carry no fingerprint and are not
 * going to acquire one. Saying that is better than backfilling a value that
 * would assert something nobody witnessed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('quality_item_events', function (Blueprint $t) {
            $t->string('subject_hash', 128)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('quality_item_events', function (Blueprint $t) {
            $t->dropColumn('subject_hash');
        });
    }
};
