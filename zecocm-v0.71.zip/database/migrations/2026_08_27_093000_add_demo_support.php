<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Two distinct demo paths, per Amin's direction (2026-08-27):
 *  - Instant, self-serve, limited demo: anyone can get one on the spot. That's just a Tenant
 *    flagged `is_demo` with an expiry, using the exact same provisioning shape as a real paid
 *    account (no second, divergent "how a tenant gets created" code path).
 *  - "Request a full demo" for entities/contractors who want the whole product shown to them:
 *    a lightweight lead queue a human follows up on and schedules manually - NOT an account, so
 *    it gets its own small table rather than overloading `contractor_registrations` (which is
 *    specifically a paid-signup state machine) or `tenants` (which is specifically real/demo
 *    accounts).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $t) {
            $t->boolean('is_demo')->default(false)->after('status');
            $t->timestamp('demo_expires_at')->nullable()->after('is_demo');
        });

        Schema::create('demo_requests', function (Blueprint $t) {
            $t->id();
            $t->string('company');
            $t->string('contact_name');
            $t->string('email');
            $t->string('phone')->nullable();
            $t->string('entity_type')->nullable(); // contractor|agency|other — free text, not enum-enforced
            $t->text('note')->nullable();
            $t->string('status')->default('pending'); // pending|contacted|scheduled|closed
            $t->timestamps();

            $t->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('demo_requests');
        Schema::table('tenants', function (Blueprint $t) {
            $t->dropColumn(['is_demo', 'demo_expires_at']);
        });
    }
};
