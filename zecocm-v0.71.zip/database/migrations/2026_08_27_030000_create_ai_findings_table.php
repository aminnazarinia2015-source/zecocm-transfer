<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - closed design, see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Codex's ruling that closed this design: TRACE observes and proposes, it
 * never adjudicates. So this table is deliberately NOT another payment
 * classification alongside PayApplicationReview's HARD_INVALID / RETURNABLE /
 * WITHHOLD (Gemini's original PROPOSED_WITHHOLD proposal was rejected for
 * exactly this reason - it let AI suggest a contractual payment remedy).
 * ai_findings is an orthogonal table: `category` describes what kind of
 * record relationship was found (never a payment conclusion), and every row
 * also carries a `finding_class` that must be one of OBSERVATION / DATA_GAP /
 * PROPOSAL - never an adjudication like "contractor is delayed" or "payment
 * is unsupported". That three-class rule is enforced in the AiFinding model,
 * not just this comment (see AiFinding::CLASSES and its creating() guard).
 *
 * A human converts a finding into something that touches the real payment
 * review workflow explicitly, by dismissing it or promoting it to a review
 * issue (status column) - PayApplicationReview::findings() itself stays a
 * pure computation with no persisted rows of its own to link against, so
 * "promoted" is recorded here as a fact about this finding, not a foreign
 * key into that domain.
 *
 * rule_id/rule_version let a later change to a rule's logic never silently
 * change what an old, already-reviewed pay application would have found -
 * an old finding keeps citing the rule version that actually produced it.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_findings', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('pay_application_id')->constrained();
            $t->foreignId('pay_application_review_context_id')->constrained();
            $t->foreignId('ai_run_id')->nullable()->constrained('ai_runs');
            $t->string('rule_id', 32); // e.g. TRACE-01
            $t->string('rule_version', 16); // e.g. 1.0
            // RECORD_MISMATCH | CORROBORATION_GAP | SCHEDULE_STATUS_MISMATCH |
            // MAPPING_GAP | DATA_STALENESS | PERIOD_ALIGNMENT_ISSUE
            $t->string('category', 32);
            $t->string('finding_class', 16); // OBSERVATION | DATA_GAP | PROPOSAL
            $t->string('severity', 16); // INFO | REVIEW | HIGH_ATTENTION
            $t->text('summary'); // what was actually and only observed - never a conclusion
            $t->json('searched_universe'); // what evidence sources were actually searched (Codex's point 8)
            $t->string('status', 16)->default('OPEN'); // OPEN | DISMISSED | PROMOTED
            $t->foreignId('resolved_by')->nullable()->constrained('users');
            $t->timestampTz('resolved_at')->nullable();
            $t->text('resolution_note')->nullable();
            $t->timestampTz('evaluated_at');
            $t->timestamps();
            $t->index(['tenant_id', 'pay_application_id']);
            $t->index(['tenant_id', 'status']);
            $t->index(['rule_id', 'rule_version']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_findings');
    }
};
