<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * How long a chain is supposed to be.
 *
 * A hash chain proves that the records still present have not been altered and
 * are in the order they were written. It proves nothing about records that are
 * no longer there. Delete the last event off a deficiency - the one that closed
 * it - and everything remaining still links perfectly, still hashes correctly,
 * and the verifier reports the chain intact.
 *
 * A cascade delete on a project does that to every chain at once, and nobody
 * has to intend it.
 *
 * The anchor is the outside witness. Every append writes one row here recording
 * what the chain's head was and how many records it then had, and the anchor
 * rows form their own single chain across ALL ledgers. Removing a record from
 * any ledger now requires forging this chain too, and forging this chain means
 * rewriting every anchor written since - including anchors for other tenants'
 * chains, which an attacker with a scoped session cannot even see.
 *
 * It is not a signature and it does not pretend to be. It converts silent
 * deletion into visible deletion, which is the difference between a record that
 * can lie by omission and one that cannot.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chain_anchors', function (Blueprint $t) {
            $t->id();
            $t->string('chain_name', 64);
            $t->string('chain_group', 64);
            $t->unsignedInteger('record_count');
            $t->string('head_hash', 128);
            $t->string('previous_anchor_hash', 128)->nullable();
            $t->string('anchor_hash', 128);
            $t->timestampTz('created_at');
            $t->index(['chain_name', 'chain_group']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('chain_anchors');
    }
};
