<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Chunked/resumable upload backend. Real project drawing sets routinely run 300-500MB
 * (Amin confirmed) and the app only ever accepted them via a single blocking multipart
 * POST - a dropped connection on jobsite wifi/cellular meant restarting the whole
 * multi-hundred-MB transfer from zero. This table is the session record for a chunked
 * upload: a client creates a session (declaring the target, the total size up front so
 * an oversized transfer is refused before a single byte moves), PUTs sequential chunks
 * against it, and finalizes it once every byte has arrived. The finalize step hands the
 * assembled file through the EXACT SAME SecureUploadGate scan + creation path a normal
 * single-shot upload uses (see DocumentLibraryController::admitAndCreateDocument /
 * admitAndCreateVersion) - chunking changes how bytes arrive, never what happens to them
 * once they do.
 *
 * Scoped to tenant + project + the uploading user exactly like every other write in this
 * app (ProjectAccess::authorize(), capability:documents middleware) - a session is a
 * capability to keep writing to one specific assembly file, and letting anyone but its
 * creator touch it would be exactly the kind of phantom-endpoint gap this audit pass has
 * repeatedly found and fixed elsewhere.
 *
 * `target`/`target_context` are deliberately generic (not "document_id" as a column) so
 * this same table can carry Knowledge-source and Schedule/CPM chunked uploads in a later
 * pass without a schema change - only 'document' and 'document_version' are wired to a
 * controller in this pass; see UploadSessionController's class doc.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('upload_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('target', 32);
            $table->json('target_context')->nullable();
            $table->string('original_filename', 255);
            $table->unsignedBigInteger('declared_total_bytes');
            $table->string('declared_content_type', 128)->nullable();
            $table->unsignedBigInteger('bytes_received')->default(0);
            $table->string('storage_path', 500);
            // in_progress -> completed (finalize succeeded) or failed (scan/creation error,
            // or an operator/cleanup command expired it). A terminal session never accepts
            // another chunk or another finalize call - see UploadSessionController.
            $table->string('status', 24)->default('in_progress');
            $table->string('failure_reason', 255)->nullable();
            $table->timestampsTz();
            $table->index(['tenant_id', 'project_id', 'status'], 'upload_session_scope_idx');
            // Abandoned-session cleanup (uploads:cleanup-abandoned-sessions, scheduled hourly
            // in routes/console.php) sweeps by age within status = in_progress.
            $table->index(['status', 'created_at'], 'upload_session_cleanup_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('upload_sessions');
    }
};
