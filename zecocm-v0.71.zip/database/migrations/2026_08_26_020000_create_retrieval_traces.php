<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TR-18: retrieval observability, per Codex's ruling captured in
 * claude/tr-18-design-brief.md.
 *
 * One row per TRACE retrieval, deliberately structured rather than
 * free-text: what query ran, what filtering happened at each stage and why
 * (never model chain-of-thought), which candidates survived to be shown to
 * the model, and which of those were ultimately cited. Never stores passage
 * BODY TEXT - only locators (source public id, version number, ordinal, body
 * hash) and scoring/authority facts, so this table is never a second copy of
 * evidence content and never a bigger attack surface than the citations a
 * result already carries.
 *
 * Write-once: a retrieval already happened by the time this row is created,
 * and nothing about the past ever needs correcting - only a new retrieval,
 * with its own row, reflects new inputs or a new retriever_version.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('retrieval_traces', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->nullable()->constrained();
            $t->foreignId('ai_run_id')->nullable()->constrained('ai_runs');
            $t->string('query', 2000);
            $t->string('retriever_version', 64);
            $t->json('chunking_versions'); // list<string>, unique versions actually touched
            $t->json('authorization_state'); // {authorized_evidence_read, tenant_id, project_id, corpora}
            $t->unsignedInteger('sql_candidate_count');
            $t->json('stages'); // ordered list of {stage, excluded: [{source_public_id, version_number, ordinal, reason}], ...}
            $t->json('final_candidates'); // list of locator+scoring+authority facts, no body text
            $t->json('passages_cited'); // list<anchor-or-locator> ultimately cited, per the result kind
            $t->string('result_kind', 24)->nullable(); // suggestion | escalation | no_match
            $t->string('escalation_basis', 32)->nullable();
            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id']);
            $t->index(['ai_run_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('retrieval_traces');
    }
};
