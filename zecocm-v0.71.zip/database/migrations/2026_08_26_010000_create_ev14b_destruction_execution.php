<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * EV-14B: verified destruction execution, gated on DATA-1's storage
 * topology. Per Codex's ruling: StorageInventory::report() only proves where
 * the primary disk is rooted, not "complete destruction topology known" - so
 * this migration adds an explicit, versioned table of every GOVERNED storage
 * location an object may exist in, and the executor below refuses to run
 * against an unknown topology rather than silently assuming primary-only.
 *
 * evidence_tombstones.state stays exactly what EV-14A wrote
 * (AUTHORIZED_PENDING_EXECUTION forever, per EvidenceTombstone's append-only
 * guard) - execution progress is recorded in a separate append-only ledger,
 * evidence_tombstone_execution_events, resolved the same way HoldStatus
 * resolves hold state: latest event wins, never a mutable "current state"
 * column.
 */
return new class extends Migration
{
    public function up(): void
    {
        // Deliberately small and explicit. Codex: "If backups are not yet
        // present, say so. Do not invent them." v1 seeds exactly one row -
        // the primary evidence disk DATA-1 already made deployment-
        // independent. When DATA-2 lands off-host backup, that adds a row
        // here; it does not change any code in EV-14B.
        Schema::create('evidence_storage_locations', function (Blueprint $t) {
            $t->id();
            $t->string('location_key', 40)->unique();
            $t->string('type', 24); // primary | object_version | replica | backup | export_cache | other
            $t->string('disk', 40)->nullable(); // Laravel disk name, when applicable
            $t->boolean('governed')->default(true);
            $t->string('destruction_capability', 24); // immediate | lifecycle | unsupported
            $t->string('verification_method', 40);
            $t->string('retention_behavior', 40)->default('none');
            $t->boolean('versioning_enabled')->default(false);
            $t->timestamp('effective_from');
            $t->timestamp('effective_to')->nullable();
            $t->timestamps();
        });

        // Append-only. The tombstone row itself never changes (EV-14A's
        // guard); "what happened during execution" lives here instead, one
        // event per state transition, exactly the ledger pattern
        // legal_hold_events already established for this codebase.
        Schema::create('evidence_tombstone_execution_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('evidence_tombstone_id')->constrained('evidence_tombstones');
            $t->string('state', 48);
            $t->foreignId('actor_id')->nullable()->constrained('users');
            $t->json('detail')->nullable();
            $t->timestamp('occurred_at');
            $t->timestamps();
            $t->index(['tenant_id', 'evidence_tombstone_id']);
        });

        // One row per (tombstone, governed location) destruction attempt.
        // Append-only per attempt - a retried worker adds a new row rather
        // than mutating the old one, so "what did we actually observe last
        // time" is never lost to an overwrite.
        Schema::create('evidence_destruction_location_results', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('evidence_tombstone_id')->constrained('evidence_tombstones');
            $t->string('location_key', 40);
            $t->timestamp('attempted_at');
            $t->string('expected_digest', 64);
            $t->boolean('pre_delete_presence')->nullable();
            $t->string('delete_result', 24)->nullable(); // deleted | not_found | error | skipped
            $t->boolean('post_delete_presence')->nullable();
            $t->string('verification_method', 40);
            $t->timestamp('verified_at')->nullable();
            $t->text('error')->nullable();
            $t->timestamps();
            $t->index(['tenant_id', 'evidence_tombstone_id', 'location_key']);
        });

        DB::table('evidence_storage_locations')->insert([
            'location_key' => 'primary',
            'type' => 'primary',
            'disk' => 'local',
            'governed' => true,
            'destruction_capability' => 'immediate',
            'verification_method' => 'sha256_absence_check',
            'retention_behavior' => 'none',
            'versioning_enabled' => false,
            'effective_from' => now(),
            'effective_to' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('evidence_destruction_location_results');
        Schema::dropIfExists('evidence_tombstone_execution_events');
        Schema::dropIfExists('evidence_storage_locations');
    }
};
