<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Found by a "what if" pass: the first-login password-setup signed link
 * (SetPasswordController@store) had no way to tell "this link has already been used" from "this
 * link has never been used" - Laravel's `signed` middleware only checks the URL's HMAC signature
 * and expiry, not one-time use. That meant anyone holding a copy of the link (a shared inbox, a
 * forwarded email, a screenshot) could silently overwrite the account's password at any point
 * within its 7-day window, even long after the real admin had already set their password and
 * started using the account normally. This column is the one-time-use marker: null means "no
 * password has ever been set via a signed link yet" (the only state store() will act on), and a
 * timestamp means "already used" (every later attempt with any link - the same one or a
 * regenerated one - is refused). It is not tenant-scoped since it is a fact about the User row
 * itself, not the platform-staff "regenerate password link" workflow.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->timestamp('password_set_at')->nullable()->after('password');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('password_set_at');
        });
    }
};
