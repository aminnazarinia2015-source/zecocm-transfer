<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * D4 confidence-gap follow-up. The OCR measurement lab (rounds 3-5) established that mean
 * OCR confidence, at any granularity Tesseract exposes, cannot see a digit destroyed by
 * becoming a non-digit — "$1,608,540.00" read as "$:" + "608,540.00" carried 84.9 confidence
 * on a page whose mean was 95.2, and classified RELIABLE under the confidence-only rule
 * shipped at v0.92. This column is a second, independent signal: whether
 * StructuralWellFormedness found at least one token on the page that announces an
 * evidentiary shape (currency, date, dimension, percent, a detail/sheet reference) without
 * satisfying it. `ExtractionReliability::classify()` forces UNRELIABLE whenever this is true,
 * regardless of how high the page's mean confidence otherwise reads.
 *
 * Never backfilled onto historical data, same rule DATA-3/D4 already established for this
 * table: populated only for pages processed after this row lands. An existing page with
 * `has_structural_defect` false is honestly silent (never checked), not falsely cleared.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('knowledge_source_pages', function (Blueprint $t) {
            $t->boolean('has_structural_defect')->default(false)->after('extraction_confidence');
            $t->json('structural_findings')->nullable()->after('has_structural_defect');
        });
    }

    public function down(): void
    {
        Schema::table('knowledge_source_pages', function (Blueprint $t) {
            $t->dropColumn(['has_structural_defect', 'structural_findings']);
        });
    }
};
