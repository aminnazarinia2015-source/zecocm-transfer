<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * A5: what has been released, and what somebody is claiming against the money.
 *
 * These are two different questions that look like one because they both live
 * in the payment file, and conflating them is the classic error:
 *
 *   A RELEASE is a claimant saying "you no longer owe me for work through this
 *   date". It reduces future exposure. It is evidence the owner collects.
 *
 *   A STOP PAYMENT NOTICE is a claimant saying "do not pay the contractor,
 *   because it owes me". It does not reduce anything - it FREEZES money that is
 *   otherwise payable, in the owner's hands.
 *
 * Netting one against the other, or treating a signed release as an answer to a
 * served stop notice, is how an owner ends up paying twice. They are recorded
 * separately here and are never summed anywhere in this codebase.
 *
 * On California public works the governing law is Civil Code Part 6 Title 3
 * (Works of Improvement), sections 8130 and following for waiver and release
 * forms, and 9350 and following for public-works stop payment notices. This
 * table records the FACTS of a release or a notice - who, how much, through
 * when, served how. It deliberately does not reproduce the statutory form text
 * and it does not decide validity; validity is a legal determination and this
 * system's standing rule is that it retrieves, cites and refuses.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lien_releases', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('trade_partner_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('subcontract_id')->nullable()->constrained()->cascadeOnDelete();
            // The application this release was collected in support of. Nullable
            // because releases also arrive at closeout, unattached to any period.
            $t->foreignId('pay_application_id')->nullable()->constrained()->cascadeOnDelete();

            // conditional_progress   Civil Code s. 8132
            // unconditional_progress Civil Code s. 8134
            // conditional_final      Civil Code s. 8136
            // unconditional_final    Civil Code s. 8138
            $t->string('form_type', 32);
            $t->string('claimant_name', 200);

            // The single most misread field on the form. A release runs THROUGH
            // A DATE. Work performed after it is not released, however large the
            // amount on the face of the paper.
            $t->date('through_date')->nullable();
            $t->bigInteger('amount_cents')->default(0);

            // Disputed claims and retention the claimant is expressly not
            // releasing. Recorded as text because that is how the form carries
            // it, and an empty box is not the same as "none stated".
            $t->text('exceptions')->nullable();
            $t->boolean('exceptions_stated')->default(false);

            $t->string('signed_by', 160)->nullable();
            $t->date('signed_on')->nullable();
            $t->boolean('document_on_file')->default(false);

            // A CONDITIONAL release is not a release until the payment it is
            // conditioned on actually clears. Holding one for a cheque that
            // bounced is holding a promise, not a release - so the evidence of
            // clearing is a separate recorded fact, never inferred from the
            // existence of the form.
            $t->date('payment_cleared_on')->nullable();
            $t->string('payment_reference', 120)->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'form_type']);
            $t->index(['project_id', 'through_date']);
        });

        Schema::create('stop_payment_notices', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('trade_partner_id')->nullable()->constrained()->nullOnDelete();

            $t->string('claimant_name', 200);
            $t->string('claimant_role', 64)->nullable();
            $t->bigInteger('claimed_amount_cents');
            $t->date('served_on');
            $t->string('served_method', 64)->nullable();

            // Civil Code s. 9300: a claimant without a direct contract with the
            // public entity must have given preliminary notice. Recorded as a
            // fact, NOT used to decide the notice is bad - that is a lawyer's
            // call and an owner who releases withheld money on this software's
            // say-so has taken on the risk personally.
            $t->boolean('preliminary_notice_on_file')->default(false);
            $t->date('preliminary_notice_served_on')->nullable();

            // open | released | bonded_around | withdrawn | forfeited
            $t->string('status', 24)->default('open');
            $t->date('resolved_on')->nullable();
            $t->string('resolution_reference', 200)->nullable();
            // s. 9364: the contractor may give a release bond in 125 per cent of
            // the claim, which frees the withheld funds. The bond has to be on
            // file for that to have happened.
            $t->boolean('release_bond_on_file')->default(false);

            $t->text('notes')->nullable();
            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stop_payment_notices');
        Schema::dropIfExists('lien_releases');
    }
};
