<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The companies doing the work, and the credentials that let them.
 *
 * A16 in the register, flagged there as foundational because three blocking
 * rows hang off it: pay applications need somebody to pay, stop notices and
 * lien releases need somebody to release, and bond and insurance tracking needs
 * somebody to be insured. It closes A6 with it, because a CSLB licence, a DIR
 * registration, a payment bond and a certificate of insurance are the same
 * shape - an issuer, a number, a window it is good for, and a consequence when
 * it lapses.
 *
 * The thing that makes this worth building rather than a contacts table:
 *
 *   THE QUESTION IS NEVER "IS THIS LICENCE CURRENT". It is "was it current on
 *   the day that work was done". A sub whose licence lapsed in March and was
 *   reinstated in May looks perfectly fine today and was unlicensed for the
 *   April pour. Under Business and Professions Code s. 7031 an unlicensed
 *   contractor cannot enforce payment and can be made to disgorge what it was
 *   already paid - so the date matters more than the status.
 *
 * DIR registration is the same shape and worse consequences: Labor Code
 * s. 1725.5 bars an unregistered contractor from bidding or working on public
 * work at all, and the awarding body can be penalised for letting it happen.
 *
 * WHAT THIS DELIBERATELY DOES NOT STORE: tax identification numbers, social
 * security numbers, bank details, or any individual's personal information.
 * Licence and DIR numbers are public record and belong here. A vendor's EIN
 * does not, and the standing rule on this project is that personal and
 * financial identifiers never enter this system.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('trade_partners', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->string('legal_name', 200);
            $t->string('dba', 200)->nullable();
            // subcontractor | supplier | consultant | trucking | staffing
            $t->string('partner_type', 32)->default('subcontractor');
            $t->string('primary_trade', 120)->nullable();
            $t->string('address_line', 200)->nullable();
            $t->string('city', 96)->nullable();
            $t->string('state', 8)->nullable();
            $t->string('postal_code', 16)->nullable();
            $t->string('contact_name', 160)->nullable();
            $t->string('contact_email', 200)->nullable();
            $t->string('contact_phone', 40)->nullable();
            $t->string('status', 24)->default('active');
            $t->string('notes', 1000)->nullable();
            $t->timestampsTz();
            $t->index(['tenant_id', 'legal_name']);
        });

        Schema::create('subcontracts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('trade_partner_id')->constrained()->cascadeOnDelete();
            $t->string('number', 32);
            $t->string('scope_description', 500);
            // Listed at bid under the Subletting and Subcontracting Fair
            // Practices Act. A listed sub cannot simply be swapped out - PCC
            // s. 4107 requires the awarding authority's consent, so the fact of
            // listing has to be recorded rather than inferred.
            $t->boolean('listed_at_bid')->default(false);
            $t->string('bid_listing_reference', 120)->nullable();
            $t->bigInteger('original_amount_cents')->default(0);
            $t->unsignedInteger('retention_basis_points')->nullable();
            $t->date('executed_on')->nullable();
            // draft | executed | substituted | terminated | complete
            $t->string('status', 24)->default('draft');
            $t->timestampsTz();
            $t->unique(['project_id', 'number']);
        });

        Schema::create('compliance_credentials', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('trade_partner_id')->nullable()->constrained()->cascadeOnDelete();
            // A credential can belong to a company generally or to one contract
            // (a payment bond is written for a specific subcontract).
            $t->foreignId('subcontract_id')->nullable()->constrained()->cascadeOnDelete();
            // cslb_license | dir_registration | general_liability | auto_liability
            // | workers_comp | umbrella | payment_bond | performance_bond
            $t->string('credential_type', 40);
            $t->string('identifier', 96)->nullable();
            $t->string('issuer', 200)->nullable();
            $t->bigInteger('limit_cents')->nullable();
            $t->date('effective_from')->nullable();
            $t->date('expires_on')->nullable();
            // Whether a person has actually looked at the certificate, as
            // opposed to somebody having typed a number into a box.
            $t->boolean('document_on_file')->default(false);
            $t->foreignId('verified_by')->nullable()->constrained('users');
            $t->timestampTz('verified_at')->nullable();
            $t->string('notes', 1000)->nullable();
            $t->timestampsTz();
            $t->index(['tenant_id', 'trade_partner_id', 'credential_type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('compliance_credentials');
        Schema::dropIfExists('subcontracts');
        Schema::dropIfExists('trade_partners');
    }
};
