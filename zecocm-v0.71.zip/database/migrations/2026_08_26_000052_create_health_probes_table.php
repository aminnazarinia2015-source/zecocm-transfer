<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * OPS-15: a table for the one row DatabaseWriteHealthCheck upserts on every
 * `/up` request. This is not tenant data and carries no evidentiary weight -
 * it exists purely so `/up` proves the database is WRITABLE (Codex's
 * closure requirement: "a failing dependency must make /up fail"), not
 * merely reachable. `SELECT 1` cannot see a write-lock pathology; C1's
 * whole history was a write-contention defect a read-only probe is blind
 * to. Deliberately not tenant-scoped and not append-only: this is
 * operational plumbing, not a record.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('health_probes', function (Blueprint $table) {
            $table->id();
            $table->timestamp('probed_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('health_probes');
    }
};
