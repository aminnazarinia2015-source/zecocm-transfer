<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * AUTO-2's fourth seeded action (pay_app_draft_rollforward, per Amin's direct
 * product override of the PN 851 usage-evidence sequencing and Codex's
 * narrowed ruling on it): what created this application, if a human didn't.
 *
 * Same shape and same reason as tasks.autonomous_action_id - never a
 * required column, since a person creates most pay applications by hand
 * through PayApplicationController::store(). Never backfilled onto existing
 * rows: this column answers "did the system create this one," and a row
 * created before this migration existed was, as a fact, created by a human.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pay_applications', function (Blueprint $t) {
            $t->unsignedBigInteger('autonomous_action_id')->nullable()->index();
        });
    }

    public function down(): void
    {
        Schema::table('pay_applications', function (Blueprint $t) {
            $t->dropColumn('autonomous_action_id');
        });
    }
};
