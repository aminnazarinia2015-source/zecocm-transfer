<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Where the money on a line actually came from.
 *
 * A cumulative-total check cannot see this. Codex's case: a line authorized at
 * $100,000, $70,000 of original scope earned, $20,000 of pending change-order work
 * performed, and $90,000 billed against the original line. Cumulative billing
 * stays under the cap, so a simple over-billing validator passes it - while
 * $20,000 of unapproved change value rides inside an original contract line.
 *
 * That is the abuse the industry rule exists to prevent: change work belongs on
 * its own line. Recording the origin makes the hidden case detectable instead of
 * relying on the total, which is exactly where the total is blind.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            // Value on this line attributable to a change order that is NOT yet
            // approved. Non-zero on an original contract line is a finding.
            $t->unsignedBigInteger('pending_change_value_cents')->default(0)->after('stored_materials_cents');
            $t->foreignId('change_order_id')->nullable()->after('pending_change_value_cents');
        });
    }

    public function down(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            $t->dropColumn(['pending_change_value_cents', 'change_order_id']);
        });
    }
};
