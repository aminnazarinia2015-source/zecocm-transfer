<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('plan_sheets', function (Blueprint $table) {
            $table->string('category', 48)->default('general')->after('discipline');
            $table->index(['tenant_id', 'project_id', 'category'], 'plan_sheet_scope_category_idx');
        });

        Schema::create('plan_revision_reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_version_id')->constrained()->restrictOnDelete();
            $table->string('disposition', 24);
            $table->text('determination');
            $table->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('reviewed_at');
            $table->timestampsTz();
            $table->unique('plan_sheet_version_id');
            $table->index(['tenant_id', 'project_id', 'disposition'], 'plan_review_scope_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plan_revision_reviews');
        Schema::table('plan_sheets', function (Blueprint $table) {
            $table->dropIndex('plan_sheet_scope_category_idx');
            $table->dropColumn('category');
        });
    }
};
