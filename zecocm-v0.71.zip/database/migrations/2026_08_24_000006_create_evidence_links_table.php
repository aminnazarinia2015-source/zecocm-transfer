<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Universal many-to-many evidence tagging (Addendum J):
        // stored once, linked everywhere, links never touch the media.
        Schema::create('evidence_links', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('media_item_id')->constrained();
            $t->morphs('record');               // record_type + record_id: RFI, CO, daily, payapp line...
            $t->foreignId('linked_by')->constrained('users');
            $t->timestamps();
            $t->unique(['media_item_id', 'record_type', 'record_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('evidence_links');
    }
};
