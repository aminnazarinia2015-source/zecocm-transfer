<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * EV-13: every stored digest now carries the algorithm that produced it,
 * independently of the payload's canonicalization version (hash_version).
 * Encoding and digest are two different axes - a record can change how it is
 * canonicalized without its digest algorithm changing, and vice versa - and
 * conflating them was exactly the gap this row closes.
 *
 * Existing rows are backfilled to 'sha256', not guessed: sha256 is literally
 * the only algorithm this codebase has ever called for an evidentiary digest,
 * in every one of the eight sites this row touches. Recording that fact is
 * documenting history, not asserting one; DigestAlgorithm::KNOWN still governs
 * what a verifier is entitled to accept going forward.
 */
return new class extends Migration
{
    public function up(): void
    {
        foreach (['knowledge_review_events', 'quality_item_events'] as $table) {
            if (Schema::hasTable($table) && ! Schema::hasColumn($table, 'hash_algorithm')) {
                Schema::table($table, function (Blueprint $t) {
                    $t->string('hash_algorithm', 16)->nullable()->after('hash_version');
                });
                DB::table($table)->whereNotNull($table === 'knowledge_review_events' ? 'event_hash' : 'event_hash')
                    ->update(['hash_algorithm' => 'sha256']);
            }
        }

        if (Schema::hasTable('quality_item_events') && ! Schema::hasColumn('quality_item_events', 'subject_hash_algorithm')) {
            Schema::table('quality_item_events', function (Blueprint $t) {
                $t->string('subject_hash_algorithm', 16)->nullable()->after('subject_hash');
            });
            DB::table('quality_item_events')->whereNotNull('subject_hash')->update(['subject_hash_algorithm' => 'sha256']);
        }

        if (Schema::hasTable('chain_anchors') && ! Schema::hasColumn('chain_anchors', 'anchor_hash_algorithm')) {
            Schema::table('chain_anchors', function (Blueprint $t) {
                $t->string('anchor_hash_algorithm', 16)->nullable()->after('anchor_hash');
            });
            DB::table('chain_anchors')->update(['anchor_hash_algorithm' => 'sha256']);
        }
    }

    public function down(): void
    {
        foreach (['knowledge_review_events', 'quality_item_events'] as $table) {
            if (Schema::hasTable($table) && Schema::hasColumn($table, 'hash_algorithm')) {
                Schema::table($table, fn (Blueprint $t) => $t->dropColumn('hash_algorithm'));
            }
        }

        if (Schema::hasTable('quality_item_events') && Schema::hasColumn('quality_item_events', 'subject_hash_algorithm')) {
            Schema::table('quality_item_events', fn (Blueprint $t) => $t->dropColumn('subject_hash_algorithm'));
        }

        if (Schema::hasTable('chain_anchors') && Schema::hasColumn('chain_anchors', 'anchor_hash_algorithm')) {
            Schema::table('chain_anchors', fn (Blueprint $t) => $t->dropColumn('anchor_hash_algorithm'));
        }
    }
};
