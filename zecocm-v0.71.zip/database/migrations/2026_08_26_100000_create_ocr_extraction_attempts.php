<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * VIS-1 (low-quality scan recovery): Codex's ruling was explicit that a poor
 * scan gets multiple bounded, deterministic recovery attempts, and every
 * attempt is recorded - never overwritten, never silently discarded once a
 * later attempt succeeds. This table is the append-only attempt log: one row
 * per (page, preprocessing variant) combination actually run, carrying
 * exactly what produced it (transform sequence, render DPI, the exact image
 * bytes OCR'd) and what it measured (confidence, structural-defect result,
 * the resulting ExtractionReliability classification).
 *
 * `selected` marks the one attempt per page that KnowledgeSourcePage's own
 * fields were populated from (via `ocr_extraction_attempt_id`), chosen by a
 * deterministic rule (ScanRecoveryPipeline::selectBest) - never by which
 * attempt happened to run last.
 *
 * VIS-1C: `image_sha256` + `image_width`/`image_height` + `transform_sequence`
 * + `render_dpi` together are the "VisualPageAsset" data Codex asked to be
 * exposed now, so a later vision-model feature (VIS-2+) has a canonical,
 * provenance-tracked page-image derivative to resolve coordinates against
 * instead of re-deriving this mapping from scratch.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ocr_extraction_attempts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_version_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('page_number');
            $t->unsignedInteger('attempt_ordinal');
            // baseline | grayscale_contrast | deskew | retry_300dpi | retry_300dpi_full
            $t->string('label', 32);
            $t->json('transform_sequence');
            $t->unsignedInteger('render_dpi');
            $t->string('ocr_engine', 48)->nullable();
            $t->string('ocr_engine_version', 32)->nullable();
            $t->decimal('mean_confidence', 5, 4)->nullable();
            $t->boolean('has_structural_defect')->default(false);
            // reliable | review_recommended | unreliable
            $t->string('reliability', 24);
            $t->string('image_sha256', 64)->nullable();
            $t->unsignedInteger('image_width')->nullable();
            $t->unsignedInteger('image_height')->nullable();
            $t->unsignedInteger('runtime_ms')->nullable();
            $t->boolean('selected')->default(false);
            $t->timestampTz('created_at')->useCurrent();
            $t->unique(['knowledge_source_version_id', 'page_number', 'attempt_ordinal'], 'ocr_attempt_unique_ordinal');
            $t->index(['tenant_id', 'project_id'], 'ocr_extraction_attempt_scope_idx');
        });

        Schema::table('knowledge_source_pages', function (Blueprint $t) {
            $t->foreignId('ocr_extraction_attempt_id')->nullable()->after('render_dpi')
                ->constrained('ocr_extraction_attempts')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('knowledge_source_pages', function (Blueprint $t) {
            $t->dropConstrainedForeignId('ocr_extraction_attempt_id');
        });
        Schema::dropIfExists('ocr_extraction_attempts');
    }
};
