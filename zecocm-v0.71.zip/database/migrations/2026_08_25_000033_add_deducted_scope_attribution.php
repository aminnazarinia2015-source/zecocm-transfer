<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Which remaining scope this money is for, on a line a change order cut.
 *
 * We can see that a deductive change order removed value from a line and that
 * somebody is still billing against it. We cannot see whether this particular
 * money is the part that was removed - a schedule-of-values line is a dollar
 * figure, not an inventory. So the person billing writes it down, and the answer
 * lives on the application instead of in somebody's memory two years later when
 * an auditor asks.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            $t->string('deducted_scope_attribution', 1000)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            $t->dropColumn('deducted_scope_attribution');
        });
    }
};
