<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Generic per-party document templates + signatures.
 *
 * Before this, "template + sign" existed twice, hardcoded, with no shared
 * concept: pay-application certification (hash-bind the numbers, void on
 * change) and daily-report worker sign-off (SignatureAttestation - one
 * immutable row per worker per day). Neither generalizes to "assign this
 * safety plan to the electrical sub and have their foreman sign it," which
 * is what a real project needs across trades.
 *
 * Three tables, deliberately kept separate rather than forced into one:
 *   - document_templates: the reusable shape (a project or org keeps a
 *     library of these - "Site Safety Plan", "Certified Payroll Statement",
 *     "Subcontractor Daily Sign-In" - each with its own field schema and an
 *     optional party_role so a template can say "this is for
 *     subcontractors" without naming a specific company).
 *   - template_assignments: one template handed to one party on one
 *     project. This is the thing that gets filled in and signed - never the
 *     template itself, which stays reusable.
 *   - signatures: a polymorphic, immutable attestation table generalizing
 *     both prior mechanisms - signable_type/signable_id so it can attach to
 *     a template_assignment today and to a pay application or daily report
 *     tomorrow without a schema change. content_hash binds a signature to
 *     the exact values it covered, the same principle as
 *     certified_content_hash on pay applications; void_at/void_reason let a
 *     signature be superseded without ever being rewritten or deleted -
 *     the present never rewrites the past.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('document_templates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('name', 128);
            $table->string('document_type', 64);
            $table->string('party_role', 64)->nullable();
            $table->json('fields');
            $table->longText('body')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('template_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('document_template_id')->constrained()->cascadeOnDelete();
            $table->string('party_label', 128);
            $table->foreignId('assigned_to_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('status', 16)->default('pending');
            $table->json('values')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('signatures', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('signable_type', 128);
            $table->unsignedBigInteger('signable_id');
            $table->foreignId('signer_id')->constrained('users')->cascadeOnDelete();
            $table->string('signer_name', 128);
            $table->string('content_hash', 64);
            $table->timestamp('signed_at');
            $table->json('signature_data')->nullable();
            $table->timestamp('void_at')->nullable();
            $table->string('void_reason', 500)->nullable();
            $table->timestamps();
            $table->index(['signable_type', 'signable_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('signatures');
        Schema::dropIfExists('template_assignments');
        Schema::dropIfExists('document_templates');
    }
};
