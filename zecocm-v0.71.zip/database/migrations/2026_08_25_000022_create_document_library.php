<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('document_folders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('parent_id')->nullable()->constrained('document_folders')->restrictOnDelete();
            $table->string('name', 160);
            $table->string('classification', 32)->default('project_private');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['project_id', 'parent_id', 'name']);
            $table->index(['tenant_id', 'project_id', 'parent_id'], 'document_folder_scope_idx');
        });

        Schema::table('knowledge_sources', function (Blueprint $table) {
            $table->foreignId('document_folder_id')->nullable()->after('project_id')->constrained('document_folders')->nullOnDelete();
            $table->string('original_filename', 255)->nullable()->after('title');
            $table->string('document_kind', 32)->default('other')->after('source_type');
            $table->index(['tenant_id', 'project_id', 'document_folder_id'], 'knowledge_document_folder_idx');
        });

        Schema::table('knowledge_source_versions', function (Blueprint $table) {
            $table->string('storage_path', 500)->nullable()->after('sha256');
            $table->string('mime_type', 128)->nullable()->after('storage_path');
            $table->unsignedBigInteger('byte_size')->nullable()->after('mime_type');
            $table->foreignId('uploaded_by')->nullable()->after('byte_size')->constrained('users')->nullOnDelete();
            $table->string('malware_scan_status', 24)->default('pending')->after('uploaded_by');
        });

        Schema::create('document_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('knowledge_source_id')->constrained()->cascadeOnDelete();
            $table->string('action', 32);
            $table->json('details')->nullable();
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('previous_event_hash', 64)->nullable();
            $table->string('event_hash', 64);
            $table->timestampsTz();
            $table->index(['tenant_id', 'project_id', 'knowledge_source_id'], 'document_event_scope_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('document_events');
        Schema::table('knowledge_source_versions', function (Blueprint $table) {
            $table->dropForeign(['uploaded_by']);
            $table->dropColumn(['storage_path', 'mime_type', 'byte_size', 'uploaded_by', 'malware_scan_status']);
        });
        Schema::table('knowledge_sources', function (Blueprint $table) {
            $table->dropForeign(['document_folder_id']);
            $table->dropIndex('knowledge_document_folder_idx');
            $table->dropColumn(['document_folder_id', 'original_filename', 'document_kind']);
        });
        Schema::dropIfExists('document_folders');
    }
};
