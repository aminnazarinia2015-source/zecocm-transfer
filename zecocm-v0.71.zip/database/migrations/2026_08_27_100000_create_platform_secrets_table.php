<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Lets an admin set a small, allow-listed set of secrets (starting with
 * ANTHROPIC_API_KEY) from inside the app instead of editing .env by hand
 * over SSH and re-running config:cache.
 *
 * Found the hard way this session: a working key sitting in .env did
 * nothing because config:cache had baked in the old value, and the only
 * fix available was a web SSH console where a stray Ctrl+W closed the
 * browser tab instead of driving nano, and a hand-typed sed corrupted the
 * key's value. None of that should ever be the only way to change a key.
 *
 * The value is stored encrypted with the app's own APP_KEY (Laravel's
 * Crypt facade) and is never returned to the client once saved - the UI
 * only ever shows whether a key is set, its length, and its last 4
 * characters, the same "prove it took effect without exposing it" pattern
 * PlatformController::systemSettings() already uses for Stripe/PayPal.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('platform_secrets', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('ciphertext');
            $table->unsignedBigInteger('updated_by_user_id')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('platform_secrets');
    }
};
