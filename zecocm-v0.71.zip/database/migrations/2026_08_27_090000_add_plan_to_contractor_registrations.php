<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The homepage offers three self-serve tiers (Field/Project/Program — see
 * public/home.html #pricing) but step 1 of registration never captured which one the
 * customer chose, and checkout() started every registration against a single hardcoded
 * Stripe price / PayPal plan. This column is the missing link: the tier a customer picked
 * drives which price/plan the payment provider charges AND which entitlements
 * RegistrationProvisioner grants once payment is confirmed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contractor_registrations', function (Blueprint $t) {
            $t->string('plan')->nullable()->after('email'); // field|project|program
        });
    }

    public function down(): void
    {
        Schema::table('contractor_registrations', function (Blueprint $t) {
            $t->dropColumn('plan');
        });
    }
};
