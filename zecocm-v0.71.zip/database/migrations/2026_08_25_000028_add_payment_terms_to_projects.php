<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Where the governing retention rule lives once a human has read it out of the
 * contract.
 *
 * Until somebody does that, the rule in force is the rate typed on the
 * application, carrying an explicit "nobody confirmed this" marker. That marker
 * is not a nag - a retention rate assumed rather than read is the single most
 * common reason a first payment application comes back.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $t) {
            $t->json('payment_terms')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $t) {
            $t->dropColumn('payment_terms');
        });
    }
};
