<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * AUTO-2: Governed Project Autopilot — the authorization/action substrate.
 *
 * Per Codex's ruling (claude/auto-1-auto-2-codex-ruling.md), autonomy is a
 * SEPARATE authorization question from capability licensing: a capability
 * grant answers "may this tenant use feature X at all"; an autonomy policy
 * answers "may the system perform action X without a human approving THIS
 * execution". A user can be licensed for pay applications while the system
 * remains forbidden from submitting one automatically.
 *
 * Three tables:
 *
 *   AUTONOMY_POLICIES     what a project has configured, per action type.
 *                         Frozen once active - an amendment supersedes rather
 *                         than edits in place, for the same reason a
 *                         confirmed ClaimRequirement is frozen: "what did this
 *                         project authorize the system to do, and when" must
 *                         stay answerable after the fact.
 *
 *   AUTONOMOUS_ACTIONS    the append-only, explainable log that is the actual
 *                         product surface (TRACE Project Steward). Every row
 *                         answers Amin's explainability requirement in full:
 *                         what triggered it, what rule authorized it, what
 *                         evidence it used, what it changed, whether a human
 *                         could or did intervene. The trigger/rule/evidence/
 *                         proposed-change identity of a row is frozen forever;
 *                         only its LIFECYCLE fields (status, notified_at,
 *                         approved_by/at, cancelled_by/at, executed_change,
 *                         executed_at) may ever move, and only forward - see
 *                         AutonomousAction's own booted() for the exact rule.
 *                         This is the same "immutable facts, mutable
 *                         workflow" split DestructionRequest already uses for
 *                         EV-14A, not a new idiom.
 *
 *   TASKS                 a generic project task/reminder record. Nothing
 *                         like this existed anywhere in the codebase before
 *                         AUTO-2 (confirmed by search) - every seeded AUTO-2
 *                         action that "creates a task/reminder" or "creates a
 *                         deliverable request" needs somewhere to put it, and
 *                         building it here (rather than overloading an
 *                         unrelated model) keeps AUTO-2's own surface
 *                         self-contained.
 *
 * Critically: the SYSTEM MAXIMUM autonomy level per action type is NOT a
 * column here at all. Per Codex's ruling it must be "hardcoded/system-
 * governed by action class, cannot be raised by customer configuration, not
 * even by an admin" - it lives in config/autonomy_action_ceilings.php,
 * checked into the codebase itself, the same pattern REL-1 used for
 * config/release_protected_regressions.php. A row in autonomy_policies can
 * only ever narrow the ceiling, never widen it - enforced in
 * AutonomyPolicyResolver, not in the schema.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('autonomy_policies', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->unsignedBigInteger('project_id')->index();
            $table->string('capability');
            $table->string('action_type')->index();
            // AUTO | AUTO_NOTIFY | APPROVAL_REQUIRED | HUMAN_ONLY | NOT_AUTOMATABLE
            $table->string('autonomy_level');
            $table->text('authority_source');
            $table->unsignedBigInteger('set_by');
            $table->timestamp('set_at');
            $table->timestamp('effective_at');
            // draft | active | superseded
            $table->string('status')->default('draft');
            $table->unsignedBigInteger('supersedes_policy_id')->nullable();
            $table->timestamps();

            $table->index(['tenant_id', 'project_id', 'action_type', 'status'], 'autonomy_policies_lookup');
        });

        Schema::create('autonomous_actions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->unsignedBigInteger('project_id')->index();
            $table->string('capability');
            $table->string('action_type')->index();
            $table->string('trigger_type');
            // list<array{type:string,id:int}> - which rows caused this, e.g. the
            // ClaimRequirement + ClaimClockCalculation that fired.
            $table->json('trigger_record_ids');
            $table->string('rule_id');
            $table->string('rule_version')->nullable();
            $table->unsignedBigInteger('autonomy_policy_id')->nullable();
            // The level actually applied: min(policy level, system ceiling),
            // or the system default when no policy row exists - see
            // AutonomyPolicyResolver. Frozen: this is what authorized whatever
            // happened next, not a live pointer that could later disagree with
            // the decision actually made.
            $table->string('effective_autonomy_level');
            $table->json('evidence_used');
            $table->json('proposed_change');
            $table->json('executed_change')->nullable();
            // proposed | executed | awaiting_notification | pending_approval |
            // awaiting_human | approved | cancelled | refused
            $table->string('status');
            $table->string('executed_by')->default('system');
            // none | notified | approved | cancelled | overridden
            $table->string('human_intervention_state')->default('none');
            $table->timestamp('executed_at')->nullable();
            $table->timestamp('notified_at')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->unsignedBigInteger('cancelled_by')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            // sha256 of {trigger_record_ids, rule_id, evidence_used,
            // proposed_change} - lets a later audit prove this row's
            // authorizing facts were not altered after creation, the same
            // reason REL-1 hashes a tarball rather than trusting its path.
            $table->string('result_hash');
            $table->timestamp('created_at');
        });

        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->unsignedBigInteger('project_id')->index();
            $table->string('task_type');
            $table->string('title');
            $table->text('detail')->nullable();
            $table->date('due_on')->nullable();
            // open | done | dismissed
            $table->string('status')->default('open');
            // What created this task, if anything did so autonomously - never
            // a required column, since a human can create a plain task too.
            $table->unsignedBigInteger('autonomous_action_id')->nullable()->index();
            // Loosely-typed link back to whatever this task is actually about
            // (a ClaimRequirement, a ClosoutDeliverable, ...) - deliberately a
            // polymorphic pair rather than a dedicated FK per source type,
            // since AUTO-2 seeds tasks from several unrelated domains.
            $table->string('subject_type')->nullable();
            $table->unsignedBigInteger('subject_id')->nullable();
            $table->unsignedBigInteger('completed_by')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['tenant_id', 'project_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('autonomous_actions');
        Schema::dropIfExists('autonomy_policies');
    }
};
