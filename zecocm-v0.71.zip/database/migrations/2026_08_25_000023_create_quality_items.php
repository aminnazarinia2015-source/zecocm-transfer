<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quality_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('number', 40);
            $table->string('kind', 24); // inspection|observation|deficiency|punch
            $table->string('title', 255);
            $table->text('description');
            $table->string('classification', 32)->default('fact');
            $table->string('severity', 16)->default('normal');
            $table->string('location', 255)->nullable();
            $table->string('spec_section', 64)->nullable();
            $table->string('drawing_reference', 128)->nullable();
            $table->string('assigned_organization', 160)->nullable();
            $table->date('due_at')->nullable();
            $table->string('status', 32)->default('open'); // verified projection of latest event
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['project_id', 'number']);
            $table->index(['tenant_id', 'project_id', 'status', 'severity'], 'quality_scope_idx');
        });

        Schema::create('quality_item_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('quality_item_id')->constrained()->cascadeOnDelete();
            $table->string('event_type', 32);
            $table->string('from_status', 32)->nullable();
            $table->string('to_status', 32);
            $table->text('note')->nullable();
            $table->string('classification', 32)->default('fact');
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('previous_event_hash', 64)->nullable();
            $table->string('event_hash', 64);
            $table->timestampsTz();
            $table->index(['tenant_id', 'project_id', 'quality_item_id'], 'quality_event_scope_idx');
        });

        Schema::create('quality_item_media', function (Blueprint $table) {
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('quality_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('media_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('linked_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('created_at')->useCurrent();
            $table->primary(['quality_item_id', 'media_item_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quality_item_media');
        Schema::dropIfExists('quality_item_events');
        Schema::dropIfExists('quality_items');
    }
};
