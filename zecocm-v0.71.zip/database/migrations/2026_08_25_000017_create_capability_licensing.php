<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Capability licensing + sponsorship model.
 *
 * Two requirements from the product owner (25 Aug 2026):
 *  1. Capabilities - above all the AI assistance tier - are licensed PER ACCOUNT,
 *     activatable/deactivatable individually and bounded by a TIME WINDOW
 *     (ten days, a month, two months, perpetual), tracked and auditable.
 *  2. Whoever purchases the system is the account owner and the highest authority
 *     in their own world: a City, a CM firm, a contractor or a designer may each be
 *     the buyer, and each may then define the counterparties beneath them as linked
 *     portals. A sponsor can never grant a portal more than the sponsor itself holds.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $t) {
            // The seat the PURCHASING organisation occupies. Not a fixed hierarchy:
            // owner_agency | cm_firm | contractor | designer | internal
            $t->string('sponsor_role', 32)->nullable()->after('type');
            // Set when this tenant is a portal created by another tenant (its sponsor).
            $t->unsignedBigInteger('parent_tenant_id')->nullable()->after('sponsor_role');
            // Optional branch/division label under one purchased account.
            $t->string('branch_name', 120)->nullable()->after('parent_tenant_id');
            // True for the tenant that bought the system: top of its own world.
            $t->boolean('is_account_owner')->default(false)->after('branch_name');
            $t->index('parent_tenant_id');
        });

        Schema::create('capability_grants', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->string('capability_key', 64);
            $t->string('status', 16)->default('active');      // active|suspended|revoked
            $t->dateTimeTz('starts_at');
            $t->dateTimeTz('ends_at')->nullable();            // null = perpetual
            $t->string('plan_reference', 120)->nullable();    // "AI Assist - 2 month pilot"
            $t->unsignedBigInteger('granted_by_user_id')->nullable();
            // null = granted by the ZecoCM platform; set = delegated by a sponsor tenant.
            $t->unsignedBigInteger('granted_by_tenant_id')->nullable();
            $t->string('reason', 255)->nullable();
            $t->boolean('metered')->default(false);
            $t->unsignedInteger('usage_limit')->nullable();   // null = unmetered within the window
            $t->unsignedInteger('usage_count')->default(0);
            $t->timestamps();
            $t->unique(['tenant_id', 'capability_key']);      // one live row; history lives in events
            $t->index(['tenant_id', 'status']);
        });

        // Append-only. Corrections and expiries append; nothing is overwritten.
        Schema::create('capability_grant_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->unsignedBigInteger('capability_grant_id')->nullable(); // survives revoke
            $t->string('capability_key', 64);
            $t->string('action', 32);   // granted|extended|suspended|resumed|revoked|expired|usage_recorded
            $t->dateTimeTz('effective_from')->nullable();
            $t->dateTimeTz('effective_until')->nullable();
            $t->unsignedBigInteger('actor_user_id')->nullable();
            $t->unsignedBigInteger('actor_tenant_id')->nullable();
            $t->string('reason', 255)->nullable();
            $t->json('before')->nullable();
            $t->json('after')->nullable();
            $t->string('correlation_id', 64)->nullable();
            $t->string('previous_event_hash', 64)->nullable();
            $t->string('event_hash', 64)->unique();
            $t->dateTimeTz('created_at');
            $t->index(['tenant_id', 'capability_key']);
        });

        $this->backfillExistingAccounts();
    }

    /**
     * Existing accounts keep exactly what they have today: every section already in
     * their entitlements list becomes an active, perpetual licence, and the first
     * tenant of each root account is marked as its own account owner. Introducing
     * licensing must not remove access anyone already had.
     */
    private function backfillExistingAccounts(): void
    {
        $now = now();
        foreach (DB::table('tenants')->get() as $tenant) {
            $sections = [];
            if (! empty($tenant->entitlements)) {
                $decoded = json_decode((string) $tenant->entitlements, true);
                if (is_array($decoded)) {
                    $sections = array_values(array_filter($decoded, 'is_string'));
                }
            }

            DB::table('tenants')->where('id', $tenant->id)->update([
                'is_account_owner' => true,
                'sponsor_role' => $this->inferSponsorRole((string) $tenant->type),
            ]);

            // Grandfather AI project assistance too: accounts live today already use it.
            foreach (array_unique(array_merge($sections, ['ai.assist'])) as $key) {
                DB::table('capability_grants')->insertOrIgnore([
                    'tenant_id' => $tenant->id,
                    'capability_key' => $key,
                    'status' => 'active',
                    'starts_at' => $now,
                    'ends_at' => null,                       // perpetual - unchanged from today
                    'plan_reference' => 'Grandfathered at licensing introduction',
                    'reason' => 'Existing access preserved when capability licensing was introduced',
                    'metered' => $key === 'ai.assist' ? 1 : 0,
                    'usage_count' => 0,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        }
    }

    private function inferSponsorRole(string $type): string
    {
        $t = strtolower($type);

        return match (true) {
            str_contains($t, 'city') || str_contains($t, 'agency') || str_contains($t, 'owner') => 'owner_agency',
            str_contains($t, 'cm') || str_contains($t, 'construction management') => 'cm_firm',
            str_contains($t, 'design') || str_contains($t, 'architect') || str_contains($t, 'engineer') => 'designer',
            str_contains($t, 'internal') => 'internal',
            default => 'contractor',
        };
    }

    public function down(): void
    {
        Schema::dropIfExists('capability_grant_events');
        Schema::dropIfExists('capability_grants');
        Schema::table('tenants', function (Blueprint $t) {
            $t->dropColumn(['sponsor_role', 'parent_tenant_id', 'branch_name', 'is_account_owner']);
        });
    }
};
