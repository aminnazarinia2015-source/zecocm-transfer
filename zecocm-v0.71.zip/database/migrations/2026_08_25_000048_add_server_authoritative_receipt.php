<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * B5 / EV-11. The old `confidence` column held strong|review|flagged, computed
 * entirely from numbers the client supplied. A client that lied consistently
 * earned STRONG; a superintendent with an unsynchronised phone earned FLAGGED.
 * The column measured self-consistency of unverified claims and displayed it
 * where a reader would read it as verification.
 *
 * It is not dropped, because dropping it would rewrite what historical records
 * asserted at the time they were made - and that is the one thing this codebase
 * does not do. It is superseded: every media item now also carries what the
 * SERVER knows, and the old value stays beside it as the claim it always was.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('media_items', function (Blueprint $t) {
            // Authoritative. The server's own clock at the moment the bytes
            // arrived, and the only time in this record a client cannot forge.
            $t->timestampTz('server_received_at')->nullable();
            // Also authoritative, and independently useful: a photograph that
            // arrived before another one arrived before it, whatever either
            // device claims about when they were taken.
            $t->unsignedBigInteger('receipt_sequence')->nullable();

            // server_receipt | device_claim
            $t->string('capture_time_basis', 24)->default('device_claim');
            // established_upper_bound | claim_consistent_with_bound
            // | claim_inconsistent_with_receipt | no_capture_claim
            $t->string('capture_finding', 40)->nullable();
            // Everything the device said, verbatim and unpromoted - including
            // EXIF where it exists. Evidence of what the file says about
            // itself, never evidence of when the shutter opened.
            $t->json('client_claims')->nullable();

            $t->index(['tenant_id', 'receipt_sequence']);
        });
    }

    public function down(): void
    {
        Schema::table('media_items', function (Blueprint $t) {
            $t->dropColumn(['server_received_at', 'receipt_sequence', 'capture_time_basis',
                'capture_finding', 'client_claims']);
        });
    }
};
