<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Change orders and time cards were the two remaining edit-before-seal record
 * types that lacked the before/after edit audit trail RFIs, submittals, and
 * quality items already have (added earlier this same audit after an
 * independent Gemini cross-check flagged the general gap). Both records are
 * typically edited by one party rather than handed back and forth between
 * two parties mid-review, so this was correctly triaged as lower priority -
 * but it's still a real gap: a corrected amount, title, or hours entry before
 * approval/determination left no trace of what the record used to say.
 * `edit_history` follows the same append-only JSON-array convention as RFI/
 * Submittal's `routing_history` - simple, consistent with the rest of the
 * app, no new mechanism needed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('change_orders', function (Blueprint $t) {
            $t->json('edit_history')->nullable()->after('seal');
        });
        Schema::table('time_cards', function (Blueprint $t) {
            $t->json('edit_history')->nullable()->after('determination');
        });
    }

    public function down(): void
    {
        Schema::table('change_orders', function (Blueprint $t) {
            $t->dropColumn('edit_history');
        });
        Schema::table('time_cards', function (Blueprint $t) {
            $t->dropColumn('edit_history');
        });
    }
};
