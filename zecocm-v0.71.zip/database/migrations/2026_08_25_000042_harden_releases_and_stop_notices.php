<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Four defects Codex found in A5 within an hour of it shipping. All four are
 * the same shape: the record was capable of stating more than the evidence
 * supported.
 *
 * 1. A RELEASE'S SCOPE COULD SILENTLY EXCEED THE PAYMENT. A conditional
 *    progress release through 31 August for $100,000 became "effective" the
 *    moment any payment was recorded as cleared - including a payment of
 *    $80,000. The statutory conditional form (Civil Code s. 8132) is effective
 *    only on receipt of the payment identified IN the release. Recording that
 *    the cheque cleared is not the same as recording that it cleared for the
 *    amount the release names, so the amount is now stored beside the date and
 *    a shortfall leaves the release partially unsatisfied.
 *
 * 2. EXCEPTIONS WERE FREE TEXT. A release preserving retention, extras, or
 *    "CO-12 unpaid" is a release that expressly did NOT release those things.
 *    Held as prose, nothing downstream can tell whether CO-12 was released, and
 *    the honest consequence - which this migration encodes - is that a release
 *    with unstructured exceptions may never be reported as having released any
 *    PARTICULAR item. Structured exceptions come next; refusing to answer is
 *    what the system does until then.
 *
 * 3. THE CLAIMED AMOUNT ON A SERVED NOTICE WAS MUTABLE. Civil Code s. 9352
 *    limits the claim to the amount due for work provided through the notice
 *    date. A served notice is a historical act; later unpaid work does not
 *    enlarge it. `served_amount_locked_at` records the moment it froze.
 *
 * 4. "SENT" WAS BEING READ AS "SERVED". The statute names who must receive a
 *    stop payment notice on a public work (Civil Code s. 9300 et seq., and for
 *    a non-state entity the controller, auditor, or disbursing officer). An
 *    email to the project inspector is evidence that an email was sent. Service
 *    effectiveness is now its own field and starts UNRESOLVED, because the
 *    software does not get to conclude that statutory service occurred.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('lien_releases', function (Blueprint $t) {
            // What actually cleared, against what the release names. Nullable
            // because "we have not recorded it" and "it cleared for zero" are
            // different facts and must not share a value.
            $t->bigInteger('payment_cleared_amount_cents')->nullable();
            // Set true only when a human has broken the exceptions text out
            // into addressable items. Until then no downstream answer may say
            // that any particular item was or was not released.
            $t->boolean('exceptions_structured')->default(false);
        });

        Schema::table('stop_payment_notices', function (Blueprint $t) {
            // prepared | sent | statutory_recipient_verified
            $t->string('service_state', 40)->default('prepared');
            // confirmed | unresolved - never inferred from the fact of sending.
            $t->string('service_effectiveness', 16)->default('unresolved');
            $t->string('served_to_role', 120)->nullable();
            $t->string('delivery_evidence', 255)->nullable();
            $t->timestampTz('served_amount_locked_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('lien_releases', function (Blueprint $t) {
            $t->dropColumn(['payment_cleared_amount_cents', 'exceptions_structured']);
        });

        Schema::table('stop_payment_notices', function (Blueprint $t) {
            $t->dropColumn(['service_state', 'service_effectiveness', 'served_to_role',
                'delivery_evidence', 'served_amount_locked_at']);
        });
    }
};
