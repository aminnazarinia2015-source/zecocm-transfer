<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * Two capabilities were added after licensing was introduced: the Daily Project
 * Success Brief and branded RFI/submittal transmittals. An upgrade must never take
 * away access someone already paid for, and it must never silently hand out something
 * they did not have. The rule applied here:
 *
 *   - an account already licensed for daily_reports OR schedule_intelligence gets
 *     daily_brief, because the brief is assembled from exactly those records;
 *   - an account already licensed for rfis OR submittals gets documents.transmittal,
 *     because the transmittal is a rendering of records it already holds.
 *
 * Grants are perpetual and clearly labelled so the audit trail explains itself.
 */
return new class extends Migration
{
    private const DERIVED = [
        'daily_brief' => ['daily_reports', 'schedule_intelligence'],
        'documents.transmittal' => ['rfis', 'submittals'],
    ];

    public function up(): void
    {
        $now = now();
        foreach (DB::table('tenants')->get() as $tenant) {
            $held = DB::table('capability_grants')
                ->where('tenant_id', $tenant->id)
                ->where('status', 'active')
                ->pluck('capability_key')
                ->all();

            foreach (self::DERIVED as $newKey => $prerequisites) {
                if (array_intersect($held, $prerequisites) === []) {
                    continue;
                }
                DB::table('capability_grants')->insertOrIgnore([
                    'tenant_id' => $tenant->id,
                    'capability_key' => $newKey,
                    'status' => 'active',
                    'starts_at' => $now,
                    'ends_at' => null,
                    'plan_reference' => 'Included with existing licence',
                    'reason' => 'Derived from records this account is already licensed for ('.implode(', ', $prerequisites).')',
                    'metered' => 0,
                    'usage_count' => 0,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        }
    }

    public function down(): void
    {
        DB::table('capability_grants')
            ->whereIn('capability_key', array_keys(self::DERIVED))
            ->where('plan_reference', 'Included with existing licence')
            ->delete();
    }
};
