<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Who decides whether a returnable defect stops a payment request.
 *
 * The question that forced this table: when an application has a RETURNABLE
 * finding and no structural defect, does the button say "Submit With Outstanding
 * Items" or "Complete Required Items"? Codex and I agreed it cannot be a global
 * setting, because returnability is contract-specific, and it cannot be a user
 * preference, because the whole point is that the user does not get to decide
 * what the agency will accept.
 *
 * So it lives here, on the project, and every row has to name the governing text
 * it came from. There are exactly three legitimate origins - the contract or
 * specification, a statute or regulation, or the agency's own published payment
 * procedure - and a row with none of those is not a rule. It is a guess, and it
 * is stored as UNRESOLVED so that the screen says it does not know rather than
 * quietly choosing the permissive answer.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_submission_rules', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->string('finding_code', 64);
            // hard_invalid | returnable_blocking | returnable_permitted | withhold_only | warning
            $t->string('submission_effect', 32);
            // contract | statute | agency_procedure
            $t->string('source_type', 32);
            $t->foreignId('knowledge_source_id')->nullable();
            $t->string('source_citation', 500);
            $t->date('effective_date')->nullable();
            // confirmed | unresolved
            $t->string('status', 16)->default('unresolved');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();
            $t->string('notes', 1000)->nullable();
            $t->timestampsTz();
            $t->unique(['project_id', 'finding_code']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_submission_rules');
    }
};
