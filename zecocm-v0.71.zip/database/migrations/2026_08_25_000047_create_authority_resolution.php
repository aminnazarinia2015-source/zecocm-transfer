<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TR-17: authority resolution. The row Codex added to the register itself and
 * called the sharper of its two additions.
 *
 * ZecoCM already had two of the three things this needs and they did not speak
 * to each other. DocumentPrecedence ranks sources. EffectiveDocument answers
 * whether a passage is still operative. Neither answers the question that
 * actually decides a dispute, which is Codex's invariant:
 *
 *   A source controls only if it is OPERATIVE, APPLICABLE to the proposition at
 *   issue, and AUTHORIZED TO PREVAIL over any incompatible alternative. Newer
 *   is not controlling by itself; higher precedence is not controlling outside
 *   its scope; RELEVANCE IS NOT AUTHORITY.
 *
 * The missing axis is APPLICABILITY, and it is the one that produces confident
 * wrong answers today. A change order can be current, outrank the drawing, and
 * still say nothing about the area somebody is asking about. A specification
 * section can be perfectly operative and belong to a phase that is not this
 * one. Retrieval that ranks by relevance will quote it with total confidence
 * because it is the best textual match, which is exactly how a contractor ends
 * up building to a requirement that was never his.
 *
 * The second thing this adds is INSTRUMENT SEMANTICS. Document type alone is
 * not enough: an RFI response saying "Detail 4/L-3 governs" clarifies without
 * changing anything, and an RFI response that actually directs changed work is
 * NOT a contract modification unless the governing contract gives that
 * instrument that effect or a later change order formalises it. Treating the
 * two the same is how an informal answer becomes an unpriced change.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('source_applicability', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_id')->nullable();
            $t->string('passage_ref', 300)->nullable();

            // Deliberately four dimensions and no more. Codex's instruction was
            // "do not build an ontology of all construction law", and an
            // applicability model with twelve axes is one nobody will populate,
            // which makes it worse than none.
            //
            // project | area | system | phase
            $t->string('dimension', 16);
            $t->string('value', 160);

            // includes | excludes
            //
            // Both directions, because "this change order applies everywhere
            // EXCEPT Area C" is how change orders are actually written, and
            // modelling only inclusion forces somebody to enumerate the whole
            // site to say it.
            $t->string('mode', 16)->default('includes');

            // confirmed | proposed | unresolved
            //
            // Applicability is a reading of a document, so it is a
            // determination like every other reading in this system. A
            // proposed tag never controls.
            $t->string('status', 16)->default('proposed');
            $t->string('basis', 300)->nullable();
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'dimension', 'value']);
        });

        Schema::create('source_authority_effects', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_id')->nullable();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            // original | amend | interpret | supplement | directive | evidence_only
            //
            // What this instrument DOES to the contract, which is not the same
            // as what kind of document it is.
            $t->string('authority_effect', 24);
            // Whether the governing contract actually gives this instrument
            // that effect. An RFI that directs changed work is not a
            // modification because it says it is.
            $t->boolean('effect_conferred_by_contract')->default(false);
            $t->string('conferring_citation', 300)->nullable();
            $t->foreignId('formalised_by_change_order_id')->nullable();

            $t->string('status', 16)->default('proposed');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'authority_effect']);
        });

        Schema::create('precedence_orders', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            $t->json('ordered_types');
            $t->string('authority_citation', 300)->nullable();

            // confirmed | unresolved | default_heuristic
            //
            // Codex's point, and it closes a hole I had left open: when the
            // contract's own order of precedence is ambiguous, DocumentPrecedence
            // must NOT quietly fall back to Zeco's default order and present it
            // as project-specific authority. The default may be used only as a
            // clearly labelled reference heuristic. The rule for READING the
            // contract lives under the same governance as the contract.
            $t->string('status', 24)->default('unresolved');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();
            $t->text('ambiguity_note')->nullable();

            $t->timestampsTz();
            $t->unique(['project_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('precedence_orders');
        Schema::dropIfExists('source_authority_effects');
        Schema::dropIfExists('source_applicability');
    }
};
