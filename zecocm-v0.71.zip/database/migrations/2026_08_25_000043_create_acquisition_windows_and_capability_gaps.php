<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Two subsystems, one principle: TRACE asks, a named person authorises, and
 * nothing the machine wants happens because the machine wanted it.
 *
 * THE ACQUISITION WINDOW. TRACE is sealed at rest. It reads the tenant's
 * governed corpus and nothing else - no outward reach, no external retrieval,
 * as the resting state rather than as a policy somebody remembers to apply.
 * When it needs knowledge it does not have, it refuses and SAYS what it needed.
 * A named human then opens a window: this subject, these sources, this long,
 * this many documents. What comes back lands in quarantine and is NOT part of
 * the corpus. A steward verifies it in. The window closes and the reach is gone.
 *
 * The reason this is worth a table rather than a config flag: every passage
 * that eventually becomes authoritative can name the window it entered through
 * and the person who opened it. "Where did this come from" stays answerable
 * years later, which is the entire product.
 *
 * What this does NOT let anyone claim. The model itself carries general
 * knowledge in its weights, and no gate here seals that. The defensible
 * statement is about RETRIEVAL: ZecoCM does not read anything outside your
 * record unless a named person opened a window to let it in. What the model
 * may generate from its own training is a separate question with a separate
 * answer - which is why the system prompt already forbids answering from
 * general knowledge and why every answer must cite a retrieved passage.
 *
 * THE CAPABILITY GAP. TRACE's own failures are the best product roadmap
 * anybody has and today they go nowhere: a no_match is logged and forgotten, a
 * steward's correction lands in a write-only table, and somebody paying for a
 * capability the catalogue reports as unbuilt is invisible. Those signals
 * cluster into named gaps, each carrying its evidence, and a gap becomes a
 * PROPOSAL.
 *
 * The hard boundary, and it is deliberate rather than timid: the system
 * proposes and never applies. A platform whose whole claim is that its record
 * is explainable cannot be one that rewrote itself overnight - it would be
 * unable to say why it answered as it did last Tuesday, and the first person
 * who understands that ends the product. Governed self-improvement is durable.
 * Self-modification is a demonstration that dies in a deposition.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('acquisition_windows', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->string('subject', 300);
            $t->text('justification');
            // The refusal that asked for this. TRACE requesting knowledge is
            // always traceable to the question it could not answer.
            $t->foreignId('requested_by_ai_run_id')->nullable()->constrained('ai_runs')->nullOnDelete();

            // Hosts or named corpora. An empty allowlist acquires nothing - the
            // default is closed, and a window with no sources is a window onto
            // nowhere rather than a window onto everything.
            $t->json('source_allowlist');
            $t->unsignedInteger('max_documents')->default(25);

            // requested | open | closed | expired | revoked
            $t->string('status', 16)->default('requested');
            $t->foreignId('opened_by')->nullable()->constrained('users');
            $t->timestampTz('opened_at')->nullable();
            $t->timestampTz('expires_at')->nullable();
            $t->foreignId('closed_by')->nullable()->constrained('users');
            $t->timestampTz('closed_at')->nullable();
            $t->string('close_reason', 255)->nullable();

            // A window whose contents would become authoritative for a legal or
            // contractual answer needs a second person, on the same principle
            // as the pay-application certification: one prepares, another
            // confirms, when the consequence is large enough.
            $t->boolean('requires_two_person')->default(false);
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'status']);
        });

        Schema::create('acquired_documents', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('acquisition_window_id')->constrained()->cascadeOnDelete();
            $t->string('source_identifier', 500);
            $t->string('title', 300)->nullable();
            $t->timestampTz('retrieved_at');
            $t->string('content_hash', 64);
            $t->unsignedBigInteger('byte_size')->default(0);

            // quarantined | verified | rejected | retracted
            //
            // Quarantined material is NEVER retrievable. Not ranked low - not
            // reachable, on the same fail-closed principle as tenancy. And
            // 'retracted' exists because the hard case is knowledge that was
            // verified, relied on, and later found to have come through a
            // window that should never have been opened. Deleting it would
            // erase the record of what the system believed when it answered.
            $t->string('quarantine_state', 16)->default('quarantined');
            $t->foreignId('verified_by')->nullable()->constrained('users');
            $t->timestampTz('verified_at')->nullable();
            $t->text('rejection_reason')->nullable();
            $t->timestampTz('retracted_at')->nullable();
            $t->text('retraction_reason')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'quarantine_state']);
            $t->unique(['acquisition_window_id', 'content_hash']);
        });

        Schema::create('capability_gaps', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();

            // no_match | escalation | steward_correction | unbuilt_capability_licensed
            // | recurring_finding
            $t->string('signal_kind', 40);
            // The stable identity of the cluster. Two runs belong to the same
            // gap when this matches - so the clustering rule is a value in the
            // record rather than a heuristic buried in a query.
            $t->string('cluster_key', 200);
            $t->string('title', 300);
            $t->text('proposal')->nullable();
            // The closure-register row this gap corresponds to, when it is one
            // we already named. A gap that maps to a known row is not news.
            $t->string('register_row', 16)->nullable();

            $t->json('evidence');
            $t->unsignedInteger('occurrences')->default(1);
            $t->unsignedInteger('distinct_askers')->default(0);
            $t->timestampTz('first_seen_at');
            $t->timestampTz('last_seen_at');

            // observed | proposed | authorized | declined | shipped
            //
            // 'observed' is deliberately below the threshold at which a human
            // is asked to look. A queue that shows every signal is a wall of
            // noise nobody reads, and that is the failure mode that kills
            // every system of this kind.
            $t->string('status', 16)->default('observed');
            $t->foreignId('authorized_by')->nullable()->constrained('users');
            $t->timestampTz('authorized_at')->nullable();
            $t->text('decision_reason')->nullable();

            $t->timestampsTz();
            $t->unique(['tenant_id', 'cluster_key']);
            $t->index(['status', 'occurrences']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('capability_gaps');
        Schema::dropIfExists('acquired_documents');
        Schema::dropIfExists('acquisition_windows');
    }
};
