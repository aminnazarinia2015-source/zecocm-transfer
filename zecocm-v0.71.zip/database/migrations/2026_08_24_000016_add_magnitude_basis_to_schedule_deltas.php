<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * P0-1 (Final Verification Directive, 24 Aug 2026): schedule delta magnitudes must
 * carry a typed basis. Date/actuals deltas store elapsed wall-clock minutes;
 * duration/float deltas store working minutes. Presenting both through a fixed
 * 480-minute divisor overstated calendar-date movements by 3x.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('schedule_deltas', 'magnitude_basis')) {
            return;
        }
        Schema::table('schedule_deltas', function (Blueprint $table) {
            $table->string('magnitude_basis', 40)->nullable()->after('magnitude_minutes');
        });
    }

    public function down(): void
    {
        Schema::table('schedule_deltas', function (Blueprint $table) {
            $table->dropColumn('magnitude_basis');
        });
    }
};
