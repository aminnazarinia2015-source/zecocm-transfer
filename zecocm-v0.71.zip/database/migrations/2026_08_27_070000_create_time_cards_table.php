<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Contractor time cards - a first-class feature, not a hidden sub-array of
 * Daily Report submission. The pre-existing `time_card_entries` table (see
 * 2026_08_24_000009_create_daily_reports_table.php) is a per-day labor/
 * equipment breakdown embedded in a Daily Report and stays exactly as it
 * was; this is a separate concept with its own header (a pay period, a
 * submitter, an approval) and its own detail rows, deliberately not folded
 * into that table so neither concept has to bend to fit the other.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('time_cards', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->foreignId('submitted_by')->constrained('users');
            $t->date('pay_period_start');
            $t->date('pay_period_end');
            $t->string('status', 24)->default('submitted'); // submitted | approved | rejected
            $t->timestamp('submitted_at')->nullable();
            $t->foreignId('approved_by')->nullable()->constrained('users');
            $t->timestamp('approved_at')->nullable();
            $t->text('determination')->nullable(); // recorded on approve/reject, same convention as ChangeOrder
            $t->timestamps();
            $t->index(['tenant_id', 'project_id', 'pay_period_start']);
        });

        Schema::create('time_card_lines', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('time_card_id')->constrained()->cascadeOnDelete();
            $t->foreignId('schedule_activity_id')->nullable()->constrained();
            $t->date('work_date');
            $t->string('resource_code');
            $t->string('resource_name');
            $t->string('resource_type', 16); // labor | equipment
            $t->string('pay_class')->nullable();
            $t->string('cost_code');
            $t->decimal('hours', 5, 2);
            $t->text('notes')->nullable();
            $t->timestamps();
            $t->index(['tenant_id', 'schedule_activity_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('time_card_lines');
        Schema::dropIfExists('time_cards');
    }
};
