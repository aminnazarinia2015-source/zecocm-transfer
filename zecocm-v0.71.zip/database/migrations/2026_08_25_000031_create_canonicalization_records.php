<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Two objects, because they are two different kinds of statement.
 *
 * The verifier may DETECT that a chain's historical serialization cannot be
 * reproduced under the current canonicalization protocol. That is a fact, and a
 * machine may record it.
 *
 * The verifier may NOT conclude that this was only a writer defect and that no
 * tampering occurred. That is an interpretation, and a system that authors its
 * own explanation for why its evidence cannot be checked has the same shape as
 * the automated knowledge verification we already had to tear out once.
 *
 * So the finding is system-generated and states only what was observed. The
 * transition record is authored by a named steward, takes the finding as
 * immutable input, and is where the explanation lives - signed by somebody who
 * can be asked about it.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('canonicalization_findings', function (Blueprint $t) {
            $t->id();
            $t->string('chain_name', 120);
            $t->string('chain_group', 64);
            $t->unsignedInteger('record_count');
            $t->string('mismatch_type', 64);
            $t->unsignedBigInteger('first_affected_record_id')->nullable();
            $t->string('linkage_result', 32);
            $t->string('content_verification_result', 32);
            $t->string('verifier_version', 32);
            $t->timestampTz('detected_at');
            $t->timestampsTz();
            // One standing condition per chain per kind, not one row per run of
            // the verifier. Re-detecting the same thing is not a new fact.
            $t->unique(['chain_name', 'chain_group', 'mismatch_type']);
        });

        Schema::create('canonicalization_transition_records', function (Blueprint $t) {
            $t->id();
            $t->foreignId('canonicalization_finding_id')->constrained()->cascadeOnDelete();
            // The steward. Not nullable: an unsigned transition record is the
            // thing this table exists to prevent.
            $t->foreignId('authored_by')->constrained('users');
            $t->string('author_role', 120);
            $t->string('cause_classification', 64);
            $t->text('explanatory_narrative');
            $t->string('supporting_release_evidence', 500)->nullable();
            $t->string('canonicalization_version_introduced', 32);
            $t->unsignedBigInteger('first_record_using_new_version')->nullable();
            $t->string('original_chain_head', 128)->nullable();
            // Optional, and explicitly non-authoritative. What the payload WOULD
            // hash to under the current protocol - never written into the chain.
            $t->string('diagnostic_recomputed_hash', 128)->nullable();
            $t->timestampTz('authored_at');
            $t->string('record_hash', 128);
            $t->timestampsTz();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('canonicalization_transition_records');
        Schema::dropIfExists('canonicalization_findings');
    }
};
