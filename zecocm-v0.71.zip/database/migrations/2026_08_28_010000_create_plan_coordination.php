<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('plan_sets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('name', 160);
            $table->string('discipline', 48)->default('general');
            $table->string('status', 24)->default('active');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['project_id', 'name']);
            $table->index(['tenant_id', 'project_id', 'status'], 'plan_set_scope_status_idx');
        });

        Schema::create('plan_sheets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_set_id')->constrained()->cascadeOnDelete();
            $table->string('sheet_number', 64);
            $table->string('title', 255);
            $table->string('discipline', 48)->default('general');
            $table->string('status', 24)->default('active');
            $table->foreignId('current_version_id')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['plan_set_id', 'sheet_number']);
            $table->index(['tenant_id', 'project_id', 'discipline'], 'plan_sheet_scope_disc_idx');
        });

        Schema::create('plan_sheet_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_id')->constrained()->cascadeOnDelete();
            $table->foreignId('knowledge_source_version_id')->constrained()->restrictOnDelete();
            $table->unsignedInteger('page_number')->nullable();
            $table->string('revision', 96);
            $table->string('issue_status', 32)->default('issued_for_construction');
            $table->date('issued_at')->nullable();
            $table->string('source_provider', 32)->default('zecocm');
            $table->string('external_id', 255)->nullable();
            $table->string('external_url', 1000)->nullable();
            $table->string('sha256', 64);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['plan_sheet_id', 'revision']);
            $table->index(['tenant_id', 'project_id', 'plan_sheet_id'], 'plan_ver_scope_sheet_idx');
        });

        Schema::table('plan_sheets', function (Blueprint $table) {
            $table->foreign('current_version_id')->references('id')->on('plan_sheet_versions')->nullOnDelete();
        });

        Schema::create('plan_markups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_version_id')->constrained()->cascadeOnDelete();
            $table->string('markup_type', 24);
            $table->json('geometry');
            $table->text('body')->nullable();
            $table->string('color', 16)->default('#D97706');
            $table->string('status', 24)->default('open');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('resolved_at')->nullable();
            $table->text('resolution')->nullable();
            $table->timestampsTz();
            $table->index(['tenant_id', 'project_id', 'status'], 'plan_markup_scope_status_idx');
        });

        Schema::create('plan_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('plan_sheet_version_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('plan_markup_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('action', 40);
            $table->json('details')->nullable();
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('previous_event_hash', 64)->nullable();
            $table->string('event_hash', 64);
            $table->timestampsTz();
            $table->index(['tenant_id', 'project_id', 'id'], 'plan_event_scope_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plan_events');
        Schema::dropIfExists('plan_markups');
        Schema::table('plan_sheets', function (Blueprint $table) {
            $table->dropForeign(['current_version_id']);
        });
        Schema::dropIfExists('plan_sheet_versions');
        Schema::dropIfExists('plan_sheets');
        Schema::dropIfExists('plan_sets');
    }
};
