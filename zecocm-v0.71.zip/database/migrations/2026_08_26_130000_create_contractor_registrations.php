<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Self-serve contractor onboarding — closed design in
 * claude/payment-gateway-and-contractor-onboarding-design-brief.md (project docs). One row per
 * registration attempt, tracked through its own state machine independent of Tenant/User so a
 * registration can be resumed, retried, or reviewed without ever having provisioned a tenant.
 *
 * Deliberately NOT tenant-scoped (no tenant_id, no BelongsToTenant) — a registration doesn't
 * belong to a tenant until step 3 provisions one; that's the whole point of keeping this table
 * separate rather than writing directly into `tenants`.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contractor_registrations', function (Blueprint $t) {
            $t->id();

            // Stable idempotency key for this registration attempt. Generated client-side or on
            // first submit and reused across retries so a duplicated submit/webhook can never
            // create two tenants for the same registration.
            $t->uuid('registration_id')->unique();

            // Step 1 — organization profile (blocking, collected before payment).
            $t->string('legal_name');
            $t->string('business_name')->nullable(); // DBA / trade name, if different from legal_name
            $t->string('entity_type'); // sole_proprietorship|llc|corporation|partnership|other
            $t->string('country'); // US|CA|other — drives which downstream compliance gates apply
            $t->string('admin_first_name');
            $t->string('admin_last_name');
            $t->string('phone');
            $t->json('address'); // line1, line2, city, state/province, postal_code
            $t->string('email');

            // Step 2 — payment. Provider-specific identifiers only; never raw card/bank data.
            $t->string('payment_provider')->nullable(); // stripe|paypal
            $t->string('payment_provider_customer_id')->nullable();
            $t->string('payment_provider_subscription_id')->nullable();

            // Overall registration state — derived from, but not identical to, payment status.
            // pending_payment -> payment_confirmed -> provisioning -> provisioned
            // (payment_failed and abandoned are terminal-but-resumable: the row stays, nothing
            // about "abandoned" here means deleted — that's a separate retention policy, not this
            // state machine.)
            $t->string('status')->default('pending_payment');

            // Set only once, by the webhook handler, never inferred from a browser redirect.
            $t->timestamp('payment_confirmed_at')->nullable();

            // Set only once provisioning actually completes — the row this ties back to.
            $t->foreignId('tenant_id')->nullable()->constrained('tenants')->nullOnDelete();

            $t->timestamps();

            $t->index('status');
            $t->index('email');
        });

        // One append-only ledger of every provider webhook this registration has processed, so a
        // retried webhook (Stripe/PayPal both retry on non-2xx or even sometimes redundantly) is a
        // guaranteed no-op rather than a chance at double-provisioning. This is the concrete
        // `processed_events` table both design-review passes (Gemini's first draft, Codex's
        // review) called mandatory.
        Schema::create('payment_webhook_events', function (Blueprint $t) {
            $t->id();
            $t->string('provider'); // stripe|paypal
            $t->string('provider_event_id')->unique();
            $t->string('event_type');
            $t->json('payload');
            $t->timestamp('processed_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_webhook_events');
        Schema::dropIfExists('contractor_registrations');
    }
};
