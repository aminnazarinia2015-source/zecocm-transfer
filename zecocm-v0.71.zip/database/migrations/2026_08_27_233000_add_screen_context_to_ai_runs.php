<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE-as-educator, step 1: what screen/record the requester was looking at
 * when they asked, so a run can ground its answer ("you're looking at
 * RFI-0045") and the audit trail shows what TRACE could see of the UI state.
 *
 * Only ever holds what App\Domain\Ai\ScreenContextResolver validated against
 * the requester's own authorized project at store time - never the raw,
 * caller-supplied payload. See AiRunController::store().
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_runs', function (Blueprint $t) {
            $t->json('screen_context')->nullable()->after('question');
        });
    }

    public function down(): void
    {
        Schema::table('ai_runs', function (Blueprint $t) {
            $t->dropColumn('screen_context');
        });
    }
};
