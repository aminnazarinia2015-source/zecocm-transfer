<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('document_passages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->string('corpus');           // project_specs|project_plans|project_contract|...
            $t->string('source');           // "Spec s. 32 84 00" / "Sheet A-01 detail 4"
            $t->string('edition')->nullable();
            $t->text('body');
            $t->timestamps();
        });
        if (DB::getDriverName() === 'mysql') {
            DB::statement('ALTER TABLE document_passages ADD FULLTEXT INDEX ft_body (body)');
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('document_passages');
    }
};
