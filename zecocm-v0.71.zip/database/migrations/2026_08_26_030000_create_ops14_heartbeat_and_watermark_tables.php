<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * OPS-14: two small operational tables, neither tenant data, neither
 * append-only records - both are plumbing in the same spirit as OPS-15's
 * `health_probes`.
 *
 * `queue_heartbeats`: each row is one scheduled dispatch, carrying a unique
 * `dispatch_token` the worker must complete. Per Codex's explicit
 * refinement, this is deliberately NOT a single upserted "last_seen_at" row -
 * a stale or replayed handler invocation could make an already-stopped
 * worker look healthy forever. A new row every interval, with its own
 * `handled_at` filled in only when THAT token is actually processed, is what
 * lets the health check ask "was the most recent dispatch actually
 * completed, recently" rather than "did anything write to this table
 * recently."
 *
 * `failed_job_watermarks`: a single-row cursor (`last_seen_failed_job_id`)
 * the failed-job-delta command advances each run, so it can report "N new
 * failures since last observation" rather than the ever-growing total
 * `failed_jobs` table already holds. `monitor_name` is unique and always
 * `'failed_jobs'` for now - per Codex's review, "assume exactly one row
 * forever" is an operational correctness trap if a second row ever appeared
 * (first() becomes nondeterministic, update() touches every row). Keying on
 * a fixed name and using updateOrInsert() makes "exactly one row" a
 * constraint the database enforces, not an assumption the command makes.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('queue_heartbeats', function (Blueprint $table) {
            $table->id();
            $table->string('dispatch_token')->unique();
            $table->string('queue_name');
            $table->timestamp('dispatched_at');
            $table->timestamp('handled_at')->nullable();
            $table->string('worker_identity')->nullable();
            $table->index('dispatched_at');
        });

        Schema::create('failed_job_watermarks', function (Blueprint $table) {
            $table->id();
            $table->string('monitor_name')->unique();
            $table->unsignedBigInteger('last_seen_failed_job_id')->default(0);
            $table->timestamp('checked_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('failed_job_watermarks');
        Schema::dropIfExists('queue_heartbeats');
    }
};
