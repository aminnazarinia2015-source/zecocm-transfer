<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * A3: the deadlines that decide whether a valid claim survives.
 *
 * The register row says it plainly: "a missed 10/15/20-day notice permanently
 * bars a valid claim." That is the whole difference between this and every
 * other clock in the product. An administrative clock going red is
 * embarrassing. A claim-preserving clock going red destroys a right, and
 * nothing afterwards restores it - not being right about the facts, not pricing
 * it perfectly, not the owner agreeing it was extra work.
 *
 * Four tables rather than one, because Codex was right that the hard part of
 * this row is not arithmetic. It is PROVENANCE. Every deadline is the product
 * of four separate things that can each be wrong, disputed, or unknown:
 *
 *   THE REQUIREMENT   what the contract or the statute actually demands, and
 *                     what happens if it is missed. Never a default. There is
 *                     no such thing as a standard notice period, and an assumed
 *                     ten days that turns out to be five is worse than no clock
 *                     at all - because a wrong deadline is trusted.
 *
 *   THE TRIGGER       the event the clock runs from. This is the part that gets
 *                     litigated. "When was the differing condition discovered"
 *                     is a question with a disputed answer far more often than
 *                     it has an obvious one, and it is frequently only
 *                     recognised as a trigger weeks later.
 *
 *   THE CALCULATION   append-only. When a trigger date is corrected, the old
 *                     deadline does not get overwritten - because two years
 *                     later the question is not only "what is the deadline" but
 *                     "what did the system TELL US on 1 September, and why".
 *
 *   THE COMPLIANCE    a notice is not compliant because a PDF was uploaded
 *                     before the deadline. TIMELY and COMPLIANT are different
 *                     findings, and SENT and SERVED are different facts. This
 *                     codebase learned that one four hours ago on stop payment
 *                     notices and it applies identically here.
 *
 * AND THE THING THIS WILL NEVER DO: pronounce a forfeiture. When a preservative
 * deadline passes with nothing recorded against it, the system says the
 * deadline passed without a qualifying compliance event and that potential loss
 * of rights requires review. It does not say the claim is waived. Whether a
 * right actually survives is a legal determination that turns on facts and law
 * this software does not have - equitable tolling, actual notice, waiver by
 * conduct, an owner who knew anyway. The software can prove its records. It
 * cannot pronounce on rights.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('claim_requirements', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            $t->string('requirement_type', 64);
            $t->string('title', 300);
            $t->string('claim_category', 64)->nullable();

            // statute | regulation | contract | agency_procedure
            //
            // The type matters as much as the citation. A contract saying
            // "shall" does not make a requirement statutory, and letting the
            // word "shall" promote an administrative step into a preservative
            // one is how a system manufactures panic.
            $t->string('authority_type', 32);
            $t->string('authority_citation', 300);
            $t->foreignId('authority_source_id')->nullable();

            // preservative | administrative | escalation | enforcement | informational
            $t->string('consequence_class', 24);

            $t->string('trigger_type', 64);
            $t->foreignId('claim_trigger_event_id')->nullable();

            $t->unsignedInteger('period_value')->nullable();
            $t->string('period_unit', 16)->default('calendar_days');
            // calendar | working | working_with_project_calendar
            //
            // And the rule itself needs a source. "Within 10 days" is not
            // self-explanatory: whether weekends count, whether the day of the
            // triggering event counts, and which holidays apply are all
            // contract or statute questions. Quietly assuming Monday to Friday
            // is inventing a deadline.
            $t->string('calendar_rule', 48)->default('calendar');
            $t->string('calendar_rule_source', 300)->nullable();

            $t->text('recipient_rule')->nullable();
            $t->text('delivery_method_rule')->nullable();
            $t->text('content_requirement_rule')->nullable();

            // draft | confirmed | superseded
            //
            // A requirement nobody confirmed produces no clock. Somebody has to
            // have read the clause.
            $t->string('status', 16)->default('draft');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'consequence_class']);
        });

        Schema::create('claim_requirement_dependencies', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('claim_requirement_id')->constrained()->cascadeOnDelete();
            $t->foreignId('depends_on_requirement_id')->constrained('claim_requirements')->cascadeOnDelete();
            // completion | denial | expiration | waiver
            $t->string('dependency_type', 16);
            $t->unsignedInteger('sequence_order')->default(0);
            $t->timestampsTz();
        });

        Schema::create('claim_trigger_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            $t->string('event_type', 64);
            $t->text('description')->nullable();
            $t->date('occurred_on')->nullable();
            // The disputed case. A range is more useful than either inventing
            // precision or saying nothing at all.
            $t->date('earliest_plausible_on')->nullable();
            $t->date('latest_plausible_on')->nullable();

            $t->string('source_type', 64)->nullable();
            $t->unsignedBigInteger('source_id')->nullable();
            $t->string('source_locator', 300)->nullable();
            $t->foreignId('observed_by')->nullable()->constrained('users');

            // confirmed | disputed | unresolved
            $t->string('status', 16)->default('unresolved');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();
            $t->text('dispute_note')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'event_type']);
        });

        Schema::create('claim_clock_calculations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('claim_requirement_id')->constrained()->cascadeOnDelete();
            $t->foreignId('claim_trigger_event_id')->nullable()->constrained()->nullOnDelete();

            // Snapshots, not references. The whole point of this table is to
            // answer "what did the screen say on 1 September and why", and a
            // reference to a row that has since changed cannot answer it.
            $t->json('trigger_snapshot');
            $t->json('authority_snapshot');
            $t->string('authority_hash', 64);

            $t->date('deadline_on')->nullable();
            // established | unresolved_trigger | unresolved_calendar | unresolved_authority
            $t->string('state', 32);
            $t->text('reason')->nullable();

            $t->timestampTz('calculated_at');
            $t->string('calculation_version', 32)->default('a3-v1');
            $t->foreignId('supersedes_calculation_id')->nullable()->constrained('claim_clock_calculations');

            $t->timestampsTz();
            $t->index(['tenant_id', 'claim_requirement_id', 'calculated_at']);
        });

        Schema::create('claim_compliance_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('claim_requirement_id')->constrained()->cascadeOnDelete();

            $t->timestampTz('prepared_at')->nullable();
            $t->timestampTz('signed_at')->nullable();
            $t->timestampTz('sent_at')->nullable();
            $t->timestampTz('received_at')->nullable();

            $t->string('recipient', 300)->nullable();
            $t->string('recipient_role', 160)->nullable();
            $t->string('delivery_method', 64)->nullable();
            $t->string('delivery_proof', 300)->nullable();

            // TIMELY and COMPLIANT are separate findings and are stored as
            // separate columns so that nothing can quietly derive one from the
            // other. A notice sent two days early to the wrong officer is
            // timely and not compliant.
            $t->string('timeliness', 24)->default('unresolved');   // timely | late | unresolved
            $t->string('content_completeness', 24)->default('unresolved'); // complete | deficient | unresolved
            $t->string('satisfaction', 24)->default('unresolved'); // satisfied | not_satisfied | unresolved

            $t->text('determination_basis')->nullable();
            $t->foreignId('determined_by')->nullable()->constrained('users');
            $t->timestampTz('determined_at')->nullable();

            $t->foreignId('evidence_document_id')->nullable();
            $t->timestampsTz();
            $t->index(['tenant_id', 'claim_requirement_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('claim_compliance_events');
        Schema::dropIfExists('claim_clock_calculations');
        Schema::dropIfExists('claim_trigger_events');
        Schema::dropIfExists('claim_requirement_dependencies');
        Schema::dropIfExists('claim_requirements');
    }
};
