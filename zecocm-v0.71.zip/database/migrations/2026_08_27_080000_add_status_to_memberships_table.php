<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * "Users & access" and "Staff & permissions" were static mockups with no
 * backing route at all - MembershipController is the real thing. Access is
 * revoked, not deleted: this platform's own pitch is that the present never
 * silently erases the past, and a removed grant is itself a fact worth
 * keeping (who had what, until when).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('memberships', function (Blueprint $t) {
            $t->string('status', 16)->default('active')->after('discipline_scope'); // active | revoked
            $t->timestamp('revoked_at')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('memberships', function (Blueprint $t) {
            $t->dropColumn(['status', 'revoked_at']);
        });
    }
};
