<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * The one child table in this codebase that could not defend itself.
 *
 * Every other child carries tenant_id and the global scope - pay application
 * lines, quality item events, change order allocations. knowledge_source_versions
 * did not, so its isolation came entirely from whoever loaded it having gone
 * through the parent first.
 *
 * That held. It held in every path I could find. But it is the same shape as the
 * raw supersession query that had to join fv to fs purely to reach a tenant
 * column - the absence of the column is what forced that join, and that join is
 * what had no filter on it.
 *
 * Backfilled from the parent, which is the only place the answer could come
 * from, and the parent is the authority on it.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('knowledge_source_versions', function (Blueprint $t) {
            $t->foreignId('tenant_id')->nullable()->after('id')->constrained()->cascadeOnDelete();
        });

        DB::statement('UPDATE knowledge_source_versions SET tenant_id = ('
            .'SELECT s.tenant_id FROM knowledge_sources s WHERE s.id = knowledge_source_versions.knowledge_source_id'
            .') WHERE tenant_id IS NULL');

        Schema::table('knowledge_source_versions', function (Blueprint $t) {
            $t->index(['tenant_id', 'knowledge_source_id'], 'ksv_tenant_source_idx');
        });
    }

    public function down(): void
    {
        Schema::table('knowledge_source_versions', function (Blueprint $t) {
            $t->dropIndex('ksv_tenant_source_idx');
            $t->dropConstrainedForeignId('tenant_id');
        });
    }
};
