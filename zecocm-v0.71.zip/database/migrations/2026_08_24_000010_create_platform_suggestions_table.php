<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Technician suggestion inbox - platform level, NOT tenant scoped:
        // technicians can never mutate tenant data; this is their only output.
        Schema::create('platform_suggestions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('suggested_by')->constrained('users');
            $t->foreignId('tenant_id')->nullable()->constrained();
            $t->string('about');
            $t->text('suggestion');
            $t->string('status')->default('pending'); // pending|approved|dismissed
            $t->foreignId('resolved_by')->nullable()->constrained('users');
            $t->timestamp('resolved_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('platform_suggestions');
    }
};
