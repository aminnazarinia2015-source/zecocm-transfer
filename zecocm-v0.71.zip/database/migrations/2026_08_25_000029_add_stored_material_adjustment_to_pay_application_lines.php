<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The declared movement of stored-material value.
 *
 * Stored material paid last month has to go somewhere this month: it is still
 * stored, it was installed and the stored balance came down by what moved, or it
 * left the job and the money comes back. Any other outcome is either a double
 * payment or a disappearance, and both look identical to arithmetic that only
 * checks this month's totals.
 *
 * The adjustment is where the contractor states which of those happened. It
 * carries a reason because an unexplained credit is the same evidentiary problem
 * as an unexplained charge.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            // Signed: negative removes previously billed stored value.
            $t->bigInteger('stored_material_adjustment_cents')->default(0);
            $t->string('stored_material_adjustment_reason', 500)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('pay_application_lines', function (Blueprint $t) {
            $t->dropColumn(['stored_material_adjustment_cents', 'stored_material_adjustment_reason']);
        });
    }
};
