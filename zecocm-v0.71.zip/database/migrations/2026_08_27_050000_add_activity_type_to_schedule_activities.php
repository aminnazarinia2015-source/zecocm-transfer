<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md, Codex's
 * point 10: rules must not run blindly against milestones, WBS summaries,
 * level-of-effort activities, procurement, fabrication, submittals, testing,
 * or owner/utility activities - only real field-production work is eligible
 * for a "no corroborating daily report" style finding.
 *
 * Nullable and unclassified for every activity imported before this column
 * existed (no schedule parser sets it yet - that is separate, later work).
 * Deliberately NOT defaulted to CONSTRUCTION: an unclassified activity is
 * excluded from TRACE-01/02 eligibility and reported as such (a MAPPING_GAP
 * finding), never silently treated as eligible. See
 * App\Domain\Trace\ProgressEvidenceCrossCheckService.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('schedule_activities', function (Blueprint $t) {
            $t->string('activity_type', 32)->nullable()->after('name');
        });
    }

    public function down(): void
    {
        Schema::table('schedule_activities', function (Blueprint $t) {
            $t->dropColumn('activity_type');
        });
    }
};
