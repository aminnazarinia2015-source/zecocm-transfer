<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('integration_connections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('provider', 32);
            $table->string('status', 24)->default('pending_authorization');
            $table->string('external_account_id', 255)->nullable();
            $table->string('external_account_name', 255)->nullable();
            $table->json('scopes')->nullable();
            $table->text('access_token_ciphertext')->nullable();
            $table->text('refresh_token_ciphertext')->nullable();
            $table->timestampTz('token_expires_at')->nullable();
            $table->text('sync_cursor')->nullable();
            $table->json('settings')->nullable();
            $table->timestampTz('last_synced_at')->nullable();
            $table->text('last_error')->nullable();
            $table->foreignId('authorized_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampsTz();
            $table->unique(['tenant_id', 'project_id', 'provider'], 'integration_connection_scope_provider_unique');
            $table->index(['tenant_id', 'status', 'provider'], 'integration_connection_status_idx');
        });

        Schema::create('integration_sync_runs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('integration_connection_id')->constrained()->cascadeOnDelete();
            $table->string('direction', 16);
            $table->string('object_type', 48);
            $table->string('status', 24)->default('queued');
            $table->string('idempotency_key', 128);
            $table->json('counts')->nullable();
            $table->text('cursor_before')->nullable();
            $table->text('cursor_after')->nullable();
            $table->text('error_summary')->nullable();
            $table->timestampTz('started_at')->nullable();
            $table->timestampTz('finished_at')->nullable();
            $table->timestampsTz();
            $table->unique(['integration_connection_id', 'idempotency_key'], 'integration_sync_idempotency_unique');
        });

        Schema::create('integration_webhook_receipts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->nullOnDelete();
            $table->string('provider', 32);
            $table->string('provider_event_id', 255);
            $table->string('payload_sha256', 64);
            $table->string('verification_status', 24);
            $table->string('processing_status', 24)->default('received');
            $table->timestampTz('received_at');
            $table->timestampTz('processed_at')->nullable();
            $table->text('error_summary')->nullable();
            $table->timestampsTz();
            $table->unique(['provider', 'provider_event_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('integration_webhook_receipts');
        Schema::dropIfExists('integration_sync_runs');
        Schema::dropIfExists('integration_connections');
    }
};
