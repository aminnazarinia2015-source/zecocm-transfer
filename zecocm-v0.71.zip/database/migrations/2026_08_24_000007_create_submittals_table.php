<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('submittals', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->string('number');               // SUB-0118; revisions as decimals .1 .2
            $t->string('spec_section');         // routes to discipline automatically
            $t->string('title');
            $t->string('type');                 // data, admin-extendable list
            $t->string('submitted_by_org');
            $t->string('contact_person')->nullable();
            $t->date('submitted_at')->nullable();   // anchor for the review clock
            $t->string('ball_in_court');        // seat currently holding it
            $t->string('status')->default('draft'); // draft|submitted|in_review|no_exceptions|revise_resubmit|rejected
            $t->json('stamp')->nullable();      // action, stamper, sealed_at, evidence state
            $t->json('routing_history');        // every hop with per-hop elapsed time
            $t->timestamps();
            $t->unique(['project_id', 'number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('submittals');
    }
};
