<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The money path. A schedule of values, and the payment applications billed
 * against it.
 *
 * Every amount is stored in integer CENTS. Floating point money is how a
 * retention calculation ends up a penny off across forty line items and a
 * public agency rejects the whole application.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('schedule_of_value_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->string('item_number', 32);
            $t->string('description', 255);
            $t->string('cost_code', 64)->nullable();
            $t->unsignedBigInteger('scheduled_value_cents');
            // A change order raises or lowers a line's scheduled value. Keeping the
            // original visible is what lets anyone see how the contract grew.
            $t->unsignedBigInteger('original_value_cents');
            $t->foreignId('change_order_id')->nullable();
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestampsTz();
            $t->unique(['project_id', 'item_number']);
        });

        Schema::create('pay_applications', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('number');
            $t->date('period_from');
            $t->date('period_to');
            $t->string('status', 24)->default('draft'); // draft|submitted|approved|rejected|paid
            $t->timestampTz('submitted_at')->nullable();
            $t->timestampTz('approved_at')->nullable();
            $t->timestampTz('paid_at')->nullable();
            // Retention as basis points (500 = 5.00%) so it is exact.
            $t->unsignedInteger('retention_basis_points')->default(500);
            $t->json('clock_snapshot')->nullable();
            $t->json('seal')->nullable();
            $t->timestampsTz();
            $t->unique(['project_id', 'number']);
        });

        Schema::create('pay_application_lines', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('pay_application_id')->constrained()->cascadeOnDelete();
            $t->foreignId('schedule_of_value_item_id')->constrained('schedule_of_value_items')->cascadeOnDelete();
            $t->unsignedBigInteger('previous_completed_cents')->default(0);
            $t->unsignedBigInteger('this_period_cents')->default(0);
            $t->unsignedBigInteger('stored_materials_cents')->default(0);
            $t->timestampsTz();
            $t->unique(['pay_application_id', 'schedule_of_value_item_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pay_application_lines');
        Schema::dropIfExists('pay_applications');
        Schema::dropIfExists('schedule_of_value_items');
    }
};
