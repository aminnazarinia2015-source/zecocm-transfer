<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * A7: the back half of the contract lifecycle.
 *
 * Codex's structure, and the separation it told me to protect above everything
 * else in this row - because I was about to collapse four different things into
 * one "completion" column, the same way I collapsed sent and served on stop
 * notices four hours ago:
 *
 *   WHAT HAPPENED            a fact or somebody's determination. The work
 *                            reached substantial completion. Labour ceased.
 *   WHAT WAS RECORDED        a recorder-backed instrument with a county, an
 *                            instrument number and a recordation date. A Notice
 *                            of Completion that exists in a drawer is not
 *                            recorded, and the statutory clocks turn on
 *                            recordation rather than on the paper existing.
 *   WHAT IS REQUIRED TO CLOSE the contractual turnover obligations - as-builts,
 *                            O&M manuals, training, spare parts, keys.
 *   WHAT REMAINS ALIVE AFTER a warranty runs FORWARD from acceptance and
 *                            outlives every other clock in the system.
 *
 * Four domains, four tables, and A3 consumes only the completion events its
 * governing requirement actually names. Collapsing any two of them produces a
 * confident wrong answer: the Civil Code s. 9356 stop-notice window is 30 days
 * or 90 depending on whether a notice of completion was RECORDED, so a system
 * that treats "the superintendent says we finished on the first" as equivalent
 * to a recorded instrument will count from the wrong event and say so with
 * total confidence.
 *
 * THE COMMERCIAL POSITION, which is Codex's phrasing and worth keeping:
 *
 *   ZecoCM treats closeout as a process that starts when the first submittal is
 *   approved, not when construction ends.
 *
 * That is what `closeout_deliverables` and the lineage columns are for. A
 * product submittal approved for construction should eventually become
 * installed, tested, documented in an O&M manual, warranted, and accepted at
 * closeout. Every missing link in that chain is closeout debt that is visible
 * in month four and unpayable in month eighteen.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('completion_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            // substantial_completion | final_completion | acceptance_by_governing_body
            // | cessation_of_labor | beneficial_occupancy
            $t->string('event_type', 48);
            // fact | determination
            //
            // Cessation of labour is a fact somebody can observe. Substantial
            // completion is a DETERMINATION - an opinion about whether the work
            // can be used for its intended purpose - and treating one as the
            // other is how a disputed date becomes an authoritative one.
            $t->string('nature', 16);
            $t->date('occurred_on')->nullable();
            $t->date('earliest_plausible_on')->nullable();
            $t->date('latest_plausible_on')->nullable();

            // asserted | determined | disputed | superseded
            $t->string('status', 16)->default('asserted');
            $t->foreignId('determined_by')->nullable()->constrained('users');
            $t->timestampTz('determined_at')->nullable();
            $t->string('determined_by_party', 160)->nullable();
            $t->text('basis')->nullable();
            $t->text('dispute_note')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'event_type']);
        });

        Schema::create('recorded_completion_instruments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('completion_event_id')->nullable()->constrained()->nullOnDelete();

            // notice_of_completion | notice_of_cessation | notice_of_acceptance
            $t->string('instrument_type', 48);

            // The four facts that make it RECORDED rather than merely written.
            // A Notice of Completion signed and sitting in a project file has
            // not started any clock, and the difference is the whole reason
            // this table is separate from the one above.
            $t->string('recording_county', 96)->nullable();
            $t->string('instrument_number', 96)->nullable();
            $t->date('recorded_on')->nullable();
            $t->string('document_reference', 300)->nullable();
            $t->boolean('copy_on_file')->default(false);

            // recorded | not_recorded | unresolved
            //
            // Defaults to UNRESOLVED, never to not_recorded. "Nobody has
            // checked the recorder" and "we checked and there is nothing" are
            // different facts, and only one of them supports counting from the
            // longer statutory window.
            $t->string('recordation_state', 16)->default('unresolved');
            $t->foreignId('verified_by')->nullable()->constrained('users');
            $t->timestampTz('verified_at')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'instrument_type']);
        });

        Schema::create('closeout_requirements', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            // as_built | om_manual | training | spare_parts | keys | warranty_document
            // | test_report | certification | permit_signoff | attic_stock | other
            $t->string('deliverable_type', 48);
            $t->string('title', 300);
            $t->string('authority_citation', 300)->nullable();
            $t->text('acceptance_criteria')->nullable();

            // Whether failing to produce it blocks final payment or retention
            // release. Not every closeout item does, and treating them all as
            // blocking trains people to ignore the list.
            $t->boolean('blocks_final_payment')->default(false);
            $t->boolean('blocks_retention_release')->default(false);

            $t->string('responsible_party', 160)->nullable();
            $t->foreignId('subcontract_id')->nullable();
            // The submittal this obligation descends from, when it has one.
            // This is the lineage that makes month-four forecasting possible.
            $t->foreignId('origin_submittal_id')->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id', 'deliverable_type']);
        });

        Schema::create('closeout_deliverables', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('closeout_requirement_id')->constrained()->cascadeOnDelete();

            // The ladder Codex named, and the reason a percentage is useless:
            // required -> assigned -> evidence_ready -> submitted -> accepted.
            // "74 per cent complete" hides which rung everything is stuck on.
            $t->string('state', 24)->default('required');
            $t->foreignId('evidence_document_id')->nullable();
            $t->string('evidence_reference', 300)->nullable();
            $t->timestampTz('submitted_at')->nullable();
            $t->timestampTz('accepted_at')->nullable();
            $t->foreignId('accepted_by')->nullable()->constrained('users');
            $t->text('rejection_reason')->nullable();
            $t->timestampsTz();
        });

        Schema::create('warranty_obligations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();

            $t->string('title', 300);
            $t->string('scope_description', 500)->nullable();
            $t->string('authority_citation', 300)->nullable();
            $t->foreignId('trade_partner_id')->nullable();
            $t->foreignId('origin_submittal_id')->nullable();

            // Every other clock in this system EXPIRES A RIGHT. A warranty runs
            // forward and creates an obligation, which is why it is not in the
            // A3 requirement graph: the consequence of the end of a warranty is
            // the opposite of the consequence of a missed notice.
            $t->string('anchor_event_type', 48)->default('acceptance_by_governing_body');
            $t->foreignId('anchor_completion_event_id')->nullable();
            $t->unsignedInteger('duration_months')->default(12);

            // A repair during the period sometimes restarts the clock FOR THAT
            // ITEM only. Whether it does is a contract question, so it is
            // recorded per obligation with its source rather than assumed.
            $t->boolean('repair_restarts_period')->default(false);
            $t->string('restart_rule_source', 300)->nullable();

            $t->timestampsTz();
            $t->index(['tenant_id', 'project_id']);
        });

        Schema::create('warranty_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('warranty_obligation_id')->constrained()->cascadeOnDelete();

            // claim_made | repair_completed | replaced | denied | extended
            $t->string('event_type', 32);
            $t->date('occurred_on');
            $t->text('description')->nullable();
            $t->string('item_reference', 300)->nullable();
            // When the contract restarts the period for a repaired item, this
            // is the new anchor for that item and only that item.
            $t->boolean('restarts_period_for_item')->default(false);
            $t->foreignId('recorded_by')->nullable()->constrained('users');
            $t->timestampsTz();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('warranty_events');
        Schema::dropIfExists('warranty_obligations');
        Schema::dropIfExists('closeout_deliverables');
        Schema::dropIfExists('closeout_requirements');
        Schema::dropIfExists('recorded_completion_instruments');
        Schema::dropIfExists('completion_events');
    }
};
