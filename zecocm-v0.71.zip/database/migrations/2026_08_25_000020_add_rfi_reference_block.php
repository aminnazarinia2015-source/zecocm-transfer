<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The reference block an RFI is actually judged on.
 *
 * A question with no specification section, no sheet and no linked submittal is an
 * e-mail, not a contract instrument. These fields make the RFI point at the documents
 * it disputes, and let it be opened from the submittal it came out of - and back.
 *
 * Cost and time impact are stored as explicit three-state values (yes / no / not stated)
 * rather than booleans, because "nobody answered" is different from "no", and printing
 * "No" when nobody said so would be a fabrication.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('rfis', function (Blueprint $t) {
            $t->string('spec_section')->nullable();
            $t->string('plan_sheets')->nullable();          // L2.01-L2.05, I-14 …
            $t->string('reference')->nullable();            // RFI-007/007.1; Q&A 4.20 …
            $t->string('schedule_impact', 16)->nullable();  // yes | no | not_stated
            $t->foreignId('linked_submittal_id')->nullable()->index();
        });

        // cost_impact was a boolean; a boolean cannot say "nobody answered".
        Schema::table('rfis', function (Blueprint $t) {
            $t->string('cost_impact_state', 16)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('rfis', function (Blueprint $t) {
            $t->dropColumn(['spec_section', 'plan_sheets', 'reference', 'schedule_impact', 'linked_submittal_id', 'cost_impact_state']);
        });
    }
};
