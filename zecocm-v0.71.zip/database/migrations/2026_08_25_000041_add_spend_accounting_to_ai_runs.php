<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * D8: the spend cap that was checked against a counter nothing ever updated.
 *
 * `budget_used_micros` has existed since the governed-intelligence migration
 * and is incremented by exactly nothing. `cost_micros`, `input_tokens` and
 * `output_tokens` are columns on `ai_runs` that no code path has ever written.
 * The controller reads the counter and refuses at 402 when it is exhausted -
 * which it never is, because it never moves. An inert control presented as
 * enforced is worse than no control, because it is relied on.
 *
 * Three columns are added here, and each of them exists because of a distinct
 * way the naive fix would still be wrong.
 *
 * `cost_measured` on ai_runs. A run whose cost could not be established must
 * NOT be recorded as having cost nothing. Zero and unknown are different facts,
 * and writing unknown as zero would rebuild the same lie one level down.
 *
 * `unmeasured_run_count` on capability_grants. Once a single run's cost is
 * unknown, the account's total spend is no longer a number - it is a lower
 * bound. The cap can still be enforced against what IS known, but nothing may
 * report it as an accurate total, and this counter is what makes the difference
 * visible instead of silently swallowed.
 *
 * `budget_reserved_micros` on capability_grants. The original check was
 * check-then-act: read the counter, dispatch the job, settle later. Ten runs
 * dispatched in the same second each read the same pre-run counter and each
 * pass. Reserving an estimated ceiling before dispatch and settling to actual
 * afterwards is what makes the cap hold under concurrency, and it is why a
 * reservation must be released on every terminal outcome - including failure,
 * because a job that dies still has to give the money back.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_runs', function (Blueprint $t) {
            $t->boolean('cost_measured')->default(false);
        });

        Schema::table('capability_grants', function (Blueprint $t) {
            $t->unsignedBigInteger('budget_reserved_micros')->default(0);
            $t->unsignedInteger('unmeasured_run_count')->default(0);
        });
    }

    public function down(): void
    {
        Schema::table('ai_runs', function (Blueprint $t) {
            $t->dropColumn('cost_measured');
        });

        Schema::table('capability_grants', function (Blueprint $t) {
            $t->dropColumn(['budget_reserved_micros', 'unmeasured_run_count']);
        });
    }
};
