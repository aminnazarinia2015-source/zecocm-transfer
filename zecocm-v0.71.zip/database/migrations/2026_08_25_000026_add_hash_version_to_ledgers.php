<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Which canonicalization rule each record's hash was computed under.
 *
 * Changing how a hash is computed retroactively invalidates every record written
 * under the old rule. Without a version marker the ledger would appear tampered
 * the moment the fix shipped - which is the opposite of what a fix should do.
 *
 * NULL means v1: whatever the writer happened to hand json_encode. Those records
 * stay verifiable for linkage and sequence, and honestly reported as not
 * content-verifiable. New records carry 'v2' and verify end to end.
 */
return new class extends Migration
{
    public function up(): void
    {
        foreach (['knowledge_review_events', 'quality_item_events'] as $table) {
            if (Schema::hasTable($table) && ! Schema::hasColumn($table, 'hash_version')) {
                Schema::table($table, function (Blueprint $t) {
                    $t->string('hash_version', 8)->nullable()->index();
                });
            }
        }
    }

    public function down(): void
    {
        foreach (['knowledge_review_events', 'quality_item_events'] as $table) {
            if (Schema::hasTable($table) && Schema::hasColumn($table, 'hash_version')) {
                Schema::table($table, fn (Blueprint $t) => $t->dropColumn('hash_version'));
            }
        }
    }
};
