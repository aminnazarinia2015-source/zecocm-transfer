<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Identity for issued documents.
 *
 * A ZecoCM transmittal carries NO ZecoCM branding. It is the account owner's document,
 * addressed to the account owner's counterparty, and both identities have to live on a
 * record rather than being typed into a Word header every time.
 *
 * issued_documents is an append-only register: every time a transmittal is issued, the
 * exact rendered bytes are fingerprinted and recorded, so a copy in someone's inbox can
 * be proved to be the copy that was issued - or proved not to be.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $t) {
            $t->string('legal_name')->nullable();
            $t->json('address_lines')->nullable();
            $t->string('brand_accent', 16)->nullable();
            $t->string('brand_mark', 8)->nullable();      // short monogram used when no logo is set
        });

        Schema::table('projects', function (Blueprint $t) {
            $t->string('site_address')->nullable();
            $t->json('owner_address_lines')->nullable();
            $t->string('owner_contact')->nullable();
        });

        Schema::create('issued_documents', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->index();
            $t->foreignId('project_id')->index();
            $t->string('record_type', 24);               // rfi | submittal
            $t->unsignedBigInteger('record_id');
            $t->string('document_number', 64);           // e.g. RFI-009
            $t->unsignedInteger('revision')->default(1);
            $t->string('content_sha256', 64);
            $t->json('parties');
            $t->json('clock')->nullable();
            $t->json('attachments')->nullable();
            $t->foreignId('issued_by')->nullable();
            $t->timestamp('issued_at');
            $t->timestamps();
            $t->index(['record_type', 'record_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('issued_documents');
        Schema::table('projects', function (Blueprint $t) {
            $t->dropColumn(['site_address', 'owner_address_lines', 'owner_contact']);
        });
        Schema::table('tenants', function (Blueprint $t) {
            $t->dropColumn(['legal_name', 'address_lines', 'brand_accent', 'brand_mark']);
        });
    }
};
