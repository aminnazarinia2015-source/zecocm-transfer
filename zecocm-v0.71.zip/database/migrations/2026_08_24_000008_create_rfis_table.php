<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('rfis', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->string('number');
            $t->string('subject');
            $t->text('question');
            $t->string('raised_by_org');
            $t->date('raised_at');
            $t->string('ball_in_court');
            $t->string('cost_impact')->default('unknown'); // unknown|no|yes
            $t->string('status')->default('open');
            $t->text('response')->nullable();
            $t->json('response_seal')->nullable();
            $t->json('ai_dispositions');        // every suggestion/escalation + human action (Aspect 19)
            $t->json('routing_history');
            $t->timestamps();
            $t->unique(['project_id', 'number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rfis');
    }
};
