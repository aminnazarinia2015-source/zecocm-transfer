<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->string('number');               // e.g. 3115
            $t->string('name');
            $t->string('sector');               // public|commercial|residential + custom
            $t->string('owner_name');           // the City / property owner
            $t->string('state', 8)->default('CA');
            $t->string('funding_source')->nullable(); // local|state|federal
            $t->date('ntp_date')->nullable();
            $t->unsignedInteger('duration_days')->nullable();
            $t->string('duration_basis')->default('working');
            $t->unsignedInteger('extension_days')->default(0);   // approved COs only
            $t->decimal('ld_per_day', 12, 2)->nullable();
            $t->json('contract_clocks');        // {submittal_review:{days,basis},rfi:{...},payapp_review:{...},payment:{...},change_notice:{...}} each w/ source citation
            $t->json('org_structure');          // the drag-and-drop delegation graph
            $t->timestamps();
            $t->index(['tenant_id', 'number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
