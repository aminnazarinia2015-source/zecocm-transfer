<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - closed design, see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Codex's finding: the citation shape Gemini proposed (a couple of ID fields
 * embedded directly in a finding's JSON) is not really a citation - it names
 * a date range and a count, not the actual records that were checked. This
 * table is a real evidence/audit trail: one row per source record an
 * AiFinding actually rests on, with an explicit evidence_role so a reader
 * can tell a record that supports the finding from one that was expected but
 * missing, from one that's only context.
 *
 * source_type + source_id is a plain polymorphic locator (daily_report,
 * schedule_activity, schedule_version, pay_application_line,
 * sov_schedule_link, ...) rather than a set of nullable foreign keys, because
 * the set of evidence types this cites is expected to grow (Codex's point 4 -
 * inspection photos, RFIs, and change events are all legitimate future
 * evidence types) without needing a new nullable FK column added here every
 * time. source_revision_id is nullable and unused today (daily_reports has no
 * revision concept yet - corrections are append-only inside the report
 * itself) but the column exists now so a future revisioned source does not
 * require a migration to become citable.
 *
 * Append-only: a finding's evidence is fixed at the moment the finding was
 * computed (see AiFinding.evaluated_at) and never edited after the fact - a
 * later re-evaluation produces a new AiFinding with its own new evidence
 * rows, exactly like RetrievalTrace's existing append-only pattern.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('finding_evidence', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('ai_finding_id')->constrained();
            $t->string('source_type', 32); // daily_report | schedule_activity | schedule_version | pay_application_line | sov_schedule_link
            $t->unsignedBigInteger('source_id');
            $t->string('source_revision_id', 64)->nullable();
            $t->string('evidence_role', 24); // SUPPORTS | CONTRADICTS | EXPECTED_BUT_MISSING | CONTEXT | MAPPING_BASIS
            $t->json('locator')->nullable(); // any extra detail needed to find the specific fact cited
            $t->timestampTz('created_at');
            $t->index(['tenant_id', 'ai_finding_id']);
            $t->index(['source_type', 'source_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('finding_evidence');
    }
};
