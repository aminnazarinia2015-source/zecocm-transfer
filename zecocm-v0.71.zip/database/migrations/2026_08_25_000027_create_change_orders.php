<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The executed change order, and the record of what it did to the contract.
 *
 * Amounts in integer cents, same reason as the pay application: a contract sum
 * that is a penny off does not reconcile, and an application that does not
 * reconcile is returned.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('change_orders', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->string('number', 32);
            $t->string('title', 255);
            $t->string('origin_reason', 48)->nullable(); // differing site condition, owner request, ...
            $t->date('identified_at')->nullable();
            // draft -> submitted -> under_review -> negotiation -> approved|rejected|withdrawn|void
            $t->string('status', 24)->default('draft');
            $t->bigInteger('amount_cents')->default(0);       // signed: a CO may reduce the contract
            $t->integer('time_extension_days')->default(0);
            $t->string('funding_source', 48)->nullable();     // base|contingency|allowance|separate
            $t->timestampTz('approved_at')->nullable();
            $t->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $t->json('seal')->nullable();
            $t->timestampsTz();
            $t->unique(['project_id', 'number']);
        });

        Schema::create('change_order_allocations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('change_order_id')->constrained()->cascadeOnDelete();
            // Null means: this allocation creates a NEW schedule-of-values line for
            // distinct added scope, rather than adjusting an existing one.
            $t->foreignId('schedule_of_value_item_id')->nullable()
                ->constrained('schedule_of_value_items')->cascadeOnDelete();
            $t->string('new_item_number', 32)->nullable();
            $t->string('new_item_description', 255)->nullable();
            $t->bigInteger('amount_cents');
            // Why this belongs on an existing line rather than its own. Required
            // when adjusting, because "it is roughly the same area of work" is how
            // added scope disappears into a base line.
            $t->text('same_scope_justification')->nullable();
            $t->timestampsTz();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('change_order_allocations');
        Schema::dropIfExists('change_orders');
    }
};
