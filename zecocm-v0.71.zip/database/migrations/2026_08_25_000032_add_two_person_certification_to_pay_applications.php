<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Two people, and a hash that makes it mean something.
 *
 * Above about twenty employees the person who bills is not the person who
 * certifies, and a workflow that lets one account do both because it holds both
 * permissions has implemented the org chart, not the control.
 *
 * The second half matters more than the first. A separate certifier who signs a
 * document that can still be edited afterwards has certified nothing - the
 * signature outlives the thing it was applied to. So certification binds to an
 * exact content hash, and any financial change after it voids the certification
 * and sends the application back for correction.
 *
 * Without that, two-person review is cosmetic.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pay_applications', function (Blueprint $t) {
            $t->foreignId('prepared_by')->nullable()->constrained('users');
            $t->foreignId('certified_by')->nullable()->constrained('users');
            $t->timestampTz('certified_at')->nullable();
            $t->string('certified_content_hash', 128)->nullable();
        });

        Schema::table('projects', function (Blueprint $t) {
            // Per project, because it is the project's payment workflow. A global
            // toggle would be the wrong shape - one company runs both kinds of
            // job at once.
            $t->json('payment_workflow')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('pay_applications', function (Blueprint $t) {
            $t->dropColumn(['prepared_by', 'certified_by', 'certified_at', 'certified_content_hash']);
        });
        Schema::table('projects', function (Blueprint $t) {
            $t->dropColumn('payment_workflow');
        });
    }
};
