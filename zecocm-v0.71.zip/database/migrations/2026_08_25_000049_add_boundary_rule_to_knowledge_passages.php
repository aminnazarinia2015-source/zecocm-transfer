<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * D3: chunking never recorded which boundary rule produced a passage. That
 * made "we chunked well" and "we got lucky" indistinguishable from the data
 * itself - the same defect the register named for D6 (no retrieval
 * evaluation harness) applied one layer downstream, to chunking itself.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('knowledge_passages', function (Blueprint $t) {
            $t->string('boundary_rule', 24)->nullable()->after('section_ref');
        });
    }

    public function down(): void
    {
        Schema::table('knowledge_passages', function (Blueprint $t) {
            $t->dropColumn('boundary_rule');
        });
    }
};
