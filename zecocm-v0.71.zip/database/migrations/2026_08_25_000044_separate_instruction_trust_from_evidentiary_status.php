<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Codex's most valuable finding of the day, and it is a type-level error rather
 * than a bug: I built a good AUTHORIZATION system and mistook it for a SAFETY
 * system.
 *
 * Every control in AcquisitionGate answers one question - MAY THIS BE FETCHED.
 * Host, expiry, document count, two-person confirmation, tenant. Not one of
 * them answers the other question: WHAT HAPPENS WHEN THE THING WE CORRECTLY
 * AUTHORISED IS HOSTILE. A document written specifically to manipulate the
 * model, or the steward reviewing it, passes every one of those checks by
 * arriving through exactly the path we deliberately opened.
 *
 * The error was in the state machine itself. `quarantine_state` moving
 * quarantined -> verified reads on its face as "now trusted", and a later
 * developer would reasonably read it that way. But verification can only ever
 * mean:
 *
 *   A steward confirmed WHAT THIS DOCUMENT IS and that it is admissible for
 *   its stated evidentiary purpose.
 *
 * It can never mean:
 *
 *   Instructions contained inside this document may influence how TRACE
 *   operates.
 *
 * So there are two axes, and only one of them ever moves.
 *
 *   evidentiary_status   quarantined -> verified -> (rejected | retracted)
 *                        A steward's determination. Changes.
 *
 *   instruction_trust    external_untrusted, permanently
 *                        Never changes. Not by verification, not by age, not
 *                        by a second steward, not by anybody.
 *
 * The column below has exactly one legal value, and that is the point. It
 * exists so that every passage, every index row, every retrieval candidate and
 * every context assembly carries the fact of external origin with it, rather
 * than inheriting it from a parent record that will eventually be lost in some
 * denormalised search representation. A trust label that survives chunking is a
 * control; a trust label that lives only on the document row is a comment.
 *
 * Also here, from the same review:
 *
 * `max_total_bytes`. A document count bounds how MANY things arrive and says
 * nothing about how much. One "document" can be a 2 KB page or an 18 GB
 * archive or a three-thousand-page scan. Count bounds breadth; bytes bound
 * volume; time is the backstop on the authorisation itself.
 *
 * `documents_reserved`. The count check was read-then-fetch: two workers both
 * see nineteen of twenty and both proceed. Slots are now reserved atomically
 * before the reach and released if it fails, which is the same lesson the AI
 * budget gate learned three hours ago and I did not carry across.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('acquired_documents', function (Blueprint $t) {
            // Permanently 'external_untrusted'. There is no transition out of
            // it and no code path that writes any other value.
            $t->string('instruction_trust', 24)->default('external_untrusted');
            // The bytes exactly as they arrived, hashed separately from any
            // extracted text. A sanitised rendering must never replace the
            // original: if an attacker wrote an instruction into the document
            // and our extraction strips it, a later forensic review would see a
            // cleaner document than the one the system actually received.
            $t->string('original_content_hash', 64)->nullable();
            $t->json('acquisition_metadata')->nullable();
            // Every hop revalidated. An authorised host that redirects to an
            // unauthorised one is a new reach, not a continuation.
            $t->json('redirect_chain')->nullable();
            // A response that arrived after the window was revoked may not be
            // silently admitted. We cannot recall packets already in flight;
            // we can refuse to treat what comes back as authorised.
            $t->boolean('retrieved_after_revocation')->default(false);
        });

        Schema::table('acquisition_windows', function (Blueprint $t) {
            $t->unsignedBigInteger('max_total_bytes')->default(52_428_800);
            $t->unsignedBigInteger('bytes_acquired')->default(0);
            $t->unsignedInteger('documents_reserved')->default(0);
        });

        Schema::table('capability_gaps', function (Blueprint $t) {
            // Codex's (h): the OFF_LIMITS substring match is theatre. A
            // proposal reading "the system is too conservative when documents
            // conflict" never contains the string refusal_policy. What must be
            // protected is the CAPABILITY BEING TOUCHED, which instrumentation
            // knows deterministically, not the words somebody chose.
            $t->string('target_capability', 64)->nullable();
            // Codex's (i): counts measure frequency, not value. Three people
            // hitting the same broken project state is one incident.
            $t->unsignedInteger('distinct_projects')->default(0);
            $t->string('materiality', 32)->nullable();
            $t->boolean('reproducible')->default(false);
            // Codex's (k), accepted without argument: at this sample size,
            // counts drawn largely from the builders testing their own known
            // gaps are false sophistication. Every gap now discloses whether
            // its evidence includes non-developer usage, and nothing is called
            // a recommendation until it does.
            $t->boolean('includes_external_usage')->default(false);
        });
    }

    public function down(): void
    {
        Schema::table('acquired_documents', function (Blueprint $t) {
            $t->dropColumn(['instruction_trust', 'original_content_hash', 'acquisition_metadata',
                'redirect_chain', 'retrieved_after_revocation']);
        });

        Schema::table('acquisition_windows', function (Blueprint $t) {
            $t->dropColumn(['max_total_bytes', 'bytes_acquired', 'documents_reserved']);
        });

        Schema::table('capability_gaps', function (Blueprint $t) {
            $t->dropColumn(['target_capability', 'distinct_projects', 'materiality',
                'reproducible', 'includes_external_usage']);
        });
    }
};
