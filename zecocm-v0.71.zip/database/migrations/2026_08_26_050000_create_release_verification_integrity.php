<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * REL-1: Release Verification Integrity. Codex's own framing for why this
 * row exists, verbatim from the design exchange: "the next real risk is not
 * 'missing capability'; it is deploying a build whose verification surface
 * has silently changed." This is the same class of failure as the TR-17
 * near-miss (`claude/closure-progress.md`'s "A near-miss worth recording") -
 * a test file silently overwritten, the suite still green, and the only
 * thing that caught it was hand arithmetic on the test-count delta. REL-1
 * makes that arithmetic a machine-enforced gate on every release candidate
 * rather than a discipline someone has to remember to apply.
 *
 * `release_manifests`: one immutable row per release candidate build
 * attempt - including FAILED attempts, deliberately. A refused build is
 * exactly the evidentiary event this row exists to prove happened: someone
 * tried to package a release whose verification surface had silently
 * shrunk, and it was caught before the tarball reached the deploy queue.
 * Never updated in place - a corrected build is a new manifest row, same
 * "new version, not an overwrite" discipline as every other evidentiary
 * record in this codebase (EV-13, D4's re-OCR, DATA-3's migrations).
 *
 * `release_deployments`: append-only ledger of actual deploy attempts
 * against a manifest, mirroring EV-14B's execution-ledger pattern rather
 * than a mutable "is this deployed" column on the manifest itself - a
 * manifest's own verification facts (what was tested, what was packaged)
 * must never be conflated with what actually happened to it in production
 * afterward. `release:check-deploy-order` reads this table to confirm a
 * version's declared dependencies were actually deployed before it, rather
 * than trusting human memory of the queue order.
 *
 * `protected_content_hashes` on `release_manifests` closes Codex's first
 * adversarial finding on this row's own review: a protected regression's
 * test ID surviving is not proof its BODY survived - "same test ID, weaker
 * test" would sail through an ID-only diff. Each protected test id's method
 * body (by source line range, via Reflection) is hashed at build time and
 * compared to the same id's hash in the baseline manifest; a change with no
 * matching justification fails the build, exactly like a removal.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('release_manifests', function (Blueprint $table) {
            $table->id();
            $table->string('version')->unique();
            $table->string('source_commit');
            $table->string('tarball_path')->nullable();
            $table->string('tarball_sha256')->nullable();
            $table->json('migration_files'); // [{file, sha256}]
            $table->json('test_ids'); // stable ["Class::method", ...] snapshot at build time
            $table->unsignedInteger('total_tests');
            $table->unsignedInteger('total_assertions')->nullable();
            $table->string('baseline_version')->nullable();
            $table->json('tests_added'); // [test_id, ...]
            $table->json('tests_removed'); // [test_id, ...] - only ever non-empty alongside a matching justification
            $table->json('removal_justifications'); // [{test_id, reason, authorized_by, renamed_to?}] - also covers content-change acknowledgments
            $table->json('protected_content_hashes'); // {test_id: sha256 of its method body}, for protected ids only
            $table->json('required_suites'); // [ClassName, ...] this release must still carry
            $table->json('depends_on'); // [version, ...] - must be release_deployments-confirmed before this deploys
            $table->string('verification_status'); // verified|failed
            $table->json('verification_failures'); // [reason, ...] - empty iff verified
            $table->timestamp('created_at');
        });

        Schema::create('release_deployments', function (Blueprint $table) {
            $table->id();
            $table->string('version');
            $table->foreignId('release_manifest_id')->nullable()->constrained('release_manifests');
            $table->timestamp('deployed_at');
            $table->string('deployed_by');
            $table->string('verify_live_result'); // e.g. "V092_LIVE ... http=200" or "V092_DEPLOY_FAILED ..."
            $table->boolean('http_healthy');
            $table->index('version');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('release_deployments');
        Schema::dropIfExists('release_manifests');
    }
};
