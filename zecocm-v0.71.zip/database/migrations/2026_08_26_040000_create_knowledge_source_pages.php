<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * D4: the page-level extraction record Codex's ruling asked for. Confidence,
 * extraction method, OCR engine/version, render DPI, and sheet identity are
 * all per-page facts on a real document - a 150-page drawing/spec set can mix
 * born-digital and scanned pages, and a single document-level scalar (the
 * pre-existing knowledge_source_versions.extraction_confidence) would lie
 * about all of them. This table is where D4 puts those facts instead of
 * overloading document-level metadata.
 *
 * Never backfilled onto historical data (DATA-3's own rule): this table is
 * populated only for source versions ingested after this row lands. An
 * existing knowledge_source_version with no rows here is honestly silent
 * about per-page provenance, not falsely populated with an inferred one.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('knowledge_source_pages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_version_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('page_number');
            $t->string('page_hash', 64)->nullable();
            $t->unsignedInteger('page_width')->nullable();
            $t->unsignedInteger('page_height')->nullable();
            $t->boolean('text_layer_present')->default(false);
            // born_digital | ocr | failed | skipped_bound
            $t->string('extraction_method', 24);
            $t->decimal('extraction_confidence', 5, 4)->nullable();
            $t->string('ocr_engine', 48)->nullable();
            $t->string('ocr_engine_version', 32)->nullable();
            $t->unsignedInteger('render_dpi')->nullable();
            $t->string('sheet_ref', 96)->nullable();
            $t->string('sheet_title', 255)->nullable();
            // none | detected | confirmed
            $t->string('sheet_detection_status', 16)->default('none');
            $t->decimal('sheet_detection_confidence', 5, 4)->nullable();
            $t->json('warnings')->nullable();
            $t->timestampsTz();
            $t->unique(['knowledge_source_version_id', 'page_number']);
            $t->index(['tenant_id', 'project_id'], 'knowledge_source_page_scope_idx');
        });

        // Passages already carry page_from/page_to and sheet_ref/coordinates
        // (compatibility, per Codex's ruling) - this FK is the precise link a
        // passage's provenance actually resolves through, when one exists.
        Schema::table('knowledge_passages', function (Blueprint $t) {
            $t->foreignId('source_page_id')->nullable()->after('knowledge_source_version_id')
                ->constrained('knowledge_source_pages')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('knowledge_passages', function (Blueprint $t) {
            $t->dropConstrainedForeignId('source_page_id');
        });
        Schema::dropIfExists('knowledge_source_pages');
    }
};
