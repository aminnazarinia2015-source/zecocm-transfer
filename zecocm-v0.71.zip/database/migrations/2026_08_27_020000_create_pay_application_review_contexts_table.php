<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - closed design, see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Codex's second finding: computing findings against "whatever ScheduleVersion
 * is active" is a temporal-leakage bug - a pay application reviewed in July and
 * re-analyzed in October could produce different TRACE findings purely because
 * the schedule moved on in the meantime, even though nothing about the July
 * pay application itself changed. This table freezes the comparison context
 * the moment a pay application enters review: which schedule version and data
 * date applied, and what period it covers. Every AiFinding for that review
 * cites this row, not a live lookup, so the finding stays reproducible forever.
 *
 * One row is written once, at freeze time, and never edited - a later
 * re-evaluation against a newer schedule version creates its own new context
 * row (and its own new AiFinding rows), it never overwrites this one. That is
 * why there is no update path in the model and no "current schedule version"
 * column that could drift.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pay_application_review_contexts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('pay_application_id')->constrained();
            $t->date('period_start');
            $t->date('period_end');
            $t->foreignId('schedule_version_id')->constrained();
            $t->date('schedule_data_date'); // copied from ScheduleVersion.data_date at freeze time
            $t->foreignId('created_by')->nullable()->constrained('users');
            $t->timestampTz('frozen_at');
            $t->timestamps();
            $t->index(['tenant_id', 'pay_application_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pay_application_review_contexts');
    }
};
