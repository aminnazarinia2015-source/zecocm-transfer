<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $t) {
            $t->decimal('lat', 9, 6)->nullable();
            $t->decimal('lng', 9, 6)->nullable();
        });
        // Real coordinates for the two seeded projects.
        DB::table('projects')->where('number', '3114')->update(['lat' => 33.9533, 'lng' => -117.3961]); // Riverside
        DB::table('projects')->where('number', '3115')->update(['lat' => 33.8894, 'lng' => -118.1597]); // Paramount
    }

    public function down(): void
    {
        Schema::table('projects', function (Blueprint $t) {
            $t->dropColumn(['lat', 'lng']);
        });
    }
};
