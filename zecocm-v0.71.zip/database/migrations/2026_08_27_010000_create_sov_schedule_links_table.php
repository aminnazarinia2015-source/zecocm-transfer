<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - closed design, see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Codex's central finding in that review: a Pay Application's Schedule of
 * Values line and a schedule's activities describe the same project at
 * different levels of abstraction, and inferring which ones correspond at
 * request time (a "semantic mapping step") is exactly the kind of guess an
 * evidence-first system cannot base a finding on. This table is the fix - an
 * explicit, human-verified many-to-many relationship. AI may populate a row
 * with mapping_source=AI_SUGGESTED, but it is never treated as evidence
 * until a human moves mapping_status to VERIFIED (see SovScheduleLink model
 * for the transitions this table actually allows).
 *
 * Many-to-many because one pay item can correspond to several activities and
 * one activity can contribute to several pay items (e.g. a single "concrete"
 * SOV line spanning form/pour/cure activities). schedule_version_id makes a
 * link specific to one schedule version rather than "whatever is active
 * now" - a later schedule revision does not silently reinterpret an old
 * verified mapping; a new version gets its own link, verified again.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sov_schedule_links', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('schedule_of_value_item_id')->constrained();
            $t->foreignId('schedule_activity_id')->constrained();
            $t->foreignId('schedule_version_id')->constrained();
            $t->string('relationship_type', 32); // DIRECT | CONTRIBUTES_TO | SUPPORTS | NOT_PROGRESS_BEARING
            $t->string('mapping_source', 16); // CONTRACTOR | PM | IMPORT | AI_SUGGESTED
            $t->string('mapping_status', 16)->default('UNVERIFIED'); // UNVERIFIED | VERIFIED | REJECTED
            $t->decimal('allocation_weight', 5, 4)->nullable(); // optional; not required initially
            $t->foreignId('verified_by')->nullable()->constrained('users');
            $t->timestampTz('verified_at')->nullable();
            $t->date('effective_from')->nullable();
            $t->date('effective_to')->nullable();
            $t->text('notes')->nullable();
            $t->timestamps();
            $t->index(['tenant_id', 'schedule_of_value_item_id']);
            $t->index(['tenant_id', 'schedule_activity_id']);
            $t->unique(
                ['schedule_of_value_item_id', 'schedule_activity_id', 'schedule_version_id'],
                'sov_schedule_links_unique_pair_per_version'
            );
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sov_schedule_links');
    }
};
