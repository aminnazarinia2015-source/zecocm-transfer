<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * WHICH PART of a document a later one actually replaced.
 *
 * D5's real closure condition, and the reason it has been sitting at PARTIAL.
 * Today a confirmed supersession edge retires a whole source version, so an
 * addendum that changes two paragraphs of a 2024 specification takes the other
 * four hundred with it. Every unaffected provision goes dark, and TRACE stops
 * being able to cite requirements that are still perfectly operative.
 *
 * The model is an OVERLAY, not a version chain. The question is never "is this
 * PDF old" - it is "is this particular requirement currently operative".
 *
 * Backward compatible on purpose: an edge with no scope rows still means the
 * whole document, which is exactly what the existing edges assert and all they
 * were ever able to assert. Adding scopes REFINES an edge rather than replacing
 * the concept, so nothing already confirmed by a steward silently changes
 * meaning.
 *
 * Two rules live in the columns rather than in code comments.
 *
 * relation distinguishes replace and delete - which retire text - from
 * supplement and clarify, which do not. An additive addendum is not supersession
 * at all: both sources stay operative and the effective requirement is their
 * combination.
 *
 * status carries proposed and unresolved as first-class states. A scope TRACE
 * inferred from wording is a proposal, never an overlay. Letting a semantic
 * guess retire contract text would make AI interpretation into contract
 * amendment, which is the one thing this system exists not to do.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('supersession_scopes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->unsignedBigInteger('knowledge_source_edge_id');
            // document | section | clause | passage_range | sheet | detail | schedule
            $t->string('scope_type', 24);
            // replace | delete | supplement | clarify
            $t->string('relation', 16);
            // What the modifying instrument called it, verbatim: "3.2.B".
            $t->string('label_claimed', 160)->nullable();
            // How we located it. Structural where the document has structure,
            // passage range where it does not.
            $t->string('locator_method', 24)->default('section_ref');
            $t->string('target_section_ref', 160)->nullable();
            $t->string('target_sheet_ref', 96)->nullable();
            $t->foreignId('start_passage_id')->nullable();
            $t->foreignId('end_passage_id')->nullable();
            // Guards against locator drift when a document is re-extracted: if
            // the text under the locator is not the text the scope was confirmed
            // against, the overlay is stale and must not be applied silently.
            $t->string('target_content_hash', 64)->nullable();
            $t->decimal('match_confidence', 5, 4)->nullable();
            // confirmed | proposed | unresolved
            $t->string('status', 16)->default('proposed');
            $t->foreignId('confirmed_by')->nullable()->constrained('users');
            $t->timestampTz('confirmed_at')->nullable();
            $t->string('notes', 1000)->nullable();
            $t->timestampsTz();
            $t->index(['knowledge_source_edge_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('supersession_scopes');
    }
};
