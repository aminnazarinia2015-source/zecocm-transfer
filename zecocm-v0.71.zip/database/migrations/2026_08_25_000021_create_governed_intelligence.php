<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('knowledge_sources', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->uuid('public_id')->unique();
            $t->string('collection', 32); // project|organization|city|regulatory|product_help|anonymized_learning
            $t->string('title', 255);
            $t->string('source_type', 48);
            $t->string('jurisdiction', 128)->nullable();
            $t->string('organization', 160)->nullable();
            $t->string('discipline', 64)->nullable();
            $t->string('authority_level', 32)->default('party_assertion');
            $t->string('access_classification', 32)->default('project_private');
            $t->string('verification_status', 24)->default('provisional');
            $t->string('ingestion_status', 24)->default('pending');
            $t->string('mime_type', 128)->nullable();
            $t->string('storage_path', 500);
            $t->unsignedBigInteger('byte_size')->nullable();
            $t->string('sha256', 64);
            $t->string('malware_scan_status', 24)->default('pending');
            $t->text('quarantine_reason')->nullable();
            $t->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTimeTz('verified_at')->nullable();
            $t->timestampsTz();
            $t->unique(['tenant_id', 'project_id', 'sha256']);
            $t->index(['tenant_id', 'project_id', 'collection', 'verification_status'], 'knowledge_source_scope_idx');
        });

        Schema::create('knowledge_source_versions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('knowledge_source_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('version_number');
            $t->string('edition', 96)->nullable();
            $t->string('revision', 96)->nullable();
            $t->dateTimeTz('effective_from')->nullable();
            $t->dateTimeTz('effective_until')->nullable();
            $t->string('sha256', 64);
            $t->string('extraction_method', 48);
            $t->decimal('extraction_confidence', 5, 4)->nullable();
            $t->string('parser_version', 64);
            $t->json('classification')->nullable();
            $t->timestampsTz();
            $t->unique(['knowledge_source_id', 'version_number']);
            $t->unique(['knowledge_source_id', 'sha256']);
        });

        Schema::create('knowledge_passages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_version_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('ordinal');
            $t->unsignedInteger('page_from')->nullable();
            $t->unsignedInteger('page_to')->nullable();
            $t->string('section_ref', 160)->nullable();
            $t->string('sheet_ref', 96)->nullable();
            $t->text('body');
            $t->string('body_sha256', 64);
            $t->json('coordinates')->nullable();
            $t->json('classification')->nullable();
            $t->timestampsTz();
            $t->unique(['knowledge_source_version_id', 'ordinal']);
            $t->index(['tenant_id', 'project_id'], 'knowledge_passage_scope_idx');
        });

        Schema::create('knowledge_source_edges', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('from_version_id')->constrained('knowledge_source_versions')->cascadeOnDelete();
            $t->foreignId('to_version_id')->constrained('knowledge_source_versions')->cascadeOnDelete();
            $t->string('relationship', 32); // supersedes|amends|conflicts_with|interprets|derived_from
            $t->string('status', 24)->default('proposed');
            $t->foreignId('confirmed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTimeTz('confirmed_at')->nullable();
            $t->timestampsTz();
            $t->unique(['from_version_id', 'to_version_id', 'relationship'], 'knowledge_edge_unique');
        });

        Schema::create('knowledge_review_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('knowledge_source_id')->constrained()->cascadeOnDelete();
            $t->string('action', 32);
            $t->string('from_status', 24)->nullable();
            $t->string('to_status', 24);
            $t->text('reason')->nullable();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('previous_event_hash', 64)->nullable();
            $t->string('event_hash', 64);
            $t->timestampsTz();
            $t->index(['tenant_id', 'knowledge_source_id']);
        });

        Schema::create('ai_runs', function (Blueprint $t) {
            $t->id();
            $t->uuid('public_id')->unique();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('requested_by')->nullable()->constrained('users')->nullOnDelete();
            $t->string('idempotency_key', 128);
            $t->string('task_type', 48);
            $t->string('category', 64);
            $t->text('question');
            $t->string('status', 24)->default('queued');
            $t->unsignedTinyInteger('progress')->default(0);
            $t->string('provider', 32)->nullable();
            $t->string('model', 96)->nullable();
            $t->string('prompt_version', 64);
            $t->string('retrieval_version', 64);
            $t->string('policy_version', 64);
            $t->json('authorization_scope');
            $t->json('retrieval_scope');
            $t->json('source_manifest')->nullable();
            $t->json('assumptions')->nullable();
            $t->json('result')->nullable();
            $t->string('result_classification', 32)->nullable();
            $t->string('confidence', 16)->nullable();
            $t->unsignedInteger('input_tokens')->nullable();
            $t->unsignedInteger('output_tokens')->nullable();
            $t->unsignedBigInteger('cost_micros')->nullable();
            $t->unsignedInteger('latency_ms')->nullable();
            $t->text('error')->nullable();
            $t->dateTimeTz('cancel_requested_at')->nullable();
            $t->dateTimeTz('started_at')->nullable();
            $t->dateTimeTz('completed_at')->nullable();
            $t->timestampsTz();
            $t->unique(['tenant_id', 'idempotency_key']);
            $t->index(['tenant_id', 'project_id', 'status']);
        });

        Schema::create('ai_run_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('ai_run_id')->constrained()->cascadeOnDelete();
            $t->string('event', 32);
            $t->json('payload')->nullable();
            $t->string('previous_event_hash', 64)->nullable();
            $t->string('event_hash', 64);
            $t->timestampsTz();
        });

        Schema::create('ai_feedback_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('ai_run_id')->constrained()->cascadeOnDelete();
            $t->string('label', 32); // accepted|rejected|corrected|outcome_recorded
            $t->text('comment')->nullable();
            $t->json('correction')->nullable();
            $t->json('outcome')->nullable();
            $t->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->timestampsTz();
        });

        Schema::table('capability_grants', function (Blueprint $t) {
            $t->string('model_tier', 32)->nullable();
            $t->json('allowed_tasks')->nullable();
            $t->unsignedBigInteger('budget_limit_micros')->nullable();
            $t->unsignedBigInteger('budget_used_micros')->default(0);
        });
    }

    public function down(): void
    {
        Schema::table('capability_grants', function (Blueprint $t) {
            $t->dropColumn(['model_tier', 'allowed_tasks', 'budget_limit_micros', 'budget_used_micros']);
        });
        Schema::dropIfExists('ai_feedback_events');
        Schema::dropIfExists('ai_run_events');
        Schema::dropIfExists('ai_runs');
        Schema::dropIfExists('knowledge_review_events');
        Schema::dropIfExists('knowledge_source_edges');
        Schema::dropIfExists('knowledge_passages');
        Schema::dropIfExists('knowledge_source_versions');
        Schema::dropIfExists('knowledge_sources');
    }
};
