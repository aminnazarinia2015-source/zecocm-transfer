<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * AUTO-2 follow-up, closing Codex's four adversarial attacks on the first
 * substrate (see claude/closure-progress.md's AUTO-2 section for the full
 * exchange):
 *
 * 1/2. Policy or system ceiling tightened between an action's creation and
 *      its execution must not let the action execute on stale authority.
 *      This migration adds no new column for that - it is enforced by
 *      AutonomousActionRecorder::executeIfStillAuthorized() re-resolving
 *      the policy/ceiling at execution time, not by data. The current
 *      seeded action always executes synchronously at creation (no gap
 *      exists yet), but the re-check method exists now so any future
 *      queued/deferred execution path is forced through it.
 *
 * 3. Uncertainty laundering - `epistemic_state` records whether the
 *    TRIGGER was resolved, unresolved, or disputed. An unresolved/disputed
 *    trigger may still auto-execute ONLY for action types registered in
 *    config/autonomy_uncertainty_preserving_actions.php as producing
 *    review/task records that preserve the uncertainty rather than assert
 *    a governed fact - everything else gets forced to at least
 *    APPROVAL_REQUIRED regardless of policy/ceiling.
 *
 * 4. Idempotency - `action_key` is a deterministic identity for "this
 *    action, for this trigger, under this rule version, given this state" -
 *    unique while the row is still active (status not in a terminal set).
 *    Re-detecting the same condition returns the existing action instead of
 *    creating a duplicate; a materially different state produces a
 *    different key and is free to create a new one.
 *
 * Also: `autonomy_observations` - Codex's point that NOT_AUTOMATABLE
 * creating no action row must not mean creating no record at all, or a
 * later reviewer cannot tell "Steward saw nothing" from "Steward saw this
 * and correctly refused to act on it."
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('autonomous_actions', function (Blueprint $table) {
            $table->string('action_key')->nullable()->after('rule_version');
            // resolved | unresolved | disputed
            $table->string('epistemic_state')->default('resolved')->after('evidence_used');
        });

        Schema::create('autonomy_observations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tenant_id')->index();
            $table->unsignedBigInteger('project_id')->index();
            $table->string('action_type')->index();
            $table->string('trigger_type');
            $table->json('trigger_record_ids');
            $table->string('reason');
            $table->timestamp('observed_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('autonomy_observations');

        Schema::table('autonomous_actions', function (Blueprint $table) {
            $table->dropColumn(['action_key', 'epistemic_state']);
        });
    }
};
