<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('media_items', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->string('sha256', 64)->index();  // content address - bytes NEVER modified
            $t->string('storage_path');         // Spaces key
            $t->string('original_name');
            $t->string('mime');
            $t->unsignedBigInteger('bytes');
            $t->json('provenance');             // sealed sidecar payload (Aspects 1-3)
            $t->string('provenance_signature', 64);
            $t->string('confidence', 16);       // strong|review|flagged
            $t->foreignId('captured_by')->constrained('users');
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('media_items');
    }
};
