<?php

use App\Domain\Licensing\CapabilityLicense;
use App\Models\CapabilityGrant;
use Illuminate\Database\Migrations\Migration;

/**
 * Data-only, no schema change. CapabilityLicense::grant() now refuses to
 * default a new ai.assist grant to BudgetGate::UNLIMITED - but that only
 * covers grants made from here on. Any ai.assist grant already sitting in
 * the database with budget_limit_micros still null (Zeco Inc.'s own seeded
 * account was found in exactly this state while investigating Amin's "how
 * do we stop unlimited usage" question) would otherwise keep running with
 * no ceiling forever, since nothing re-grants it on its own.
 *
 * This is a one-time backfill, not a guess at anyone's actual commercial
 * tier: it applies the same conservative fallback new code applies to an
 * unrecognized plan_reference (the FIELD tier's modeled monthly AI spend),
 * so every account gets SOME real ceiling today. A named admin can raise
 * or lower it for a specific account through the existing licensing
 * endpoint once its real tier is decided - this migration does not attempt
 * to make that business decision on its own.
 */
return new class extends Migration
{
    public function up(): void
    {
        CapabilityGrant::query()
            ->where('capability_key', 'ai.assist')
            ->whereNull('budget_limit_micros')
            ->get()
            ->each(function (CapabilityGrant $grant) {
                $grant->update([
                    'budget_limit_micros' => CapabilityLicense::defaultAiBudgetMicros($grant->plan_reference),
                ]);
            });
    }

    /**
     * Deliberately not reversible back to unlimited. A rollback that put
     * every account back to no AI spend ceiling would be reintroducing the
     * exact defect this migration exists to close - if a specific account
     * genuinely needs a different number, that is a licensing decision made
     * through CapabilityLicense::grant(), not a schema rollback.
     */
    public function down(): void
    {
        // Intentionally a no-op.
    }
};
