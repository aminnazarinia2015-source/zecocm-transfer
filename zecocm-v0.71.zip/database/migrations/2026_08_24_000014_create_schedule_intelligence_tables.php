<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('schedule_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('project_id')->constrained()->restrictOnDelete();
            $table->foreignId('parent_version_id')->nullable()->constrained('schedule_versions')->restrictOnDelete();
            $table->string('kind', 32);
            $table->string('label', 120);
            $table->date('data_date');
            $table->string('submitted_by_org', 160);
            $table->dateTimeTz('submitted_at');
            $table->string('review_status', 32)->default('submitted'); // verified projection only
            $table->foreignId('source_file_media_id')->constrained('media_items')->restrictOnDelete();
            $table->string('source_format', 16);
            $table->text('narrative_text')->nullable();
            $table->boolean('provisional')->default(false);
            $table->string('parser_name', 80);
            $table->string('parser_version', 40);
            $table->string('source_sha256', 64);
            $table->unsignedInteger('row_count')->default(0);
            $table->json('ingest_assumptions');
            $table->json('security_scan');
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();
            $table->index(['tenant_id', 'project_id', 'data_date']);
            $table->index(['project_id', 'parent_version_id']);
        });

        Schema::create('schedule_version_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->constrained()->restrictOnDelete();
            $table->string('event_type', 48);
            $table->string('disposition', 32)->nullable();
            $table->json('payload');
            $table->foreignId('actor_id')->nullable()->constrained('users')->restrictOnDelete();
            $table->dateTimeTz('occurred_at');
            $table->string('previous_event_hash', 64)->nullable();
            $table->string('event_hash', 64)->unique();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'schedule_version_id', 'occurred_at']);
        });

        Schema::create('schedule_calendars', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('project_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->constrained()->restrictOnDelete();
            $table->foreignId('inherits_calendar_id')->nullable()->constrained('schedule_calendars')->restrictOnDelete();
            $table->string('external_uid', 128);
            $table->string('name', 160);
            $table->string('time_zone', 64);
            $table->unsignedSmallInteger('minutes_per_day')->default(480);
            $table->string('source_basis', 40);
            $table->timestamps();
            $table->unique(['schedule_version_id', 'external_uid']);
            $table->index(['tenant_id', 'project_id']);
        });

        Schema::create('schedule_calendar_working_periods', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_calendar_id')->constrained()->restrictOnDelete();
            $table->unsignedTinyInteger('weekday_iso');
            $table->time('starts_at');
            $table->time('ends_at');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'schedule_calendar_id', 'weekday_iso']);
        });

        Schema::create('schedule_calendar_exceptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_calendar_id')->constrained()->restrictOnDelete();
            $table->date('exception_date');
            $table->boolean('is_working')->default(false);
            $table->string('label', 160)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['schedule_calendar_id', 'exception_date']);
        });

        Schema::create('schedule_calendar_exception_periods', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_calendar_exception_id')->constrained()->restrictOnDelete();
            $table->time('starts_at');
            $table->time('ends_at');
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('schedule_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->constrained()->restrictOnDelete();
            $table->uuid('canonical_id')->nullable();
            $table->string('activity_code', 128);
            $table->string('name', 500);
            $table->string('wbs_path', 1000)->nullable();
            $table->dateTimeTz('start_planned')->nullable();
            $table->dateTimeTz('finish_planned')->nullable();
            $table->dateTimeTz('start_actual')->nullable();
            $table->dateTimeTz('finish_actual')->nullable();
            $table->unsignedInteger('duration_minutes')->default(0);
            $table->integer('total_float_minutes')->nullable();
            $table->boolean('is_critical')->default(false);
            $table->boolean('is_near_critical')->default(false);
            $table->string('constraint_type', 48)->nullable();
            $table->dateTimeTz('constraint_at')->nullable();
            $table->boolean('weather_sensitive')->default(false);
            $table->string('header_path', 1000)->nullable();
            $table->decimal('ingestion_confidence', 5, 4)->default(1);
            $table->string('confirmation_status', 32)->default('confirmed');
            $table->timestamps();
            $table->unique(['schedule_version_id', 'activity_code']);
            $table->index(['tenant_id', 'schedule_version_id', 'canonical_id']);
        });

        Schema::create('schedule_activity_calendar_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_activity_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_calendar_id')->constrained()->restrictOnDelete();
            $table->string('relationship', 24)->default('primary');
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['schedule_activity_id', 'schedule_calendar_id', 'relationship']);
        });

        Schema::create('schedule_activity_relationships', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->constrained()->restrictOnDelete();
            $table->foreignId('predecessor_activity_id')->constrained('schedule_activities')->restrictOnDelete();
            $table->foreignId('successor_activity_id')->constrained('schedule_activities')->restrictOnDelete();
            $table->string('relationship_type', 2);
            $table->integer('lag_minutes')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['predecessor_activity_id', 'successor_activity_id', 'relationship_type', 'lag_minutes'], 'schedule_rel_unique');
            $table->index(['tenant_id', 'schedule_version_id']);
        });

        Schema::create('schedule_activity_resources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_activity_id')->constrained()->restrictOnDelete();
            $table->string('resource_code', 128)->nullable();
            $table->string('resource_name', 255);
            $table->string('resource_type', 48)->nullable();
            $table->decimal('allocation_units', 10, 4)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'schedule_activity_id']);
        });

        Schema::create('activity_mapping_groups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('project_id')->constrained()->restrictOnDelete();
            $table->foreignId('supersedes_group_id')->nullable()->constrained('activity_mapping_groups')->restrictOnDelete();
            $table->foreignId('from_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->foreignId('to_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->string('relation', 24);
            $table->decimal('confidence', 5, 4);
            $table->string('confirmation_status', 24)->default('proposed');
            $table->string('source', 32)->default('deterministic_matcher');
            $table->foreignId('confirmed_by')->nullable()->constrained('users')->restrictOnDelete();
            $table->dateTimeTz('confirmed_at')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'project_id', 'from_version_id', 'to_version_id'], 'schedule_mapping_pair_idx');
            $table->index(['tenant_id', 'supersedes_group_id']);
        });

        Schema::create('activity_mapping_edges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('mapping_group_id')->constrained('activity_mapping_groups')->restrictOnDelete();
            $table->foreignId('from_activity_id')->nullable()->constrained('schedule_activities')->restrictOnDelete();
            $table->foreignId('to_activity_id')->nullable()->constrained('schedule_activities')->restrictOnDelete();
            $table->decimal('edge_confidence', 5, 4);
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'mapping_group_id']);
        });

        Schema::create('analysis_runs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('project_id')->constrained()->restrictOnDelete();
            $table->foreignId('from_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->foreignId('to_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->string('idempotency_key', 128);
            $table->string('status', 32)->default('queued');
            $table->unsignedTinyInteger('progress_percent')->default(0);
            $table->json('stage_status');
            $table->string('parser_version', 40);
            $table->string('cpm_engine_version', 40);
            $table->string('rules_version', 40);
            $table->string('ai_model')->nullable();
            $table->string('ai_prompt_version')->nullable();
            $table->json('source_hashes');
            $table->json('authorization_scope');
            $table->json('assumptions');
            $table->json('retrieval_times');
            $table->text('error')->nullable();
            $table->foreignId('queued_by')->constrained('users')->restrictOnDelete();
            $table->dateTimeTz('started_at')->nullable();
            $table->dateTimeTz('finished_at')->nullable();
            $table->dateTimeTz('cancel_requested_at')->nullable();
            $table->dateTimeTz('cancelled_at')->nullable();
            $table->timestamps();
            $table->unique(['tenant_id', 'project_id', 'idempotency_key'], 'analysis_idempotency_unique');
            $table->index(['tenant_id', 'project_id', 'status']);
        });

        Schema::create('schedule_validation_issues', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('analysis_run_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_activity_id')->nullable()->constrained()->restrictOnDelete();
            $table->string('code', 80);
            $table->string('severity', 16);
            $table->string('classification', 40)->default('deterministic_calculation');
            $table->text('message');
            $table->json('details');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'analysis_run_id', 'severity']);
        });

        Schema::create('analysis_activity_metrics', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('analysis_run_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_activity_id')->constrained()->restrictOnDelete();
            $table->dateTimeTz('early_start');
            $table->dateTimeTz('early_finish');
            $table->dateTimeTz('late_start');
            $table->dateTimeTz('late_finish');
            $table->integer('total_float_minutes');
            $table->boolean('is_critical');
            $table->boolean('is_near_critical');
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['analysis_run_id', 'schedule_activity_id']);
        });

        Schema::create('schedule_deltas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('project_id')->constrained()->restrictOnDelete();
            $table->foreignId('analysis_run_id')->constrained()->restrictOnDelete();
            $table->foreignId('from_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->foreignId('to_version_id')->constrained('schedule_versions')->restrictOnDelete();
            $table->foreignId('mapping_group_id')->nullable()->constrained('activity_mapping_groups')->restrictOnDelete();
            $table->foreignId('from_activity_id')->nullable()->constrained('schedule_activities')->restrictOnDelete();
            $table->foreignId('to_activity_id')->nullable()->constrained('schedule_activities')->restrictOnDelete();
            $table->uuid('canonical_id')->nullable();
            $table->string('delta_type', 48);
            $table->string('field', 80)->nullable();
            $table->integer('magnitude_minutes')->nullable();
            $table->text('before_value')->nullable();
            $table->text('after_value')->nullable();
            $table->text('explanation');
            $table->string('classification', 40)->default('deterministic_calculation');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'project_id', 'from_version_id', 'to_version_id'], 'schedule_delta_pair_idx');
            $table->index(['analysis_run_id', 'delta_type']);
        });

        Schema::create('schedule_delta_sources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_delta_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_version_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignId('media_item_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignId('schedule_activity_id')->nullable()->constrained()->restrictOnDelete();
            $table->string('source_hash', 64)->nullable();
            $table->string('authorization_label', 64)->default('schedule.view');
            $table->dateTimeTz('retrieved_at');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['tenant_id', 'schedule_delta_id']);
        });

        Schema::create('schedule_delta_record_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->foreignId('schedule_delta_id')->constrained()->restrictOnDelete();
            $table->string('record_type', 64);
            $table->unsignedBigInteger('record_id');
            $table->string('authorization_label', 64);
            $table->dateTimeTz('retrieved_at');
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['schedule_delta_id', 'record_type', 'record_id']);
            $table->index(['tenant_id', 'record_type', 'record_id']);
        });

        Schema::create('outbox_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->restrictOnDelete();
            $table->string('aggregate_type', 80);
            $table->unsignedBigInteger('aggregate_id');
            $table->string('event_type', 120);
            $table->json('payload');
            $table->string('idempotency_key', 160)->unique();
            $table->string('status', 24)->default('pending');
            $table->unsignedSmallInteger('attempts')->default(0);
            $table->dateTimeTz('available_at');
            $table->dateTimeTz('published_at')->nullable();
            $table->text('last_error')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'status', 'available_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('outbox_events');
        Schema::dropIfExists('schedule_delta_record_links');
        Schema::dropIfExists('schedule_delta_sources');
        Schema::dropIfExists('schedule_deltas');
        Schema::dropIfExists('analysis_activity_metrics');
        Schema::dropIfExists('schedule_validation_issues');
        Schema::dropIfExists('analysis_runs');
        Schema::dropIfExists('activity_mapping_edges');
        Schema::dropIfExists('activity_mapping_groups');
        Schema::dropIfExists('schedule_activity_resources');
        Schema::dropIfExists('schedule_activity_relationships');
        Schema::dropIfExists('schedule_activity_calendar_assignments');
        Schema::dropIfExists('schedule_activities');
        Schema::dropIfExists('schedule_calendar_exception_periods');
        Schema::dropIfExists('schedule_calendar_exceptions');
        Schema::dropIfExists('schedule_calendar_working_periods');
        Schema::dropIfExists('schedule_calendars');
        Schema::dropIfExists('schedule_version_events');
        Schema::dropIfExists('schedule_versions');
    }
};
