<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Structure taken from Zeco's REAL HeavyJob exports (Melville PN 851):
        // diary + per-cost-code notes + crew/equipment time card + signatures.
        Schema::create('daily_reports', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->date('report_date');
            $t->foreignId('foreman_id')->constrained('users');
            $t->json('weather')->nullable();    // retrieved + source + time (Aspect 2)
            $t->text('work_performed');
            $t->text('site_conditions')->nullable();
            $t->text('delays')->nullable();
            $t->json('cost_code_notes');        // [{code, name, note}]
            $t->boolean('locked')->default(false); // locked on signature; corrections APPEND
            $t->json('lock_seal')->nullable();
            $t->json('corrections');            // append-only, never overwrite
            $t->timestamps();
            $t->unique(['project_id', 'report_date', 'foreman_id']);
        });

        Schema::create('time_card_entries', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('daily_report_id')->constrained();
            $t->string('resource_code');        // employee code or equipment code
            $t->string('resource_name');
            $t->string('resource_type');        // labor|equipment
            $t->string('pay_class')->nullable(); // LA3, LF1, LJ...
            $t->string('cost_code');            // 6.01, 8.11...
            $t->decimal('hours', 5, 2);
            $t->timestamps();
        });

        Schema::create('signature_attestations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('daily_report_id')->constrained();
            $t->string('worker_code');
            $t->string('worker_name');
            $t->string('language', 8)->default('en');    // presented language (Aspect 12)
            $t->boolean('safety_training_received');
            $t->boolean('breaks_and_lunch_taken');
            $t->text('exception_reason')->nullable();    // if either is NO
            $t->text('signature_data')->nullable();      // vector strokes, not a scan
            $t->json('seal');                            // dual-clock sealed (Aspect 3)
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('signature_attestations');
        Schema::dropIfExists('time_card_entries');
        Schema::dropIfExists('daily_reports');
    }
};
