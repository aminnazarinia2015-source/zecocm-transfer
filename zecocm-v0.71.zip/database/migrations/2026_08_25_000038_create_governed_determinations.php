<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * What makes a HUMAN determination trustworthy, reviewable, reversible, and
 * incapable of silently becoming machine truth forever.
 *
 * Everything built into this system defers to an accountable person: a steward
 * confirms a supersession scope, a certifier signs a payment application, an
 * inspector closes a deficiency, an awarding body prices a withholding. That is
 * correct design - it is the whole reason the machine refuses rather than
 * guesses.
 *
 * But it means human judgment is now part of the trusted computing base, and
 * nothing was watching that half.
 *
 * The failure this exists to catch, and it is worse than any bug fixed today:
 * TRACE refuses correctly - "I cannot tell whether Addendum 4 replaces 3.2.B."
 * A project admin then confirms the wrong scope. From that moment TRACE is
 * confident, internally consistent, and WRONG. Every retrieval test passes.
 * Every hash verifies. Every chain links. Every tenant boundary holds. The
 * source of the false answer is a human determination that entered the trusted
 * state correctly, and there is nothing in the machine that can find it.
 *
 * So every human act that changes what ZecoCM may treat as authoritative writes
 * one of these. Not a per-feature confirmation boolean - one common record, in
 * one place, that can be listed, reviewed, superseded and withdrawn.
 *
 * NO EDITING AFTER SIGNATURE. A determination that turned out to be wrong is
 * corrected by a new determination that supersedes it, never by rewriting the
 * old one. The wrong answer stays in the record with its author's name on it,
 * because the fact that it was believed for a while is itself part of the
 * history somebody may need.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('governed_determinations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();

            // What kind of authority this act conferred or removed.
            $t->string('determination_type', 64);
            $t->string('subject_type', 64);
            $t->unsignedBigInteger('subject_id');

            // What it changed, so a reviewer can see the delta without
            // reconstructing it from somewhere else.
            $t->text('prior_value')->nullable();
            $t->text('proposed_value')->nullable();

            $t->foreignId('determined_by')->constrained('users');
            // The role held AT THE MOMENT of the act. Grants change; the record
            // of what authority somebody actually had must not change with them.
            $t->string('determiner_role', 120);
            $t->json('determiner_authority')->nullable();

            // Server authoritative. A client clock is not evidence.
            $t->timestampTz('determined_at');
            $t->timestampTz('effective_at')->nullable();

            $t->text('reason');
            $t->json('supporting_source_ids')->nullable();
            $t->json('supporting_citations')->nullable();

            $t->string('decision_hash', 128);

            // Some determinations should not stand on one person alone.
            $t->string('review_requirement', 32)->default('none');
            $t->foreignId('reviewed_by')->nullable()->constrained('users');
            $t->timestampTz('reviewed_at')->nullable();

            // active | superseded | withdrawn
            $t->string('status', 16)->default('active');
            $t->unsignedBigInteger('supersedes_determination_id')->nullable();
            $t->timestampsTz();

            $t->index(['subject_type', 'subject_id', 'status']);
            $t->index(['tenant_id', 'determination_type', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('governed_determinations');
    }
};
