<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Confirmed by reading the schema (2026-08-27): daily_reports has no
 * schedule-activity association today, only free-text cost_code_notes tied
 * to cost codes, not schedule activities. This join table is that missing
 * link - it is what lets TRACE-01/02 ask a structured question ("does a
 * finalized daily report reference this activity, and on what date") rather
 * than guessing from narrative text.
 *
 * Deliberately a plain child record, not append-only or immutable: it
 * belongs to a DailyReport, which itself is editable until locked on
 * signature (App\Models\DailyReport::locked) and append-only-corrected after
 * that - this table follows the same lifecycle as the report it belongs to,
 * it does not invent a stricter one of its own.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('daily_report_activities', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('daily_report_id')->constrained();
            $t->foreignId('schedule_activity_id')->constrained();
            $t->string('work_status', 24)->default('performed'); // performed | no_work_this_visit
            $t->text('notes')->nullable();
            $t->timestamps();
            $t->unique(['daily_report_id', 'schedule_activity_id']);
            $t->index(['tenant_id', 'schedule_activity_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('daily_report_activities');
    }
};
