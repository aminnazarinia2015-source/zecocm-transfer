<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('memberships', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('project_id')->constrained();
            $t->foreignId('user_id')->constrained();
            $t->string('organization');         // whose seat: City / CM / design firm / sub
            $t->string('seat');                 // city|cm|inspector|design|contractor + custom
            $t->json('capabilities');           // originate/verify/attest/approve/assign per doc type
            $t->json('discipline_scope')->nullable(); // spec divisions for design seats
            $t->timestamps();
            $t->unique(['project_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('memberships');
    }
};
