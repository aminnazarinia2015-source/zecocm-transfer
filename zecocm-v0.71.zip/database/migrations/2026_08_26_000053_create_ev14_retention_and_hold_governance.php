<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * EV-14A: retention/legal-hold/tombstone governance, per Codex's ruling that
 * split this row in two - eligibility and governance can close now; verified
 * destruction execution (EV-14B) is gated on DATA-1's storage topology.
 *
 * Nothing here can delete a byte. `destruction_requests` and
 * `evidence_tombstones` record a governed DECISION about destruction; no
 * executor exists yet that acts on either table.
 */
return new class extends Migration
{
    public function up(): void
    {
        // No retention default is shipped (Codex + the brief's own A3-style
        // reasoning: an assumed period that's wrong is worse than none).
        // Null means unclassified, and unclassified means "keep, and say so."
        Schema::table('media_items', function (Blueprint $t) {
            $t->string('retention_class')->nullable()->after('quarantine_reason');
        });

        // Append-only. A hold is placed by one event and released by another;
        // a hold row is never updated in place, so "when was this released,
        // and by whom" is never lost to an UPDATE.
        Schema::create('legal_hold_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->uuid('hold_id'); // groups a placed event with its eventual released event
            $t->string('event_type', 16); // 'placed' | 'released'
            $t->string('scope_type', 24); // 'project' | 'tenant' | 'media_item'
            $t->json('scope_value'); // e.g. {"project_id": 5} - the brief deliberately keeps this generic
            $t->string('matter_reference')->nullable();
            $t->foreignId('actor_id')->constrained('users'); // who placed or released
            $t->text('reason');
            $t->timestamp('occurred_at');
            $t->timestamps();
            $t->index(['tenant_id', 'hold_id']);
        });

        // Append-only unlink record. EvidenceLink itself becomes immutable
        // (see EvidenceLink::bootEvidenceLink) - a link is never deleted or
        // updated; an unlink is recorded here instead, and the original link
        // row still proves the evidence was once associated with the record.
        Schema::create('evidence_unlink_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('evidence_link_id')->constrained('evidence_links');
            $t->foreignId('actor_id')->constrained('users');
            $t->text('reason');
            $t->timestamp('occurred_at');
            $t->timestamps();
        });

        // A destruction REQUEST - a proposal, never an action. Codex: no
        // automatic destruction; every batch requires human authorization.
        Schema::create('destruction_requests', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('media_item_id')->constrained('media_items');
            $t->foreignId('requested_by')->constrained('users');
            $t->timestamp('requested_at');
            $t->text('reason');
            $t->string('status', 24); // 'pending' | 'authorized' | 'refused'
            $t->string('refusal_reason')->nullable();
            $t->foreignId('authorized_by')->nullable()->constrained('users');
            $t->timestamp('authorized_at')->nullable();
            $t->text('authority_citation')->nullable();
            $t->string('hold_check_result', 24)->nullable(); // 'no_hold' | 'held' | 'cannot_determine'
            $t->timestamps();
        });

        // The tombstone. Retains identity and integrity metadata forever;
        // never retains the bytes. Per Codex's ruling: the digest is ALWAYS
        // retained (it is the evidentiary commitment, not the content), and
        // this table's `state` can only ever be a pre-execution state in
        // EV-14A - there is no executor yet that can move it to a genuinely
        // destroyed state. See DestructionCertificate for the wording this
        // constraint enforces.
        Schema::create('evidence_tombstones', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->constrained();
            $t->foreignId('media_item_id')->constrained('media_items');
            $t->foreignId('destruction_request_id')->constrained('destruction_requests');
            $t->string('digest', 64);
            $t->string('digest_algorithm', 16);
            $t->unsignedBigInteger('bytes');
            $t->string('mime');
            $t->string('original_name');
            $t->foreignId('authorized_by')->constrained('users');
            $t->timestamp('authorized_at');
            $t->text('authority_citation');
            $t->string('hold_check_result', 24); // the check result AT AUTHORIZATION TIME
            $t->string('state', 48); // see EvidenceTombstone::STATE_* constants
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('evidence_tombstones');
        Schema::dropIfExists('destruction_requests');
        Schema::dropIfExists('evidence_unlink_events');
        Schema::dropIfExists('legal_hold_events');
        Schema::table('media_items', function (Blueprint $t) {
            $t->dropColumn('retention_class');
        });
    }
};
