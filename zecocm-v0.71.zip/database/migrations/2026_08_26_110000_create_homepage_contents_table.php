<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Homepage CMS: a single editable row backing the public marketing
     * homepage's dynamic sections (news, and the pilot customer-count
     * showcase) so the platform admin can update them from the control
     * panel without a code deploy. Not tenant-scoped - this is platform
     * marketing content, not customer data.
     */
    public function up(): void
    {
        Schema::create('homepage_contents', function (Blueprint $t) {
            $t->id();
            $t->json('news')->nullable();
            $t->json('customer_counts')->nullable();
            // Internal-only flag: renders a "PILOT / TEST DATA" banner in the
            // control panel next to the counts. Never sent in the public
            // /api/homepage-content payload - per Amin's explicit direction,
            // the public homepage shows the counts with no visible caveat.
            $t->boolean('counts_are_pilot_data')->default(true);
            $t->foreignId('updated_by')->nullable()->constrained('users');
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('homepage_contents');
    }
};
