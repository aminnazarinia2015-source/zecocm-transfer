<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tenant_id')->nullable()->constrained();  // null = platform staff
            $t->string('name');
            $t->string('email')->unique();
            $t->string('password');
            $t->string('platform_role')->nullable();  // admin|technician|null(customer user)
            $t->json('platform_permissions')->nullable(); // per-capability switches for technicians
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
