<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Below you may configure as many filesystem disks as necessary, and you
    | may even configure multiple disks for the same driver. Examples for
    | most supported storage drivers are configured here for reference.
    |
    | Supported drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            // DATA-1: every evidence write in this codebase (MediaController,
            // DocumentLibraryController, KnowledgeController, ScheduleIngest)
            // goes through this one disk. Before DATA-1 its root was always
            // storage_path('app/private') - inside the application's own
            // release directory - which is exactly what deploy/bootstrap.sh's
            // `rm -rf zecocm` (C3) would take with it if it were ever run
            // against a live install. EVIDENCE_STORAGE_ROOT lets production
            // point this disk at a path outside the deployable app tree
            // entirely, without touching any of the four call sites that
            // write through it. Unset in .env, behaviour is unchanged from
            // before this row - see App\Domain\Ops\StorageInventory for the
            // one place this codebase can query whether that separation is
            // actually in effect.
            // Found via independent review (source-hardening pass, 2026-08-28):
            // .env.example ships this line present-but-blank
            // ("EVIDENCE_STORAGE_ROOT="), which is exactly how a real
            // deployment following that template ends up too. env()'s second
            // argument is a default for an ABSENT key, not a blank one - a
            // key that exists with an empty value returns '' from env(),
            // never the default. That meant a fresh install following this
            // project's own .env.example got '' as this disk's root, which
            // made EvidenceStorageHealthCheck fail /up outright and made
            // every evidence-writing endpoint (media upload, schedule
            // upload, OCR ingestion, TRACE governed intelligence) throw 500
            // - reproduced directly by running the full test suite against
            // a fresh checkout with only .env.example values.  `?:` treats
            // both "unset" and "set but blank" as "use the default."
            'root' => env('EVIDENCE_STORAGE_ROOT') ?: storage_path('app/private'),
            // Baked in here, not read with env() at request time in
            // StorageInventory - a raw env() call outside a config file
            // always returns null once `config:cache` has run (production's
            // normal state), which would make this diagnostic silently lie
            // and report "not configured via env" even when it plainly is.
            'root_configured_via_env' => in_array(env('EVIDENCE_STORAGE_ROOT'), [null, ''], true) === false,
            // Private evidence is served only through authorization-filtered
            // controllers. Never register Laravel's generic local-file routes.
            'serve' => false,
            'throw' => false,
            'report' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => rtrim(env('APP_URL', 'http://localhost'), '/').'/storage',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
            'report' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
