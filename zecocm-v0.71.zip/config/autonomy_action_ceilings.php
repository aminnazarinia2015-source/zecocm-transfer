<?php

use App\Domain\Autonomy\AutonomyLevel;

/**
 * AUTO-2: the system-governed autonomy CEILING per action type.
 *
 * Per Codex's ruling: "hardcoded/system-governed by action class, cannot be
 * raised by customer configuration, not even by an admin." A row in
 * autonomy_policies can only narrow this ceiling for a project (e.g. a
 * cautious owner sets claim_clock_reminder to APPROVAL_REQUIRED even though
 * the system would allow AUTO) - never widen it. This file is the only place
 * that can widen it, and widening it is a code change subject to the same
 * review discipline as everything else in this codebase, not a runtime
 * setting.
 *
 * An action type with no entry here has an implicit ceiling of HUMAN_ONLY -
 * fail closed. See AutonomyPolicyResolver::ceilingFor().
 */
return [
    // AUTO - no external legal effect. Creates an internal record only.
    'claim_clock_reminder' => AutonomyLevel::AUTO,
    'pay_app_draft_rollforward' => AutonomyLevel::AUTO,
    'closeout_deliverable_request' => AutonomyLevel::AUTO,
    'insufficient_evidence_review_request' => AutonomyLevel::AUTO,

    // APPROVAL_REQUIRED examples from the ruling, recorded here so a future
    // seeded action for one of these cannot accidentally ship at a looser
    // ceiling than Codex specified.
    // Deliberately a SEPARATE action type from pay_app_draft_rollforward,
    // per Codex's 2026-08-26 ruling on Amin's pay-app-automation direction:
    // "pay-app chasing" can mean an external message to the PM/owner/
    // accountant that payment is late, which must not quietly reuse the
    // safer shell-creation ceiling. Not yet seeded by any evaluator - listed
    // here so the ceiling exists and fails at APPROVAL_REQUIRED, not at
    // whatever a future evaluator's author happens to pick, the day
    // something builds it.
    'pay_app_followup_chase' => AutonomyLevel::APPROVAL_REQUIRED,
    'send_contractual_notice' => AutonomyLevel::APPROVAL_REQUIRED,
    'certify_pay_application' => AutonomyLevel::APPROVAL_REQUIRED,
    'approve_financial_authorization' => AutonomyLevel::APPROVAL_REQUIRED,
    'verify_authoritative_source' => AutonomyLevel::APPROVAL_REQUIRED,
    'open_acquisition_window' => AutonomyLevel::APPROVAL_REQUIRED,
    'submit_agency_package' => AutonomyLevel::APPROVAL_REQUIRED,
    'reclassify_governing_source' => AutonomyLevel::APPROVAL_REQUIRED,
    'finalize_closeout_deliverable_acceptance' => AutonomyLevel::APPROVAL_REQUIRED,

    // NOT_AUTOMATABLE - the system must not even create an action candidate,
    // per Codex's explicit "automated framing itself could bias the decision"
    // warning. Listed here, not because AUTO-2 seeds any of these yet, but so
    // the ceiling exists and fails closed the day something naively tries to.
    'determine_fraud' => AutonomyLevel::NOT_AUTOMATABLE,
    'determine_litigation_strategy' => AutonomyLevel::NOT_AUTOMATABLE,
    'determine_waiver_or_forfeiture' => AutonomyLevel::NOT_AUTOMATABLE,
    'determine_contractor_termination' => AutonomyLevel::NOT_AUTOMATABLE,
    'authorize_evidence_destruction' => AutonomyLevel::NOT_AUTOMATABLE,
];
