<?php

return [
    'max_upload_kilobytes' => (int) env('SCHEDULE_MAX_UPLOAD_KB', 25600),
    'max_archive_entries' => (int) env('SCHEDULE_MAX_ARCHIVE_ENTRIES', 10000),
    'max_uncompressed_bytes' => (int) env('SCHEDULE_MAX_UNCOMPRESSED_BYTES', 209715200),
    'max_compression_ratio' => (int) env('SCHEDULE_MAX_COMPRESSION_RATIO', 100),
    'max_rows' => (int) env('SCHEDULE_MAX_ROWS', 50000),
    'max_columns' => (int) env('SCHEDULE_MAX_COLUMNS', 100),
    'near_critical_minutes' => (int) env('SCHEDULE_NEAR_CRITICAL_MINUTES', 2400),

    // In production the safe default is to refuse schedule imports unless an
    // operator has configured a malware scanner. Local/test still performs
    // strict MIME, archive, formula, size, and encoding checks.
    'require_malware_scan' => env(
        'SCHEDULE_REQUIRE_MALWARE_SCAN',
        env('APP_ENV', 'production') === 'production'
    ),
    'malware_scanner_binary' => env('SCHEDULE_MALWARE_SCANNER_BINARY'),
    'parser_version' => 'zecocm-spreadsheet-1.0.0',
    'cpm_engine_version' => 'zecocm-cpm-1.0.0',
    'rules_version' => 'zecocm-schedule-rules-1.0.0',
];
