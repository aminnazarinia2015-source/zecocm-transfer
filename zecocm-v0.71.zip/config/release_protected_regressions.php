<?php

/**
 * REL-1: test IDs ("FullyQualifiedClass::method") this codebase has already
 * learned the hard way it cannot afford to lose silently. This list is
 * itself checked-in, git-tracked source - the point is that a change to it
 * shows up as a diff, not that it is unchangeable. A protected regression
 * disappearing from a release's test snapshot without a matching entry in
 * that release's removal_justifications is exactly the TR-17 near-miss
 * (`claude/closure-progress.md`'s "A near-miss worth recording" section):
 * a test file silently overwritten, the suite still green, caught only by
 * hand arithmetic on the total. REL-1 makes that arithmetic automatic.
 *
 * Each entry names why it is here, so a future reviewer deciding whether a
 * removal justification is actually warranted has the original stakes in
 * front of them, not just a bare class name.
 */
return [

    'Tests\Feature\DocumentPrecedenceTest::test_an_addendum_outranks_the_specification_it_amended_even_when_the_spec_matches_more_words' => 'TR-17: the exact acceptance case whose silent loss (a test file overwritten, suite still green) is what led to this row existing at all.',

    'Tests\Feature\DocumentPrecedenceTest::test_the_conflict_is_reported_rather_than_silently_resolved' => 'TR-17: proves an unresolved precedence conflict refuses rather than silently answers - the sharpest of Codex\'s four acceptance cases.',

    'Tests\Unit\GovernedContextBuilderTest' => 'TR-15: the structural test proving retrieved content can never be mistaken for instruction at the model-call gateway. Class-level protection - every method in it matters.',

    'Tests\Feature\EvidenceInvariantTest' => 'The chain-verification / append-only evidentiary invariants this entire certification claim rests on. Class-level protection.',

    'Tests\Feature\Ev14RetentionAndHoldGovernanceTest::test_the_certificate_refuses_to_render_an_unrecognized_state' => 'EV-14A/EV-14B: the structural guarantee that a destruction certificate can never claim more than this codebase can prove.',

];
