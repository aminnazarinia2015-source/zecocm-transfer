<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Resend, Postmark, AWS, and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    // Contractor self-serve onboarding payment providers — see
    // claude/payment-gateway-and-contractor-onboarding-design-brief.md (project docs) for why
    // these two and no others (no crypto, no ACH yet). Read via config(), not env() directly,
    // for the same config:cache-safety reason documented in config/zecocm_ai.php.
    'stripe' => [
        'secret_key' => env('STRIPE_SECRET_KEY', ''),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET', ''),
        // One Stripe Price per self-serve tier (public/home.html #pricing: Field/Project/Program).
        // STRIPE_PRICE_ID is kept as a fallback for the "field" tier alone so a deploy that only
        // ever set the single old env var still works rather than silently breaking.
        'price_id_field' => env('STRIPE_PRICE_ID_FIELD', env('STRIPE_PRICE_ID', '')),
        'price_id_project' => env('STRIPE_PRICE_ID_PROJECT', ''),
        'price_id_program' => env('STRIPE_PRICE_ID_PROGRAM', ''),
    ],

    'paypal' => [
        'client_id' => env('PAYPAL_CLIENT_ID', ''),
        'client_secret' => env('PAYPAL_CLIENT_SECRET', ''),
        'webhook_id' => env('PAYPAL_WEBHOOK_ID', ''),
        // One PayPal billing plan per self-serve tier — same fallback reasoning as Stripe above.
        'plan_id_field' => env('PAYPAL_PLAN_ID_FIELD', env('PAYPAL_PLAN_ID', '')),
        'plan_id_project' => env('PAYPAL_PLAN_ID_PROJECT', ''),
        'plan_id_program' => env('PAYPAL_PLAN_ID_PROGRAM', ''),
        'mode' => env('PAYPAL_MODE', 'sandbox'), // sandbox|live
    ],

];
