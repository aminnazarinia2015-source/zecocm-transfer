<?php

return [
    /*
     * D4: a page is treated as "born-digital text is usable" when its
     * pdftotext extraction is at least this many meaningful characters.
     * Below this, the page falls back to OCR (for a PDF page) or is the
     * whole document (for a directly-uploaded image). Matches the
     * pre-existing whole-document threshold this row replaces at page
     * granularity, per Codex's ruling: "keep this deterministic and
     * conservative initially... do not build a machine-learning quality
     * estimator yet."
     */
    'min_meaningful_chars' => env('OCR_MIN_MEANINGFUL_CHARS', 40),

    /*
     * D4: OCR is a bounded fallback, never an unbounded one - Codex's own
     * words: "D4 must not reopen parser DoS by letting a 2,000-page scan
     * spawn unlimited OCR subprocesses." Three independent bounds:
     *   - max_pages_total: hard cap on pages processed at all (born-digital
     *     or OCR). Pages beyond this are recorded skipped_bound, never
     *     silently dropped.
     *   - max_ocr_pages: of the pages needing OCR, the most that will
     *     actually be rendered+OCR'd in one ingest. Beyond this, remaining
     *     deficient pages are skipped_bound too.
     *   - max_ocr_seconds_total: a wall-clock budget across the whole OCR
     *     pass: even under max_ocr_pages, a document made of enormous pages
     *     stops once this elapses.
     */
    'max_pages_total' => env('OCR_MAX_PAGES_TOTAL', 300),
    'max_ocr_pages' => env('OCR_MAX_OCR_PAGES', 50),
    'max_ocr_seconds_total' => env('OCR_MAX_OCR_SECONDS_TOTAL', 120),

    /*
     * D4: per-subprocess wall-clock bounds, via BoundedProcess (SEC-5's
     * parser-hang guard) - the same discipline applied to pdftotext already
     * applies to pdfinfo, pdftoppm and tesseract, each of which is a real
     * parser running on untrusted, attacker-influenceable bytes.
     */
    'inspect_timeout_seconds' => env('OCR_INSPECT_TIMEOUT_SECONDS', 10),
    'text_extract_timeout_seconds' => env('OCR_TEXT_EXTRACT_TIMEOUT_SECONDS', 20),
    'render_timeout_seconds' => env('OCR_RENDER_TIMEOUT_SECONDS', 25),
    'ocr_timeout_seconds' => env('OCR_TIMEOUT_SECONDS', 25),

    /*
     * VIS-1 (low-quality scan recovery): bound on each `convert`
     * (ImageMagick) preprocessing invocation ScanRecoveryPipeline runs -
     * `convert` is a second parser over attacker-influenceable bytes exactly
     * like pdftoppm/tesseract, so it gets the same BoundedProcess discipline.
     */
    'preprocess_timeout_seconds' => env('OCR_PREPROCESS_TIMEOUT_SECONDS', 20),

    /*
     * D4: rendering a PDF page to an image for OCR. DPI is capped
     * deliberately - a higher DPI produces a larger, slower-to-OCR image
     * without meaningfully improving Tesseract's accuracy on typical
     * construction documents, and an uncapped DPI on an attacker-supplied
     * page size is a memory-exhaustion vector.
     */
    'render_dpi' => env('OCR_RENDER_DPI', 200),
    'max_render_pixels' => env('OCR_MAX_RENDER_PIXELS', 40_000_000), // ~ a 6350x6300 page at 200 DPI

    /*
     * D4: sheet-reference detection is restricted to the bottom-right
     * region of a page - where a construction drawing's title block
     * conventionally lives - specifically so a plausible-looking token
     * appearing in ordinary body text (an RFI number, a spec section, an
     * unrelated code) is never mistaken for the sheet's own identity.
     * Fractions are of page width/height; a word must sit at or past both
     * to be considered.
     */
    'sheet_region_min_x_fraction' => env('OCR_SHEET_REGION_MIN_X_FRACTION', 0.55),
    'sheet_region_min_y_fraction' => env('OCR_SHEET_REGION_MIN_Y_FRACTION', 0.72),

    /*
     * D4: recorded on every OCR-derived page so a citation names the exact
     * producing engine and version (EV-13's versioned-producing-agent
     * pattern). Re-running OCR with a different value here is a new source
     * version, never a rewrite of these fields on an existing page.
     */
    'engine' => 'tesseract',
    'engine_version' => env('OCR_ENGINE_VERSION', '5.3.4'),

    /*
     * D4/Codex's ruling: extraction reliability must reach the answer layer
     * as a deterministic, code-controlled classification - never left to
     * model discretion - so a governing clause reconstructed by noisy OCR is
     * never presented with the same posture as exact born-digital text. See
     * App\Domain\Knowledge\Ocr\ExtractionReliability. Tesseract's own mean
     * word confidence is an extraction-quality signal, not a probability
     * that the text is correct; these thresholds are deliberately
     * conservative rather than calibrated against a labelled dataset.
     */
    'reliability_high_confidence' => env('OCR_RELIABILITY_HIGH_CONFIDENCE', 0.80),
    'reliability_low_confidence' => env('OCR_RELIABILITY_LOW_CONFIDENCE', 0.55),
];
