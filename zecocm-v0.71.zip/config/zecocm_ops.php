<?php

return [
    /*
     * OPS-14: queue-worker heartbeat. A scheduled dispatch every N seconds
     * stamps a fresh row. Per Codex's review of the first version, the
     * scheduler-stopped path and the worker-stopped path need independent
     * thresholds - a healthy worker consumes within seconds, so waiting the
     * full dispatch_stale_seconds to notice an unhandled dispatch would miss
     * a stopped worker for minutes. See QueueHeartbeatHealthCheck's doc
     * comment for what each threshold gates.
     */
    'queue_heartbeat' => [
        'interval_seconds' => env('QUEUE_HEARTBEAT_INTERVAL_SECONDS', 60),
        'dispatch_stale_seconds' => env('QUEUE_HEARTBEAT_DISPATCH_STALE_SECONDS', 180),
        'handling_grace_seconds' => env('QUEUE_HEARTBEAT_HANDLING_GRACE_SECONDS', 45),
        'warning_seconds' => env('QUEUE_HEARTBEAT_WARNING_SECONDS', 20),
        'handling_latency_warning_seconds' => env('QUEUE_HEARTBEAT_HANDLING_LATENCY_WARNING_SECONDS', 10),
        'queue' => env('QUEUE_HEARTBEAT_QUEUE', 'default'),
    ],

    /*
     * OPS-14: oldest-pending-job age. Not every backlog is a health
     * failure - this is a configured SLO, not an arbitrary number.
     */
    'queue_backlog' => [
        'max_pending_age_seconds' => env('QUEUE_MAX_PENDING_AGE_SECONDS', 600),
    ],

    /*
     * OPS-14: evidence-volume free space. Hard minimum fails /up; the
     * warning threshold only logs (Codex: "do not fail /up" on warning).
     */
    'evidence_storage' => [
        'min_free_bytes' => env('EVIDENCE_STORAGE_MIN_FREE_BYTES', 500 * 1024 * 1024),
        'warning_free_bytes' => env('EVIDENCE_STORAGE_WARNING_FREE_BYTES', 2 * 1024 * 1024 * 1024),
    ],

    /*
     * OPS-14: SQLite PRAGMA read-back. Compared against the live
     * connection, never against the configured/env value - the point of
     * this check is catching the two disagreeing.
     */
    'sqlite_pragmas' => [
        'expected_journal_mode' => env('DB_JOURNAL_MODE', 'WAL'),
        'expected_busy_timeout' => env('DB_BUSY_TIMEOUT', 5000),
    ],

    /*
     * OPS-14: failed-job delta tracking is an alertable event, never a
     * /up gate (Codex: "one legitimate permanently failed job can keep
     * health red indefinitely").
     */
    'failed_job_watch' => [
        'enabled' => env('FAILED_JOB_WATCH_ENABLED', true),
    ],
];
