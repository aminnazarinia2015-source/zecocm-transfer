<?php

/**
 * AUTO-2: which action types are allowed to auto-execute while their
 * triggering evidence is unresolved or disputed - Codex's "uncertainty
 * laundering" attack, closed by config rather than by trusting each
 * evaluator to get it right on its own.
 *
 * An action type belongs here ONLY if its executed_change can never do
 * anything but preserve the uncertainty (create a review/task record naming
 * the unresolved fact) - never assert, certify, or act as though the
 * unresolved fact were settled. TR-16's insufficient_evidence review request
 * is the canonical example: "create a human-review request preserving the
 * missing fact" does not increase certainty, so it is safe to auto-create
 * even from an unresolved trigger. "Send the notice using the disputed
 * trigger date" would NOT belong here even if the action type itself is
 * elsewhere marked AUTO for the resolved case - see
 * AutonomousActionRecorder::record()'s epistemic gate.
 *
 * An action type with no entry here is NOT uncertainty-preserving by
 * default (fail closed): if its trigger is unresolved/disputed, the
 * effective autonomy level is forced to at least APPROVAL_REQUIRED
 * regardless of policy or ceiling.
 */
return [
    'insufficient_evidence_review_request',
];
