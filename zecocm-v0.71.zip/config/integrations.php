<?php

return [
    'autodesk' => [
        'client_id' => env('AUTODESK_CLIENT_ID', ''),
        'client_secret' => env('AUTODESK_CLIENT_SECRET', ''),
        'redirect_uri' => env('AUTODESK_REDIRECT_URI', ''),
        'webhook_secret' => env('AUTODESK_WEBHOOK_SECRET', ''),
    ],
    'procore' => [
        'client_id' => env('PROCORE_CLIENT_ID', ''),
        'client_secret' => env('PROCORE_CLIENT_SECRET', ''),
        'redirect_uri' => env('PROCORE_REDIRECT_URI', ''),
        'webhook_secret' => env('PROCORE_WEBHOOK_SECRET', ''),
    ],
    'bluebeam' => [
        'client_id' => env('BLUEBEAM_CLIENT_ID', ''),
        'client_secret' => env('BLUEBEAM_CLIENT_SECRET', ''),
        'redirect_uri' => env('BLUEBEAM_REDIRECT_URI', ''),
    ],
    'microsoft365' => [
        'client_id' => env('MICROSOFT365_CLIENT_ID', ''),
        'client_secret' => env('MICROSOFT365_CLIENT_SECRET', ''),
        'tenant_id' => env('MICROSOFT365_TENANT_ID', ''),
        'redirect_uri' => env('MICROSOFT365_REDIRECT_URI', ''),
        'webhook_client_state' => env('MICROSOFT365_WEBHOOK_CLIENT_STATE', ''),
    ],
];
