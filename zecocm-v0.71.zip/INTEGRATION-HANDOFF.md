# ZecoCM construction-platform integration handoff

ZecoCM is integration-ready, not vendor-connected by default. A provider is
reported as **configured** only when its application credentials and callback
are present. It is reported as **connected** only after an authorized customer
completes OAuth and a real encrypted `integration_connections` record exists.

## Shared implementation contract

Every connector must implement the same controls before it can be enabled:

1. OAuth state is random, short-lived, one-use, tenant/project-bound, and
   validated before exchanging an authorization code.
2. Access and refresh tokens are encrypted with the application key, hidden
   from serialization and logs, independently revocable, and refreshed under a
   lock so two workers cannot rotate the same token concurrently.
3. Requested scopes are least privilege and shown to the authorizing customer.
4. Every imported object retains provider, external account/project/object ID,
   external version, source timestamp, content hash, and ZecoCM record ID.
5. A provider update appends a new governed version. It never overwrites sealed
   ZecoCM evidence or changes a formal human determination.
6. Every sync run has a unique idempotency key, direction, object type, cursors,
   counts, timestamps and a bounded error summary. Retries resume from the last
   committed cursor.
7. Every webhook is signature-verified before parsing, rate-limited, deduplicated
   by provider event ID, recorded by payload hash, and acknowledged only after a
   durable receipt exists. Unknown tenants/projects fail closed.
8. Deletes become tombstones or disconnected mappings; external deletion never
   erases a ZecoCM record under hold or retention.
9. Conflicts enter a human review queue. No "last write wins" rule is allowed for
   revisions, review decisions, RFIs, submittals, markups, or permissions.
10. Integration workers use separate queues, bounded timeouts, exponential
    backoff with jitter, circuit breaking, dead-letter visibility, and provider
    rate-limit headers.

The package already includes the provider registry, encrypted connection model,
sync-run idempotency ledger, webhook receipt ledger, configuration readiness
API, project authorization and the in-product status surface.

## Autodesk Construction Cloud / APS

Required before coding the live adapter:

- Approved Autodesk Platform Services application and customer ACC access.
- Three-legged OAuth client ID/secret and exact HTTPS redirect URI.
- Confirmed products/scopes for Data Management, ACC/BIM 360 projects,
  Model Derivative/model translation, issues, and webhooks.
- Test accounts covering multiple hubs, projects, folders, permissions and
  revoked access.

Target mapping: hub/account → external account, ACC project → ZecoCM project,
folder/file/version → knowledge source/version, drawing/version → plan
sheet/revision, issue/markup → governed finding or markup. Model federation and
clash detection remain Autodesk-backed workflows until ZecoCM licenses and
tests its own model engine.

## Procore

Required before coding the live adapter:

- Registered Procore OAuth application, client ID/secret and HTTPS callback.
- Customer/company and project authorization with approved scopes.
- A written system-of-record decision for documents, drawings, RFIs,
  submittals and project membership.
- Webhook availability and a sandbox covering duplicate, reordered and delayed
  events.

Target mapping must preserve both systems' identifiers. ZecoCM should initially
import documents/drawings and deep-link RFIs/submittals; two-way workflow sync
should ship only after conflict and permission matrices pass.

## Bluebeam

Required before promising live synchronization:

- Bluebeam confirmation of the API/partner product available to ZecoCM and the
  specific Studio/PDF/markup operations it permits.
- Issued OAuth credentials/callback and commercial permission to expose the
  integration to customers.
- Stable identifiers and export semantics for sessions, documents, markups,
  authors, timestamps, status and coordinate systems.

If the contracted API cannot provide an operation, the UI must keep the current
external-reference/export workflow and label it accordingly. ZecoCM must never
market a "Bluebeam sync" based only on a URL field.

## Microsoft 365 / SharePoint / OneDrive

Required before coding the live adapter:

- Entra application registration, tenant ID, client ID/credential and callback.
- Administrator consent and a decision between delegated and application
  permissions. Prefer `Sites.Selected` or equivalent site-scoped access;
  broad file permissions require security approval.
- Selected SharePoint sites/drives, subscription lifecycle handling and a
  webhook client-state secret.

Target mapping: site/drive/folder → governed external container;
driveItem/version → knowledge source/version. SharePoint permissions narrow
what is eligible for import and never widen ZecoCM project authorization.

## Definition of done for each provider

- OAuth connect, callback, refresh, revoke and expired-consent flows pass.
- Secrets/tokens never appear in responses, logs, exceptions or exports.
- Tenant/project boundary and least-privilege tests pass with two customers.
- Initial import, incremental cursor sync, webhook update, retry, replay,
  out-of-order delivery, rate limiting and outage recovery pass.
- Revision, deletion, permission and simultaneous-edit conflicts pass.
- Source hashes and external IDs are traceable through plan/document history.
- TRACE citations open the authorized ZecoCM evidence record, not an inaccessible
  vendor URL.
- Load, observability, backup/restore and vendor sandbox acceptance pass.
- Product copy changes from "integration-ready" to "connected" only after all
  of the above is evidenced for that provider.
