<?php

namespace Tests\Feature;

use Tests\TestCase;

/**
 * Static guard for the frontend half of the change-order/time-card/quality
 * edit-before-seal fix (backend covered by
 * ChangeOrderTimeCardQualityCanBeEditedBeforeSealTest), found missing
 * during the same real-world audit as the RFI/submittal gap.
 */
class ChangeOrderTimeCardQualityEditUiWiredTest extends TestCase
{
    public function test_change_order_detail_has_a_wired_edit_button(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertStringContainsString('ZAPI.editChangeOrder()', $html);
        $this->assertStringContainsString('ZAPI.saveChangeOrderEdit', $html);
        $this->assertStringContainsString("ZAPI.call('PUT', '/change-orders/", $html);
    }

    public function test_time_card_detail_has_a_wired_hours_edit(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertStringContainsString('ZAPI.toggleTimeCardEdit', $html);
        $this->assertStringContainsString('ZAPI.saveTimeCardHours', $html);
        $this->assertStringContainsString("ZAPI.call('PUT', '/time-cards/", $html);
    }

    public function test_quality_item_row_has_a_wired_edit_button(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertStringContainsString('ZAPI.editQualityItem', $html);
        $this->assertStringContainsString("ZAPI.call('PUT', '/quality-items/", $html);
    }
}
