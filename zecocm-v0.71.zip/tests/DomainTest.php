<?php

/**
 * Framework-free domain test runner. PHPUnit arrives with composer install
 * on the server; these run anywhere PHP runs, including this sandbox, so the
 * core mechanisms are PROVEN before deployment.
 */
spl_autoload_register(function ($class) {
    $path = __DIR__.'/../'.str_replace(['App\\', '\\'], ['app/', '/'], $class).'.php';
    if (is_file($path)) {
        require $path;
    }
});

use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Clocks\DeadlineExpression;
use App\Domain\Clocks\PayAppClocks;
use App\Domain\Provenance\CaptureClocks;
use App\Domain\Provenance\ProvenanceSealer;
use App\Domain\Provenance\SealedRecord;
use App\Domain\Provenance\SigningKeyRing;
use App\Tenancy\TenantContext;

// EV-12: ProvenanceSealer::verify() now resolves its key through
// SigningKeyRing, which reads config('provenance.keys'). This script has no
// Laravel container - it proves the domain classes work with nothing but
// PHP - so it stands in the one config() value that path needs rather than
// bootstrapping the framework just for this.
if (! function_exists('config')) {
    function config(string $key, mixed $default = null): mixed
    {
        $store = [
            'provenance.active_key_id' => SigningKeyRing::LEGACY_KEY_ID,
            'provenance.keys' => [SigningKeyRing::LEGACY_KEY_ID => 'test-signing-key'],
        ];

        return $store[$key] ?? $default;
    }
}

$pass = 0;
$fail = 0;
function check(string $name, bool $ok): void
{
    global $pass, $fail;
    if ($ok) {
        $pass++;
        echo "  ok  $name\n";
    } else {
        $fail++;
        echo "  FAIL $name\n";
    }
}

echo "-- DeadlineExpression --\n";
// 10 working days from Mon Aug 17 2026 -> Mon Aug 31 (skip 2 weekends)
$e = new DeadlineExpression(10, DeadlineExpression::BASIS_WORKING);
$due = $e->dueFrom(new DateTimeImmutable('2026-08-17'));
check('10 working days from Mon 8/17 = Mon 8/31', $due->format('Y-m-d') === '2026-08-31');

// Holiday shifts it: Labor Day 9/7
$e2 = new DeadlineExpression(15, DeadlineExpression::BASIS_WORKING, ['2026-09-07']);
$due2 = $e2->dueFrom(new DateTimeImmutable('2026-08-17'));
check('15 working days over Labor Day = Tue 9/8', $due2->format('Y-m-d') === '2026-09-08');

// Calendar basis is plain addition
$e3 = new DeadlineExpression(30, DeadlineExpression::BASIS_CALENDAR);
check('30 calendar days from 8/4 = 9/3', $e3->dueFrom(new DateTimeImmutable('2026-08-04'))->format('Y-m-d') === '2026-09-03');

// Late math
check('due yesterday reads late', $e3->daysLate(new DateTimeImmutable('2026-07-01'), new DateTimeImmutable('2026-08-05')) > 0);
check('due next week reads not late', $e3->daysLate(new DateTimeImmutable('2026-08-01'), new DateTimeImmutable('2026-08-05')) < 0);

echo "-- PayAppClocks (two sequential clocks) --\n";
$clocks = new PayAppClocks(
    review: new DeadlineExpression(15, DeadlineExpression::BASIS_WORKING),
    payment: new DeadlineExpression(30, DeadlineExpression::BASIS_CALENDAR),
    statutoryBackstopCalendarDays: 30,
    backstopCitation: 'PCC s. 20104.50',
);
$submitted = new DateTimeImmutable('2026-08-18');
$reviewDue = $clocks->reviewDue($submitted);
check('review clock anchors at submission', $reviewDue->format('Y-m-d') === '2026-09-08'); // 15 wd over Labor Day? no holidays configured -> 9/8? compute: from 8/18 -> 9/8 is 15 wd
$approved = new DateTimeImmutable('2026-09-04');
check('payment clock anchors at APPROVAL not submission', $clocks->paymentDue($approved)->format('Y-m-d') === '2026-10-04');
check('statutory backstop is 30 calendar days from submission', $clocks->backstopDeemedApprovedAt($submitted)->format('Y-m-d') === '2026-09-17');

echo "-- ProvenanceSealer --\n";
$sealer = new ProvenanceSealer(SigningKeyRing::LEGACY_KEY_ID, 'test-signing-key');
$bytes = random_bytes(2048);
$hash = $sealer->hashMedia($bytes);
$capture = new CaptureClocks(new DateTimeImmutable('2026-08-24 07:00:00'), 1000.0);
$sealed = $sealer->seal($hash, ['project' => '3115'], $capture, new DateTimeImmutable('2026-08-24 07:00:30'), 1030.0);
check('seal verifies', $sealer->verify($sealed));
check('media verifies against original bytes', $sealer->verifyMedia($sealed, $bytes));
check('tampered bytes detected', ! $sealer->verifyMedia($sealed, $bytes.'x'));
$tampered = new SealedRecord(
    array_merge($sealed->payload, ['context' => ['project' => 'FAKED']]),
    $sealed->signature
);
check('tampered payload detected', ! $sealer->verify($tampered));
check('agreeing clocks = strong confidence', $sealer->confidence($sealed) === 'strong');
// Device clock rolled back 2 hours vs monotonic reality
$badCapture = new CaptureClocks(new DateTimeImmutable('2026-08-24 05:00:00'), 1000.0);
$badSealed = $sealer->seal($hash, [], $badCapture, new DateTimeImmutable('2026-08-24 07:00:30'), 1030.0);
check('clock rollback = flagged confidence', $sealer->confidence($badSealed) === 'flagged');

echo "-- AI posture --\n";
$policy = new RefusalPolicy;
check('structural adequacy always escalates', $policy->mustEscalate('structural_adequacy'));
check('dimension clarification does not force-escalate', ! $policy->mustEscalate('dimension_clarification'));

$scope = JurisdictionScope::forProject('public', 'CA', 'local');
check('CA public project scope includes Greenbook', in_array('greenbook', $scope->corpora, true));
check('CA public project scope includes state PCC', in_array('state_public_contract_code', $scope->corpora, true));
check('local funding excludes FAR', ! in_array('far_dfars', $scope->corpora, true));
$fedScope = JurisdictionScope::forProject('public', 'CA', 'federal');
check('federal funding includes FAR', in_array('far_dfars', $fedScope->corpora, true));

$threw = false;
try {
    new CitedSuggestion('uncited claim', []);
} catch (InvalidArgumentException) {
    $threw = true;
}
check('a suggestion WITHOUT a citation cannot be constructed', $threw);

echo "-- Tenancy fail-closed --\n";
TenantContext::clear();
check('no context = no tenant id (scope will emit 1=0)', TenantContext::tenantId() === null);
TenantContext::set(42);
check('context set = scoped to tenant 42', TenantContext::tenantId() === 42);
TenantContext::clear();

echo "\n{$pass} passed, {$fail} failed\n";
exit($fail === 0 ? 0 : 1);
