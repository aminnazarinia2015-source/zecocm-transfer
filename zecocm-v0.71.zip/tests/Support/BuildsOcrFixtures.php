<?php

namespace Tests\Support;

use Illuminate\Http\UploadedFile;

/**
 * D4 tests exercise the real `pdfinfo`/`pdftotext`/`pdftoppm`/`tesseract`
 * binaries against real files, the same way DATA-3's tests ran against a
 * real PostgreSQL instance rather than a mock - a mocked OCR result cannot
 * prove the TSV parsing, the bounding-box math, or the sheet-detection
 * region logic actually work against what these tools really emit.
 *
 * `wkhtmltopdf` produces a genuine born-digital PDF (a real embedded text
 * layer); `convert` (ImageMagick) rasterizes text onto a plain image with
 * no text layer at all, and wrapping that image in a PDF via `convert`
 * again produces a genuine scanned-with-no-text-layer PDF; `pdfunite`
 * assembles a mixed multi-page PDF from both kinds of single-page source.
 */
trait BuildsOcrFixtures
{
    private array $ocrFixtureDirs = [];

    protected function tearDownOcrFixtures(): void
    {
        foreach ($this->ocrFixtureDirs as $dir) {
            foreach (glob($dir.'/*') ?: [] as $file) {
                @unlink($file);
            }
            @rmdir($dir);
        }
        $this->ocrFixtureDirs = [];
    }

    private function ocrFixtureDir(): string
    {
        $dir = sys_get_temp_dir().'/d4fixture-'.bin2hex(random_bytes(6));
        mkdir($dir, 0700, true);
        $this->ocrFixtureDirs[] = $dir;

        return $dir;
    }

    /**
     * A real born-digital, single-page PDF with an actual embedded text
     * layer - pdftotext extracts $text verbatim from this without any OCR.
     */
    private function bornDigitalPdf(string $text): string
    {
        $dir = $this->ocrFixtureDir();
        file_put_contents($dir.'/page.html', '<html><body><p>'.htmlspecialchars($text).'</p></body></html>');
        $pdf = $dir.'/born_digital.pdf';
        exec('wkhtmltopdf --quiet '.escapeshellarg($dir.'/page.html').' '.escapeshellarg($pdf).' 2>/dev/null');

        return $pdf;
    }

    /**
     * A single-page PDF with NO text layer at all - a rasterized image of
     * the requested body text (optionally with a sheet reference stamped
     * in the bottom-right corner, matching where a real title block sits)
     * wrapped in a PDF via ImageMagick. pdftotext extracts nothing from
     * this; only OCR can recover the text.
     */
    private function scannedPdf(string $bodyText, ?string $sheetRef = null, int $width = 1700, int $height = 2200): string
    {
        $dir = $this->ocrFixtureDir();
        $png = $dir.'/page.png';
        $this->renderScannedPng($png, $bodyText, $sheetRef, $width, $height);
        $pdf = $dir.'/scanned.pdf';
        exec('convert '.escapeshellarg($png).' '.escapeshellarg($pdf).' 2>/dev/null');

        return $pdf;
    }

    private function scannedImage(string $bodyText, ?string $sheetRef = null, int $width = 1700, int $height = 2200): string
    {
        $dir = $this->ocrFixtureDir();
        $png = $dir.'/page.png';
        $this->renderScannedPng($png, $bodyText, $sheetRef, $width, $height);

        return $png;
    }

    private function renderScannedPng(string $outPath, string $bodyText, ?string $sheetRef, int $width, int $height): void
    {
        // pointsize is deliberately small relative to $width - a longer body
        // sentence at a large pointsize simply runs off the right edge of a
        // single unwrapped ImageMagick -annotate line, clipping both ends
        // and corrupting the fixture's own ground truth, not anything this
        // row's pipeline does.
        $cmd = 'convert -size '.$width.'x'.$height.' xc:white -gravity North -pointsize 34 -annotate +0+100 '
            .escapeshellarg($bodyText);
        if ($sheetRef !== null) {
            $cmd .= ' -gravity SouthEast -pointsize 50 -annotate +80+80 '.escapeshellarg($sheetRef);
        }
        $cmd .= ' '.escapeshellarg($outPath).' 2>/dev/null';
        exec($cmd);
    }

    /**
     * VIS-1: a genuinely degraded scan - slight rotation, blur, and reduced
     * contrast applied on top of a clean rendered page, tuned (empirically,
     * against the real `tesseract` binary this test suite already requires)
     * to land baseline OCR confidence in the `review_recommended` band
     * (~0.55) rather than either "reads perfectly" or "reads nothing at
     * all" - the middle ground VIS-1's recovery pipeline exists for. Real
     * degraded scans vary far more than this one synthetic profile; this is
     * a fixture to prove the recovery mechanism runs and helps, not a
     * calibration claim about real-world scan quality.
     */
    private function degradedScannedImage(string $bodyText, int $width = 1700, int $height = 2200): string
    {
        $dir = $this->ocrFixtureDir();
        $clean = $dir.'/clean.png';
        $this->renderScannedPng($clean, $bodyText, null, $width, $height);
        $degraded = $dir.'/degraded.png';
        exec('convert '.escapeshellarg($clean).' -rotate 3 -blur 0x1.8 -brightness-contrast -25x-22 '
            .escapeshellarg($degraded).' 2>/dev/null');

        return $degraded;
    }

    /** A page rendered pure white - no legible text of any kind. */
    private function blankScannedPdf(int $width = 1700, int $height = 2200): string
    {
        $dir = $this->ocrFixtureDir();
        $png = $dir.'/blank.png';
        exec('convert -size '.$width.'x'.$height.' xc:white '.escapeshellarg($png).' 2>/dev/null');
        $pdf = $dir.'/blank.pdf';
        exec('convert '.escapeshellarg($png).' '.escapeshellarg($pdf).' 2>/dev/null');

        return $pdf;
    }

    /** Merge single-page PDFs (in order) into one multi-page PDF. */
    private function mergePdfs(array $pdfPaths): string
    {
        $dir = $this->ocrFixtureDir();
        $out = $dir.'/merged.pdf';
        $args = implode(' ', array_map('escapeshellarg', $pdfPaths));
        exec('pdfunite '.$args.' '.escapeshellarg($out).' 2>/dev/null');

        return $out;
    }

    private function uploadedFile(string $path, string $clientName, string $mime): UploadedFile
    {
        return new UploadedFile($path, $clientName, $mime, null, true);
    }
}
