<?php

namespace Tests\Unit;

use App\Domain\Licensing\CapabilityCatalog;
use App\Models\Tenant;
use PHPUnit\Framework\TestCase;

class DefaultEntitlementsTest extends TestCase
{
    public function test_default_entitlements_never_include_roadmap_capabilities(): void
    {
        $defaults = Tenant::defaultEntitlements('Contractor');

        $this->assertSame(CapabilityCatalog::operationalLicensableKeys(), $defaults);
        foreach ($defaults as $capability) {
            $this->assertTrue(CapabilityCatalog::isOperational($capability), $capability.' is not operational.');
        }

        $this->assertNotContains('closeout', $defaults);
        $this->assertNotContains('trade_partners', $defaults);
    }
}
