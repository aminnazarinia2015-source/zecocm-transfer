<?php

namespace Tests\Unit;

use App\Domain\Provenance\CaptureClocks;
use App\Domain\Provenance\ProvenanceSealer;
use App\Domain\Provenance\SealedRecord;
use App\Domain\Provenance\SigningKeyRing;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

/**
 * EV-12: key rotation that preserves historical verification.
 *
 * Before this row, ProvenanceSealer took one HMAC secret in its constructor
 * and used that same secret for both sealing and verifying, always. Nothing
 * in a sealed record said which value of PROVENANCE_SIGNING_KEY produced its
 * signature - so rotating that one mutable environment variable (a
 * disclosed leak, routine hygiene) would silently break `verify()` for every
 * seal already written, because verification always re-derived the
 * signature from whatever the variable holds NOW, not what it held then.
 *
 * The fix: every seal now carries `signing_key_id` in its own signed
 * payload, and `verify()` looks that id up through SigningKeyRing instead of
 * trusting its own constructor key. This proves the actual rotation
 * scenario end to end - seal under key A, rotate to key B, and confirm the
 * old seal still verifies without key A ever being removed from config.
 */
class ProvenanceSealerKeyRotationTest extends TestCase
{
    private function capture(): CaptureClocks
    {
        return new CaptureClocks(new \DateTimeImmutable('2026-08-26 07:00:00'), 1000.0);
    }

    public function test_current_seals_with_the_active_key_and_records_its_id(): void
    {
        Config::set('provenance.active_key_id', 'v1-test');
        Config::set('provenance.keys', ['v1-test' => 'secret-one']);

        $sealed = ProvenanceSealer::current()->seal(
            'deadbeef', ['project' => '410'], $this->capture(),
            new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        $this->assertSame('v1-test', $sealed->payload['signing_key_id']);
    }

    public function test_a_seal_verifies_against_its_own_active_key(): void
    {
        Config::set('provenance.active_key_id', 'v1-test');
        Config::set('provenance.keys', ['v1-test' => 'secret-one']);

        $sealed = ProvenanceSealer::current()->seal(
            'deadbeef', ['project' => '410'], $this->capture(),
            new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        $this->assertTrue(ProvenanceSealer::current()->verify($sealed));
    }

    public function test_a_seal_written_before_rotation_still_verifies_after_the_active_key_changes(): void
    {
        // Seal under the key that is active today.
        Config::set('provenance.active_key_id', 'v1-test');
        Config::set('provenance.keys', ['v1-test' => 'secret-one']);
        $sealedBeforeRotation = ProvenanceSealer::current()->seal(
            'deadbeef', ['project' => '410'], $this->capture(),
            new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        // Rotate: a new key becomes active. The old key is NEVER removed -
        // that is the whole rule, enforced here by simply not removing it.
        Config::set('provenance.active_key_id', 'v2-test');
        Config::set('provenance.keys', [
            'v1-test' => 'secret-one',
            'v2-test' => 'secret-two',
        ]);

        // A verifier built AFTER rotation - the ordinary way any future
        // request would build one - must still confirm the old seal,
        // because it looks up 'v1-test' from the seal's own payload rather
        // than assuming today's active key produced it.
        $this->assertTrue(ProvenanceSealer::current()->verify($sealedBeforeRotation),
            'A seal written under a since-rotated key must still verify after rotation.');
    }

    public function test_a_new_seal_after_rotation_carries_the_new_key_id_not_the_old_one(): void
    {
        Config::set('provenance.active_key_id', 'v2-test');
        Config::set('provenance.keys', [
            'v1-test' => 'secret-one',
            'v2-test' => 'secret-two',
        ]);

        $sealed = ProvenanceSealer::current()->seal(
            'deadbeef', ['project' => '410'], $this->capture(),
            new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        $this->assertSame('v2-test', $sealed->payload['signing_key_id']);
    }

    public function test_a_legacy_seal_with_no_signing_key_id_verifies_against_the_legacy_key(): void
    {
        // Simulates a record written before EV-12 existed: no
        // `signing_key_id` in the payload at all, because there was only
        // ever one key.
        Config::set('provenance.active_key_id', SigningKeyRing::LEGACY_KEY_ID);
        Config::set('provenance.keys', [SigningKeyRing::LEGACY_KEY_ID => 'the-one-original-secret']);

        $payload = ['media_hash' => 'deadbeef', 'context' => [], 'clock_divergence_s' => 0.0];
        $signature = hash_hmac('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES), 'the-one-original-secret');
        $legacySeal = new SealedRecord($payload, $signature);

        $this->assertTrue(ProvenanceSealer::current()->verify($legacySeal));
    }

    public function test_a_seal_signed_with_an_unrecognised_key_id_fails_closed(): void
    {
        Config::set('provenance.keys', ['v1-test' => 'secret-one']);

        // A record claiming a key id this installation has never heard of.
        // Whatever produced this signature, there is no key to check it
        // against - verify() must say so by refusing, not by guessing.
        $payload = ['media_hash' => 'deadbeef', 'signing_key_id' => 'never-configured'];
        $phantomSignature = hash_hmac('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES), 'whatever-secret-produced-this');
        $orphanSeal = new SealedRecord($payload, $phantomSignature);

        Config::set('provenance.active_key_id', 'v1-test');
        $this->assertFalse(ProvenanceSealer::current()->verify($orphanSeal));
    }

    public function test_tampering_with_the_recorded_key_id_is_caught_by_the_signature(): void
    {
        Config::set('provenance.active_key_id', 'v1-test');
        Config::set('provenance.keys', [
            'v1-test' => 'secret-one',
            'v2-test' => 'secret-two',
        ]);

        $sealed = ProvenanceSealer::current()->seal(
            'deadbeef', ['project' => '410'], $this->capture(),
            new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        // An attacker claims a different (also-valid) key signed this,
        // hoping a verifier would just check the new claimed key. It can't
        // work: signing_key_id is inside the signed payload itself, so
        // changing it invalidates the signature regardless of which key id
        // is substituted in.
        $forged = new SealedRecord(
            array_merge($sealed->payload, ['signing_key_id' => 'v2-test']),
            $sealed->signature,
        );

        $this->assertFalse(ProvenanceSealer::current()->verify($forged));
    }

    public function test_rotation_never_requires_removing_or_overwriting_the_prior_key(): void
    {
        Config::set('provenance.active_key_id', 'v1-test');
        Config::set('provenance.keys', ['v1-test' => 'secret-one']);
        $before = ProvenanceSealer::current()->seal(
            'deadbeef', [], $this->capture(), new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        // The only change a rotation makes: add v2, move active_key_id.
        Config::set('provenance.active_key_id', 'v2-test');
        Config::set('provenance.keys', [
            'v1-test' => 'secret-one',
            'v2-test' => 'secret-two',
        ]);

        $after = ProvenanceSealer::current()->seal(
            'deadbeef', [], $this->capture(), new \DateTimeImmutable('2026-08-26 07:00:05'), 1005.0,
        );

        $this->assertTrue(ProvenanceSealer::current()->verify($before));
        $this->assertTrue(ProvenanceSealer::current()->verify($after));
        $this->assertNotSame($before->payload['signing_key_id'], $after->payload['signing_key_id']);
    }
}
