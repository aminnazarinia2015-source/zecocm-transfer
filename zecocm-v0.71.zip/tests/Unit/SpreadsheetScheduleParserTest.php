<?php

namespace Tests\Unit;

use App\Domain\Schedule\ScheduleUploadGuard;
use App\Domain\Schedule\SpreadsheetScheduleParser;
use App\Domain\Schedule\UnsafeScheduleUpload;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;

class SpreadsheetScheduleParserTest extends TestCase
{
    public function test_csv_parses_minute_headers_relationships_resources_and_explicit_calendar_assumption(): void
    {
        config(['schedule.require_malware_scan' => false]);
        $file = UploadedFile::fake()->createWithContent('update.csv', implode("\n", [
            'activity_code,name,duration_minutes,total_float_minutes,planned_start,planned_finish,predecessors,resources,calendar',
            'A100,Mobilize,480,0,2026-08-24 08:00,2026-08-24 17:00,,LAB|Labor crew|labor|1,Standard',
            'A200,Excavate,960,120,2026-08-25 08:00,2026-08-26 17:00,A100 FS+1d,EXC|Excavator|equipment|0.5,Standard',
        ]));

        $scan = (new ScheduleUploadGuard)->inspect($file);
        $parsed = (new SpreadsheetScheduleParser)->parse($file);

        self::assertSame('passed', $scan['status']);
        self::assertSame(480, $parsed->activities[0]['duration_minutes']);
        self::assertSame(120, $parsed->activities[1]['total_float_minutes']);
        self::assertSame(480, $parsed->activities[1]['predecessors'][0]['lag_minutes']);
        self::assertSame('Excavator', $parsed->activities[1]['resources'][0]['resource_name']);
        self::assertStringContainsString('Monday-Friday', implode(' ', $parsed->assumptions));
    }

    public function test_formula_like_csv_content_is_refused(): void
    {
        $file = UploadedFile::fake()->createWithContent('unsafe.csv', "activity_code,name,duration_days\nA1,=HYPERLINK(\"https://example.invalid\"),1\n");

        $this->expectException(UnsafeScheduleUpload::class);
        (new SpreadsheetScheduleParser)->parse($file);
    }
}
