<?php

namespace Tests\Unit;

use App\Domain\Provenance\DigestAlgorithm;
use Tests\TestCase;

class DigestAlgorithmTest extends TestCase
{
    public function test_digest_produces_the_expected_sha256(): void
    {
        $this->assertSame(hash('sha256', 'hello'), DigestAlgorithm::digest('hello'));
    }

    public function test_digest_refuses_an_unrecognised_algorithm_rather_than_silently_using_one(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        DigestAlgorithm::digest('hello', 'md5');
    }

    public function test_verify_matches_a_correct_digest_under_a_known_algorithm(): void
    {
        $digest = DigestAlgorithm::digest('the payload bytes');
        $this->assertSame(DigestAlgorithm::MATCH, DigestAlgorithm::verify('the payload bytes', $digest, 'sha256'));
    }

    public function test_verify_reports_mismatch_on_altered_bytes_under_a_known_algorithm(): void
    {
        $digest = DigestAlgorithm::digest('the original bytes');
        $this->assertSame(DigestAlgorithm::MISMATCH, DigestAlgorithm::verify('altered bytes', $digest, 'sha256'));
    }

    public function test_verify_reports_cannot_verify_when_the_algorithm_is_missing(): void
    {
        $digest = DigestAlgorithm::digest('some bytes');
        // Even though the bytes and digest actually match under sha256, an
        // absent algorithm tag must never be silently assumed to be today's
        // default - that is exactly the guess this class refuses to make.
        $this->assertSame(DigestAlgorithm::CANNOT_VERIFY, DigestAlgorithm::verify('some bytes', $digest, null));
    }

    public function test_verify_reports_cannot_verify_for_an_unrecognised_algorithm_even_when_the_digest_would_match_under_sha256(): void
    {
        $digest = DigestAlgorithm::digest('some bytes');
        // The sharpest case: the stored digest happens to be a valid sha256 of
        // the bytes, but the record claims an algorithm this verifier does not
        // know. Falling back to sha256 anyway would be exactly the "try
        // several algorithms until one matches" failure mode that turns
        // corruption into apparent validity.
        $this->assertSame(DigestAlgorithm::CANNOT_VERIFY, DigestAlgorithm::verify('some bytes', $digest, 'sha3-256'));
    }

    public function test_verify_never_reports_match_for_a_genuinely_unknown_algorithm_regardless_of_byte_content(): void
    {
        $this->assertSame(
            DigestAlgorithm::CANNOT_VERIFY,
            DigestAlgorithm::verify('anything', 'deadbeef', 'whirlpool'),
        );
    }
}
