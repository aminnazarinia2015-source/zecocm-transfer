<?php

namespace Tests\Unit;

use App\Domain\Schedule\DeltaComparator;
use App\Domain\Schedule\ProjectGrant;
use App\Domain\Schedule\SchedulePresenter;
use App\Models\Project;
use App\Models\ScheduleDelta;
use Tests\TestCase;

/**
 * P0-1 regression (Final Verification Directive, 24 Aug 2026): a 25-calendar-day
 * date movement was displayed as "+75 work days" because wall-clock minutes were
 * divided by a fixed 480-minute workday. Date/actuals magnitudes are elapsed
 * calendar time; duration/float magnitudes are working minutes. The two units are
 * typed, presented separately, and never mixed.
 */
class DeltaMagnitudeBasisTest extends TestCase
{
    private function activity(array $overrides = []): array
    {
        return array_merge([
            'activity_code' => 'A010', 'name' => 'Fixture work', 'canonical_id' => 'c-1',
            'start_planned' => '2026-07-16T08:00:00+00:00', 'finish_planned' => '2026-07-20T17:00:00+00:00',
            'start_actual' => null, 'finish_actual' => null,
            'duration_minutes' => 480, 'total_float_minutes' => 2400, 'is_critical' => false,
            'logic_signature' => '[]', 'calendar_name' => 'Standard', 'constraint_signature' => null,
        ], $overrides);
    }

    private function find(array $deltas, string $field): array
    {
        foreach ($deltas as $delta) {
            if (($delta['field'] ?? null) === $field) {
                return $delta;
            }
        }
        $this->fail("No delta produced for field {$field}");
    }

    public function test_a_24_hour_date_shift_is_one_calendar_day_of_elapsed_minutes_never_three_work_days(): void
    {
        $deltas = (new DeltaComparator)->compare(
            $this->activity(),
            $this->activity(['start_planned' => '2026-07-17T08:00:00+00:00']),
            'one_to_one'
        );
        $delta = $this->find($deltas, 'start_planned');

        $this->assertSame(1440, $delta['magnitude_minutes']);
        $this->assertSame('elapsed_minutes', $delta['magnitude_basis']);
        $this->assertStringContainsString('1 calendar days', $delta['explanation']);
        $this->assertStringNotContainsString('work days', $delta['explanation']);
    }

    public function test_friday_to_monday_reports_three_calendar_days(): void
    {
        // 2026-07-17 is a Friday; 2026-07-20 is the following Monday.
        $deltas = (new DeltaComparator)->compare(
            $this->activity(['finish_planned' => '2026-07-17T17:00:00+00:00']),
            $this->activity(['finish_planned' => '2026-07-20T17:00:00+00:00']),
            'one_to_one'
        );
        $delta = $this->find($deltas, 'finish_planned');

        $this->assertSame(3 * 1440, $delta['magnitude_minutes']);
        $this->assertSame('elapsed_minutes', $delta['magnitude_basis']);
        $this->assertStringContainsString('3 calendar days', $delta['explanation']);
    }

    public function test_same_date_time_shift_keeps_full_timestamps_and_magnitude(): void
    {
        $deltas = (new DeltaComparator)->compare(
            $this->activity(['finish_planned' => '2026-07-20T08:00:00+00:00']),
            $this->activity(['finish_planned' => '2026-07-20T17:00:00+00:00']),
            'one_to_one'
        );
        $delta = $this->find($deltas, 'finish_planned');

        $this->assertSame(540, $delta['magnitude_minutes']);
        $this->assertStringContainsString('T08:00:00', $delta['before_value']);
        $this->assertStringContainsString('T17:00:00', $delta['after_value']);
    }

    public function test_duration_and_float_changes_carry_working_minute_bases(): void
    {
        $deltas = (new DeltaComparator)->compare(
            $this->activity(),
            $this->activity(['duration_minutes' => 960, 'total_float_minutes' => 2880]),
            'one_to_one'
        );

        $duration = $this->find($deltas, 'duration_minutes');
        $this->assertSame(480, $duration['magnitude_minutes']);
        $this->assertSame('duration_work_minutes', $duration['magnitude_basis']);
        $this->assertStringContainsString('1 standard work days', $duration['explanation']);

        $float = $this->find($deltas, 'total_float_minutes');
        $this->assertSame('float_work_minutes', $float['magnitude_basis']);
    }

    public function test_presenter_types_the_magnitudes_and_never_divides_elapsed_time_by_480(): void
    {
        $grant = new ProjectGrant(new Project, 1, 'project_manager', 'Test Org', [], false);
        $presenter = new SchedulePresenter;

        // The exact production failure: A120 start moved 25 calendar days (36,000 wall-clock minutes).
        $dateDelta = (new ScheduleDelta)->forceFill([
            'delta_type' => 'date', 'field' => 'start_planned', 'magnitude_minutes' => 36000,
            'magnitude_basis' => 'elapsed_minutes', 'before_value' => '2026-07-16T08:00:00+00:00',
            'after_value' => '2026-08-10T08:00:00+00:00', 'explanation' => 'x', 'classification' => 'deterministic_calculation',
        ]);
        $payload = $presenter->delta($dateDelta, $grant);
        $this->assertSame(25.0, $payload['magnitude_calendar_days']);
        $this->assertNull($payload['magnitude_standard_work_days'], 'Elapsed time must never be presented as work days.');

        $durationDelta = (new ScheduleDelta)->forceFill([
            'delta_type' => 'duration', 'field' => 'duration_minutes', 'magnitude_minutes' => 480,
            'magnitude_basis' => 'duration_work_minutes', 'before_value' => '480', 'after_value' => '960',
            'explanation' => 'x', 'classification' => 'deterministic_calculation',
        ]);
        $payload = $presenter->delta($durationDelta, $grant);
        $this->assertSame(1.0, $payload['magnitude_standard_work_days']);
        $this->assertNull($payload['magnitude_calendar_days']);

        // Legacy row written before the basis column existed: basis is inferred and flagged.
        $legacyDate = (new ScheduleDelta)->forceFill([
            'delta_type' => 'date', 'field' => 'finish_planned', 'magnitude_minutes' => 36000,
            'magnitude_basis' => null, 'before_value' => 'a', 'after_value' => 'b',
            'explanation' => 'x', 'classification' => 'deterministic_calculation',
        ]);
        $payload = $presenter->delta($legacyDate, $grant);
        $this->assertSame('elapsed_minutes', $payload['magnitude_basis']);
        $this->assertTrue($payload['magnitude_basis_inferred']);
        $this->assertSame(25.0, $payload['magnitude_calendar_days']);
        $this->assertNull($payload['magnitude_standard_work_days']);
    }
}
