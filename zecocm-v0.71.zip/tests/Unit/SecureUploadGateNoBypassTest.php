<?php

namespace Tests\Unit;

use Tests\TestCase;

/**
 * SEC-5's closure criterion, in the same shape used for EV-13 (eight sha256
 * call sites) and TR-15 (GovernedContextBuilder as sole model-call-content
 * builder): the three upload controllers must route through SecureUploadGate
 * rather than any inline validation, and the two binaries this codebase
 * invokes on uploaded bytes (pdftotext, the malware scanner) must run through
 * BoundedProcess rather than a raw, unbounded proc_open.
 */
class SecureUploadGateNoBypassTest extends TestCase
{
    public function test_every_upload_controller_calls_secure_upload_gate_admit(): void
    {
        $controllers = [
            'DocumentLibraryController.php',
            'KnowledgeController.php',
            'MediaController.php',
        ];

        foreach ($controllers as $name) {
            $source = file_get_contents(app_path('Http/Controllers/'.$name));
            $this->assertStringContainsString('SecureUploadGate::admit(', $source,
                $name.' must admit uploaded files through SecureUploadGate rather than validating inline.');
        }
    }

    public function test_no_controller_defines_its_own_inline_extension_or_scan_check(): void
    {
        // The methods this row deleted. If one reappears, a controller has
        // drifted back into duplicating validation SecureUploadGate now owns.
        $offendingPatterns = [
            '/function\s+assertDocumentary\s*\(/',
            '/function\s+safeOriginalName\s*\(/',
            '/private\s+function\s+scan\s*\(/',
        ];

        foreach (glob(app_path('Http/Controllers/*.php')) as $file) {
            $source = file_get_contents($file);
            foreach ($offendingPatterns as $pattern) {
                $this->assertDoesNotMatchRegularExpression($pattern, $source,
                    basename($file).' still defines validation logic that belongs to SecureUploadGate.');
            }
        }
    }

    public function test_no_file_outside_bounded_process_and_secure_upload_gate_calls_proc_open_directly(): void
    {
        // pdftotext and the malware scanner are the two binaries this codebase
        // invokes on uploaded bytes; both must go through BoundedProcess so a
        // hang has a wall-clock deadline. A raw proc_open reappearing anywhere
        // else in app/ is exactly the DoS surface this row closed.
        $offenders = [];
        $exempt = ['BoundedProcess.php'];

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(app_path(), \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if ($file->getExtension() !== 'php' || in_array($file->getFilename(), $exempt, true)) {
                continue;
            }
            $source = file_get_contents($file->getPathname());
            if (str_contains($source, 'proc_open(')) {
                $offenders[] = str_replace(app_path().'/', '', $file->getPathname());
            }
        }

        $this->assertSame([], $offenders,
            'A file outside BoundedProcess calls proc_open() directly: '.implode(', ', $offenders));
    }
}
