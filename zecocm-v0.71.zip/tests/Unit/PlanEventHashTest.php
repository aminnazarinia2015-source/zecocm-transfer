<?php

namespace Tests\Unit;

use App\Domain\Schedule\ProjectAccess;
use App\Http\Controllers\PlanController;
use PHPUnit\Framework\TestCase;

class PlanEventHashTest extends TestCase
{
    public function test_plan_event_chain_verifies_and_detects_content_tampering(): void
    {
        $controller = new PlanController(new ProjectAccess);
        $hash = new \ReflectionMethod($controller, 'eventHash');
        $verify = new \ReflectionMethod($controller, 'eventChainValid');

        $first = $this->event(null, 'sheet_created', ['revision' => '0']);
        $first->event_hash = $hash->invoke($controller, (array) $first, ['revision' => '0']);
        $second = $this->event($first->event_hash, 'markup_created', ['type' => 'pin']);
        $second->event_hash = $hash->invoke($controller, (array) $second, ['type' => 'pin']);

        $this->assertTrue($verify->invoke($controller, [$first, $second]));

        $second->details = json_encode(['type' => 'rectangle'], JSON_THROW_ON_ERROR);
        $this->assertFalse($verify->invoke($controller, [$first, $second]));
    }

    private function event(?string $previous, string $action, array $details): object
    {
        return (object) [
            'tenant_id' => 1,
            'project_id' => 2,
            'plan_sheet_id' => 3,
            'plan_sheet_version_id' => 4,
            'plan_markup_id' => $action === 'markup_created' ? 5 : null,
            'action' => $action,
            'details' => json_encode($details, JSON_THROW_ON_ERROR),
            'actor_user_id' => 6,
            'previous_event_hash' => $previous,
            'event_hash' => '',
        ];
    }
}
