<?php

namespace Tests\Unit;

use App\Domain\Provenance\SigningKeyRing;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

/**
 * EV-12: SigningKeyRing is the one place that turns a key id into a secret.
 * Fail-closed, same discipline as DigestAlgorithm - an id this installation
 * does not recognise (or recognises but never configured a secret for)
 * resolves to null, never a guess and never today's active key substituted
 * for a historical one.
 */
class SigningKeyRingTest extends TestCase
{
    public function test_active_key_id_reads_from_config(): void
    {
        Config::set('provenance.active_key_id', 'v3-test');

        $this->assertSame('v3-test', SigningKeyRing::activeKeyId());
    }

    public function test_active_key_returns_the_secret_for_the_active_id(): void
    {
        Config::set('provenance.active_key_id', 'v3-test');
        Config::set('provenance.keys', ['v3-test' => 'secret-for-v3']);

        $this->assertSame('secret-for-v3', SigningKeyRing::activeKey());
    }

    public function test_active_key_throws_when_the_active_id_has_no_configured_secret(): void
    {
        Config::set('provenance.active_key_id', 'ghost-key');
        Config::set('provenance.keys', []);

        $this->expectException(\RuntimeException::class);
        SigningKeyRing::activeKey();
    }

    public function test_key_for_returns_null_for_a_null_key_id(): void
    {
        Config::set('provenance.keys', ['legacy-v1' => 'x']);

        $this->assertNull(SigningKeyRing::keyFor(null));
    }

    public function test_key_for_returns_null_for_an_empty_key_id(): void
    {
        Config::set('provenance.keys', ['legacy-v1' => 'x']);

        $this->assertNull(SigningKeyRing::keyFor(''));
    }

    public function test_key_for_returns_null_for_an_unknown_key_id(): void
    {
        Config::set('provenance.keys', ['legacy-v1' => 'x']);

        // Rotated-away or simply invented - the ring cannot and must not
        // tell those apart, so both resolve to null rather than a guess.
        $this->assertNull(SigningKeyRing::keyFor('never-configured'));
    }

    public function test_key_for_returns_null_when_the_configured_secret_is_blank(): void
    {
        // A key id present in config with an empty string secret (e.g. an
        // .env value that was never actually set) must fail closed exactly
        // like an id absent from config entirely - an empty HMAC key is not
        // "no rotation happened," it is "this seal cannot be verified."
        Config::set('provenance.keys', ['legacy-v1' => '']);

        $this->assertNull(SigningKeyRing::keyFor('legacy-v1'));
    }

    public function test_key_for_returns_the_secret_for_a_known_key_id(): void
    {
        Config::set('provenance.keys', [
            'legacy-v1' => 'old-secret',
            'v2-2026-09' => 'new-secret',
        ]);

        $this->assertSame('old-secret', SigningKeyRing::keyFor('legacy-v1'));
        $this->assertSame('new-secret', SigningKeyRing::keyFor('v2-2026-09'));
    }

    public function test_rotation_retains_every_prior_key_alongside_the_new_active_one(): void
    {
        // The shape a real rotation takes: a new entry is added, the active
        // id moves to point at it, and the old entry is still resolvable -
        // never deleted, never overwritten.
        Config::set('provenance.active_key_id', 'v2-2026-09');
        Config::set('provenance.keys', [
            'legacy-v1' => 'old-secret',
            'v2-2026-09' => 'new-secret',
        ]);

        $this->assertSame('new-secret', SigningKeyRing::activeKey());
        $this->assertSame('old-secret', SigningKeyRing::keyFor('legacy-v1'),
            'Rotating to a new active key must never make the previous key unresolvable.');
    }
}
