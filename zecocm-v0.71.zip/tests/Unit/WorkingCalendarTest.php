<?php

namespace Tests\Unit;

use App\Domain\Schedule\WorkingCalendar;
use DateTimeImmutable;
use DateTimeZone;
use PHPUnit\Framework\TestCase;

class WorkingCalendarTest extends TestCase
{
    public function test_working_math_honors_breaks_weekends_holidays_and_reverse_calculation(): void
    {
        $calendar = $this->calendar(['2026-08-31' => []]);
        $start = new DateTimeImmutable('2026-08-28 08:00:00', new DateTimeZone('America/Los_Angeles'));

        $finish = $calendar->addWorkingMinutes($start, 600);

        self::assertSame('2026-09-01 10:00:00 -07:00', $finish->format('Y-m-d H:i:s P'));
        self::assertSame($start->format(DATE_ATOM), $calendar->subtractWorkingMinutes($finish, 600)->format(DATE_ATOM));
        self::assertSame(600, $calendar->workingMinutesBetween($start, $finish));
        self::assertSame(-600, $calendar->workingMinutesBetween($finish, $start));
    }

    public function test_exception_can_replace_a_normal_day_with_custom_working_periods(): void
    {
        $calendar = $this->calendar(['2026-08-29' => [['09:00:00', '11:00:00']]]);
        $fridayFinish = new DateTimeImmutable('2026-08-28 17:00:00', new DateTimeZone('America/Los_Angeles'));

        self::assertSame(
            '2026-08-29 10:00:00',
            $calendar->addWorkingMinutes($fridayFinish, 60)->format('Y-m-d H:i:s'),
        );
    }

    /** @param array<string,list<array{0:string,1:string}>> $exceptions */
    private function calendar(array $exceptions = []): WorkingCalendar
    {
        $weekly = [];
        foreach (range(1, 5) as $weekday) {
            $weekly[$weekday] = [['08:00:00', '12:00:00'], ['13:00:00', '17:00:00']];
        }

        return new WorkingCalendar(1, 'Standard', new DateTimeZone('America/Los_Angeles'), $weekly, $exceptions);
    }
}
