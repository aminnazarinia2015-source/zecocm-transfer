<?php

namespace Tests\Unit;

use App\Domain\Security\BoundedProcess;
use Tests\TestCase;

/**
 * SEC-5: the reason BoundedProcess exists is that pdftotext and the malware
 * scanner can be made to hang on crafted input. This proves the timeout
 * itself actually fires and returns within a bound - not just that a fast
 * command completes.
 */
class BoundedProcessTest extends TestCase
{
    public function test_a_command_that_completes_quickly_returns_ok_with_its_output(): void
    {
        $result = BoundedProcess::run(['printf', 'hello'], 5);

        $this->assertSame(BoundedProcess::OK, $result['status']);
        $this->assertSame(0, $result['exitCode']);
        $this->assertSame('hello', $result['stdout']);
    }

    public function test_a_command_that_outlives_its_deadline_is_terminated_and_reported_as_timeout(): void
    {
        $start = microtime(true);

        $result = BoundedProcess::run(['sleep', '5'], 1);

        $elapsed = microtime(true) - $start;

        $this->assertSame(BoundedProcess::TIMEOUT, $result['status']);
        $this->assertNull($result['exitCode']);
        $this->assertSame('', $result['stdout']);
        // The whole point: the caller gets control back near the 1-second
        // deadline, not after the child's real 5-second runtime.
        $this->assertLessThan(4.0, $elapsed);
    }

    public function test_a_command_that_does_not_exist_fails_to_start_rather_than_hanging(): void
    {
        $result = BoundedProcess::run(['this-binary-does-not-exist-sec5', 'x'], 5);

        $this->assertContains($result['status'], [BoundedProcess::FAILED_TO_START, BoundedProcess::OK]);
        if ($result['status'] === BoundedProcess::OK) {
            $this->assertNotSame(0, $result['exitCode']);
        }
    }
}
