<?php

namespace Tests\Unit;

use App\Models\ScheduleActivity;
use DateTimeImmutable;
use Tests\TestCase;

/**
 * Regression: PN 851 production incident (24 Aug 2026). constraint_at was not cast,
 * so an activity hydrated from the database exposed a raw string and
 * DeltaEngine::activitySnapshots() crashed calling ->format() on it at the
 * delta_ledger stage (80%). Real MSPDI exports carry constraint dates; the
 * spreadsheet fixtures never did, so the suite missed it.
 */
class ScheduleActivityConstraintCastTest extends TestCase
{
    public function test_constraint_at_hydrates_as_immutable_date_and_formats(): void
    {
        // forceFill mirrors database hydration: raw string attributes, casts applied on access.
        $activity = (new ScheduleActivity)->forceFill([
            'activity_code' => 'A010',
            'constraint_type' => 'start_no_earlier_than',
            'constraint_at' => '2026-07-07 08:00:00',
        ]);

        $this->assertInstanceOf(DateTimeImmutable::class, $activity->constraint_at);
        // The exact call that crashed in production before the cast existed:
        $this->assertSame('2026-07-07', $activity->constraint_at->format('Y-m-d'));

        // Null stays null through the nullsafe path DeltaEngine uses.
        $bare = (new ScheduleActivity)->forceFill(['activity_code' => 'A020', 'constraint_at' => null]);
        $this->assertNull($bare->constraint_at?->format(DATE_ATOM));
    }
}
