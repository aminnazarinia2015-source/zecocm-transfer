<?php

namespace Tests\Unit;

use App\Domain\Ai\EffectiveWindow;
use App\Domain\Ai\JurisdictionMatch;
use Tests\TestCase;

/**
 * TR-13, unit level: the two pure decision rules before they're wired into
 * HybridKnowledgeRetriever (see Feature\Tr13EffectiveDateJurisdictionTest for
 * the end-to-end proof that retrieval actually honors them).
 */
class EffectiveWindowAndJurisdictionMatchTest extends TestCase
{
    public function test_no_bounds_at_all_is_always_in_force(): void
    {
        $this->assertTrue(EffectiveWindow::inForce(null, null, new \DateTimeImmutable('2026-08-26')));
    }

    public function test_a_future_effective_from_is_not_yet_in_force(): void
    {
        $this->assertFalse(EffectiveWindow::inForce(
            new \DateTimeImmutable('2027-01-01'), null, new \DateTimeImmutable('2026-08-26'),
        ));
    }

    public function test_a_past_effective_until_has_lapsed(): void
    {
        $this->assertFalse(EffectiveWindow::inForce(
            null, new \DateTimeImmutable('2025-01-01'), new \DateTimeImmutable('2026-08-26'),
        ));
    }

    public function test_between_both_bounds_is_in_force(): void
    {
        $this->assertTrue(EffectiveWindow::inForce(
            new \DateTimeImmutable('2026-01-01'), new \DateTimeImmutable('2026-12-31'),
            new \DateTimeImmutable('2026-08-26'),
        ));
    }

    public function test_exactly_on_the_effective_from_instant_is_in_force(): void
    {
        $instant = new \DateTimeImmutable('2026-08-26T00:00:00Z');
        $this->assertTrue(EffectiveWindow::inForce($instant, null, $instant));
    }

    public function test_only_the_regulatory_collection_is_jurisdiction_gated(): void
    {
        $this->assertTrue(JurisdictionMatch::permits('NV', 'project', 'CA'),
            'A project-collection source (the project\'s own instrument) must never be jurisdiction-gated.');
        $this->assertTrue(JurisdictionMatch::permits('NV', 'organization', 'CA'));
        $this->assertTrue(JurisdictionMatch::permits('NV', 'city', 'CA'),
            'City-collection jurisdiction matching is out of scope - Project has no city field to compare against.');
    }

    public function test_a_regulatory_source_coded_for_a_different_state_is_refused(): void
    {
        $this->assertFalse(JurisdictionMatch::permits('NV', 'regulatory', 'CA'));
        $this->assertFalse(JurisdictionMatch::permits('nv', 'regulatory', 'ca'),
            'The comparison is case-insensitive.');
    }

    public function test_a_regulatory_source_coded_for_the_same_state_is_permitted(): void
    {
        $this->assertTrue(JurisdictionMatch::permits('CA', 'regulatory', 'CA'));
    }

    public function test_a_regulatory_source_with_no_recognisable_state_code_is_not_gated(): void
    {
        // Unset, "federal", and a city name are all left alone by design - see
        // JurisdictionMatch's own class doc. Forcing a guess here would produce
        // false rejections, not a safety improvement.
        $this->assertTrue(JurisdictionMatch::permits(null, 'regulatory', 'CA'));
        $this->assertTrue(JurisdictionMatch::permits('federal', 'regulatory', 'CA'));
        $this->assertTrue(JurisdictionMatch::permits('City of Atlas', 'regulatory', 'CA'));
    }
}
