<?php

namespace Tests\Unit;

use App\Domain\Ai\Citation;
use App\Domain\Ai\CitationAnchor;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

/**
 * TR-14: citation addressability. Before this row, a `Citation`'s only
 * locator was `passage_id` - `knowledge_passages.id`, an autoincrement
 * integer scoped to this one database. It means nothing once a citation
 * leaves ZecoCM: a restored backup, a migrated database, or a party running
 * their own copy of the same source documents has no way to use it to find
 * the passage the citation actually means.
 *
 * `CitationAnchor::build()` composes an address from four pieces that were
 * already portable by construction - the source's public_id, the version
 * number, the passage's ordinal, and its content hash - none of which
 * requires a live database to interpret.
 */
class CitationAnchorTest extends TestCase
{
    public function test_builds_a_stable_anchor_from_portable_locators(): void
    {
        $anchor = CitationAnchor::build('a1b2c3d4-uuid', 2, 7, str_repeat('f', 64));

        $this->assertSame('a1b2c3d4-uuid#v2.p7@sha256:'.str_repeat('f', 64), $anchor);
    }

    public function test_the_anchor_is_identical_regardless_of_the_internal_row_id(): void
    {
        // The scenario TR-14 exists for: the same passage, re-ingested into a
        // fresh database (or restored from backup) where autoincrement
        // assigned it a completely different knowledge_passages.id. The
        // anchor must not move, because it never looked at that id.
        $here = CitationAnchor::build('same-source-uuid', 1, 3, 'deadbeef');
        $afterRestore = CitationAnchor::build('same-source-uuid', 1, 3, 'deadbeef');

        $this->assertSame($here, $afterRestore);
    }

    public function test_a_different_passage_produces_a_different_anchor(): void
    {
        $this->assertNotSame(
            CitationAnchor::build('uuid', 1, 1, 'aaaa'),
            CitationAnchor::build('uuid', 1, 2, 'aaaa'),
            'A different ordinal within the same version must not collide.',
        );
        $this->assertNotSame(
            CitationAnchor::build('uuid', 1, 1, 'aaaa'),
            CitationAnchor::build('uuid', 2, 1, 'aaaa'),
            'A different version of the same source must not collide.',
        );
    }

    #[DataProvider('missingPieceProvider')]
    public function test_a_missing_portable_piece_refuses_rather_than_guessing(
        ?string $sourcePublicId, ?int $versionNumber, ?int $ordinal, ?string $bodyHash,
    ): void {
        // Fail closed, same discipline as DigestAlgorithm::CANNOT_VERIFY and
        // JurisdictionMatch's unrecognisable-jurisdiction case: a citation is
        // either fully addressable or it says so plainly (null), never a
        // partial anchor presented as if it were complete.
        $this->assertNull(CitationAnchor::build($sourcePublicId, $versionNumber, $ordinal, $bodyHash));
    }

    public static function missingPieceProvider(): array
    {
        return [
            'no source id' => [null, 1, 1, 'aaaa'],
            'no version number' => ['uuid', null, 1, 'aaaa'],
            'no ordinal' => ['uuid', 1, null, 'aaaa'],
            'no body hash' => ['uuid', 1, 1, null],
            'nothing at all' => [null, null, null, null],
        ];
    }

    public function test_citation_toarray_exposes_the_anchor_built_from_its_own_portable_fields(): void
    {
        $citation = new Citation(
            source: 'Special Provisions',
            edition: 'Rev. 2',
            retrievedAt: new \DateTimeImmutable('2026-08-26T00:00:00Z'),
            passageId: 999999, // deliberately not part of the expected anchor
            sourcePublicId: 'sp-uuid',
            sourceHash: 'source-level-hash',
            pageFrom: 4,
            pageTo: 4,
            sectionRef: '01 10 00',
            authorityLevel: 'project_contract',
            versionNumber: 3,
            ordinal: 12,
            bodyHash: 'passage-level-hash',
        );

        $array = $citation->toArray();

        $this->assertSame('sp-uuid#v3.p12@sha256:passage-level-hash', $array['anchor']);
        $this->assertStringNotContainsString('999999', $array['anchor'],
            'The anchor must never be built from the internal passage_id.');
    }

    public function test_citation_toarray_anchor_is_null_when_portable_fields_were_never_set(): void
    {
        // Pre-TR-14 call sites (or a future one that forgets to wire the new
        // fields) get an honest null, never a silently wrong anchor built
        // from whatever happened to be available.
        $citation = new Citation(
            source: 'Legacy Source',
            edition: null,
            retrievedAt: new \DateTimeImmutable,
            passageId: 42,
            sourcePublicId: 'sp-uuid',
        );

        $this->assertNull($citation->toArray()['anchor']);
    }

    public function test_no_other_file_builds_this_anchor_format(): void
    {
        // ONE GATEWAY, same habit as SecureUploadGate and GovernedContextBuilder.
        // Nobody but CitationAnchor may concatenate "#v" . ... . ".p" . ... - if
        // this ever appears elsewhere, the format can drift silently the way
        // the three upload paths drifted before SEC-5.
        $appFiles = (new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(app_path(), \FilesystemIterator::SKIP_DOTS)
        ));

        $offenders = [];
        foreach ($appFiles as $file) {
            if ($file->getExtension() !== 'php') {
                continue;
            }
            if ($file->getFilename() === 'CitationAnchor.php') {
                continue;
            }
            $contents = file_get_contents($file->getPathname());
            if (str_contains($contents, '@sha256:') && str_contains($contents, "'#v'")) {
                $offenders[] = $file->getPathname();
            }
        }

        $this->assertSame([], $offenders, 'Only CitationAnchor may compose the citation anchor format.');
    }
}
