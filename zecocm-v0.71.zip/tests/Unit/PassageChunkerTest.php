<?php

namespace Tests\Unit;

use App\Domain\Knowledge\PassageChunker;
use Tests\TestCase;

class PassageChunkerTest extends TestCase
{
    private PassageChunker $chunker;

    protected function setUp(): void
    {
        parent::setUp();
        $this->chunker = new PassageChunker;
    }

    public function test_a_csi_section_header_forces_a_boundary_and_is_captured_as_section_ref(): void
    {
        $text = "General notes about the project that have nothing to do with irrigation.\n\n"
            ."SECTION 32 84 00 - IRRIGATION\n\nTrench depth shall be 18 inches minimum below finish grade.";
        $chunks = $this->chunker->chunk($text);

        $header = array_values(array_filter($chunks, fn ($c) => $c['boundary_rule'] === 'header'));
        $this->assertCount(1, $header);
        $this->assertSame('32 84 00', $header[0]['section_ref']);
        $this->assertStringContainsString('SECTION 32 84 00', $header[0]['body']);
        // The header carries its own following content rather than the header
        // landing in one passage and the requirement in the next.
        $this->assertStringContainsString('Trench depth', $header[0]['body']);
    }

    public function test_a_table_like_block_is_never_split_even_when_it_exceeds_the_budget(): void
    {
        $rows = [];
        for ($i = 1; $i <= 40; $i++) {
            $rows[] = "Item {$i}    Unit Cost    Quantity    Extended";
        }
        $table = implode("\n", $rows);
        $this->assertGreaterThan(PassageChunker::BUDGET_BYTES, strlen($table));

        $chunks = $this->chunker->chunk($table);

        $this->assertCount(1, $chunks);
        $this->assertSame('table', $chunks[0]['boundary_rule']);
        $this->assertStringContainsString('Item 1', $chunks[0]['body']);
        $this->assertStringContainsString('Item 40', $chunks[0]['body']);
    }

    public function test_an_oversized_paragraph_splits_on_sentence_boundaries_not_mid_sentence(): void
    {
        $sentence = 'The contractor shall provide backfill compacted to ninety five percent relative density. ';
        $paragraph = trim(str_repeat($sentence, 40));
        $this->assertGreaterThan(PassageChunker::BUDGET_BYTES, strlen($paragraph));

        $chunks = $this->chunker->chunk($paragraph);

        $this->assertGreaterThan(1, count($chunks));
        foreach ($chunks as $chunk) {
            $this->assertSame('sentence', $chunk['boundary_rule']);
            $body = trim($chunk['body']);
            // Every emitted piece ends on a sentence boundary — never mid-word,
            // mid-clause, or with a dangling fragment.
            $this->assertMatchesRegularExpression('/[.!?]$/', $body);
        }
    }

    public function test_ordinary_paragraphs_still_pack_to_the_budget_as_before(): void
    {
        $chunks = $this->chunker->chunk("First short paragraph.\n\nSecond short paragraph.");
        $this->assertCount(1, $chunks);
        $this->assertSame('paragraph', $chunks[0]['boundary_rule']);
        $this->assertStringContainsString('First short paragraph.', $chunks[0]['body']);
        $this->assertStringContainsString('Second short paragraph.', $chunks[0]['body']);
    }

    public function test_empty_text_produces_no_passages(): void
    {
        $this->assertSame([], $this->chunker->chunk('   '));
    }

    public function test_a_passage_never_crosses_from_one_csi_section_into_the_next_even_with_no_blank_line_between_headers(): void
    {
        // Codex's flagged gap: two sections separated by a single newline,
        // never a blank line — the shape real pdftotext output takes when a
        // short section runs straight into the next heading.
        $text = "SECTION 32 84 00 - IRRIGATION\nTrench depth shall be 18 inches minimum.\n"
            ."SECTION 32 91 00 - PLANTING SOIL\nTopsoil depth shall be 6 inches minimum.";

        $chunks = $this->chunker->chunk($text);
        $headers = array_values(array_filter($chunks, fn ($c) => $c['boundary_rule'] === 'header'));

        $this->assertCount(2, $headers);
        $this->assertSame('32 84 00', $headers[0]['section_ref']);
        $this->assertSame('32 91 00', $headers[1]['section_ref']);
        $this->assertStringContainsString('Trench depth', $headers[0]['body']);
        $this->assertStringNotContainsString('Topsoil', $headers[0]['body']);
        $this->assertStringContainsString('Topsoil depth', $headers[1]['body']);
        $this->assertStringNotContainsString('Trench', $headers[1]['body']);
    }

    public function test_the_sharpest_case_a_section_header_immediately_followed_by_its_own_table(): void
    {
        $rows = ["SECTION 33 41 00 - STORM DRAIN"];
        for ($i = 1; $i <= 20; $i++) {
            $rows[] = "Pipe {$i}    12 IN RCP    Class III";
        }
        $text = implode("\n", $rows);

        $chunks = $this->chunker->chunk($text);

        // The header line and the table beneath it are one paragraph block (no
        // blank line separates them in real extracted text), so the header
        // rule fires first and the whole block — header plus its table — is
        // captured together rather than the table being torn from its header.
        $this->assertCount(1, $chunks);
        $this->assertSame('header', $chunks[0]['boundary_rule']);
        $this->assertSame('33 41 00', $chunks[0]['section_ref']);
        $this->assertStringContainsString('Pipe 1 ', $chunks[0]['body']);
        $this->assertStringContainsString('Pipe 20', $chunks[0]['body']);
    }
}
