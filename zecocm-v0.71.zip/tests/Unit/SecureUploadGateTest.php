<?php

namespace Tests\Unit;

use App\Domain\Security\SecureUploadGate;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;

/**
 * SEC-5: the one gateway every uploaded file must pass through. Codex's
 * acceptance cases, scoped to what this gate actually checks (type
 * confusion, allowlist, archive-bomb bounds, filename safety) - parser
 * sandboxing and malware-scan behavior are covered where they're wired in
 * (SecureUploadGateScanTest, the KnowledgeController/DocumentLibraryController
 * feature tests).
 */
class SecureUploadGateTest extends TestCase
{
    private function fileWithMime(string $name, string $content, string $mime): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'sec5');
        file_put_contents($path, $content);

        // The four-arg UploadedFile constructor's third argument is the
        // CLIENT-declared MIME - exactly the thing this gate must not trust.
        // getMimeType() (used inside the gate) reads the actual bytes via
        // fileinfo instead, which is why these fixtures still need real
        // matching magic bytes to prove the gate is checking detection, not
        // the declared type.
        return new UploadedFile($path, $name, $mime, null, true);
    }

    private function realPdf(string $name = 'contract.pdf'): UploadedFile
    {
        // Minimal valid PDF magic bytes so fileinfo detects application/pdf.
        return $this->fileWithMime($name, "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF", 'application/pdf');
    }

    // ---- case: a normal, allowed file is admitted -----------------------------

    public function test_a_valid_pdf_is_admitted_for_document_ingestion(): void
    {
        $decision = SecureUploadGate::admit($this->realPdf(), SecureUploadGate::DOCUMENT_INGESTION);

        $this->assertTrue($decision->admitted);
        $this->assertSame('pdf', $decision->extension);
        $this->assertSame('contract.pdf', $decision->safeName);
    }

    // ---- case 1/2 analog: spoofed MIME / double extension ---------------------

    public function test_an_executable_disguised_with_a_pdf_extension_is_rejected(): void
    {
        // Real bytes are an ELF-style/binary blob, not a PDF - fileinfo will
        // not detect application/pdf for this content regardless of the
        // filename or the declared Content-Type.
        $file = $this->fileWithMime('invoice.pdf', "\x7FELF".str_repeat("\x00", 32), 'application/pdf');

        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);

        $this->assertFalse($decision->admitted);
        $this->assertSame('detected_type_not_allowed', $decision->rejectionReason);
    }

    public function test_a_double_extension_is_evaluated_by_its_real_last_extension(): void
    {
        // pathinfo takes the LAST extension. 'invoice.pdf.exe' is 'exe', and
        // 'exe' is on no profile's allowlist regardless of file content.
        $file = $this->fileWithMime('invoice.pdf.exe', "\x7FELF".str_repeat("\x00", 32), 'application/x-msdownload');

        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);

        $this->assertFalse($decision->admitted);
        $this->assertSame('extension_not_allowed', $decision->rejectionReason);
    }

    public function test_an_extension_absent_from_the_profile_is_rejected_outright(): void
    {
        $file = $this->fileWithMime('macro.docm', 'PK'.str_repeat("\x00", 16), 'application/vnd.ms-word.document.macroEnabled.12');

        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);

        $this->assertFalse($decision->admitted);
        $this->assertSame('extension_not_allowed', $decision->rejectionReason);
    }

    public function test_the_evidence_media_profile_is_narrower_than_document_ingestion(): void
    {
        // A perfectly valid DOCX is not evidence-media material - this path
        // exists for field photos and short documentary evidence, not office
        // documents.
        $file = $this->fileWithMime('note.docx', 'PK'.str_repeat("\x00", 16),
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document');

        $decision = SecureUploadGate::admit($file, SecureUploadGate::EVIDENCE_MEDIA);

        $this->assertFalse($decision->admitted);
        $this->assertSame('extension_not_allowed', $decision->rejectionReason);
    }

    // ---- case: unknown profile fails closed ------------------------------------

    public function test_an_unrecognised_profile_is_rejected_rather_than_defaulting_open(): void
    {
        $decision = SecureUploadGate::admit($this->realPdf(), 'made_up_profile');

        $this->assertFalse($decision->admitted);
        $this->assertSame('unknown_profile', $decision->rejectionReason);
    }

    // ---- case 8/9 analog: path traversal and bidi filename attacks ------------

    public function test_safe_name_strips_directory_components_from_a_path_traversal_attempt(): void
    {
        $this->assertSame('.env', SecureUploadGate::safeName('../../.env'));
        $this->assertSame('shell.php', SecureUploadGate::safeName('..\\..\\shell.php'));
    }

    public function test_safe_name_strips_control_and_bidirectional_override_characters(): void
    {
        // U+202E (RIGHT-TO-LEFT OVERRIDE) is how "cod\u{202E}fdp.exe" is made
        // to visually display as if it ends in ".pdf" in a naive UI. Stripped
        // outright rather than merely displayed carefully, since this name
        // may reach logs and other surfaces this gate does not control.
        $name = SecureUploadGate::safeName("evil\u{202E}fdp.exe");

        $this->assertStringNotContainsString("\u{202E}", $name);
    }

    public function test_safe_name_never_returns_an_empty_string(): void
    {
        $this->assertSame('upload', SecureUploadGate::safeName(''));
        $this->assertSame('upload', SecureUploadGate::safeName("\x00\x01\x02"));
    }

    // ---- case 5/6/7 analog: archive/decompression bomb bounds ------------------

    private function zipFixture(int $entries, int $bytesPerEntry, string $fill = 'A'): string
    {
        $path = tempnam(sys_get_temp_dir(), 'sec5zip').'.zip';
        $zip = new \ZipArchive;
        $zip->open($path, \ZipArchive::CREATE);
        for ($i = 0; $i < $entries; $i++) {
            $zip->addFromString("entry{$i}.txt", str_repeat($fill, $bytesPerEntry));
        }
        $zip->close();

        return $path;
    }

    public function test_an_archive_within_bounds_passes(): void
    {
        $path = $this->zipFixture(entries: 3, bytesPerEntry: 100);

        $verdict = SecureUploadGate::archiveVerdict($path, maxEntries: 10, maxUncompressedBytes: 10_000, maxRatio: 500);

        $this->assertNull($verdict);
    }

    public function test_an_archive_over_the_entry_count_limit_is_rejected(): void
    {
        $path = $this->zipFixture(entries: 20, bytesPerEntry: 10);

        $verdict = SecureUploadGate::archiveVerdict($path, maxEntries: 10, maxUncompressedBytes: 1_000_000, maxRatio: 500);

        $this->assertSame('archive_entry_limit', $verdict);
    }

    public function test_an_archive_over_the_total_uncompressed_bound_is_rejected(): void
    {
        // Highly compressible content (a single repeated byte) so the actual
        // ZIP on disk stays tiny while the uncompressed total is large - the
        // decompression-bomb shape itself, proven with a small fixture rather
        // than an actually enormous one.
        $path = $this->zipFixture(entries: 5, bytesPerEntry: 50_000, fill: 'A');

        $verdict = SecureUploadGate::archiveVerdict($path, maxEntries: 100, maxUncompressedBytes: 100_000, maxRatio: 100_000);

        $this->assertSame('archive_uncompressed_total_limit', $verdict);
    }

    public function test_a_single_oversized_entry_is_rejected_even_within_other_bounds(): void
    {
        // The per-entry check runs before the total is even summed, so an
        // entry alone over the (shared) uncompressed-bytes bound is caught
        // as 'archive_entry_too_large' rather than falling through to the
        // total-bound check - proven here with a bound below this one
        // entry's size but well above what a *count* limit would catch.
        $path = $this->zipFixture(entries: 1, bytesPerEntry: 50_000, fill: 'B');

        $verdict = SecureUploadGate::archiveVerdict($path, maxEntries: 100, maxUncompressedBytes: 10_000, maxRatio: 100_000);

        $this->assertSame('archive_entry_too_large', $verdict);
    }

    public function test_an_extreme_compression_ratio_is_rejected_even_under_the_size_cap(): void
    {
        // The classic zip-bomb signature: what is stored is tiny relative to
        // what it expands to, well before the total-bytes cap alone would
        // catch it on a real-world-sized limit.
        $path = $this->zipFixture(entries: 1, bytesPerEntry: 50_000, fill: 'C');

        $verdict = SecureUploadGate::archiveVerdict($path, maxEntries: 100, maxUncompressedBytes: 10_000_000, maxRatio: 10);

        $this->assertSame('archive_compression_ratio_limit', $verdict);
    }

    public function test_admit_applies_the_archive_bound_to_a_docx_shaped_zip(): void
    {
        // admit() uses the class's real (much larger) constants, so this
        // proves the wiring - that a docx really is routed through
        // archiveVerdict() - rather than the bound itself, which the tests
        // above already prove in isolation.
        $entries = SecureUploadGate::MAX_ARCHIVE_ENTRIES + 1;
        $path = $this->zipFixture(entries: $entries, bytesPerEntry: 1);
        $file = new UploadedFile($path, 'huge.docx',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document', null, true);

        $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);

        $this->assertFalse($decision->admitted);
        $this->assertSame('archive_entry_limit', $decision->rejectionReason);
    }
}
