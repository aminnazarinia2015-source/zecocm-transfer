<?php

namespace Tests\Unit;

use App\Domain\Schedule\CpmEngine;
use App\Domain\Schedule\WorkingCalendar;
use DateTimeImmutable;
use DateTimeZone;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class CpmEngineTest extends TestCase
{
    #[DataProvider('relationshipTypes')]
    public function test_relationship_types_are_calculated_deterministically(string $type, string $expectedStart, string $expectedFinish): void
    {
        $result = (new CpmEngine)->calculate(
            [$this->activity(1, 'A', 480), $this->activity(2, 'B', 240)],
            [['predecessor_id' => 1, 'successor_id' => 2, 'type' => $type, 'lag_minutes' => 0]],
            $this->options(),
        );

        self::assertSame($expectedStart, $result->metrics[2]['early_start']->format('Y-m-d H:i'));
        self::assertSame($expectedFinish, $result->metrics[2]['early_finish']->format('Y-m-d H:i'));
    }

    public static function relationshipTypes(): array
    {
        return [
            'finish-to-start' => ['FS', '2026-08-25 08:00', '2026-08-25 12:00'],
            'start-to-start' => ['SS', '2026-08-24 08:00', '2026-08-24 12:00'],
            'finish-to-finish' => ['FF', '2026-08-24 13:00', '2026-08-24 17:00'],
            'start-to-finish floor at data date' => ['SF', '2026-08-24 08:00', '2026-08-24 12:00'],
        ];
    }

    public function test_positive_and_negative_lags_use_working_time(): void
    {
        $engine = new CpmEngine;
        $positive = $engine->calculate(
            [$this->activity(1, 'A', 480), $this->activity(2, 'B', 240)],
            [['predecessor_id' => 1, 'successor_id' => 2, 'type' => 'FS', 'lag_minutes' => 60]],
            $this->options(),
        );
        $negative = $engine->calculate(
            [$this->activity(1, 'A', 480), $this->activity(2, 'B', 240)],
            [['predecessor_id' => 1, 'successor_id' => 2, 'type' => 'FS', 'lag_minutes' => -60]],
            $this->options(),
        );

        self::assertSame('2026-08-25 09:00', $positive->metrics[2]['early_start']->format('Y-m-d H:i'));
        self::assertSame('2026-08-24 16:00', $negative->metrics[2]['early_start']->format('Y-m-d H:i'));
        self::assertContains('negative_lag', array_column($negative->issues, 'code'));
    }

    public function test_calendars_constraints_actuals_open_ends_and_schedule_options_are_reported(): void
    {
        $holidayCalendar = $this->calendar(['2026-08-25' => []]);
        $a = $this->activity(1, 'A', 480, $holidayCalendar);
        $b = $this->activity(2, 'B', 480, $holidayCalendar) + [
            'constraint_type' => 'finish_no_later_than',
            'constraint_at' => '2026-08-26 12:00:00',
            'start_planned' => '2026-08-25 08:00:00',
        ];
        $result = (new CpmEngine)->calculate(
            [$a, $b],
            [['predecessor_id' => 1, 'successor_id' => 2, 'type' => 'FS', 'lag_minutes' => 0]],
            $this->options(['open_end_policy' => 'error']),
        );

        self::assertSame('2026-08-26 17:00', $result->metrics[2]['early_finish']->format('Y-m-d H:i'));
        self::assertContains('constraint_violation', array_column($result->issues, 'code'));

        $openEnds = (new CpmEngine)->calculate(
            [$this->activity(1, 'A', 480), array_merge($this->activity(2, 'B', 960), ['start_planned' => '2026-08-25 08:00:00'])],
            [],
            $this->options(['open_end_policy' => 'error']),
        );
        self::assertContains('open_start', array_column($openEnds->issues, 'code'));
        self::assertContains('open_finish', array_column($openEnds->issues, 'code'));

        $outOfSequence = (new CpmEngine)->calculate(
            [
                $this->activity(1, 'A', 960),
                $this->activity(2, 'B', 480) + ['start_actual' => '2026-08-25 08:00:00'],
            ],
            [['predecessor_id' => 1, 'successor_id' => 2, 'type' => 'FS', 'lag_minutes' => 0]],
            $this->options(['data_date' => new DateTimeImmutable('2026-08-26 08:00:00', new DateTimeZone('America/Los_Angeles')), 'out_of_sequence_mode' => 'retain_logic']),
        );
        self::assertContains('out_of_sequence_progress', array_column($outOfSequence->issues, 'code'));
    }

    public function test_cycles_and_unsupported_options_fail_closed(): void
    {
        $this->expectException(\DomainException::class);
        (new CpmEngine)->calculate(
            [$this->activity(1, 'A', 60), $this->activity(2, 'B', 60)],
            [
                ['predecessor_id' => 1, 'successor_id' => 2, 'type' => 'FS', 'lag_minutes' => 0],
                ['predecessor_id' => 2, 'successor_id' => 1, 'type' => 'FS', 'lag_minutes' => 0],
            ],
            $this->options(),
        );
    }

    /** @param array<string,mixed> $overrides @return array<string,mixed> */
    private function options(array $overrides = []): array
    {
        return $overrides + [
            'data_date' => new DateTimeImmutable('2026-08-24 08:00:00', new DateTimeZone('America/Los_Angeles')),
            'open_end_policy' => 'warn',
            'out_of_sequence_mode' => 'retain_logic',
            'near_critical_minutes' => 2400,
        ];
    }

    /** @return array<string,mixed> */
    private function activity(int $id, string $code, int $duration, ?WorkingCalendar $calendar = null): array
    {
        return [
            'id' => $id,
            'code' => $code,
            'duration_minutes' => $duration,
            'calendar' => $calendar ?? $this->calendar(),
            'start_planned' => '2026-08-24 08:00:00',
            'finish_planned' => '2026-08-24 17:00:00',
        ];
    }

    /** @param array<string,list<array{0:string,1:string}>> $exceptions */
    private function calendar(array $exceptions = []): WorkingCalendar
    {
        $weekly = [];
        foreach (range(1, 5) as $weekday) {
            $weekly[$weekday] = [['08:00:00', '12:00:00'], ['13:00:00', '17:00:00']];
        }

        return new WorkingCalendar('standard', 'Standard', new DateTimeZone('America/Los_Angeles'), $weekly, $exceptions);
    }
}
