<?php

namespace App\Mail;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Sent once, immediately, when a visitor requests the instant self-serve demo
 * (Onboarding\DemoController::instant). Distinct from ContractorAccountProvisioned - this is a
 * free, limited, time-boxed account, not a paid one, and the copy must say so plainly.
 */
class DemoAccountProvisioned extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public Tenant $tenant,
        public User $admin,
        public string $passwordSetupUrl,
    ) {
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Your ZecoCM demo account is ready',
        );
    }

    public function content(): Content
    {
        return new Content(
            markdown: 'mail.onboarding.demo-provisioned',
        );
    }
}
