<?php

namespace App\Mail;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Sent exactly once per self-serve registration, right after payment is confirmed and the
 * tenant/admin are provisioned (RegistrationProvisioner::provision — see
 * PaymentWebhookController). Carries the signed, 7-day password-setup link; this is the only
 * place that link ever leaves the server, since no password is ever mailed.
 *
 * Deliberately NOT queued behind a real queue connection by default (ShouldQueue would require
 * a running worker to ever actually send it) - this fires synchronously so "the customer paid,
 * an email either sent or the webhook response reflects a real failure" stays true without an
 * extra moving part. If mail sending becomes slow enough to matter, queueing is a one-line change
 * (implement ShouldQueue).
 */
class ContractorAccountProvisioned extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public Tenant $tenant,
        public User $admin,
        public string $passwordSetupUrl,
    ) {
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Your ZecoCM account is ready — set your password',
        );
    }

    public function content(): Content
    {
        return new Content(
            markdown: 'mail.onboarding.account-provisioned',
        );
    }
}
