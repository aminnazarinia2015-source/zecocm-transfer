<?php

namespace App\Tenancy;

trait BelongsToTenant
{
    public static function bootBelongsToTenant(): void
    {
        static::addGlobalScope(new TenantScope);

        static::creating(function ($model) {
            if ($model->tenant_id === null) {
                $tenantId = TenantContext::tenantId();
                if ($tenantId === null) {
                    throw new \RuntimeException(
                        'Refusing to create '.static::class.' without tenant context (fail closed).'
                    );
                }
                $model->tenant_id = $tenantId;
            }
        });
    }
}
