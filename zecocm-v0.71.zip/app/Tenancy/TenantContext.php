<?php

namespace App\Tenancy;

/**
 * Holds the tenant for the current request. Set exactly once by middleware
 * from the authenticated user. Deliberately has no "skip" or "all tenants"
 * escape hatch on the query path: platform staff browsing a tenant get the
 * tenant CONTEXT, never a scope bypass.
 *
 * Write policy while browsing (the flow-down Amin defined):
 *  - platform ADMIN in a customer account = SUPPORT MODE - may fix things;
 *    every write carries the admin's identity in the record it touches.
 *  - platform TECHNICIAN = read-only; proposals go to the suggestions inbox.
 */
final class TenantContext
{
    private static ?int $tenantId = null;

    private static bool $platformStaff = false;

    private static bool $platformAdmin = false;

    public static function set(int $tenantId, bool $platformStaff = false, bool $platformAdmin = false): void
    {
        self::$tenantId = $tenantId;
        self::$platformStaff = $platformStaff;
        self::$platformAdmin = $platformAdmin;
    }

    public static function tenantId(): ?int
    {
        return self::$tenantId;
    }

    public static function isPlatformStaff(): bool
    {
        return self::$platformStaff;
    }

    /** True only for the platform ADMIN browsing a customer account. */
    public static function isSupportMode(): bool
    {
        return self::$platformStaff && self::$platformAdmin;
    }

    /** Writes are blocked for staff EXCEPT the admin in support mode. */
    public static function writesBlocked(): bool
    {
        return self::$platformStaff && ! self::$platformAdmin;
    }

    public static function clear(): void
    {
        self::$tenantId = null;
        self::$platformStaff = false;
        self::$platformAdmin = false;
    }
}
