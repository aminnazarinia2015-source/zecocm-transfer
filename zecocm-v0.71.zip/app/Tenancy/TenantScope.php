<?php

namespace App\Tenancy;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

/**
 * FAIL-CLOSED tenant isolation. If no tenant context has been established,
 * the query matches NOTHING (whereRaw 1=0) - it never falls through to
 * all rows. This is the single most important security property in the
 * codebase: a bug here leaks one contractor's documents to another.
 * Do not add a bypass. Do not "fix" the 1=0.
 */
class TenantScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        $tenantId = TenantContext::tenantId();

        if ($tenantId === null) {
            $builder->whereRaw('1 = 0');

            return;
        }

        $builder->where($model->getTable().'.tenant_id', $tenantId);
    }
}
