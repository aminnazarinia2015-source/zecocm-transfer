<?php

namespace App\Services;

/**
 * Open-Meteo: authoritative, free, NO API KEY required. Every reading is
 * stored with source identity + retrieval time (Aspect 2). Also serves the
 * 10-day forecast for look-ahead rain flags (Addendum G).
 */
class WeatherService
{
    public function current(float $lat, float $lng): ?array
    {
        $data = $this->get("https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lng}"
            .'&current=temperature_2m,precipitation,weather_code,wind_speed_10m&temperature_unit=fahrenheit');
        if ($data === null) {
            return null;
        }

        return [
            'temp_f' => $data['current']['temperature_2m'] ?? null,
            'precipitation' => $data['current']['precipitation'] ?? null,
            'wind_mph' => $data['current']['wind_speed_10m'] ?? null,
            'weather_code' => $data['current']['weather_code'] ?? null,
            'source' => 'open-meteo.com',
            'retrieved_at' => now()->toIso8601String(),
        ];
    }

    /** @return list<array{date:string,precip_probability:int}>|null */
    public function tenDayPrecipProbability(float $lat, float $lng): ?array
    {
        $data = $this->get("https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lng}"
            .'&daily=precipitation_probability_max&forecast_days=10');
        if ($data === null) {
            return null;
        }
        $out = [];
        foreach ($data['daily']['time'] ?? [] as $i => $date) {
            $out[] = [
                'date' => $date,
                'precip_probability' => (int) ($data['daily']['precipitation_probability_max'][$i] ?? 0),
            ];
        }

        return $out;
    }

    private function get(string $url): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15]);
        $raw = curl_exec($ch);
        curl_close($ch);
        if ($raw === false) {
            return null;
        }
        $decoded = json_decode($raw, true);

        return is_array($decoded) ? $decoded : null;
    }
}
