<?php

namespace App\Http\Middleware;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;

/**
 * Server-side licence gate. Navigation visibility is never the control - the API
 * enforces the same decision independently, and fails closed.
 *
 * Usage: ->middleware('capability:schedule_intelligence')
 */
class RequireCapabilityLicense
{
    public function __construct(private readonly CapabilityLicense $license) {}

    public function handle(Request $request, Closure $next, string $capabilityKey)
    {
        $tenant = $this->resolveTenant($request);

        // No resolvable account context: match nothing rather than defaulting open.
        if ($tenant === null) {
            return response()->json([
                'message' => 'No account context for this request.',
                'capability' => $capabilityKey,
            ], 403);
        }

        $state = $this->license->state($tenant, $capabilityKey);
        if (! $state->allows()) {
            return response()->json([
                'message' => match ($state->state) {
                    'expired' => 'The licence for this capability ended on '.substr((string) $state->endsAt, 0, 10).'.',
                    'suspended' => 'This capability is switched off for this account.',
                    'limit_reached' => 'This account has used its allowance for the current period.',
                    'licensed_unavailable' => 'This capability is licensed but not yet available.',
                    default => 'This account is not licensed for this capability.',
                },
                'capability' => $capabilityKey,
                'state' => $state->state,
                'ends_at' => $state->endsAt,
            ], 402);
        }

        return $next($request);
    }

    /**
     * The licence is always read from the CALLER'S OWN account context - never from a
     * project id supplied in the request. Resolving by project would answer "that
     * project exists but is not licensed" for another tenant's record, which is an
     * existence leak. Cross-tenant access is refused later, by ProjectAccess, as 404.
     */
    private function resolveTenant(Request $request): ?Tenant
    {
        if (TenantContext::tenantId() !== null) {
            return Tenant::find(TenantContext::tenantId());
        }

        return $request->user()?->tenant_id ? Tenant::find($request->user()->tenant_id) : null;
    }
}
