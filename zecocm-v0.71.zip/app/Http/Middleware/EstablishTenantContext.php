<?php

namespace App\Http\Middleware;

use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;

/**
 * Sets the tenant context from the authenticated user, exactly once per
 * request. Customer users are locked to their own tenant. Platform staff
 * (admin/technician) may browse a tenant READ-ONLY by passing an explicit
 * X-Browse-Tenant header - flagged as staff so every write path rejects.
 */
class EstablishTenantContext
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        abort_if($user === null, 401);

        TenantContext::clear();

        if ($user->isPlatformStaff()) {
            $browse = (int) $request->header('X-Browse-Tenant', '0');
            // A well-formed but nonexistent tenant id must fail closed exactly
            // like no header at all - never set context to an id nothing backs.
            // Left unchecked, a write path (e.g. ProjectController::store())
            // would sail past its "tenant context is set" guard and only then
            // hit the tenant_id foreign key constraint, turning a bad header
            // into an unhandled 500 instead of a clean, expected refusal.
            if ($browse > 0 && Tenant::where('id', $browse)->exists()) {
                TenantContext::set($browse, platformStaff: true, platformAdmin: $user->isPlatformAdmin());
            }
            // No header, or a browse id that doesn't exist: staff stay in the
            // platform layer; tenant queries resolve to nothing (fail closed)
            // - exactly right.
        } else {
            abort_if($user->tenant_id === null, 403, 'User has no tenant.');
            // AuthController blocks a suspended tenant's users at LOGIN, but a
            // token issued before suspension keeps working for every request
            // after that unless checked again here - suspension must cut off
            // an already-open session, not just the next sign-in. Found during
            // an adversarial "what if" pass: a user with a valid Sanctum token
            // could still fully use the app after their tenant was suspended
            // mid-session (GET /api/projects returned 200, not 403). Same
            // fail-closed treatment for a tenant deleted mid-session - the row
            // no longer exists, so there is no account left to act as.
            $tenant = Tenant::find($user->tenant_id);
            abort_if($tenant === null, 403, 'This account no longer exists.');
            abort_if($tenant->status === 'suspended', 403, 'This account has been suspended. Contact your ZecoCM administrator.');
            TenantContext::set($user->tenant_id, platformStaff: false);
        }

        try {
            return $next($request);
        } finally {
            TenantContext::clear();   // never leak context across requests
        }
    }
}
