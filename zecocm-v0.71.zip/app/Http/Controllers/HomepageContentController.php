<?php

namespace App\Http\Controllers;

use App\Models\HomepageContent;
use Illuminate\Http\Request;

/**
 * Homepage CMS. Backs the editable sections of the public marketing
 * homepage - news and the pilot customer-count showcase - so the platform
 * admin can update them from the control panel without a code deploy.
 *
 * Public payload (show) never includes counts_are_pilot_data or who last
 * edited it: that internal bookkeeping is admin-only (adminShow), per
 * Amin's explicit direction that the "this is pilot/test data" label
 * belongs in the control panel, not on the page a visitor sees.
 */
class HomepageContentController
{
    /** Public, unauthenticated: what the homepage itself renders. */
    public function show()
    {
        $content = HomepageContent::current();

        return response()->json([
            'news' => $content->news ?? [],
            'customer_counts' => $content->customer_counts ?? HomepageContent::defaultCounts(),
            'updated_at' => $content->updated_at,
        ]);
    }

    /** Platform staff (admin or technician): the same content plus the internal pilot-data flag. */
    public function adminShow(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $content = HomepageContent::current();

        return response()->json($content);
    }

    public function update(Request $request)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin edits the public homepage.');

        $data = $request->validate([
            'news' => 'sometimes|array|max:50',
            'news.*.title' => 'required_with:news|string|max:160',
            'news.*.body' => 'required_with:news|string|max:2000',
            'news.*.published_at' => 'nullable|date',
            'news.*.url' => 'nullable|url|max:500',
            'customer_counts' => 'sometimes|array',
            'customer_counts.contractors' => 'required_with:customer_counts|integer|min:0',
            'customer_counts.public_entities' => 'required_with:customer_counts|integer|min:0',
            'customer_counts.construction_managers' => 'required_with:customer_counts|integer|min:0',
            'counts_are_pilot_data' => 'sometimes|boolean',
        ]);

        $content = HomepageContent::current();
        $content->fill(array_intersect_key($data, array_flip(['news', 'customer_counts', 'counts_are_pilot_data'])));
        $content->updated_by = $request->user()->id;
        $content->save();

        return response()->json($content);
    }
}
