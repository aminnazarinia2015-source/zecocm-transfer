<?php

namespace App\Http\Controllers\Onboarding;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Http\Controllers\Controller;
use App\Mail\DemoAccountProvisioned;
use App\Models\DemoRequest;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;

/**
 * Two distinct demo paths, per Amin's direction (2026-08-27) - see
 * database/migrations/2026_08_27_093000_add_demo_support.php for the design rationale.
 */
class DemoController extends Controller
{
    /**
     * Instant, self-serve, limited demo. No payment, no human involved - a real (if
     * time-boxed) Tenant + admin User provisioned on the spot, using the exact same shape as a
     * paid account so nothing about "how a demo works" is a second, divergent code path.
     */
    public function instant(Request $request)
    {
        $data = $request->validate([
            'company' => 'required|string|max:255',
            'admin_first_name' => 'required|string|max:128',
            'admin_last_name' => 'required|string|max:128',
            'email' => 'required|email|max:255',
        ]);

        // Found by a "what if" pass: unlike the paid registration flow (which catches exactly
        // this collision - see RegistrationProvisioner/DuplicateEmailProvisioningException), this
        // instant-demo path had no check at all. users.email is globally unique, so a second
        // instant-demo request (or a repeat click) for an email that already has an account -
        // demo or otherwise - crashed with a raw UniqueConstraintViolationException, a 500 with a
        // full stack trace, and left an orphan Tenant row behind with no admin user ever created
        // for it. Refused cleanly before either row is created.
        if (User::where('email', $data['email'])->exists()) {
            return response()->json([
                'message' => 'An account already exists for this email. Log in instead, or use a different email to start a new demo.',
            ], 409);
        }

        // Field-tier entitlements only - the homepage explicitly frames the instant demo as
        // "limited"; the full set is reserved for the human-scheduled full demo below.
        $entitlements = array_values(array_intersect(
            CapabilityCatalog::licensableKeys(),
            ['daily_reports', 'rfis', 'submittals', 'photos', 'documents', 'documents.transmittal', 'ai.assist'],
        ));

        $tenant = Tenant::create([
            'name' => $data['company'].' (Demo)',
            'type' => 'Demo',
            'entitlements' => $entitlements,
            'status' => 'trial',
            'is_demo' => true,
            'demo_expires_at' => now()->addDays(14),
        ]);

        $admin = User::create([
            'tenant_id' => $tenant->id,
            'name' => trim($data['admin_first_name'].' '.$data['admin_last_name']),
            'email' => $data['email'],
            'password' => bcrypt(Str::random(40)),
        ]);

        $licenses = app(CapabilityLicense::class);
        foreach ($entitlements as $capability) {
            if (CapabilityCatalog::has($capability) && ! CapabilityCatalog::isFree($capability)) {
                $licenses->grant(
                    $tenant, $capability,
                    endsAt: $tenant->demo_expires_at,
                    planReference: 'instant_demo',
                    reason: 'Instant self-serve demo',
                );
            }
        }

        $passwordSetupUrl = URL::temporarySignedRoute('onboarding.password.show', now()->addDays(7), ['user' => $admin->id]);

        Mail::to($admin->email)->send(new DemoAccountProvisioned($tenant, $admin, $passwordSetupUrl));

        return response()->json([
            'message' => 'Demo account created. Check your email to set a password and sign in.',
            // Returned directly, not just emailed: production mail delivery is a separate,
            // not-yet-confirmed dependency (see PlatformController::systemSettings) - if it isn't
            // wired up yet, an instant demo would otherwise be a dead end with no way in. This is
            // safe to hand back here specifically because it's the same person who just
            // submitted this request, in the same request/response cycle - never done for the
            // paid registration flow, where the equivalent step happens later, asynchronously,
            // inside a payment webhook with no browser on the other end.
            'password_setup_url' => $passwordSetupUrl,
            'expires_at' => $tenant->demo_expires_at,
        ], 201);
    }

    /**
     * "Show me the whole product" request for entities/contractors - not an account, a lead a
     * human follows up on and schedules. See PlatformController::demoRequests() for the admin
     * side of this queue.
     */
    public function requestFullDemo(Request $request)
    {
        $data = $request->validate([
            'company' => 'required|string|max:255',
            'contact_name' => 'required|string|max:128',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:32',
            'entity_type' => 'nullable|string|max:64',
            'note' => 'nullable|string|max:1000',
        ]);

        $request_ = DemoRequest::create($data + ['status' => DemoRequest::STATUS_PENDING]);

        return response()->json(['message' => 'Request received. A ZecoCM team member will reach out to schedule your full demo.', 'id' => $request_->id], 201);
    }
}
