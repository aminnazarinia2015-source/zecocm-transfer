<?php

namespace App\Http\Controllers\Onboarding;

use App\Domain\Onboarding\PayPalPaymentProvider;
use App\Domain\Onboarding\RegistrationProvisioner;
use App\Domain\Onboarding\StripePaymentProvider;
use App\Http\Controllers\Controller;
use App\Mail\ContractorAccountProvisioned;
use App\Models\ContractorRegistration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

/**
 * Receives Stripe and PayPal webhooks. This is the ONLY place payment success is ever recognized
 * — never a browser return URL (`/onboarding/success`, which is UX only). Every event is
 * idempotency-checked against `payment_webhook_events` before anything else happens, so a
 * retried/duplicated webhook delivery can never provision a tenant twice or double-process a
 * payment.
 */
class PaymentWebhookController extends Controller
{
    public function stripe(Request $request, RegistrationProvisioner $provisioner)
    {
        // Resolved via app() rather than a type-hinted method parameter: Laravel's controller
        // method injection still passes whatever the container's StripePaymentProvider::class
        // binding resolves to, but a type-hinted parameter has PHP itself enforce that the
        // resolved object is an instanceof StripePaymentProvider — which a test double bound in
        // its place (e.g. FakePaymentProvider, which only implements the PaymentProvider
        // interface) is not, causing a TypeError before the method body ever runs. Assigning to an
        // untyped local avoids that enforcement while keeping tests able to swap the concrete
        // class via $this->app->bind(StripePaymentProvider::class, ...).
        $provider = app(StripePaymentProvider::class);

        return $this->handle($request, $provider, $provisioner, [
            'checkout.session.completed', 'invoice.paid',
        ]);
    }

    public function paypal(Request $request, RegistrationProvisioner $provisioner)
    {
        $provider = app(PayPalPaymentProvider::class);

        return $this->handle($request, $provider, $provisioner, [
            'BILLING.SUBSCRIPTION.ACTIVATED', 'PAYMENT.SALE.COMPLETED',
        ]);
    }

    private function handle(Request $request, $provider, RegistrationProvisioner $provisioner, array $successEventTypes)
    {
        $event = $provider->verifyWebhook($request->getContent(), $request->headers->all());

        if ($event === null) {
            // Fails closed: an unverifiable payload is never trusted, but we still return 200 so
            // the provider doesn't spin retrying something it will never be able to verify (e.g.
            // a signature mismatch is not something a retry fixes).
            return response()->json(['status' => 'ignored'], 200);
        }

        $isNewEvent = $provisioner->recordWebhookEventOnce(
            $provider->name(),
            $event['event_id'],
            $event['type'],
            $event,
        );

        if (! $isNewEvent) {
            // Already processed this exact event — idempotent no-op, not an error.
            return response()->json(['status' => 'already_processed'], 200);
        }

        if (! in_array($event['type'], $successEventTypes, true) || $event['registration_id'] === null) {
            return response()->json(['status' => 'ignored'], 200);
        }

        $registration = ContractorRegistration::where('registration_id', $event['registration_id'])->first();
        if ($registration === null) {
            return response()->json(['status' => 'unknown_registration'], 200);
        }

        $registration = $provisioner->markPaymentConfirmed(
            $registration,
            $provider->name(),
            $event['customer_id'],
            $event['subscription_id'],
        );

        // Found by a "what if" pass: two registrations can innocently share an email, and
        // whichever pays second used to crash provision() with a raw database exception, leaving
        // the registration stuck at payment_confirmed forever with nothing to show for it. That
        // is now a typed refusal (RegistrationProvisioner marks the registration for a human to
        // resolve via the platform registrations queue before throwing) - caught here so the
        // webhook still returns 200 (retrying will never succeed; there is nothing to retry) and
        // no "your account is ready" email goes out for an account that was never created.
        try {
            $result = $provisioner->provision($registration);
        } catch (\App\Domain\Onboarding\DuplicateEmailProvisioningException $e) {
            return response()->json(['status' => 'provisioning_failed_duplicate_email'], 200);
        }

        // password_setup_token is only non-null on the first, real provisioning of this
        // registration (RegistrationProvisioner::provision returns null for it on the idempotent
        // re-provision path) - this is what keeps a retried webhook delivery from re-sending the
        // welcome email a second time.
        if ($result['password_setup_token'] !== null) {
            Mail::to($result['admin_user']->email)->send(
                new ContractorAccountProvisioned($result['tenant'], $result['admin_user'], $result['password_setup_token'])
            );
        }

        return response()->json(['status' => 'ok']);
    }
}
