<?php

namespace App\Http\Controllers\Onboarding;

use App\Domain\Onboarding\PaymentProvider;
use App\Http\Controllers\Controller;
use App\Models\ContractorRegistration;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Step 1 (blocking organization profile) and step 2 (starting payment) of the self-serve
 * contractor onboarding flow. See claude/payment-gateway-and-contractor-onboarding-design-brief.md
 * (project docs) for the full closed design this implements.
 */
class RegistrationController extends Controller
{
    /**
     * Step 1: create the registration record. Nothing about this step touches payment — it is
     * pure organization-profile capture and can be safely retried/resubmitted (a client-generated
     * registration_id, if provided, dedupes; otherwise one is generated here).
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'registration_id' => 'nullable|uuid',
            'legal_name' => 'required|string|max:255',
            'business_name' => 'nullable|string|max:255',
            'entity_type' => 'required|string|in:'.implode(',', array_keys(ContractorRegistration::entityTypes())),
            'plan' => 'required|string|in:'.implode(',', array_keys(ContractorRegistration::plans())),
            'country' => 'required|string|max:2', // ISO 3166-1 alpha-2: US, CA, etc.
            'admin_first_name' => 'required|string|max:128',
            'admin_last_name' => 'required|string|max:128',
            'phone' => 'required|string|max:32',
            'address.line1' => 'required|string|max:255',
            'address.line2' => 'nullable|string|max:255',
            'address.city' => 'required|string|max:128',
            'address.region' => 'required|string|max:128', // state/province
            'address.postal_code' => 'required|string|max:32',
            'email' => 'required|email|max:255',
        ]);

        $registrationId = $data['registration_id'] ?? (string) Str::uuid();

        // Upsert on registration_id: resubmitting step 1 (e.g. the user corrects a typo and
        // re-submits with the same client-held registration_id) updates the same row rather than
        // creating a duplicate registration. Built via firstOrNew rather than updateOrCreate so we
        // can set `status` only on first creation — updateOrCreate's $values array applies to both
        // branches, which would reset an already-paid/provisioned registration's status back to
        // pending_payment on a resubmit. This also sidesteps a separate quirk: an Eloquent model
        // returned by a fresh INSERT does not carry the DB column's own default value (e.g.
        // `status` defaulting to 'pending_payment' at the schema level) unless it was explicitly
        // set on the model before save() — the in-memory attribute stays null even though the row
        // in the database is correct.
        $registration = ContractorRegistration::firstOrNew(['registration_id' => $registrationId]);
        $isNewRegistration = ! $registration->exists;

        // Found via a real-world "what if" pass: this had no status check at all, so resubmitting
        // step 1 with an already-provisioned registration_id silently overwrote email/name/address
        // on a registration whose tenant and admin user already exist - and since provision()'s own
        // idempotent-retry path (a real, expected occurrence: payment-provider webhooks do get
        // retried) looks up the admin by registration.email, changing that email here breaks that
        // guarantee outright: a retried webhook after this resubmit throws ModelNotFoundException
        // instead of returning the existing tenant, exactly the failure mode this class's own
        // docblock says can never happen. Step 1 is for correcting a typo before payment, never
        // for editing a paid, provisioned account after the fact - that goes through account
        // settings, not this anonymous, unauthenticated endpoint.
        if (! $isNewRegistration && $registration->status !== ContractorRegistration::STATUS_PENDING_PAYMENT) {
            return response()->json([
                'message' => 'This registration has already moved past the payment step and can no longer be edited here.',
                'status' => $registration->status,
            ], 409);
        }

        $registration->fill([
            'legal_name' => $data['legal_name'],
            'business_name' => $data['business_name'] ?? null,
            'entity_type' => $data['entity_type'],
            'plan' => $data['plan'],
            'country' => strtoupper($data['country']),
            'admin_first_name' => $data['admin_first_name'],
            'admin_last_name' => $data['admin_last_name'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'email' => $data['email'],
        ]);

        if ($isNewRegistration) {
            $registration->status = ContractorRegistration::STATUS_PENDING_PAYMENT;
        }

        $registration->save();

        return response()->json([
            'registration_id' => $registration->registration_id,
            'status' => $registration->status,
        ], 201);
    }

    /**
     * Step 2: start payment with the chosen provider (card via Stripe, or PayPal — no crypto, no
     * ACH, per the closed design). Returns the URL to redirect the customer to; this app never
     * renders a card/bank form itself.
     */
    public function checkout(Request $request, string $registrationId)
    {
        $data = $request->validate([
            'provider' => 'required|string|in:stripe,paypal',
        ]);

        $registration = ContractorRegistration::where('registration_id', $registrationId)->firstOrFail();

        if ($registration->status !== ContractorRegistration::STATUS_PENDING_PAYMENT) {
            return response()->json([
                'message' => 'This registration has already moved past the payment step.',
                'status' => $registration->status,
            ], 409);
        }

        $provider = $this->resolveProvider($data['provider']);

        try {
            $url = $provider->startCheckout($registration);
        } catch (\App\Domain\Onboarding\PaymentProviderNotConfiguredException $e) {
            // Expected, recoverable: this provider hasn't had its keys/price-plan added to this
            // environment yet — never a 500, and never silently treated as success.
            return response()->json([
                'message' => ucfirst($data['provider']).' is not available yet for this plan. Please try the other payment method, or contact us.',
            ], 503);
        }

        return response()->json(['checkout_url' => $url]);
    }

    private function resolveProvider(string $name): PaymentProvider
    {
        return match ($name) {
            'stripe' => app(\App\Domain\Onboarding\StripePaymentProvider::class),
            'paypal' => app(\App\Domain\Onboarding\PayPalPaymentProvider::class),
        };
    }
}
