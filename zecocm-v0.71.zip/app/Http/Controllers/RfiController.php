<?php

namespace App\Http\Controllers;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Schedule\ProjectAccess;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Tenancy\TenantContext;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Http\Request;

class RfiController
{
    public function __construct(
        private readonly AiAssistant $assistant,
        private readonly ProjectAccess $access,
    ) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'records.view');

        return Rfi::where('project_id', $grant->project->id)
            ->orderByDesc('raised_at')->orderByDesc('id')->limit(200)->get();
    }

    public function store(Request $request)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        }
        $data = $request->validate([
            'project_id' => 'required|integer',
            'subject' => 'required|string|max:255',
            'question' => 'required|string',
            'raised_by_org' => 'nullable|string|max:128',
            'spec_section' => 'nullable|string|max:255',
            'plan_sheets' => 'nullable|string|max:255',
            'reference' => 'nullable|string|max:255',
            'linked_submittal_id' => 'nullable|integer',
            'cost_impact_state' => 'nullable|in:yes,no,not_stated',
            'schedule_impact' => 'nullable|in:yes,no,not_stated',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'rfi.create', write: true);

        // A linked submittal must belong to THIS project; a foreign id is refused, not ignored.
        $linkedId = null;
        if (! empty($data['linked_submittal_id'])) {
            $linked = Submittal::query()
                ->where('project_id', $grant->project->id)
                ->find((int) $data['linked_submittal_id']);
            abort_if($linked === null, 422, 'That submittal is not on this project.');
            $linkedId = $linked->id;
        }

        // Round 12: two people raising an RFI on the same project within the
        // same instant both read the same max(number) before either insert
        // commits, then both attempt to create "the next" number - and the
        // table's own (project_id, number) unique constraint (see
        // 2026_08_24_000008_create_rfis_table.php) means the second of the
        // two throws, not silently duplicates. Before this loop that throw
        // was never caught: the second submitter's honest, well-formed
        // request produced a raw unique-constraint QueryException -> an
        // unhandled 500, on the exact "I clicked submit and my RFI vanished"
        // moment a real user is least equipped to make sense of. Recomputing
        // the number and retrying is safe precisely because nothing about
        // this insert depends on anything other party wrote - "the next
        // number" is a re-derivable fact, not a decision that needs to
        // survive a conflict the way a pay application's certified figures
        // do (see PayApplicationController::certify()'s content-hash check).
        $attempts = 0;
        while (true) {
            $next = (int) Rfi::query()
                ->where('project_id', $grant->project->id)
                ->selectRaw("max(cast(replace(number, 'RFI-', '') as integer)) as n")
                ->value('n');
            $number = sprintf('RFI-%03d', $next + 1);

            try {
                $rfi = Rfi::create([
                    'project_id' => $grant->project->id,
                    'number' => $number,
                    'subject' => $data['subject'],
                    'question' => $data['question'],
                    'raised_by_org' => ($data['raised_by_org'] ?? null) ?: ($grant->organization ?: 'This account'),
                    'raised_at' => now(),
                    'ball_in_court' => 'architect',
                    'spec_section' => $data['spec_section'] ?? null,
                    'plan_sheets' => $data['plan_sheets'] ?? null,
                    'reference' => $data['reference'] ?? null,
                    'linked_submittal_id' => $linkedId,
                    'cost_impact_state' => $data['cost_impact_state'] ?? 'not_stated',
                    'schedule_impact' => $data['schedule_impact'] ?? 'not_stated',
                    'status' => 'open',
                    // NOT NULL on the table; omitting it made every API-created RFI fail with a 500.
                    'ai_dispositions' => [],
                    'routing_history' => [[
                        'to' => 'architect', 'at' => now()->toIso8601String(),
                        'action' => 'raised', 'by' => $request->user()->id,
                    ]],
                ]);
                break;
            } catch (UniqueConstraintViolationException $e) {
                if (++$attempts >= 5) {
                    throw $e;
                }
            }
        }

        return response()->json($rfi, 201);
    }

    public function assist(Request $request, Rfi $rfi)
    {
        $this->access->authorize($request->user(), $rfi->project_id, 'rfi.assist', write: true);
        $category = $request->string('category', 'dimension_clarification')->toString();
        $request->attributes->set('authorized_project_id', $rfi->project_id);

        $result = $this->assistant->suggest(
            task: $rfi->subject."\n".$rfi->question,
            category: $category,
            scope: $rfi->project->jurisdictionScope(),   // derived from the project, never user-picked
            policy: new RefusalPolicy,
        );

        // The suggestion/escalation itself becomes part of the record the
        // moment it is shown - before the human even acts on it.
        $rfi->recordAiDisposition(['kind' => $result->kind()], 'presented', $request->user()->id);
        $rfi->save();

        return response()->json(['kind' => $result->kind(), 'result' => $result]);
    }

    /**
     * Editable up to the point of a sealed response - mirrors
     * DailyReportController::update()'s "editable before seal, append-only
     * correction after" pattern, which is this app's own established
     * precedent for correcting an honest mistake without rewriting sealed
     * evidence. Found missing during a real-world audit: there was no way
     * to fix so much as a typo in a raised RFI before the architect
     * answered it - the only options were "live with the typo" or "raise a
     * second RFI," neither of which is what a real user expects from a
     * "draft" stage the app's own UI copy already implies exists.
     */
    public function update(Request $request, Rfi $rfi)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        }
        $this->access->authorize($request->user(), $rfi->project_id, 'rfi.create', write: true);
        abort_if($rfi->response_seal !== null, 422,
            'This RFI already has a sealed response. A sealed answer is never rewritten - raise a revision or a new RFI instead.');

        $data = $request->validate([
            'subject' => 'sometimes|required|string|max:255',
            'question' => 'sometimes|required|string',
            'spec_section' => 'nullable|string|max:255',
            'plan_sheets' => 'nullable|string|max:255',
            'reference' => 'nullable|string|max:255',
            'cost_impact_state' => 'nullable|in:yes,no,not_stated',
            'schedule_impact' => 'nullable|in:yes,no,not_stated',
        ]);

        // Found in an independent AI cross-check of this fix: an edit here is
        // silent otherwise - if the party answering started reviewing before
        // the question changed underneath them, nothing records what it used
        // to say. Appending to routing_history (the same append-only log
        // Submittal::route() already writes to) answers "what did it
        // originally say" without needing a full state-machine redesign.
        //
        // Found during the "what if" adversarial pass: a request body with
        // only unrecognized fields (none of the whitelist above) validates to
        // an empty $data and update() is a true no-op - but this used to log
        // an "edited" entry anyway, with an empty before: [], recording a
        // change that never happened. Skip the log (and the update call
        // entirely) when there is nothing real to record.
        if (empty($data)) {
            return response()->json($rfi->fresh());
        }

        $before = array_intersect_key($rfi->getAttributes(), $data);
        $history = $rfi->routing_history ?? [];
        $history[] = ['action' => 'edited', 'by' => $request->user()->id, 'at' => now()->toIso8601String(), 'before' => $before];
        $rfi->routing_history = $history;
        $rfi->update($data);

        return response()->json($rfi->fresh());
    }

    public function respond(Request $request, Rfi $rfi)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians are read-only in customer workspaces - submit a suggestion; the admin applies it.');
        }
        $this->access->authorize($request->user(), $rfi->project_id, 'rfi.respond', write: true);

        $data = $request->validate(['response' => 'required|string']);

        // A sealed answer is sealed. Before this guard a second POST silently
        // overwrote both the response and its seal, leaving no trace that a
        // different answer had ever been issued - on the exact record a dispute
        // turns on. A changed answer is a new RFI or a formal revision, never a
        // quiet rewrite of the original.
        abort_if($rfi->response_seal !== null, 409,
            'This RFI response is already sealed. Issue a revision or a new RFI; a sealed answer is never rewritten.');

        $rfi->response = $data['response'];
        $rfi->status = 'answered';
        $rfi->response_seal = [
            'by' => $request->user()->id,
            'sealed_at' => now()->toIso8601String(),
        ];
        $rfi->save();

        return response()->json($rfi);
    }
}
