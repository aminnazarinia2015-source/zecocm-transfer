<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController
{
    // A fixed, valid bcrypt hash with no corresponding real password. When the email doesn't
    // match any account we still run Hash::check against this instead of short-circuiting, so a
    // nonexistent-email response costs the same bcrypt work as a wrong-password one. Without this,
    // Hash::check only ever ran for a real email (it's skipped by the `$user === null ||` short
    // circuit above), making the response for "no such account" measurably faster than "wrong
    // password" - a timing side channel an attacker can use to enumerate which emails have
    // accounts without ever seeing a different message. Found via adversarial "what if" pass.
    private const DUMMY_HASH = '$2y$12$CiKnbCP95x/vHuFfXpyHMOF5bDoA.sdy4mW5/q.8PV1tv8vxbaPsi';

    /** ONE login. The account decides who you are - never a role picker. */
    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $data['email'])->first();
        $hashToCheck = $user->password ?? self::DUMMY_HASH;
        $passwordOk = Hash::check($data['password'], $hashToCheck);
        if ($user === null || ! $passwordOk) {
            return response()->json(['message' => 'Invalid credentials.'], 422);
        }

        // Platform staff have no tenant_id and are never blocked here. A
        // customer user whose tenant has been suspended (not deleted - see
        // PlatformController::setStatus) cannot sign in until reactivated.
        if ($user->tenant_id !== null) {
            $tenant = Tenant::find($user->tenant_id);
            if ($tenant !== null && $tenant->status === 'suspended') {
                return response()->json(['message' => 'This account has been suspended. Contact your ZecoCM administrator.'], 403);
            }
        }

        $token = $user->createToken('zecocm')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'platform_role' => $user->platform_role,   // null => customer user
                'tenant_id' => $user->tenant_id,
            ],
        ]);
    }
}
