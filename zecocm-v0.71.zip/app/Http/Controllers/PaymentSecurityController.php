<?php

namespace App\Http\Controllers;

use App\Domain\Payment\ReleaseCoverage;
use App\Domain\Payment\StopNoticeWithholding;
use App\Domain\Schedule\ProjectAccess;
use App\Models\LienRelease;
use App\Models\StopPaymentNotice;
use Illuminate\Http\Request;

/**
 * The two records that decide whether money should leave the building.
 *
 * They are served by one controller and reported as two totals that are never
 * added together, because that is the invariant the whole area turns on: a
 * waiver and release reduces exposure to a claimant, a stop payment notice
 * freezes money in the owner's hands, and an owner who lets one answer the
 * other pays twice.
 *
 * This surface records facts and reports gaps. It does not decide that a
 * claimant's lien rights are gone, and it does not decide that a stop payment
 * notice is bad - both are legal determinations, and the standing rule here is
 * that this system retrieves, cites, and refuses.
 */
class PaymentSecurityController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'payment.view')->project;

        $releases = LienRelease::query()->where('project_id', $project->id)
            ->orderByDesc('through_date')->limit(500)->get();

        $notices = StopPaymentNotice::query()->where('project_id', $project->id)
            ->orderByDesc('served_on')->limit(500)->get();

        $required = StopNoticeWithholding::required($notices->map(fn ($n) => $this->noticeArray($n))->all());

        return response()->json([
            'releases' => $releases->map(fn (LienRelease $r) => [
                'id' => $r->id,
                'claimant_name' => $r->claimant_name,
                'form_type' => $r->form_type,
                'form_label' => ReleaseCoverage::label((string) $r->form_type),
                'citation' => ReleaseCoverage::CITATIONS[$r->form_type] ?? null,
                'through_date' => $r->through_date?->toDateString(),
                'amount_cents' => (int) $r->amount_cents,
                'conditional' => $r->isConditional(),
                'document_on_file' => (bool) $r->document_on_file,
                'exceptions_stated' => (bool) $r->exceptions_stated,
                'exceptions' => $r->exceptions,
                'payment_cleared_on' => $r->payment_cleared_on?->toDateString(),
                'payment_cleared_amount_cents' => $r->payment_cleared_amount_cents,
                'exceptions_structured' => (bool) $r->exceptions_structured,
                // A conditional release held against a payment nobody confirmed
                // cleared is a promise. The list says so on its face rather than
                // making somebody open each row to find out.
                'has_taken_effect' => $r->hasTakenEffect(),
            ]),
            'stop_notices' => $notices->map(fn (StopPaymentNotice $n) => [
                'id' => $n->id,
                'claimant_name' => $n->claimant_name,
                'claimant_role' => $n->claimant_role,
                'claimed_amount_cents' => (int) $n->claimed_amount_cents,
                'withhold_cents' => $n->withholdCents(),
                'served_on' => $n->served_on?->toDateString(),
                'status' => $n->status,
                'preliminary_notice_on_file' => (bool) $n->preliminary_notice_on_file,
                'release_bond_on_file' => (bool) $n->release_bond_on_file,
                'service_state' => $n->service_state,
                'service_effectiveness' => $n->service_effectiveness,
                'served_to_role' => $n->served_to_role,
                'still_freezes_funds' => $n->stillFreezesFunds(),
            ]),
            // Two totals, deliberately. Nothing in this payload nets them.
            'frozen' => [
                'total_withheld_cents' => $required['total_withheld_cents'],
                'basis' => 'Civil Code s. 9358 - the claim plus 25 per cent for the public entity\'s costs.',
                'note' => 'Frozen funds remain owed to the contractor. They are unpayable, not deducted.',
            ],
            'findings' => $required['findings'],
        ]);
    }

    /** @return array<string,mixed> */
    private function noticeArray(StopPaymentNotice $n): array
    {
        return [
            'claimant_name' => $n->claimant_name,
            'claimant_role' => $n->claimant_role,
            'claimed_amount_cents' => (int) $n->claimed_amount_cents,
            'served_on' => $n->served_on?->toDateString(),
            'status' => $n->status,
            'preliminary_notice_on_file' => (bool) $n->preliminary_notice_on_file,
            'release_bond_on_file' => (bool) $n->release_bond_on_file,
            'service_state' => $n->service_state,
            'service_effectiveness' => $n->service_effectiveness,
            'served_to_role' => $n->served_to_role,
        ];
    }

    public function storeRelease(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'claimant_name' => 'required|string|max:200',
            'form_type' => 'required|in:conditional_progress,unconditional_progress,conditional_final,unconditional_final',
            'through_date' => 'nullable|date',
            'amount_cents' => 'nullable|integer|min:0',
            'trade_partner_id' => 'nullable|integer',
            'subcontract_id' => 'nullable|integer',
            'pay_application_id' => 'nullable|integer',
            'exceptions' => 'nullable|string|max:4000',
            'signed_by' => 'nullable|string|max:160',
            'signed_on' => 'nullable|date',
            'document_on_file' => 'boolean',
            'payment_cleared_on' => 'nullable|date',
            'payment_cleared_amount_cents' => 'nullable|integer|min:0',
            'payment_reference' => 'nullable|string|max:120',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'payment.create', write: true)->project;

        // An empty exceptions box and "none stated" are different facts, and the
        // flag is derived from the text rather than trusted from the client:
        // a form that says "except retention" has not released retention, and a
        // client that forgot to set the flag must not be able to hide that.
        $data['exceptions_stated'] = trim((string) ($data['exceptions'] ?? '')) !== '';
        $data['tenant_id'] = $project->tenant_id;

        $release = LienRelease::create($data);

        return response()->json(['release' => $release], 201);
    }

    public function storeNotice(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'claimant_name' => 'required|string|max:200',
            'claimant_role' => 'nullable|string|max:64',
            'claimed_amount_cents' => 'required|integer|min:0',
            'served_on' => 'required|date',
            'served_method' => 'nullable|string|max:64',
            'trade_partner_id' => 'nullable|integer',
            'preliminary_notice_on_file' => 'boolean',
            'preliminary_notice_served_on' => 'nullable|date',
            'service_state' => 'nullable|in:prepared,sent,statutory_recipient_verified',
            'served_to_role' => 'nullable|string|max:120',
            'delivery_evidence' => 'nullable|string|max:255',
            'notes' => 'nullable|string|max:4000',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'payment.create', write: true)->project;

        $data['tenant_id'] = $project->tenant_id;
        // A notice is created open. Nothing may create one already resolved -
        // resolution is an event with a date and a reference behind it.
        $data['status'] = StopNoticeWithholding::OPEN;
        // Service effectiveness is never taken from the client. A caller may
        // say where it was sent; only a recorded human verification against the
        // statutory recipient may say it was served.
        $data['service_effectiveness'] = StopNoticeWithholding::SERVICE_UNRESOLVED;
        // s. 9352: the claim freezes at service. From here the amount is
        // immutable and the model enforces it.
        $data['served_amount_locked_at'] = now();

        $notice = StopPaymentNotice::create($data);

        return response()->json([
            'notice' => $notice,
            'withhold_cents' => $notice->withholdCents(),
        ], 201);
    }

    /**
     * Resolving a notice is the act that lets money move again, so it carries
     * its own reasons and its own refusals rather than being a status edit.
     */
    public function resolveNotice(Request $request, StopPaymentNotice $notice)
    {
        $data = $request->validate([
            'status' => 'required|in:released,bonded_around,withdrawn,forfeited',
            'resolved_on' => 'required|date',
            'resolution_reference' => 'nullable|string|max:200',
            'release_bond_on_file' => 'boolean',
        ]);

        $this->access->authorize($request->user(), (int) $notice->project_id, 'payment.create', write: true);

        // s. 9364: the bond is what frees the funds. Marking a notice bonded
        // around without it in the file would release money on a promise, so
        // this refuses rather than recording an optimistic status.
        if ($data['status'] === StopNoticeWithholding::BONDED_AROUND && ! ($data['release_bond_on_file'] ?? false)) {
            return response()->json([
                'error' => 'A stop payment notice cannot be recorded as bonded around until the release bond is on file. '
                    .'Under Civil Code section 9364 it is the bond, in 125 per cent of the claim, that frees the withheld funds - '
                    .'not the undertaking to provide one.',
                'citation' => 'Civil Code s. 9364',
            ], 422);
        }

        $notice->fill($data)->save();

        return response()->json(['notice' => $notice->fresh(), 'still_freezes_funds' => $notice->fresh()->stillFreezesFunds()]);
    }
}
