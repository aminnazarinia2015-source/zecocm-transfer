<?php

namespace App\Http\Controllers;

use App\Domain\Brief\BriefBuilder;
use App\Domain\Schedule\ProjectAccess;
use App\Services\WeatherService;
use Illuminate\Http\Request;

/**
 * The Daily Project Success Brief. Deterministic, cited, freshness-stamped, and
 * explicit about what it refuses to say.
 */
class BriefController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function show(Request $request, int $project, WeatherService $weather)
    {
        $grant = $this->access->authorize($request->user(), $project, 'records.view');

        return response()->json(
            (new BriefBuilder($weather))->build($grant->project, $grant)
        );
    }
}
