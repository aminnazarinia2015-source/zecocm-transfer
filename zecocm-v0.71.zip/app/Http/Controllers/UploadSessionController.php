<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\DocumentFolder;
use App\Models\KnowledgeSource;
use App\Models\UploadSession;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Chunked/resumable upload backend, wired to the Document Library's two upload
 * surfaces (new document, new document version) - see upload_sessions migration's
 * doc comment for the "why" (real drawing sets run 300-500MB; a single blocking
 * multipart POST means a dropped jobsite connection restarts the whole transfer).
 *
 * Deliberately NOT wired to Knowledge-source or Schedule/CPM uploads in this pass -
 * those files are typically much smaller (schedule XML/XER, knowledge PDFs) and
 * don't carry the specific urgency Amin named (project drawing sets). The
 * `target`/`target_context` columns on upload_sessions are generic so extending this
 * controller (or adding sibling ones) to those surfaces later needs no schema change.
 *
 * Also deliberately keeps the malware scan SYNCHRONOUS at finalize() - moving it to a
 * background queue job is a separate, larger change: several dozen existing tests
 * across this codebase assume a synchronous scan-result contract on the response of
 * a document upload, and rewiring that is out of scope for landing chunked upload
 * itself. Documented here as explicit follow-up, not silently deferred.
 *
 * Every route here carries the same capability:documents gate and
 * ProjectAccess::authorize() rigor as DocumentLibraryController's own routes (see
 * routes/api.php) - a chunked-upload session that could be created or advanced
 * without that gate would be exactly the phantom-endpoint bug class this app's audit
 * pass has already found and fixed multiple times elsewhere.
 *
 * A session is additionally scoped to the user who created it: authorize() below
 * checks project membership (same as every other write), and every action here
 * further requires the acting user to be the session's own created_by. Two different
 * users on the same project-authorized team do not share resumable upload sessions -
 * a session is a capability to keep writing to one specific assembly file, not a
 * project-wide upload slot.
 */
class UploadSessionController
{
    // 750MB - must track DocumentLibraryController's own 'file' => 'max:768000' (KB)
    // validation rule and UploadLimitsHealthCheck's ceiling. Checked at session
    // CREATION time (declared_total_bytes), not only discovered at finalize, so a
    // caller can never even start a transfer that could not finish.
    private const MAX_DECLARED_BYTES = 768000 * 1024;

    // Sanity bound on a single chunk PUT. The client picks its own chunk size
    // (public/app.html uses 8MB - see ZAPI.uploadChunked's comment for why), but the
    // server never trusts the client's choice blindly: this is deliberately several
    // times the client's chunk size, not a tight match to it, so it never becomes a
    // second source of truth for "the" chunk size - it exists only to stop a single
    // PUT from re-creating the exact unbounded-request problem chunking exists to
    // avoid.
    private const MAX_CHUNK_BYTES = 32 * 1024 * 1024;

    public function __construct(private readonly ProjectAccess $access, private readonly DocumentLibraryController $documentLibrary) {}

    public function create(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'folder_id' => 'nullable|integer',
            'target' => 'required|in:document,document_version',
            'document_id' => 'required_if:target,document_version|integer',
            'original_filename' => 'required|string|max:255',
            'declared_total_bytes' => 'required|integer|min:1|max:'.self::MAX_DECLARED_BYTES,
            'declared_content_type' => 'nullable|string|max:128',
            'title' => 'nullable|string|max:255',
            'classification' => 'nullable|in:project_private,tenant_private,party_shared,restricted',
            'revision' => 'nullable|string|max:96',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.ingest', write: true)->project;

        $folderId = isset($data['folder_id']) ? (int) $data['folder_id'] : null;
        if ($folderId !== null) {
            DocumentFolder::query()->where('project_id', $project->id)->findOrFail($folderId);
        }

        $document = null;
        if ($data['target'] === UploadSession::TARGET_DOCUMENT_VERSION) {
            $document = KnowledgeSource::query()->where('project_id', $project->id)->findOrFail((int) $data['document_id']);
        }

        $sessionToken = (string) Str::uuid();
        $storagePath = 'upload-sessions/'.$project->tenant_id.'/'.$project->id.'/'.$sessionToken.'.part';
        // touch() the assembly file at zero bytes now, rather than lazily on the first
        // chunk, so status() can report bytes_received=0 truthfully for a session that
        // exists but has not yet received any bytes.
        Storage::disk('local')->put($storagePath, '');

        $session = UploadSession::create([
            'tenant_id' => $project->tenant_id,
            'project_id' => $project->id,
            'created_by' => $request->user()->id,
            'target' => $data['target'],
            'target_context' => [
                'folder_id' => $folderId,
                'document_id' => $document?->id,
                'title' => $data['title'] ?? null,
                'classification' => $data['classification'] ?? null,
                'revision' => $data['revision'] ?? null,
            ],
            'original_filename' => $data['original_filename'],
            'declared_total_bytes' => (int) $data['declared_total_bytes'],
            'declared_content_type' => $data['declared_content_type'] ?? null,
            'bytes_received' => 0,
            'storage_path' => $storagePath,
            'status' => UploadSession::STATUS_IN_PROGRESS,
        ]);

        return response()->json([
            'session' => $this->present($session),
            'notice' => 'Upload session created. Send chunks in order starting at offset 0, then finalize.',
        ], 201);
    }

    public function status(Request $request, UploadSession $session)
    {
        $this->authorizeSession($request, $session);

        return response()->json(['session' => $this->present($session)]);
    }

    public function chunk(Request $request, UploadSession $session)
    {
        $this->authorizeSession($request, $session);

        if ($session->status !== UploadSession::STATUS_IN_PROGRESS) {
            abort(409, 'This upload session is '.$session->status.' and can no longer accept chunks.');
        }

        $data = $request->validate(['offset' => 'required|integer|min:0']);
        $offset = (int) $data['offset'];

        $body = $request->getContent();
        $length = strlen($body);

        if ($length === 0) {
            abort(422, 'Empty chunk bodies are not accepted.');
        }

        if ($length > self::MAX_CHUNK_BYTES) {
            abort(422, 'This chunk exceeds the maximum accepted chunk size ('.self::MAX_CHUNK_BYTES.' bytes).');
        }

        // The core of resumability: a chunk is only accepted if it starts exactly where
        // the server's own record says the assembly file currently ends. Out-of-order,
        // duplicate, and stale-resume chunks are all the same failure mode from the
        // server's point of view - "this does not start where I am" - and the response
        // tells the client exactly where it DOES need to resume from, so a reconnecting
        // client can self-correct without a separate status() round trip.
        if ($offset !== $session->bytes_received) {
            return response()->json([
                'message' => 'Chunk offset does not match bytes already received; resume from the reported offset.',
                'expected_offset' => $session->bytes_received,
            ], 409);
        }

        if ($session->bytes_received + $length > $session->declared_total_bytes) {
            abort(422, 'This chunk would push the upload past its declared total size.');
        }

        $absolutePath = Storage::disk('local')->path($session->storage_path);
        $handle = fopen($absolutePath, 'ab');
        if ($handle === false) {
            abort(500, 'The upload session assembly file could not be opened for writing.');
        }
        try {
            $written = fwrite($handle, $body);
        } finally {
            fclose($handle);
        }
        if ($written !== $length) {
            abort(500, 'The chunk was not fully written to disk; retry this chunk.');
        }

        $session->update(['bytes_received' => $session->bytes_received + $length]);

        return response()->json(['session' => $this->present($session)]);
    }

    public function finalize(Request $request, UploadSession $session)
    {
        $this->authorizeSession($request, $session);

        if ($session->status !== UploadSession::STATUS_IN_PROGRESS) {
            abort(409, 'This upload session is '.$session->status.' and cannot be finalized again.');
        }

        if ($session->bytes_received !== $session->declared_total_bytes) {
            abort(409, 'Not all declared bytes have been received yet ('.$session->bytes_received.' of '.
                $session->declared_total_bytes.'); finalize refused rather than create a truncated file.');
        }

        $absolutePath = Storage::disk('local')->path($session->storage_path);
        $file = new UploadedFile($absolutePath, $session->original_filename, $session->declared_content_type, null, true);

        try {
            $context = $session->target_context ?? [];

            if ($session->target === UploadSession::TARGET_DOCUMENT) {
                $response = $this->documentLibrary->admitAndCreateDocument(
                    $session->project,
                    $file,
                    isset($context['folder_id']) ? (int) $context['folder_id'] : null,
                    $context['title'] ?? null,
                    $context['classification'] ?? null,
                    $session->created_by,
                );
            } else {
                $document = KnowledgeSource::query()->where('project_id', $session->project_id)
                    ->findOrFail((int) $context['document_id']);
                $response = $this->documentLibrary->admitAndCreateVersion($document, $file, $context['revision'] ?? null, $session->created_by);
            }
        } catch (\Throwable $e) {
            $session->update(['status' => UploadSession::STATUS_FAILED, 'failure_reason' => $this->failureReason($e)]);
            $this->cleanupAssembly($session);
            throw $e;
        }

        $session->update(['status' => UploadSession::STATUS_COMPLETED]);
        $this->cleanupAssembly($session);

        return $response;
    }

    private function authorizeSession(Request $request, UploadSession $session): void
    {
        // ProjectAccess::authorize() already fails closed (404) for a project the
        // caller's tenant/membership does not reach, so a cross-tenant or
        // cross-project session id 404s here exactly like every other resource in
        // this app. Layered on top: the session must belong to the requesting user -
        // see class doc for why this is per-user, not merely per-project.
        $this->access->authorize($request->user(), (int) $session->project_id, 'documents.ingest', write: true);
        abort_if($session->created_by !== $request->user()->id, 404, 'No upload session matches that id for this account.');
    }

    private function present(UploadSession $session): array
    {
        return [
            'id' => $session->id,
            'status' => $session->status,
            'target' => $session->target,
            'original_filename' => $session->original_filename,
            'declared_total_bytes' => $session->declared_total_bytes,
            'bytes_received' => $session->bytes_received,
        ];
    }

    private function failureReason(\Throwable $e): string
    {
        if ($e instanceof ValidationException) {
            return 'validation: '.implode(' ', $e->validator->errors()->all());
        }

        return Str::limit($e->getMessage(), 240, '');
    }

    private function cleanupAssembly(UploadSession $session): void
    {
        if (Storage::disk('local')->exists($session->storage_path)) {
            Storage::disk('local')->delete($session->storage_path);
        }
    }
}
