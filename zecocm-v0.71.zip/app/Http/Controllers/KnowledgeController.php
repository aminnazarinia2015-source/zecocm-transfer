<?php

namespace App\Http\Controllers;

use App\Domain\Governance\GovernedDetermination;
use App\Domain\Knowledge\KnowledgeClassifier;
use App\Domain\Knowledge\Ocr\KnowledgeDocumentExtractor;
use App\Domain\Knowledge\Ocr\PageExtraction;
use App\Domain\Knowledge\PassageChunker;
use App\Domain\Provenance\CanonicalPayload;
use App\Domain\Provenance\ChainAnchor;
use App\Domain\Provenance\DigestAlgorithm;
use App\Domain\Schedule\ProjectAccess;
use App\Domain\Security\BoundedProcess;
use App\Domain\Security\SecureUploadGate;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourcePage;
use App\Models\KnowledgeSourceVersion;
use App\Models\OcrExtractionAttempt;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class KnowledgeController
{
    private const IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/tiff'];

    public function __construct(
        private readonly ProjectAccess $access,
        private readonly KnowledgeClassifier $classifier,
        private readonly PassageChunker $chunker,
        private readonly KnowledgeDocumentExtractor $documentExtractor,
    ) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer', 'status' => 'nullable|string|max:24']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.view')->project;
        $query = KnowledgeSource::query()->where('project_id', $project->id)->with('versions');
        if (! empty($data['status'])) {
            $query->where('verification_status', $data['status']);
        }

        return response()->json(['sources' => $query->latest('id')->limit(200)->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'collection' => 'required|in:project,organization,city,regulatory',
            'corpus' => 'required|in:project_specs,project_plans,project_contract,state_public_contract_code,prevailing_wage_determinations,greenbook,far_dfars,building_code',
            'title' => 'required|string|max:255',
            'source_type' => 'required|in:contract,specification,drawing,standard,regulation,policy,correspondence,lesson',
            'authority_level' => 'required|in:party_assertion,project_contract,adopted_standard,published_regulation,historical_pattern',
            'edition' => 'nullable|string|max:96',
            'revision' => 'nullable|string|max:96',
            'jurisdiction' => 'nullable|string|max:128',
            'effective_from' => 'nullable|date',
            'text' => 'nullable|string|max:5000000|required_without:file',
            'file' => 'nullable|file|max:25600|mimetypes:application/pdf,text/plain,image/jpeg,image/png,image/tiff|required_without:text',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.ingest', write: true)->project;

        $text = $data['text'] ?? '';
        $mime = 'text/plain';
        $bytes = strlen($text);
        $hash = hash('sha256', $text);
        $scan = 'clean';
        $method = 'submitted_text';
        $confidence = 1.0;
        /** @var list<PageExtraction> $pages D4: populated only for a PDF or image upload - see extractPagesFromFile() */
        $pages = [];
        // D4/Codex's ruling: a bounded document must never silently present
        // itself as fully covered. Non-empty only when extractPdf() itself
        // had to stop short of the whole document (max_pages_total) - the
        // per-page skipped_bound/failed states already give each individual
        // unprocessed-for-other-reasons page its own row.
        $documentWarnings = [];

        if ($request->hasFile('file')) {
            $file = $request->file('file');

            // SEC-5: the request-level 'mimetypes:...' rule above already
            // narrows this endpoint to pdf/text/plain/image, but that is
            // Laravel's own check, not this codebase's one gateway - route it
            // through SecureUploadGate anyway so this path can never quietly
            // drift out of step with DocumentLibraryController and
            // MediaController.
            $decision = SecureUploadGate::admit($file, SecureUploadGate::DOCUMENT_INGESTION);
            if (! $decision->admitted) {
                throw ValidationException::withMessages([
                    'file' => 'Only documentary files are accepted ('.$decision->rejectionReason.').',
                ]);
            }

            $path = $file->getRealPath();
            $mime = (string) ($file->getMimeType() ?: 'application/octet-stream');
            $bytes = (int) $file->getSize();
            $hash = hash_file('sha256', $path);
            $scan = SecureUploadGate::scan($path, SecureUploadGate::timeoutForSize($bytes));
            if ($scan !== 'clean') {
                $text = '';
            } elseif ($mime === 'application/pdf') {
                // D4: page-selective extraction - born-digital text is kept
                // wherever a page's own text layer is usable; OCR is invoked
                // only as a bounded fallback for the pages that need it, per
                // Codex's ruling. See KnowledgeDocumentExtractor's own doc
                // comment for the bounds enforced here.
                $extraction = $this->documentExtractor->extractPdf($path);
                $pages = $extraction['pages'];
                $method = $extraction['summary_method'];
                $documentWarnings = $extraction['warnings'];
                $text = implode("\n\n", array_map(
                    fn (PageExtraction $p) => $p->text,
                    array_values(array_filter($pages, fn (PageExtraction $p) => $p->hasRetrievableText())),
                ));
                $confidence = $this->summaryConfidence($method, $pages);
            } elseif (in_array($mime, self::IMAGE_MIMES, true)) {
                // A directly-uploaded image is a single scanned sheet with no
                // text layer by definition - straight to OCR, one page.
                $page = $this->documentExtractor->extractImage($path);
                $pages = [$page];
                $text = $page->text;
                $method = $page->hasRetrievableText() ? 'ocr' : 'failed';
                $confidence = $page->confidence;
            } else {
                $text = (string) file_get_contents($path);
                $method = 'plain-text';
            }
        }

        $storagePath = 'knowledge/'.($scan === 'clean' ? 'sealed' : 'quarantine').'/'.$project->tenant_id.'/'.$hash;
        $duplicate = KnowledgeSource::query()->where('project_id', $project->id)->where('sha256', $hash)->first();
        if ($duplicate) {
            return response()->json(['source' => $duplicate->load('versions'), 'replayed' => true,
                'notice' => 'Identical source already exists; the immutable copy was reused.']);
        }
        if ($request->hasFile('file')) {
            Storage::disk('local')->put($storagePath, file_get_contents($request->file('file')->getRealPath()));
        } else {
            Storage::disk('local')->put($storagePath, $text);
        }

        $classification = $this->classifier->classify($data['title'], $text, $data['corpus']);
        // D4/Codex's ruling: TRACE must be able to tell "not found" from
        // "not processed" - coverage_state names, explicitly and
        // machine-readably, whether extraction actually reached every page
        // of the document, rather than letting a bounded-out tail of pages
        // disappear as though they never existed.
        $coverageState = $documentWarnings === [] ? 'complete' : 'partial';
        $versionClassification = $classification + ['coverage_state' => $coverageState, 'extraction_warnings' => $documentWarnings];
        $needsReview = $scan !== 'clean' || mb_strlen(trim($text)) < 40 || $confidence === null || $confidence < 0.85 || $coverageState === 'partial';

        $source = DB::transaction(function () use ($data, $project, $request, $text, $mime, $bytes, $hash, $scan, $storagePath, $method, $confidence, $classification, $versionClassification, $needsReview, $pages) {
            $source = KnowledgeSource::create([
                'tenant_id' => $project->tenant_id, 'project_id' => $project->id, 'public_id' => (string) Str::uuid(),
                'collection' => $data['collection'], 'title' => $data['title'], 'source_type' => $data['source_type'],
                'jurisdiction' => $data['jurisdiction'] ?? $project->state ?? null,
                'discipline' => $classification['discipline'], 'authority_level' => $data['authority_level'],
                'access_classification' => $data['collection'] === 'project' ? 'project_private' : 'tenant_private',
                'verification_status' => 'provisional', 'ingestion_status' => $needsReview ? 'review_required' : 'ready',
                'mime_type' => $mime, 'storage_path' => $storagePath, 'byte_size' => $bytes, 'sha256' => $hash, 'malware_scan_status' => $scan,
                'quarantine_reason' => $scan === 'clean' ? null : 'Upload is quarantined until a configured malware scanner clears it.',
                'uploaded_by' => $request->user()->id,
            ]);
            $version = KnowledgeSourceVersion::create([
                'knowledge_source_id' => $source->id, 'version_number' => 1, 'edition' => $data['edition'] ?? null,
                'revision' => $data['revision'] ?? null, 'effective_from' => $data['effective_from'] ?? null,
                'sha256' => $hash, 'extraction_method' => $method, 'extraction_confidence' => $confidence,
                'parser_version' => 'knowledge-ingest-v1', 'classification' => $versionClassification,
            ]);

            $ordinal = 0;
            if ($pages !== []) {
                // D4: one KnowledgeSourcePage row per processed page - every
                // page, including a failed or bound-skipped one, is recorded
                // for provenance, never silently dropped.
                $sourcePagesByNumber = [];
                foreach ($pages as $page) {
                    /** @var PageExtraction $page */
                    // VIS-1: every deterministic scan-recovery attempt made for
                    // this page is persisted first, append-only, never
                    // overwritten - the winning attempt's id is then recorded
                    // on the page row so a page's own fields stay traceable
                    // back to exactly which attempt produced them.
                    $selectedAttemptId = null;
                    foreach ($page->recoveryAttempts as $attempt) {
                        $row = OcrExtractionAttempt::create([
                            'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                            'knowledge_source_version_id' => $version->id, 'page_number' => $page->pageNumber,
                            'attempt_ordinal' => $attempt['ordinal'], 'label' => $attempt['label'],
                            'transform_sequence' => $attempt['transform_sequence'], 'render_dpi' => $attempt['render_dpi'],
                            'ocr_engine' => $attempt['ocr_engine'], 'ocr_engine_version' => $attempt['ocr_engine_version'],
                            'mean_confidence' => $attempt['mean_confidence'], 'has_structural_defect' => $attempt['has_structural_defect'],
                            'reliability' => $attempt['reliability'], 'image_sha256' => $attempt['image_sha256'],
                            'image_width' => $attempt['image_width'], 'image_height' => $attempt['image_height'],
                            'runtime_ms' => $attempt['runtime_ms'], 'selected' => $attempt['selected'],
                        ]);
                        if ($attempt['selected']) {
                            $selectedAttemptId = $row->id;
                        }
                    }

                    $sourcePagesByNumber[$page->pageNumber] = KnowledgeSourcePage::create([
                        'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                        'knowledge_source_version_id' => $version->id, 'page_number' => $page->pageNumber,
                        'text_layer_present' => $page->method === 'born_digital',
                        'extraction_method' => $page->method, 'extraction_confidence' => $page->confidence,
                        'ocr_engine' => $page->ocrEngine, 'ocr_engine_version' => $page->ocrEngineVersion,
                        'render_dpi' => $page->renderDpi, 'ocr_extraction_attempt_id' => $selectedAttemptId,
                        'sheet_ref' => $page->sheetRef,
                        'sheet_detection_status' => $page->sheetDetectionStatus,
                        'sheet_detection_confidence' => $page->sheetDetectionConfidence,
                        'warnings' => $page->warnings,
                        'has_structural_defect' => $page->hasStructuralDefect,
                        'structural_findings' => $page->structuralFindings === [] ? null : $page->structuralFindings,
                    ]);
                }

                // Per Codex's ruling: extraction is page-granular, chunking is
                // semantic-granular. Adjacent born-digital pages are stitched
                // into one continuous stream before chunking, so a sentence,
                // an exception clause, or a table that straddles a page break
                // is preserved as one passage rather than hard-cut at every
                // page boundary. OCR pages are never stitched (v1: only
                // reliable born-digital continuation is stitched) and remain
                // one passage per page, as D3's boundary rules assume a real
                // text stream, which a drawing sheet's OCR transcription is
                // not.
                $count = count($pages);
                $i = 0;
                while ($i < $count) {
                    $page = $pages[$i];
                    /** @var PageExtraction $page */
                    if (! $page->hasRetrievableText()) {
                        $i++;

                        continue;
                    }

                    if ($page->method !== 'born_digital') {
                        // 'ocr': one passage for the whole page, deliberately
                        // never sub-chunked or stitched to a neighbor.
                        $ordinal++;
                        KnowledgePassage::create([
                            'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                            'knowledge_source_version_id' => $version->id,
                            'source_page_id' => $sourcePagesByNumber[$page->pageNumber]->id,
                            'ordinal' => $ordinal, 'page_from' => $page->pageNumber, 'page_to' => $page->pageNumber,
                            'body' => $page->text, 'body_sha256' => hash('sha256', $page->text),
                            'classification' => $classification + ['chunking_version' => 'ocr-page-v1'],
                            'section_ref' => null, 'boundary_rule' => 'ocr_page',
                            'sheet_ref' => $page->sheetRef, 'coordinates' => $page->coordinates,
                        ]);
                        $i++;

                        continue;
                    }

                    // Gather the contiguous run of adjacent, retrievable
                    // born-digital pages starting here.
                    $run = [$page];
                    $j = $i + 1;
                    while ($j < $count
                        && $pages[$j]->method === 'born_digital'
                        && $pages[$j]->hasRetrievableText()
                        && $pages[$j]->pageNumber === $pages[$j - 1]->pageNumber + 1
                    ) {
                        $run[] = $pages[$j];
                        $j++;
                    }

                    $runInput = array_map(fn (PageExtraction $p) => ['page_number' => $p->pageNumber, 'text' => $p->text], $run);
                    foreach ($this->chunker->chunkPages($runInput) as $chunk) {
                        $ordinal++;
                        $spansOnePage = $chunk['page_from'] === $chunk['page_to'];
                        KnowledgePassage::create([
                            'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                            'knowledge_source_version_id' => $version->id,
                            // Null, not a guess, when a passage spans more than
                            // one page - page_from/page_to are the authoritative
                            // locator for a multi-page passage; source_page_id
                            // only names a single page when the passage truly
                            // lives on exactly one.
                            'source_page_id' => $spansOnePage ? $sourcePagesByNumber[$chunk['page_from']]->id : null,
                            'ordinal' => $ordinal, 'page_from' => $chunk['page_from'], 'page_to' => $chunk['page_to'],
                            'body' => $chunk['body'], 'body_sha256' => hash('sha256', $chunk['body']),
                            'classification' => $classification + ['chunking_version' => PassageChunker::VERSION],
                            'section_ref' => $chunk['section_ref'], 'boundary_rule' => $chunk['boundary_rule'],
                            'sheet_ref' => null, 'coordinates' => null,
                        ]);
                    }

                    $i = $j;
                }
            } elseif ($scan === 'clean' && mb_strlen(trim($text)) >= 40) {
                foreach ($this->chunker->chunk($text) as $chunk) {
                    $ordinal++;
                    KnowledgePassage::create([
                        'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                        'knowledge_source_version_id' => $version->id, 'ordinal' => $ordinal, 'body' => $chunk['body'],
                        'body_sha256' => hash('sha256', $chunk['body']),
                        'classification' => $classification + ['chunking_version' => PassageChunker::VERSION],
                        'section_ref' => $chunk['section_ref'], 'boundary_rule' => $chunk['boundary_rule'],
                    ]);
                }
            }
            $this->event($source, 'ingested', null, 'provisional', $request->user()->id, $needsReview ? 'Human review required before retrieval.' : null);

            return $source;
        });

        return response()->json(['source' => $source->load('versions'), 'retrievable' => ! $needsReview,
            'notice' => $needsReview ? 'Provisional source queued for human review; AI cannot retrieve it.' : 'Source indexed provisionally; a steward must verify it before AI retrieval.'], 201);
    }

    public function verify(Request $request, KnowledgeSource $source)
    {
        $this->assertSteward($request, $source);

        // A knowledge-steward decision is an attestation, not a click. Two rules are
        // enforced here because an evidence product that gets them wrong is worse than
        // no product at all:
        //   1. The reason is written by the steward. It is never defaulted, because a
        //      canned reason in the ledger asserts that a person reviewed something
        //      when the record cannot show that they did.
        //   2. Promotion is reversible. A mistaken verification must be correctable
        //      without falsely rejecting a legitimate document; 'return_to_provisional'
        //      appends the correction rather than erasing the earlier event.
        $data = $request->validate([
            'action' => 'required|in:verify,adopt,reject,return_to_provisional',
            'reason' => 'required|string|min:12|max:2000',
        ]);
        abort_if($source->malware_scan_status !== 'clean' || $source->ingestion_status === 'quarantined', 422, 'A quarantined source cannot be verified.');

        $from = $source->verification_status;
        if ($data['action'] === 'return_to_provisional') {
            abort_if($from === 'provisional', 409, 'This source is already provisional; there is nothing to return.');
            $source->update(['verification_status' => 'provisional', 'ingestion_status' => 'review_required',
                'verified_by' => null, 'verified_at' => null]);
            $this->event($source, 'return_to_provisional', $from, 'provisional', $request->user()->id, $data['reason']);

            // Withdrawing the standing verification, if one exists. A retraction
            // is not a better answer replacing a worse one - it says the earlier
            // assertion should not have been made and nothing takes its place.
            $withdrawn = null;
            foreach (GovernedDetermination::standingFor('knowledge_verification', $source->id) as $standing) {
                $withdrawn = GovernedDetermination::withdraw(
                    $request->user(), $this->grantFor($request, $source), (int) $standing['id'], $data['reason'],
                );
            }

            return response()->json(['source' => $source->fresh(), 'withdrawal_determination_id' => $withdrawn,
                'notice' => 'Returned to provisional and withdrawn from retrieval. The earlier decision remains in the ledger, '
                    .($withdrawn === null
                        ? 'and no standing determination was found to withdraw.'
                        : 'and the determination that promoted it is now recorded as withdrawn rather than removed.')]);
        }

        // A source with no extracted passages retrieves nothing. Promoting one puts a
        // 'verified' badge on a document TRACE can never cite, and in the library it is
        // indistinguishable from a source that is genuinely available. Refuse it, and
        // say what is actually wrong (usually a scanned PDF with no text layer).
        if ($data['action'] !== 'reject') {
            $versionIds = KnowledgeSourceVersion::query()->where('knowledge_source_id', $source->id)->pluck('id');
            $passages = KnowledgePassage::query()->whereIn('knowledge_source_version_id', $versionIds)->count();
            abort_if($passages === 0, 422, 'No text was extracted from this source, so nothing in it can ever be cited. It is most likely a scanned image with no text layer. Re-upload a text-bearing copy rather than verifying an empty record.');
        }

        $to = ['verify' => 'verified', 'adopt' => 'adopted', 'reject' => 'rejected'][$data['action']];
        $source->update(['verification_status' => $to, 'ingestion_status' => $to === 'rejected' ? 'rejected' : 'ready',
            'verified_by' => $request->user()->id, 'verified_at' => now()]);
        $this->event($source, $data['action'], $from, $to, $request->user()->id, $data['reason']);

        // The determination itself, in the one place every act of this kind
        // lands. Promoting a source changes what TRACE may treat as
        // authoritative, which is precisely the class of human act that has to
        // be reviewable and reversible rather than becoming machine truth
        // silently and permanently.
        $determination = GovernedDetermination::record(
            actor: $request->user(),
            grant: $this->grantFor($request, $source),
            type: 'knowledge_verification',
            subjectType: 'knowledge_verification',
            subjectId: $source->id,
            reason: $data['reason'],
            priorValue: $from,
            proposedValue: $to,
            supportingSourceIds: [$source->id],
            // Promotion to governing authority does not stand on one person.
            reviewRequirement: $to === 'verified'
                ? GovernedDetermination::REVIEW_SECOND_PERSON
                : GovernedDetermination::REVIEW_NONE,
        );

        return response()->json(['source' => $source->fresh(), 'determination_id' => $determination,
            'notice' => $to === 'verified'
                ? 'Review appended; original source and prior events remain unchanged. This promotion is recorded as a determination awaiting a second person - it is in force now, and it is visible as unreviewed until somebody else confirms it.'
                : 'Review appended; original source and prior events remain unchanged.']);
    }

    public function show(Request $request, KnowledgeSource $source)
    {
        $this->access->authorize($request->user(), (int) $source->project_id, 'documents.view');

        return response()->json(['source' => $source->load('versions.passages')]);
    }

    public function content(Request $request, KnowledgeSource $source)
    {
        $this->access->authorize($request->user(), (int) $source->project_id, 'documents.view');
        abort_unless($source->malware_scan_status === 'clean', 423, 'Quarantined content cannot be opened.');
        abort_unless(Storage::disk('local')->exists($source->storage_path), 404, 'Sealed source bytes are unavailable.');

        return Storage::disk('local')->download($source->storage_path, $source->title, ['Content-Type' => $source->mime_type ?: 'application/octet-stream',
            'X-Content-Type-Options' => 'nosniff', 'Content-Security-Policy' => "default-src 'none'; sandbox"]);
    }

    public function relate(Request $request, KnowledgeSource $source)
    {
        $this->assertSteward($request, $source);
        $data = $request->validate([
            'to_source_id' => 'required|integer',
            'relationship' => 'required|in:supersedes,amends,conflicts_with,interprets,derived_from',
            // WHICH PART. Omitting scopes still means the whole document, which
            // is what every edge recorded before this asserted - so an existing
            // workflow keeps working and does not silently change meaning.
            'scopes' => 'nullable|array|max:100',
            'scopes.*.scope_type' => 'required|in:document,section,clause,passage_range,sheet,detail,schedule',
            'scopes.*.relation' => 'required|in:replace,delete,supplement,clarify',
            'scopes.*.label_claimed' => 'nullable|string|max:160',
            'scopes.*.target_section_ref' => 'nullable|string|max:160',
            'scopes.*.target_sheet_ref' => 'nullable|string|max:96',
            'scopes.*.start_passage_id' => 'nullable|integer',
            'scopes.*.end_passage_id' => 'nullable|integer',
            'scopes.*.notes' => 'nullable|string|max:1000',
        ]);
        $to = KnowledgeSource::query()->where('project_id', $source->project_id)->findOrFail($data['to_source_id']);
        $fromVersion = $source->versions()->latest('version_number')->firstOrFail();
        $toVersion = $to->versions()->latest('version_number')->firstOrFail();
        $id = DB::table('knowledge_source_edges')->insertGetId(['tenant_id' => $source->tenant_id, 'from_version_id' => $fromVersion->id,
            'to_version_id' => $toVersion->id, 'relationship' => $data['relationship'], 'status' => 'confirmed',
            'confirmed_by' => $request->user()->id, 'confirmed_at' => now(), 'created_at' => now(), 'updated_at' => now()]);
        $scopes = [];
        foreach ($data['scopes'] ?? [] as $scope) {
            $locator = $scope['scope_type'] === 'passage_range' ? 'passage_range'
                : (in_array($scope['scope_type'], ['sheet', 'detail'], true) ? 'sheet_ref' : 'section_ref');

            // A scope has to say WHERE. Without a locator it is a claim that
            // something changed with no way to tell what, which is worse than
            // no scope at all - the overlay would refuse on it forever.
            $located = match ($locator) {
                'passage_range' => ! empty($scope['start_passage_id']),
                'sheet_ref' => ! empty($scope['target_sheet_ref']),
                default => ! empty($scope['target_section_ref']),
            };
            abort_unless($located || $scope['scope_type'] === 'document', 422,
                'A scoped modification must say which part it reaches. Give the section, the sheet, or the passage range.');

            // Passage ranges are resolved through this tenant's passages, so an
            // id from anywhere else simply does not exist.
            foreach (['start_passage_id', 'end_passage_id'] as $key) {
                if (! empty($scope[$key])) {
                    KnowledgePassage::query()->findOrFail($scope[$key]);
                }
            }

            $scopes[] = DB::table('supersession_scopes')->insertGetId([
                'tenant_id' => $source->tenant_id,
                'knowledge_source_edge_id' => $id,
                'scope_type' => $scope['scope_type'],
                'relation' => $scope['relation'],
                'label_claimed' => $scope['label_claimed'] ?? null,
                'locator_method' => $locator,
                'target_section_ref' => $scope['target_section_ref'] ?? null,
                'target_sheet_ref' => $scope['target_sheet_ref'] ?? null,
                'start_passage_id' => $scope['start_passage_id'] ?? null,
                'end_passage_id' => $scope['end_passage_id'] ?? $scope['start_passage_id'] ?? null,
                // Confirmed, because a named steward is entering it by hand right
                // now. A scope TRACE proposes from wording is written elsewhere
                // and arrives as 'proposed'.
                'status' => 'confirmed',
                'confirmed_by' => $request->user()->id,
                'confirmed_at' => now(),
                'notes' => $scope['notes'] ?? null,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        $this->event($source, 'relationship_confirmed', $source->verification_status, $source->verification_status,
            $request->user()->id, $data['relationship'].' source '.$to->public_id
                .($scopes === [] ? ' (whole document)' : ' ('.count($scopes).' scoped modification(s))'));

        return response()->json([
            'edge_id' => $id, 'scope_ids' => $scopes,
            'notice' => $scopes === []
                ? 'Relationship appended as a WHOLE-DOCUMENT modification; neither source was overwritten. If the later document changed only part of it, record the scopes - otherwise every untouched provision loses its authority.'
                : 'Relationship appended with '.count($scopes).' scoped modification(s). Provisions outside those scopes remain operative.',
        ], 201);
    }

    private function grantFor(Request $request, KnowledgeSource $source)
    {
        return $this->access->authorize($request->user(), (int) $source->project_id, 'knowledge.verify', write: true);
    }

    private function assertSteward(Request $request, KnowledgeSource $source): void
    {
        $grant = $this->access->authorize($request->user(), (int) $source->project_id, 'knowledge.verify', write: true);
        abort_unless($request->user()->isPlatformAdmin() || $grant->allows('knowledge.verify'), 403, 'A named knowledge steward must authorize this promotion.');
    }

    // scan() moved to SecureUploadGate::scan() - one gateway, bounded by a
    // timeout, shared with DocumentLibraryController rather than each
    // maintaining its own unbounded proc_open.

    /**
     * SEC-5: this is the one place in the codebase that hands an uploaded
     * file's bytes to an external parser (`pdftotext`) rather than merely
     * hashing or scanning them. An unbounded proc_open here was a crafted-PDF
     * denial-of-service: a PDF built to make pdftotext hang would have hung
     * this request, and eventually the worker, indefinitely. Bounded via
     * BoundedProcess; a timeout is treated the same as a failed extraction -
     * empty text, never a silent partial read presented as the whole
     * document.
     */
    private function extractPdf(string $path): string
    {
        $result = BoundedProcess::run(['pdftotext', '-layout', $path, '-'], 20);
        if ($result['status'] !== BoundedProcess::OK || $result['exitCode'] !== 0) {
            return '';
        }

        return $result['stdout'];
    }

    /**
     * D4/Codex's ruling #1: a single document-level extraction_confidence
     * cannot honestly describe a document that mixes born-digital and OCR
     * pages - per-page confidence lives on knowledge_source_pages instead,
     * and this returns null for exactly that case rather than averaging a
     * number that would describe no part of the actual document.
     *
     * @param  list<PageExtraction>  $pages
     */
    private function summaryConfidence(string $method, array $pages): ?float
    {
        if ($method === 'failed') {
            return 0.0;
        }
        if ($method === 'mixed') {
            return null;
        }
        if ($method === 'born_digital') {
            return 0.75;
        }

        $confidences = array_values(array_filter(array_map(
            fn (PageExtraction $p) => ($p->method === 'ocr' && $p->hasRetrievableText()) ? $p->confidence : null,
            $pages,
        )));

        return $confidences === [] ? null : round(array_sum($confidences) / count($confidences), 4);
    }

    private function event(KnowledgeSource $source, string $action, ?string $from, string $to, ?int $actor, ?string $reason): void
    {
        $previous = DB::table('knowledge_review_events')->where('tenant_id', $source->tenant_id)->where('knowledge_source_id', $source->id)->latest('id')->first();
        $payload = ['tenant_id' => $source->tenant_id, 'knowledge_source_id' => $source->id, 'action' => $action,
            'from_status' => $from, 'to_status' => $to, 'reason' => $reason, 'actor_user_id' => $actor,
            'previous_event_hash' => $previous?->event_hash, 'created_at' => now(), 'updated_at' => now()];
        // Canonicalized. The previous version hashed Carbon instances while the
        // database returns strings, so this ledger's content could never be
        // checked against its own hashes - structurally sound and evidentially
        // inert. The chain walker proved it; this fixes it. Records written
        // before this carry no hash_version and remain linkage-verifiable only.
        $payload['hash_version'] = CanonicalPayload::CURRENT;
        // EV-13: the digest algorithm is recorded beside the encoding version,
        // never implied by it - a future rotation of the digest primitive must
        // not require guessing which one produced an existing row's hash.
        $payload['hash_algorithm'] = DigestAlgorithm::CURRENT;
        $payload['event_hash'] = CanonicalPayload::hash(
            Arr::except($payload, ['hash_version', 'hash_algorithm'])
        );
        DB::table('knowledge_review_events')->insert($payload);

        ChainAnchor::record('Knowledge review events', $source->id,
            DB::table('knowledge_review_events')->where('knowledge_source_id', $source->id)->count(),
            $payload['event_hash']);
    }
}
