<?php

namespace App\Http\Controllers;

use App\Domain\Decisions\EnvelopeBuilder;
use App\Domain\Schedule\ProjectAccess;
use App\Domain\Schedule\ScheduleDispositionService;
use App\Domain\Schedule\ScheduleIngest;
use App\Domain\Schedule\SchedulePresenter;
use App\Domain\Schedule\UnsafeScheduleUpload;
use App\Domain\Schedule\VersionMatcher;
use App\Jobs\RunScheduleAnalysis;
use App\Models\ActivityMappingGroup;
use App\Models\AnalysisRun;
use App\Models\ScheduleActivity;
use App\Models\ScheduleDelta;
use App\Models\ScheduleVersion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ScheduleController
{
    public function __construct(
        private readonly ProjectAccess $access,
        private readonly SchedulePresenter $presenter,
        private readonly EnvelopeBuilder $envelopes,
    ) {}

    public function store(Request $request, ScheduleIngest $ingest)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate([
            'project_id' => 'required|integer',
            'file' => 'required|file|mimes:csv,xlsx,xml|max:'.config('schedule.max_upload_kilobytes'),
            'kind' => 'required|in:preliminary,baseline,update,recovery,revised_baseline,lookahead',
            'label' => 'required|string|max:120',
            'data_date' => 'required|date',
            'submitted_by_org' => 'nullable|string|max:160',
            'narrative_text' => 'nullable|string|max:100000',
            'parent_version_id' => 'nullable|integer',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'schedule.submit', write: true);

        try {
            $version = $ingest->ingest($request->file('file'), $grant, $data);
        } catch (UnsafeScheduleUpload $exception) {
            return response()->json(['message' => $exception->getMessage(), 'status' => 'refused'], $exception->httpStatus);
        }

        return response()->json($this->presenter->version($version, $grant), 201);
    }

    public function index(Request $request)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'schedule.view');
        $versions = ScheduleVersion::query()
            ->where('project_id', $grant->project->id)
            ->with(['sourceFile', 'events'])
            ->orderBy('data_date')
            ->orderBy('id')
            ->get();

        return response()->json([
            'project_id' => $grant->project->id,
            'versions' => $versions->map(fn ($version) => $this->presenter->version($version, $grant)),
        ]);
    }

    public function activities(Request $request, ScheduleVersion $version)
    {
        $this->rejectRoleParameter($request);
        $grant = $this->access->authorize($request->user(), $version->project_id, 'schedule.view');
        $activities = ScheduleActivity::query()
            ->where('schedule_version_id', $version->id)
            ->with(['calendarAssignments.calendar', 'resources'])
            ->orderBy('activity_code')
            ->paginate(min(500, max(25, $request->integer('per_page', 100))));
        $activities->setCollection($activities->getCollection()->map(fn ($activity) => $this->presenter->activity($activity, $grant)));

        return response()->json($activities);
    }

    public function accept(Request $request, ScheduleVersion $version, ScheduleDispositionService $dispositions)
    {
        return $this->disposition($request, $version, $dispositions, 'accepted');
    }

    public function reject(Request $request, ScheduleVersion $version, ScheduleDispositionService $dispositions)
    {
        return $this->disposition($request, $version, $dispositions, 'rejected');
    }

    public function analyze(Request $request)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate([
            'project_id' => 'required|integer',
            'from_version_id' => 'required|integer|different:to_version_id',
            'to_version_id' => 'required|integer',
        ]);
        $idempotencyKey = trim((string) $request->header('Idempotency-Key'));
        if ($idempotencyKey === '' || strlen($idempotencyKey) > 128) {
            return response()->json(['message' => 'A stable Idempotency-Key header (1-128 characters) is required.'], 422);
        }
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'schedule.analyze', write: true);
        $versions = ScheduleVersion::query()
            ->where('project_id', $grant->project->id)
            ->whereIn('id', [(int) $data['from_version_id'], (int) $data['to_version_id']])
            ->get()
            ->keyBy('id');
        abort_unless($versions->count() === 2, 422, 'Both versions must belong to the authorized project.');

        $run = AnalysisRun::firstOrCreate([
            'project_id' => $grant->project->id,
            'idempotency_key' => $idempotencyKey,
        ], [
            'from_version_id' => (int) $data['from_version_id'],
            'to_version_id' => (int) $data['to_version_id'],
            'status' => 'queued',
            'progress_percent' => 0,
            'stage_status' => ['queued' => ['status' => 'completed', 'at' => now()->toIso8601String()]],
            'parser_version' => config('schedule.parser_version'),
            'cpm_engine_version' => config('schedule.cpm_engine_version'),
            'rules_version' => config('schedule.rules_version'),
            'ai_model' => null,
            'ai_prompt_version' => null,
            'source_hashes' => [
                'from' => $versions[(int) $data['from_version_id']]->source_sha256,
                'to' => $versions[(int) $data['to_version_id']]->source_sha256,
            ],
            'authorization_scope' => $grant->auditScope(),
            'assumptions' => [
                'recovery_cost_time_ranges' => 'Not computed in deterministic phase B.',
                'factual_core' => 'Computed without requester role as an input.',
            ],
            'retrieval_times' => ['schedule_versions' => now()->toIso8601String()],
            'queued_by' => $request->user()->id,
        ]);
        if (! $run->wasRecentlyCreated && (
            (int) $run->from_version_id !== (int) $data['from_version_id']
            || (int) $run->to_version_id !== (int) $data['to_version_id']
        )) {
            return response()->json([
                'message' => 'This Idempotency-Key is already bound to a different version pair.',
            ], 409);
        }

        $shouldDispatch = $run->wasRecentlyCreated;
        if (! $shouldDispatch && $run->status === 'failed') {
            $shouldDispatch = AnalysisRun::query()
                ->whereKey($run->id)
                ->where('status', 'failed')
                ->update([
                    'status' => 'queued',
                    'progress_percent' => 0,
                    'error' => null,
                    'cancel_requested_at' => null,
                    'finished_at' => null,
                    'updated_at' => now(),
                ]) === 1;
            $run->refresh();
        }
        if ($shouldDispatch) {
            RunScheduleAnalysis::dispatch($run->id);
        }

        return response()->json($this->presenter->analysis($run->fresh(), $grant), $shouldDispatch ? 202 : 200);
    }

    public function analysisHistory(Request $request)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate([
            'project_id' => 'required|integer',
            'from_version_id' => 'required|integer|different:to_version_id',
            'to_version_id' => 'required|integer',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'schedule.view');
        $runs = AnalysisRun::query()
            ->where('project_id', $grant->project->id)
            ->where('from_version_id', (int) $data['from_version_id'])
            ->where('to_version_id', (int) $data['to_version_id'])
            ->orderBy('id')
            ->get();

        $history = [];
        $previousId = null;
        foreach ($runs as $run) {
            $row = $this->presenter->analysisHistoryRow($run, $previousId);
            if ($previousId !== null && isset($history[count($history) - 1])) {
                $history[count($history) - 1]['superseded'] = true;
                $history[count($history) - 1]['superseded_by_run_id'] = $run->id;
            }
            $history[] = $row;
            $previousId = $run->id;
        }

        return response()->json([
            'project_id' => $grant->project->id,
            'from_version_id' => (int) $data['from_version_id'],
            'to_version_id' => (int) $data['to_version_id'],
            'runs' => array_reverse($history),
        ]);
    }

    public function analysis(Request $request, AnalysisRun $analysis)
    {
        $this->rejectRoleParameter($request);
        $grant = $this->access->authorize($request->user(), $analysis->project_id, 'schedule.view');

        return response()->json($this->presenter->analysis($analysis, $grant));
    }

    public function cancel(Request $request, AnalysisRun $analysis)
    {
        $this->rejectRoleParameter($request);
        $grant = $this->access->authorize($request->user(), $analysis->project_id, 'schedule.analyze', write: true);
        if (in_array($analysis->status, ['completed', 'cancelled'], true)) {
            return response()->json($this->presenter->analysis($analysis, $grant), 409);
        }
        $analysis->forceFill(['status' => 'cancel_requested', 'cancel_requested_at' => now()])->save();

        return response()->json($this->presenter->analysis($analysis->fresh(), $grant), 202);
    }

    public function deltas(Request $request)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate([
            'project_id' => 'required|integer',
            'from_version_id' => 'required|integer',
            'to_version_id' => 'required|integer',
            'critical_only' => 'nullable|boolean',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'schedule.view');
        $run = AnalysisRun::query()
            ->where('project_id', $grant->project->id)
            ->where('from_version_id', (int) $data['from_version_id'])
            ->where('to_version_id', (int) $data['to_version_id'])
            ->where('status', 'completed')
            ->latest('id')
            ->first();
        if ($run === null) {
            return response()->json(['message' => 'No completed deterministic analysis exists for this version pair.'], 404);
        }
        $query = ScheduleDelta::query()->where('analysis_run_id', $run->id);
        if ($request->boolean('critical_only')) {
            $criticalIds = DB::table('analysis_activity_metrics')
                ->where('analysis_run_id', $run->id)
                ->where('is_critical', true)
                ->pluck('schedule_activity_id');
            $query->where(function ($where) use ($criticalIds) {
                $where->whereIn('from_activity_id', $criticalIds)->orWhereIn('to_activity_id', $criticalIds);
            });
        }

        return response()->json([
            'analysis_id' => $run->id,
            'deltas' => $query->orderByRaw(SchedulePresenter::NORMALIZED_DAYS_ORDER)->get()->map(fn ($delta) => $this->presenter->delta($delta, $grant)),
        ]);
    }

    public function confirmMapping(Request $request, VersionMatcher $matcher)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate([
            'map_id' => 'required|integer',
            'correct_to_activity_ids' => 'nullable|array|min:1|max:20',
            'correct_to_activity_ids.*' => 'integer',
        ]);
        $group = ActivityMappingGroup::query()->findOrFail((int) $data['map_id']);
        $this->access->authorize($request->user(), $group->project_id, 'schedule.match', write: true);
        $group = $matcher->confirm($group, $request->user()->id, $data['correct_to_activity_ids'] ?? null);

        return response()->json($group);
    }

    private function disposition(Request $request, ScheduleVersion $version, ScheduleDispositionService $dispositions, string $status)
    {
        $this->rejectRoleParameter($request);
        $data = $request->validate(['note' => 'nullable|string|max:4000']);
        $grant = $this->access->authorize($request->user(), $version->project_id, 'schedule.review', write: true);
        // Compatibility endpoint only: apply the SAME decision-envelope readiness rules.
        // The primary UI previews /api/decisions/schedule/{id}/envelope and confirms there.
        $envelope = $this->envelopes->forScheduleDisposition($version, $grant, $request->user(), $status);
        if (! $envelope->isReady()) {
            return response()->json([
                'message' => $envelope->blockedReason ?: 'This schedule disposition is not ready to be authorised.',
                'state' => $envelope->state,
                'envelope' => $envelope->toArray(),
            ], 409);
        }
        $event = $dispositions->append(
            version: $version,
            eventType: 'schedule_version.review_disposition',
            disposition: $status,
            payload: ['note' => $data['note'] ?? null, 'authorization_scope' => $grant->auditScope()],
            actorId: $request->user()->id,
        );

        return response()->json([
            'version' => $this->presenter->version($version->fresh(['events', 'sourceFile']), $grant),
            'event_id' => $event->id,
            'event_hash' => $event->event_hash,
        ]);
    }

    private function rejectRoleParameter(Request $request): void
    {
        abort_if($request->query->has('role') || $request->request->has('role'), 422, 'Role is derived from the authenticated project grant and cannot be supplied by the caller.');
    }
}
