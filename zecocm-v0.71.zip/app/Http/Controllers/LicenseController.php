<?php

namespace App\Http\Controllers;

use App\Domain\Identity\PasswordSetupInvitation;
use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Domain\Licensing\LicensingRefused;
use App\Models\CapabilityGrantEvent;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Capability licensing.
 *
 * Two grantors exist:
 *  - the ZecoCM platform admin, who licenses any account;
 *  - an account owner (whoever bought the system), who licenses the counterparty
 *    portals it sponsors - never beyond what it holds itself.
 */
class LicenseController
{
    public function __construct(private readonly CapabilityLicense $license) {}

    /** The catalogue: every capability, its tier, and whether it is actually built. */
    public function catalog()
    {
        $out = [];
        foreach (CapabilityCatalog::all() as $key => $meta) {
            $out[] = [
                'capability' => $key,
                'label' => $meta['label'],
                'tier' => $meta['tier'],
                'operational' => $meta['operational'],
                'group' => $meta['group'] ?? 'Other',
                'metered' => (bool) ($meta['metered'] ?? false),
                'summary' => $meta['summary'] ?? null,
            ];
        }

        return response()->json(['capabilities' => $out, 'sponsor_roles' => Tenant::sponsorRoles()]);
    }

    /**
     * The authenticated user's OWN licence book - what drives their own nav.
     *
     * Found live: ZAPI.applyLicensedNav() (the client-side "only show nav items
     * you're licensed for" filter) called GET /licensing/customers/{tenantId}
     * with the caller's own tenant id, but show()'s authorizeGrantor() only
     * permits the platform admin or a SPONSOR viewing a tenant it sponsors -
     * never a tenant viewing itself. Every ordinary customer got a 403, the
     * client's .then() saw !res.ok and returned early, and the nav filter
     * silently never applied - every capability-gated nav item stayed at its
     * unfiltered default visibility regardless of actual license state. The
     * underlying API endpoints still enforce licensing separately (this was
     * never a security hole), but the nav itself lied about what was actually
     * usable. This is a read of your own state, not a grantor action, so it
     * needs no grantor check - only that you are authenticated.
     */
    public function mine(Request $request)
    {
        $tenantId = $request->user()->tenant_id;
        abort_if($tenantId === null, 404, 'No tenant account is associated with this session.');
        $tenant = Tenant::findOrFail($tenantId);

        return response()->json(['licenses' => $this->license->book($tenant)]);
    }

    /** The licence book for one account, with live states and remaining days. */
    public function show(Request $request, Tenant $tenant)
    {
        $this->authorizeGrantor($request, $tenant);

        return response()->json([
            'tenant' => [
                'id' => $tenant->id,
                'name' => $tenant->name,
                'sponsor_role' => $tenant->sponsor_role,
                'is_account_owner' => $tenant->is_account_owner,
                'parent_tenant_id' => $tenant->parent_tenant_id,
                'branch_name' => $tenant->branch_name,
            ],
            'licenses' => $this->license->book($tenant),
        ]);
    }

    /** Grant or extend one capability for a set period. */
    public function grant(Request $request, Tenant $tenant)
    {
        $grantor = $this->authorizeGrantor($request, $tenant);

        $data = $request->validate([
            'capability' => 'required|string|max:64',
            'starts_at' => 'nullable|date',
            'ends_at' => 'nullable|date|after:starts_at',
            'duration_days' => 'nullable|integer|min:1|max:3650',
            'plan_reference' => 'nullable|string|max:120',
            'reason' => 'nullable|string|max:255',
            'usage_limit' => 'nullable|integer|min:1',
            'model_tier' => 'nullable|in:standard,premium,private',
            'allowed_tasks' => 'nullable|array',
            'allowed_tasks.*' => 'in:answer,draft,classify,compare,educate',
            'budget_limit_micros' => 'nullable|integer|min:1',
        ]);

        $startsAt = isset($data['starts_at']) ? new \DateTimeImmutable($data['starts_at']) : new \DateTimeImmutable;
        $endsAt = isset($data['ends_at']) ? new \DateTimeImmutable($data['ends_at']) : null;
        // "ten days, a month, two months" - a duration is the natural way to say it.
        if ($endsAt === null && ! empty($data['duration_days'])) {
            $endsAt = $startsAt->modify('+'.(int) $data['duration_days'].' days');
        }

        try {
            $grant = $this->license->grant(
                tenant: $tenant,
                capabilityKey: $data['capability'],
                startsAt: $startsAt,
                endsAt: $endsAt,
                planReference: $data['plan_reference'] ?? null,
                actorUserId: $request->user()->id,
                grantorTenant: $grantor,
                reason: $data['reason'] ?? null,
                usageLimit: $data['usage_limit'] ?? null,
                modelTier: $data['model_tier'] ?? null,
                allowedTasks: $data['allowed_tasks'] ?? null,
                budgetLimitMicros: $data['budget_limit_micros'] ?? null,
            );
        } catch (LicensingRefused $e) {
            return response()->json(['message' => $e->getMessage()], $e->httpStatus);
        }

        return response()->json([
            'granted' => $this->license->state($tenant, $grant->capability_key)->toArray(),
        ], 201);
    }

    /** Switch a licence off, back on, or end it entirely. */
    public function update(Request $request, Tenant $tenant)
    {
        $this->authorizeGrantor($request, $tenant);
        $data = $request->validate([
            'capability' => 'required|string|max:64',
            'action' => 'required|in:suspend,resume,revoke',
            'reason' => 'nullable|string|max:255',
        ]);

        try {
            match ($data['action']) {
                'suspend' => $this->license->suspend($tenant, $data['capability'], $request->user()->id, $data['reason'] ?? null),
                'resume' => $this->license->resume($tenant, $data['capability'], $request->user()->id, $data['reason'] ?? null),
                'revoke' => $this->license->revoke($tenant, $data['capability'], $request->user()->id, $data['reason'] ?? null),
            };
        } catch (LicensingRefused $e) {
            return response()->json(['message' => $e->getMessage()], $e->httpStatus);
        }

        return response()->json(['license' => $this->license->state($tenant, $data['capability'])->toArray()]);
    }

    /** The append-only licence history for one account. */
    public function history(Request $request, Tenant $tenant)
    {
        $this->authorizeGrantor($request, $tenant);

        return response()->json([
            'events' => CapabilityGrantEvent::query()
                ->where('tenant_id', $tenant->id)
                ->orderByDesc('id')->limit(200)
                ->get(['capability_key', 'action', 'effective_from', 'effective_until', 'actor_user_id', 'actor_tenant_id', 'reason', 'before', 'after', 'created_at']),
        ]);
    }

    /**
     * An account owner creates a counterparty portal beneath itself.
     * A City can create a CM portal; a contractor can create a City portal; a CM
     * can create both. The buyer decides - ZecoCM does not impose the chain.
     */
    public function createPortal(Request $request, Tenant $tenant)
    {
        $user = $request->user();
        $isPlatform = $user->isPlatformAdmin();
        abort_unless($isPlatform || ((int) $user->tenant_id === (int) $tenant->id && $tenant->is_account_owner), 403,
            'Only the account owner may create portals beneath their account.');

        $data = $request->validate([
            'name' => 'required|string|max:128',
            'sponsor_role' => 'required|string|max:32',
            'branch_name' => 'nullable|string|max:120',
            'admin_name' => 'required|string|max:128',
            'admin_email' => 'required|email|unique:users,email',
            'capabilities' => 'array',
            'capabilities.*' => 'string|max:64',
            'duration_days' => 'nullable|integer|min:1|max:3650',
        ]);

        $assignable = $tenant->assignableRoles();
        abort_unless(array_key_exists($data['sponsor_role'], $assignable), 422,
            'Your account cannot create a portal for that seat. Assignable: '.implode(', ', array_keys($assignable)).'.');

        $endsAt = ! empty($data['duration_days'])
            ? (new \DateTimeImmutable)->modify('+'.(int) $data['duration_days'].' days')
            : null;

        [$portal, $admin, $granted, $refused] = DB::transaction(function () use ($data, $tenant, $user, $isPlatform, $assignable, $endsAt) {
            $portal = Tenant::create([
                'name' => $data['name'],
                'type' => $assignable[$data['sponsor_role']],
                'sponsor_role' => $data['sponsor_role'],
                'parent_tenant_id' => $tenant->id,
                'branch_name' => $data['branch_name'] ?? null,
                'is_account_owner' => false,
                'entitlements' => [],
                'status' => 'active',
            ]);

            $admin = User::create([
                'tenant_id' => $portal->id,
                'name' => $data['admin_name'],
                'email' => $data['admin_email'],
                'password' => PasswordSetupInvitation::placeholderHash(),
            ]);

            $granted = [];
            $refused = [];
            foreach ($data['capabilities'] ?? [] as $key) {
                try {
                    $this->license->grant(
                        tenant: $portal, capabilityKey: $key, startsAt: new \DateTimeImmutable, endsAt: $endsAt,
                        planReference: 'Delegated by '.$tenant->name, actorUserId: $user->id,
                        grantorTenant: $isPlatform ? null : $tenant, reason: 'Portal created by sponsor',
                    );
                    $granted[] = $key;
                } catch (LicensingRefused $e) {
                    $refused[] = ['capability' => $key, 'reason' => $e->getMessage()];
                }
            }

            return [$portal, $admin, $granted, $refused];
        });

        return response()->json([
            'portal' => $portal->only(['id', 'name', 'sponsor_role', 'parent_tenant_id', 'branch_name']),
            'password_setup_url' => PasswordSetupInvitation::url($admin),
            'granted' => $granted,
            'refused' => $refused,
        ], 201);
    }

    /** Platform admin, or the sponsoring account owner. Everyone else: 403. */
    private function authorizeGrantor(Request $request, Tenant $tenant): ?Tenant
    {
        $user = $request->user();
        if ($user->isPlatformAdmin()) {
            return null; // platform grants directly
        }
        $own = $user->tenant_id ? Tenant::find($user->tenant_id) : null;
        abort_unless(
            $own !== null && $own->is_account_owner && (int) $tenant->parent_tenant_id === (int) $own->id,
            403, 'Only the platform administrator or the sponsoring account owner may license this account.'
        );

        return $own;
    }
}
