<?php

namespace App\Http\Controllers;

use App\Domain\Integrations\ProviderRegistry;
use App\Domain\Schedule\ProjectAccess;
use App\Models\IntegrationConnection;
use Illuminate\Http\Request;

class IntegrationController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'plans.view');
        $connections = IntegrationConnection::query()->where('project_id', $grant->project->id)->get()->keyBy('provider');

        return response()->json([
            'providers' => collect(ProviderRegistry::all())->map(function ($definition, $key) use ($connections) {
                $status = ProviderRegistry::publicStatus($key, $definition);
                $connection = $connections->get($key);
                if ($connection !== null) {
                    $status['connection_state'] = $connection->status;
                    $status['connection'] = [
                        'id' => $connection->id,
                        'external_account_name' => $connection->external_account_name,
                        'last_synced_at' => optional($connection->last_synced_at)->toIso8601String(),
                        'has_error' => $connection->last_error !== null,
                    ];
                }

                return $status;
            })->values(),
            'permissions' => ['manage' => $grant->allows('integrations.manage')],
            'notice' => 'Ready means application configuration is present. Connected means a customer completed vendor authorization. ZecoCM never reports either state from a placeholder.',
        ]);
    }
}
