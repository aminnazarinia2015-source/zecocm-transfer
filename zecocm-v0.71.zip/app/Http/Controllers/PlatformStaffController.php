<?php

namespace App\Http\Controllers;

use App\Domain\Identity\PasswordSetupInvitation;
use App\Models\User;
use Illuminate\Http\Request;

/**
 * "Staff & permissions" was a static, hardcoded "roadmap" stub with zero
 * backing route - this is the real thing. Deliberately admin-only: a
 * platform_role of 'admin' reaches every tenant's data (see ProjectAccess::
 * authorize's isPlatformStaff() branch), so who can grant that is one of the
 * few places in this codebase where a mistake is not scoped to one tenant.
 */
class PlatformStaffController
{
    private function requireAdmin(Request $request): void
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only a platform admin may manage platform staff.');
    }

    public function index(Request $request)
    {
        $this->requireAdmin($request);

        $staff = User::query()->whereNotNull('platform_role')->orderBy('name')->get();

        return response()->json(['staff' => $staff->map(fn (User $u) => $this->digest($u))]);
    }

    public function store(Request $request)
    {
        $this->requireAdmin($request);

        $data = $request->validate([
            'name' => 'required|string|max:128',
            'email' => 'required|email|unique:users,email',
            'platform_role' => 'required|in:admin,technician',
            'platform_permissions' => 'array',
        ]);

        $user = User::create([
            'tenant_id' => null, // null = platform staff, reaches across every tenant per its role
            'name' => $data['name'], 'email' => $data['email'], 'password' => PasswordSetupInvitation::placeholderHash(),
            'platform_role' => $data['platform_role'],
            'platform_permissions' => $data['platform_role'] === 'technician' ? ($data['platform_permissions'] ?? []) : null,
        ]);

        return response()->json([
            'staff' => $this->digest($user),
            'password_setup_url' => PasswordSetupInvitation::url($user),
        ], 201);
    }

    public function update(Request $request, User $user)
    {
        $this->requireAdmin($request);
        abort_if($user->platform_role === null, 404, 'That account is not platform staff.');

        $data = $request->validate([
            'platform_role' => 'sometimes|required|in:admin,technician',
            'platform_permissions' => 'array',
        ]);
        if (($data['platform_role'] ?? $user->platform_role) !== 'admin' && $user->id === $request->user()->id && $request->user()->isPlatformAdmin()) {
            abort(422, 'You cannot demote your own admin role - have another admin do it.');
        }
        $user->update($data);

        return response()->json($this->digest($user->fresh()));
    }

    public function revoke(Request $request, User $user)
    {
        $this->requireAdmin($request);
        abort_if($user->id === $request->user()->id, 422, 'You cannot revoke your own platform access.');
        abort_if($user->platform_role === null, 404, 'That account is not platform staff.');

        $user->update(['platform_role' => null, 'platform_permissions' => null]);

        return response()->json(['notice' => $user->name.' is no longer platform staff. Their account and tenant history, if any, are unchanged.']);
    }

    private function digest(User $u): array
    {
        return [
            'id' => $u->id, 'name' => $u->name, 'email' => $u->email,
            'platform_role' => $u->platform_role, 'platform_permissions' => $u->platform_permissions ?? [],
        ];
    }
}
