<?php

namespace App\Http\Controllers;

use App\Domain\Overview\ProjectOverviewBuilder;
use App\Domain\Schedule\ProjectAccess;
use Illuminate\Http\Request;

/**
 * Project overview: percent complete from the accepted schedule of record, and
 * billing status from certified pay applications. See ProjectOverviewBuilder
 * for what each figure means and why an absent record is reported as an
 * unavailable state rather than a zero pretending to be a fact.
 */
class ProjectOverviewController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function show(Request $request, int $project, ProjectOverviewBuilder $builder)
    {
        $grant = $this->access->authorize($request->user(), $project, 'records.view');

        return response()->json($builder->build($grant->project));
    }
}
