<?php

namespace App\Http\Controllers;

use App\Domain\Claims\ClaimClock;
use App\Domain\Schedule\ProjectAccess;
use App\Models\ClaimClockCalculation;
use App\Models\ClaimComplianceEvent;
use App\Models\ClaimRequirement;
use App\Models\ClaimTriggerEvent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * The deadlines that decide whether a valid claim survives.
 *
 * This codebase has shipped modules that worked, were tested, and were reachable
 * by nothing - twice. So the surface goes in with the domain rather than after
 * it.
 *
 * Two things this controller does that are unusual and deliberate.
 *
 * EVERY READ WRITES A CALCULATION. Asking what the deadline is produces a
 * durable record of what was displayed and on what basis, because the question
 * two years from now is "why did the system show 4 September" and a screen that
 * computes on the fly cannot answer it. Only a CHANGED answer is recorded, so
 * refreshing a page ten times does not write ten rows.
 *
 * NOTHING HERE PRONOUNCES A FORFEITURE. A passed preservative deadline produces
 * "potential loss of rights requires review", never "your claim is barred".
 * Whether a right survives turns on facts and law this system does not hold.
 */
class ClaimClockController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'project.view')->project;

        $calendar = $this->calendarFor($project);

        $requirements = ClaimRequirement::query()
            ->where('project_id', $project->id)
            ->with('trigger')
            ->orderByRaw("CASE consequence_class WHEN 'preservative' THEN 0 WHEN 'enforcement' THEN 1 WHEN 'escalation' THEN 2 ELSE 3 END")
            ->limit(500)->get();

        $dependencies = DB::table('claim_requirement_dependencies as d')
            ->join('claim_requirements as r', 'r.id', '=', 'd.depends_on_requirement_id')
            ->where('r.project_id', $project->id)
            ->select('d.claim_requirement_id', 'd.dependency_type', 'r.title as depends_on_title', 'r.id as depends_on_id')
            ->get()->groupBy('claim_requirement_id');

        $satisfied = ClaimComplianceEvent::query()
            ->whereIn('claim_requirement_id', $requirements->pluck('id'))
            ->where('satisfaction', 'satisfied')
            ->pluck('claim_requirement_id')->unique()->flip();

        $rows = $requirements->map(function (ClaimRequirement $requirement) use ($calendar, $dependencies, $satisfied) {
            $gate = ClaimClock::gateState(
                collect($dependencies[$requirement->id] ?? [])->map(fn ($d) => [
                    'depends_on_title' => $d->depends_on_title,
                    'dependency_type' => $d->dependency_type,
                    'satisfied' => $satisfied->has($d->depends_on_id),
                ])->all()
            );

            $result = ClaimClock::calculate(
                $requirement->toArray(),
                $requirement->trigger?->toArray(),
                $calendar,
            );

            // A stage that has not opened has no clock, and showing one would be
            // inventing a deadline out of a sequence position.
            if (! $gate['open']) {
                $result['state'] = ClaimClock::UNRESOLVED_TRIGGER;
                $result['deadline_on'] = null;
                $result['may_alert'] = false;
                $result['message'] = $gate['reason'];
            } else {
                $this->recordCalculation($requirement, $result);
            }

            $met = $satisfied->has($requirement->id);
            $passed = $result['deadline_on'] !== null && $result['deadline_on'] < now()->toDateString();

            return [
                'id' => $requirement->id,
                'title' => $requirement->title,
                'authority' => $requirement->authority_citation,
                'authority_type' => $requirement->authority_type,
                'consequence' => $result['consequence'],
                'gate_open' => $gate['open'],
                'state' => $result['state'],
                'deadline_on' => $result['deadline_on'],
                'earliest_on' => $result['earliest_on'],
                'latest_on' => $result['latest_on'],
                'may_alert' => $result['may_alert'],
                'message' => $result['message'],
                'recipient_rule' => $requirement->recipient_rule,
                'delivery_method_rule' => $requirement->delivery_method_rule,
                'content_requirement_rule' => $requirement->content_requirement_rule,
                'compliance' => $met ? 'satisfied' : 'unresolved',
                // Said only when the deadline has actually passed, and worded so
                // that it can never be quoted as a determination of waiver.
                'after_deadline' => $passed
                    ? ClaimClock::afterDeadline($requirement->toArray(), $result, $met)
                    : null,
            ];
        });

        return response()->json([
            'requirements' => $rows,
            'calendar' => [
                'confirmed' => (bool) ($calendar['confirmed'] ?? false),
                'note' => ($calendar['confirmed'] ?? false)
                    ? 'A project calendar is confirmed, so working-day requirements can be counted.'
                    : 'No confirmed project calendar is recorded. Requirements counted in working days will show as '
                        .'unresolved rather than assume a Monday-to-Friday week.',
            ],
            // Said on the screen rather than in a help page, because this is the
            // sentence somebody will otherwise supply for themselves.
            'disclaimer' => 'ZecoCM reports the state of its own records. It does not determine that any claim is '
                .'barred or preserved - that turns on facts and law outside this system.',
        ]);
    }

    public function storeRequirement(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'requirement_type' => 'required|string|max:64',
            'title' => 'required|string|max:300',
            'claim_category' => 'nullable|string|max:64',
            'authority_type' => 'required|in:statute,regulation,contract,agency_procedure',
            'authority_citation' => 'required|string|max:300',
            'consequence_class' => 'required|in:preservative,administrative,escalation,enforcement,informational',
            'trigger_type' => 'required|string|max:64',
            'period_value' => 'nullable|integer|min:0',
            'period_unit' => 'nullable|string|max:16',
            'calendar_rule' => 'nullable|in:calendar,working,working_with_project_calendar',
            'calendar_rule_source' => 'nullable|string|max:300',
            'recipient_rule' => 'nullable|string|max:2000',
            'delivery_method_rule' => 'nullable|string|max:2000',
            'content_requirement_rule' => 'nullable|string|max:2000',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'project.view', write: true)->project;
        $data['tenant_id'] = $project->tenant_id;
        // Draft on creation, always. Confirmation is a separate act by a person
        // who has read the clause, and a requirement that arrives confirmed is a
        // requirement nobody read.
        $data['status'] = 'draft';

        return response()->json(['requirement' => ClaimRequirement::create($data)], 201);
    }

    /**
     * Confirming a requirement is reading a contract clause and saying so.
     *
     * After this the period, the counting rule, the authority and the
     * consequence are frozen, because people rely on them and an amendment is a
     * new requirement rather than an edit.
     */
    public function confirmRequirement(Request $request, ClaimRequirement $requirement)
    {
        $this->access->authorize($request->user(), (int) $requirement->project_id, 'project.view', write: true);

        abort_if($requirement->status === 'confirmed', 409,
            'This requirement is already confirmed. A change to what the contract requires is a new requirement '
            .'superseding this one, not an edit to it.');

        abort_if($requirement->period_value === null, 422,
            'A requirement cannot be confirmed without the period it allows. Confirming an empty period would create '
            .'a clock with nothing to count.');

        abort_if($requirement->calendar_rule !== 'calendar' && trim((string) $requirement->calendar_rule_source) === '', 422,
            'This requirement counts in working days, so the source of that counting rule has to be recorded. '
            .'Whether weekends count is a contract question, and an unsourced counting rule is an invented deadline.');

        $requirement->forceFill([
            'status' => 'confirmed',
            'confirmed_by' => $request->user()->id,
            'confirmed_at' => now(),
        ])->save();

        return response()->json(['requirement' => $requirement->fresh()]);
    }

    public function storeTrigger(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'event_type' => 'required|string|max:64',
            'description' => 'nullable|string|max:4000',
            'occurred_on' => 'nullable|date',
            'earliest_plausible_on' => 'nullable|date',
            'latest_plausible_on' => 'nullable|date',
            'source_type' => 'nullable|string|max:64',
            'source_id' => 'nullable|integer',
            'source_locator' => 'nullable|string|max:300',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'project.view', write: true)->project;
        $data['tenant_id'] = $project->tenant_id;
        $data['observed_by'] = $request->user()->id;
        // Unresolved on arrival. "When was the differing condition discovered"
        // is a contested question far more often than an obvious one, and a
        // clock counted from somebody's first guess is a date that was never
        // right being relied on.
        $data['status'] = ClaimClock::TRIGGER_UNRESOLVED;

        return response()->json(['trigger' => ClaimTriggerEvent::create($data)], 201);
    }

    public function resolveTrigger(Request $request, ClaimTriggerEvent $trigger)
    {
        $data = $request->validate([
            'status' => 'required|in:confirmed,disputed',
            'occurred_on' => 'nullable|date',
            'earliest_plausible_on' => 'nullable|date',
            'latest_plausible_on' => 'nullable|date',
            'dispute_note' => 'nullable|string|max:4000',
        ]);

        $this->access->authorize($request->user(), (int) $trigger->project_id, 'project.view', write: true);

        if ($data['status'] === ClaimClock::TRIGGER_CONFIRMED) {
            abort_if(($data['occurred_on'] ?? null) === null, 422,
                'A confirmed trigger needs the date it occurred. Confirming without one would let a clock run from nothing.');

            $data['confirmed_by'] = $request->user()->id;
            $data['confirmed_at'] = now();
        }

        $trigger->fill($data)->save();

        return response()->json(['trigger' => $trigger->fresh()]);
    }

    /**
     * What was actually done, kept apart from whether it worked.
     *
     * Timeliness, completeness and satisfaction are three separate findings and
     * nothing here derives one from another. A notice sent two days early to
     * the wrong officer, missing the cost impact the clause requires, is timely
     * and not compliant - and one green tick for it would tell the contractor
     * he is safe.
     */
    public function storeCompliance(Request $request, ClaimRequirement $requirement)
    {
        $data = $request->validate([
            'prepared_at' => 'nullable|date',
            'signed_at' => 'nullable|date',
            'sent_at' => 'nullable|date',
            'received_at' => 'nullable|date',
            'recipient' => 'nullable|string|max:300',
            'recipient_role' => 'nullable|string|max:160',
            'delivery_method' => 'nullable|string|max:64',
            'delivery_proof' => 'nullable|string|max:300',
            'evidence_document_id' => 'nullable|integer',
        ]);

        $this->access->authorize($request->user(), (int) $requirement->project_id, 'project.view', write: true);

        $data['tenant_id'] = $requirement->tenant_id;
        $data['claim_requirement_id'] = $requirement->id;
        // All three start unresolved. Uploading a PDF before the deadline is
        // not compliance; somebody has to determine that it satisfied what the
        // clause demanded, and that is a separate act.
        $data['timeliness'] = 'unresolved';
        $data['content_completeness'] = 'unresolved';
        $data['satisfaction'] = 'unresolved';

        return response()->json([
            'compliance' => ClaimComplianceEvent::create($data),
            'note' => 'Recorded as an event, not as compliance. Timeliness, content completeness and satisfaction are '
                .'three separate determinations and none of them follows from the fact that something was sent.',
        ], 201);
    }

    public function determineCompliance(Request $request, ClaimComplianceEvent $event)
    {
        $data = $request->validate([
            'timeliness' => 'required|in:timely,late,unresolved',
            'content_completeness' => 'required|in:complete,deficient,unresolved',
            'satisfaction' => 'required|in:satisfied,not_satisfied,unresolved',
            'determination_basis' => 'required|string|max:4000',
        ]);

        $requirement = ClaimRequirement::findOrFail($event->claim_requirement_id);
        $this->access->authorize($request->user(), (int) $requirement->project_id, 'project.view', write: true);

        // Once determined, frozen - same reasoning as confirmRequirement()
        // above. determined_at exists precisely so this can be checked, and a
        // determination silently overwritten (satisfied flipped to
        // not_satisfied, or the reverse) with no trace of the original finding
        // is worse than no determination: it destroys the record of what was
        // actually found without leaving evidence that anything changed. A
        // correction is a new, separately accountable act, not an edit.
        abort_if($event->determined_at !== null, 409,
            'This compliance event was already determined. A correction is a new determination, recorded '
            .'separately, not an edit to what was already found.');

        // Timely does not mean compliant, and the API refuses to let somebody
        // record that it does.
        if ($data['satisfaction'] === 'satisfied' && $data['content_completeness'] === 'deficient') {
            return response()->json([
                'error' => 'A notice recorded as deficient in content cannot be recorded as satisfying the requirement. '
                    .'Timeliness and completeness are separate findings, and a requirement is not met by a document that '
                    .'arrived on time without what the clause demands.',
            ], 422);
        }

        $event->fill($data + [
            'determined_by' => $request->user()->id,
            'determined_at' => now(),
        ])->save();

        return response()->json(['compliance' => $event->fresh()]);
    }

    /**
     * Write a calculation only when the answer has changed.
     *
     * The history has to be complete enough to reconstruct what was displayed
     * and shallow enough that nobody has to read a thousand identical rows to
     * find the two that matter.
     */
    private function recordCalculation(ClaimRequirement $requirement, array $result): void
    {
        $latest = ClaimClockCalculation::query()
            ->where('claim_requirement_id', $requirement->id)
            ->orderByDesc('id')->first();

        $deadline = $result['deadline_on'];

        if ($latest !== null
            && $latest->state === $result['state']
            && ($latest->deadline_on?->toDateString()) === $deadline) {
            return;
        }

        $authority = [
            'citation' => $requirement->authority_citation,
            'authority_type' => $requirement->authority_type,
            'period_value' => $requirement->period_value,
            'period_unit' => $requirement->period_unit,
            'calendar_rule' => $requirement->calendar_rule,
            'consequence_class' => $requirement->consequence_class,
        ];

        ClaimClockCalculation::create([
            'tenant_id' => $requirement->tenant_id,
            'claim_requirement_id' => $requirement->id,
            'claim_trigger_event_id' => $requirement->claim_trigger_event_id,
            'trigger_snapshot' => $requirement->trigger?->only(
                ['occurred_on', 'earliest_plausible_on', 'latest_plausible_on', 'status', 'event_type']
            ) ?? [],
            'authority_snapshot' => $authority,
            'authority_hash' => hash('sha256', json_encode($authority, JSON_THROW_ON_ERROR)),
            'deadline_on' => $deadline,
            'state' => $result['state'],
            'reason' => $result['message'],
            'calculated_at' => now(),
            'supersedes_calculation_id' => $latest?->id,
        ]);
    }

    /** @return array<string,mixed> */
    private function calendarFor($project): array
    {
        $clocks = (array) ($project->contract_clocks ?? []);
        $calendar = (array) ($clocks['calendar'] ?? []);

        return [
            // Never defaulted to true. A working-day requirement with no
            // confirmed calendar produces UNRESOLVED, which is the whole point.
            'confirmed' => (bool) ($calendar['confirmed'] ?? false),
            'holidays' => (array) ($calendar['holidays'] ?? []),
            'saturday_working' => (bool) ($calendar['saturday_working'] ?? false),
        ];
    }
}
