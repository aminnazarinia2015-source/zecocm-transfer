<?php

namespace App\Http\Controllers;

use App\Domain\Payment\ChangeOrderIncorporation;
use App\Domain\Schedule\ProjectAccess;
use App\Models\ChangeOrder;
use App\Models\ChangeOrderAllocation;
use App\Models\ScheduleOfValueItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * Change orders, and the moment one becomes part of the contract.
 *
 * The domain has been right for a while and had no route into it, which is the
 * failure mode this codebase has already shipped twice: a module that works,
 * is tested, and is invisible.
 *
 * Two things this surface refuses to make easy.
 *
 * Approval and incorporation are separate acts. Approving a change order is a
 * decision about the contract; incorporating it rewrites the schedule of values
 * that every payment application bills against. Doing both on one click would
 * mean nobody ever saw what the second one did.
 *
 * Adjusting an existing line requires saying why the work belongs to that
 * line's scope. Added scope folded into a base line raises the cap, and from
 * then on the extra work is invisible - cumulative billing looks normal because
 * the ceiling moved. That is the same blindness the hidden-change check exists
 * to catch, except baked into the schedule of values where no downstream check
 * can see it.
 */
class ChangeOrderController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'changeorder.view')->project;

        $orders = ChangeOrder::query()->where('project_id', $project->id)
            ->with('allocations.item')->orderByDesc('id')->limit(300)->get();

        $original = (int) ScheduleOfValueItem::query()->where('project_id', $project->id)->sum('original_value_cents');
        $current = (int) ScheduleOfValueItem::query()->where('project_id', $project->id)->sum('scheduled_value_cents');

        return response()->json([
            'orders' => $orders->map(fn (ChangeOrder $o) => $this->digest($o)),
            'schedule_of_values' => ScheduleOfValueItem::query()->where('project_id', $project->id)
                ->orderBy('item_number')->get(),
            // The contract growth bridge, visible at a glance. original_value_cents
            // is never touched by incorporation, which is what makes this legible.
            'contract' => [
                'original_cents' => $original,
                'approved_change_cents' => $current - $original,
                'current_cents' => $current,
            ],
            'computed_at' => now()->toIso8601String(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'number' => 'required|string|max:32',
            'title' => 'required|string|max:255',
            'origin_reason' => 'nullable|string|max:48',
            'amount_cents' => 'required|integer',
            'time_extension_days' => 'nullable|integer',
            'identified_at' => 'nullable|date',
            'allocations' => 'required|array|min:1|max:200',
            'allocations.*.schedule_of_value_item_id' => 'nullable|integer',
            'allocations.*.new_item_number' => 'nullable|string|max:32',
            'allocations.*.new_item_description' => 'nullable|string|max:255',
            'allocations.*.amount_cents' => 'required|integer',
            'allocations.*.same_scope_justification' => 'nullable|string|max:2000',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'changeorder.create', write: true)->project;

        $order = DB::transaction(function () use ($data, $project) {
            $order = ChangeOrder::create([
                'tenant_id' => $project->tenant_id, 'project_id' => $project->id,
                'number' => $data['number'], 'title' => $data['title'],
                'origin_reason' => $data['origin_reason'] ?? null,
                'status' => 'draft',
                'amount_cents' => (int) $data['amount_cents'],
                'time_extension_days' => (int) ($data['time_extension_days'] ?? 0),
                'identified_at' => $data['identified_at'] ?? null,
            ]);

            foreach ($data['allocations'] as $allocation) {
                $item = null;
                if (! empty($allocation['schedule_of_value_item_id'])) {
                    // Resolved through the project, so an id from another project
                    // - or another tenant - simply does not exist here.
                    $item = ScheduleOfValueItem::query()->where('project_id', $project->id)
                        ->findOrFail($allocation['schedule_of_value_item_id']);
                }

                ChangeOrderAllocation::create([
                    'tenant_id' => $project->tenant_id,
                    'change_order_id' => $order->id,
                    'schedule_of_value_item_id' => $item?->id,
                    'new_item_number' => $allocation['new_item_number'] ?? null,
                    'new_item_description' => $allocation['new_item_description'] ?? null,
                    'amount_cents' => (int) $allocation['amount_cents'],
                    'same_scope_justification' => $allocation['same_scope_justification'] ?? null,
                ]);
            }

            return $order;
        });

        return response()->json($this->show($request, $order->fresh())->getData(true), 201);
    }

    /**
     * Editable only while still a draft - the same precedent as
     * RfiController::update()/SubmittalController::update(). Found missing
     * during a real-world audit: a typo in a change order's title or amount
     * before it was ever approved had no fix path except abandoning the
     * record and raising a new one. Once approved, the amount/title are part
     * of a decision about the contract and are never silently rewritten -
     * a corrected amount goes through a superseding change order instead.
     */
    public function update(Request $request, ChangeOrder $order)
    {
        $this->access->authorize($request->user(), (int) $order->project_id, 'changeorder.create', write: true);
        abort_if($order->status !== 'draft', 422,
            'This change order has already been approved. An approved amount is a decision about the contract - raise a superseding change order instead of rewriting it.');

        $data = $request->validate([
            'number' => 'sometimes|required|string|max:32',
            'title' => 'sometimes|required|string|max:255',
            'origin_reason' => 'nullable|string|max:48',
            'amount_cents' => 'sometimes|required|integer',
            'time_extension_days' => 'nullable|integer',
            'identified_at' => 'nullable|date',
        ]);

        // Same edit-audit-trail pattern as RfiController::update()/
        // SubmittalController::update() (added after an independent Gemini
        // cross-check flagged the general gap): record what the draft used
        // to say before applying the correction. Skip entirely on a true
        // no-op (only unrecognized fields in the body) so the log doesn't
        // lie about how many times the record was genuinely edited.
        if (! empty($data)) {
            $before = array_intersect_key($order->getAttributes(), $data);
            $history = $order->edit_history ?? [];
            $history[] = ['action' => 'edited', 'by' => $request->user()->id, 'at' => now()->toIso8601String(), 'before' => $before];
            $order->edit_history = $history;
            $order->update($data);
        }

        return response()->json($this->digest($order->fresh()));
    }

    public function show(Request $request, ChangeOrder $order)
    {
        $this->access->authorize($request->user(), (int) $order->project_id, 'changeorder.view');
        $order->loadMissing('allocations.item');

        return response()->json([
            'order' => $this->digest($order),
            // Computed on read as well as on write, so what the screen shows and
            // what the server will accept come from one code path.
            'refusals' => ChangeOrderIncorporation::refusals($order),
        ]);
    }

    /** Approve. A decision about the contract, and nothing else. */
    public function approve(Request $request, ChangeOrder $order)
    {
        $this->access->authorize($request->user(), (int) $order->project_id, 'changeorder.approve', write: true);
        abort_unless($order->status !== 'approved', 422, 'This change order is already approved.');

        $data = $request->validate(['determination' => 'required|string|max:2000']);

        $order->forceFill([
            'status' => 'approved', 'approved_at' => now(), 'approved_by' => $request->user()->id,
            'seal' => array_merge((array) $order->seal, [
                'approved_by_name' => $request->user()->name,
                'determination' => $data['determination'],
                'approved_at' => now()->toIso8601String(),
            ]),
        ])->save();

        return response()->json([
            'order' => $this->digest($order->fresh()),
            'notice' => 'Approved. The schedule of values has NOT changed yet - incorporating it is a separate act, because it rewrites what every payment application bills against.',
        ]);
    }

    /** Incorporate. This rewrites the billing ledger, so it stands alone. */
    public function incorporate(Request $request, ChangeOrder $order)
    {
        $this->access->authorize($request->user(), (int) $order->project_id, 'changeorder.incorporate', write: true);

        try {
            $result = ChangeOrderIncorporation::incorporate($order);
        } catch (RuntimeException $e) {
            return response()->json([
                'refused' => true, 'reason' => $e->getMessage(),
                'refusals' => ChangeOrderIncorporation::refusals($order),
            ], 422);
        }

        return response()->json([
            'order' => $this->digest($order->fresh()),
            'result' => $result,
            'notice' => $result['adjusted'] === 0 && $result['created'] === 0
                ? 'Already incorporated. Nothing changed - applying a change order twice would inflate the contract sum silently.'
                : $result['adjusted'].' line(s) adjusted, '.$result['created'].' line(s) created. Original contract values are untouched, so the growth stays visible.',
        ]);
    }

    private function digest(ChangeOrder $order): array
    {
        $order->loadMissing('allocations.item');

        return [
            'id' => $order->id, 'number' => $order->number, 'title' => $order->title,
            'status' => $order->status, 'amount_cents' => (int) $order->amount_cents,
            'time_extension_days' => (int) $order->time_extension_days,
            'origin_reason' => $order->origin_reason,
            'approved_at' => $order->approved_at?->toIso8601String(),
            'approved_by_name' => $order->seal['approved_by_name'] ?? null,
            'incorporated' => ScheduleOfValueItem::query()
                ->where('project_id', $order->project_id)->where('change_order_id', $order->id)->exists(),
            'allocations' => $order->allocations->map(fn ($a) => [
                'id' => $a->id,
                'item_number' => $a->item?->item_number,
                'new_item_number' => $a->new_item_number,
                'new_item_description' => $a->new_item_description,
                'amount_cents' => (int) $a->amount_cents,
                'same_scope_justification' => $a->same_scope_justification,
                'creates_new_line' => $a->createsNewLine(),
            ])->all(),
        ];
    }
}
