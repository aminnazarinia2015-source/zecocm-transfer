<?php

namespace App\Http\Controllers;

use App\Domain\Evolution\SelfObservation;
use App\Models\CapabilityGap;
use Illuminate\Http\Request;

/**
 * TRACE proposing its own next build (trace-independence.md, Part 3): the
 * surface that makes SelfObservation's wiring actually reach a person.
 * Before this controller existed, a capability_gaps row was invisible to
 * everyone - indistinguishable in practice from not being recorded at all,
 * which is exactly the "brain growing but nobody can see it grow" gap Amin
 * asked to have closed.
 *
 * Cross-tenant by design and platform-staff-only: a gap is a fact about the
 * PRODUCT ("this keeps failing across accounts"), not one customer's
 * project data, so it is read the same way PlatformController already reads
 * tenant-crossing data - withoutGlobalScopes(), gated on isPlatformStaff()/
 * isPlatformAdmin() rather than a project grant. CapabilityGap uses
 * BelongsToTenant, so every lookup here is manual
 * (withoutGlobalScopes()->findOrFail()) rather than implicit route-model
 * binding, which would silently fail-closed to zero rows for a platform
 * user with no tenant context.
 *
 * propose()/decide() do not reimplement SelfObservation's rules - the
 * threshold check, the protected-capability refusal, and the status
 * transitions all still live in SelfObservation itself and are simply
 * surfaced here as a 422 with the same reason a caller of the class
 * directly would get.
 */
class CapabilityGapController
{
    public function index(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $data = $request->validate([
            'status' => 'nullable|in:observed,proposed,authorized,declined,shipped',
            'ready_only' => 'nullable|boolean',
        ]);

        $query = CapabilityGap::withoutGlobalScopes()->orderByDesc('last_seen_at');
        if (! empty($data['status'])) {
            $query->where('status', $data['status']);
        }

        $gaps = $query->limit(200)->get();
        if (! empty($data['ready_only'])) {
            $gaps = $gaps->filter(fn (CapabilityGap $g) => SelfObservation::readyToPropose($g))->values();
        }

        return response()->json(['gaps' => $gaps->map(fn (CapabilityGap $g) => $this->digest($g))]);
    }

    public function show(Request $request, int $gap)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $g = CapabilityGap::withoutGlobalScopes()->findOrFail($gap);

        // Codex's finding: cross-tenant product observation may aggregate
        // BEHAVIOUR - it does not inherit permission to aggregate customer
        // EVIDENCE. Raw samples (which can carry a steward's correction text
        // or a run's question verbatim) are withheld from the default view
        // even for platform staff, and are surfaced only to a platform admin
        // who explicitly asks for them, for a specific investigation.
        $withEvidence = $request->boolean('with_evidence') && $request->user()->isPlatformAdmin();

        return response()->json([
            'gap' => $this->digest($g, $withEvidence),
            'ready_to_propose' => SelfObservation::readyToPropose($g),
        ]);
    }

    public function propose(Request $request, int $gap)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $data = $request->validate([
            'proposal' => 'required|string|min:10',
            'register_row' => 'nullable|string|max:16',
        ]);
        $g = CapabilityGap::withoutGlobalScopes()->findOrFail($gap);

        try {
            $g = SelfObservation::propose($g, $data['proposal'], $data['register_row'] ?? null);
        } catch (\RuntimeException $e) {
            return response()->json(['refused' => true, 'reason' => $e->getMessage()], 422);
        }

        return response()->json(['gap' => $this->digest($g)]);
    }

    public function decide(Request $request, int $gap)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the platform admin decides a capability gap proposal.');
        $data = $request->validate([
            'authorized' => 'required|boolean',
            'reason' => 'required|string|min:5',
        ]);
        $g = CapabilityGap::withoutGlobalScopes()->findOrFail($gap);

        try {
            $g = SelfObservation::decide($g, $request->user()->id, $data['authorized'], $data['reason']);
        } catch (\RuntimeException $e) {
            return response()->json(['refused' => true, 'reason' => $e->getMessage()], 422);
        }

        return response()->json(['gap' => $this->digest($g)]);
    }

    /**
     * Cross-tenant product observation may aggregate BEHAVIOUR; it does not
     * inherit permission to aggregate customer EVIDENCE (Codex's finding).
     * The default digest carries counts and identity fields only - never the
     * raw `evidence` blob, which can hold a run's actual question text or a
     * steward's correction comment. `$withEvidence` is only ever true when
     * `show()` has already confirmed the caller is a platform admin asking
     * for a specific gap by id, never on the cross-tenant `index()` listing.
     */
    private function digest(CapabilityGap $gap, bool $withEvidence = false): array
    {
        $evidence = (array) $gap->evidence;
        $samples = (array) ($evidence['samples'] ?? []);

        $digest = [
            'id' => $gap->id,
            'tenant_id' => $gap->tenant_id,
            'signal_kind' => $gap->signal_kind,
            'cluster_key' => $gap->cluster_key,
            'title' => $gap->title,
            'occurrences' => $gap->occurrences,
            'distinct_askers' => $gap->distinct_askers,
            'distinct_projects' => $gap->distinct_projects,
            'sample_count' => count($samples),
            'target_capability' => $gap->target_capability,
            'includes_external_usage' => $gap->includes_external_usage,
            'status' => $gap->status,
            'proposal' => $gap->proposal,
            'register_row' => $gap->register_row,
            'authorized_by' => $gap->authorized_by,
            'authorized_at' => $gap->authorized_at,
            'decision_reason' => $gap->decision_reason,
            'first_seen_at' => $gap->first_seen_at,
            'last_seen_at' => $gap->last_seen_at,
        ];

        if ($withEvidence) {
            $digest['evidence'] = $gap->evidence;
        }

        return $digest;
    }
}
