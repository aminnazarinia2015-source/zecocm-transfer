<?php

namespace App\Http\Controllers;

use App\Domain\Autonomy\AutonomyLevel;
use App\Domain\Autonomy\AutonomyPolicyResolver;
use App\Domain\Schedule\ProjectAccess;
use App\Models\AutonomyPolicy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * AUTO-2's second missing piece, per Amin's direct pay-app-automation
 * direction and Codex's ruling on it: the customer-facing surface for
 * `AutonomyPolicy`, which had no HTTP controller anywhere before this file
 * (confirmed by search). Codex's explicit list of what this surface must be,
 * verbatim:
 *
 *   - only users with project.autonomy.manage can create/supersede a policy;
 *   - no hardcoded role-name checks;
 *   - policy changes are append-only/supersede-not-edit;
 *   - UI/API must show both customer-selected level and system maximum
 *     ceiling;
 *   - attempts to select above the ceiling are refused, not silently
 *     clamped;
 *   - no policy means APPROVAL_REQUIRED;
 *   - every change records actor, time, previous policy, new policy, and
 *     reason;
 *   - changing a policy must not retroactively auto-execute already-pending
 *     actions - those remain under the execution-time reauthorization rule
 *     already built (AutonomousActionRecorder::executeIfStillAuthorized()).
 *
 * "No hardcoded role-name checks" is what `project.autonomy.manage` being an
 * ordinary capability string on `ProjectGrant` already gives us - the same
 * mechanism every other write in this codebase goes through
 * (`ProjectAccess::authorize()`), not a new authorization idiom invented for
 * this surface. Configuring automation is deliberately a DIFFERENT capability
 * from any pay-application capability (`payment.certify`, `payment.submit`,
 * ...) - a project can grant one without the other, per Codex's "authority to
 * configure automation != authority to perform the underlying certified act."
 *
 * The last bullet needs no code here: AutonomousActionRecorder's
 * executeIfStillAuthorized() already re-resolves the CURRENT policy at
 * execution time rather than trusting an action's creation-time
 * effective_autonomy_level. Superseding a policy here is enough - any action
 * still pending when that happens is re-checked the next time something
 * tries to execute it, never on stale authority.
 */
class AutonomyPolicyController
{
    public function __construct(
        private readonly ProjectAccess $access,
        private readonly AutonomyPolicyResolver $resolver = new AutonomyPolicyResolver,
    ) {}

    /**
     * Every configured action type for this project: its system ceiling, its
     * current effective level, the active policy (if any), and the full
     * superseded history - so a reader can see what was authorized and when,
     * never just the current value.
     */
    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'project.autonomy.manage')->project;

        $actionTypes = array_keys(config('autonomy_action_ceilings', []));

        $rows = collect($actionTypes)->map(function (string $actionType) use ($project) {
            $resolution = $this->resolver->resolve($project->tenant_id, $project->id, $actionType);

            $history = AutonomyPolicy::query()
                ->where('tenant_id', $project->tenant_id)
                ->where('project_id', $project->id)
                ->where('action_type', $actionType)
                ->orderByDesc('id')
                ->get()
                ->map(fn (AutonomyPolicy $p) => $this->digest($p))
                ->values();

            return [
                'action_type' => $actionType,
                'system_ceiling' => $resolution['ceiling'],
                'effective_level' => $resolution['level'],
                'active_policy' => $resolution['policy'] !== null ? $this->digest($resolution['policy']) : null,
                'history' => $history,
            ];
        })->values();

        return response()->json([
            'project_id' => $project->id,
            'action_types' => $rows,
            'computed_at' => now()->toIso8601String(),
        ]);
    }

    /**
     * Set (or narrow) a project's autonomy policy for one action type. Never
     * edits an existing row - creates a new active policy and supersedes
     * whatever was active before, so "what was authorized as of date X"
     * stays answerable forever.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'action_type' => 'required|string',
            'autonomy_level' => 'required|string',
            'reason' => 'required|string|max:1000',
        ]);

        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'project.autonomy.manage', write: true)->project;

        $ceilings = config('autonomy_action_ceilings', []);
        $actionType = $data['action_type'];

        abort_unless(array_key_exists($actionType, $ceilings), 422,
            "'{$actionType}' is not a recognized autonomy action type.");
        abort_unless(AutonomyLevel::isValid($data['autonomy_level']), 422,
            "'{$data['autonomy_level']}' is not a recognized autonomy level.");

        $ceiling = $ceilings[$actionType];
        $requested = $data['autonomy_level'];

        // Refused, never silently clamped: the platform will not pretend a
        // customer got what they asked for when the system ceiling forbids
        // it, and it will not silently substitute the ceiling either - the
        // customer sees exactly why their selection did not take effect.
        if (AutonomyLevel::stricterOf($requested, $ceiling) !== $requested) {
            return response()->json([
                'refused' => true,
                'reason' => "The system ceiling for '{$actionType}' is {$ceiling}. A project policy may only "
                    .'narrow automation toward stricter than the ceiling, never widen past it.',
                'system_ceiling' => $ceiling,
                'requested_level' => $requested,
            ], 422);
        }

        $policy = DB::transaction(function () use ($project, $actionType, $requested, $data, $request) {
            $current = AutonomyPolicy::query()
                ->where('tenant_id', $project->tenant_id)
                ->where('project_id', $project->id)
                ->where('action_type', $actionType)
                ->where('status', 'active')
                ->first();

            $new = AutonomyPolicy::create([
                'tenant_id' => $project->tenant_id,
                'project_id' => $project->id,
                'capability' => 'project.autonomy.manage',
                'action_type' => $actionType,
                'autonomy_level' => $requested,
                'authority_source' => $data['reason'],
                'set_by' => $request->user()->id,
                'set_at' => now(),
                'effective_at' => now(),
                'status' => 'active',
                'supersedes_policy_id' => $current?->id,
            ]);

            // Superseding here is the whole safety mechanism: any
            // AutonomousAction still pending under the old policy is
            // re-resolved against THIS row (or its absence) the next time
            // anything tries to execute it - see
            // AutonomousActionRecorder::executeIfStillAuthorized(). Nothing
            // pending is touched directly by this request.
            $current?->update(['status' => 'superseded']);

            return $new;
        });

        return response()->json(['policy' => $this->digest($policy)], 201);
    }

    private function digest(AutonomyPolicy $policy): array
    {
        return [
            'id' => $policy->id,
            'action_type' => $policy->action_type,
            'autonomy_level' => $policy->autonomy_level,
            'status' => $policy->status,
            'reason' => $policy->authority_source,
            'set_by' => $policy->set_by,
            'set_at' => $policy->set_at?->toIso8601String(),
            'supersedes_policy_id' => $policy->supersedes_policy_id,
        ];
    }
}
