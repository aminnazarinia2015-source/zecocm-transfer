<?php

namespace App\Http\Controllers;

use App\Domain\Payment\PayApplicationAccountantExport;
use App\Domain\Payment\PayApplicationMath;
use App\Domain\Payment\RetentionRule;
use App\Domain\Payment\StopNoticeWithholding;
use App\Domain\Schedule\ProjectAccess;
use App\Models\PayApplication;
use App\Models\StopPaymentNotice;
use Illuminate\Http\Request;

/**
 * AUTO-2's third missing piece: a structured export of a pay application for
 * the customer's own accountant, per Codex's ruling on Amin's pay-app-
 * automation direction (claude/auto2-pay-app-automation-design-brief.md).
 * Gated on `payment.view` - the same capability that already lets a user see
 * this application in the product - because this is a reshaping of data a
 * user can already see, not a new grant of access to anything.
 *
 * Two formats from the one snapshot, mirroring how TransmittalController
 * already serves a composed document: default JSON carries both the CSV
 * text and the HTML document inline; `?format=csv` streams the CSV as a
 * download; `?format=html` streams the self-contained HTML document (see
 * PayApplicationAccountantExport's class doc for why HTML rather than a
 * binary PDF).
 */
class PayApplicationAccountantExportController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function show(Request $request, PayApplication $application)
    {
        $project = $this->access->authorize($request->user(), (int) $application->project_id, 'payment.view')->project;

        $retention = RetentionRule::fromProjectTerms($project->payment_terms)
            ?? new RetentionRule(
                basisPoints: (int) $application->retention_basis_points,
                source: 'Rate recorded on this application. Not confirmed against the contract.',
                confirmed: false,
            );

        // Paid to date is the most recent PAID application, not a sum across
        // every paid application - see the identical reasoning on
        // PayApplicationController::previouslyPaid().
        $latestPaid = PayApplication::query()->where('project_id', $application->project_id)
            ->where('number', '<', $application->number)
            ->where('status', 'paid')
            ->orderByDesc('number')
            ->with('lines')
            ->first();
        $previouslyPaid = $latestPaid !== null ? (int) PayApplicationMath::summarize($latestPaid)['earned_less_retention_cents'] : 0;

        $notices = StopPaymentNotice::query()->where('project_id', $project->id)->get()
            ->map(fn ($n) => [
                'claimant_name' => $n->claimant_name,
                'claimant_role' => $n->claimant_role,
                'claimed_amount_cents' => (int) $n->claimed_amount_cents,
                'served_on' => $n->served_on?->toDateString(),
                'status' => $n->status,
                'preliminary_notice_on_file' => (bool) $n->preliminary_notice_on_file,
                'release_bond_on_file' => (bool) $n->release_bond_on_file,
            ])->all();
        $withheld = StopNoticeWithholding::required($notices)['total_withheld_cents'];

        // Codex's finding: payment.view alone must not let this export act as
        // a side channel around SEC-3's changeorder.view gate. A viewer who
        // cannot independently see change orders gets the CO dollar delta
        // (already implicit in the pay application's own math) but not the
        // CO reference/number itself.
        $canViewChangeOrders = false;
        try {
            $canViewChangeOrders = $this->access->authorize($request->user(), $project->id, 'changeorder.view')
                ->allows('changeorder.view');
        } catch (\Throwable) {
            $canViewChangeOrders = false;
        }

        $snapshot = PayApplicationAccountantExport::snapshot(
            $application, $project, $retention, $previouslyPaid, $withheld, $canViewChangeOrders,
        );

        $format = (string) $request->query('format', '');

        if ($format === 'csv') {
            return response(PayApplicationAccountantExport::toCsv($snapshot), 200, [
                'Content-Type' => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="pay-application-'.$application->number.'-export.csv"',
                'X-Content-Type-Options' => 'nosniff',
            ]);
        }

        $document = PayApplicationAccountantExport::toDocument($snapshot);

        if ($format === 'html') {
            return response($document['html'], 200, [
                'Content-Type' => 'text/html; charset=UTF-8',
                'Content-Security-Policy' => "default-src 'none'; style-src 'unsafe-inline'",
                'X-Content-Type-Options' => 'nosniff',
            ]);
        }

        return response()->json([
            'snapshot' => $snapshot,
            'csv' => PayApplicationAccountantExport::toCsv($snapshot),
            'html' => $document['html'],
            'fingerprint' => $document['fingerprint'],
            'notice' => 'A structured export for accounting ingestion and filing. Employee-level certified-payroll '
                .'detail, internal review reasoning, and evidence not needed to process this invoice are '
                .'deliberately not included.',
        ]);
    }
}
