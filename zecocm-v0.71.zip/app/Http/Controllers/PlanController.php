<?php

namespace App\Http\Controllers;

use App\Domain\Schedule\ProjectAccess;
use App\Models\KnowledgeSourceVersion;
use App\Models\PlanMarkup;
use App\Models\PlanRevisionReview;
use App\Models\PlanSet;
use App\Models\PlanSheet;
use App\Models\PlanSheetVersion;
use App\Models\Project;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class PlanController
{
    private const CATEGORIES = ['general', 'cover', 'site', 'civil', 'landscape', 'architectural', 'structural', 'mechanical', 'electrical', 'plumbing', 'fire_protection', 'telecom', 'details', 'schedules', 'as_built'];

    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'discipline' => 'nullable|string|max:48',
            'category' => 'nullable|in:'.implode(',', self::CATEGORIES),
            'q' => 'nullable|string|max:160',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'plans.view');
        $project = $grant->project;

        $sets = PlanSet::query()->where('project_id', $project->id)
            ->with(['sheets' => function ($query) use ($data) {
                $query->when($data['discipline'] ?? null, fn ($q, $discipline) => $q->where('discipline', $discipline))
                    ->when($data['category'] ?? null, fn ($q, $category) => $q->where('category', $category))
                    ->when($data['q'] ?? null, function ($q, $term) {
                        $escaped = '%'.addcslashes($term, '%_\\').'%';
                        $q->where(fn ($inner) => $inner->where('sheet_number', 'like', $escaped)->orWhere('title', 'like', $escaped));
                    })
                    ->with(['currentVersion' => fn ($q) => $q->with(['sourceVersion.source', 'review.reviewer'])->withCount(['markups as open_markups_count' => fn ($m) => $m->where('status', 'open')])])
                    ->withCount('versions')
                    ->orderBy('sheet_number');
            }])->orderBy('name')->get();

        return response()->json([
            'sets' => $sets,
            'disciplines' => PlanSheet::query()->where('project_id', $project->id)->distinct()->orderBy('discipline')->pluck('discipline')->values(),
            'permissions' => [
                'manage' => $grant->allows('plans.manage'),
                'markup' => $grant->allows('plans.markup'),
                'review' => $grant->allows('plans.review'),
            ],
            'categories' => self::CATEGORIES,
            'notice' => 'Every sheet revision points to immutable, hash-verified document bytes. Superseded revisions remain available.',
        ]);
    }

    public function sources(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'plans.manage')->project;
        $this->access->authorize($request->user(), $project->id, 'documents.view');

        $versions = KnowledgeSourceVersion::query()
            ->with('source')
            ->where('malware_scan_status', 'clean')
            ->whereHas('source', fn ($query) => $query->where('project_id', $project->id))
            ->latest('id')
            ->limit(1000)
            ->get()
            ->filter(fn ($version) => Storage::disk('local')->exists($version->storage_path))
            ->map(fn ($version) => [
                'id' => $version->id,
                'label' => ($version->source?->title ?: $version->source?->original_filename ?: 'Document')
                    .' · v'.$version->version_number
                    .($version->revision ? ' · '.$version->revision : ''),
                'sha256' => $version->sha256,
            ])->values();

        return response()->json([
            'sources' => $versions,
            'notice' => 'Only clean document versions with available immutable bytes are eligible.',
        ]);
    }

    public function storeSet(Request $request)
    {
        $this->writesAllowed();
        $data = $request->validate([
            'project_id' => 'required|integer',
            'name' => 'required|string|max:160',
            'discipline' => 'nullable|string|max:48',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'plans.manage', write: true)->project;
        $set = DB::transaction(function () use ($project, $data, $request) {
            Project::query()->whereKey($project->id)->lockForUpdate()->firstOrFail();
            $name = trim($data['name']);
            abort_if(PlanSet::query()->where('project_id', $project->id)->whereRaw('LOWER(name) = ?', [mb_strtolower($name)])->exists(), 422, 'A plan set with this name already exists.');

            return PlanSet::create([
                'tenant_id' => $project->tenant_id,
                'project_id' => $project->id,
                'name' => $name,
                'discipline' => $data['discipline'] ?? 'general',
                'status' => 'active',
                'created_by' => $request->user()->id,
            ]);
        });

        return response()->json(['set' => $set], 201);
    }

    public function storeSheet(Request $request, PlanSet $set)
    {
        $this->writesAllowed();
        $data = $request->validate($this->sheetRules());
        $project = $this->access->authorize($request->user(), (int) $set->project_id, 'plans.manage', write: true)->project;
        $this->access->authorize($request->user(), (int) $set->project_id, 'documents.view');
        abort_unless((int) $set->project_id === (int) $project->id, 404, 'That plan set does not belong to this project.');
        $sourceVersion = $this->sourceVersion($data['knowledge_source_version_id'], $project->id);

        $sheet = DB::transaction(function () use ($data, $set, $project, $request, $sourceVersion) {
            $lockedSet = PlanSet::query()->lockForUpdate()->findOrFail($set->id);
            $number = strtoupper(trim($data['sheet_number']));
            abort_if(PlanSheet::query()->where('plan_set_id', $lockedSet->id)->whereRaw('LOWER(sheet_number) = ?', [mb_strtolower($number)])->exists(), 422, 'That sheet number already exists in this set.');
            $sheet = PlanSheet::create([
                'tenant_id' => $project->tenant_id,
                'project_id' => $project->id,
                'plan_set_id' => $lockedSet->id,
                'sheet_number' => $number,
                'title' => trim($data['title']),
                'discipline' => $data['discipline'] ?? $lockedSet->discipline,
                'category' => $data['category'] ?? 'general',
                'status' => 'active',
                'created_by' => $request->user()->id,
            ]);
            $version = $this->createVersion($sheet, $sourceVersion, $data, $request->user()->id);
            $sheet->update(['current_version_id' => $version->id]);
            $sourceVersion->source->update(['source_type' => 'drawing', 'collection' => 'project']);
            $this->event($sheet, $version, null, 'sheet_created', ['revision' => $version->revision], $request->user()->id);

            return $sheet;
        });

        return response()->json(['sheet' => $this->digest($sheet->fresh())], 201);
    }

    public function storeRevision(Request $request, PlanSheet $sheet)
    {
        $this->writesAllowed();
        $data = $request->validate($this->revisionRules());
        $this->access->authorize($request->user(), (int) $sheet->project_id, 'plans.manage', write: true);
        $this->access->authorize($request->user(), (int) $sheet->project_id, 'documents.view');
        $sourceVersion = $this->sourceVersion($data['knowledge_source_version_id'], $sheet->project_id);

        $version = DB::transaction(function () use ($sheet, $sourceVersion, $data, $request) {
            $locked = PlanSheet::query()->lockForUpdate()->findOrFail($sheet->id);
            abort_if($locked->versions()->whereRaw('LOWER(revision) = ?', [mb_strtolower(trim($data['revision']))])->exists(), 422, 'That revision already exists for this sheet.');
            $version = $this->createVersion($locked, $sourceVersion, $data, $request->user()->id);
            $locked->update(['current_version_id' => $version->id]);
            $sourceVersion->source->update(['source_type' => 'drawing', 'collection' => 'project']);
            $this->event($locked, $version, null, 'revision_appended', ['revision' => $version->revision], $request->user()->id);

            return $version;
        });

        return response()->json(['version' => $version, 'sheet' => $this->digest($sheet->fresh())], 201);
    }

    public function show(Request $request, PlanSheet $sheet)
    {
        $grant = $this->access->authorize($request->user(), (int) $sheet->project_id, 'plans.view');
        $sheet->load(['set', 'versions' => fn ($q) => $q->with(['sourceVersion.source', 'markups', 'review.reviewer'])->latest('id')]);

        $events = DB::table('plan_events')->where('plan_sheet_id', $sheet->id)->orderBy('id')->get();
        $projectEvents = DB::table('plan_events')->where('project_id', $sheet->project_id)->orderBy('id')->get();

        return response()->json([
            'sheet' => $this->digest($sheet),
            'events' => $events,
            'event_chain_valid' => $this->eventChainValid($projectEvents),
            'permissions' => [
                'manage' => $grant->allows('plans.manage'),
                'markup' => $grant->allows('plans.markup'),
                'review' => $grant->allows('plans.review'),
            ],
        ]);
    }

    public function preview(Request $request, PlanSheetVersion $version)
    {
        $this->access->authorize($request->user(), (int) $version->project_id, 'plans.view');
        $source = $version->sourceVersion()->with('source')->firstOrFail();
        abort_unless($source->malware_scan_status === 'clean', 423, 'This drawing revision is quarantined and cannot be previewed.');
        abort_unless(Storage::disk('local')->exists($source->storage_path), 404, 'The drawing bytes are not available on this server.');
        $mime = strtolower((string) $source->mime_type);
        abort_unless(in_array($mime, ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'], true), 415, 'This file type cannot be safely previewed in the browser; download the verified bytes instead.');
        $extension = match ($mime) {
            'application/pdf' => 'pdf',
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
        };
        $filename = ($version->sheet?->sheet_number ?? 'sheet').'-'.$version->revision.'.'.$extension;

        return Storage::disk('local')->response($source->storage_path, $filename, [
            'Content-Type' => $mime,
            'X-Content-Type-Options' => 'nosniff',
            'Content-Security-Policy' => "default-src 'none'; sandbox",
            'Cache-Control' => 'private, no-store',
            'X-Frame-Options' => 'SAMEORIGIN',
        ], 'inline');
    }

    public function reviewRevision(Request $request, PlanSheetVersion $version)
    {
        $this->writesAllowed();
        $data = $request->validate([
            'disposition' => 'required|in:accepted,rejected',
            'determination' => 'required|string|min:3|max:4000',
        ]);
        $this->access->authorize($request->user(), (int) $version->project_id, 'plans.review', write: true);

        $review = DB::transaction(function () use ($version, $data, $request) {
            $locked = PlanSheetVersion::query()->lockForUpdate()->findOrFail($version->id);
            abort_if($locked->review()->exists(), 409, 'This revision already has a formal disposition. Append a new revision rather than replacing its review.');
            $review = PlanRevisionReview::create([
                'tenant_id' => $locked->tenant_id,
                'project_id' => $locked->project_id,
                'plan_sheet_version_id' => $locked->id,
                'disposition' => $data['disposition'],
                'determination' => trim($data['determination']),
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
            ]);
            $this->event($locked->sheet, $locked, null, 'revision_'.$review->disposition, ['determination' => $review->determination], $request->user()->id);

            return $review;
        });

        return response()->json(['review' => $review]);
    }

    public function download(Request $request, PlanSheetVersion $version)
    {
        $this->access->authorize($request->user(), (int) $version->project_id, 'plans.view');
        $source = $version->sourceVersion()->with('source')->firstOrFail();
        abort_unless($source->malware_scan_status === 'clean', 423, 'This drawing revision is quarantined and cannot be opened.');
        abort_unless(Storage::disk('local')->exists($source->storage_path), 404, 'The drawing bytes are not available on this server.');
        $filename = ($version->sheet?->sheet_number ?? 'sheet').'-'.$version->revision.'.'.pathinfo((string) $source->source?->original_filename, PATHINFO_EXTENSION);

        return Storage::disk('local')->download($source->storage_path, $filename, [
            'Content-Type' => $source->mime_type ?: 'application/octet-stream',
            'X-Content-Type-Options' => 'nosniff',
            'Content-Security-Policy' => "default-src 'none'; sandbox",
            'Cache-Control' => 'private, no-store',
        ]);
    }

    public function storeMarkup(Request $request, PlanSheetVersion $version)
    {
        $this->writesAllowed();
        $data = $request->validate([
            'markup_type' => 'required|in:pin,text,rectangle,cloud,polyline',
            'geometry' => 'required|array',
            'geometry.x' => 'nullable|numeric|min:0|max:1',
            'geometry.y' => 'nullable|numeric|min:0|max:1',
            'geometry.width' => 'nullable|numeric|min:0|max:1',
            'geometry.height' => 'nullable|numeric|min:0|max:1',
            'geometry.points' => 'nullable|array|max:200',
            'geometry.points.*.x' => 'required_with:geometry.points|numeric|min:0|max:1',
            'geometry.points.*.y' => 'required_with:geometry.points|numeric|min:0|max:1',
            'body' => 'nullable|string|max:4000',
            'color' => ['nullable', 'string', 'regex:/^#[0-9A-Fa-f]{6}$/'],
        ]);
        $this->access->authorize($request->user(), (int) $version->project_id, 'plans.markup', write: true);
        $this->validateGeometry($data['markup_type'], $data['geometry']);

        $markup = DB::transaction(function () use ($version, $data, $request) {
            $markup = PlanMarkup::create([
                'tenant_id' => $version->tenant_id,
                'project_id' => $version->project_id,
                'plan_sheet_version_id' => $version->id,
                'markup_type' => $data['markup_type'],
                'geometry' => $data['geometry'],
                'body' => $data['body'] ?? null,
                'color' => strtoupper($data['color'] ?? '#D97706'),
                'status' => 'open',
                'created_by' => $request->user()->id,
            ]);
            $this->event($version->sheet, $version, $markup, 'markup_created', ['type' => $markup->markup_type], $request->user()->id);

            return $markup;
        });

        return response()->json(['markup' => $markup], 201);
    }

    public function resolveMarkup(Request $request, PlanMarkup $markup)
    {
        $this->writesAllowed();
        $data = $request->validate(['resolution' => 'required|string|max:4000']);
        $this->access->authorize($request->user(), (int) $markup->project_id, 'plans.markup', write: true);
        DB::transaction(function () use ($markup, $data, $request) {
            $locked = PlanMarkup::query()->lockForUpdate()->findOrFail($markup->id);
            abort_unless($locked->status === 'open', 409, 'This markup is already resolved.');
            $locked->update(['status' => 'resolved', 'resolved_by' => $request->user()->id, 'resolved_at' => now(), 'resolution' => $data['resolution']]);
            $version = $locked->version;
            $this->event($version->sheet, $version, $locked, 'markup_resolved', ['resolution' => $data['resolution']], $request->user()->id);
        });

        return response()->json(['markup' => $markup->fresh()]);
    }

    private function sheetRules(): array
    {
        return $this->revisionRules() + [
            'sheet_number' => 'required|string|max:64',
            'title' => 'required|string|max:255',
            'discipline' => 'nullable|string|max:48',
            'category' => 'nullable|in:'.implode(',', self::CATEGORIES),
        ];
    }

    private function revisionRules(): array
    {
        return [
            'knowledge_source_version_id' => 'required|integer',
            'page_number' => 'nullable|integer|min:1|max:100000',
            'revision' => 'required|string|max:96',
            'issue_status' => 'required|in:bid,permit,issued_for_construction,record,as_built',
            'issued_at' => 'nullable|date',
            'source_provider' => 'nullable|in:zecocm,autodesk,bluebeam,procore,other',
            'external_id' => 'nullable|string|max:255',
            'external_url' => 'nullable|url:https|max:1000',
        ];
    }

    private function sourceVersion(int $id, int $projectId): KnowledgeSourceVersion
    {
        $version = KnowledgeSourceVersion::query()->with('source')->find($id);
        abort_if($version === null || $version->source === null || (int) $version->source->project_id !== $projectId, 422, 'The selected document version does not belong to this project.');
        abort_unless($version->malware_scan_status === 'clean', 423, 'The selected document version is quarantined and cannot become a plan revision.');
        abort_unless(Storage::disk('local')->exists($version->storage_path), 422, 'The selected document bytes are missing and cannot become a plan revision.');

        return $version;
    }

    private function createVersion(PlanSheet $sheet, KnowledgeSourceVersion $source, array $data, int $actor): PlanSheetVersion
    {
        return PlanSheetVersion::create([
            'tenant_id' => $sheet->tenant_id,
            'project_id' => $sheet->project_id,
            'plan_sheet_id' => $sheet->id,
            'knowledge_source_version_id' => $source->id,
            'page_number' => $data['page_number'] ?? null,
            'revision' => trim($data['revision']),
            'issue_status' => $data['issue_status'],
            'issued_at' => $data['issued_at'] ?? null,
            'source_provider' => $data['source_provider'] ?? 'zecocm',
            'external_id' => $data['external_id'] ?? null,
            'external_url' => $data['external_url'] ?? null,
            'sha256' => $source->sha256,
            'created_by' => $actor,
        ]);
    }

    private function validateGeometry(string $type, array $geometry): void
    {
        if ($type === 'polyline') {
            if (count($geometry['points'] ?? []) < 2) {
                throw ValidationException::withMessages(['geometry.points' => 'A polyline requires at least two normalized points.']);
            }

            return;
        }
        foreach (['x', 'y'] as $key) {
            if (! array_key_exists($key, $geometry)) {
                throw ValidationException::withMessages(['geometry.'.$key => 'This normalized coordinate is required.']);
            }
        }
        if (in_array($type, ['rectangle', 'cloud'], true) && (! isset($geometry['width'], $geometry['height']))) {
            throw ValidationException::withMessages(['geometry' => 'Rectangle and cloud markups require normalized width and height.']);
        }
    }

    private function digest(PlanSheet $sheet): array
    {
        $sheet->loadMissing(['set', 'versions.sourceVersion.source', 'versions.markups', 'versions.review.reviewer', 'currentVersion.sourceVersion.source', 'currentVersion.review.reviewer']);

        return [
            'id' => $sheet->id,
            'project_id' => $sheet->project_id,
            'plan_set_id' => $sheet->plan_set_id,
            'set_name' => $sheet->set?->name,
            'sheet_number' => $sheet->sheet_number,
            'title' => $sheet->title,
            'discipline' => $sheet->discipline,
            'category' => $sheet->category,
            'status' => $sheet->status,
            'current_version_id' => $sheet->current_version_id,
            'versions' => $sheet->versions->sortByDesc('id')->map(fn ($version) => [
                'id' => $version->id,
                'revision' => $version->revision,
                'issue_status' => $version->issue_status,
                'issued_at' => optional($version->issued_at)->toDateString(),
                'page_number' => $version->page_number,
                'sha256' => $version->sha256,
                'source_provider' => $version->source_provider,
                'external_url' => $version->external_url,
                'download_url' => '/api/plans/versions/'.$version->id.'/download',
                'preview_url' => '/api/plans/versions/'.$version->id.'/preview',
                'trace_ready' => $version->sourceVersion?->source?->ingestion_status === 'ready',
                'review_status' => $version->review?->disposition ?? 'submitted',
                'review' => $version->review ? [
                    'disposition' => $version->review->disposition,
                    'determination' => $version->review->determination,
                    'reviewed_by' => $version->review->reviewed_by,
                    'reviewed_by_name' => $version->review->reviewer?->name,
                    'reviewed_at' => optional($version->review->reviewed_at)->toIso8601String(),
                ] : null,
                'markups' => $version->markups,
            ])->values(),
            'trace_context' => [
                'view' => 'plans',
                'record_type' => 'plan_sheet',
                'record_id' => $sheet->id,
            ],
        ];
    }

    private function event(?PlanSheet $sheet, ?PlanSheetVersion $version, ?PlanMarkup $markup, string $action, array $details, int $actor): void
    {
        $tenantId = $sheet?->tenant_id ?? $version?->tenant_id ?? $markup?->tenant_id;
        $projectId = $sheet?->project_id ?? $version?->project_id ?? $markup?->project_id;
        // Serialize the project-wide chain on the project row. Locking only
        // the latest event cannot serialize the first insert into an empty
        // chain and can fork under concurrent markup/revision writes.
        Project::query()->whereKey($projectId)->lockForUpdate()->firstOrFail();
        $previous = DB::table('plan_events')->where('tenant_id', $tenantId)->where('project_id', $projectId)->latest('id')->first();
        $payload = [
            'tenant_id' => $tenantId,
            'project_id' => $projectId,
            'plan_sheet_id' => $sheet?->id,
            'plan_sheet_version_id' => $version?->id,
            'plan_markup_id' => $markup?->id,
            'action' => $action,
            'details' => json_encode($details, JSON_THROW_ON_ERROR),
            'actor_user_id' => $actor,
            'previous_event_hash' => $previous?->event_hash,
            'created_at' => now(),
            'updated_at' => now(),
        ];
        $payload['event_hash'] = $this->eventHash($payload, $details);
        DB::table('plan_events')->insert($payload);
    }

    private function eventChainValid(iterable $events): bool
    {
        $previous = null;
        foreach ($events as $event) {
            if ($event->previous_event_hash !== $previous) {
                return false;
            }
            $payload = (array) $event;
            $details = json_decode((string) $event->details, true, flags: JSON_THROW_ON_ERROR);
            if (! hash_equals((string) $event->event_hash, $this->eventHash($payload, is_array($details) ? $details : []))) {
                return false;
            }
            $previous = $event->event_hash;
        }

        return true;
    }

    private function eventHash(array $payload, array $details): string
    {
        $canonical = [
            'tenant_id' => (int) $payload['tenant_id'],
            'project_id' => (int) $payload['project_id'],
            'plan_sheet_id' => isset($payload['plan_sheet_id']) ? (int) $payload['plan_sheet_id'] : null,
            'plan_sheet_version_id' => isset($payload['plan_sheet_version_id']) ? (int) $payload['plan_sheet_version_id'] : null,
            'plan_markup_id' => isset($payload['plan_markup_id']) ? (int) $payload['plan_markup_id'] : null,
            'action' => (string) $payload['action'],
            'details' => $this->canonicalize($details),
            'actor_user_id' => isset($payload['actor_user_id']) ? (int) $payload['actor_user_id'] : null,
            'previous_event_hash' => $payload['previous_event_hash'] ?? null,
        ];

        return hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private function canonicalize(array $value): array
    {
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $item) {
            if (is_array($item)) {
                $value[$key] = $this->canonicalize($item);
            }
        }

        return $value;
    }

    private function writesAllowed(): void
    {
        abort_if(TenantContext::writesBlocked(), 403, 'Technicians are read-only in customer workspaces.');
    }
}
