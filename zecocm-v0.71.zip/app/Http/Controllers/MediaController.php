<?php

namespace App\Http\Controllers;

use App\Domain\Provenance\CaptureAttestation;
use App\Domain\Provenance\CaptureClocks;
use App\Domain\Provenance\ProvenanceSealer;
use App\Domain\Schedule\ProjectAccess;
use App\Domain\Security\SecureUploadGate;
use App\Models\DailyReport;
use App\Models\EvidenceLink;
use App\Models\MediaItem;
use App\Models\Rfi;
use App\Models\ScheduleVersion;
use App\Models\Submittal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class MediaController
{
    public function __construct(private readonly ProjectAccess $access) {}

    /**
     * A real listing was missing entirely - upload and link both worked
     * server-side, but there was no way to see what had already been
     * captured, so the "Photos" nav item was left prototype-gated even
     * though the capability is sold as operational (CapabilityCatalog
     * 'photos'). Gated on 'documents.view', the same broad evidence-read
     * capability every other read-only project record uses, since photo
     * evidence is not a separately toggleable permission in the invite
     * wizard today.
     */
    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'documents.view');

        return MediaItem::where('project_id', $grant->project->id)
            ->orderByDesc('id')
            ->limit(200)
            ->get(['id', 'original_name', 'mime', 'bytes', 'sha256', 'confidence', 'capture_finding', 'malware_scan_status', 'server_received_at', 'captured_by']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'file' => 'required|file|max:102400',
            'device_wall_clock' => 'nullable|date',
            'monotonic_at_capture' => 'nullable|numeric|min:0',
            'monotonic_at_transmit' => 'nullable|numeric|min:0',
            'context' => 'nullable|array|max:50',
        ]);
        $grant = $this->access->authorize($request->user(), (int) $data['project_id'], 'media.upload', write: true);

        $file = $request->file('file');

        // SEC-5: this path had no type allowlist and no malware scan at all
        // before this gate - any byte stream was accepted, content-addressed,
        // and stored. It is evidence media, not office documents, so the
        // profile is narrower than document ingestion (images and PDF only).
        $decision = SecureUploadGate::admit($file, SecureUploadGate::EVIDENCE_MEDIA);
        if (! $decision->admitted) {
            throw ValidationException::withMessages([
                'file' => 'Only photographic or PDF evidence is accepted ('.$decision->rejectionReason.').',
            ]);
        }

        $hash = hash_file('sha256', $file->getRealPath());
        abort_if($hash === false, 422, 'The uploaded file could not be hashed.');

        $scan = SecureUploadGate::scan($file->getRealPath(), SecureUploadGate::timeoutForSize($file->getSize()));

        $sealer = ProvenanceSealer::current();

        // Content-addressed: bytes stored once, NEVER modified (Aspect 1).
        // Sealed and quarantine bytes are kept apart the same way document
        // and knowledge uploads already are - a scan that is not 'clean'
        // (including 'pending', when no scanner is configured, and 'error',
        // when the scanner itself failed or timed out) never lands beside
        // material treated as safe.
        $bucket = $scan === 'clean' ? 'sealed' : 'quarantine';
        $path = 'media/'.$bucket.'/'.substr($hash, 0, 2).'/'.$hash;
        if (! Storage::exists($path)) {
            $stored = Storage::putFileAs('media/'.$bucket.'/'.substr($hash, 0, 2), $file, $hash);
            abort_if($stored !== $path, 500, 'The verified file could not be stored.');
        }

        // B5/EV-11. The server's clock, taken once, before anything the client
        // said is looked at. This is the only time in the whole record that a
        // client cannot forge, and everything the device claims is measured
        // against it rather than against the device's own other numbers.
        $receivedAt = new \DateTimeImmutable;

        $clientClaims = [
            'device_wall_clock' => $request->input('device_wall_clock'),
            'monotonic_at_capture' => $request->input('monotonic_at_capture'),
            'monotonic_at_transmit' => $request->input('monotonic_at_transmit'),
            'context' => $request->input('context', []),
        ];

        $attestation = CaptureAttestation::attest(
            $receivedAt,
            $clientClaims,
            // Authoritative ordering: whatever two devices claim about when
            // their photographs were taken, the sequence in which they reached
            // this server is a fact.
            (int) (MediaItem::withoutGlobalScopes()->max('receipt_sequence') ?? 0) + 1,
        );

        $capture = new CaptureClocks(
            new \DateTimeImmutable($request->input('device_wall_clock', 'now')),
            (float) $request->input('monotonic_at_capture', 0),
        );
        $sealed = $sealer->seal(
            $hash,
            [
                'tenant_id' => $grant->project->tenant_id,
                'project_id' => $grant->project->id,
                'captured_by' => $request->user()->id,
                'client_context' => $request->input('context', []),
            ],
            $capture,
            $receivedAt,
            (float) $request->input('monotonic_at_transmit', 0),
        );

        $item = MediaItem::create([
            'project_id' => $grant->project->id,
            'sha256' => $hash,
            'storage_path' => $path,
            'original_name' => $decision->safeName,
            'mime' => $file->getMimeType() ?? 'application/octet-stream',
            'bytes' => $file->getSize(),
            'malware_scan_status' => $scan,
            'quarantine_reason' => $scan === 'clean' ? null : 'Awaiting configured malware scanning.',
            'provenance' => $sealed->payload + ['capture_attestation' => $attestation],
            'provenance_signature' => $sealed->signature,
            // Kept, not dropped. Historical records asserted this value and
            // rewriting what a record said at the time it was made is the one
            // thing this codebase does not do. It is superseded by the columns
            // below rather than corrected in place.
            'confidence' => $sealer->confidence($sealed),
            'server_received_at' => $receivedAt,
            'receipt_sequence' => $attestation['established']['receipt_sequence'],
            'capture_time_basis' => $attestation['capture_time_basis'],
            'capture_finding' => $attestation['finding'],
            'client_claims' => $clientClaims,
            'captured_by' => $request->user()->id,
        ]);

        return response()->json($item->toArray() + [
            // The sentence that goes on the face of a document, in place of a
            // one-word badge a reader would fill in for themselves.
            'capture_statement' => CaptureAttestation::statement($attestation),
            'attestation' => $attestation,
        ], 201);
    }

    /** Tag once, discoverable everywhere (Addendum J). */
    public function link(Request $request, MediaItem $media)
    {
        $data = $request->validate([
            'record_type' => 'required|in:rfi,submittal,daily_report,schedule_version',
            'record_id' => 'required|integer',
        ]);
        $this->access->authorize($request->user(), $media->project_id, 'media.link', write: true);
        $model = match ($data['record_type']) {
            'rfi' => Rfi::query()->find($data['record_id']),
            'submittal' => Submittal::query()->find($data['record_id']),
            'daily_report' => DailyReport::query()->find($data['record_id']),
            'schedule_version' => ScheduleVersion::query()->find($data['record_id']),
        };
        abort_if($model === null || (int) $model->project_id !== (int) $media->project_id, 422, 'The evidence target must exist in the same authorized project.');

        $link = EvidenceLink::firstOrCreate([
            'media_item_id' => $media->id,
            'record_type' => $data['record_type'],
            'record_id' => $data['record_id'],
        ], ['linked_by' => $request->user()->id]);

        return response()->json($link, 201);
    }

    // safeOriginalName() moved to SecureUploadGate::safeName(), applied via
    // the admission decision above rather than duplicated here.
}
