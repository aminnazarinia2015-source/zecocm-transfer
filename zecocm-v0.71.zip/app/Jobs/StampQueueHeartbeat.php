<?php

namespace App\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\DB;

/**
 * OPS-14: the worker side of the queue-worker heartbeat. `DispatchQueueHeartbeat`
 * (an artisan command, scheduled every `zecocm_ops.queue_heartbeat.interval_seconds`)
 * inserts a `queue_heartbeats` row with a fresh `dispatch_token` and dispatches
 * this job carrying that exact token onto the real production queue - not a
 * side channel - so the health check is proving the same worker/queue that
 * processes actual application jobs is still consuming them.
 *
 * This job does exactly one thing: stamp `handled_at` on the row that matches
 * its own token. It never creates a row itself - if the token it was given
 * does not exist (a truncated table, a bug in the dispatcher), it fails
 * loudly rather than silently inserting one, since a heartbeat this job
 * invented itself would prove nothing about the dispatcher having run.
 */
class StampQueueHeartbeat implements ShouldQueue
{
    use Queueable;

    public int $tries = 1;

    public int $timeout = 30;

    public function __construct(public readonly string $dispatchToken)
    {
        $this->onQueue(config('zecocm_ops.queue_heartbeat.queue', 'default'));
    }

    public function handle(): void
    {
        $updated = DB::table('queue_heartbeats')
            ->where('dispatch_token', $this->dispatchToken)
            ->update([
                'handled_at' => now(),
                'worker_identity' => gethostname() ?: 'unknown',
            ]);

        if ($updated === 0) {
            throw new \RuntimeException(
                "Queue heartbeat token {$this->dispatchToken} had no matching row to stamp - the dispatcher and worker disagree about what was sent."
            );
        }
    }
}
