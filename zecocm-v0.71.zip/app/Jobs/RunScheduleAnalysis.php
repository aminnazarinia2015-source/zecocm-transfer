<?php

namespace App\Jobs;

use App\Domain\Schedule\AnalysisCancelled;
use App\Domain\Schedule\AnalysisPipeline;
use App\Domain\Schedule\Outbox;
use App\Models\AnalysisRun;
use App\Tenancy\TenantContext;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Throwable;

class RunScheduleAnalysis implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public int $timeout = 180;

    public function __construct(public readonly int $analysisRunId)
    {
        $this->afterCommit();
    }

    public function handle(AnalysisPipeline $pipeline, Outbox $outbox): void
    {
        $priorTenantId = TenantContext::tenantId();
        $priorPlatformStaff = TenantContext::isPlatformStaff();
        $priorPlatformAdmin = TenantContext::isSupportMode();
        $run = AnalysisRun::withoutGlobalScopes()->findOrFail($this->analysisRunId);
        TenantContext::set($run->tenant_id);
        try {
            if ($run->status === 'completed' || $run->status === 'cancelled') {
                return;
            }
            if ($run->cancel_requested_at !== null) {
                $run->forceFill(['status' => 'cancelled', 'cancelled_at' => now(), 'finished_at' => now()])->save();

                return;
            }

            $run->forceFill([
                'status' => 'running',
                'started_at' => $run->started_at ?? now(),
                'error' => null,
            ])->save();
            $outbox->record($run->tenant_id, 'analysis_run', $run->id, 'schedule.analysis.started', [
                'analysis_id' => $run->id,
                'from_version_id' => $run->from_version_id,
                'to_version_id' => $run->to_version_id,
            ], "analysis:{$run->id}:started");

            $pipeline->run($run);
            $outbox->record($run->tenant_id, 'analysis_run', $run->id, 'schedule.analysis.completed', [
                'analysis_id' => $run->id,
            ], "analysis:{$run->id}:completed");
        } catch (AnalysisCancelled) {
            $outbox->record($run->tenant_id, 'analysis_run', $run->id, 'schedule.analysis.cancelled', [
                'analysis_id' => $run->id,
            ], "analysis:{$run->id}:cancelled");
        } catch (Throwable $exception) {
            $run->forceFill([
                'status' => 'failed',
                'error' => mb_substr($exception->getMessage(), 0, 4000),
                'finished_at' => now(),
            ])->save();
            throw $exception;
        } finally {
            if ($priorTenantId !== null) {
                TenantContext::set($priorTenantId, $priorPlatformStaff, $priorPlatformAdmin);
            } else {
                TenantContext::clear();
            }
        }
    }
}
