<?php

namespace App\Providers;

use App\Domain\Ops\DatabaseWriteHealthCheck;
use App\Domain\Ops\EvidenceStorageHealthCheck;
use App\Domain\Ops\MalwareScannerHealthCheck;
use App\Domain\Ops\QueueBacklogHealthCheck;
use App\Domain\Ops\QueueHeartbeatHealthCheck;
use App\Domain\Ops\SqlitePragmaHealthCheck;
use App\Domain\Ops\UploadLimitsHealthCheck;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Events\DiagnosingHealth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by(Str::lower((string) $request->input('email')).'|'.$request->ip());
        });

        // Self-serve contractor onboarding is the one anonymous write surface in the app —
        // throttled by IP to make it a much less useful target for scripted spam registrations.
        RateLimiter::for('registration', function (Request $request) {
            return Limit::perMinute(10)->by($request->ip());
        });

        // Possession of a signed onboarding URL is authorization to choose the
        // initial password, but it must not permit unlimited password attempts.
        RateLimiter::for('password-setup', function (Request $request) {
            return Limit::perMinute(10)->by((string) $request->route('user').'|'.$request->ip());
        });

        // Payment provider webhooks are also an anonymous surface (no Sanctum auth — the caller
        // is Stripe/PayPal, verified by signature instead). Found by a "what if" pass: unlike
        // /onboarding/register and /demo above, these routes had NO throttle at all — a garbage
        // flood costs little to send but, for PayPal, each request shaped like `{"id":...,
        // "event_type":...}` triggers a real outbound HTTP call to PayPal's own
        // verify-webhook-signature API before it's rejected, so an unthrottled flood is an easy
        // way to hammer both this app's outbound connection pool and PayPal's API. By-IP (not
        // global) so one noisy sender can't starve legitimate provider deliveries from other
        // IPs; limit is generous because real providers can burst-retry.
        RateLimiter::for('webhook', function (Request $request) {
            return Limit::perMinute(60)->by($request->ip());
        });

        // OPS-15: makes `/up` dependency-aware, per Codex's explicit ruling -
        // a failing dependency must make `/up` fail, and the check belongs
        // ON `/up` rather than a separate endpoint. Laravel dispatches this
        // event from its own built-in `/up` route before responding; an
        // uncaught exception from a listener turns the response into a 500.
        Event::listen(DiagnosingHealth::class, DatabaseWriteHealthCheck::class);

        // OPS-14: application-side conditions that can make /up truthful,
        // per Codex's ruling - each either passes silently or throws (no
        // new degrade vocabulary in /up's own HTTP contract); severity for
        // alerting purposes is logged separately inside each check. Failed
        // jobs are deliberately NOT here - see ReportFailedJobDelta's doc
        // comment for why that stays alert-only.
        Event::listen(DiagnosingHealth::class, QueueHeartbeatHealthCheck::class);
        Event::listen(DiagnosingHealth::class, QueueBacklogHealthCheck::class);
        Event::listen(DiagnosingHealth::class, EvidenceStorageHealthCheck::class);
        Event::listen(DiagnosingHealth::class, SqlitePragmaHealthCheck::class);

        // OPS-16: found during a real-world audit that drove the upload
        // endpoints end to end rather than just reading the code - a blank
        // SCHEDULE_MALWARE_SCANNER_BINARY (the default in .env.example)
        // silently refuses every schedule upload with a 503 and leaves every
        // document/photo permanently quarantined, unopenable, unreadable by
        // AI, forever - with the app otherwise looking fully healthy. Same
        // fail-loudly-not-silently pattern as EvidenceStorageHealthCheck.
        Event::listen(DiagnosingHealth::class, MalwareScannerHealthCheck::class);

        // OPS-17: found the same way as OPS-16 - actually uploading a real
        // 5MB test photo through the real endpoint, which failed with a
        // bare "The file failed to upload" 422. PHP's stock
        // upload_max_filesize/post_max_size (2M/8M) silently cap every
        // upload well below what nginx (400M) and this app's own
        // validation rules (100M documents/media, 25M schedules) already
        // promise, and nothing in bootstrap.sh ever raised them.
        Event::listen(DiagnosingHealth::class, UploadLimitsHealthCheck::class);
    }
}
