<?php

namespace App\Providers;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\ClaudeAssistant;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\RetrievalClient;
use App\Domain\Ai\RetrievedPassage;
use App\Domain\Ops\PlatformSecretStore;
use App\Tenancy\TenantContext;
use Illuminate\Support\ServiceProvider;

class AiServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Phase 1 retrieval: the project's OWN uploaded documents (specs,
        // plans, contract) indexed in MySQL fulltext. Licensed external
        // corpora (Greenbook, ICC) plug in behind this same interface
        // once the data licenses are signed - no code change upstream.
        $this->app->singleton(RetrievalClient::class, HybridKnowledgeRetriever::class);

        $this->app->singleton(AiAssistant::class, fn ($app) => new ClaudeAssistant(
            // config('zecocm_ai.api_key'), NOT env() directly - see the
            // comment on that config key for why: a raw env() call here
            // returns nothing once the app is running on a cached config,
            // which production always is.
            //
            // Wrapped through PlatformSecretStore::resolve() so an admin who
            // sets this key from System Settings sees it take effect on the
            // very next request - no config:clear/config:cache round trip.
            // The config() value stays as the fallback, so nothing changes
            // for a deploy that only ever sets ANTHROPIC_API_KEY in .env.
            apiKey: PlatformSecretStore::resolve('ANTHROPIC_API_KEY', (string) config('zecocm_ai.api_key', '')),
            retrieval: $app->make(RetrievalClient::class),
            model: (string) config('zecocm_ai.models.standard'),
        ));
    }
}
