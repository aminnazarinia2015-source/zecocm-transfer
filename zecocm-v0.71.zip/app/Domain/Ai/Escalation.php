<?php

namespace App\Domain\Ai;

/**
 * "I found the documents but this needs a licensed professional" -
 * a COMPLETE, first-class result, not an error (Aspect 31).
 *
 * TR-16: an escalation is itself an abstention, and Codex's closure rule for
 * TR-16 is that an abstention must identify its evidentiary basis rather
 * than being an unstructured prose reason - the same discipline
 * CitedSuggestion already enforces on the affirmative path (no claim without
 * a citation), applied here to the refusal path. `basis` names WHY this
 * result exists; the fields that back it up depend on which basis it is:
 *
 *  - BASIS_CONFLICT: `conflictCitations` holds >=2 distinct retrieved
 *    passages that were actually resolved against the real candidate set
 *    (see ClaudeAssistant::parseEscalation()) - never the model's bare
 *    unverified say-so that a conflict exists.
 *  - BASIS_INSUFFICIENT_EVIDENCE: passages were retrieved but do not
 *    establish the requested proposition. `conflictCitations` holds whatever
 *    relevant-but-incomplete passages were cited (may be empty) and
 *    `missingFact` names the specific fact or authority that is missing.
 *  - BASIS_UNGROUNDED_CLAIM: the model asserted CONFLICT or
 *    INSUFFICIENT_EVIDENCE but did not meet the grounding bar for that basis
 *    (not enough valid passage refs, or no refs and no missing-fact string).
 *    This is a distinct, visible outcome precisely so an ungrounded claim can
 *    never be promoted into looking like a verified conflict or a
 *    well-evidenced insufficiency - see CONTINUATION_BRIEF / closure-progress
 *    for the exact TR-16 acceptance cases this exists to satisfy.
 *  - BASIS_POLICY: every escalation this codebase already issued before
 *    TR-16 - category-level mandatory review (RefusalPolicy), service not
 *    configured, service unreachable, service error, malformed model
 *    response. These are decided by code, before or without regard to the
 *    model's own content judgment, so they carry no citations by default.
 */
final class Escalation extends AiResult
{
    public const BASIS_CONFLICT = 'conflict';

    public const BASIS_INSUFFICIENT_EVIDENCE = 'insufficient_evidence';

    public const BASIS_UNGROUNDED_CLAIM = 'ungrounded_claim';

    public const BASIS_POLICY = 'policy';

    /** @param list<Citation> $conflictCitations */
    public function __construct(
        public readonly string $reason,          // the specific ambiguity/conflict found
        public readonly string $routeTo,          // e.g. "structural engineer of record"
        public readonly array $conflictCitations = [],
        public readonly string $basis = self::BASIS_POLICY,
        public readonly ?string $missingFact = null,
    ) {}

    public function kind(): string
    {
        return 'escalation';
    }
}
