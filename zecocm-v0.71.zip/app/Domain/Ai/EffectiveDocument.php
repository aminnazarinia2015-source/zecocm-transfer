<?php

namespace App\Domain\Ai;

/**
 * Is this particular requirement currently operative?
 *
 * The question TRACE has to answer, and the one a version chain cannot. "Is this
 * PDF old" is a different question with a different answer, and answering the
 * second while claiming to answer the first is how a spec section that nobody
 * touched goes dark because an addendum changed two paragraphs elsewhere.
 *
 * The rules below are Codex's overlay contract, and every one of them exists
 * because the obvious shortcut is wrong.
 *
 *   SILENCE IS NOT SUPERSESSION. A passage no confirmed scope covers stays
 *   operative. Later issuance does not extinguish earlier text outside the
 *   scope that was actually confirmed. This is the whole point.
 *
 *   SUPPLEMENT AND CLARIFY RETIRE NOTHING. An additive addendum leaves both
 *   sources operative and the effective requirement is their combination.
 *   Treating an addition as a replacement silently deletes a requirement
 *   somebody still has to build to.
 *
 *   DELETE WITHOUT REPLACEMENT LEAVES A HOLE, AND THE HOLE IS THE ANSWER. If an
 *   addendum deletes a clause and puts nothing in its place, TRACE must not
 *   resurrect the deleted requirement merely because it is the only passage that
 *   addresses the question. It says no current requirement is established, cites
 *   the deletion, and labels the old text HISTORICAL.
 *
 *   A PROPOSAL IS NOT AN OVERLAY. A scope inferred from wording is a proposal
 *   until a steward confirms it. Letting a semantic guess retire contract text
 *   would make AI interpretation into contract amendment.
 *
 *   AN UNRESOLVED SCOPE POISONS THE ANSWER RATHER THAN BEING IGNORED. If the
 *   record shows a modification whose extent cannot be established, TRACE
 *   refuses to pick a governing requirement instead of quietly choosing the
 *   convenient one.
 */
final class EffectiveDocument
{
    public const CURRENT = 'current';
    public const SUPERSEDED = 'superseded';
    public const DELETED = 'deleted';
    public const SUPPLEMENTED = 'supplemented';
    public const UNRESOLVED = 'unresolved';

    public const REPLACE = 'replace';
    public const DELETE = 'delete';
    public const SUPPLEMENT = 'supplement';
    public const CLARIFY = 'clarify';

    public const CONFIRMED = 'confirmed';
    public const PROPOSED = 'proposed';
    public const UNRESOLVED_STATUS = 'unresolved';

    /**
     * @param  array{section_ref: ?string, sheet_ref: ?string, id: int, body_sha256?: ?string}  $passage
     * @param  list<array<string,mixed>>  $scopes  scopes on confirmed edges pointing at this passage's version
     * @return array{state: string, by: ?string, scope: ?array<string,mixed>, note: ?string}
     */
    public static function stateOf(array $passage, array $scopes): array
    {
        $applicable = array_values(array_filter($scopes, fn ($s) => self::covers($passage, $s)));

        if ($applicable === []) {
            // Silence. Not supersession.
            return self::result(self::CURRENT, null, null, null);
        }

        // An unresolved or merely proposed scope that touches this passage means
        // the record shows a modification we cannot place. That is reported, not
        // ignored and not applied.
        foreach ($applicable as $scope) {
            if (($scope['status'] ?? self::PROPOSED) !== self::CONFIRMED) {
                return self::result(self::UNRESOLVED, $scope['superseding_title'] ?? null, $scope,
                    'A modification touching this passage is recorded but its extent has not been confirmed. '
                    .'TRACE will not select a governing requirement until the modification scope is confirmed.');
            }
        }

        // Locator drift. The text under the locator is not the text the scope was
        // confirmed against, so the overlay may be pointing somewhere else now.
        foreach ($applicable as $scope) {
            $expected = $scope['target_content_hash'] ?? null;
            $actual = $passage['body_sha256'] ?? null;
            if ($expected !== null && $actual !== null && $expected !== $actual) {
                return self::result(self::UNRESOLVED, $scope['superseding_title'] ?? null, $scope,
                    'This passage has been re-extracted since the modification was confirmed against it, so the '
                    .'recorded scope may no longer point at the same text. It must be remapped before it is applied.');
            }
        }

        foreach ($applicable as $scope) {
            if (($scope['relation'] ?? null) === self::DELETE) {
                return self::result(self::DELETED, $scope['superseding_title'] ?? null, $scope,
                    'This provision was deleted and no operative replacement has been identified. TRACE will not '
                    .'treat the deleted requirement as current.');
            }
        }

        foreach ($applicable as $scope) {
            if (($scope['relation'] ?? null) === self::REPLACE) {
                return self::result(self::SUPERSEDED, $scope['superseding_title'] ?? null, $scope, null);
            }
        }

        // Only supplements and clarifications remain, and neither retires text.
        return self::result(self::SUPPLEMENTED, $applicable[0]['superseding_title'] ?? null, $applicable[0],
            'This provision remains operative. The later document adds to it rather than replacing it, so the '
            .'effective requirement is the combination of both.');
    }

    /** May a passage in this state control an answer? */
    public static function mayControl(string $state): bool
    {
        return $state === self::CURRENT || $state === self::SUPPLEMENTED;
    }

    /**
     * Does this scope cover this passage?
     *
     * Matching is deliberately conservative and structural. Nothing here matches
     * on meaning - a scope reaches a passage because a steward confirmed a
     * locator that identifies it, never because the words look similar.
     *
     * @param  array<string,mixed>  $passage
     * @param  array<string,mixed>  $scope
     */
    private static function covers(array $passage, array $scope): bool
    {
        $type = $scope['scope_type'] ?? 'document';

        if ($type === 'document') {
            return true;
        }

        if ($type === 'sheet' || $type === 'detail') {
            $target = self::normalise($scope['target_sheet_ref'] ?? null);

            return $target !== null && self::normalise($passage['sheet_ref'] ?? null) === $target;
        }

        if ($type === 'passage_range') {
            $start = $scope['start_passage_id'] ?? null;
            $end = $scope['end_passage_id'] ?? $start;

            return $start !== null && (int) $passage['id'] >= (int) $start && (int) $passage['id'] <= (int) $end;
        }

        // section, clause, schedule: a structural path. "3.2" covers "3.2.B",
        // because deleting a section deletes what is inside it - but "3.2" must
        // never cover "3.20", which is a different section that merely starts
        // with the same characters.
        $target = self::normalise($scope['target_section_ref'] ?? null);
        $actual = self::normalise($passage['section_ref'] ?? null);

        if ($target === null || $actual === null) {
            return false;
        }

        return $actual === $target || str_starts_with($actual, $target.'.');
    }

    private static function normalise(?string $ref): ?string
    {
        if ($ref === null) {
            return null;
        }

        $ref = strtolower(trim($ref));
        // Trailing separators are formatting, not identity: "3.2.B." is "3.2.b".
        $ref = rtrim($ref, ". \t");

        return $ref === '' ? null : $ref;
    }

    /** @return array{state: string, by: ?string, scope: ?array<string,mixed>, note: ?string} */
    private static function result(string $state, ?string $by, ?array $scope, ?string $note): array
    {
        return ['state' => $state, 'by' => $by, 'scope' => $scope, 'note' => $note];
    }
}
