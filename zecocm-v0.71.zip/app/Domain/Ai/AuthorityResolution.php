<?php

namespace App\Domain\Ai;

/**
 * Which source actually controls, as opposed to which one matched best.
 *
 * Codex's invariant, and it is the whole class in one sentence:
 *
 *   A source controls only if it is OPERATIVE, APPLICABLE to the proposition at
 *   issue, and AUTHORIZED TO PREVAIL over any incompatible alternative. Newer
 *   is not controlling by itself; higher precedence is not controlling outside
 *   its scope; RELEVANCE IS NOT AUTHORITY.
 *
 * Three conditions, and ZecoCM had two of them built and not speaking to each
 * other. EffectiveDocument answers OPERATIVE. DocumentPrecedence answers
 * AUTHORIZED TO PREVAIL. Nothing answered APPLICABLE, which is the axis that
 * produces confident wrong answers: a change order can be perfectly current,
 * outrank the drawing, and say nothing whatever about the area being asked
 * about. Retrieval ranked by relevance will quote it anyway, because it is the
 * best textual match.
 *
 * TWO THINGS THIS DELIBERATELY DOES NOT DO.
 *
 * It does not refuse whenever two documents mention the same subject. That
 * would make the system useless, and Codex was explicit: recency is a SECONDARY
 * axis, not a rival to precedence. A newer, lower-ranked source that does not
 * amend the higher one is context, not conflict.
 *
 * It does not settle a genuine conflict. Where two sources are both operative,
 * both applicable, and incompatible, and the precedence order does not separate
 * them, that is a real contract ambiguity and the answer is to surface both
 * with their citations. Picking one would be this software making a contract
 * interpretation, which is the one thing it exists not to do.
 */
final class AuthorityResolution
{
    public const CONTROLS = 'controls';
    public const CONTEXT = 'context';
    public const NOT_APPLICABLE = 'not_applicable';
    public const NOT_OPERATIVE = 'not_operative';
    public const UNRESOLVED_APPLICABILITY = 'unresolved_applicability';
    public const CONFLICT = 'conflict';

    // What an instrument DOES to the contract, which is not what kind of
    // document it is.
    public const EFFECT_ORIGINAL = 'original';
    public const EFFECT_AMEND = 'amend';
    public const EFFECT_INTERPRET = 'interpret';
    public const EFFECT_SUPPLEMENT = 'supplement';
    public const EFFECT_DIRECTIVE = 'directive';
    public const EFFECT_EVIDENCE_ONLY = 'evidence_only';

    /** Effects that can change what the contract requires. */
    public const MODIFYING_EFFECTS = [self::EFFECT_AMEND, self::EFFECT_DIRECTIVE];

    public const DIMENSIONS = ['project', 'area', 'system', 'phase'];

    /**
     * Does this source reach the thing being asked about?
     *
     * The rules that matter here are both about silence. A source with NO tag
     * on a dimension is silent on it and therefore does not exclude itself -
     * a specification with no area tag applies site-wide, which is the sane
     * default and the common case. But an UNRESOLVED tag is different: somebody
     * started to say where this applies and did not finish, and treating that
     * as "applies everywhere" would turn an unfinished thought into authority.
     *
     * @param  list<array{dimension: string, value: string, mode: string, status: string}>  $tags
     * @param  array<string,string>  $subject  e.g. ['area' => 'Area A', 'system' => 'irrigation']
     * @return array{state: string, reason: ?string}
     */
    public static function applicability(array $tags, array $subject): array
    {
        foreach (self::DIMENSIONS as $dimension) {
            $asked = $subject[$dimension] ?? null;

            $forDimension = array_values(array_filter($tags, fn ($t) => ($t['dimension'] ?? null) === $dimension));

            if ($forDimension === []) {
                // Silent. Applies unless something says otherwise.
                continue;
            }

            $unresolved = array_filter($forDimension, fn ($t) => ($t['status'] ?? 'proposed') !== 'confirmed');

            if ($unresolved !== []) {
                return ['state' => self::UNRESOLVED_APPLICABILITY,
                    'reason' => 'Where this source applies by '.$dimension.' has been recorded but not confirmed. '
                        .'An unconfirmed scope is an unfinished reading of the document, and treating it as applying '
                        .'everywhere would turn that into authority.'];
            }

            if ($asked === null) {
                // The source scopes itself by a dimension the question does not
                // specify. Not a refusal, but not a controlling answer either -
                // the question has to get more specific before this can control.
                return ['state' => self::UNRESOLVED_APPLICABILITY,
                    'reason' => 'This source applies only to particular '.$dimension.'s, and the question does not say '
                        .'which '.$dimension.' it concerns. Whether it reaches this proposition cannot be established.'];
            }

            $excluded = array_filter($forDimension, fn ($t) => ($t['mode'] ?? 'includes') === 'excludes'
                && strcasecmp((string) $t['value'], $asked) === 0);

            if ($excluded !== []) {
                return ['state' => self::NOT_APPLICABLE,
                    'reason' => 'This source expressly excludes '.$dimension.' "'.$asked.'".'];
            }

            $includes = array_values(array_filter($forDimension, fn ($t) => ($t['mode'] ?? 'includes') === 'includes'));

            if ($includes !== []) {
                $matched = array_filter($includes, fn ($t) => strcasecmp((string) $t['value'], $asked) === 0);

                if ($matched === []) {
                    return ['state' => self::NOT_APPLICABLE,
                        'reason' => 'This source applies to '.$dimension.' '
                            .implode(', ', array_map(fn ($t) => '"'.$t['value'].'"', $includes))
                            .', not to "'.$asked.'".'];
                }
            }
        }

        return ['state' => self::CONTROLS, 'reason' => null];
    }

    /**
     * Resolve a set of candidate sources against one proposition.
     *
     * @param  list<array<string,mixed>>  $candidates  each with: id, label, citation,
     *   operative (bool), applicability_tags, authority_effect, effect_conferred_by_contract,
     *   precedence_rank (int, lower wins), issued_on
     * @param  array<string,string>  $subject
     * @param  array{status: string, citation?: ?string}  $precedenceOrder
     * @return array<string,mixed>
     */
    public static function resolve(array $candidates, array $subject, array $precedenceOrder): array
    {
        $assessed = [];

        foreach ($candidates as $candidate) {
            $assessed[] = $candidate + self::assess($candidate, $subject);
        }

        $controlling = array_values(array_filter($assessed, fn ($c) => $c['state'] === self::CONTROLS));
        $unresolved = array_values(array_filter($assessed, fn ($c) => $c['state'] === self::UNRESOLVED_APPLICABILITY));

        // An unresolved applicability POISONS the answer rather than being
        // skipped over. Codex's test case: remove the confirmed Area C scope
        // from CO-7 and the correct answer is REFUSE, not the next-ranked
        // source's number. Falling through to a lower-ranked source would
        // silently answer a question the record can no longer settle.
        if ($unresolved !== []) {
            return self::out(self::UNRESOLVED_APPLICABILITY, null, $assessed,
                'A source that may or may not reach this question has unconfirmed applicability: '
                .implode('; ', array_map(fn ($c) => $c['label'].' - '.$c['reason'], $unresolved))
                .'. ZecoCM will not answer past it. Resolving the scope is what settles this, not ranking around it.');
        }

        if ($controlling === []) {
            return self::out(self::NOT_APPLICABLE, null, $assessed,
                'No governed source both remains operative and reaches this question.');
        }

        if (count($controlling) === 1) {
            return self::out(self::CONTROLS, $controlling[0], $assessed,
                $controlling[0]['label'].' controls: it is operative, it reaches this question, and nothing '
                .'incompatible outranks it.');
        }

        // More than one survivor. Precedence decides, and only a CONFIRMED
        // precedence order may decide it.
        if (($precedenceOrder['status'] ?? 'unresolved') !== 'confirmed') {
            return self::out(self::CONFLICT, null, $assessed,
                count($controlling).' sources are each operative and applicable to this question, and the contract\'s '
                .'own order of precedence is not confirmed. ZecoCM\'s default order is a labelled reference heuristic '
                .'and is NOT a substitute for the contract\'s order, so it will not be used to decide this. Both are '
                .'shown with their citations.');
        }

        usort($controlling, fn ($a, $b) => ($a['precedence_rank'] ?? PHP_INT_MAX) <=> ($b['precedence_rank'] ?? PHP_INT_MAX));

        $top = $controlling[0];
        $rivals = array_values(array_filter($controlling,
            fn ($c) => ($c['precedence_rank'] ?? PHP_INT_MAX) === ($top['precedence_rank'] ?? PHP_INT_MAX)));

        if (count($rivals) > 1) {
            return self::out(self::CONFLICT, null, $assessed,
                'Two sources of EQUAL precedence both reach this question and neither amends the other. That is a '
                .'contract ambiguity, not something this software may settle by choosing. Both are shown.');
        }

        // Newer-but-lower-ranked sources are CONTEXT, not conflict. Recency is
        // a secondary axis, not a rival to precedence, and refusing every time
        // a later document mentions the same subject would make the system
        // useless.
        $context = array_values(array_filter($controlling, fn ($c) => $c !== $top));

        return self::out(self::CONTROLS, $top, $assessed,
            $top['label'].' controls under the contract\'s order of precedence ('
            .($precedenceOrder['citation'] ?? 'confirmed order').').'
            .($context !== []
                ? ' '.count($context).' later or lower-ranked source(s) also speak to this and are shown as context: '
                    .implode(', ', array_column($context, 'label')).'. Being newer does not make a source controlling.'
                : ''));
    }

    /**
     * @param  array<string,mixed>  $candidate
     * @param  array<string,string>  $subject
     * @return array{state: string, reason: ?string}
     */
    private static function assess(array $candidate, array $subject): array
    {
        if (! ($candidate['operative'] ?? true)) {
            return ['state' => self::NOT_OPERATIVE,
                'reason' => 'This passage has been superseded or deleted and is no longer operative.'];
        }

        // An instrument claiming an effect the contract never gave it. The RFI
        // response that directs changed work is the case: it is real evidence
        // of what somebody said, and it is not a contract modification unless
        // the contract says that instrument can be one, or a later change order
        // formalises it.
        $effect = (string) ($candidate['authority_effect'] ?? self::EFFECT_ORIGINAL);

        if (in_array($effect, self::MODIFYING_EFFECTS, true)
            && ! ($candidate['effect_conferred_by_contract'] ?? false)
            && ($candidate['formalised_by_change_order_id'] ?? null) === null) {
            return ['state' => self::CONTEXT,
                'reason' => 'This instrument reads as a '.$effect.', but the governing contract has not been recorded '
                    .'as giving an instrument of this kind that effect, and no change order formalises it. It is '
                    .'evidence of what was said, not a modification of what is required.'];
        }

        if ($effect === self::EFFECT_EVIDENCE_ONLY) {
            return ['state' => self::CONTEXT,
                'reason' => 'Recorded as evidence only. It does not state a requirement.'];
        }

        return self::applicability((array) ($candidate['applicability_tags'] ?? []), $subject);
    }

    /** @return array<string,mixed> */
    private static function out(string $state, ?array $controlling, array $assessed, string $message): array
    {
        return [
            'state' => $state,
            'controlling' => $controlling === null ? null : [
                'id' => $controlling['id'] ?? null,
                'label' => $controlling['label'] ?? null,
                'citation' => $controlling['citation'] ?? null,
            ],
            'considered' => array_map(fn ($c) => [
                'id' => $c['id'] ?? null,
                'label' => $c['label'] ?? null,
                'citation' => $c['citation'] ?? null,
                'state' => $c['state'],
                'reason' => $c['reason'],
            ], $assessed),
            'message' => $message,
            // Repeated in the payload because this is the sentence somebody
            // will otherwise supply for themselves, wrongly.
            'invariant' => 'A source controls only if it is operative, applicable to the proposition at issue, and '
                .'authorised to prevail over any incompatible alternative. Newer is not controlling by itself; higher '
                .'precedence is not controlling outside its scope; relevance is not authority.',
        ];
    }
}
