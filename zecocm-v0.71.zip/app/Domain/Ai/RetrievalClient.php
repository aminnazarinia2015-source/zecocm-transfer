<?php

namespace App\Domain\Ai;

interface RetrievalClient
{
    /** @return list<RetrievedPassage> */
    public function retrieve(string $query, JurisdictionScope $scope): array;
}
