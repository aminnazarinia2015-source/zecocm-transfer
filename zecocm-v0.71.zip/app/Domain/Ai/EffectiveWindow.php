<?php

namespace App\Domain\Ai;

/**
 * TR-13: a knowledge source version carries `effective_from`/`effective_until`
 * (present in the schema since v0.?? ingestion work) and nothing ever consulted
 * either one. A statute amended effective next month, or a prevailing-wage
 * determination that expired last year, was retrievable and rankable exactly
 * like current text - the same "written by a human, read by nothing" shape as
 * D5 before TR-17 closed it.
 *
 * This is deliberately narrow: it answers one question, "is this version's
 * text in force as of the reference instant," and nothing else. It does not
 * replace EffectiveDocument's overlay/supersession logic (a different axis -
 * a version can be effective-dated AND separately superseded by a later
 * instrument) and does not decide jurisdiction (see JurisdictionMatch).
 */
final class EffectiveWindow
{
    /**
     * Fails closed on the side that matters for a statute: an explicit
     * `effective_until` in the past means the text has lapsed and must not
     * control an answer, and an explicit `effective_from` in the future means
     * it has not yet taken effect. Absent bounds are unbounded in that
     * direction - most sources (project specs, contracts) never carry an
     * effective window at all, and treating "no data" as "not yet effective"
     * would silently blind retrieval to the majority of this codebase's
     * content, which is not what TR-13 is about.
     */
    public static function inForce(?\DateTimeInterface $effectiveFrom, ?\DateTimeInterface $effectiveUntil, \DateTimeInterface $asOf): bool
    {
        if ($effectiveFrom !== null && $asOf < $effectiveFrom) {
            return false;
        }

        if ($effectiveUntil !== null && $asOf > $effectiveUntil) {
            return false;
        }

        return true;
    }
}
