<?php

namespace App\Domain\Ai;

final class CitedSuggestion extends AiResult
{
    /** @param list<Citation> $citations */
    public function __construct(
        public readonly string $text,
        public readonly array $citations,
    ) {
        if ($citations === []) {
            throw new \InvalidArgumentException(
                'A suggestion without a citation is not allowed to exist. Use NoMatch or Escalation.'
            );
        }
    }

    public function kind(): string
    {
        return 'suggestion';
    }
}
