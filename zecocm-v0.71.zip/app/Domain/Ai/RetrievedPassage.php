<?php

namespace App\Domain\Ai;

use App\Domain\Knowledge\InstructionTrust;
use App\Domain\Knowledge\Ocr\ExtractionReliability;

final class RetrievedPassage
{
    public function __construct(
        public readonly string $source,
        public readonly ?string $edition,
        public readonly string $text,
        public readonly ?int $passageId = null,
        public readonly ?string $sourcePublicId = null,
        public readonly ?string $sourceHash = null,
        public readonly ?int $pageFrom = null,
        public readonly ?int $pageTo = null,
        public readonly ?string $sectionRef = null,
        public readonly ?string $authorityLevel = null,
        /** Document type, used for order-of-precedence ranking. */
        public readonly ?string $sourceType = null,
        /** Lower governs. Derived from the contract's own order of precedence where recorded. */
        public readonly ?int $precedenceRank = null,
        /** governing | reference | assertion. See SourceClass. */
        public readonly ?string $sourceClass = null,
        /**
         * Whether this passage may control an answer, or is context only.
         * Reference and assertion material is useful and retrievable; it is never
         * allowed to decide what the contract requires.
         */
        public readonly bool $controlsAnswer = false,
        /**
         * Title of the source that superseded this one, when a steward has
         * recorded a supersedes edge. Non-null means: this text is no longer the
         * governing version and must be shown as history, never as the answer.
         */
        public readonly ?string $supersededBy = null,
        /**
         * TR-15: whether text inside this passage's body, source title, or any
         * other field may ever be read as an instruction to the model. It is
         * NEVER the caller's job to decide this per-question - it is a property
         * of where the passage came from, set once at retrieval, and it never
         * moves regardless of what the text says or how the answer turns out.
         *
         * Defaults to InstructionTrust::TENANT_RECORD because every existing
         * retrieval path (HybridKnowledgeRetriever) reads only this tenant's own
         * governed knowledge_passages. If a future retrieval path surfaces
         * externally acquired material (D4 / AcquiredDocument), that path MUST
         * set this explicitly to InstructionTrust::EXTERNAL_UNTRUSTED - it must
         * never be left to inherit this default silently.
         */
        public readonly string $instructionTrust = InstructionTrust::TENANT_RECORD,
        /**
         * TR-14: the three portable locators, alongside `sourceHash`, that
         * together let `CitationAnchor::build()` compose an address that
         * survives export - see that class's doc comment. `passageId` above
         * remains for internal use only; it is never the addressable anchor.
         */
        public readonly ?int $versionNumber = null,
        public readonly ?int $ordinal = null,
        public readonly ?string $bodyHash = null,
        /**
         * D4/Codex's ruling: source authority and extraction reliability are
         * two separate axes. These three fields carry the SECOND axis only -
         * they must never be read anywhere as a ranking or authority input
         * (see HybridKnowledgeRetriever's sort comparator, which is and stays
         * blind to all three). extractionReliability is the deterministic,
         * code-computed classification (App\Domain\Knowledge\Ocr\ExtractionReliability)
         * that GovernedContextBuilder uses to decide whether a passage needs
         * a visible caveat before the model ever sees it - never left to the
         * model to judge extraction quality for itself.
         */
        public readonly ?string $extractionMethod = null,
        public readonly ?float $extractionConfidence = null,
        public readonly string $extractionReliability = ExtractionReliability::RELIABLE,
    ) {}
}
