<?php

namespace App\Domain\Ai;

use App\Models\Project;

/**
 * Which document governs when two of them disagree.
 *
 * Newer is not the same as controlling. A change order is newer than the contract
 * without superseding it; an addendum outranks a plan sheet regardless of date; a
 * referenced standard specification yields to the special provision that modified
 * it. Retrieval that ranks only by textual match will happily quote the losing
 * document with total confidence, which on a public works project is how a
 * contractor ends up building to the wrong requirement and paying for it.
 *
 * The order below is the default from Zeco's own Greenbook AI Deployment Policy,
 * section 5. It is a DEFAULT only: where the executed contract states its own order
 * of precedence, that order governs and is read from the project record
 * (org_structure.precedence). The contract always decides how the contract is read.
 *
 * This class never resolves a conflict on its own authority. It ranks, and it
 * reports. Where two sources of different rank speak to the same question, the
 * conflict is surfaced for a human - it is not silently settled by dropping the
 * lower-ranked passage.
 */
final class DocumentPrecedence
{
    /**
     * Default order, highest authority first. Index 0 governs.
     *
     * @var list<string>
     */
    public const DEFAULT_ORDER = [
        'contract',        // executed contract and amendments
        'addendum',        // addenda and bid documents
        'special_provisions',
        'drawing',         // approved plans
        'rfi_response',    // RFIs, submittals, change orders as applicable
        'specification',   // referenced standard specifications, incl. the identified Greenbook edition
        'standard',
        'regulation',
        'policy',
        'manufacturer',    // manufacturer instructions and other referenced standards
        'correspondence',
        'lesson',
    ];

    /** @var list<string> */
    private array $order;

    /** @param list<string>|null $order */
    public function __construct(?array $order = null)
    {
        $this->order = $order ?: self::DEFAULT_ORDER;
    }

    /**
     * Build from the project record. If the contract recorded its own order of
     * precedence, that governs; otherwise the policy default applies. The caller
     * can always tell which happened via contractSpecified().
     */
    /** @var array<string,array{0:string,1:float}> label => [type, confidence] */
    private array $labelMap = [];

    /** @var list<string> labels we could not map from the alias dictionary */
    private array $unmapped = [];

    /**
     * Build from the project record. If the contract recorded its own order of
     * precedence, that governs; otherwise the policy default applies.
     */
    public static function forProject(Project $project): self
    {
        $recorded = $project->org_structure['precedence'] ?? null;
        if (! is_array($recorded) || $recorded === []) {
            return new self;
        }

        $mapped = [];
        $labelMap = [];
        $unmapped = [];

        foreach ($recorded as $label) {
            [$key, $method, $confidence] = self::classifyLabel((string) $label);

            if ($key === null) {
                $unmapped[] = (string) $label;

                continue;
            }

            // A heuristic guess never silently sets precedence. Raised by Codex:
            // "Heuristic-normalized labels must not silently determine precedence."
            // We record it so a steward can confirm or correct it, but it does not
            // move the order until they do.
            if ($method === 'heuristic') {
                $unmapped[] = (string) $label;
                $labelMap[(string) $label] = [$key, $confidence];

                continue;
            }

            $labelMap[(string) $label] = [$key, $confidence];
            if (! in_array($key, $mapped, true)) {
                $mapped[] = $key;
            }
        }

        // Anything the contract did not name keeps its default relative position
        // BELOW everything the contract did name. Silence is not promotion.
        foreach (self::DEFAULT_ORDER as $key) {
            if (! in_array($key, $mapped, true)) {
                $mapped[] = $key;
            }
        }

        $instance = new self($mapped);
        $instance->labelMap = $labelMap;
        $instance->unmapped = $unmapped;

        return $instance;
    }

    /**
     * Labels the contract used that we could not map with confidence. These are
     * shown to a steward rather than guessed at, because a mis-ranked contract
     * instrument is exactly the error that decides a dispute the wrong way.
     *
     * @return list<string>
     */
    public function needsClassification(): array
    {
        return $this->unmapped;
    }

    public function contractSpecified(Project $project): bool
    {
        $recorded = $project->org_structure['precedence'] ?? null;

        return is_array($recorded) && $recorded !== [];
    }

    /**
     * Rank of a document type. Lower governs. An unknown type sorts last rather
     * than first - an unrecognised document never outranks a known one.
     */
    public function rank(?string $sourceType): int
    {
        if ($sourceType === null) {
            return count($this->order) + 1;
        }

        $index = array_search($sourceType, $this->order, true);

        return $index === false ? count($this->order) + 1 : (int) $index;
    }

    public function governs(?string $a, ?string $b): bool
    {
        return $this->rank($a) < $this->rank($b);
    }

    /** @return list<string> */
    public function order(): array
    {
        return $this->order;
    }

    /**
     * Real contracts do not write enum keys. They write "Supplementary
     * Conditions", "Issued-for-Construction Drawings", "Division 00". This alias
     * dictionary is the authoritative mapping; anything not in it is a guess and
     * is treated as one.
     *
     * The list is Codex's, drawn from language that actually appears in public
     * works contracts. Order matters only in that longer, more specific aliases
     * are checked before shorter ones.
     *
     * @var array<string,string>
     */
    private const ALIASES = [
        'agreement' => 'contract',
        'the agreement' => 'contract',
        'construction contract' => 'contract',
        'contract' => 'contract',
        'contract documents' => 'contract',
        'modifications' => 'contract',
        'division 00' => 'contract',
        'procurement and contracting requirements' => 'contract',

        'addenda' => 'addendum',
        'addendum' => 'addendum',
        'clarifications issued before bid' => 'addendum',
        'written interpretations' => 'addendum',
        'bid clarifications' => 'addendum',

        'special provisions' => 'special_provisions',
        'special conditions' => 'special_provisions',
        'supplementary conditions' => 'special_provisions',
        'supplemental conditions' => 'special_provisions',
        'general conditions' => 'special_provisions',
        'agency supplements' => 'special_provisions',

        'plans' => 'drawing',
        'drawings' => 'drawing',
        'contract drawings' => 'drawing',
        'issued-for-construction drawings' => 'drawing',
        'issued for construction drawings' => 'drawing',
        'standard plans' => 'drawing',
        'approved shop drawings' => 'drawing',
        'shop drawings' => 'drawing',

        'specifications' => 'specification',
        'technical specifications' => 'specification',
        'contract specifications' => 'specification',
        'standard specifications' => 'specification',
        'standard specifications and standard plans' => 'specification',
        'project manual' => 'specification',
        'referenced standards' => 'standard',

        'change orders' => 'rfi_response',
        'construction change directives' => 'rfi_response',
        'field orders' => 'rfi_response',
        'owner directives' => 'rfi_response',
        'architect\'s supplemental instructions' => 'rfi_response',
        'approved substitutions' => 'rfi_response',
        'rfi responses' => 'rfi_response',
        'approved submittals' => 'rfi_response',

        'geotechnical report' => 'reference_report',
        'soils report' => 'reference_report',

        'manufacturer instructions' => 'manufacturer',
        "manufacturer's instructions" => 'manufacturer',
    ];

    /**
     * @return array{0: ?string, 1: string, 2: float} [type, method, confidence]
     */
    public static function classifyLabel(string $label): array
    {
        $l = mb_strtolower(trim($label));
        $l = trim($l, " \t.;,");

        if (isset(self::ALIASES[$l])) {
            return [self::ALIASES[$l], 'exact_alias', 1.0];
        }

        // Fallback only. Longest alias first so "contract drawings" is not eaten
        // by "contract" - that exact collision would have ranked every drawing as
        // the executed agreement.
        $aliases = self::ALIASES;
        uksort($aliases, fn ($a, $b) => mb_strlen($b) <=> mb_strlen($a));
        foreach ($aliases as $alias => $type) {
            if (str_contains($l, $alias)) {
                return [$type, 'heuristic', 0.5];
            }
        }

        return [null, 'unmapped', 0.0];
    }

}
