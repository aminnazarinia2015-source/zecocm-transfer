<?php

namespace App\Domain\Ai;

use App\Domain\Knowledge\Ocr\ExtractionReliability;

/**
 * Production driver: calls the Anthropic API with a system prompt that
 * hard-codes the ZecoCM posture - answer only from supplied retrieved
 * passages, cite every claim, output escalation when documents conflict
 * or the category demands licensed judgment. API key from env; retrieval
 * is performed BEFORE the model call and passed in as context, so the
 * model can only cite what it was actually given.
 *
 * TR-15: this class never builds the model request body itself. Every
 * passage and every rule of the system prompt passes through
 * GovernedContextBuilder, the one place retrieved content is allowed to
 * become part of a model call.
 */
final class ClaudeAssistant implements AiAssistant
{
    public function __construct(
        private readonly string $apiKey,
        private readonly RetrievalClient $retrieval,
        private readonly string $model = 'claude-sonnet-4-5',
    ) {}

    public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): AiResult
    {
        // Every path out of this method carries what it cost. The three below
        // are measured zeros - the provider was never called - and saying so
        // explicitly is what lets the budget tell zero apart from unknown.
        if ($policy->mustEscalate($category)) {
            return (new Escalation(
                reason: "Category '{$category}' is configured for licensed review regardless of document clarity.",
                routeTo: 'licensed design professional of record',
            ))->withSpend(TokenSpend::none($this->model));
        }

        if ($this->apiKey === '') {
            return (new Escalation(
                reason: 'AI service is not configured on this server yet (no API key). Routed for human review instead of guessing.',
                routeTo: 'platform administrator',
            ))->withSpend(TokenSpend::none($this->model));
        }

        $passages = $this->retrieval->retrieve($task, $scope);
        if ($passages === []) {
            return (new NoMatch(implode(', ', $scope->corpora)))->withSpend(TokenSpend::none($this->model));
        }

        // The HTTP call itself is isolated here so the whole class above it
        // is testable without network. See tests/DomainTest.php.
        return $this->callModel($task, $passages);
    }

    /**
     * TR-15: this is the ONLY place in the codebase that may send passage
     * content to the model, and it does so only through
     * GovernedContextBuilder::build() - never by concatenating passage text
     * into a string itself. See GovernedContextBuilderTest for the structural
     * assertion that this stays true.
     *
     * @param  list<RetrievedPassage>  $passages
     */
    private function callModel(string $task, array $passages): AiResult
    {
        $governed = GovernedContextBuilder::build($task, $passages);

        $body = json_encode([
            'model' => $this->model,
            'max_tokens' => 1024,
            'system' => $governed['system'],
            'messages' => [[
                'role' => 'user',
                'content' => $governed['content'],
            ]],
        ], JSON_THROW_ON_ERROR);

        $ch = curl_init('https://api.anthropic.com/v1/messages');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => [
                'content-type: application/json',
                'x-api-key: '.$this->apiKey,
                'anthropic-version: 2023-06-01',
            ],
            CURLOPT_TIMEOUT => 60,
        ]);
        $raw = curl_exec($ch);
        if ($raw === false) {
            // Network failure NEVER degrades to a guess - and it does not
            // degrade to a free run either. The request may well have been
            // served and billed before the connection dropped, so this is
            // UNMEASURED rather than zero.
            return (new Escalation('AI service unreachable - no suggestion offered.', 'manual review'))
                ->withSpend(TokenSpend::unmeasured($this->model));
        }
        curl_close($ch);

        return $this->parse($raw, $passages);
    }

    /** @param list<RetrievedPassage> $passages */
    private function parse(string $raw, array $passages): AiResult
    {
        $data = json_decode($raw, true);
        // Read off the response itself, before any branch. An error response and
        // a malformed one both cost something; only the reasons differ.
        $spend = is_array($data)
            ? TokenSpend::fromAnthropic($data, $this->model)
            : TokenSpend::unmeasured($this->model);

        if (isset($data['error'])) {
            // Surface the REAL cause (billing, auth, rate limit) - never
            // disguise an infrastructure failure as a content problem.
            return (new Escalation(
                reason: 'AI service error: '.($data['error']['message'] ?? $data['error']['type'] ?? 'unknown').' No suggestion offered.',
                routeTo: 'platform administrator',
            ))->withSpend($spend);
        }
        $text = $data['content'][0]['text'] ?? '';
        $decoded = json_decode($text, true);
        if (! is_array($decoded)) {
            // Tolerate markdown fences / prose around the JSON object.
            if (preg_match('/\{.*\}/s', $text, $m)) {
                $decoded = json_decode($m[0], true);
            }
        }
        if (! is_array($decoded) || ! isset($decoded['kind'])) {
            return (new Escalation('AI response did not match the required cited format - no suggestion offered.', 'manual review'))
                ->withSpend($spend);
        }
        $now = new \DateTimeImmutable;

        if ($decoded['kind'] === 'suggestion') {
            $refs = $this->resolveRefs($decoded['passage_refs'] ?? [], $passages);
            if ($refs === [] || trim((string) ($decoded['text'] ?? '')) === '') {
                return (new Escalation(
                    'AI output did not provide a valid supporting passage for every answer - no suggestion offered.',
                    'manual evidence review',
                ))->withSpend($spend);
            }

            // D4/Codex's ruling: the RESULT layer, not the model, enforces
            // extraction-reliability posture - the same discipline TR-16's
            // parseEscalation() already applies to a self-reported basis
            // (never trusted on faith; verified against the real retrieved
            // set). GovernedContextBuilder's system-prompt rule 7 asks the
            // model to escalate an unreliable-sole-basis citation itself,
            // but an otherwise-perfect model response that simply forgot is
            // not an acceptable failure mode for an evidentiary product - so
            // this is checked here regardless of what the model actually
            // said, against the real RetrievedPassage objects, not the
            // model's claims about them.
            $unreliable = array_values(array_filter($refs,
                fn ($i) => $passages[$i]->extractionReliability === ExtractionReliability::UNRELIABLE));
            if ($unreliable !== []) {
                $citedButUnresolved = $this->citationsFor($unreliable, $passages, $now);
                $first = $passages[$unreliable[0]];

                return (new Escalation(
                    reason: 'TRACE identified a potentially controlling passage, but its text was recovered from OCR below the reliability threshold and cannot be relied on without visual confirmation of the source page.',
                    routeTo: 'steward visual confirmation of the source page',
                    conflictCitations: $citedButUnresolved,
                    basis: Escalation::BASIS_INSUFFICIENT_EVIDENCE,
                    missingFact: 'Visual confirmation of '.$first->source
                        .($first->pageFrom !== null ? ', page '.$first->pageFrom.($first->pageTo !== null && $first->pageTo !== $first->pageFrom ? '-'.$first->pageTo : '') : '')
                        .' (extraction_reliability: unreliable).',
                ))->withSpend($spend);
            }

            // Codex's ruling: a review-recommended answer must visibly carry
            // its OCR-review caveat regardless of whether the model
            // remembered to say so itself - the code appends the SAME fixed
            // wording GovernedContextBuilder showed the model, so the
            // caveat's presence never depends on model compliance.
            $reviewRecommended = array_values(array_filter($refs,
                fn ($i) => $passages[$i]->extractionReliability === ExtractionReliability::REVIEW_RECOMMENDED));
            $text = $decoded['text'];
            if ($reviewRecommended !== []) {
                $caveat = ExtractionReliability::caveat(ExtractionReliability::REVIEW_RECOMMENDED);
                if (! str_contains($text, $caveat)) {
                    $text = rtrim($text)."\n\n".$caveat;
                }
            }

            return (new CitedSuggestion(
                $text,
                $this->citationsFor($refs, $passages, $now),
            ))->withSpend($spend);
        }

        return match ($decoded['kind']) {
            'escalation' => $this->parseEscalation($decoded, $passages, $now)->withSpend($spend),
            default => (new NoMatch($decoded['scope'] ?? 'retrieved passages'))->withSpend($spend),
        };
    }

    /**
     * TR-16: the escalation path gets the same grounding discipline
     * CitedSuggestion already forces on the affirmative path. The model
     * self-reports a `basis`; this method NEVER takes that basis's citations
     * on faith - it resolves `passage_refs` against the real retrieved
     * candidate set exactly the way suggestion refs are resolved, and
     * downgrades to BASIS_UNGROUNDED_CLAIM whenever the claimed basis is not
     * actually backed by what was retrieved. A basis the model never sends,
     * or sends unrecognised, is likewise never trusted as a grounded refusal
     * type - it is a protocol failure, distinct from a deliberate BASIS_POLICY
     * escalation this codebase issues itself before the model is even called.
     *
     * @param  array<string,mixed>  $decoded
     * @param  list<RetrievedPassage>  $passages
     */
    private function parseEscalation(array $decoded, array $passages, \DateTimeImmutable $now): Escalation
    {
        $reason = trim((string) ($decoded['reason'] ?? '')) !== '' ? $decoded['reason'] : 'Conflict found.';
        $routeTo = $decoded['route_to'] ?? 'design professional';
        $basis = $decoded['basis'] ?? null;

        if ($basis === Escalation::BASIS_CONFLICT) {
            $refs = $this->resolveRefs($decoded['passage_refs'] ?? [], $passages);
            if (count($refs) >= 2) {
                return new Escalation($reason, $routeTo, $this->citationsFor($refs, $passages, $now), Escalation::BASIS_CONFLICT);
            }

            return new Escalation(
                "AI claimed a document conflict but did not cite at least two distinct retrieved passages to support it - conflict unverified. Original claim: {$reason}",
                $routeTo,
                [],
                Escalation::BASIS_UNGROUNDED_CLAIM,
            );
        }

        if ($basis === Escalation::BASIS_INSUFFICIENT_EVIDENCE) {
            $refs = $this->resolveRefs($decoded['passage_refs'] ?? [], $passages);
            $missingFact = trim((string) ($decoded['missing_fact'] ?? ''));
            if ($refs === [] && $missingFact === '') {
                return new Escalation(
                    "AI claimed insufficient evidence but did not cite relevant passages or name the missing fact/authority. Original claim: {$reason}",
                    $routeTo,
                    [],
                    Escalation::BASIS_UNGROUNDED_CLAIM,
                );
            }

            return new Escalation(
                $reason,
                $routeTo,
                $this->citationsFor($refs, $passages, $now),
                Escalation::BASIS_INSUFFICIENT_EVIDENCE,
                $missingFact !== '' ? $missingFact : null,
            );
        }

        // Category-level (RefusalPolicy) and service-level (no key, unreachable,
        // provider error, malformed format) escalations are all returned
        // BEFORE the model is ever called or from response-shape failures
        // above - never from here. An escalation reaching this branch means
        // the model itself emitted kind "escalation" without a recognised
        // basis, which is a protocol failure, not a grounded refusal.
        return new Escalation($reason, $routeTo, [], Escalation::BASIS_UNGROUNDED_CLAIM);
    }

    /** @param list<RetrievedPassage> $passages @return list<int> */
    private function resolveRefs(mixed $refs, array $passages): array
    {
        return array_values(array_unique(array_filter(
            is_array($refs) ? $refs : [],
            fn ($i) => is_int($i) && array_key_exists($i, $passages)
        )));
    }

    /** @param list<int> $refs @param list<RetrievedPassage> $passages @return list<Citation> */
    private function citationsFor(array $refs, array $passages, \DateTimeImmutable $now): array
    {
        return array_map(function ($i) use ($passages, $now) {
            $p = $passages[$i];

            return new Citation($p->source, $p->edition, $now, $p->passageId, $p->sourcePublicId,
                $p->sourceHash, $p->pageFrom, $p->pageTo, $p->sectionRef, $p->authorityLevel,
                $p->versionNumber, $p->ordinal, $p->bodyHash);
        }, $refs);
    }

    // TR-15: the system prompt moved to GovernedContextBuilder::SYSTEM_PROMPT,
    // which now owns both the pre-existing rules and the instruction-trust
    // rule this row added. This driver no longer holds its own copy - having
    // two would let them drift, and the whole point of this row is that there
    // is exactly one gateway.
}
