<?php

namespace App\Domain\Ai;

/**
 * Retrieval scope derived automatically from the PROJECT record - owner
 * authority, funding source, contract type, location (Aspect 17). The user
 * never picks "which code book"; the project already knows.
 */
final class JurisdictionScope
{
    /** @param list<string> $corpora identifiers of licensed/public corpora in scope */
    public function __construct(
        public readonly string $sector,          // public|commercial|residential
        public readonly string $state,
        public readonly ?string $fundingSource,  // local|state|federal
        public readonly array $corpora,
    ) {}

    public static function forProject(string $sector, string $state, ?string $funding): self
    {
        $corpora = ['project_specs', 'project_plans', 'project_contract'];
        if ($sector === 'public') {
            $corpora[] = 'state_public_contract_code';
            $corpora[] = 'prevailing_wage_determinations';
            if ($state === 'CA') {
                $corpora[] = 'greenbook';           // licensed source - see design doc
            }
            if ($funding === 'federal') {
                $corpora[] = 'far_dfars';
            }
        }
        if ($sector !== 'public') {
            $corpora[] = 'building_code';           // licensed source (ICC)
        }

        return new self($sector, $state, $funding, $corpora);
    }
}
