<?php

namespace App\Domain\Ai;

use App\Models\AiRun;
use App\Models\AiRunEvent;

final class AiRunLedger
{
    public function record(AiRun $run, string $event, array $payload = []): void
    {
        $previous = AiRunEvent::query()->where('ai_run_id', $run->id)->latest('id')->first();
        $data = ['tenant_id' => $run->tenant_id, 'ai_run_id' => $run->id, 'event' => $event,
            'payload' => $payload, 'previous_event_hash' => $previous?->event_hash];
        $data['event_hash'] = hash('sha256', json_encode($data + ['at' => now()->toIso8601String()], JSON_THROW_ON_ERROR));
        AiRunEvent::create($data);
    }
}
