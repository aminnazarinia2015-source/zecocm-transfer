<?php

namespace App\Domain\Ai;

/**
 * Three classes of source, not one review queue.
 *
 * Provisional-by-default with a named human steward is coherent at four documents
 * and incoherent at five thousand. Nobody reads five thousand. Faced with that
 * queue a steward either ignores it — in which case the library is inert — or
 * bulk-approves without reading, which is worse than having no gate at all,
 * because it manufactures attestations the record cannot support.
 *
 * Codex's resolution, adopted: AUTHORITY DETERMINES ADMISSION, USE DETERMINES
 * REVIEW DEPTH. The question is not "has a human blessed this document" but
 * "can this document control an answer". Only the first class can, and only that
 * class needs a steward.
 *
 *   GOVERNING   the executed contract, addenda, special provisions, approved
 *               drawings, change orders, statutes and regulations. These decide
 *               what is required. A named steward must verify one before it can
 *               control an answer. This is the tier the gate exists for, and it
 *               is small.
 *
 *   REFERENCE   manuals, methods, prior projects, product literature, industry
 *               material. Auto-admitted with provenance, retrievable, useful —
 *               and can NEVER control an answer. Nobody needs to read five
 *               thousand of these, because none of them can outrank a contract.
 *
 *   ASSERTION   correspondence, daily reports, photographs, letters, positions
 *               taken by a party. Auto-admitted as EVIDENCE with attribution.
 *               Evidence of what someone said or observed is not authority for
 *               what is required, and the distinction is the whole ballgame in
 *               a dispute.
 */
final class SourceClass
{
    public const GOVERNING = 'governing';
    public const REFERENCE = 'reference';
    public const ASSERTION = 'assertion';

    /**
     * Document types that state a requirement of the contract itself.
     *
     * @var list<string>
     */
    private const GOVERNING_TYPES = [
        'contract', 'addendum', 'special_provisions', 'drawing', 'regulation',
    ];

    /**
     * Authority levels that can carry a contractual or legal requirement. A
     * document of a governing TYPE that only carries a party's assertion is not
     * governing — a letter attaching a marked-up drawing is still a letter.
     *
     * @var list<string>
     */
    private const GOVERNING_AUTHORITIES = [
        'project_contract', 'published_regulation', 'adopted_standard',
    ];

    /** @var list<string> */
    private const ASSERTION_TYPES = ['correspondence', 'lesson'];

    public static function for(?string $sourceType, ?string $authorityLevel): string
    {
        if ($authorityLevel === 'party_assertion' || in_array($sourceType, self::ASSERTION_TYPES, true)) {
            return self::ASSERTION;
        }

        if (in_array($sourceType, self::GOVERNING_TYPES, true)
            && in_array($authorityLevel, self::GOVERNING_AUTHORITIES, true)) {
            return self::GOVERNING;
        }

        // A specification is governing only when the project contract adopted it.
        // The same standard consulted for background is reference material.
        if ($sourceType === 'specification' && $authorityLevel === 'project_contract') {
            return self::GOVERNING;
        }

        return self::REFERENCE;
    }

    /**
     * May a source of this class control an answer, given its review state?
     *
     * Governing material must be stewarded first. Everything else is admitted on
     * arrival and is never allowed to control, so no steward time is spent on it.
     */
    public static function mayControlAnswer(string $class, ?string $verificationStatus): bool
    {
        if ($class !== self::GOVERNING) {
            return false;
        }

        return in_array($verificationStatus, ['verified', 'adopted'], true);
    }

    /**
     * May a source be retrieved at all? Governing material stays invisible until
     * stewarded — that gate does not move. Reference and assertion material is
     * retrievable immediately, clearly labelled, because withholding a product
     * manual until someone signs for it helps nobody.
     */
    public static function mayBeRetrieved(string $class, ?string $verificationStatus): bool
    {
        if ($class === self::GOVERNING) {
            return in_array($verificationStatus, ['verified', 'adopted'], true);
        }

        return $verificationStatus !== 'rejected';
    }

    /** Steward attention is finite. This is where it goes. */
    public static function requiresSteward(string $class): bool
    {
        return $class === self::GOVERNING;
    }
}
