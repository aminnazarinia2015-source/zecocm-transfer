<?php

namespace App\Domain\Ai;

use App\Domain\Knowledge\InstructionTrust;
use App\Domain\Knowledge\Ocr\ExtractionReliability;
use App\Models\KnowledgePassage;
use App\Models\Project;
use App\Tenancy\TenantContext;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Tenant-safe structured + lexical retrieval foundation. Embeddings can later be
 * added behind this interface; authorization and corpus gates remain invariant.
 */
final class HybridKnowledgeRetriever implements RetrievalClient
{
    public const VERSION = 'hybrid-structured-lexical-v1';

    /**
     * TR-18: the trace of the most recently completed retrieve() call on
     * this instance. HybridKnowledgeRetriever is bound as a singleton (see
     * AiServiceProvider), so this is safe to read immediately after
     * retrieve() returns within the same request/job - never across two
     * concurrent retrievals, which this codebase's synchronous per-job
     * processing never produces.
     */
    private ?RetrievalTraceRecorder $lastTrace = null;

    public function lastTrace(): ?RetrievalTraceRecorder
    {
        return $this->lastTrace;
    }

    public function retrieve(string $query, JurisdictionScope $scope): array
    {
        $trace = new RetrievalTraceRecorder;
        $this->lastTrace = $trace;

        $tenantId = TenantContext::tenantId();
        $projectId = (int) request()->attributes->get('authorized_project_id', 0);
        $authorizedRead = request()->attributes->get('authorized_evidence_read') === true;
        $trace->recordAuthorizationState([
            'authorized_evidence_read' => $authorizedRead,
            'tenant_id' => $tenantId,
            'project_id' => $projectId,
            'corpora' => $scope->corpora,
        ]);

        // Security trimming. Being allowed to ASK is not the same as being allowed
        // to READ. The assistant authorizes 'assistant.use'; document access is
        // 'documents.view', and on a multi-party project the owner, the general
        // contractor and the subs sit on the same project with different document
        // rights. Without this gate TRACE would read a document's contents aloud
        // to someone who cannot open that document - a retrieval layer that
        // launders permissions. Fails closed: absent the flag, nothing is
        // retrieved, so any new caller must authorize evidence reads deliberately.
        // Strict identity, not truthiness. Raised by Codex: a loose check would
        // let the string "false", "0", or any stray truthy value open the gate.
        // Only a real boolean true, set deliberately by a caller that checked the
        // grant, may release evidence.
        if (request()->attributes->get('authorized_evidence_read') !== true) {
            return [];
        }

        if ($tenantId === null || $projectId < 1 || $scope->corpora === []) {
            return [];
        }

        [$words, $phrases] = self::terms($query);
        if ($words === [] && $phrases === []) {
            return [];
        }

        $rows = KnowledgePassage::query()
            ->with('version.source', 'sourcePage')
            // LIB-1: a 'project_private' source (this project's own contract,
            // specs, plans) is only ever a candidate for ITS OWN project - the
            // project_id match below. A 'tenant_private' source (the shared
            // Knowledge Library: regulations, codes, industry reference) is a
            // candidate for EVERY project under the same tenant, which is the
            // entire point of ingesting a regulation once rather than
            // per-project. Cross-TENANT isolation is a separate, structural
            // guarantee - every model here carries BelongsToTenant's
            // fail-closed global scope (see TenantScope), so this OR can never
            // surface another tenant's rows no matter what it matches within
            // this tenant. What it still must pass, unconditionally, further
            // down: EffectiveWindow, JurisdictionMatch (the source's own
            // jurisdiction against THIS project's state), and
            // SourceClass::mayBeRetrieved() - sharing a source tenant-wide
            // does not exempt it from any authority check a project-private
            // source would face.
            ->where(function ($scoped) use ($projectId, $tenantId) {
                $scoped->where(function ($own) use ($projectId) {
                    $own->where('project_id', $projectId)
                        ->whereHas('version.source', fn ($q) => $q->where('access_classification', 'project_private'));
                })->orWhere(function ($shared) use ($tenantId) {
                    $shared->where('tenant_id', $tenantId)
                        ->whereHas('version.source', fn ($q) => $q->where('access_classification', 'tenant_private'));
                });
            })
            ->whereHas('version.source', function ($q) {
                $q->whereIn('collection', ['project', 'organization', 'city', 'regulatory'])
                    ->where('ingestion_status', 'ready')
                    ->where('malware_scan_status', 'clean')
                    // Candidates only. The retrieval gate itself lives in
                    // SourceClass::mayBeRetrieved() and is applied below, so the
                    // rule exists in exactly one place. Duplicating it in SQL is
                    // how the gate and the classifier drift apart, and a gate that
                    // disagrees with its own classifier is not a gate.
                    ->where('verification_status', '!=', 'rejected');
            })
            ->whereHas('version', function ($version) use ($scope) {
                $version->where(function ($corpus) use ($scope) {
                    foreach ($scope->corpora as $name) {
                        $corpus->orWhereJsonContains('classification->corpora', $name);
                    }
                });
            })
            ->where(function ($q) use ($words, $phrases) {
                foreach (array_merge($words, $phrases) as $term) {
                    $q->orWhere('body', 'like', '%'.addcslashes($term, '%_').'%');
                }
            })
            ->limit(40)
            ->get();

        $trace->recordSqlCandidateCount($rows->count());
        foreach ($rows as $row) {
            $trace->noteChunkingVersion($row->version?->classification['chunking_version'] ?? null);
        }

        $precedence = self::precedenceFor($projectId);
        $projectState = (string) (Project::query()->find($projectId)?->state ?? '');
        $versionIds = $rows->pluck('knowledge_source_version_id')->unique()->all();
        $superseded = self::supersededVersions($versionIds);
        // The overlay. Document-level supersession is one case of it - the case
        // where a modifying instrument replaced everything - and it is now the
        // exception rather than the assumption.
        $overlay = self::overlayScopes($versionIds);
        $now = now();

        $trace->startStage('candidate_filters');
        $rows = $rows->filter(function (KnowledgePassage $passage) use ($projectState, $now, $trace) {
            $version = $passage->version;
            $source = $version?->source;
            if ($source === null) {
                return false;
            }
            $locator = self::locatorOf($passage, $version, $source);

            // TR-13: effective-date and jurisdiction, checked before source-class
            // and verification even get a say. A statute not yet in force, one
            // that has lapsed, or one licensed for a different state's public
            // contract code is not a candidate to rank at all - not merely
            // outranked, excluded, the same way an unauthorized read never
            // reaches ranking either.
            if (! EffectiveWindow::inForce($version->effective_from, $version->effective_until, $now)) {
                $trace->exclude($locator, 'effective_window');

                return false;
            }
            if (! JurisdictionMatch::permits($source->jurisdiction, $source->collection, $projectState)) {
                $trace->exclude($locator, 'jurisdiction');

                return false;
            }

            $mayRetrieve = SourceClass::mayBeRetrieved(
                SourceClass::for($source->source_type, $source->authority_level),
                $source->verification_status,
            );
            if (! $mayRetrieve) {
                $trace->exclude($locator, 'source_class');
            }

            return $mayRetrieve;
        });

        $trace->startStage('lexical_rank');
        $scored = $rows->map(function (KnowledgePassage $passage) use ($words, $phrases) {
            $body = mb_strtolower($passage->body);
            $score = 0;
            foreach ($words as $word) {
                $score += substr_count($body, $word) * (10 + mb_strlen($word));
            }
            // A section or sheet reference is the single most decisive signal a
            // construction query carries. Matching '32 84 00' is not the same
            // kind of evidence as matching the word 'irrigation'.
            foreach ($phrases as $phrase) {
                $score += substr_count($body, $phrase) * 250;
            }

            return [$score, $passage];
        })->sortByDesc(fn ($entry) => $entry[0]);
        $ranked = $scored->take(8);
        foreach ($scored->slice(8) as $entry) {
            /** @var KnowledgePassage $dropped */
            $dropped = $entry[1];
            $trace->exclude(self::locatorOf($dropped, $dropped->version, $dropped->version?->source), 'lexical_rank_cutoff');
        }

        // Order of precedence beats textual match. A plan sheet that mentions the
        // query eleven times does not outrank the addendum that changed it once.
        // Score still breaks ties within a precedence tier.
        $ranked = $ranked->sort(function ($a, $b) use ($precedence, $superseded) {
            $srcA = $a[1]->version?->source;
            $srcB = $b[1]->version?->source;

            // Class first: a product manual never surfaces above the contract,
            // however well its words happen to match the question.
            // Superseded material sorts below everything current. The revision
            // that replaced it is the answer; this is the paper trail.
            $oldA = isset($superseded[$a[1]->knowledge_source_version_id]) ? 1 : 0;
            $oldB = isset($superseded[$b[1]->knowledge_source_version_id]) ? 1 : 0;
            if ($oldA !== $oldB) {
                return $oldA <=> $oldB;
            }

            $classA = SourceClass::for($srcA?->source_type, $srcA?->authority_level) === SourceClass::GOVERNING ? 0 : 1;
            $classB = SourceClass::for($srcB?->source_type, $srcB?->authority_level) === SourceClass::GOVERNING ? 0 : 1;
            if ($classA !== $classB) {
                return $classA <=> $classB;
            }

            $rankA = $precedence->rank($srcA?->source_type);
            $rankB = $precedence->rank($srcB?->source_type);

            return $rankA === $rankB ? $b[0] <=> $a[0] : $rankA <=> $rankB;
        });

        // Precedence-first is wrong when the governing document is SILENT.
        //
        // Codex's example: nothing in the contract, special provisions or project
        // specification says anything about PVC solvent weld curing time; the
        // incorporated manufacturer instructions do. Ranking purely by authority
        // buries the only document that answers the question underneath three that
        // merely mention the words. Silence is not an answer, and outranking is
        // not the same as responding.
        //
        // So a higher-ranked passage only takes the top slot when it is actually
        // responsive - within a reasonable factor of the best lexical match. Below
        // that it is incidental, and burying the document that does answer would be
        // a worse error than the one precedence exists to prevent.
        $ranked = self::demoteIncidentalAuthority($ranked);

        $traceCandidates = [];
        $result = $ranked->map(function ($entry) use ($precedence, $superseded, $overlay, &$traceCandidates) {
            /** @var KnowledgePassage $passage */
            [$score, $passage] = $entry;
            $version = $passage->version;
            $source = $version->source;

            // D4/Codex's ruling: extraction reliability is a SEPARATE axis
            // from everything above this line - it never enters ranking or
            // authority (see the sort comparator above, which never reads
            // sourcePage) and is computed once, here, deterministically -
            // never left for the model to judge. A passage with no single
            // source page (source_page_id is null for a stitched multi-page
            // born-digital passage or a plain-text source) was never
            // OCR-derived and classifies as reliable by definition.
            $extractionMethod = $passage->sourcePage?->extraction_method;
            $extractionConfidence = $passage->sourcePage?->extraction_confidence;
            $reliability = ExtractionReliability::classify(
                $extractionMethod,
                $extractionConfidence,
                (bool) ($passage->sourcePage?->has_structural_defect ?? false),
            );

            $passageObj = new RetrievedPassage(
                source: $source->title,
                edition: $version->edition ?: $version->revision,
                text: $passage->body,
                passageId: $passage->id,
                sourcePublicId: $source->public_id,
                sourceHash: $version->sha256,
                pageFrom: $passage->page_from,
                pageTo: $passage->page_to,
                sectionRef: $passage->section_ref ?: $passage->sheet_ref,
                authorityLevel: $source->authority_level,
                sourceType: $source->source_type,
                precedenceRank: $precedence->rank($source->source_type),
                sourceClass: $class = SourceClass::for($source->source_type, $source->authority_level),
                // Is THIS passage currently operative? Not "is this PDF old".
                //
                // A scoped modification retires only what it actually reached,
                // so an unaffected provision of a modified specification is
                // still the contract and can still control the answer. Where no
                // scope was ever recorded, the edge means the whole document and
                // this collapses to the behaviour it had before - which is what
                // every existing confirmed edge asserts and all it could assert.
                controlsAnswer: EffectiveDocument::mayControl(
                    $state = self::operativeState($passage, $version->id, $superseded, $overlay)
                ) && SourceClass::mayControlAnswer($class, $source->verification_status),
                supersededBy: $state === EffectiveDocument::CURRENT
                    ? null
                    : ($superseded[$version->id] ?? self::overlayTitle($passage, $version->id, $overlay)),
                // TR-15: named explicitly rather than left to RetrievedPassage's
                // default. Every passage this retriever returns comes from the
                // tenant's own knowledge_passages table - never from an
                // AcquiredDocument - so tenant_record is the correct label today.
                // The day this retriever (or any other) starts surfacing
                // externally acquired material, that path must set
                // InstructionTrust::EXTERNAL_UNTRUSTED here instead; it must
                // never inherit a default silently.
                instructionTrust: InstructionTrust::TENANT_RECORD,
                // TR-14: the portable locators. Never the internal passageId.
                versionNumber: $version->version_number,
                ordinal: $passage->ordinal,
                bodyHash: $passage->body_sha256,
                extractionMethod: $extractionMethod,
                extractionConfidence: $extractionConfidence,
                extractionReliability: $reliability,
            );

            $traceCandidates[] = [
                'source_public_id' => $source->public_id,
                'version_number' => $version->version_number,
                'ordinal' => $passage->ordinal,
                'body_hash' => $passage->body_sha256,
                'source_type' => $source->source_type,
                'authority_level' => $source->authority_level,
                'precedence_rank' => $passageObj->precedenceRank,
                'source_class' => $passageObj->sourceClass,
                'operative_state' => $state,
                'lexical_score' => $score,
                'controls_answer' => $passageObj->controlsAnswer,
                'superseded_by' => $passageObj->supersededBy,
            ];

            return $passageObj;
        })->values()->all();

        $trace->recordFinalCandidates($traceCandidates);

        return $result;
    }

    /**
     * Construction queries are made of exactly the tokens a naive length filter
     * throws away.
     *
     * The previous rule - keep words of four characters or more - silently
     * deleted 'PVC', 'psi', 'DIA', 'in', every dimension, and every two-digit
     * segment of a CSI section number, so a question about 'section 32 84 00'
     * tokenized to nothing at all and returned no passages. The filter existed
     * to drop English stop words; it was throwing out the vocabulary instead.
     *
     * So: drop stop words by name, keep everything else of two characters or
     * more, and lift multi-part section and sheet references out as phrases
     * before tokenizing, so they survive as units rather than as digit soup.
     *
     * @return array{0: list<string>, 1: list<string>}
     */
    public static function terms(string $query): array
    {
        $lower = mb_strtolower($query);

        // CSI MasterFormat: '32 84 00', '32 84 00.13'. Also sheet refs: 'L-3', '4/A-01'.
        $phrases = [];
        if (preg_match_all('/\b\d{2}\s\d{2}\s\d{2}(?:\.\d{2})?\b/', $lower, $m)) {
            $phrases = array_merge($phrases, $m[0]);
        }
        if (preg_match_all('/\b(?:\d+\/)?[a-z]{1,3}-\d{1,3}(?:\.\d+)?\b/', $lower, $m)) {
            $phrases = array_merge($phrases, $m[0]);
        }
        $phrases = array_values(array_unique($phrases));

        $stripped = $lower;
        foreach ($phrases as $phrase) {
            $stripped = str_replace($phrase, ' ', $stripped);
        }

        $words = array_values(array_unique(array_filter(
            preg_split('/[^a-z0-9\.\"]+/i', $stripped) ?: [],
            fn ($word) => mb_strlen(trim($word, '."')) >= 2 && ! in_array($word, self::STOP_WORDS, true)
        )));

        return [$words, $phrases];
    }

    /**
     * Named stop words, not a length cut. Deliberately short: in a specification
     * corpus an aggressive stop list removes meaning ('as', 'per', 'by', 'not'
     * all carry contractual weight), so only words that cannot narrow a search
     * are listed here.
     *
     * @var list<string>
     */
    private const STOP_WORDS = [
        'the', 'and', 'for', 'are', 'but', 'was', 'were', 'this', 'that', 'these',
        'those', 'with', 'from', 'what', 'when', 'where', 'which', 'who', 'how',
        'you', 'your', 'our', 'it', 'is', 'be', 'to', 'of', 'a', 'an', 'or', 'do',
        'does', 'did', 'can', 'could', 'would', 'should', 'about', 'there', 'has',
        'have', 'had', 'me', 'my', 'we', 'us', 'they', 'them', 'i',
    ];

    /**
     * TR-18: the same three portable locators CitationAnchor already uses,
     * built for a candidate that is about to be excluded - so a trace can
     * name WHICH candidate was excluded without ever touching its body text.
     *
     * @return array{source_public_id: ?string, version_number: ?int, ordinal: ?int}
     */
    private static function locatorOf(KnowledgePassage $passage, $version, $source): array
    {
        return [
            'source_public_id' => $source?->public_id,
            'version_number' => $version?->version_number,
            'ordinal' => $passage->ordinal,
        ];
    }

    private static function precedenceFor(int $projectId): DocumentPrecedence
    {
        $project = Project::query()->find($projectId);

        return $project === null ? new DocumentPrecedence : DocumentPrecedence::forProject($project);
    }

    /**
     * Two passages of different precedence rank that both answer the same question
     * are a conflict, and a conflict is a human's to settle. Retrieval reports it;
     * it never resolves it by quietly returning only the winner.
     *
     * @param  list<RetrievedPassage>  $passages
     * @return array{conflict: bool, governing: ?RetrievedPassage, subordinate: list<RetrievedPassage>}
     */
    public static function precedenceConflict(array $passages): array
    {
        $ranked = array_values(array_filter($passages, fn ($p) => $p->precedenceRank !== null));
        if (count($ranked) < 2) {
            return ['conflict' => false, 'governing' => $passages[0] ?? null, 'subordinate' => []];
        }

        $best = min(array_map(fn ($p) => $p->precedenceRank, $ranked));
        $governing = null;
        $subordinate = [];
        foreach ($ranked as $passage) {
            if ($passage->precedenceRank === $best && $governing === null) {
                $governing = $passage;

                continue;
            }
            if ($passage->precedenceRank > $best) {
                $subordinate[] = $passage;
            }
        }

        return ['conflict' => $subordinate !== [], 'governing' => $governing, 'subordinate' => $subordinate];
    }

    /**
     * @param  Collection<int, array{0: int, 1: KnowledgePassage}>  $ranked
     * @return Collection<int, array{0: int, 1: KnowledgePassage}>
     */
    private static function demoteIncidentalAuthority($ranked)
    {
        $entries = $ranked->values()->all();
        if (count($entries) < 2) {
            return $ranked;
        }

        $bestScore = max(array_map(fn ($e) => $e[0], $entries));
        if ($bestScore <= 0) {
            return $ranked;
        }

        // A passage scoring under a quarter of the best match is mentioning the
        // subject, not addressing it. Authority does not promote a mention.
        $floor = $bestScore * self::RESPONSIVENESS_FLOOR;

        $responsive = array_values(array_filter($entries, fn ($e) => $e[0] >= $floor));
        $incidental = array_values(array_filter($entries, fn ($e) => $e[0] < $floor));

        return collect(array_merge($responsive, $incidental));
    }

    /**
     * How close to the best lexical match a passage must score before its
     * contractual authority is allowed to promote it above better matches.
     */
    public const RESPONSIVENESS_FLOOR = 0.25;

    /**
     * Which versions has a steward recorded as superseded, and by what.
     *
     * `knowledge_source_edges` has been written since the beginning - a steward
     * clicks "relate" and records that Addendum 3 supersedes Addendum 2 - and read
     * by absolutely nothing. The supersession was captured and then ignored, so a
     * replaced specification was retrieved and cited as current with no warning
     * anywhere. Recording a fact and never consulting it is worse than not
     * recording it, because the interface implies the system knows.
     *
     * @param  list<int>  $versionIds
     * @return array<int,string> superseded version id => title of what replaced it
     */
    /**
     * Confirmed scoped modifications reaching these versions, grouped by the
     * version they modify.
     *
     * Proposed and unresolved scopes are deliberately INCLUDED. They do not
     * retire anything - EffectiveDocument refuses on them - but leaving them out
     * would mean answering from text the record already suggests may be dead,
     * which is the quieter half of the same mistake.
     *
     * @param  list<int>  $versionIds
     * @return array<int,list<array<string,mixed>>>
     */
    private static function overlayScopes(array $versionIds): array
    {
        if ($versionIds === []) {
            return [];
        }

        $tenantId = TenantContext::tenantId();
        if ($tenantId === null) {
            return [];
        }

        $rows = DB::table('supersession_scopes as sc')
            ->join('knowledge_source_edges as e', 'e.id', '=', 'sc.knowledge_source_edge_id')
            ->join('knowledge_source_versions as fv', 'fv.id', '=', 'e.from_version_id')
            ->join('knowledge_sources as fs', 'fs.id', '=', 'fv.knowledge_source_id')
            ->whereIn('e.to_version_id', $versionIds)
            ->whereIn('e.relationship', ['supersedes', 'amends'])
            ->where('e.status', 'confirmed')
            ->where('sc.tenant_id', $tenantId)
            ->where('e.tenant_id', $tenantId)
            ->where('fs.tenant_id', $tenantId)
            ->get([
                'e.to_version_id as version_id', 'sc.scope_type', 'sc.relation', 'sc.status',
                'sc.target_section_ref', 'sc.target_sheet_ref', 'sc.start_passage_id',
                'sc.end_passage_id', 'sc.target_content_hash', 'fs.title as superseding_title',
            ]);

        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row->version_id][] = (array) $row;
        }

        return $map;
    }

    /** @param  array<int,list<array<string,mixed>>>  $overlay */
    private static function operativeState(KnowledgePassage $passage, int $versionId, array $superseded, array $overlay): string
    {
        $scopes = $overlay[$versionId] ?? [];

        if ($scopes !== []) {
            return EffectiveDocument::stateOf([
                'id' => $passage->id,
                'section_ref' => $passage->section_ref,
                'sheet_ref' => $passage->sheet_ref,
                'body_sha256' => $passage->body_sha256,
            ], $scopes)['state'];
        }

        // No scope recorded: the edge means the whole document, as before.
        return isset($superseded[$versionId]) ? EffectiveDocument::SUPERSEDED : EffectiveDocument::CURRENT;
    }

    /** @param  array<int,list<array<string,mixed>>>  $overlay */
    private static function overlayTitle(KnowledgePassage $passage, int $versionId, array $overlay): ?string
    {
        $scopes = $overlay[$versionId] ?? [];
        if ($scopes === []) {
            return null;
        }

        return EffectiveDocument::stateOf([
            'id' => $passage->id,
            'section_ref' => $passage->section_ref,
            'sheet_ref' => $passage->sheet_ref,
            'body_sha256' => $passage->body_sha256,
        ], $scopes)['by'];
    }

    private static function supersededVersions(array $versionIds): array
    {
        if ($versionIds === []) {
            return [];
        }

        // Raw query, so no global scope reaches it. Today this is safe only
        // because the version ids arriving here were themselves retrieved under
        // the scope - which is safety by accident of other code rather than by
        // construction, and the thing this query returns is a DOCUMENT TITLE
        // from another tenant if that accident ever stops holding.
        //
        // The tenant is named explicitly, and with no tenant in context the
        // query returns nothing rather than everything.
        $tenantId = TenantContext::tenantId();
        if ($tenantId === null) {
            return [];
        }

        $rows = DB::table('knowledge_source_edges as e')
            ->join('knowledge_source_versions as fv', 'fv.id', '=', 'e.from_version_id')
            ->join('knowledge_sources as fs', 'fs.id', '=', 'fv.knowledge_source_id')
            ->whereIn('e.to_version_id', $versionIds)
            ->whereIn('e.relationship', ['supersedes', 'amends'])
            ->where('e.status', 'confirmed')
            ->where('e.tenant_id', $tenantId)
            ->where('fv.tenant_id', $tenantId)
            ->where('fs.tenant_id', $tenantId)
            ->get(['e.to_version_id as superseded_version_id', 'fs.title as replaced_by']);

        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row->superseded_version_id] = (string) $row->replaced_by;
        }

        return $map;
    }
}
