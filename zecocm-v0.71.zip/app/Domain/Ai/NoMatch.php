<?php

namespace App\Domain\Ai;

/** "No applicable requirement found" is never presented as "no requirement exists" (Aspect 18). */
final class NoMatch extends AiResult
{
    public function __construct(public readonly string $scopeSearched) {}

    public function kind(): string
    {
        return 'no_match';
    }
}
