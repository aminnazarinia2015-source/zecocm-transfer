<?php

namespace App\Domain\Ai;

use App\Models\RetrievalTrace;

/**
 * TR-18: turns one completed retrieval's RetrievalTraceRecorder, plus the
 * eventual result (suggestion / escalation / no_match), into the single
 * append-only retrieval_traces row for that run. The one place a trace is
 * ever written - mirrors CitationAnchor::build() being the one place an
 * anchor is ever built (TR-14) and GovernedContextBuilder being the one
 * gateway passages reach the model through (TR-15).
 */
final class RetrievalTraceWriter
{
    public static function write(
        RetrievalTraceRecorder $recorder,
        string $query,
        ?int $tenantId,
        ?int $projectId,
        ?int $aiRunId,
        AiResult $result,
    ): RetrievalTrace {
        $data = $recorder->toArray();

        return RetrievalTrace::create([
            'tenant_id' => $tenantId,
            'project_id' => $projectId,
            'ai_run_id' => $aiRunId,
            'query' => mb_substr($query, 0, 2000),
            'retriever_version' => HybridKnowledgeRetriever::VERSION,
            'chunking_versions' => $data['chunking_versions'],
            'authorization_state' => $data['authorization_state'],
            'sql_candidate_count' => $data['sql_candidate_count'],
            'stages' => $data['stages'],
            'final_candidates' => $data['final_candidates'],
            'passages_cited' => self::citedAnchorsOf($result),
            'result_kind' => $result->kind(),
            'escalation_basis' => $result instanceof Escalation ? $result->basis : null,
        ]);
    }

    /**
     * TR-18, Codex's second finding: retrieval is itself a historical fact,
     * independent of whether the model call that follows it ever completes.
     * Every path inside ClaudeAssistant already turns a network failure, a
     * provider error, or a malformed response into an Escalation rather than
     * throwing - but suggest() is not the only thing that can throw between
     * a successful retrieve() and a written trace (job infrastructure, a DB
     * error, an unexpected exception). Without this method, the single most
     * useful diagnostic artifact - what TRACE actually retrieved - would be
     * lost exactly on the runs that went wrong, which is precisely backwards.
     *
     * Called only when no AiResult exists to write through write() above.
     * `passages_cited` is always empty and `result_kind` is the fixed
     * sentinel 'model_failed' - never a real AiResult::kind() value, so a
     * reader can never mistake an incomplete trace for a resolved one.
     */
    public static function writeIncomplete(
        RetrievalTraceRecorder $recorder,
        string $query,
        ?int $tenantId,
        ?int $projectId,
        ?int $aiRunId,
    ): RetrievalTrace {
        $data = $recorder->toArray();

        return RetrievalTrace::create([
            'tenant_id' => $tenantId,
            'project_id' => $projectId,
            'ai_run_id' => $aiRunId,
            'query' => mb_substr($query, 0, 2000),
            'retriever_version' => HybridKnowledgeRetriever::VERSION,
            'chunking_versions' => $data['chunking_versions'],
            'authorization_state' => $data['authorization_state'],
            'sql_candidate_count' => $data['sql_candidate_count'],
            'stages' => $data['stages'],
            'final_candidates' => $data['final_candidates'],
            'passages_cited' => [],
            'result_kind' => 'model_failed',
            'escalation_basis' => null,
        ]);
    }

    /** @return list<array{anchor: ?string, source: string}> */
    private static function citedAnchorsOf(AiResult $result): array
    {
        $citations = match (true) {
            $result instanceof CitedSuggestion => $result->citations,
            $result instanceof Escalation => $result->conflictCitations,
            default => [],
        };

        return array_map(fn (Citation $c) => [
            'anchor' => CitationAnchor::build($c->sourcePublicId, $c->versionNumber, $c->ordinal, $c->bodyHash),
            'source' => $c->source,
        ], $citations);
    }
}
