<?php

namespace App\Domain\Ai;

/**
 * TR-14: citation addressability - an anchor that still resolves after the
 * citation leaves this database.
 *
 * Every citation this codebase renders (see `Citation`) has always carried
 * `passage_id` - `knowledge_passages.id`, an autoincrement integer scoped to
 * this one database. That is not an address a third party can use. Restore a
 * backup, migrate to a new database, or hand an evidence export (EV-15) to a
 * party running their own copy of the source documents, and the row id that
 * meant "this exact passage" here means nothing, or worse, means a different
 * row there. A citation whose only locator disappears the moment it leaves
 * ZecoCM is not a citation a third party can check - it is a reference back
 * to us.
 *
 * The anchor built here uses only data that is already portable by
 * construction, because each piece was built for a different row's closure
 * and happens to compose into an address:
 *
 * - the source's `public_id` (a UUID assigned once at ingest, carried in every
 *   export - already the addressable identity of the SOURCE, just never
 *   extended down to the passage within it);
 * - the version's `version_number` (assigned once per source, in the order
 *   versions were ingested - which edition, unambiguously);
 * - the passage's `ordinal` (its position within that version, assigned once
 *   at chunking time - D3's `chunking_version` already stamps which process
 *   produced that ordering);
 * - the passage's `body_sha256` (a content hash of the passage text itself -
 *   the same digest EV-13 treats as portable identity for a whole source,
 *   applied here at passage grain).
 *
 * None of the four requires a live database to interpret, and the last one is
 * independently checkable: anyone holding the passage text can recompute
 * sha256 over it and confirm the anchor still names that exact text. That is
 * addressability, not integrity - it does not by itself prove the surrounding
 * document is unaltered (EV-13/EV-15 answer that question); it proves which
 * passage a citation means, in a way that survives the citation leaving this
 * database.
 *
 * ONE GATEWAY: this is the only place in the codebase that composes this
 * string. Building it ad hoc elsewhere would let the format drift the way the
 * three upload paths drifted before SEC-5 - see
 * `CitationAnchorTest::test_no_other_file_builds_this_format`.
 */
final class CitationAnchor
{
    /**
     * Returns null rather than a partial or best-guess anchor when any
     * portable piece is missing. A citation is either fully addressable or it
     * says so - it never presents a guess as if it were a locator, the same
     * fail-closed discipline as `DigestAlgorithm::CANNOT_VERIFY` and
     * `JurisdictionMatch`'s unrecognised-jurisdiction case.
     */
    public static function build(
        ?string $sourcePublicId,
        ?int $versionNumber,
        ?int $ordinal,
        ?string $bodySha256,
    ): ?string {
        if ($sourcePublicId === null || $versionNumber === null || $ordinal === null || $bodySha256 === null) {
            return null;
        }

        return sprintf('%s#v%d.p%d@sha256:%s', $sourcePublicId, $versionNumber, $ordinal, $bodySha256);
    }
}
