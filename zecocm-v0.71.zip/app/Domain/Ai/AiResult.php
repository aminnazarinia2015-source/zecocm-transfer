<?php

namespace App\Domain\Ai;

/**
 * Every AI interaction in ZecoCM resolves to exactly one of three shapes
 * (patent Aspects 17-19, 30-32). There is no fourth "confident answer
 * without citation" shape anywhere in the system - by construction.
 */
abstract class AiResult
{
    abstract public function kind(): string;

    /**
     * What producing this result cost.
     *
     * It rides on the result rather than being returned separately because the
     * cost has to survive every path out of the assistant, including the ones
     * that refuse. A refusal issued AFTER the model was called is not free, and
     * a design where only the success path carries a cost would undercount
     * precisely the runs that go wrong.
     *
     * Null means the assistant never said - which the budget treats as unknown,
     * not as zero.
     */
    public ?TokenSpend $spend = null;

    public function withSpend(?TokenSpend $spend): static
    {
        $this->spend = $spend;

        return $this;
    }
}
