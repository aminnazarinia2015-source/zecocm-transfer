<?php

namespace App\Domain\Ai;

/**
 * What one model call actually cost, or the honest admission that nobody knows.
 *
 * The distinction this type exists to keep is between ZERO and UNKNOWN. A run
 * that was refused before the model was ever called cost nothing, and that is a
 * measured zero. A run whose provider response arrived without usage figures,
 * or whose connection dropped after the tokens were spent, cost SOMETHING that
 * was not recorded - and writing that as zero is how a spend cap ends up
 * enforcing against a number that quietly understates reality.
 *
 * So `measured` is not a nicety. It is the flag that stops the budget from
 * lying about itself.
 */
final class TokenSpend
{
    private function __construct(
        public readonly int $inputTokens,
        public readonly int $outputTokens,
        public readonly string $model,
        public readonly bool $measured,
    ) {}

    public static function of(int $inputTokens, int $outputTokens, string $model): self
    {
        return new self(max(0, $inputTokens), max(0, $outputTokens), $model, true);
    }

    /** Nothing was spent, and we know it. A refusal before the provider call. */
    public static function none(string $model = ''): self
    {
        return new self(0, 0, $model, true);
    }

    /** Something was spent and the amount could not be established. */
    public static function unmeasured(string $model): self
    {
        return new self(0, 0, $model, false);
    }

    /**
     * Read the usage block off an Anthropic response, refusing to guess.
     *
     * A response without a usage block is unmeasured, not free. The provider
     * has been paid either way.
     *
     * @param  array<string,mixed>  $payload
     */
    public static function fromAnthropic(array $payload, string $model): self
    {
        $usage = $payload['usage'] ?? null;

        if (! is_array($usage) || ! isset($usage['input_tokens'], $usage['output_tokens'])) {
            return self::unmeasured($model);
        }

        return self::of((int) $usage['input_tokens'], (int) $usage['output_tokens'], $model);
    }

    /**
     * Cost in micros (millionths of a dollar), or null when unmeasured.
     *
     * Null rather than zero, deliberately. Every caller is forced to decide what
     * an unknown cost means to it, which is the decision that was being skipped.
     *
     * @param  array<string,array{input_micros_per_mtok: int, output_micros_per_mtok: int}>  $priceTable
     */
    public function micros(array $priceTable): ?int
    {
        if (! $this->measured) {
            return null;
        }

        $price = $priceTable[$this->model] ?? null;

        if ($price === null) {
            // A model nobody priced is not a free model. Refusing to invent a
            // rate here is the same refusal the rest of this codebase makes
            // about amounts it cannot establish.
            return $this->inputTokens === 0 && $this->outputTokens === 0 ? 0 : null;
        }

        return (int) (
            intdiv($this->inputTokens * (int) $price['input_micros_per_mtok'], 1_000_000)
            + intdiv($this->outputTokens * (int) $price['output_micros_per_mtok'], 1_000_000)
        );
    }

    public function totalTokens(): int
    {
        return $this->inputTokens + $this->outputTokens;
    }
}
