<?php

namespace App\Domain\Ai;

interface AiAssistant
{
    /**
     * Draft a suggestion grounded ONLY in the given scope's retrieved text.
     * Implementations MUST return one of the three AiResult shapes and MUST
     * apply the RefusalPolicy before attempting a suggestion.
     */
    public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): AiResult;
}
