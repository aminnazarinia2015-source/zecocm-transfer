<?php

namespace App\Domain\Ai;

final class Citation
{
    public function __construct(
        public readonly string $source,        // e.g. "Plan sheet A-01, detail 4/A-01"
        public readonly ?string $edition,      // e.g. "Rev. 3" or "2024 ed."
        public readonly \DateTimeImmutable $retrievedAt,
        public readonly ?int $passageId = null,
        public readonly ?string $sourcePublicId = null,
        public readonly ?string $sourceHash = null,
        public readonly ?int $pageFrom = null,
        public readonly ?int $pageTo = null,
        public readonly ?string $sectionRef = null,
        public readonly ?string $authorityLevel = null,
        /**
         * TR-14: the portable locators `CitationAnchor::build()` composes into
         * an address that still resolves once this citation leaves ZecoCM.
         * `passageId` above is retained for internal debugging only - it is a
         * database row id, not an anchor, and must never be presented as one.
         */
        public readonly ?int $versionNumber = null,
        public readonly ?int $ordinal = null,
        public readonly ?string $bodyHash = null,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'source' => $this->source,
            'edition' => $this->edition,
            'retrieved_at' => $this->retrievedAt->format(DATE_ATOM),
            'passage_id' => $this->passageId,
            'source_id' => $this->sourcePublicId,
            'source_hash' => $this->sourceHash,
            'page_from' => $this->pageFrom,
            'page_to' => $this->pageTo,
            'section' => $this->sectionRef,
            'authority_level' => $this->authorityLevel,
            // TR-14: null, never a partial guess, when any portable piece is
            // missing - see CitationAnchor's own fail-closed doc comment.
            'anchor' => CitationAnchor::build($this->sourcePublicId, $this->versionNumber, $this->ordinal, $this->bodyHash),
        ];
    }
}
