<?php

namespace App\Domain\Ai;

/**
 * TR-18: accumulates the structured facts of one retrieval as
 * HybridKnowledgeRetriever actually makes its decisions, so the trace is
 * built alongside the real filtering rather than reconstructed afterward
 * from a guess about what must have happened.
 *
 * Deliberately dumb: this class records facts a caller hands it. It never
 * decides anything itself, and it never receives or stores passage body
 * text - only the locators (`source public id`, `version number`, `ordinal`,
 * `body hash`) that already identify a passage everywhere else in this
 * codebase (TR-14's `CitationAnchor`), plus scores and authority facts that
 * are themselves numbers and short labels, never narrative.
 */
final class RetrievalTraceRecorder
{
    private array $stages = [];

    private array $currentExclusions = [];

    private string $currentStage = '';

    private int $sqlCandidateCount = 0;

    private array $authorizationState = [];

    private array $chunkingVersions = [];

    private array $finalCandidates = [];

    public function recordAuthorizationState(array $state): void
    {
        $this->authorizationState = $state;
    }

    public function recordSqlCandidateCount(int $count): void
    {
        $this->sqlCandidateCount = $count;
    }

    /**
     * Starts a new filtering stage. Any exclusions recorded via exclude()
     * after this call, and before the next startStage(), belong to $name.
     */
    public function startStage(string $name): void
    {
        $this->flushStage();
        $this->currentStage = $name;
    }

    /** @param array{source_public_id: ?string, version_number: ?int, ordinal: ?int} $locator */
    public function exclude(array $locator, string $reason): void
    {
        $this->currentExclusions[] = $locator + ['reason' => $reason];
    }

    public function noteChunkingVersion(?string $version): void
    {
        if ($version !== null && ! in_array($version, $this->chunkingVersions, true)) {
            $this->chunkingVersions[] = $version;
        }
    }

    /**
     * The surviving candidate set as it stood right before the model was
     * called - locators, scores, and authority facts only, never body text.
     *
     * @param  list<array<string,mixed>>  $candidates
     */
    public function recordFinalCandidates(array $candidates): void
    {
        $this->finalCandidates = $candidates;
    }

    private function flushStage(): void
    {
        if ($this->currentStage === '') {
            return;
        }
        $this->stages[] = ['stage' => $this->currentStage, 'excluded' => $this->currentExclusions];
        $this->currentExclusions = [];
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $this->flushStage();
        $this->currentStage = '';

        return [
            'authorization_state' => $this->authorizationState,
            'sql_candidate_count' => $this->sqlCandidateCount,
            'stages' => $this->stages,
            'chunking_versions' => $this->chunkingVersions,
            'final_candidates' => $this->finalCandidates,
        ];
    }
}
