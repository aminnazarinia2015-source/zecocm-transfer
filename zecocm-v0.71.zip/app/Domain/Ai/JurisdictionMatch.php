<?php

namespace App\Domain\Ai;

/**
 * TR-13's other axis: `knowledge_sources.jurisdiction` is captured at ingest
 * (defaulting to the project's own state, per `KnowledgeController::ingest()`)
 * and nothing at retrieval time ever compared it against the asking project's
 * actual jurisdiction. Two tenants each running a `regulatory` corpus tagged
 * `state_public_contract_code` - one for California, one for Nevada - would
 * cross-pollinate the moment both matched the same corpus name, because
 * corpus membership was the only gate `HybridKnowledgeRetriever` ever
 * checked. A California project citing Nevada's public contract code is a
 * wrong-jurisdiction answer delivered with full confidence.
 *
 * Deliberately scoped to what this codebase can actually verify: `Project`
 * carries a two-letter `state` and nothing finer (no city, no county). A
 * source jurisdiction that reads as a state code is checked against it. A
 * source jurisdiction that is anything else - a city name ("City of Atlas"),
 * "federal", blank, or free text - is left alone rather than guessed at,
 * because a wrong guess here is worse than no check: city- and federal-level
 * sources are already scoped correctly by `collection`/`corpora`, and forcing
 * a match this codebase cannot verify would produce false rejections of
 * legitimate content, not a safety improvement.
 */
final class JurisdictionMatch
{
    /** Collections this check applies to - the shared regulatory corpora, never a project's own instruments. */
    public const GATED_COLLECTIONS = ['regulatory'];

    public static function permits(?string $sourceJurisdiction, string $collection, string $projectState): bool
    {
        if (! in_array($collection, self::GATED_COLLECTIONS, true)) {
            return true;
        }

        $source = self::normaliseStateCode($sourceJurisdiction);
        if ($source === null) {
            // Not a recognisable state code (unset, "federal", a city name, free
            // text). Out of this check's scope - see class doc.
            return true;
        }

        return $source === strtoupper(trim($projectState));
    }

    private static function normaliseStateCode(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = strtoupper(trim($value));

        return preg_match('/^[A-Z]{2}$/', $value) === 1 ? $value : null;
    }
}
