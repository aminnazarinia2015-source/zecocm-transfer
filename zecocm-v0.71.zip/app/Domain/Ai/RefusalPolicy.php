<?php

namespace App\Domain\Ai;

/**
 * Category-level conservative defaults (Aspect 32): some subject matter
 * routes straight to escalation regardless of how clear the documents look.
 * Configurable per project; these are the shipped defaults.
 */
final class RefusalPolicy
{
    /**
     * The three original categories covered questions that could hurt someone.
     * They did not cover the questions that decide money and liability, which is
     * most of what a construction platform is actually asked. A cited passage can
     * be perfectly accurate and the conclusion drawn from it still be a
     * professional opinion that TRACE has no standing to give:
     *
     *  - differing_site_conditions: whether a condition is Type I or II is an
     *    entitlement determination, not a document lookup.
     *  - means_and_methods: contractually the contractor's sole responsibility;
     *    an owner-side tool answering it transfers liability by accident.
     *  - cost_quantum: what an impact is worth is an expert opinion.
     *  - schedule_causation: concurrency and but-for delay analysis is contested
     *    expert territory even when every date in the file is undisputed.
     *  - safety_direction: telling a crew how to do something safely is
     *    direction, and direction carries duty.
     *
     * @var list<string>
     */
    public const DEFAULT_ESCALATIONS = [
        'structural_adequacy',
        'life_safety',
        'code_equivalency',
        'differing_site_conditions',
        'means_and_methods',
        'cost_quantum',
        'schedule_causation',
        'safety_direction',
    ];

    /** @var list<string> */
    private array $alwaysEscalate;

    /** @param list<string> $alwaysEscalate */
    public function __construct(array $alwaysEscalate = self::DEFAULT_ESCALATIONS)
    {
        $this->alwaysEscalate = $alwaysEscalate;
    }

    public function mustEscalate(string $category): bool
    {
        return in_array($category, $this->alwaysEscalate, true);
    }
}
