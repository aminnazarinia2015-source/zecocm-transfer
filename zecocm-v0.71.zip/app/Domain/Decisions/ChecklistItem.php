<?php

namespace App\Domain\Decisions;

/**
 * One completeness requirement for a formal action, with its epistemic type so the
 * interface can separate a recorded fact from a calculation or a party's assertion.
 */
final class ChecklistItem
{
    public function __construct(
        public readonly string $key,
        public readonly string $label,
        public readonly bool $satisfied,
        public readonly string $classification, // fact|deterministic_calculation|assertion|policy
        public readonly ?string $detail = null,
        public readonly bool $blocking = true,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'key' => $this->key,
            'label' => $this->label,
            'satisfied' => $this->satisfied,
            'classification' => $this->classification,
            'detail' => $this->detail,
            'blocking' => $this->blocking,
        ];
    }
}
