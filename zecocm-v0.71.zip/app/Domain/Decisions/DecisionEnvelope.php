<?php

namespace App\Domain\Decisions;

use App\Domain\Schedule\ProjectGrant;
use App\Models\EvidenceLink;
use App\Models\MediaItem;

/**
 * A sealed object describing ONE formal action before it happens: what is being
 * decided, what evidence supports it, which clock governs it, who may authorise it,
 * and exactly what will happen if they do.
 *
 * Nothing here decides anything. The envelope reports readiness; an accountable
 * human authorises, and only then is anything sealed.
 */
final class DecisionEnvelope
{
    /** @param list<ChecklistItem> $checklist */
    public function __construct(
        public readonly string $actionKey,        // rfi.respond | submittal.stamp | daily.lock
        public readonly string $title,
        public readonly string $recordRef,
        public readonly int $recordId,
        public readonly string $state,
        public readonly array $checklist,
        public readonly array $authority,         // who may authorise, and may the caller
        public readonly array $clock,             // deterministic contract clock facts
        public readonly array $evidence,          // linked, hash-sealed evidence
        public readonly array $consequences,      // what authorising will actually do
        public readonly array $assumptions = [],
        public readonly ?string $blockedReason = null,
    ) {}

    public function isReady(): bool
    {
        return $this->state === DecisionState::READY;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'action' => $this->actionKey,
            'title' => $this->title,
            'record_ref' => $this->recordRef,
            'record_id' => $this->recordId,
            'state' => $this->state,
            'ready' => $this->isReady(),
            'blocked_reason' => $this->blockedReason,
            'checklist' => array_map(fn (ChecklistItem $c) => $c->toArray(), $this->checklist),
            'authority' => $this->authority,
            'clock' => $this->clock,
            'evidence' => $this->evidence,
            'consequences' => $this->consequences,
            'assumptions' => $this->assumptions,
            'notice' => 'ZecoCM does not issue formal actions on its own. Authorising this envelope records YOUR decision, under your identity, permanently.',
        ];
    }

    /**
     * Evidence linked to a record, with its provenance seal. This is the evidence
     * drawer's data: every item carries its own hash and capture record.
     *
     * @return list<array<string,mixed>>
     */
    public static function evidenceFor(string $recordType, int $recordId, ProjectGrant $grant): array
    {
        $links = EvidenceLink::query()
            ->where('record_type', $recordType)
            ->where('record_id', $recordId)
            ->get();
        if ($links->isEmpty()) {
            return [];
        }
        $media = MediaItem::query()->whereIn('id', $links->pluck('media_item_id'))->get()->keyBy('id');

        $out = [];
        foreach ($links as $link) {
            $m = $media[$link->media_item_id] ?? null;
            if ($m === null) {
                continue;
            }
            $row = [
                'media_id' => $m->id,
                'name' => $m->original_name,
                'mime' => $m->mime,
                'bytes' => $m->bytes,
                'classification' => 'fact',
                'linked_by' => $link->linked_by,
                'linked_at' => optional($link->created_at)->toIso8601String(),
            ];
            // Source hashes and the provenance record are authorization-filtered.
            if ($grant->allows('records.view_source_metadata') || $grant->allows('*')) {
                $row['sha256'] = $m->sha256;
                $row['confidence'] = $m->confidence;
                $row['provenance'] = $m->provenance;
                $row['sealed'] = $m->provenance_signature !== null;
            }
            $out[] = $row;
        }

        return $out;
    }
}
