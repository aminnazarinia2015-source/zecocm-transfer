<?php

namespace App\Domain\Decisions;

use App\Domain\Schedule\ProjectGrant;
use App\Models\DailyReport;
use App\Models\Rfi;
use App\Models\ScheduleVersion;
use App\Models\Submittal;
use App\Models\User;
use DateTimeImmutable;

/**
 * Builds the decision envelope for each formal action ZecoCM supports today.
 *
 * Every value here is a recorded fact or a deterministic calculation from the
 * project's own contract settings. Nothing is inferred, and no responsibility or
 * fault is attributed.
 */
final class EnvelopeBuilder
{
    public function forRfiResponse(Rfi $rfi, ProjectGrant $grant, User $user): DecisionEnvelope
    {
        $project = $grant->project;
        $clock = $this->clockFacts($project, ['rfi_response', 'rfi'], $rfi->raised_at);

        $evidence = DecisionEnvelope::evidenceFor('rfi', $rfi->id, $grant);
        $alreadyAnswered = $rfi->status === 'answered';
        $mayAuthorise = $grant->allows('rfi.respond') || $grant->allows('*');

        $checklist = [
            new ChecklistItem('question', 'The question is on the record', trim((string) $rfi->question) !== '',
                'assertion', 'Submitted by '.($rfi->raised_by_org ?: 'the raising party').'. This is that party\'s statement, not a finding.'),
            new ChecklistItem('ball', 'The response is yours to give', ! $alreadyAnswered,
                'fact', $alreadyAnswered ? 'This RFI is already answered and sealed.' : 'Ball in court: '.($rfi->ball_in_court ?: 'unassigned')),
            new ChecklistItem('clock', 'The governing review period is known', $clock['configured'],
                'deterministic_calculation', $clock['configured']
                    ? $clock['period_days'].' '.$clock['basis'].' days from '.$clock['anchor'].' - from this project\'s contract settings.'
                    : 'No RFI review clock is configured in Project settings, so no due date can be computed.'),
            new ChecklistItem('evidence', 'Supporting evidence attached', count($evidence) > 0,
                'fact', count($evidence) > 0
                    ? count($evidence).' sealed item(s) linked to this RFI.'
                    : 'No evidence is linked. A response may still be given; the record will show none was attached.',
                blocking: false),
            new ChecklistItem('authority', 'You hold the authority to respond', $mayAuthorise,
                'policy', $mayAuthorise ? 'Your project grant includes rfi.respond.' : 'Your project grant does not include rfi.respond.'),
        ];

        return new DecisionEnvelope(
            actionKey: 'rfi.respond',
            title: 'Send and seal an RFI response',
            recordRef: (string) $rfi->number,
            recordId: $rfi->id,
            state: $this->state($checklist, $alreadyAnswered, $mayAuthorise),
            checklist: $checklist,
            authority: [
                'required_capability' => 'rfi.respond',
                'caller_may_authorise' => $mayAuthorise,
                'caller' => ['id' => $user->id, 'name' => $user->name, 'seat' => $grant->seat, 'organization' => $grant->organization],
                'accountable' => 'The response is recorded under your identity and cannot be edited afterwards.',
            ],
            clock: $clock,
            evidence: $evidence,
            consequences: [
                'seals' => 'The response text, your identity and the server timestamp become a permanent part of this RFI.',
                'status_change' => 'open -> answered',
                'ball_moves_to' => $rfi->raised_by_org ?: 'the raising party',
                'reversible' => false,
                'corrections' => 'A later correction appends to the record; it never overwrites this response.',
            ],
            assumptions: $clock['configured'] ? [] : ['No RFI review clock configured: this envelope reports no due date rather than assuming one.'],
            blockedReason: $alreadyAnswered ? 'This RFI has already been answered and sealed.'
                : (! $mayAuthorise ? 'Your project grant does not include rfi.respond.' : null),
        );
    }

    public function forSubmittalStamp(Submittal $submittal, ProjectGrant $grant, User $user): DecisionEnvelope
    {
        $project = $grant->project;
        $clock = $this->clockFacts($project, ['submittal_review'], $submittal->submitted_at);
        $evidence = DecisionEnvelope::evidenceFor('submittal', $submittal->id, $grant);
        $decided = in_array($submittal->status, ['no_exceptions', 'rejected', 'revise_resubmit'], true);
        $mayAuthorise = $grant->allows('submittal.stamp') || $grant->allows('*');

        $checklist = [
            new ChecklistItem('spec', 'Specification section recorded', trim((string) $submittal->spec_section) !== '',
                'fact', 'Spec § '.($submittal->spec_section ?: 'not recorded').' - drives discipline routing.'),
            new ChecklistItem('submitted', 'Submission date recorded', ! empty($submittal->submitted_at),
                'fact', 'The review clock runs from the recorded submission date.'),
            new ChecklistItem('clock', 'The governing review period is known', $clock['configured'],
                'deterministic_calculation', $clock['configured']
                    ? $clock['period_days'].' '.$clock['basis'].' days from '.$clock['anchor'].'.'
                    : 'No submittal review clock is configured in Project settings.'),
            new ChecklistItem('evidence', 'Submitted documents attached', count($evidence) > 0,
                'fact', count($evidence) > 0 ? count($evidence).' sealed item(s) linked.' : 'No documents are linked to this submittal.',
                blocking: false),
            new ChecklistItem('undecided', 'Not already dispositioned', ! $decided,
                'fact', $decided ? 'A stamp has already been recorded: '.$submittal->status : 'No stamp recorded yet.'),
            new ChecklistItem('authority', 'You hold the authority to stamp', $mayAuthorise,
                'policy', $mayAuthorise ? 'Your project grant includes submittal.stamp.' : 'Your project grant does not include submittal.stamp.'),
        ];

        return new DecisionEnvelope(
            actionKey: 'submittal.stamp',
            title: 'Stamp a submittal',
            recordRef: (string) $submittal->number,
            recordId: $submittal->id,
            state: $this->state($checklist, $decided, $mayAuthorise),
            checklist: $checklist,
            authority: [
                'required_capability' => 'submittal.stamp',
                'caller_may_authorise' => $mayAuthorise,
                'caller' => ['id' => $user->id, 'name' => $user->name, 'seat' => $grant->seat, 'organization' => $grant->organization],
                'accountable' => 'The stamp is a formal determination recorded under your identity.',
            ],
            clock: $clock,
            evidence: $evidence,
            consequences: [
                'seals' => 'Your stamp, identity and timestamp become part of the permanent submittal record.',
                'status_change' => $submittal->status.' -> the disposition you choose',
                'ball_moves_to' => $submittal->submitted_by_org ?: 'the submitting party',
                'reversible' => false,
                'corrections' => 'A revised submittal is a new record; this stamp is never rewritten.',
            ],
            blockedReason: $decided ? 'This submittal already carries a recorded disposition.'
                : (! $mayAuthorise ? 'Your project grant does not include submittal.stamp.' : null),
        );
    }

    public function forScheduleDisposition(ScheduleVersion $version, ProjectGrant $grant, User $user, string $disposition): DecisionEnvelope
    {
        if (! in_array($disposition, ['accepted', 'rejected'], true)) {
            throw new \InvalidArgumentException('Schedule disposition must be accepted or rejected.');
        }

        $latestEvent = $version->events()->orderByDesc('id')->first();
        $mayAuthorise = $grant->allows('schedule.review') || $grant->allows('*');
        $label = trim((string) $version->label);
        $hasSource = trim((string) $version->source_sha256) !== '' && (int) $version->row_count > 0;

        $checklist = [
            new ChecklistItem('source', 'Immutable submitted schedule artifact is recorded', $hasSource,
                'fact', $hasSource
                    ? 'Source hash and parsed activity rows are recorded for this immutable version.'
                    : 'The immutable source record is incomplete; disposition is blocked.'),
            new ChecklistItem('label', 'Submitter label is treated only as source metadata', true,
                'assertion', 'Submitter label: '.($label !== '' ? $label : 'not supplied').'. This wording is not an acceptance or rejection determination.',
                blocking: false),
            new ChecklistItem('requested_disposition', 'The requested human determination is explicit', true,
                'fact', 'Requested disposition: '.$disposition.'. This is the action the accountable user is being asked to authorise.'),
            new ChecklistItem('prior_disposition', 'Prior disposition history remains preserved', true,
                'fact', $latestEvent
                    ? 'Latest recorded disposition: '.($latestEvent->disposition ?: 'none').'. A new determination appends; it does not rewrite this event.'
                    : 'No prior disposition event exists. A determination will append the first event.',
                blocking: false),
            new ChecklistItem('authority', 'You hold the authority to disposition this schedule version', $mayAuthorise,
                'policy', $mayAuthorise ? 'Your project grant includes schedule.review.' : 'Your project grant does not include schedule.review.'),
        ];

        return new DecisionEnvelope(
            actionKey: 'schedule.disposition.'.$disposition,
            title: ucfirst($disposition).' schedule version',
            recordRef: 'Schedule version '.$version->id.' - '.($label !== '' ? $label : 'unlabelled'),
            recordId: $version->id,
            state: $this->state($checklist, false, $mayAuthorise),
            checklist: $checklist,
            authority: [
                'required_capability' => 'schedule.review',
                'caller_may_authorise' => $mayAuthorise,
                'caller' => ['id' => $user->id, 'name' => $user->name, 'seat' => $grant->seat, 'organization' => $grant->organization],
                'accountable' => 'The disposition is a formal human determination recorded under your identity. ZecoCM does not infer or assign delay responsibility.',
            ],
            clock: ['configured' => false, 'note' => 'Schedule acceptance/rejection is not computed from a default review clock. No contract period is invented.'],
            evidence: [],
            consequences: [
                'seals' => 'The requested disposition, your identity, note, authorization scope and server timestamp are appended to the schedule version event chain.',
                'status_change' => 'Current projection -> '.$disposition.'; the immutable submitted schedule artifact does not change.',
                'reversible' => false,
                'corrections' => 'A later determination appends another event; prior dispositions and source evidence are never overwritten.',
                'responsibility' => 'No delay responsibility or fault is attributed by this action.',
            ],
            assumptions: [],
            blockedReason: ! $hasSource ? 'The immutable source record is incomplete.'
                : (! $mayAuthorise ? 'Your project grant does not include schedule.review.' : null),
        );
    }

    public function forDailyLock(DailyReport $report, ProjectGrant $grant, User $user): DecisionEnvelope
    {
        $evidence = DecisionEnvelope::evidenceFor('daily_report', $report->id, $grant);
        $locked = (bool) $report->locked;
        $mayAuthorise = $grant->allows('daily.lock') || $grant->allows('*');

        $checklist = [
            new ChecklistItem('date', 'Report date recorded', ! empty($report->report_date), 'fact',
                'Daily reports are filed against a specific calendar date.'),
            new ChecklistItem('work', 'Work performed recorded', trim((string) $report->work_performed) !== '',
                'assertion', 'This is the reporting party\'s account of the day, not an inspection finding.'),
            new ChecklistItem('unlocked', 'Not already sealed', ! $locked, 'fact',
                $locked ? 'Sealed at '.(($report->lock_seal['sealed_at'] ?? null) ?: 'an earlier time') : 'This report is still open for edits.'),
            new ChecklistItem('evidence', 'Photos or attachments linked', count($evidence) > 0, 'fact',
                count($evidence) > 0 ? count($evidence).' sealed item(s) linked.' : 'No media linked to this report.',
                blocking: false),
            new ChecklistItem('authority', 'You hold the authority to seal', $mayAuthorise, 'policy',
                $mayAuthorise ? 'Your project grant includes daily.lock.' : 'Your project grant does not include daily.lock.'),
        ];

        return new DecisionEnvelope(
            actionKey: 'daily.lock',
            title: 'Sign and seal a daily report',
            recordRef: 'DR-'.$report->id,
            recordId: $report->id,
            state: $this->state($checklist, $locked, $mayAuthorise),
            checklist: $checklist,
            authority: [
                'required_capability' => 'daily.lock',
                'caller_may_authorise' => $mayAuthorise,
                'caller' => ['id' => $user->id, 'name' => $user->name, 'seat' => $grant->seat, 'organization' => $grant->organization],
                'accountable' => 'Sealing binds this day\'s account to your identity permanently.',
            ],
            clock: ['configured' => false, 'note' => 'Daily reports are sealed on signature, not against a review clock.'],
            evidence: $evidence,
            consequences: [
                'seals' => 'The report contents, your identity and the server timestamp are sealed.',
                'status_change' => 'open -> locked',
                'reversible' => false,
                'corrections' => 'Corrections append to a sealed daily report; the original text is never altered.',
            ],
            blockedReason: $locked ? 'This report is already sealed.'
                : (! $mayAuthorise ? 'Your project grant does not include daily.lock.' : null),
        );
    }

    /** @param list<ChecklistItem> $checklist */
    private function state(array $checklist, bool $alreadyDone, bool $mayAuthorise): string
    {
        if ($alreadyDone) {
            return DecisionState::COMPLETE;
        }
        foreach ($checklist as $item) {
            if ($item->blocking && ! $item->satisfied && $item->key !== 'authority') {
                return $item->key === 'evidence' ? DecisionState::AWAITING_EVIDENCE : DecisionState::BLOCKED;
            }
        }
        if (! $mayAuthorise) {
            return DecisionState::AWAITING_AUTHORISATION;
        }

        return DecisionState::READY;
    }

    /** Deterministic clock facts from the project's own contract settings. */
    private function clockFacts($project, array $names, $anchor): array
    {
        foreach ($names as $name) {
            try {
                $clock = $project->clock($name);
            } catch (\Throwable) {
                continue;
            }
            $facts = [
                'configured' => true,
                'name' => $name,
                'period_days' => $clock->periodDays,
                'basis' => $clock->basis,
                'anchor' => $anchor ? (string) (is_string($anchor) ? substr($anchor, 0, 10) : $anchor->format('Y-m-d')) : null,
                'source' => 'Project settings - the contract governs, not a system default.',
            ];
            if ($anchor) {
                try {
                    $due = $clock->dueFrom(new DateTimeImmutable($facts['anchor']));
                    $facts['due'] = $due->format('Y-m-d');
                    $facts['days_late'] = max(0, (int) floor((now()->getTimestamp() - $due->getTimestamp()) / 86400));
                    $facts['in_window'] = $facts['days_late'] === 0;
                } catch (\Throwable) {
                }
            }

            return $facts;
        }

        return ['configured' => false, 'note' => 'No matching clock is configured for this project.'];
    }
}
