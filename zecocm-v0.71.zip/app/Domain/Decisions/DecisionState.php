<?php

namespace App\Domain\Decisions;

/**
 * The decision states every screen must be able to show. A formal action is never
 * simply "enabled" - it is ready, or it is blocked for a reason the user can read.
 */
final class DecisionState
{
    public const READY = 'ready';                                 // may be authorised now

    public const AWAITING_EVIDENCE = 'awaiting_evidence';         // required evidence missing

    public const AWAITING_PARTY = 'awaiting_party';               // the ball is with someone else

    public const AWAITING_AUTHORISATION = 'awaiting_authorisation'; // ready, but not by this user

    public const BLOCKED = 'blocked';                              // a hard precondition fails

    public const DISPUTED = 'disputed';                            // parties disagree on a fact

    public const COMPLETE = 'complete';                            // already sealed
}
