<?php

namespace App\Domain\Compliance;

/**
 * Whether the certified payroll supports paying this application.
 *
 * On California public works, certified payroll is a condition of payment, not
 * paperwork that follows it. A missing or non-compliant record is grounds for
 * withholding, and the withholding is on the whole progress payment - not on the
 * affected worker's hours. That asymmetry is why this belongs beside the pay
 * application rather than in an HR module: one missing weekly record can hold up
 * a six-figure payment.
 *
 * These checks produce WITHHOLD findings, in Codex's severity scheme. The
 * application may be perfectly proper; the money is held for a separate
 * compliance reason, and conflating that with an improper request would start the
 * wrong statutory clock.
 *
 * A finding is NOT a withholding. Codex attacked the first version of this class
 * for collapsing the two, and was right: a condition that is grounds for
 * withholding is not the same as an amount ZecoCM may assert is held. Two axes
 * now travel with every finding.
 *
 *   eligibility - may this software put a number on it?
 *     computable            the exposure follows arithmetically from a governing
 *                           determination and a filed record.
 *     estimate_only         a real hold, but the amount is the agency's to set.
 *     requires_determination no dollar figure may be asserted at all. An
 *                           uncovered classification has no rate to compute
 *                           against, and inventing one would be inventing the
 *                           violation.
 *     informational         a trajectory, not yet a violation. An apprentice
 *                           ratio is measured over the project, so a mid-project
 *                           shortfall is a warning and nothing else.
 *
 *   release - what ends it?
 *     evidence       producing the required record ends it. Under 8 CCR s. 16435
 *                    withholding may NOT continue solely for delinquent or
 *                    inadequate payroll once the records are produced - so a
 *                    system that keeps this finding alive after the filing is
 *                    itself out of compliance.
 *     determination  a human or enforcement act ends it. Uploading a corrected
 *                    payroll does not release an established underpayment.
 *
 * exposure_key exists for the stacking rule: a provisional estimate and a later
 * established amount against the same employer, period and legal basis are the
 * same liability seen twice, and must never be summed.
 */
final class CertifiedPayrollCheck
{
    /**
     * @param  list<array{worker: string, classification: string, hours: float, hourly_paid_cents: int, fringe_paid_cents?: int}>  $records
     * @param  array<string,PrevailingWageDetermination>  $determinations  keyed by classification
     * @return list<array{severity: string, code: string, message: string, citation: ?string}>
     */
    public static function findings(array $records, array $determinations, array $context = []): array
    {
        $findings = [];

        foreach ($records as $record) {
            $classification = (string) ($record['classification'] ?? '');
            $determination = $determinations[$classification] ?? null;

            if ($determination === null) {
                // Not a violation - an unknown. Saying "underpaid" without a rate
                // to compare against would be inventing the finding.
                $findings[] = self::finding('withhold', 'no_determination_for_classification',
                    'No prevailing wage determination is on file for the classification "'.$classification
                    .'" worked by '.($record['worker'] ?? 'a worker')
                    .'. Without the governing determination the rate cannot be checked. ZecoCM will not put an amount on this: where a craft is not covered by a general determination the awarding body may need a special determination, and a number invented here would be an invented violation.', null,
                    eligibility: self::REQUIRES_DETERMINATION, release: self::RELEASE_DETERMINATION,
                    exposureKey: self::key($context, 'classification_uncovered', $classification));

                continue;
            }

            $paid = (int) ($record['hourly_paid_cents'] ?? 0) + (int) ($record['fringe_paid_cents'] ?? 0);
            $owed = $determination->totalHourlyCents();

            if ($paid < $owed) {
                $short = $owed - $paid;
                $hours = (float) ($record['hours'] ?? 0);
                $findings[] = self::finding('withhold', 'paid_below_determination',
                    ($record['worker'] ?? 'A worker').' was paid $'.number_format($paid / 100, 2)
                    .' per hour against a determination of $'.number_format($owed / 100, 2)
                    .' for '.$classification.'. Short by $'.number_format($short / 100, 2).' per hour over '
                    .rtrim(rtrim(number_format($hours, 2, '.', ''), '0'), '.').' hours - $'
                    .number_format(($short * $hours) / 100, 2).' in total. This is grounds for withholding the progress payment, not just the difference. Releasing it takes an enforcement or awarding-body determination - a corrected payroll filed afterwards does not by itself end it.',
                    $determination->source,
                    eligibility: self::COMPUTABLE, release: self::RELEASE_DETERMINATION,
                    exposureKey: self::key($context, 'underpayment', $classification),
                    exposureCents: (int) round($short * $hours));
            }
        }

        foreach ((array) ($context['weeks_without_records'] ?? []) as $week) {
            // The commonest cause of a held payment, and the least dramatic: a
            // week where work was billed and no payroll was filed.
            $findings[] = self::finding('withhold', 'missing_weekly_record',
                'No certified payroll record was filed for the week ending '.$week
                .', and work was billed in that period. A missing weekly record is grounds for withholding the progress payment. The amount is the awarding body\'s to set, and under 8 CCR s. 16435 the withholding cannot continue on this basis once the required records are produced.',
                '8 CCR s. 16435',
                eligibility: self::ESTIMATE_ONLY, release: self::RELEASE_EVIDENCE,
                exposureKey: self::key($context, 'payroll_delinquent', $week));
        }

        if (($context['apprentice_hours'] ?? null) !== null && ($context['journeyman_hours'] ?? null) !== null) {
            $apprentice = (float) $context['apprentice_hours'];
            $journeyman = (float) $context['journeyman_hours'];
            $required = (float) ($context['required_apprentice_ratio'] ?? 0.2);

            if ($journeyman > 0 && ($apprentice / $journeyman) < $required) {
                // Measured over the project, not over one billing period. A
                // mid-project shortfall is still curable, so it must not create
                // held money on its own - only at closeout, and even then the
                // penalty is a determination somebody makes.
                $complete = (bool) ($context['project_complete'] ?? false);

                $findings[] = self::finding('withhold', 'apprentice_ratio_short',
                    'Apprentice hours are '.round(($apprentice / $journeyman) * 100, 1)
                    .'% of journeyman hours against a required '.round($required * 100, 1)
                    .'%. '.($complete
                        ? 'The project is complete, so the shortfall is final and carries its own penalty - which is an awarding-body or DAS determination, not a figure ZecoCM asserts.'
                        : 'Apprentice hours are measured over the whole project, so this is a trajectory and not yet a violation. It is curable, and no money is held on it.'),
                    $context['apprentice_citation'] ?? null,
                    eligibility: $complete ? self::REQUIRES_DETERMINATION : self::INFORMATIONAL,
                    release: self::RELEASE_DETERMINATION,
                    exposureKey: self::key($context, 'apprentice_ratio', 'project'));
            }
        }

        return $findings;
    }

    public const COMPUTABLE = 'computable';
    public const ESTIMATE_ONLY = 'estimate_only';
    public const REQUIRES_DETERMINATION = 'requires_determination';
    public const INFORMATIONAL = 'informational';

    public const RELEASE_EVIDENCE = 'evidence';
    public const RELEASE_DETERMINATION = 'determination';

    /**
     * The findings this software may attach a dollar figure to. Everything else
     * is a condition somebody with authority has to price.
     *
     * @param  list<array<string,mixed>>  $findings
     * @return list<array<string,mixed>>
     */
    public static function monetary(array $findings): array
    {
        return array_values(array_filter(
            $findings,
            fn ($f) => ($f['eligibility'] ?? null) === self::COMPUTABLE,
        ));
    }

    /**
     * Codex's stacking rule. A provisional estimate and a later established
     * amount against the same employer, period and legal basis are one liability
     * seen twice. Summing them would withhold the same wages twice.
     *
     * @param  list<array<string,mixed>>  $findings
     * @return list<array<string,mixed>>
     */
    public static function collapseOverlappingExposure(array $findings): array
    {
        $byKey = [];
        foreach ($findings as $finding) {
            $key = $finding['exposure_key'] ?? null;
            if ($key === null) {
                $byKey[] = $finding;

                continue;
            }

            $existing = $byKey[$key] ?? null;
            // An established amount replaces a provisional estimate of the same
            // liability. It never adds to it.
            if ($existing === null
                || (($existing['eligibility'] ?? null) === self::ESTIMATE_ONLY
                    && ($finding['eligibility'] ?? null) === self::COMPUTABLE)) {
                $byKey[$key] = $finding;
            }
        }

        return array_values($byKey);
    }

    private static function key(array $context, string $basis, string $scope): string
    {
        $employer = (string) ($context['employer'] ?? 'unidentified_employer');

        return $employer.'|'.$basis.'|'.$scope;
    }

    private static function finding(
        string $severity,
        string $code,
        string $message,
        ?string $citation,
        string $eligibility = self::REQUIRES_DETERMINATION,
        string $release = self::RELEASE_DETERMINATION,
        ?string $exposureKey = null,
        ?int $exposureCents = null,
    ): array {
        return compact('severity', 'code', 'message', 'citation')
            + ['eligibility' => $eligibility, 'release' => $release,
                'exposure_key' => $exposureKey, 'exposure_cents' => $exposureCents];
    }
}
