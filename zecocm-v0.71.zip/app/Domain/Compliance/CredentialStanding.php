<?php

namespace App\Domain\Compliance;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * Was this credential good on the day the work was done?
 *
 * Not "is it good now". A subcontractor whose licence lapsed in March and was
 * reinstated in May looks perfectly current today and was unlicensed for the
 * April pour. Under Business and Professions Code s. 7031 an unlicensed
 * contractor cannot enforce payment for that work and can be ordered to
 * disgorge what it was already paid - so the question a payment application has
 * to ask is about the period being billed, never about today.
 *
 * Every other compliance check in this codebase already works this way. This is
 * the same idea applied to the companies rather than to the documents.
 */
final class CredentialStanding
{
    public const VALID = 'valid';
    public const EXPIRED = 'expired';
    public const NOT_YET_EFFECTIVE = 'not_yet_effective';
    public const UNKNOWN = 'unknown';

    /** Credentials whose absence is a legal bar, not an administrative annoyance. */
    public const STATUTORY = ['cslb_license', 'dir_registration'];

    /**
     * @param  array{credential_type: string, effective_from: mixed, expires_on: mixed, document_on_file?: bool, verified_at?: mixed}  $credential
     * @return array{state: string, statutory: bool, message: string}
     */
    public static function on(array $credential, DateTimeInterface $asOf): array
    {
        $type = (string) ($credential['credential_type'] ?? 'unknown');
        $statutory = in_array($type, self::STATUTORY, true);
        $label = self::label($type);

        $from = self::date($credential['effective_from'] ?? null);
        $until = self::date($credential['expires_on'] ?? null);

        // A window nobody recorded is not a valid window. Treating an unknown
        // date as "probably fine" is how an expired certificate sits in a file
        // for a year looking like compliance.
        if ($from === null && $until === null) {
            return self::result(self::UNKNOWN, $statutory,
                $label.' is recorded with no effective or expiry date, so whether it covered '
                .$asOf->format('j M Y').' cannot be established from the record.');
        }

        if ($from !== null && $asOf < $from) {
            return self::result(self::NOT_YET_EFFECTIVE, $statutory,
                $label.' did not take effect until '.$from->format('j M Y')
                .', which is after the work being considered on '.$asOf->format('j M Y').'.');
        }

        if ($until !== null && $asOf > $until) {
            return self::result(self::EXPIRED, $statutory,
                $label.' expired on '.$until->format('j M Y').', before the work on '
                .$asOf->format('j M Y').'.'
                .($statutory
                    ? ' This is a statutory bar, not a paperwork gap - the lapse is not cured by the credential being current again now.'
                    : ''));
        }

        return self::result(self::VALID, $statutory,
            $label.' was in force on '.$asOf->format('j M Y').'.');
    }

    /**
     * Findings for a whole set, in the severity scheme the payment review uses.
     *
     * A statutory lapse is HARD_INVALID because the work itself was unlawful and
     * the contract for it may be unenforceable. An insurance gap is a
     * WITHHOLD - the work happened and may be perfectly good, and the exposure
     * belongs to whoever carried the risk.
     *
     * @param  list<array<string,mixed>>  $credentials
     * @param  list<string>  $required
     * @return list<array{severity: string, code: string, message: string, citation: ?string}>
     */
    public static function findings(array $credentials, DateTimeInterface $asOf, array $required = []): array
    {
        $findings = [];
        $seen = [];

        foreach ($credentials as $credential) {
            $type = (string) ($credential['credential_type'] ?? '');
            $seen[$type] = true;
            $standing = self::on($credential, $asOf);

            if ($standing['state'] === self::VALID) {
                // Present, in force, and nobody has actually looked at it.
                if (($credential['document_on_file'] ?? false) !== true) {
                    $findings[] = self::finding('withhold', 'credential_document_missing',
                        self::label($type).' is recorded as in force, but the certificate itself is not on file. '
                        .'A number typed into a box is not a certificate.', null);
                }

                continue;
            }

            $findings[] = self::finding(
                $standing['statutory'] ? 'hard_invalid' : 'withhold',
                $standing['statutory'] ? 'statutory_credential_lapsed' : 'insurance_credential_lapsed',
                $standing['message'],
                match ($type) {
                    'cslb_license' => 'California Business and Professions Code s. 7031',
                    'dir_registration' => 'California Labor Code s. 1725.5',
                    default => null,
                },
            );
        }

        foreach ($required as $type) {
            if (! isset($seen[$type])) {
                $statutory = in_array($type, self::STATUTORY, true);
                $findings[] = self::finding(
                    $statutory ? 'hard_invalid' : 'withhold',
                    'credential_missing',
                    self::label($type).' is required on this work and no record of it exists at all.',
                    match ($type) {
                        'cslb_license' => 'California Business and Professions Code s. 7031',
                        'dir_registration' => 'California Labor Code s. 1725.5',
                        default => null,
                    },
                );
            }
        }

        return $findings;
    }

    /** Credentials lapsing within the window, so somebody can chase them before they bite. */
    public static function expiringWithin(array $credentials, DateTimeInterface $from, int $days): array
    {
        $limit = (new DateTimeImmutable($from->format('Y-m-d')))->modify('+'.$days.' days');
        $out = [];

        foreach ($credentials as $credential) {
            $until = self::date($credential['expires_on'] ?? null);
            if ($until !== null && $until >= $from && $until <= $limit) {
                $out[] = $credential + ['days_remaining' => (int) $from->diff($until)->days];
            }
        }

        return $out;
    }

    private static function label(string $type): string
    {
        return [
            'cslb_license' => 'The CSLB contractor licence',
            'dir_registration' => 'DIR public works registration',
            'general_liability' => 'General liability insurance',
            'auto_liability' => 'Automobile liability insurance',
            'workers_comp' => "Workers' compensation insurance",
            'umbrella' => 'Umbrella liability coverage',
            'payment_bond' => 'The payment bond',
            'performance_bond' => 'The performance bond',
        ][$type] ?? 'A required credential';
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format('Y-m-d'));
        }

        return new DateTimeImmutable((string) $value);
    }

    private static function result(string $state, bool $statutory, string $message): array
    {
        return ['state' => $state, 'statutory' => $statutory, 'message' => $message];
    }

    private static function finding(string $severity, string $code, string $message, ?string $citation): array
    {
        return compact('severity', 'code', 'message', 'citation') + ['gate' => 'internal'];
    }
}
