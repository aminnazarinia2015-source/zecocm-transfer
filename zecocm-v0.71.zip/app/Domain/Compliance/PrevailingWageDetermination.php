<?php

namespace App\Domain\Compliance;

/**
 * The rate a classification must be paid on this project, and where it came from.
 *
 * Same rule as every clock and the retention rate: never invented. A prevailing
 * wage determination is a published document with an issue date and an expiration,
 * and the one that governs is the one in effect when the contract was awarded -
 * not the newest one, and not whatever someone remembers. Getting that wrong
 * underpays workers and creates a penalty exposure that survives the job.
 *
 * On California public works the determination is issued by the Director of
 * Industrial Relations. Rates are per straight-time hour, plus fringe.
 */
final class PrevailingWageDetermination
{
    public function __construct(
        public readonly string $craft,
        public readonly string $classification,
        /** Straight-time base hourly rate, in cents. */
        public readonly int $baseRateCents,
        /** Employer fringe obligation per hour, in cents. */
        public readonly int $fringeCents,
        /** The determination number or citation this rate comes from. */
        public readonly string $source,
        public readonly ?string $effectiveFrom = null,
        public readonly ?string $expiresAfter = null,
    ) {
        if (trim($source) === '') {
            throw new \InvalidArgumentException(
                'A prevailing wage rate must cite the determination it comes from. An uncited rate is somebody\'s recollection, and underpaying against a recollection is still underpaying.'
            );
        }

        if ($baseRateCents < 0 || $fringeCents < 0) {
            throw new \InvalidArgumentException('Wage components cannot be negative.');
        }
    }

    /** Total hourly obligation: base plus fringe. */
    public function totalHourlyCents(): int
    {
        return $this->baseRateCents + $this->fringeCents;
    }

    /**
     * Was this determination in effect on the award date? The governing
     * determination is the one in effect at award, which is why a newer rate
     * appearing mid-job does not retroactively change what is owed.
     */
    public function governsAwardOn(string $awardDate): bool
    {
        if ($this->effectiveFrom !== null && $awardDate < $this->effectiveFrom) {
            return false;
        }

        if ($this->expiresAfter !== null && $awardDate > $this->expiresAfter) {
            return false;
        }

        return true;
    }
}
