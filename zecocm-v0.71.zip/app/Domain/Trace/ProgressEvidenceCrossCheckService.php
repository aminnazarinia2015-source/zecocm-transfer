<?php

namespace App\Domain\Trace;

use App\Models\AiFinding;
use App\Models\DailyReportActivity;
use App\Models\FindingEvidence;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\PayApplicationReviewContext;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use App\Models\SovScheduleLink;

/**
 * TRACE Progress Evidence Cross-Check - runs TRACE-01 and TRACE-02 for one
 * pay application. Closed design: claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Deliberately conservative, per Codex's ruling that closed this design:
 * every finding is an OBSERVATION or a DATA_GAP, never an adjudication. This
 * service never decides a contractor is late, at fault, or unsupported - it
 * only reports what specific records were checked and what was or was not
 * found among them. TRACE-03 (conflicting structured schedule-status) is not
 * implemented here - it is gated on a pay-application field that does not
 * exist yet (see design brief).
 *
 * MVP scope, deliberately narrow:
 *  - only SOV lines with a VERIFIED SovScheduleLink are ever considered -
 *    no runtime AI mapping (Codex's finding (a)).
 *  - only schedule activities classified activity_type=CONSTRUCTION are
 *    eligible - an unclassified or non-field activity produces a
 *    MAPPING_GAP finding rather than being silently skipped (Codex's
 *    point 10, "no silent caps").
 *  - only daily reports that are locked (finalized/signed) count as
 *    evidence (Codex's point 9).
 */
final class ProgressEvidenceCrossCheckService
{
    public const RULE_MISSING_PROGRESS_RECORD = 'TRACE-01';
    public const RULE_OUT_OF_WINDOW_PROGRESS = 'TRACE-02';
    public const RULE_VERSION = '1.0';

    /**
     * A daily report dated more than this many days outside an activity's
     * planned window is "materially outside" it (TRACE-02). Deliberately not
     * zero-tolerance - routine early mobilization or a few days of float
     * usage is normal schedule behavior, not something worth a human's
     * attention. Chosen as a conservative starting point, not derived from
     * project data; revisit once this rule has run against real schedules.
     */
    public const OUT_OF_WINDOW_BUFFER_DAYS = 14;

    /**
     * @return list<AiFinding> findings created for this pay application against
     *   the most current schedule version for its project. Returns an empty
     *   array (not a finding) if the project has no schedule version at all -
     *   there is nothing to cross-check against yet, which is a project-setup
     *   fact, not a TRACE observation.
     */
    public function evaluate(PayApplication $application, ?int $actorId = null): array
    {
        $scheduleVersion = $this->currentScheduleVersion($application);
        if ($scheduleVersion === null) {
            return [];
        }

        $context = $this->context($application, $scheduleVersion, $actorId);

        $findings = [];
        foreach ($application->lines as $line) {
            foreach ($this->evaluateLine($line, $context, $scheduleVersion) as $finding) {
                $findings[] = $finding;
            }
        }

        return $findings;
    }

    /**
     * The schedule version this pay application is compared against. Picked
     * once, at evaluation time, and frozen into a PayApplicationReviewContext
     * immediately - nothing downstream re-resolves "the active schedule"
     * later (Codex's temporal-leakage finding).
     */
    private function currentScheduleVersion(PayApplication $application): ?ScheduleVersion
    {
        return ScheduleVersion::where('project_id', $application->project_id)
            ->orderByDesc('data_date')
            ->first();
    }

    private function context(PayApplication $application, ScheduleVersion $scheduleVersion, ?int $actorId): PayApplicationReviewContext
    {
        return PayApplicationReviewContext::firstOrCreate(
            [
                'pay_application_id' => $application->id,
                'schedule_version_id' => $scheduleVersion->id,
            ],
            [
                'tenant_id' => $application->tenant_id,
                'period_start' => $application->period_from,
                'period_end' => $application->period_to,
                'schedule_data_date' => $scheduleVersion->data_date,
                'created_by' => $actorId,
                'frozen_at' => now(),
            ]
        );
    }

    /** @return list<AiFinding> */
    private function evaluateLine(PayApplicationLine $line, PayApplicationReviewContext $context, ScheduleVersion $scheduleVersion): array
    {
        $links = SovScheduleLink::where('schedule_of_value_item_id', $line->schedule_of_value_item_id)
            ->where('schedule_version_id', $scheduleVersion->id)
            ->where('mapping_status', SovScheduleLink::STATUS_VERIFIED)
            ->where('relationship_type', '!=', SovScheduleLink::RELATIONSHIP_NOT_PROGRESS_BEARING)
            ->get();

        if ($links->isEmpty()) {
            return [$this->mappingGapFinding($line, $context,
                'No verified schedule-activity mapping exists for this SOV line - it cannot yet be cross-checked against the schedule.',
                [])];
        }

        $findings = [];
        foreach ($links as $link) {
            $activity = $link->scheduleActivity;

            if (! $activity->isFieldProduction()) {
                $findings[] = $this->mappingGapFinding($line, $context,
                    "Schedule Activity {$activity->activity_code} is not classified as field-production work (activity_type=".
                    ($activity->activity_type ?? 'unclassified').') - excluded from progress cross-checking rather than assumed eligible.',
                    [['type' => 'schedule_activity', 'id' => $activity->id, 'role' => FindingEvidence::ROLE_CONTEXT]]);
                continue;
            }

            foreach ($this->evaluateActivity($line, $link, $activity, $context) as $finding) {
                $findings[] = $finding;
            }
        }

        return $findings;
    }

    /** @return list<AiFinding> */
    private function evaluateActivity(PayApplicationLine $line, SovScheduleLink $link, ScheduleActivity $activity, PayApplicationReviewContext $context): array
    {
        $periodStart = $context->period_start;
        $periodEnd = $context->period_end;

        $reports = DailyReportActivity::where('schedule_activity_id', $activity->id)
            ->whereHas('dailyReport', fn ($q) => $q->where('locked', true))
            ->with('dailyReport')
            ->get();

        $findings = [];

        $plannedActiveInPeriod = $activity->start_planned !== null
            && $activity->start_planned->lte($periodEnd)
            && ($activity->finish_planned === null || $activity->finish_planned->gte($periodStart));

        if ($plannedActiveInPeriod) {
            $inPeriod = $reports->filter(
                fn (DailyReportActivity $r) => $r->dailyReport->report_date->between($periodStart, $periodEnd)
            );

            if ($inPeriod->isEmpty()) {
                $findings[] = $this->corroborationGapFinding($line, $link, $activity, $context, $reports->count());
            }
        }

        foreach ($reports as $report) {
            if ($this->isMaterallyOutsideWindow($report, $activity)) {
                $findings[] = $this->recordMismatchFinding($line, $link, $activity, $context, $report);
            }
        }

        return $findings;
    }

    private function isMaterallyOutsideWindow(DailyReportActivity $report, ScheduleActivity $activity): bool
    {
        if ($activity->start_planned === null || $activity->finish_planned === null) {
            return false; // nothing to compare against; not a finding this service can support
        }

        $date = $report->dailyReport->report_date;
        $buffer = self::OUT_OF_WINDOW_BUFFER_DAYS;

        return $date->lt($activity->start_planned->copy()->subDays($buffer))
            || $date->gt($activity->finish_planned->copy()->addDays($buffer));
    }

    /**
     * TRACE-01/02 are meant to be safe to re-run on every read of the Pay
     * Application Review screen (matching this codebase's existing
     * PayApplicationReview::findings() convention of computing live on
     * read), so evaluate() must never create a duplicate row for something
     * it already found and is still OPEN. "Same finding" here means: same
     * context, same rule, same category, same primary subject record - if a
     * human already dismissed or promoted that exact finding, a fresh run
     * does not resurrect it as a new row; dismissing/promoting is meant to
     * stick until the underlying evidence actually changes.
     */
    private function existingFinding(PayApplicationReviewContext $context, string $ruleId, string $category, string $subjectType, int $subjectId): ?AiFinding
    {
        return AiFinding::where('pay_application_review_context_id', $context->id)
            ->where('rule_id', $ruleId)
            ->where('category', $category)
            ->whereHas('evidence', fn ($q) => $q->where('source_type', $subjectType)->where('source_id', $subjectId))
            ->first();
    }

    /** @param list<array{type:string,id:int,role:string}> $extraEvidence */
    private function mappingGapFinding(PayApplicationLine $line, PayApplicationReviewContext $context, string $summary, array $extraEvidence): AiFinding
    {
        $subjectType = $extraEvidence[0]['type'] ?? 'pay_application_line';
        $subjectId = $extraEvidence[0]['id'] ?? $line->id;
        if ($existing = $this->existingFinding($context, self::RULE_MISSING_PROGRESS_RECORD, 'MAPPING_GAP', $subjectType, $subjectId)) {
            return $existing;
        }

        $finding = AiFinding::create([
            'tenant_id' => $context->tenant_id,
            'pay_application_id' => $context->pay_application_id,
            'pay_application_review_context_id' => $context->id,
            'rule_id' => self::RULE_MISSING_PROGRESS_RECORD,
            'rule_version' => self::RULE_VERSION,
            'category' => 'MAPPING_GAP',
            'finding_class' => 'DATA_GAP',
            'severity' => 'INFO',
            'summary' => $summary,
            'searched_universe' => ['sov_line_id' => $line->schedule_of_value_item_id,
                'schedule_version_id' => $context->schedule_version_id],
            'evaluated_at' => now(),
        ]);

        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'pay_application_line', 'source_id' => $line->id,
            'evidence_role' => FindingEvidence::ROLE_EXPECTED_BUT_MISSING]);

        foreach ($extraEvidence as $e) {
            FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
                'source_type' => $e['type'], 'source_id' => $e['id'], 'evidence_role' => $e['role']]);
        }

        return $finding;
    }

    private function corroborationGapFinding(PayApplicationLine $line, SovScheduleLink $link, ScheduleActivity $activity, PayApplicationReviewContext $context, int $reportsCheckedForActivity): AiFinding
    {
        if ($existing = $this->existingFinding($context, self::RULE_MISSING_PROGRESS_RECORD, 'CORROBORATION_GAP', 'schedule_activity', $activity->id)) {
            return $existing;
        }

        $finding = AiFinding::create([
            'tenant_id' => $context->tenant_id,
            'pay_application_id' => $context->pay_application_id,
            'pay_application_review_context_id' => $context->id,
            'rule_id' => self::RULE_MISSING_PROGRESS_RECORD,
            'rule_version' => self::RULE_VERSION,
            'category' => 'CORROBORATION_GAP',
            'finding_class' => 'DATA_GAP',
            'severity' => 'REVIEW',
            'summary' => "Expected corroboration not located: Activity {$activity->activity_code} ({$activity->name}) ".
                "is planned/in-progress during {$context->period_start->toDateString()}-{$context->period_end->toDateString()}, ".
                'but no finalized daily report references it in that period.',
            'searched_universe' => [
                'period_start' => $context->period_start->toDateString(),
                'period_end' => $context->period_end->toDateString(),
                'schedule_activity_id' => $activity->id,
                'finalized_daily_report_activity_links_checked' => $reportsCheckedForActivity,
            ],
            'evaluated_at' => now(),
        ]);

        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'schedule_activity', 'source_id' => $activity->id,
            'evidence_role' => FindingEvidence::ROLE_EXPECTED_BUT_MISSING]);
        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'sov_schedule_link', 'source_id' => $link->id,
            'evidence_role' => FindingEvidence::ROLE_MAPPING_BASIS]);
        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'pay_application_line', 'source_id' => $line->id,
            'evidence_role' => FindingEvidence::ROLE_CONTEXT]);

        return $finding;
    }

    private function recordMismatchFinding(PayApplicationLine $line, SovScheduleLink $link, ScheduleActivity $activity, PayApplicationReviewContext $context, DailyReportActivity $report): AiFinding
    {
        if ($existing = $this->existingFinding($context, self::RULE_OUT_OF_WINDOW_PROGRESS, 'RECORD_MISMATCH', 'daily_report_activity', $report->id)) {
            return $existing;
        }

        $finding = AiFinding::create([
            'tenant_id' => $context->tenant_id,
            'pay_application_id' => $context->pay_application_id,
            'pay_application_review_context_id' => $context->id,
            'rule_id' => self::RULE_OUT_OF_WINDOW_PROGRESS,
            'rule_version' => self::RULE_VERSION,
            'category' => 'RECORD_MISMATCH',
            'finding_class' => 'OBSERVATION',
            'severity' => 'REVIEW',
            'summary' => "Daily report {$report->dailyReport->report_date->toDateString()} records work on Activity ".
                "{$activity->activity_code} ({$activity->name}). The applicable schedule (Update as of ".
                "{$context->schedule_data_date->toDateString()}) shows this activity's planned window as ".
                "{$activity->start_planned->toDateString()}-{$activity->finish_planned->toDateString()}.",
            'searched_universe' => [
                'schedule_activity_id' => $activity->id,
                'daily_report_activity_id' => $report->id,
                'buffer_days' => self::OUT_OF_WINDOW_BUFFER_DAYS,
            ],
            'evaluated_at' => now(),
        ]);

        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'daily_report', 'source_id' => $report->daily_report_id,
            'evidence_role' => FindingEvidence::ROLE_SUPPORTS]);
        // The specific daily_report_activity link (not just the report it
        // belongs to) is what makes this finding's identity unique - a report
        // can eventually reference several activities, and the dedupe check
        // in existingFinding() above keys on this exact link so re-running
        // evaluate() never creates a second finding for the same one.
        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'daily_report_activity', 'source_id' => $report->id,
            'evidence_role' => FindingEvidence::ROLE_SUPPORTS]);
        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'schedule_activity', 'source_id' => $activity->id,
            'evidence_role' => FindingEvidence::ROLE_CONTEXT]);
        FindingEvidence::create(['tenant_id' => $context->tenant_id, 'ai_finding_id' => $finding->id,
            'source_type' => 'sov_schedule_link', 'source_id' => $link->id,
            'evidence_role' => FindingEvidence::ROLE_MAPPING_BASIS]);

        return $finding;
    }
}
