<?php

namespace App\Domain\Licensing;

use App\Domain\Ai\TokenSpend;
use App\Models\AiRun;
use App\Models\CapabilityGrant;
use Illuminate\Support\Facades\DB;

/**
 * The spend cap, actually enforced.
 *
 * Until this existed the control was `budget_used_micros >= budget_limit_micros`
 * against a counter that no code path incremented. It refused at 402 when the
 * budget was exhausted, and the budget was never exhausted, because it never
 * moved. That is a control that is relied on and does nothing - which is worse
 * than an absent control, because an absent one is visible.
 *
 * Two properties this had to have that a simple increment does not.
 *
 * RESERVE BEFORE, SETTLE AFTER. Reading the counter, dispatching the job, and
 * incrementing on completion is check-then-act. Ten runs dispatched inside the
 * same second all read the same pre-run counter and all pass. A reservation
 * taken in the same locked transaction as the check is what makes the cap hold
 * under concurrency, and the reservation is released on EVERY terminal outcome -
 * completion, refusal, failure, cancellation - because a job that died still
 * has to give the money back.
 *
 * KNOWN SPEND IS A LOWER BOUND, NOT A TOTAL. The moment one run's cost cannot
 * be established, the account's spend stops being a number. The cap is still
 * enforced against what is known, and the state reports that it is no longer a
 * complete figure. Reporting an incomplete total as a total is the same defect
 * this class was written to remove.
 */
final class BudgetGate
{
    public const WITHIN = 'within';
    public const EXHAUSTED = 'exhausted';
    public const UNLIMITED = 'unlimited';

    /** The ceiling reserved for a run before its real cost is known. */
    public const RESERVATION_MICROS = 250_000;

    /**
     * @return array{state: string, limit_micros: ?int, used_micros: int, reserved_micros: int,
     *   remaining_micros: ?int, complete: bool, unmeasured_runs: int, message: string}
     */
    public static function state(?CapabilityGrant $grant): array
    {
        $limit = $grant?->budget_limit_micros !== null ? (int) $grant->budget_limit_micros : null;
        $used = (int) ($grant->budget_used_micros ?? 0);
        $reserved = (int) ($grant->budget_reserved_micros ?? 0);
        $unmeasured = (int) ($grant->unmeasured_run_count ?? 0);
        $complete = $unmeasured === 0;

        if ($limit === null) {
            return self::result(self::UNLIMITED, null, $used, $reserved, null, $complete, $unmeasured,
                'No monetary budget is set on this licence.');
        }

        $remaining = $limit - $used - $reserved;
        $state = $remaining > 0 ? self::WITHIN : self::EXHAUSTED;

        $message = $state === self::EXHAUSTED
            ? 'The AI monetary budget for this account has been reached.'
            : '$'.number_format($remaining / 1_000_000, 2).' of the AI budget remains'
                .($reserved > 0 ? ' after $'.number_format($reserved / 1_000_000, 2).' reserved for work in flight' : '').'.';

        if (! $complete) {
            // Said out loud rather than folded into the number. An account with
            // unmeasured runs has spent AT LEAST this much.
            $message .= ' '.$unmeasured.' run(s) completed without a usable cost figure, so the recorded spend is a lower bound rather than a total.';
        }

        return self::result($state, $limit, $used, $reserved, $remaining, $complete, $unmeasured, $message);
    }

    /**
     * Take a reservation, or refuse. Atomic: the check and the reservation
     * happen inside one locked transaction, which is the whole point.
     *
     * @return array{granted: bool, state: array<string,mixed>}
     */
    public static function reserve(?CapabilityGrant $grant, int $micros = self::RESERVATION_MICROS): array
    {
        if ($grant === null || $grant->budget_limit_micros === null) {
            return ['granted' => true, 'state' => self::state($grant)];
        }

        return DB::transaction(function () use ($grant, $micros) {
            $locked = CapabilityGrant::query()->whereKey($grant->id)->lockForUpdate()->first();
            $state = self::state($locked);

            if ($state['state'] === self::EXHAUSTED) {
                return ['granted' => false, 'state' => $state];
            }

            $locked->increment('budget_reserved_micros', $micros);

            return ['granted' => true, 'state' => self::state($locked->fresh())];
        });
    }

    /**
     * Settle a run: record what it actually cost, release its reservation.
     *
     * Called on every terminal outcome. A refused or failed run releases its
     * reservation and records the spend it did incur - a refusal after the
     * model was called is not free.
     */
    public static function settle(AiRun $run, TokenSpend $spend, int $reserved = self::RESERVATION_MICROS): void
    {
        $micros = $spend->micros(config('zecocm_ai.pricing', []));

        DB::transaction(function () use ($run, $spend, $micros, $reserved) {
            $run->forceFill([
                'input_tokens' => $spend->inputTokens,
                'output_tokens' => $spend->outputTokens,
                // Null, never zero, when the cost could not be established.
                'cost_micros' => $micros,
                'cost_measured' => $micros !== null,
            ])->save();

            $grant = CapabilityGrant::query()
                ->where('tenant_id', $run->tenant_id)
                ->where('capability_key', 'ai.assist')
                ->lockForUpdate()->first();

            if ($grant === null) {
                return;
            }

            if ($micros !== null) {
                $grant->increment('budget_used_micros', $micros);
            } else {
                // Not incremented by zero. Counted as a hole in the total, so
                // the state can say the figure is a lower bound.
                $grant->increment('unmeasured_run_count');
            }

            // Release the reservation without letting it go negative - a
            // double settle must not hand budget back that was never held.
            $grant->refresh();
            $grant->budget_reserved_micros = max(0, (int) $grant->budget_reserved_micros - $reserved);
            $grant->save();
        });
    }

    /** Give back a reservation for work that never ran at all. */
    public static function release(?CapabilityGrant $grant, int $micros = self::RESERVATION_MICROS): void
    {
        if ($grant === null || $grant->budget_limit_micros === null) {
            return;
        }

        DB::transaction(function () use ($grant, $micros) {
            $locked = CapabilityGrant::query()->whereKey($grant->id)->lockForUpdate()->first();
            if ($locked === null) {
                return;
            }
            $locked->budget_reserved_micros = max(0, (int) $locked->budget_reserved_micros - $micros);
            $locked->save();
        });
    }

    private static function result(string $state, ?int $limit, int $used, int $reserved,
        ?int $remaining, bool $complete, int $unmeasured, string $message): array
    {
        return compact('state') + [
            'limit_micros' => $limit,
            'used_micros' => $used,
            'reserved_micros' => $reserved,
            'remaining_micros' => $remaining,
            'complete' => $complete,
            'unmeasured_runs' => $unmeasured,
            'message' => $message,
        ];
    }
}
