<?php

namespace App\Domain\Licensing;

use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;

/**
 * TRACE's platform-operations lens - answers a platform staff member's own questions about
 * the business itself (how many customers, how many projects, are accounts active) from live
 * counts against the real database, not from any AI model.
 *
 * Deliberately deterministic and keyword-matched, the same pattern HelpAssistant already uses
 * for the free tier - a platform-staff dashboard question ("how many customers are active",
 * "how many projects do we have in total") has one correct numeric answer computed from the
 * database; there is nothing an LLM call adds here except latency and a hallucination risk on
 * numbers that must be exactly right. AssistController only reaches this class for a caller who
 * is already isPlatformStaff() - see the class doc there - so this never runs for a tenant user,
 * and it never scopes any query by tenant_id: it exists specifically to cross tenant boundaries
 * for the one audience allowed to see that aggregate (internal platform staff, not customers).
 *
 * Returns null (not an error shape) when the question doesn't match a platform-stats intent, so
 * the caller can fall through to HelpAssistant for a general "how does ZecoCM work" question -
 * platform staff still get the normal free-help answers for everything else.
 */
final class PlatformAssistant
{
    /** @return array<string,mixed>|null */
    public function answer(string $question): ?array
    {
        $q = mb_strtolower(trim($question));

        $wantsQuantity = (bool) preg_match('/\b(how many|count|total|number of|overview|snapshot|dashboard|summary|status of)\b/', $q);
        $aboutCustomers = (bool) preg_match('/\b(customer|customers|tenant|tenants|account|accounts)\b/', $q);
        $aboutProjects = (bool) preg_match('/\b(project|projects|job|jobs)\b/', $q);
        $aboutActivity = (bool) preg_match('/\b(active|activity|working|busy|engaged|usage|using)\b/', $q);

        if (! $wantsQuantity && ! ($aboutCustomers && $aboutActivity) && ! ($aboutProjects && $aboutActivity)) {
            return null;
        }
        if (! $aboutCustomers && ! $aboutProjects) {
            return null;
        }

        $lines = [];

        if ($aboutCustomers || ! $aboutProjects) {
            $byStatus = Tenant::query()->selectRaw('status, count(*) as c')->groupBy('status')->pluck('c', 'status');
            $totalCustomers = (int) $byStatus->sum();
            $active = (int) ($byStatus['active'] ?? 0);
            $trial = (int) ($byStatus['trial'] ?? 0);
            $suspended = (int) ($byStatus['suspended'] ?? 0);
            $lines[] = sprintf(
                'Customers: %d total — %d active, %d on trial, %d suspended.',
                $totalCustomers, $active, $trial, $suspended
            );
        }

        if ($aboutProjects || ! $aboutCustomers) {
            $totalProjects = Project::withoutGlobalScopes()->count();
            $tenantsWithProjects = Project::withoutGlobalScopes()->distinct('tenant_id')->count('tenant_id');
            $lines[] = sprintf(
                'Projects: %d total, across %d customer%s.',
                $totalProjects, $tenantsWithProjects, $tenantsWithProjects === 1 ? '' : 's'
            );
            $lines[] = 'ZecoCM does not yet track a project-level "active/closed" status — every project shown above is currently open in the system (no archival step exists yet), so "active projects" and "total projects" are the same number today.';
        }

        if ($aboutCustomers && $aboutProjects) {
            $topTenants = Tenant::query()
                ->withCount(['projects' => fn ($qq) => $qq->withoutGlobalScopes()])
                ->orderByDesc('projects_count')
                ->limit(3)
                ->get(['id', 'name']);
            if ($topTenants->isNotEmpty() && $topTenants->first()->projects_count > 0) {
                $lines[] = 'Busiest customers by project count: '.$topTenants->map(
                    fn ($t) => $t->name.' ('.$t->projects_count.')'
                )->implode(', ').'.';
            }
        }

        $totalUsers = User::query()->whereNotNull('tenant_id')->count();
        $lines[] = sprintf('Total customer-side users across all accounts: %d.', $totalUsers);

        return [
            'kind' => 'help',
            'tier' => 'free_help',
            'answer' => [[
                'title' => 'Platform snapshot',
                'body' => implode("\n", $lines),
            ]],
            'capabilities' => [],
            'source' => 'Live query against the platform database, computed for this answer — not cached, not an estimate.',
            'boundary' => 'This snapshot is only ever shown to platform staff; customer accounts never see cross-account counts through TRACE.',
        ];
    }
}
