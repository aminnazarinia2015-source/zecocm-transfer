<?php

namespace App\Domain\Licensing;

/**
 * The truthful states a capability can be in for one account. The interface must
 * distinguish all of them - "not licensed" is a commercial offer, "not yet built"
 * is a roadmap item, and neither may be presented as the other.
 */
final class LicenseState
{
    public const AVAILABLE = 'licensed_available';        // licensed, in window, and built

    public const NOT_OPERATIONAL = 'licensed_unavailable'; // licensed but not built yet

    public const NOT_LICENSED = 'not_licensed';           // never granted - offer it

    public const EXPIRED = 'expired';                     // window closed

    public const SUSPENDED = 'suspended';                 // switched off by the grantor

    public const LIMIT_REACHED = 'limit_reached';         // metered allowance used up

    public const FREE = 'free';                           // free tier - always on

    public function __construct(
        public readonly string $capabilityKey,
        public readonly string $state,
        public readonly ?string $endsAt = null,
        public readonly ?int $daysRemaining = null,
        public readonly ?string $planReference = null,
        public readonly ?int $usageCount = null,
        public readonly ?int $usageLimit = null,
        public readonly ?string $note = null,
        /**
         * BudgetGate::state() output, set only for 'ai.assist'. Nobody had
         * anywhere in the UI to actually see this before - the cap existed
         * and was enforced, but an admin had no way to look at spend versus
         * ceiling without querying the database directly.
         *
         * @var array{state: string, limit_micros: ?int, used_micros: int, reserved_micros: int,
         *   remaining_micros: ?int, complete: bool, unmeasured_runs: int, message: string}|null
         */
        public readonly ?array $budget = null,
    ) {}

    public function allows(): bool
    {
        return $this->state === self::AVAILABLE || $this->state === self::FREE;
    }

    public function expiringSoon(int $withinDays = 14): bool
    {
        return $this->state === self::AVAILABLE
            && $this->daysRemaining !== null
            && $this->daysRemaining <= $withinDays;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $meta = CapabilityCatalog::get($this->capabilityKey) ?? [];

        return [
            'capability' => $this->capabilityKey,
            'label' => $meta['label'] ?? $this->capabilityKey,
            'group' => $meta['group'] ?? 'Other',
            'tier' => $meta['tier'] ?? CapabilityCatalog::TIER_LICENSED,
            'summary' => $meta['summary'] ?? null,
            'state' => $this->state,
            'allowed' => $this->allows(),
            'expiring_soon' => $this->expiringSoon(),
            'ends_at' => $this->endsAt,
            'days_remaining' => $this->daysRemaining,
            'plan_reference' => $this->planReference,
            'usage_count' => $this->usageCount,
            'usage_limit' => $this->usageLimit,
            'note' => $this->note,
            'budget' => $this->budget,
        ];
    }
}
