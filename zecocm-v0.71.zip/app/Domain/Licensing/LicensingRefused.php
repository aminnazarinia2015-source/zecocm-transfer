<?php

namespace App\Domain\Licensing;

final class LicensingRefused extends \RuntimeException
{
    public function __construct(string $message, public readonly int $httpStatus = 422)
    {
        parent::__construct($message);
    }
}
