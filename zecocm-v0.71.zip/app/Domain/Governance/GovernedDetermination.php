<?php

namespace App\Domain\Governance;

use App\Domain\Schedule\ProjectGrant;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * The record of a human act that changed what this system may treat as true.
 *
 * One layer, not a confirmation flag per feature. The point is that every such
 * act ends up in the same place, so somebody can ask "what has been decided on
 * this project, by whom, on what basis" and get an answer - rather than that
 * question requiring a tour of six tables nobody remembers exist.
 *
 * Immutable after signature. A determination that turns out to be wrong is
 * corrected by a NEW determination superseding it. The wrong one stays, with
 * its author's name on it, because the fact that it was believed for a while is
 * part of the history somebody may need - and because a system that lets people
 * quietly erase their own mistaken determinations is not an evidence system.
 */
final class GovernedDetermination
{
    public const ACTIVE = 'active';
    public const SUPERSEDED = 'superseded';
    public const WITHDRAWN = 'withdrawn';

    public const REVIEW_NONE = 'none';
    public const REVIEW_SECOND_PERSON = 'second_person';

    /**
     * @param  array<string,mixed>  $attributes
     */
    public static function record(
        User $actor,
        ProjectGrant $grant,
        string $type,
        string $subjectType,
        int $subjectId,
        string $reason,
        ?string $priorValue = null,
        ?string $proposedValue = null,
        array $supportingSourceIds = [],
        array $supportingCitations = [],
        string $reviewRequirement = self::REVIEW_NONE,
        ?int $supersedes = null,
    ): int {
        // A determination without a reason is a click. The whole reason this
        // layer exists is that somebody may have to answer for it later, and
        // "no reason given" is not an answer.
        if (trim($reason) === '') {
            throw new RuntimeException('A determination has to say why. Record the basis, not just the outcome.');
        }

        $payload = [
            'tenant_id' => $grant->project->tenant_id,
            'project_id' => $grant->project->id,
            'determination_type' => $type,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'prior_value' => $priorValue,
            'proposed_value' => $proposedValue,
            'determined_by' => $actor->id,
            // The authority actually held at this moment. Grants get widened and
            // narrowed; the record of what somebody could do when they did it
            // must not move with them.
            'determiner_role' => $grant->seat.' · '.$grant->organization,
            'determiner_authority' => json_encode($grant->auditScope(), JSON_THROW_ON_ERROR),
            'determined_at' => now(),
            'reason' => $reason,
            'supporting_source_ids' => json_encode(array_values($supportingSourceIds), JSON_THROW_ON_ERROR),
            'supporting_citations' => json_encode(array_values($supportingCitations), JSON_THROW_ON_ERROR),
            'review_requirement' => $reviewRequirement,
            'status' => self::ACTIVE,
            'supersedes_determination_id' => $supersedes,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        $payload['decision_hash'] = hash('sha256', json_encode([
            $payload['determination_type'], $payload['subject_type'], $payload['subject_id'],
            $payload['prior_value'], $payload['proposed_value'], $payload['determined_by'],
            $payload['determiner_role'], $payload['reason'], $payload['supporting_source_ids'],
        ], JSON_THROW_ON_ERROR));

        return DB::transaction(function () use ($payload, $supersedes) {
            if ($supersedes !== null) {
                $previous = DB::table('governed_determinations')->where('id', $supersedes)->first();
                if ($previous === null) {
                    throw new RuntimeException('The determination being superseded does not exist.');
                }
                if ($previous->status !== self::ACTIVE) {
                    throw new RuntimeException('That determination is already '.$previous->status
                        .'. Supersede the one that is currently standing.');
                }
                DB::table('governed_determinations')->where('id', $supersedes)
                    ->update(['status' => self::SUPERSEDED, 'updated_at' => now()]);
            }

            return (int) DB::table('governed_determinations')->insertGetId($payload);
        });
    }

    /**
     * Withdraw a determination that should never have been made.
     *
     * Distinct from superseding on purpose. Superseding says "here is the better
     * answer". Withdrawing says "this should not have been asserted at all, and
     * nothing replaces it" - which is exactly the shape of my own PN 851 error,
     * where sources were promoted to verified on a reason nobody wrote.
     *
     * The row is not deleted and not edited. Its status changes and a new
     * determination records the withdrawal, so the original stands in the record
     * with its author's name on it.
     */
    public static function withdraw(User $actor, ProjectGrant $grant, int $determinationId, string $reason): int
    {
        $existing = DB::table('governed_determinations')->where('id', $determinationId)->first();

        if ($existing === null) {
            throw new RuntimeException('That determination does not exist.');
        }
        if ($existing->status !== self::ACTIVE) {
            throw new RuntimeException('That determination is already '.$existing->status.'.');
        }

        return DB::transaction(function () use ($actor, $grant, $existing, $reason, $determinationId) {
            DB::table('governed_determinations')->where('id', $determinationId)
                ->update(['status' => self::WITHDRAWN, 'updated_at' => now()]);

            return self::record(
                actor: $actor, grant: $grant,
                type: 'withdrawal',
                subjectType: $existing->subject_type, subjectId: (int) $existing->subject_id,
                reason: $reason,
                priorValue: $existing->proposed_value,
                proposedValue: null,
            );
        });
    }

    /**
     * What is currently standing on this subject. Withdrawn and superseded
     * determinations are excluded from the answer and remain in the record.
     *
     * @return list<array<string,mixed>>
     */
    public static function standingFor(string $subjectType, int $subjectId): array
    {
        return array_map(fn ($r) => (array) $r, DB::table('governed_determinations')
            ->where('subject_type', $subjectType)
            ->where('subject_id', $subjectId)
            ->where('status', self::ACTIVE)
            ->orderBy('id')
            ->get()->all());
    }

    /**
     * Determinations a second person has not yet reviewed, oldest first.
     *
     * This is the queue that makes the layer worth having. Without somewhere to
     * see them, a determination requiring review is just a column nobody reads.
     *
     * @return list<array<string,mixed>>
     */
    public static function awaitingReview(int $tenantId): array
    {
        return array_map(fn ($r) => (array) $r, DB::table('governed_determinations')
            ->where('tenant_id', $tenantId)
            ->where('status', self::ACTIVE)
            ->where('review_requirement', self::REVIEW_SECOND_PERSON)
            ->whereNull('reviewed_by')
            ->orderBy('determined_at')
            ->get()->all());
    }

    /** A second person confirms. Never the person who made it. */
    public static function review(User $reviewer, int $determinationId): void
    {
        $existing = DB::table('governed_determinations')->where('id', $determinationId)->first();

        if ($existing === null) {
            throw new RuntimeException('That determination does not exist.');
        }
        if ((int) $existing->determined_by === $reviewer->id) {
            throw new RuntimeException('A determination cannot be reviewed by the person who made it. '
                .'Holding both permissions is not the same as being two people.');
        }
        if ($existing->reviewed_by !== null) {
            throw new RuntimeException('That determination has already been reviewed.');
        }

        DB::table('governed_determinations')->where('id', $determinationId)
            ->update(['reviewed_by' => $reviewer->id, 'reviewed_at' => now(), 'updated_at' => now()]);
    }
}
