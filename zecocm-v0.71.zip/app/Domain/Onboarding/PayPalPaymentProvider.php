<?php

namespace App\Domain\Onboarding;

use App\Models\ContractorRegistration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Direct PayPal integration — required because Stripe's own PayPal support only covers
 * European/UK/EEA merchants, not US ones (per Codex's review of this design). Uses PayPal's
 * REST API directly (subscriptions product), never the deprecated classic API, and never
 * handles raw payment credentials — the customer approves the subscription on PayPal's own
 * hosted page.
 */
class PayPalPaymentProvider implements PaymentProvider
{
    public function name(): string
    {
        return 'paypal';
    }

    private function baseUrl(): string
    {
        return config('services.paypal.mode') === 'live'
            ? 'https://api-m.paypal.com'
            : 'https://api-m.sandbox.paypal.com';
    }

    private function accessToken(): string
    {
        $clientId = config('services.paypal.client_id');
        $secret = config('services.paypal.client_secret');

        if ($clientId === '' || $secret === '') {
            throw new \RuntimeException('PayPal is not configured (PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET).');
        }

        // PayPal OAuth tokens are valid ~9h; cache to avoid a token request on every call.
        return Cache::remember('paypal_access_token', 28800, function () use ($clientId, $secret) {
            $response = Http::asForm()
                ->withBasicAuth($clientId, $secret)
                ->post($this->baseUrl().'/v1/oauth2/token', ['grant_type' => 'client_credentials'])
                ->throw();

            return $response->json('access_token');
        });
    }

    public function startCheckout(ContractorRegistration $registration): string
    {
        $planId = config('services.paypal.plan_id_'.($registration->plan ?: 'field'), '');
        if ($planId === '') {
            throw new PaymentProviderNotConfiguredException(
                'PAYPAL_PLAN_ID_'.strtoupper($registration->plan ?: 'field')." is not configured — cannot start a PayPal subscription checkout for the \"{$registration->plan}\" plan."
            );
        }

        $response = Http::withToken($this->accessToken())
            ->withHeaders(['PayPal-Request-Id' => 'subscription-'.$registration->registration_id])
            ->post($this->baseUrl().'/v1/billing/subscriptions', [
                'plan_id' => $planId,
                'custom_id' => $registration->registration_id,
                'subscriber' => ['email_address' => $registration->email],
                'application_context' => [
                    'return_url' => config('app.url').'/onboarding/success?registration_id='.$registration->registration_id,
                    'cancel_url' => config('app.url').'/onboarding/payment?registration_id='.$registration->registration_id,
                ],
            ])
            ->throw();

        foreach ($response->json('links', []) as $link) {
            if (($link['rel'] ?? null) === 'approve') {
                return $link['href'];
            }
        }

        throw new \RuntimeException('PayPal did not return an approval link for the subscription.');
    }

    public function verifyWebhook(string $rawPayload, array $headers): ?array
    {
        $webhookId = config('services.paypal.webhook_id');
        if ($webhookId === '') {
            throw new \RuntimeException('PAYPAL_WEBHOOK_ID is not configured — refusing to trust an unverifiable webhook.');
        }

        $event = json_decode($rawPayload, true);
        if (! is_array($event) || ! isset($event['id'], $event['event_type'])) {
            return null;
        }

        // PayPal verification is a live API call against their servers, not a local HMAC check —
        // this is PayPal's own documented mechanism (there's no shared-secret signature scheme
        // like Stripe's). Fails closed: any non-"SUCCESS" verification status is treated as not
        // verified, never assumed valid.
        $verification = Http::withToken($this->accessToken())
            ->post($this->baseUrl().'/v1/notifications/verify-webhook-signature', [
                'transmission_id' => $headers['paypal-transmission-id'][0] ?? null,
                'transmission_time' => $headers['paypal-transmission-time'][0] ?? null,
                'cert_url' => $headers['paypal-cert-url'][0] ?? null,
                'auth_algo' => $headers['paypal-auth-algo'][0] ?? null,
                'transmission_sig' => $headers['paypal-transmission-sig'][0] ?? null,
                'webhook_id' => $webhookId,
                'webhook_event' => $event,
            ]);

        if (! $verification->successful() || $verification->json('verification_status') !== 'SUCCESS') {
            return null;
        }

        $resource = $event['resource'] ?? [];

        return [
            'event_id' => $event['id'],
            'type' => $event['event_type'],
            'registration_id' => $resource['custom_id'] ?? null,
            'customer_id' => $resource['subscriber']['payer_id'] ?? null,
            'subscription_id' => $resource['id'] ?? null,
        ];
    }
}
