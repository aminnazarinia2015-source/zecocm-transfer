<?php

namespace App\Domain\Onboarding;

use App\Models\ContractorRegistration;

/**
 * Normalizes Stripe and PayPal (the only two v1 payment methods — cards via Stripe, PayPal
 * directly, no crypto, no ACH yet, per the closed design brief) behind one interface so the rest
 * of the app never sees a provider-specific status string. Every implementation must:
 *  - never accept or store raw card/bank credentials (hosted-fields/tokenized flows only);
 *  - treat the provider's own webhook/API confirmation as the only source of truth for payment
 *    success — never infer it from a browser return URL.
 */
interface PaymentProvider
{
    public function name(): string;

    /**
     * Start a checkout for this registration. Returns a URL the customer is redirected to. Must
     * be idempotent on $registration->registration_id — calling this twice for the same
     * registration must not create two checkout sessions/subscriptions at the provider.
     */
    public function startCheckout(ContractorRegistration $registration): string;

    /**
     * Verify a raw inbound webhook request is authentically from this provider (signature check)
     * and return a normalized event, or null if the payload isn't one this provider recognizes.
     *
     * @return array{event_id:string,type:string,registration_id:?string,customer_id:?string,subscription_id:?string}|null
     */
    public function verifyWebhook(string $rawPayload, array $headers): ?array;
}
