<?php

namespace App\Domain\Onboarding;

/**
 * Thrown when a payment-confirmed registration cannot be provisioned because its email already
 * belongs to an existing user (a different registration, provisioned earlier, that happened to
 * share an email). Distinct from a generic RuntimeException so callers - specifically
 * PaymentWebhookController - can catch it by type and respond cleanly instead of letting a raw
 * exception (or a raw database constraint violation) surface to a payment provider's webhook
 * delivery.
 */
class DuplicateEmailProvisioningException extends \RuntimeException
{
}
