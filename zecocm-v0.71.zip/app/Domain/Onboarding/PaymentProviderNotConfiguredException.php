<?php

namespace App\Domain\Onboarding;

/**
 * Thrown when a payment provider is missing the credentials/price-plan it needs to start a
 * checkout. Distinct from a generic RuntimeException so RegistrationController::checkout() can
 * catch it specifically and return a clean, customer-facing 503 ("try the other payment method,
 * or contact us") instead of a bare 500 — this is an expected, recoverable operational state
 * (e.g. only Stripe keys have been added to production so far, PayPal's are still pending), not
 * a bug.
 */
class PaymentProviderNotConfiguredException extends \RuntimeException
{
}
