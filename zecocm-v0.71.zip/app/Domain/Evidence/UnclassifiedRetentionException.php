<?php

namespace App\Domain\Evidence;

/** E14-7: thrown when destruction is proposed for a record with no retention class. Never caught and silently ignored - see EvidenceDestructionService::requestDestruction(). */
final class UnclassifiedRetentionException extends \RuntimeException
{
}
