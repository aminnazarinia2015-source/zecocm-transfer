<?php

namespace App\Domain\Evidence;

use App\Models\EvidenceLink;
use App\Models\EvidenceUnlinkEvent;
use App\Models\User;

/**
 * EV-14A / B9: the one way an evidence association is ever removed. Never
 * `EvidenceLink::delete()` - the model itself refuses that (see
 * `EvidenceLink::bootEvidenceLink()`). Unlinking is an appended event with an
 * actor and a reason; the original link row is untouched and still proves
 * the evidence was once attached to the record.
 */
final class EvidenceLinkService
{
    public static function unlink(EvidenceLink $link, User $actor, string $reason): EvidenceUnlinkEvent
    {
        if (trim($reason) === '') {
            throw new \InvalidArgumentException('An unlink requires a reason - the same discipline knowledge-review decisions already enforce.');
        }

        return EvidenceUnlinkEvent::create([
            'tenant_id' => $link->tenant_id,
            'evidence_link_id' => $link->id,
            'actor_id' => $actor->id,
            'reason' => $reason,
            'occurred_at' => now(),
        ]);
    }
}
