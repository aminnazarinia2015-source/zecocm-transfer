<?php

namespace App\Domain\Evidence;

use App\Models\EvidenceTombstone;

/**
 * Renders the ONE statement a tombstone is entitled to make, and no more.
 * Codex's invariant: "ZecoCM must never certify destruction more broadly than
 * the storage locations it can actually prove have ceased to retain the
 * object."
 *
 * EV-14A shipped this class incapable of rendering the word "destroyed" as a
 * fact at all, because no executor existed. EV-14B adds one, so this class
 * now reads `EvidenceDestructionExecutor::currentState()` - the append-only
 * execution ledger, never the tombstone's own fixed `state` column - and
 * renders exactly what that ledger can prove, no more. An in-progress or
 * blocked run still gets an honest certificate: what happened, and what has
 * NOT been proven. Only `DESTROYED_WITHIN_GOVERNED_SCOPE` may use the word
 * "destroyed," and only naming the governed locations actually verified.
 */
final class DestructionCertificate
{
    public static function render(EvidenceTombstone $tombstone): string
    {
        $executionState = EvidenceDestructionExecutor::currentState($tombstone);

        return match ($executionState) {
            EvidenceTombstone::AUTHORIZED_PENDING_EXECUTION => sprintf(
                'Destruction of media item %d (digest %s:%s) was AUTHORIZED on %s by user %d, citing: "%s". '
                .'Hold status at authorization: %s. No storage location has been verified to no longer retain this '
                .'object - physical destruction has not been executed. This certificate does NOT state that the '
                .'object has been destroyed.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
                $tombstone->authorized_at->format(DATE_ATOM),
                $tombstone->authorized_by,
                $tombstone->authority_citation,
                $tombstone->hold_check_result,
            ),
            EvidenceTombstone::EXECUTION_IN_PROGRESS => sprintf(
                'Destruction of media item %d (digest %s:%s) is IN PROGRESS. No storage location has yet been '
                .'verified to no longer retain this object. This certificate does NOT state that the object has '
                .'been destroyed.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::EXECUTION_BLOCKED_HOLD,
            EvidenceTombstone::EXECUTION_STOPPED_PARTIAL_HOLD => sprintf(
                'Destruction of media item %d (digest %s:%s) was BLOCKED by an active legal hold detected at '
                .'execution time. No further destruction may proceed while a hold covers this object. This '
                .'certificate does NOT state that the object has been destroyed.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::EXECUTION_BLOCKED_CONTENT_MISMATCH => sprintf(
                'Destruction of media item %d (digest %s:%s) was REFUSED: the object\'s current content no longer '
                .'matches the digest this destruction was authorized against. This certificate does NOT state that '
                .'the object has been destroyed, and flags the mismatch for review.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::EXECUTION_BLOCKED_TOPOLOGY_UNKNOWN => sprintf(
                'Destruction of media item %d (digest %s:%s) was REFUSED: no governed storage topology is defined '
                .'for the current time. ZecoCM will not execute destruction without a known set of governed '
                .'locations to certify against.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::EXECUTION_DISCREPANCY_UNEXPECTED_ABSENCE => sprintf(
                'Destruction of media item %d (digest %s:%s) encountered a DISCREPANCY: a governed storage location '
                .'was found already absent before this destruction executed. This is flagged for human review and '
                .'is NOT treated as a verified destruction.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::PRIMARY_REMOVED => sprintf(
                'Destruction of media item %d (digest %s:%s): the primary governed storage location has been '
                .'verified removed. One or more other governed storage locations recorded for this object remain '
                .'unresolved. This certificate does NOT state that the object has been destroyed from all governed '
                .'storage locations.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::RESIDUAL_COPY_EXISTS => sprintf(
                'Destruction of media item %d (digest %s:%s): a destruction attempt left this object verifiably '
                .'still present at one or more governed storage locations. This certificate does NOT state that '
                .'the object has been destroyed.',
                $tombstone->media_item_id,
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE => sprintf(
                'ZecoCM verified that the object identified by %s:%s was removed from all governed storage '
                .'locations recorded for this destruction operation. The certificate does not assert that no '
                .'uncontrolled or previously exported copy exists elsewhere.',
                $tombstone->digest_algorithm,
                $tombstone->digest,
            ),
            default => throw new \LogicException(
                "DestructionCertificate has no rendering for execution state '{$executionState}' - "
                .'either a bug wrote an unrecognised state to the execution ledger, or a new state was added to '
                .'EvidenceDestructionExecutor without a matching branch here.'
            ),
        };
    }
}
