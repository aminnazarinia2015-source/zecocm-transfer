<?php

namespace App\Domain\Evidence;

use App\Domain\Provenance\DigestAlgorithm;
use App\Models\DestructionLocationResult;
use App\Models\EvidenceTombstone;
use App\Models\EvidenceTombstoneExecutionEvent;
use App\Models\MediaItem;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Support\Facades\Storage;

/**
 * EV-14B: the only code in this codebase that removes evidence bytes from a
 * governed storage location. Everything above this class (EV-14A) only ever
 * PROPOSED or AUTHORIZED destruction; nothing executed.
 *
 * Every rule here is a direct answer to a question Codex asked of DATA-1's
 * storage topology, or a lesson this codebase already learned the hard way
 * elsewhere:
 *  - re-check hold status and content identity FRESH, at execution time, not
 *    trusted from authorization time (E14-11 / SEC-3's lesson, one hop further);
 *  - an unknown storage topology is refused, never assumed to mean
 *    "primary only" (Codex: StorageInventory proving deployment-independence
 *    is not the same fact as "every governed copy is known");
 *  - a location whose bytes are unexpectedly already gone is a discrepancy
 *    requiring review, never an automatic success;
 *  - a hold that appears after some (but not all) governed locations have
 *    been cleared stops the batch and records the partial state honestly,
 *    rather than finishing because "authorization was valid when it started";
 *  - the only terminal success state is DESTROYED_WITHIN_GOVERNED_SCOPE, and
 *    only when every governed location as of execution time resolves absent.
 */
final class EvidenceDestructionExecutor
{
    /**
     * @return array{state: string, detail: array<string,mixed>}
     */
    public static function execute(EvidenceTombstone $tombstone, User $executor, ?\DateTimeInterface $now = null): array
    {
        $now = $now ?? now();
        $previousTenant = TenantContext::tenantId();
        TenantContext::set($tombstone->tenant_id);

        try {
            $current = self::currentState($tombstone);
            if ($current === EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE) {
                // Idempotent no-op: already fully resolved, nothing more to do,
                // and re-running must never fabricate new history over a
                // settled terminal state.
                return ['state' => $current, 'detail' => []];
            }

            $item = MediaItem::withoutGlobalScopes()
                ->where('tenant_id', $tombstone->tenant_id)
                ->where('id', $tombstone->media_item_id)
                ->first();

            if ($item === null) {
                // Tenant mismatch or the record is otherwise unreachable under
                // this tombstone's own tenant scope - refuse rather than guess,
                // and refuse before ever asking whether a hold applies to a
                // record we cannot even confirm belongs to this tenant.
                return self::recordEvent($tombstone, $executor, $now, EvidenceTombstone::EXECUTION_BLOCKED_HOLD, [
                    'reason' => 'media_item_unreachable_under_tombstone_tenant',
                ]);
            }

            // E14B fresh re-check #1: hold status, right now, never trusted
            // from the tombstone's authorization-time hold_check_result.
            $hold = HoldStatus::forMediaItem($item);
            if ($hold['status'] !== HoldStatus::NO_HOLD) {
                $hasProgress = DestructionLocationResult::where('evidence_tombstone_id', $tombstone->id)->exists();
                $state = $hasProgress
                    ? EvidenceTombstone::EXECUTION_STOPPED_PARTIAL_HOLD
                    : EvidenceTombstone::EXECUTION_BLOCKED_HOLD;

                return self::recordEvent($tombstone, $executor, $now, $state, ['hold_status' => $hold['status']]);
            }

            $locations = EvidenceStorageTopology::governedLocationsAt($now);
            if ($locations->isEmpty()) {
                return self::recordEvent($tombstone, $executor, $now, EvidenceTombstone::EXECUTION_BLOCKED_TOPOLOGY_UNKNOWN, []);
            }

            self::recordEvent($tombstone, $executor, $now, EvidenceTombstone::EXECUTION_IN_PROGRESS, [
                'locations' => $locations->pluck('location_key')->all(),
            ]);

            foreach ($locations as $location) {
                $alreadyAbsent = DestructionLocationResult::where('evidence_tombstone_id', $tombstone->id)
                    ->where('location_key', $location->location_key)
                    ->where('post_delete_presence', false)
                    ->exists();
                if ($alreadyAbsent) {
                    continue;
                }

                // E14B fresh re-check #2: hold status again, immediately
                // before touching this specific location - a hold placed
                // after an earlier location was cleared must stop the rest
                // of the batch, not just be caught at the top of the run.
                $midHold = HoldStatus::forMediaItem($item);
                if ($midHold['status'] !== HoldStatus::NO_HOLD) {
                    return self::recordEvent($tombstone, $executor, $now, EvidenceTombstone::EXECUTION_STOPPED_PARTIAL_HOLD, [
                        'hold_status' => $midHold['status'],
                        'location_key' => $location->location_key,
                    ]);
                }

                $outcome = self::attemptLocation($tombstone, $location, $item, $now);
                if ($outcome !== null) {
                    // A per-location outcome that must stop the whole batch
                    // (unexpected absence, digest mismatch).
                    return self::recordEvent($tombstone, $executor, $now, $outcome['state'], $outcome['detail']);
                }
            }

            return self::finalize($tombstone, $executor, $now, $locations->pluck('location_key')->all());
        } finally {
            if ($previousTenant === null) {
                TenantContext::clear();
            } else {
                TenantContext::set($previousTenant);
            }
        }
    }

    /**
     * @return array{state: string, detail: array<string,mixed>}|null null means "continue to the next location"
     */
    private static function attemptLocation(EvidenceTombstone $tombstone, $location, MediaItem $item, \DateTimeInterface $now): ?array
    {
        $disk = Storage::disk($location->disk);
        $path = $item->storage_path;

        $pre = self::safeExists($disk, $path);

        if ($pre === false) {
            // The bytes are already gone before this executor ever attempted
            // anything - never silently counted as success. Something
            // outside this row's own accounting removed them.
            DestructionLocationResult::create([
                'tenant_id' => $tombstone->tenant_id,
                'evidence_tombstone_id' => $tombstone->id,
                'location_key' => $location->location_key,
                'attempted_at' => $now,
                'expected_digest' => $tombstone->digest,
                'pre_delete_presence' => false,
                'delete_result' => DestructionLocationResult::NOT_FOUND,
                'post_delete_presence' => null,
                'verification_method' => $location->verification_method,
                'verified_at' => null,
                'error' => null,
            ]);

            return ['state' => EvidenceTombstone::EXECUTION_DISCREPANCY_UNEXPECTED_ABSENCE, 'detail' => ['location_key' => $location->location_key]];
        }

        $bytes = null;
        try {
            $bytes = $disk->get($path);
        } catch (\Throwable $e) {
            $bytes = null;
        }

        $currentDigest = $bytes !== null ? DigestAlgorithm::digest($bytes) : null;
        if ($currentDigest === null || $currentDigest !== $tombstone->digest) {
            DestructionLocationResult::create([
                'tenant_id' => $tombstone->tenant_id,
                'evidence_tombstone_id' => $tombstone->id,
                'location_key' => $location->location_key,
                'attempted_at' => $now,
                'expected_digest' => $tombstone->digest,
                'pre_delete_presence' => true,
                'delete_result' => null,
                'post_delete_presence' => null,
                'verification_method' => $location->verification_method,
                'verified_at' => null,
                'error' => 'content_digest_mismatch',
            ]);

            return ['state' => EvidenceTombstone::EXECUTION_BLOCKED_CONTENT_MISMATCH, 'detail' => [
                'location_key' => $location->location_key,
                'expected_digest' => $tombstone->digest,
                'observed_digest' => $currentDigest,
            ]];
        }

        $deleted = false;
        $error = null;
        try {
            $deleted = (bool) $disk->delete($path);
        } catch (\Throwable $e) {
            $deleted = false;
            $error = $e->getMessage();
        }

        $post = self::safeExists($disk, $path);
        $deleteResult = match (true) {
            $deleted && $post === false => DestructionLocationResult::DELETED,
            default => DestructionLocationResult::ERROR,
        };

        DestructionLocationResult::create([
            'tenant_id' => $tombstone->tenant_id,
            'evidence_tombstone_id' => $tombstone->id,
            'location_key' => $location->location_key,
            'attempted_at' => $now,
            'expected_digest' => $tombstone->digest,
            'pre_delete_presence' => true,
            'delete_result' => $deleteResult,
            'post_delete_presence' => $post,
            'verification_method' => $location->verification_method,
            'verified_at' => $now,
            'error' => $error,
        ]);

        return null;
    }

    private static function safeExists($disk, string $path): ?bool
    {
        try {
            return $disk->exists($path);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * @param  list<string>  $locationKeys
     * @return array{state: string, detail: array<string,mixed>}
     */
    private static function finalize(EvidenceTombstone $tombstone, User $executor, \DateTimeInterface $now, array $locationKeys): array
    {
        $outcome = self::determineFinalState($tombstone, $locationKeys);

        return self::recordEvent($tombstone, $executor, $now, $outcome['state'], $outcome['detail']);
    }

    /**
     * The pure aggregation: given every `DestructionLocationResult` row
     * recorded so far for this tombstone, what is the honest overall state?
     * Separated from `finalize()` (which also writes the ledger event) so
     * this can be exercised directly and deterministically in tests without
     * needing a real filesystem to produce every combination of outcomes.
     *
     * @param  list<string>  $locationKeys
     * @return array{state: string, detail: array<string,mixed>}
     */
    public static function determineFinalState(EvidenceTombstone $tombstone, array $locationKeys): array
    {
        $resolvedAbsent = [];
        foreach ($locationKeys as $key) {
            $resolvedAbsent[$key] = DestructionLocationResult::withoutGlobalScopes()
                ->where('tenant_id', $tombstone->tenant_id)
                ->where('evidence_tombstone_id', $tombstone->id)
                ->where('location_key', $key)
                ->where('post_delete_presence', false)
                ->exists();
        }

        if (! in_array(false, $resolvedAbsent, true)) {
            return ['state' => EvidenceTombstone::DESTROYED_WITHIN_GOVERNED_SCOPE, 'detail' => [
                'locations_verified_absent' => $locationKeys,
            ]];
        }

        $unresolved = array_keys(array_filter($resolvedAbsent, fn ($absent) => ! $absent));
        $primaryAbsent = $resolvedAbsent['primary'] ?? false;

        if ($primaryAbsent) {
            return ['state' => EvidenceTombstone::PRIMARY_REMOVED, 'detail' => ['pending_locations' => $unresolved]];
        }

        return ['state' => EvidenceTombstone::RESIDUAL_COPY_EXISTS, 'detail' => ['unresolved_locations' => $unresolved]];
    }

    /** @param array<string,mixed> $detail
     * @return array{state: string, detail: array<string,mixed>}
     */
    private static function recordEvent(EvidenceTombstone $tombstone, User $executor, \DateTimeInterface $now, string $state, array $detail): array
    {
        EvidenceTombstoneExecutionEvent::create([
            'tenant_id' => $tombstone->tenant_id,
            'evidence_tombstone_id' => $tombstone->id,
            'state' => $state,
            'actor_id' => $executor->id,
            'detail' => $detail,
            'occurred_at' => $now,
        ]);

        return ['state' => $state, 'detail' => $detail];
    }

    /** Resolves current execution state the same way HoldStatus resolves hold state: latest event wins. */
    public static function currentState(EvidenceTombstone $tombstone): string
    {
        $latest = EvidenceTombstoneExecutionEvent::withoutGlobalScopes()
            ->where('tenant_id', $tombstone->tenant_id)
            ->where('evidence_tombstone_id', $tombstone->id)
            ->orderByDesc('occurred_at')
            ->orderByDesc('id')
            ->first();

        return $latest?->state ?? EvidenceTombstone::AUTHORIZED_PENDING_EXECUTION;
    }
}
