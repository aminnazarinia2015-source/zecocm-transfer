<?php

namespace App\Domain\Evidence;

use App\Domain\Provenance\DigestAlgorithm;
use App\Models\DestructionRequest;
use App\Models\EvidenceTombstone;
use App\Models\MediaItem;
use App\Models\User;

/**
 * EV-14A: retention eligibility, destruction requests, and authorization.
 * Deliberately stops there - see `EvidenceTombstone`'s doc comment. Nothing
 * in this class deletes a byte. Codex's split: eligibility and governance can
 * close now; verified destruction execution is EV-14B, gated on DATA-1.
 */
final class EvidenceDestructionService
{
    public const REFUSAL_UNCLASSIFIED = 'retention_class_unassigned';

    public const REFUSAL_HELD = 'held';

    public const REFUSAL_CANNOT_DETERMINE_HOLD = 'cannot_determine_hold_status';

    /**
     * E14-7: an unclassified record generates no proposal at all - not a
     * pending one, not a refused one. "No retention classification = retain
     * indefinitely / destruction not authorized," in Codex's own words, and
     * shipping a default class here would be the A3 error with worse
     * consequences: an assumed period this codebase invented is not a policy
     * the customer's retention schedule actually set.
     */
    public static function requestDestruction(MediaItem $item, User $requester, string $reason): DestructionRequest
    {
        if (trim($reason) === '') {
            throw new \InvalidArgumentException('A destruction request requires a stated reason.');
        }

        if ($item->retention_class === null) {
            throw new UnclassifiedRetentionException(
                "Media item {$item->id} has no retention class assigned. No retention classification means "
                .'retain indefinitely; destruction cannot even be proposed until a governed classification exists.'
            );
        }

        // E14-1: a hold recorded at request time is surfaced immediately -
        // the same status is re-checked at authorization (E14-11), because a
        // hold placed between request and authorization must still block.
        $hold = HoldStatus::forMediaItem($item);

        return DestructionRequest::create([
            'tenant_id' => $item->tenant_id,
            'media_item_id' => $item->id,
            'requested_by' => $requester->id,
            'requested_at' => now(),
            'reason' => $reason,
            'status' => DestructionRequest::PENDING,
            'hold_check_result' => $hold['status'],
        ]);
    }

    /**
     * The hold status is re-resolved HERE, at authorization/execution time,
     * never trusted from whatever it was at request time - E14-11, and the
     * same lesson SEC-3's second slice proved for `RunGovernedAi` re-
     * authorizing at execution rather than at queue time. Fails closed: an
     * indeterminate hold status is refused exactly like an active one.
     */
    public static function authorize(DestructionRequest $request, User $authorizer, string $authorityCitation): DestructionRequest
    {
        if (trim($authorityCitation) === '') {
            throw new \InvalidArgumentException('Authorizing destruction requires a stated authority citation.');
        }
        if ($request->status !== DestructionRequest::PENDING) {
            throw new \RuntimeException("Destruction request {$request->id} is not pending (status: {$request->status}).");
        }

        $item = MediaItem::withoutGlobalScopes()->findOrFail($request->media_item_id);
        $hold = HoldStatus::forMediaItem($item);

        if ($hold['status'] !== HoldStatus::NO_HOLD) {
            $refusalReason = $hold['status'] === HoldStatus::HELD
                ? self::REFUSAL_HELD
                : self::REFUSAL_CANNOT_DETERMINE_HOLD;

            $request->update([
                'status' => DestructionRequest::REFUSED,
                'refusal_reason' => $refusalReason,
                'hold_check_result' => $hold['status'],
            ]);

            return $request->refresh();
        }

        $request->update([
            'status' => DestructionRequest::AUTHORIZED,
            'authorized_by' => $authorizer->id,
            'authorized_at' => now(),
            'authority_citation' => $authorityCitation,
            'hold_check_result' => $hold['status'],
        ]);

        // Retain the digest and every piece of integrity metadata forever
        // (Codex's ruling); the tombstone is the only place that metadata
        // survives once (eventually, under EV-14B) the bytes are gone.
        EvidenceTombstone::create([
            'tenant_id' => $item->tenant_id,
            'media_item_id' => $item->id,
            'destruction_request_id' => $request->id,
            'digest' => $item->sha256,
            'digest_algorithm' => DigestAlgorithm::CURRENT,
            'bytes' => $item->bytes,
            'mime' => $item->mime,
            'original_name' => $item->original_name,
            'authorized_by' => $authorizer->id,
            'authorized_at' => now(),
            'authority_citation' => $authorityCitation,
            'hold_check_result' => $hold['status'],
            'state' => EvidenceTombstone::AUTHORIZED_PENDING_EXECUTION,
        ]);

        return $request->refresh();
    }
}
