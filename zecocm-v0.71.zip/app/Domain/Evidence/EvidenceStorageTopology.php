<?php

namespace App\Domain\Evidence;

use App\Models\EvidenceStorageLocation;
use Illuminate\Support\Collection;

/**
 * EV-14B: the explicit, versioned set of storage locations EV-14B is willing
 * to certify destruction against, as of a given instant.
 *
 * Codex's distinction: DATA-1's StorageInventory proves where the primary
 * disk is rooted and that deployment cannot reach it. It does not prove
 * "every governed place an object may still exist is known." This class is
 * that second, separate fact - and when it cannot resolve any governed
 * location for a given instant, that is refused, not assumed to mean
 * "primary only" (see EvidenceDestructionExecutor::EXECUTION_BLOCKED_TOPOLOGY_UNKNOWN).
 */
final class EvidenceStorageTopology
{
    /** @return Collection<int, EvidenceStorageLocation> */
    public static function governedLocationsAt(\DateTimeInterface $at): Collection
    {
        return EvidenceStorageLocation::query()
            ->where('governed', true)
            ->where('effective_from', '<=', $at)
            ->where(function ($q) use ($at) {
                $q->whereNull('effective_to')->orWhere('effective_to', '>', $at);
            })
            ->orderBy('location_key')
            ->get();
    }
}
