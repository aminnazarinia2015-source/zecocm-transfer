<?php

namespace App\Domain\Evidence;

use App\Models\LegalHoldEvent;
use App\Models\User;
use Illuminate\Support\Str;

/**
 * EV-14A: places and releases legal holds. The system never decides that a
 * hold applies - it only records that a named person placed or released one,
 * the same line A3 drew refusing to pronounce forfeiture and A5 drew freezing
 * funds rather than ruling on a defective notice. Whether litigation is
 * reasonably anticipated is a legal judgment this class does not make.
 */
final class LegalHoldService
{
    public static function place(string $scopeType, array $scopeValue, User $actor, string $reason, ?string $matterReference = null): LegalHoldEvent
    {
        if (trim($reason) === '') {
            throw new \InvalidArgumentException('Placing a hold requires a stated reason.');
        }
        if (! in_array($scopeType, [LegalHoldEvent::SCOPE_PROJECT, LegalHoldEvent::SCOPE_TENANT, LegalHoldEvent::SCOPE_MEDIA_ITEM], true)) {
            throw new \InvalidArgumentException("Unrecognised hold scope type '{$scopeType}'.");
        }

        return LegalHoldEvent::create([
            'hold_id' => (string) Str::uuid(),
            'event_type' => LegalHoldEvent::PLACED,
            'scope_type' => $scopeType,
            'scope_value' => $scopeValue,
            'matter_reference' => $matterReference,
            'actor_id' => $actor->id,
            'reason' => $reason,
            'occurred_at' => now(),
        ]);
    }

    /**
     * A hold does not lapse on a timer - it is released by a named person,
     * with their own reason recorded, referencing the same hold_id the
     * placement used. A hold that silently expired would be indistinguishable
     * afterwards from one that was never placed; this method is the only way
     * a hold ever stops covering a record.
     */
    public static function release(string $holdId, User $actor, string $reason): LegalHoldEvent
    {
        if (trim($reason) === '') {
            throw new \InvalidArgumentException('Releasing a hold requires a stated reason.');
        }

        $placement = LegalHoldEvent::where('hold_id', $holdId)
            ->where('event_type', LegalHoldEvent::PLACED)
            ->first();

        if ($placement === null) {
            throw new \RuntimeException("No hold with id '{$holdId}' was ever placed.");
        }

        return LegalHoldEvent::create([
            'hold_id' => $holdId,
            'event_type' => LegalHoldEvent::RELEASED,
            'scope_type' => $placement->scope_type,
            'scope_value' => $placement->scope_value,
            'matter_reference' => $placement->matter_reference,
            'actor_id' => $actor->id,
            'reason' => $reason,
            'occurred_at' => now(),
        ]);
    }
}
