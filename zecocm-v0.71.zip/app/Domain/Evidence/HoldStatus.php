<?php

namespace App\Domain\Evidence;

use App\Models\LegalHoldEvent;
use App\Models\MediaItem;
use Illuminate\Support\Facades\DB;

/**
 * EV-14A: whether a legal hold covers a media item, right now.
 *
 * Codex's own words are the whole spec: "ZecoCM must never certify
 * destruction more broadly than the storage locations it can actually prove
 * have ceased to retain the object" - and the same fail-closed discipline
 * this codebase has applied everywhere else (`DigestAlgorithm::CANNOT_VERIFY`,
 * `SecureUploadGate`'s unknown_profile, EV-12's unresolvable key) applies
 * here: an indeterminate hold status is never treated as "no hold." It
 * refuses, the same as a genuinely active hold would.
 *
 * A hold is "active" for a given (hold_id) group when its most recent event
 * is `placed` and no `released` event has since been appended for that same
 * hold_id - resolved directly from the append-only ledger, never from a
 * cached or mutable "is_active" flag.
 */
final class HoldStatus
{
    public const NO_HOLD = 'no_hold';

    public const HELD = 'held';

    public const CANNOT_DETERMINE = 'cannot_determine';

    /** @return array{status: string, holds: list<array<string,mixed>>} */
    public static function forMediaItem(MediaItem $item): array
    {
        try {
            $activeHolds = self::activeHoldsCovering($item);
        } catch (\Throwable $e) {
            // Anything that keeps this from resolving cleanly - a malformed
            // scope_value, a missing project id, a database error - is an
            // indeterminate status, never a clean "no hold." Silently
            // swallowing the exception here would be exactly the "unknown
            // defaults to safe" mistake this row exists to prevent.
            return ['status' => self::CANNOT_DETERMINE, 'holds' => []];
        }

        if ($activeHolds === []) {
            return ['status' => self::NO_HOLD, 'holds' => []];
        }

        return ['status' => self::HELD, 'holds' => $activeHolds];
    }

    /** @return list<array<string,mixed>> */
    private static function activeHoldsCovering(MediaItem $item): array
    {
        $events = DB::table('legal_hold_events')
            ->where('tenant_id', $item->tenant_id)
            ->orderBy('occurred_at')
            ->orderBy('id')
            ->get();

        // Latest event per hold_id decides whether that hold is currently
        // active - a released event, however old the original placement,
        // always wins over a placed event that came before it.
        $latestByHold = [];
        foreach ($events as $event) {
            $latestByHold[$event->hold_id] = $event;
        }

        $covering = [];
        foreach ($latestByHold as $event) {
            if ($event->event_type !== LegalHoldEvent::PLACED) {
                continue;
            }

            $scope = json_decode($event->scope_value, true);
            if (! is_array($scope)) {
                // A hold event this codebase cannot even parse is exactly the
                // "cannot determine" case, not "does not apply."
                throw new \RuntimeException('Unreadable legal_hold_events.scope_value for hold '.$event->hold_id);
            }

            $covers = match ($event->scope_type) {
                LegalHoldEvent::SCOPE_MEDIA_ITEM => (int) ($scope['media_item_id'] ?? 0) === $item->id,
                LegalHoldEvent::SCOPE_PROJECT => (int) ($scope['project_id'] ?? 0) === $item->project_id,
                LegalHoldEvent::SCOPE_TENANT => (int) ($scope['tenant_id'] ?? 0) === $item->tenant_id,
                default => throw new \RuntimeException('Unrecognised legal hold scope_type: '.$event->scope_type),
            };

            if ($covers) {
                $covering[] = [
                    'hold_id' => $event->hold_id,
                    'matter_reference' => $event->matter_reference,
                    'actor_id' => $event->actor_id,
                    'reason' => $event->reason,
                    'occurred_at' => $event->occurred_at,
                ];
            }
        }

        return $covering;
    }
}
