<?php

namespace App\Domain\Overview;

use App\Domain\Payment\PayApplicationMath;
use App\Domain\Payment\RetentionRule;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleOfValueItem;
use App\Models\ScheduleVersion;

/**
 * The two numbers a project owner asks for first: how much of it is built, and
 * how the money stands.
 *
 * Both are read from records this project already keeps - the accepted schedule
 * of record (ScheduleController/ScheduleActivity) and certified pay applications
 * (PayApplicationController/PayApplicationMath) - never estimated, and never
 * blended together into a single figure. Percent-complete and billing status are
 * two different questions with two different denominators, and collapsing them
 * would answer neither one honestly.
 *
 * Missing data is reported as an explicit unavailable state with a reason, the
 * same convention BriefBuilder uses for a Refusal: no schedule imported yet, or
 * no schedule of values set up yet, is not an error, it is the finding.
 */
final class ProjectOverviewBuilder
{
    /** @return array<string,mixed> */
    public function build(Project $project): array
    {
        return [
            'project' => [
                'id' => $project->id,
                'number' => $project->number,
                'name' => $project->name,
            ],
            'schedule' => $this->schedule($project),
            'billing' => $this->billing($project),
            'computed_at' => now()->toIso8601String(),
        ];
    }

    /** @return array<string,mixed> */
    private function schedule(Project $project): array
    {
        // Only an ACCEPTED version counts as the schedule of record - same rule
        // BriefBuilder applies to "where this project stands". A submitter's
        // label is not an acceptance, and percent-complete is not reported from
        // a version nobody has accepted.
        $version = ScheduleVersion::query()
            ->where('project_id', $project->id)
            ->where('review_status', 'accepted')
            ->orderByDesc('data_date')
            ->orderByDesc('id')
            ->first();

        if ($version === null) {
            $anyVersion = ScheduleVersion::query()->where('project_id', $project->id)->exists();

            return [
                'available' => false,
                'message' => $anyVersion
                    ? 'A schedule has been uploaded but none has an acceptance disposition. Percent complete is not reported from a version nobody has accepted.'
                    : 'No schedule has been imported for this project yet.',
                'percent_complete' => null,
            ];
        }

        $activities = ScheduleActivity::query()->where('schedule_version_id', $version->id)
            ->get(['duration_minutes', 'finish_actual']);

        $totalMinutes = (int) $activities->sum('duration_minutes');
        $completeMinutes = (int) $activities->whereNotNull('finish_actual')->sum('duration_minutes');
        $activitiesTotal = $activities->count();
        $activitiesComplete = $activities->whereNotNull('finish_actual')->count();

        return [
            'available' => true,
            'source_version' => [
                'id' => $version->id,
                'label' => $version->label,
                'kind' => $version->kind,
                'data_date' => $version->data_date?->toDateString(),
            ],
            // Duration-weighted: an activity counts toward "complete" only once it
            // carries a finish_actual, so a schedule with a handful of huge
            // activities is not misrepresented by a headcount of small ones.
            'percent_complete' => $totalMinutes > 0 ? round($completeMinutes / $totalMinutes * 100, 1) : null,
            'percent_complete_basis' => 'Duration-weighted share of scheduled activity duration whose actual finish is recorded, on the accepted schedule of record.',
            'activities_total' => $activitiesTotal,
            'activities_complete' => $activitiesComplete,
            'message' => $totalMinutes === 0
                ? 'The accepted schedule version carries no activity durations to compute a percentage from.'
                : null,
        ];
    }

    /** @return array<string,mixed> */
    private function billing(Project $project): array
    {
        $contractValueCents = (int) ScheduleOfValueItem::query()
            ->where('project_id', $project->id)->sum('scheduled_value_cents');

        if ($contractValueCents === 0 && ! ScheduleOfValueItem::query()->where('project_id', $project->id)->exists()) {
            return [
                'available' => false,
                'message' => 'No schedule of values has been set up for this project yet.',
                'contract_value_cents' => 0,
            ];
        }

        $retention = $this->retention($project);

        // Billed to date: the most recent application that has actually left
        // draft. A draft is a working figure nobody has certified yet, and
        // reporting it as "billed" would be reporting a number nobody stands
        // behind.
        $latestBilled = PayApplication::query()->where('project_id', $project->id)
            ->whereIn('status', ['certified', 'submitted', 'approved', 'paid'])
            ->orderByDesc('number')->first();

        // Paid to date: the most recent application marked paid. Each
        // application's earned_less_retention_cents is already a cumulative,
        // as-of-this-period figure (previous_completed_cents carries every
        // earlier period forward) - so the latest paid application, not a sum
        // across every paid application, is the project's cumulative paid
        // total. Summing would double-count periods.
        $latestPaid = PayApplication::query()->where('project_id', $project->id)
            ->where('status', 'paid')->orderByDesc('number')->first();

        $billedToDateCents = 0;
        $certifiedLessRetentionCents = 0;
        $retentionHeldCents = 0;
        if ($latestBilled !== null) {
            $summary = PayApplicationMath::summarize($latestBilled, retention: $retention);
            $billedToDateCents = (int) $summary['total_completed_and_stored_cents'];
            $certifiedLessRetentionCents = (int) $summary['earned_less_retention_cents'];
            $retentionHeldCents = (int) $summary['retention_cents'];
        }

        $paidToDateCents = 0;
        if ($latestPaid !== null) {
            $paidSummary = PayApplicationMath::summarize($latestPaid, retention: $retention);
            $paidToDateCents = (int) $paidSummary['earned_less_retention_cents'];
        }

        return [
            'available' => true,
            'contract_value_cents' => $contractValueCents,
            'billed_to_date_cents' => $billedToDateCents,
            'retention_held_cents' => $retentionHeldCents,
            'paid_to_date_cents' => $paidToDateCents,
            // What is certified/submitted less retention, minus what has actually
            // been paid. This is the figure a "how much do we still owe" question
            // is asking for - not the raw billed total, which still has retention
            // sitting in it.
            'outstanding_unpaid_cents' => $certifiedLessRetentionCents - $paidToDateCents,
            'percent_billed' => $contractValueCents > 0
                ? round($billedToDateCents / $contractValueCents * 100, 1) : null,
            'pay_applications_count' => PayApplication::query()->where('project_id', $project->id)->count(),
            'latest_application' => $latestBilled !== null ? [
                'id' => $latestBilled->id,
                'number' => $latestBilled->number,
                'status' => $latestBilled->status,
                'period_to' => $latestBilled->period_to?->toDateString(),
            ] : null,
            'message' => $latestBilled === null
                ? 'No pay application has been certified for this project yet.' : null,
        ];
    }

    private function retention(Project $project): RetentionRule
    {
        return RetentionRule::fromProjectTerms($project->payment_terms)
            ?? new RetentionRule(
                basisPoints: RetentionRule::STATUTORY_CAP_BASIS_POINTS,
                source: 'No governing retention rule is recorded on this project. Statutory cap shown as a ceiling, not a confirmed rate.',
                confirmed: false,
            );
    }
}
