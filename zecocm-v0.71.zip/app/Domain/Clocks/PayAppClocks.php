<?php

namespace App\Domain\Clocks;

use DateTimeImmutable;

/**
 * The two SEQUENTIAL payment-application clocks (patent Addendum L note):
 * review clock runs from submission; payment clock starts only at approval.
 * On CA public works a statutory deemed-approval backstop applies
 * (Public Contract Code s. 20104.50) - carried as a cited default,
 * confirmed by a human at project setup, never silently assumed.
 */
final class PayAppClocks
{
    public function __construct(
        public readonly DeadlineExpression $review,
        public readonly DeadlineExpression $payment,
        public readonly ?int $statutoryBackstopCalendarDays = null,
        public readonly ?string $backstopCitation = null,
    ) {}

    public function reviewDue(DateTimeImmutable $submittedAt): DateTimeImmutable
    {
        return $this->review->dueFrom($submittedAt);
    }

    public function backstopDeemedApprovedAt(DateTimeImmutable $submittedAt): ?DateTimeImmutable
    {
        if ($this->statutoryBackstopCalendarDays === null) {
            return null;
        }

        return $submittedAt->modify("+{$this->statutoryBackstopCalendarDays} days");
    }

    /** Payment clock anchors at APPROVAL, never submission. */
    public function paymentDue(DateTimeImmutable $approvedAt): DateTimeImmutable
    {
        return $this->payment->dueFrom($approvedAt);
    }
}
