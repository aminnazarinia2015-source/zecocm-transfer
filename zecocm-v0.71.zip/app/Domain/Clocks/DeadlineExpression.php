<?php

namespace App\Domain\Clocks;

use DateTimeImmutable;

/**
 * A contract deadline stored as an EXPRESSION, not a static date
 * (patent Aspect 8): an anchor event, a period, and a calendar basis.
 * Recomputes whenever the anchor moves. Pure PHP - no framework.
 */
final class DeadlineExpression
{
    public const BASIS_CALENDAR = 'calendar';

    public const BASIS_WORKING = 'working';

    /** @param list<string> $holidays Y-m-d strings treated as non-working */
    public function __construct(
        public readonly int $periodDays,
        public readonly string $basis = self::BASIS_WORKING,
        public readonly array $holidays = [],
        public readonly bool $saturdayWorking = false,
    ) {
        if ($periodDays < 0) {
            throw new \InvalidArgumentException('periodDays must be >= 0');
        }
    }

    public function dueFrom(DateTimeImmutable $anchor): DateTimeImmutable
    {
        if ($this->basis === self::BASIS_CALENDAR) {
            return $anchor->modify("+{$this->periodDays} days");
        }

        $date = $anchor;
        $remaining = $this->periodDays;
        while ($remaining > 0) {
            $date = $date->modify('+1 day');
            if ($this->isWorkingDay($date)) {
                $remaining--;
            }
        }

        return $date;
    }

    public function isWorkingDay(DateTimeImmutable $date): bool
    {
        $dow = (int) $date->format('N'); // 1=Mon .. 7=Sun
        if ($dow === 7) {
            return false;
        }
        if ($dow === 6 && ! $this->saturdayWorking) {
            return false;
        }

        return ! in_array($date->format('Y-m-d'), $this->holidays, true);
    }

    /** Signed days: negative = still has time, 0 = due today, positive = late. */
    public function daysLate(DateTimeImmutable $anchor, DateTimeImmutable $now): int
    {
        $due = $this->dueFrom($anchor)->setTime(23, 59, 59);
        $now = $now->setTime(12, 0);
        $interval = $due->diff($now);
        $days = (int) $interval->format('%r%a');

        return $days > 0 ? $days : ($now > $due ? 1 : $days);
    }
}
