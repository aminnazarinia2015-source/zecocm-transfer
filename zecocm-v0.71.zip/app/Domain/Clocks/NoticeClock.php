<?php

namespace App\Domain\Clocks;

use DateTimeImmutable;

/**
 * The clock that decides whether a valid claim survives.
 *
 * Late notice kills more change orders than bad pricing does. A contractor can be
 * completely right about a differing site condition, price it perfectly, and lose
 * the entire claim because the changes clause required written notice within ten
 * days of discovery and nobody counted the days. The money is not lost in
 * negotiation; it is lost quietly, weeks earlier, while everyone is busy building.
 *
 * So this clock has one job: make the deadline impossible to miss, and make the
 * consequence of missing it explicit rather than discovered later by a lawyer.
 *
 * Two properties matter more than the arithmetic:
 *
 *   PRESERVATIVE vs ADMINISTRATIVE. Some notice periods bar the claim outright if
 *   missed; others are procedural and merely awkward. Conflating them is
 *   dangerous in both directions - it either panics people over paperwork or
 *   lets them stroll past the one deadline that forfeits their money. The
 *   distinction comes from the contract clause, and the clause is cited.
 *
 *   NEVER INVENTED. There is no default notice period. A clock exists only when
 *   somebody read the contract and recorded the clause it comes from. An assumed
 *   ten days that turns out to be five is worse than no clock at all, because a
 *   wrong deadline is trusted.
 */
final class NoticeClock
{
    /** Missing this deadline bars the claim. The clause says so. */
    public const EFFECT_PRESERVATIVE = 'preservative';

    /** Procedural. Missing it is a defect, not a forfeiture. */
    public const EFFECT_ADMINISTRATIVE = 'administrative';

    public function __construct(
        public readonly DeadlineExpression $expression,
        /** e.g. "General Conditions 6.3.2" - the clause this period comes from. */
        public readonly string $clauseCitation,
        public readonly string $effect = self::EFFECT_PRESERVATIVE,
        /** What the clause requires: written notice, notice plus records, etc. */
        public readonly ?string $requirement = null,
    ) {
        if (trim($clauseCitation) === '') {
            // A period with no clause behind it is somebody's memory, and memory
            // is not a contract term.
            throw new \InvalidArgumentException(
                'A notice clock must cite the contract clause it comes from. Without a citation it is an assumption, and an assumed deadline is trusted exactly as much as a real one.'
            );
        }

        if (! in_array($effect, [self::EFFECT_PRESERVATIVE, self::EFFECT_ADMINISTRATIVE], true)) {
            throw new \InvalidArgumentException('Unknown notice effect: '.$effect);
        }
    }

    /**
     * Build from a project's recorded contract clocks. Returns null when the
     * contract has no recorded notice clause - the caller must then say "no
     * notice clock is configured for this contract", never assume one.
     *
     * @param  array<string,mixed>  $clock  as stored on Project::contract_clocks
     * @param  list<string>  $holidays
     */
    public static function fromContractClock(?array $clock, array $holidays = []): ?self
    {
        if (! is_array($clock) || ! isset($clock['days'], $clock['source'])) {
            return null;
        }

        $days = (int) $clock['days'];
        $source = trim((string) $clock['source']);
        if ($days <= 0 || $source === '') {
            return null;
        }

        return new self(
            new DeadlineExpression(
                $days,
                ($clock['basis'] ?? 'calendar') === 'working'
                    ? DeadlineExpression::BASIS_WORKING
                    : DeadlineExpression::BASIS_CALENDAR,
                $holidays,
            ),
            $source,
            ($clock['effect'] ?? self::EFFECT_PRESERVATIVE) === self::EFFECT_ADMINISTRATIVE
                ? self::EFFECT_ADMINISTRATIVE
                : self::EFFECT_PRESERVATIVE,
            $clock['requirement'] ?? null,
        );
    }

    /** The date written notice is due, counted from the date the event was identified. */
    public function dueFrom(DateTimeImmutable $identifiedAt): DateTimeImmutable
    {
        return $this->expression->dueFrom($identifiedAt);
    }

    /**
     * Days remaining. Negative means time left, 0 due today, positive means late.
     * Deliberately the same sign convention as DeadlineExpression::daysLate so
     * nobody has to remember two.
     */
    public function daysLate(DateTimeImmutable $identifiedAt, DateTimeImmutable $now): int
    {
        return $this->expression->daysLate($identifiedAt, $now);
    }

    public function barsTheClaimIfMissed(): bool
    {
        return $this->effect === self::EFFECT_PRESERVATIVE;
    }

    /**
     * The whole state of this deadline, ready to render, with the plain-English
     * consequence attached. The urgency band is deliberately coarse - a
     * superintendent glancing at a phone needs one of four answers, not a number.
     *
     * @return array{
     *   due: string, days_remaining: int, state: string, bars_claim: bool,
     *   clause: string, requirement: ?string, message: string
     * }
     */
    public function status(DateTimeImmutable $identifiedAt, DateTimeImmutable $now): array
    {
        $due = $this->dueFrom($identifiedAt);
        $late = $this->daysLate($identifiedAt, $now);
        $remaining = -$late;

        $state = match (true) {
            $late > 0 => 'missed',
            $remaining <= 1 => 'critical',
            $remaining <= 3 => 'urgent',
            default => 'open',
        };

        $consequence = $this->barsTheClaimIfMissed()
            ? 'Missing it bars the claim under '.$this->clauseCitation.'.'
            : 'Procedural under '.$this->clauseCitation.'; missing it is a defect, not a forfeiture.';

        $message = match ($state) {
            'missed' => $this->barsTheClaimIfMissed()
                ? 'Notice was due '.$due->format('D j M Y').' and was not given. '.$this->clauseCitation
                    .' bars the claim on late notice. Preserve the record and get advice; do not treat this as still open.'
                : 'Notice was due '.$due->format('D j M Y').' and is late. '.$consequence,
            'critical' => 'Written notice is due '.$due->format('D j M Y').' - '
                .($remaining === 0 ? 'today' : 'tomorrow').'. '.$consequence,
            'urgent' => 'Written notice is due in '.$remaining.' days, '.$due->format('D j M Y').'. '.$consequence,
            default => 'Written notice is due '.$due->format('D j M Y').' ('.$remaining.' days). '.$consequence,
        };

        return [
            'due' => $due->format('Y-m-d'),
            'days_remaining' => $remaining,
            'state' => $state,
            'bars_claim' => $this->barsTheClaimIfMissed(),
            'clause' => $this->clauseCitation,
            'requirement' => $this->requirement,
            'message' => $message,
        ];
    }
}
