<?php

namespace App\Domain\Documents;

use App\Models\Tenant;
use Illuminate\Support\Facades\Storage;

/**
 * Who this document belongs to. Never ZecoCM.
 *
 * The platform is the instrument, not the author. A transmittal issued through ZecoCM
 * carries the issuing account's legal name, address, mark and accent - and nothing that
 * identifies the software. This is deliberate: the document has to be filable by a public
 * agency as the contractor's or the CM's own correspondence.
 */
final class DocumentBrand
{
    private function __construct(
        public readonly string $name,
        public readonly array $addressLines,
        public readonly string $accent,
        public readonly string $mark,
        public readonly ?string $logoDataUri,
    ) {}

    public static function forTenant(?Tenant $tenant): self
    {
        $name = trim((string) ($tenant?->legal_name ?: $tenant?->name ?: ''));
        if ($name === '') {
            $name = 'Issuing party';
        }

        return new self(
            name: $name,
            addressLines: array_values(array_filter(array_map('trim', (array) ($tenant?->address_lines ?? [])))),
            accent: self::safeColour((string) ($tenant?->brand_accent ?? '')) ?: '#123b3b',
            mark: strtoupper(substr(trim((string) ($tenant?->brand_mark ?: $name)), 0, 2)),
            logoDataUri: self::logo($tenant),
        );
    }

    /** A counterparty we hold no account for still gets a proper party block. */
    public static function forCounterparty(string $name, array $addressLines): self
    {
        return new self(
            name: trim($name) !== '' ? trim($name) : 'Owner',
            addressLines: array_values(array_filter(array_map('trim', $addressLines))),
            accent: '#3d4a52',
            mark: strtoupper(substr(trim($name) !== '' ? trim($name) : 'OW', 0, 2)),
            logoDataUri: null,
        );
    }

    private static function safeColour(string $value): ?string
    {
        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) === 1 ? $value : null;
    }

    /**
     * Logos are embedded as data URIs so the issued document is one self-contained file:
     * it prints, e-mails and archives identically, with no request back to any server.
     */
    private static function logo(?Tenant $tenant): ?string
    {
        $path = $tenant?->logo_path;
        if (! $path) {
            return null;
        }
        try {
            $disk = Storage::disk(config('filesystems.default'));
            if (! $disk->exists($path)) {
                return null;
            }
            $bytes = $disk->get($path);
            if ($bytes === null || strlen($bytes) > 2_000_000) {
                return null;
            }
            $info = @getimagesizefromstring($bytes);
            if ($info === false || ! in_array($info['mime'] ?? '', ['image/png', 'image/jpeg', 'image/gif', 'image/webp'], true)) {
                return null;   // verified raster only; an SVG could carry script into the document
            }

            return 'data:'.$info['mime'].';base64,'.base64_encode($bytes);
        } catch (\Throwable) {
            return null;
        }
    }
}
