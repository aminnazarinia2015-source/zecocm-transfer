<?php

namespace App\Domain\Documents;

final class ComposedDocument
{
    public function __construct(
        public readonly string $html,
        public readonly bool $overflow,
        public readonly string $fingerprint,
        public readonly string $documentNumber,
        public readonly string $recordType,
        public readonly int $recordId,
        public readonly array $parties,
        public readonly array $clock,
        public readonly array $attachments,
    ) {}
}
