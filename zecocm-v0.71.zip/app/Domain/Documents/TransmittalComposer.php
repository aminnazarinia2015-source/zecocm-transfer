<?php

namespace App\Domain\Documents;

use App\Domain\Schedule\ProjectGrant;
use App\Models\ChangeOrder;
use App\Models\EvidenceLink;
use App\Models\MediaItem;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Models\Tenant;

/**
 * Composes an issue-ready RFI or submittal transmittal.
 *
 * What makes this different from the Word template every contractor keeps on a shared
 * drive, and from every competitor's PDF export:
 *
 *  1. The party block is DERIVED from the account and the project record, so "To" and
 *     "From" cannot be stale or wrong. Nobody retypes a header.
 *  2. A PRECEDENCE STRIP names the contract instruments the question sits between, in
 *     the order the contract itself gives them. That ordering is the whole substance of
 *     a good RFI and today it is done by hand, if at all.
 *  3. The CLOCK STRIP shows the contract response period, the clause it came from, the
 *     computed due date and the arithmetic. No typed due dates.
 *  4. Impacts are printed as ASSERTIONS by the originator, labelled as such. The document
 *     never converts a party's claim into a finding, and never assigns fault.
 *  5. The EVIDENCE LEDGER lists each attachment with its SHA-256 and seal time, and the
 *     document itself carries a fingerprint, so a copy can be proved to be the copy issued.
 *
 * Output is one self-contained HTML file: no external fonts, scripts, styles or images.
 */
final class TransmittalComposer
{
    public function rfi(Rfi $rfi, Project $project, ProjectGrant $grant): ComposedDocument
    {
        $issuer = DocumentBrand::forTenant(Tenant::find($project->tenant_id));
        $recipient = DocumentBrand::forCounterparty(
            (string) ($project->owner_name ?? 'Owner'),
            (array) ($project->owner_address_lines ?? [])
        );

        $anchor = $rfi->raised_at ? new \DateTimeImmutable((string) $rfi->raised_at) : null;
        $clock = $this->clock($project, ['rfi_response', 'rfi'], $anchor, 'RFI response period');

        $impactWord = ['yes' => 'Yes', 'no' => 'No', 'not_stated' => 'Not stated'];
        $linked = $rfi->linked_submittal_id ? Submittal::find($rfi->linked_submittal_id) : null;

        $fields = [
            ['Date initiated', $anchor?->format('j M Y') ?? '—'],
            ['Status', ucfirst(str_replace('_', ' ', (string) $rfi->status))],
            ['Ball in court', (string) ($rfi->ball_in_court ?: '—')],
            ['Response due', $clock['due'] ?? 'no contract clock configured'],
            ['Project site', (string) ($project->site_address ?: '—')],
            ['Raised by', (string) ($rfi->raised_by_org ?: $issuer->name)],
        ];

        $references = [
            ['Specification section', (string) ($rfi->spec_section ?: 'Not cited')],
            ['Plan sheets / details', (string) ($rfi->plan_sheets ?: 'Not cited')],
            ['Reference', (string) ($rfi->reference ?: '—')],
            ['Linked submittal', $linked
                ? $linked->number.' — '.$linked->title.($linked->spec_section ? ' (§ '.$linked->spec_section.')' : '')
                : 'None linked'],
            ['Cost impact', $impactWord[$rfi->impact('cost')]],
            ['Time impact', $impactWord[$rfi->impact('schedule')]],
        ];

        return $this->render(
            issuer: $issuer,
            recipient: $recipient,
            project: $project,
            kind: 'REQUEST FOR INFORMATION',
            number: (string) $rfi->number,
            title: (string) $rfi->subject,
            fields: $fields,
            references: $references,
            clock: $clock,
            bodyLabel: 'Question from '.$issuer->name,
            body: (string) $rfi->question,
            assertions: self::impactAssertions($rfi->impact('cost'), $rfi->impact('schedule')),
            responseLabel: 'Response',
            response: $rfi->status === 'answered' ? (string) $rfi->response : null,
            responseSeal: is_array($rfi->response_seal) ? $rfi->response_seal : null,
            attachments: $this->attachments('rfi', $rfi->id, $grant),
            recordType: 'rfi',
            recordId: $rfi->id,
        );
    }

    public function submittal(Submittal $submittal, Project $project, ProjectGrant $grant): ComposedDocument
    {
        $issuer = DocumentBrand::forTenant(Tenant::find($project->tenant_id));
        $recipient = DocumentBrand::forCounterparty(
            (string) ($project->owner_name ?? 'Owner'),
            (array) ($project->owner_address_lines ?? [])
        );

        $anchor = $submittal->submitted_at ? new \DateTimeImmutable((string) $submittal->submitted_at) : null;
        $clock = $this->clock($project, ['submittal_review'], $anchor, 'Submittal review period');

        $fields = [
            ['Date submitted', $anchor?->format('j M Y') ?? '—'],
            ['Specification section', (string) ($submittal->spec_section ?: '—')],
            ['Type', ucfirst(str_replace('_', ' ', (string) $submittal->type))],
            ['Review due', $clock['due'] ?? 'no contract clock configured'],
            ['Ball in court', (string) ($submittal->ball_in_court ?: '—')],
            ['Submitted by', (string) ($submittal->submitted_by_org ?: $issuer->name)],
        ];

        $stamp = is_array($submittal->stamp) ? $submittal->stamp : null;

        return $this->render(
            issuer: $issuer,
            recipient: $recipient,
            project: $project,
            kind: 'SUBMITTAL TRANSMITTAL',
            number: (string) $submittal->number,
            title: (string) $submittal->title,
            fields: $fields,
            references: [
                ['Specification section', (string) ($submittal->spec_section ?: 'Not cited')],
                ['Contact', (string) ($submittal->contact_person ?: '—')],
            ],
            clock: $clock,
            bodyLabel: 'Item submitted for review',
            body: (string) $submittal->title,
            assertions: [],
            responseLabel: 'Review action',
            response: $stamp['action'] ?? null,
            responseSeal: $stamp,
            attachments: $this->attachments('submittal', $submittal->id, $grant),
            recordType: 'submittal',
            recordId: $submittal->id,
        );
    }

    public function changeOrder(ChangeOrder $order, Project $project, ProjectGrant $grant): ComposedDocument
    {
        $issuer = DocumentBrand::forTenant(Tenant::find($project->tenant_id));
        $recipient = DocumentBrand::forCounterparty(
            (string) ($project->owner_name ?? 'Owner'),
            (array) ($project->owner_address_lines ?? [])
        );

        $anchor = $order->identified_at ? new \DateTimeImmutable((string) $order->identified_at) : null;
        $clock = $this->clock($project, ['change_order_response'], $anchor, 'Change order review period');
        $amount = number_format(((int) $order->amount_cents) / 100, 2);
        $amountLabel = ((int) $order->amount_cents) < 0 ? '-$'.number_format(abs((int) $order->amount_cents) / 100, 2) : '$'.$amount;

        $fields = [
            ['Date identified', $anchor?->format('j M Y') ?? '—'],
            ['Origin', $order->origin_reason ? ucfirst(str_replace('_', ' ', (string) $order->origin_reason)) : '—'],
            ['Funding source', $order->funding_source ? ucfirst(str_replace('_', ' ', (string) $order->funding_source)) : '—'],
            ['Contract amount change', $amountLabel],
            ['Time extension', (string) ($order->time_extension_days ?: 0).' days'],
            ['Status', ucfirst(str_replace('_', ' ', (string) $order->status))],
        ];

        $seal = is_array($order->seal) ? $order->seal : null;

        return $this->render(
            issuer: $issuer,
            recipient: $recipient,
            project: $project,
            kind: 'CHANGE ORDER',
            number: (string) $order->number,
            title: (string) $order->title,
            fields: $fields,
            references: [
                ['Funding source', (string) ($order->funding_source ?: 'Not cited')],
            ],
            clock: $clock,
            bodyLabel: 'Description of change',
            body: (string) $order->title,
            assertions: [],
            responseLabel: 'Approval status',
            response: $order->status,
            responseSeal: $seal,
            attachments: $this->attachments('change_order', $order->id, $grant),
            recordType: 'change_order',
            recordId: $order->id,
        );
    }

    public function payApplication(PayApplication $application, Project $project, ProjectGrant $grant): ComposedDocument
    {
        $issuer = DocumentBrand::forTenant(Tenant::find($project->tenant_id));
        $recipient = DocumentBrand::forCounterparty(
            (string) ($project->owner_name ?? 'Owner'),
            (array) ($project->owner_address_lines ?? [])
        );

        $anchor = $application->submitted_at ? new \DateTimeImmutable((string) $application->submitted_at) : null;
        $clock = $this->clock($project, ['pay_application_review'], $anchor, 'Payment application review period');

        $application->loadMissing('lines');
        $thisPeriodCents = (int) $application->lines->sum('this_period_cents');
        $storedCents = (int) $application->lines->sum('stored_materials_cents');
        $retentionCents = (int) round(($thisPeriodCents + $storedCents) * ((int) $application->retention_basis_points) / 10000);
        $netCents = $thisPeriodCents + $storedCents - $retentionCents;
        $dollars = fn (int $cents) => '$'.number_format($cents / 100, 2);

        $fields = [
            ['Period', ($application->period_from?->format('j M Y') ?? '—').' – '.($application->period_to?->format('j M Y') ?? '—')],
            ['This period earned', $dollars($thisPeriodCents)],
            ['Stored materials', $dollars($storedCents)],
            ['Retention', $dollars($retentionCents).' ('.number_format(((int) $application->retention_basis_points) / 100, 2).'%)'],
            ['Net this application', $dollars($netCents)],
            ['Status', ucfirst(str_replace('_', ' ', (string) $application->status))],
        ];

        $seal = is_array($application->seal) ? $application->seal : null;

        return $this->render(
            issuer: $issuer,
            recipient: $recipient,
            project: $project,
            kind: 'APPLICATION FOR PAYMENT',
            number: (string) $application->number,
            title: 'Application for Payment No. '.$application->number,
            fields: $fields,
            references: [
                ['Retention basis', number_format(((int) $application->retention_basis_points) / 100, 2).'%'],
            ],
            clock: $clock,
            bodyLabel: 'Certification',
            body: 'The undersigned certifies that the work covered by this application has been completed in accordance with '
                .'the contract documents, that all amounts have been paid for work for which previous certificates for '
                .'payment were issued, and that the current payment shown is now due.',
            assertions: [],
            responseLabel: 'Certification status',
            response: $application->status,
            responseSeal: $seal,
            attachments: $this->attachments('pay_application', $application->id, $grant),
            recordType: 'pay_application',
            recordId: $application->id,
        );
    }

    /* ------------------------------------------------------------------ */

    /** @return array<string,mixed> */
    private function clock(Project $project, array $names, ?\DateTimeImmutable $anchor, string $label): array
    {
        foreach ($names as $name) {
            try {
                $expr = $project->clock($name);
            } catch (\Throwable) {
                continue;
            }
            $raw = $project->contract_clocks[$name] ?? [];
            $days = (int) ($raw['days'] ?? 0);
            $basis = (string) ($raw['basis'] ?? 'working');
            $source = (string) ($raw['source'] ?? 'the project record');

            if ($anchor === null) {
                return ['label' => $label, 'days' => $days, 'basis' => $basis, 'source' => $source,
                    'due' => null, 'working_out' => 'No anchor date is recorded, so no due date can be computed.'];
            }
            $due = $expr->dueFrom($anchor);

            return [
                'label' => $label,
                'days' => $days,
                'basis' => $basis,
                'source' => $source,
                'due' => $due->format('j M Y'),
                'working_out' => $anchor->format('j M Y').' + '.$days.' '.$basis.' days ('.$source.') = '.$due->format('j M Y'),
            ];
        }

        return ['label' => $label, 'days' => null, 'basis' => null, 'source' => null, 'due' => null,
            'working_out' => 'This project has no '.strtolower($label).' recorded, so no due date is printed. A period is never assumed.'];
    }

    /** @return array<int,array<string,mixed>> */
    private function attachments(string $type, int $id, ProjectGrant $grant): array
    {
        $showHashes = $grant->allows('records.view_source_metadata') || $grant->allows('*');
        $links = EvidenceLink::query()
            ->where('record_type', $type)
            ->where('record_id', $id)
            ->limit(50)->get();

        $out = [];
        foreach ($links as $link) {
            $media = MediaItem::find($link->media_item_id);
            if ($media === null) {
                continue;
            }
            $out[] = [
                'name' => (string) ($media->original_name ?? 'Attachment'),
                'sha256' => $showHashes ? (string) ($media->sha256 ?? '') : null,
                'sealed_at' => optional($media->created_at)->format('j M Y H:i'),
            ];
        }

        return $out;
    }

    /** @param array<int,array{0:string,1:string}> $fields */
    private function render(
        DocumentBrand $issuer,
        DocumentBrand $recipient,
        Project $project,
        string $kind,
        string $number,
        string $title,
        array $fields,
        array $references,
        array $clock,
        string $bodyLabel,
        string $body,
        array $assertions,
        string $responseLabel,
        ?string $response,
        ?array $responseSeal,
        array $attachments,
        string $recordType,
        int $recordId,
    ): ComposedDocument {
        $e = fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $accent = $issuer->accent;

        // ONE PAGE, ALWAYS. A transmittal is a cover sheet; attachments follow it as their
        // own documents. The body type steps down through fixed densities so the sheet fills
        // without spilling, and if the text genuinely cannot fit at the tightest density the
        // document says so out loud rather than silently losing the end of a sentence.
        [$bodySize, $bodyLead, $overflow] = self::density($body, $attachments, $assertions);

        $logo = $issuer->logoDataUri !== null
            ? '<img class="logo" src="'.$e($issuer->logoDataUri).'" alt="">'
            : '<div class="mark" style="background:'.$e($accent).'">'.$e($issuer->mark).'</div>';

        $addr = fn (DocumentBrand $b) => implode('', array_map(fn ($l) => '<div>'.$e($l).'</div>', $b->addressLines));


        // The reference block: what this item points at. Impacts read Yes / No / Not stated,
        // and "Not cited" is printed rather than an empty cell, so a gap is visible.
        $refRows = '';
        foreach (array_merge($fields, $references) as [$k, $v]) {
            $flag = in_array($v, ['Not cited', 'None linked', 'Not stated', '—'], true) ? ' class="thin"' : '';
            $refRows .= '<div class="ref"><span class="ref-k">'.$e($k).'</span><span'.$flag.'>'.$e($v).'</span></div>';
        }
        $refBlock = '<div class="strip"><div class="strip-h">PROJECT DETAIL, REFERENCES &amp; DECLARED IMPACT</div>'
            .'<div class="strip-b refs">'.$refRows.'</div></div>';

        $precedence = $this->precedenceStrip($project, $e, $accent);

        $clockBlock = '<div class="strip"><div class="strip-h">CONTRACT CLOCK</div>'
            .'<div class="strip-b"><strong>'.$e($clock['label']).'</strong>'
            .($clock['days'] !== null ? ' — '.$e($clock['days']).' '.$e($clock['basis']).' days, per '.$e($clock['source']) : '')
            .'<div class="workings">'.$e($clock['working_out']).'</div></div></div>';

        $assertBlock = '';
        if ($assertions !== []) {
            $assertBlock = '<div class="assert"><span class="tag">ASSERTED BY THE ORIGINATOR</span> '
                .$e(implode(' ', $assertions))
                .' <span class="workings">Recorded as stated; not adopted as a finding, and no responsibility is assigned.</span></div>';
        }

        $respBlock = '<div class="resp"><div class="resp-h">'.$e($responseLabel).'</div>';
        if ($response !== null && trim($response) !== '') {
            $respBlock .= '<div class="resp-b">'.nl2br($e($response)).'</div>';
            $who = $responseSeal['by'] ?? ($responseSeal['stamped_by'] ?? null);
            $when = $responseSeal['at'] ?? ($responseSeal['stamped_at'] ?? null);
            if ($who || $when) {
                $respBlock .= '<div class="seal">Sealed'.($who ? ' by '.$e($who) : '').($when ? ' on '.$e($when) : '')
                    .' — corrections append as a new revision; this text cannot be edited in place.</div>';
            }
        } else {
            $respBlock .= '<div class="resp-empty">Awaiting response. This space is left deliberately blank rather than pre-filled.</div>';
        }
        $respBlock .= '</div>';

        $attachBlock = '<div class="ledger"><span class="ledger-h">EVIDENCE LEDGER</span> ';
        if ($attachments === []) {
            $attachBlock .= 'No attachments are linked to this record.';
        } else {
            $parts = [];
            foreach ($attachments as $i => $a) {
                $parts[] = ($i + 1).'. '.$e($a['name'])
                    .($a['sha256'] ? ' <span class="hash">'.$e(substr($a['sha256'], 0, 12)).'…</span>' : '')
                    .($a['sealed_at'] ? ' · sealed '.$e($a['sealed_at']) : '');
            }
            $attachBlock .= implode(' &nbsp;|&nbsp; ', $parts).' &nbsp;— attachments follow this cover sheet as separate documents.';
        }
        $attachBlock .= '</div>';

        $html = '<!doctype html><html lang="en"><head><meta charset="utf-8">'
            .'<title>'.$e($number).' — '.$e($title).'</title><style>'
            .$this->css($accent)
            .'</style></head><body><div class="page">'
            .'<header class="head">'
            .'<div class="from">'.$logo.'<div class="fromtext"><div class="who">'.$e($issuer->name).'</div>'.$addr($issuer).'</div></div>'
            .'<div class="ident"><div class="kind">'.$e($kind).'</div><div class="num">'.$e($number).'</div>'
            .'<div class="proj">'.$e($project->number).' · '.$e($project->name).'</div>'
            .'<div class="site">'.$e((string) ($project->site_address ?: '')).'</div></div>'
            .'</header>'
            .'<div class="rule" style="background:'.$e($accent).'"></div>'
            .'<h1>'.$e($title).'</h1>'
            .'<table class="parties"><tr>'
            .'<th>TO</th><td><strong>'.$e($recipient->name).'</strong>'.$addr($recipient).'</td>'
            .'<th>FROM</th><td><strong>'.$e($issuer->name).'</strong>'.$addr($issuer).'</td>'
            .'</tr></table>'
            .$refBlock
            .'<div class="duo">'.$precedence.$clockBlock.'</div>'
            .'<div class="body"><div class="body-h" style="background:'.$e($accent).'">'.$e($bodyLabel).'</div>'
            .'<div class="body-b" style="font-size:'.$bodySize.'px;line-height:'.$bodyLead.';">'.nl2br($e($body)).'</div>'
            .($overflow ? '<div class="spill">This item is longer than one cover sheet. It continues in the attached statement listed in the evidence ledger. Nothing has been shortened on the record.</div>' : '')
            .'</div>'
            .$assertBlock
            .$attachBlock
            .$respBlock
            .'<footer class="foot"><div class="fingerprint">DOCUMENT FINGERPRINT <span id="fp">__FINGERPRINT__</span></div>'
            .'<div class="verify">Any copy of this document whose fingerprint differs from the one on the issuing party\'s register is not the copy that was issued.</div></footer>'
            .'</div></body></html>';

        $fingerprint = hash('sha256', $html);
        // Display the complete SHA-256 identity. A truncated value is useful as a
        // short code but must never be mistaken for the verification hash.
        $html = str_replace('__FINGERPRINT__', $fingerprint, $html);

        return new ComposedDocument(
            html: $html,
            overflow: $overflow,
            fingerprint: $fingerprint,
            documentNumber: $number,
            recordType: $recordType,
            recordId: $recordId,
            parties: ['issuer' => $issuer->name, 'recipient' => $recipient->name],
            clock: $clock,
            attachments: $attachments,
        );
    }

    /**
     * The precedence strip. A dispute between two contract instruments is the substance of
     * most RFIs, and no register in this industry records WHICH instruments are in tension
     * or in what order they govern. ZecoCM prints the order the contract itself states, and
     * says plainly when the order does not resolve the conflict.
     */
    private function precedenceStrip(Project $project, callable $e, string $accent): string
    {
        $order = $project->org_structure['precedence'] ?? null;
        if (! is_array($order) || $order === []) {
            return '<div class="strip"><div class="strip-h">ORDER OF PRECEDENCE</div><div class="strip-b">'
                .'No order of precedence has been recorded for this contract, so none is printed. '
                .'ZecoCM will not infer which document governs.</div></div>';
        }
        $items = '';
        foreach (array_values($order) as $i => $doc) {
            $items .= '<li><span class="rank" style="background:'.$e($accent).'">'.($i + 1).'</span>'.$e($doc).'</li>';
        }

        return '<div class="strip"><div class="strip-h">ORDER OF PRECEDENCE</div><div class="strip-b">'
            .'<ol class="prec">'.$items.'</ol>'
            .'<div class="workings">Read as recorded from the contract. Where two instruments hold the same rank, '
            .'the order does not resolve a conflict between them and the owner\'s interpretation is required.</div>'
            .'</div></div>';
    }

    /**
     * Cost and time impact are the originator's declarations. When either is claimed the
     * sheet says so in plain words and, in the same breath, that the document neither adopts
     * the claim nor assigns responsibility for it. That sentence is what keeps an RFI from
     * reading as a claim letter.
     *
     * @return array<int,string>
     */
    private static function impactAssertions(string $cost, string $schedule): array
    {
        $claimed = [];
        if ($cost === 'yes') {
            $claimed[] = 'cost';
        }
        if ($schedule === 'yes') {
            $claimed[] = 'time';
        }
        if ($claimed === []) {
            return [];
        }

        return [ucfirst(implode(' and ', $claimed)).' impact '.(count($claimed) === 1 ? 'is' : 'are').' declared by the originator on this item.'];
    }

    /**
     * Choose a body density that fills exactly one letter sheet.
     *
     * A transmittal is a COVER SHEET. It is always one page; attachments follow it as their
     * own documents. The furniture above and below the question is fixed, so the well left
     * for the question is a known height, measured against a real browser render rather than
     * guessed. The first density whose text fits that well is used.
     *
     * Nothing is ever silently truncated. If the item genuinely cannot fit at the tightest
     * legible density, the sheet says so, the caller is told, and the full text remains on
     * the record and goes out as the first attachment.
     *
     * @return array{0:float,1:float,2:bool}
     */
    private static function density(string $body, array $attachments, array $assertions): array
    {
        // Measured against a headless letter-size render of this exact layout.
        $budget = 180.0;                                   // px of body well, with an assertion line
        if ($assertions === []) {
            $budget += 30.0;                               // no assertion line: the well grows
        }
        if (count($attachments) > 2) {
            $budget -= 13.0 * (int) floor((count($attachments) - 1) / 2);   // ledger wraps
        }

        $chars = mb_strlen(trim($body));
        $breaks = substr_count($body, "\n");

        // [font px, line-height, characters per line]  cpl scales inversely with type size.
        $steps = [[12.5, 1.60, 88], [11.5, 1.52, 96], [10.5, 1.44, 105], [9.5, 1.38, 116], [8.5, 1.32, 130]];

        foreach ($steps as [$px, $lead, $cpl]) {
            $lines = ($chars / $cpl) + $breaks;
            if ($lines * ($px * $lead) <= $budget) {
                return [$px, $lead, false];
            }
        }

        return [8.5, 1.32, true];
    }

    private function css(string $accent): string
    {
        return 'html,body{margin:0;padding:0;background:#f2f3f2;color:#14201f;font:13px/1.5 "Helvetica Neue",Arial,sans-serif}'
            .'@page{size:letter;margin:0}.page{width:8.5in;height:11in;margin:0 auto;background:#fff;padding:.55in .65in;box-sizing:border-box;display:flex;flex-direction:column;overflow:hidden}.body{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}.body-b{flex:1 1 auto;min-height:0;overflow:hidden}.spill{flex:none;margin:0;padding:5px 12px;border-top:1px dashed #b8892b;background:#fdf8ee;color:#8a6614;font-size:9.5px;font-style:italic}'
            .'.head{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;flex:none}'
            .'.from{display:flex;gap:12px;align-items:flex-start}.logo{max-height:64px;max-width:150px}'
            .'.mark{width:50px;height:50px;border-radius:12px;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;letter-spacing:1px}'
            .'.fromtext .who{font-weight:700;font-size:14px}.fromtext div{color:#4a5654;font-size:11.5px}'
            .'.ident{text-align:right}.kind{font-size:10px;letter-spacing:.14em;color:#66736f}'
            .'.num{font-size:27px;font-weight:700;line-height:1.1}.proj{font-size:11.5px;font-weight:600;margin-top:4px}'
            .'.site{font-size:11px;color:#66736f}'
            .'.rule{height:3px;margin:10px 0 8px}'
            .'h1{font-size:18px;margin:0 0 8px;text-align:center;letter-spacing:.01em}'
            .'table{width:100%;border-collapse:collapse}'
            .'.parties th{width:52px}.parties td{width:calc(50% - 52px)}'
            .'.parties th,.parties td,.fields th,.fields td{border-top:1px solid #dfe3e1;padding:3px 8px;vertical-align:top;text-align:left;font-size:11px}'
            .'.parties th,.fields th{font-size:9.5px;letter-spacing:.09em;color:#66736f;text-transform:uppercase;font-weight:700;white-space:nowrap}'
            .'.fields th{width:118px}'
            .'.strip{margin:7px 0;border:1px solid #dfe3e1;border-radius:6px;overflow:hidden}'
            .'.strip-h{background:#f6f7f6;padding:5px 10px;font-size:9.5px;letter-spacing:.1em;color:#5c6a67;font-weight:700}'
            .'.strip-b{padding:7px 9px;font-size:11px}'
            .'.duo{display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:start}.duo .strip{margin:8px 0 0}'
            .'.workings{margin-top:5px;font-size:10px;color:#66736f;font-style:italic}'
            .'.prec{margin:0;padding:0;list-style:none}.prec li{display:flex;gap:7px;align-items:center;padding:1px 0;font-size:11px}'
            .'.rank{width:18px;height:18px;border-radius:50%;color:#fff;font-size:10px;display:inline-flex;align-items:center;justify-content:center;flex:none}'
            .'.body{margin:8px 0;border:1px solid #14201f}'
            .'.body-h{color:#fff;padding:4px 10px;font-size:11px;font-weight:700}'
            .'.body-b{padding:10px 12px}'
            .'.assert{border-left:3px solid #b8892b;background:#fdf8ee;padding:5px 9px;margin:7px 0;font-size:10.5px}'
            .'.refs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:2px 14px}'
            .'.ref{display:flex;gap:6px;font-size:10.5px;line-height:1.35}'
            .'.ref-k{color:#66736f;font-size:9px;letter-spacing:.07em;text-transform:uppercase;font-weight:700;min-width:92px;flex:none;padding-top:1px}'
            .'.thin{color:#98a2a0;font-style:italic}'
            .'.ledger{margin:7px 0;padding:5px 9px;border:1px solid #dfe3e1;border-radius:5px;font-size:10px;color:#4a5654}'
            .'.ledger-h{font-size:9px;letter-spacing:.1em;color:#5c6a67;font-weight:700;margin-right:6px}'
            .'.tag{display:inline;font-size:9px;letter-spacing:.1em;font-weight:700;color:#8a6614;margin-bottom:4px}'
            .'.atts{margin-top:4px}.atts th,.atts td{border-top:1px solid #eceeed;padding:4px 6px;font-size:10.5px;text-align:left}'
            .'.hash{font-family:ui-monospace,Menlo,Consolas,monospace;color:#5c6a67}'
            .'.resp{margin:8px 0;flex:none;border:1px solid #dfe3e1;border-radius:6px;overflow:hidden}'
            .'.resp-h{background:#14201f;color:#fff;padding:4px 10px;font-size:11px;font-weight:700}'
            .'.resp-b{padding:12px;font-size:12.5px;line-height:1.6}'
            .'.resp-empty{padding:12px 12px;color:#8a9391;font-size:11.5px;font-style:italic}'
            .'.seal{padding:7px 12px;background:#f6f7f6;font-size:10.5px;color:#4a5654;border-top:1px solid #dfe3e1}'
            .'.foot{margin-top:auto;flex:none;border-top:1px solid #dfe3e1;padding-top:6px}'
            .'.fingerprint{font-size:8.6px;letter-spacing:.06em;color:#5c6a67;overflow-wrap:anywhere}'
            .'.fingerprint span{font-family:ui-monospace,Menlo,Consolas,monospace;letter-spacing:0}'
            .'.verify{font-size:10px;color:#8a9391;margin-top:3px}'
            .'@media print{html,body{background:#fff}.page{box-shadow:none;page-break-after:avoid}}';
    }
}
