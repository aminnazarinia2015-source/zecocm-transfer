<?php

namespace App\Domain\Ops;

/**
 * DATA-1. This is the one place in the codebase that can answer, truthfully,
 * whether evidence storage is physically independent of the application's
 * own deployment lifecycle - the property EV-14B's eventual destruction
 * executor needs before it can honestly reason about "governed storage
 * locations." It reports facts about the configured disk root; it does not
 * itself move any bytes (see the `evidence:relocate-storage` console command
 * for that) and it does not gate anything today - it is diagnostic, in the
 * same spirit TR-15's `InstructionTrust::reviewFlags()` is diagnostic rather
 * than a gate.
 */
final class StorageInventory
{
    /**
     * @return array{disk: string, root: string, configured_via_env: bool, outside_app_tree: bool, app_base_path: string}
     */
    public static function report(): array
    {
        $disk = (string) config('filesystems.default');
        $root = (string) config("filesystems.disks.{$disk}.root");
        $base = base_path();

        return [
            'disk' => $disk,
            'root' => $root,
            'configured_via_env' => (bool) config("filesystems.disks.{$disk}.root_configured_via_env", false),
            'outside_app_tree' => ! self::isWithin($root, $base),
            'app_base_path' => $base,
        ];
    }

    /**
     * True if $path resolves to somewhere inside (or equal to) $base.
     * Uses realpath() when both sides exist on disk; falls back to a
     * lexical prefix comparison so a not-yet-created root (a fresh
     * EVIDENCE_STORAGE_ROOT nobody has written to yet) is still classified
     * correctly rather than silently reporting "outside" because
     * realpath() returned false.
     */
    public static function isWithin(string $path, string $base): bool
    {
        $realPath = realpath($path);
        $realBase = realpath($base);

        $comparePath = $realPath !== false ? $realPath : rtrim($path, '/');
        $compareBase = $realBase !== false ? $realBase : rtrim($base, '/');

        $comparePath = rtrim($comparePath, '/').'/';
        $compareBase = rtrim($compareBase, '/').'/';

        return str_starts_with($comparePath, $compareBase);
    }
}
