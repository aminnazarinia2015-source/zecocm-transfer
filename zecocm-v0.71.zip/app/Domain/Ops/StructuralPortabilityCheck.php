<?php

namespace App\Domain\Ops;

use Illuminate\Support\Facades\DB;

/**
 * DATA-3, Level 1 (Codex's own three-level split: structural, record
 * equivalence, behavioral/evidentiary equivalence - this is the first).
 *
 * Compares the column set of a table across two database connections after
 * both have run the same migrations. Deliberately does not compare column
 * TYPES byte-for-byte - a `bigint` in one engine and an `integer` in another
 * can be the same semantic column, and this codebase's own migrations
 * already declare the semantic type (`$table->boolean(...)`,
 * `$table->foreignId(...)`) rather than an engine-specific one. What must
 * never differ is which COLUMNS exist - a migration that silently drops or
 * renames a column on one engine and not another is exactly the "data-correct
 * but evidentiary-meaning-changed" failure Codex named.
 */
final class StructuralPortabilityCheck
{
    /** @return array{missing_here: list<string>, missing_there: list<string>, matches: bool} */
    public static function compareColumns(string $connectionA, string $connectionB, string $table): array
    {
        $columnsA = self::columnsOf($connectionA, $table);
        $columnsB = self::columnsOf($connectionB, $table);

        $missingHere = array_values(array_diff($columnsB, $columnsA));
        $missingThere = array_values(array_diff($columnsA, $columnsB));

        return [
            'missing_here' => $missingHere,
            'missing_there' => $missingThere,
            'matches' => $missingHere === [] && $missingThere === [],
        ];
    }

    /** @return list<string> */
    private static function columnsOf(string $connection, string $table): array
    {
        $driver = DB::connection($connection)->getDriverName();

        $columns = $driver === 'sqlite'
            ? array_map(fn ($r) => $r->name, DB::connection($connection)->select("PRAGMA table_info({$table})"))
            : array_map(fn ($r) => $r->column_name, DB::connection($connection)->select(
                'select column_name from information_schema.columns where table_name = ?', [$table]
            ));

        sort($columns);

        return $columns;
    }
}
