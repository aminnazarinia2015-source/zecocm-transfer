<?php

namespace App\Domain\Ops;

use Illuminate\Support\Facades\DB;

/**
 * OPS-14, Codex's ruling: "Do not trust environment/config values. Query the
 * live connection." C1 was closed by setting `journal_mode=WAL` and
 * `busy_timeout` in config/database.php - but a config value is only a
 * request to the driver, not proof the running connection honored it. This
 * reads the PRAGMAs back from the live SQLite connection on every poll (not
 * only at deploy time, the way the original C1 fix was verified) and fails
 * /up if the connection actually in use disagrees with what deployment
 * intended.
 *
 * A non-SQLite connection (a future Postgres/MySQL cutover, per DATA-3)
 * has no such PRAGMAs to misreport, so this check is a no-op for any other
 * driver rather than a false failure.
 *
 * `journal_mode` is skipped (never asserted, never a failure) specifically
 * when the connection's database is `:memory:` - SQLite itself forces
 * `journal_mode=memory` for an in-memory database no matter what is
 * requested, which is exactly the test suite's own connection, not a
 * production configuration. Asserting WAL against `:memory:` would be
 * asserting something SQLite cannot do, not verifying anything real.
 * `busy_timeout` has no such restriction and is always checked.
 */
final class SqlitePragmaHealthCheck
{
    /**
     * Registered on `DiagnosingHealth`, which invokes this with the event
     * object as its first argument - accepted and ignored here so the
     * listener signature stays compatible, with the actual check delegated
     * to `check()`, which takes an explicit (optional) connection name
     * instead so tests can point it at a real file-backed connection.
     */
    public function handle(mixed $event = null): void
    {
        $this->check();
    }

    public function check(?string $connectionName = null): void
    {
        $connection = DB::connection($connectionName);

        if ($connection->getDriverName() !== 'sqlite') {
            return;
        }

        $expectedBusyTimeout = (int) config('zecocm_ops.sqlite_pragmas.expected_busy_timeout');

        $isInMemory = in_array($connection->getDatabaseName(), ['', ':memory:'], true);

        if (! $isInMemory) {
            $expectedJournalMode = mb_strtolower((string) config('zecocm_ops.sqlite_pragmas.expected_journal_mode'));
            $journalModeRow = $connection->select('PRAGMA journal_mode');
            $actualJournalMode = mb_strtolower((string) ($journalModeRow[0]->journal_mode ?? ''));

            if ($actualJournalMode !== $expectedJournalMode) {
                throw new \RuntimeException(
                    "SQLite journal_mode on the live connection is '{$actualJournalMode}', expected '{$expectedJournalMode}'."
                );
            }
        }

        $busyTimeoutRow = $connection->select('PRAGMA busy_timeout');
        $actualBusyTimeout = (int) ($busyTimeoutRow[0]->timeout ?? -1);

        if ($actualBusyTimeout !== $expectedBusyTimeout) {
            throw new \RuntimeException(
                "SQLite busy_timeout on the live connection is {$actualBusyTimeout}ms, expected {$expectedBusyTimeout}ms."
            );
        }
    }
}
