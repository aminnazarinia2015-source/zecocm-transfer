<?php

namespace App\Domain\Ops;

use Illuminate\Support\Facades\Log;

/**
 * OPS-14: evidence-volume free space. Reuses `StorageInventory::report()`
 * (DATA-1) to find the configured disk root rather than hardcoding a path
 * a second time. Per Codex's ruling, only the hard minimum fails /up -
 * dropping below the warning threshold is logged for alerting but must not
 * make the application unreachable while there is still real room left.
 *
 * Codex's review caught a real false-green path in the first version: a
 * blank, unconfigured, unmounted, or typoed root silently RETURNED healthy,
 * on the theory that a fresh install's evidence directory might not exist
 * yet. That is exactly backwards - if the disk holding governed evidence is
 * not there, that is precisely when this check must fail, not opt out.
 * There is no separate "fresh install" state this check can distinguish
 * from "the real production root vanished"; it does not try to.
 */
final class EvidenceStorageHealthCheck
{
    public function handle(): void
    {
        $root = StorageInventory::report()['root'];

        if ($root === '') {
            throw new \RuntimeException('Evidence storage root is not configured.');
        }

        if (! is_dir($root)) {
            throw new \RuntimeException('Evidence storage root is unavailable (missing, unmounted, or misconfigured).');
        }

        $free = @disk_free_space($root);
        if ($free === false) {
            throw new \RuntimeException('Evidence storage free space could not be determined for the configured root.');
        }

        $hardMinimum = (int) config('zecocm_ops.evidence_storage.min_free_bytes');
        $warningThreshold = (int) config('zecocm_ops.evidence_storage.warning_free_bytes');

        // Codex's secondary hardening: a reversed configuration (warning
        // below hard minimum) would create nonsensical semantics - not a
        // storage failure, but a config error worth failing loudly on
        // rather than silently misbehaving.
        if ($warningThreshold < $hardMinimum) {
            throw new \RuntimeException(
                'Evidence storage warning threshold is configured below the hard minimum - fix zecocm_ops.evidence_storage config.'
            );
        }

        if ($free < $hardMinimum) {
            Log::critical('ops14.evidence_storage: below hard minimum free space', [
                'free_bytes' => $free, 'hard_minimum_bytes' => $hardMinimum, 'root' => $root,
            ]);

            throw new \RuntimeException('Evidence storage free space is below the configured hard minimum.');
        }

        if ($free < $warningThreshold) {
            Log::warning('ops14.evidence_storage: below warning threshold free space', [
                'free_bytes' => $free, 'warning_threshold_bytes' => $warningThreshold, 'root' => $root,
            ]);
        }
    }
}
