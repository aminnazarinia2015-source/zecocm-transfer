<?php

namespace App\Domain\Ops;

use Illuminate\Support\Facades\DB;

/**
 * DATA-3. Copies rows from one database connection to another, unchanged.
 *
 * Codex's own ruling on this row is the whole spec: "Database migration must
 * never require re-sealing or rehashing a record merely because its storage
 * engine changed." This class is transportation, not historical cleanup - it
 * never recomputes a hash, never normalises text, never "fixes" a null/empty
 * distinction, never reorders anything the application itself did not order.
 * If the source contains an inconsistency, this class preserves it and moves
 * on; it does not repair it.
 *
 * The one place engine differences are deliberately absorbed rather than
 * passed through raw is the boolean representation: SQLite has no native
 * boolean type and stores 0/1 integers for a column PostgreSQL declares as
 * `boolean`, which rejects an integer literal outright. This class asks the
 * DESTINATION engine, via its own catalog (`information_schema`), which
 * columns are actually boolean, and casts only those - everything else moves
 * through byte-for-byte as a string, integer, or JSON-encoded text exactly as
 * the source engine returned it.
 */
final class CrossEnginePortability
{
    /**
     * Copies every row of one table from $fromConnection to $toConnection, in
     * primary-key order (never re-derived, never re-sorted by any other
     * column - the source's own row order is preserved as the copy order).
     *
     * @return int rows copied
     */
    public static function copyTable(string $fromConnection, string $toConnection, string $table, string $orderColumn = 'id'): int
    {
        $rows = DB::connection($fromConnection)->table($table)->orderBy($orderColumn)->get();
        if ($rows->isEmpty()) {
            return 0;
        }

        $booleanColumns = self::booleanColumnsOf($toConnection, $table);

        $payload = $rows->map(function ($row) use ($booleanColumns) {
            $record = (array) $row;
            foreach ($booleanColumns as $column) {
                if (array_key_exists($column, $record) && $record[$column] !== null) {
                    // The ONLY normalisation this class performs, and only
                    // because the destination's own schema says the column
                    // IS a boolean - never a guess based on the value 0/1
                    // happening to look boolean-shaped.
                    $record[$column] = (bool) $record[$column];
                }
            }

            return $record;
        })->all();

        DB::connection($toConnection)->table($table)->insert($payload);

        return count($payload);
    }

    /** @return list<string> */
    private static function booleanColumnsOf(string $connection, string $table): array
    {
        $driver = DB::connection($connection)->getDriverName();

        if ($driver !== 'pgsql') {
            // Only PostgreSQL, among the drivers this codebase supports, has
            // no room to accept a 0/1 integer into a typed boolean column.
            // SQLite and MySQL both accept it, so there is nothing to absorb.
            return [];
        }

        $rows = DB::connection($connection)->select(
            'select column_name from information_schema.columns where table_name = ? and data_type = ?',
            [$table, 'boolean']
        );

        return array_map(fn ($r) => $r->column_name, $rows);
    }

    /**
     * Every real, user-data table this application writes to - the migration
     * bookkeeping tables (`migrations`, `password_reset_tokens`, sessions,
     * cache, jobs/failed_jobs) are deliberately excluded, since they carry no
     * evidentiary weight and are not part of what this row certifies.
     *
     * @return list<string>
     */
    public static function evidentiaryTables(string $connection): array
    {
        $driver = DB::connection($connection)->getDriverName();

        $all = $driver === 'sqlite'
            ? array_map(fn ($r) => $r->name, DB::connection($connection)->select("select name from sqlite_master where type = 'table'"))
            : array_map(fn ($r) => $r->table_name, DB::connection($connection)->select("select table_name from information_schema.tables where table_schema = 'public'"));

        $excluded = ['migrations', 'password_reset_tokens', 'sessions', 'cache', 'cache_locks',
            'jobs', 'job_batches', 'failed_jobs', 'sqlite_sequence', 'personal_access_tokens'];

        return array_values(array_diff($all, $excluded));
    }
}
