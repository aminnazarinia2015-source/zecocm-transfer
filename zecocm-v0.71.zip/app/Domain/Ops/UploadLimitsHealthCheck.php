<?php

namespace App\Domain\Ops;

/**
 * OPS-17: `/up` must fail if PHP's own upload limits are smaller than what
 * the app's own validation rules and nginx already promise - found during a
 * real-world audit that uploaded a real 5MB test photo and hit a bare,
 * unhelpful "The file failed to upload" 422 with no indication why.
 *
 * The layers involved do not agree, and nothing catches the disagreement:
 *   - nginx (deploy/nginx.conf) allows up to 400MB per request
 *     (client_max_body_size).
 *   - Laravel's own validation rules allow up to 100MB for a document/media
 *     upload (DocumentLibraryController, MediaController: `max:102400`) and
 *     25MB for a schedule import (config('schedule.max_upload_kilobytes')).
 *   - PHP's stock defaults - upload_max_filesize=2M, post_max_size=8M - are
 *     never raised anywhere in this app's own deploy tooling. Nothing in
 *     bootstrap.sh, the RUNBOOK, or any shipped php.ini touches them.
 * PHP enforces its own limit BEFORE Laravel's validation ever runs, so the
 * smallest number silently wins: any real construction PDF or a modern
 * phone's jobsite photo (routinely 3-15MB) over 2MB fails, and the error
 * the user sees names no size, no limit, and no cause - "The file failed to
 * upload." A field user reporting "uploads don't work" with no further
 * detail is the visible symptom of exactly this gap.
 *
 * This check reads PHP's live `ini_get()` values (not `.env`, not
 * `php.ini` on disk - the actual running configuration for this process)
 * and fails loudly if either is below what the app's own upload paths
 * require, the same fail-loudly-not-silently pattern as
 * EvidenceStorageHealthCheck (OPS-14) and MalwareScannerHealthCheck
 * (OPS-16).
 *
 * Raised from 100MB to 750MB after Amin flagged that real project drawing sets routinely run
 * 300-500MB - the prior ceiling rejected exactly the files the Document Library exists to hold.
 */
final class UploadLimitsHealthCheck
{
    // Must track DocumentLibraryController's own `'file' => '...|max:768000'` validation rule
    // (768000 KB = 750MB) - the largest single-file upload this app's own code claims to accept.
    private const REQUIRED_UPLOAD_MAX_BYTES = 750 * 1024 * 1024;

    // Multipart overhead (headers, other form fields, boundary strings) on
    // top of the largest file the request can carry.
    private const REQUIRED_POST_MAX_BYTES = 760 * 1024 * 1024;

    public function handle(): void
    {
        $uploadMax = $this->iniBytes('upload_max_filesize');
        $postMax = $this->iniBytes('post_max_size');

        if ($uploadMax < self::REQUIRED_UPLOAD_MAX_BYTES) {
            throw new \RuntimeException(sprintf(
                "PHP upload_max_filesize is %s, below the %s this app's own upload endpoints allow - ".
                'every larger file will fail with a generic error before Laravel validation ever runs. '.
                'Set it in a php.ini/conf.d drop-in for the running SAPI (see deploy/bootstrap.sh) and reload php-fpm.',
                $this->humanBytes($uploadMax), $this->humanBytes(self::REQUIRED_UPLOAD_MAX_BYTES)
            ));
        }

        if ($postMax < self::REQUIRED_POST_MAX_BYTES) {
            throw new \RuntimeException(sprintf(
                "PHP post_max_size is %s, below the %s a request carrying the largest allowed file plus form ".
                'overhead needs - the request itself will be truncated or rejected before upload_max_filesize is '.
                'even checked. Set it in a php.ini/conf.d drop-in for the running SAPI and reload php-fpm.',
                $this->humanBytes($postMax), $this->humanBytes(self::REQUIRED_POST_MAX_BYTES)
            ));
        }
    }

    /** Parses PHP's own shorthand ini notation (e.g. "2M", "8M", "1G") into bytes. */
    private function iniBytes(string $key): int
    {
        $raw = trim((string) ini_get($key));
        if ($raw === '' || $raw === '0') {
            // '0' means "no limit" for these two directives specifically -
            // never a failure state for this check.
            return PHP_INT_MAX;
        }

        $unit = strtoupper(substr($raw, -1));
        $number = (float) $raw;

        return (int) match ($unit) {
            'G' => $number * 1024 * 1024 * 1024,
            'M' => $number * 1024 * 1024,
            'K' => $number * 1024,
            default => $number,
        };
    }

    private function humanBytes(int $bytes): string
    {
        if ($bytes >= PHP_INT_MAX) {
            return 'unlimited';
        }

        return round($bytes / (1024 * 1024)).'M';
    }
}
