<?php

namespace App\Domain\Ops;

use App\Models\PlatformSecret;
use Illuminate\Support\Facades\Crypt;

/**
 * The allow-listed, admin-settable secrets an operator can change from inside
 * the app, instead of editing .env by hand and re-running config:cache.
 *
 * Read at request time (never baked into bootstrap/cache/config.php), so a
 * key set here takes effect on the very next request - no config:clear,
 * no config:cache, no restart. That gap (a correct .env value that did
 * nothing until the cache was rebuilt) is exactly what made the
 * ANTHROPIC_API_KEY incident on 2026-08-27 look like the key "wasn't
 * really there" when it was.
 *
 * Deliberately small: only a name, a human label, and which config path it
 * shadows. Adding a new manageable secret is one array entry here plus
 * (optionally) wiring the resolved value in wherever that config key is
 * consumed - see AiServiceProvider for the first example.
 */
final class PlatformSecretStore
{
    /** @return array<string,array{label:string,hint:string}> */
    public static function known(): array
    {
        return [
            'ANTHROPIC_API_KEY' => [
                'label' => 'Anthropic API key',
                'hint' => 'Powers TRACE\'s paid, project-grounded answers (ai.assist). Free help answers do not need this.',
            ],
            'AUTODESK_CLIENT_SECRET' => [
                'label' => 'Autodesk OAuth client secret',
                'hint' => 'Required only after the Autodesk application and callback URL are approved. Never paste a customer access token here.',
            ],
            'PROCORE_CLIENT_SECRET' => [
                'label' => 'Procore OAuth client secret',
                'hint' => 'Required only after the Procore application is registered. Customer tokens are stored per connection, encrypted and separately revocable.',
            ],
            'BLUEBEAM_CLIENT_SECRET' => [
                'label' => 'Bluebeam OAuth client secret',
                'hint' => 'Use only credentials issued for an approved Bluebeam API/partner application.',
            ],
            'MICROSOFT365_CLIENT_SECRET' => [
                'label' => 'Microsoft 365 application secret',
                'hint' => 'Entra application credential. Prefer short-lived credentials or certificate authentication when the production connector is implemented.',
            ],
        ];
    }

    /** @return array<string,string> */
    public static function fallbacks(): array
    {
        return [
            'ANTHROPIC_API_KEY' => (string) config('zecocm_ai.api_key', ''),
            'AUTODESK_CLIENT_SECRET' => (string) config('integrations.autodesk.client_secret', ''),
            'PROCORE_CLIENT_SECRET' => (string) config('integrations.procore.client_secret', ''),
            'BLUEBEAM_CLIENT_SECRET' => (string) config('integrations.bluebeam.client_secret', ''),
            'MICROSOFT365_CLIENT_SECRET' => (string) config('integrations.microsoft365.client_secret', ''),
        ];
    }

    public static function isKnown(string $key): bool
    {
        return array_key_exists($key, self::known());
    }

    /**
     * The value to actually use: the database override if an admin has set
     * one, otherwise the given fallback (normally an env()-sourced config
     * value, so behavior is unchanged until someone sets an override here).
     */
    public static function resolve(string $key, string $fallback): string
    {
        $row = PlatformSecret::where('key', $key)->first();
        if (! $row) {
            return $fallback;
        }

        try {
            return (string) Crypt::decryptString($row->ciphertext);
        } catch (\Throwable $e) {
            // A corrupted ciphertext (e.g. APP_KEY rotated without
            // re-encrypting) must never crash a request - fall back rather
            // than 500 every page that resolves this key.
            report($e);

            return $fallback;
        }
    }

    public static function set(string $key, string $value, ?int $updatedByUserId): void
    {
        PlatformSecret::updateOrCreate(
            ['key' => $key],
            ['ciphertext' => Crypt::encryptString($value), 'updated_by_user_id' => $updatedByUserId]
        );
    }

    /**
     * Status for the settings screen: never the value itself. Length and
     * last 4 characters are enough for an admin to confirm "yes, that's the
     * key I just pasted" without the value ever round-tripping to the
     * browser - the same proof-without-exposure shape as verify-live.sh's
     * KEY IS SET, length=108 check.
     */
    public static function status(string $key, string $envFallback): array
    {
        $row = PlatformSecret::where('key', $key)->first();
        $value = self::resolve($key, $envFallback);

        return [
            'source' => $row ? 'database' : ($envFallback !== '' ? 'env_file' : 'none'),
            'configured' => $value !== '',
            'length' => strlen($value),
            'last4' => $value !== '' ? substr($value, -4) : null,
            'updated_at' => $row?->updated_at,
        ];
    }
}
