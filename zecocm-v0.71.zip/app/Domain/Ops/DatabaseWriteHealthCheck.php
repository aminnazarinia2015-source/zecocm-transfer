<?php

namespace App\Domain\Ops;

use Illuminate\Support\Facades\DB;

/**
 * OPS-15: `/up`'s dependency-aware health check, per Codex's explicit ruling
 * on this row - deployment verification must probe `/up`, `/up` itself must
 * verify the dependencies required for a meaningful healthy state, and a
 * failing dependency must make `/up` fail. Codex rejected this session's own
 * draft proposal of a second, separate `/health` endpoint: dependency
 * checking belongs ON `/up`, not beside it.
 *
 * Registered as a listener on Laravel's own `DiagnosingHealth` event (see
 * `AppServiceProvider::boot()`), which is the framework's built-in extension
 * point for exactly this: `/up` dispatches it before responding, and an
 * uncaught exception from any listener turns the response into a 500 (in
 * production - `report()`ed, never re-thrown to the client) with no code of
 * our own required in the route itself.
 *
 * WHY A WRITE, NOT A READ: `SELECT 1` proves the database is reachable, not
 * that it is usable. C1's whole history was a WRITE-lock pathology
 * (concurrent SQLite writers contending for the same connection) that a
 * read-only probe cannot see. This upserts a single row - `health_probes` id
 * 1 - and reads it back inside the same transaction, so a probe that
 * "succeeds" actually proves a write reached disk and was visible again
 * immediately after, the same round trip a real request performs.
 *
 * WHY NO CUSTOM TIMEOUT MACHINERY: this is a plain PDO call, not a shelled-
 * out process (`BoundedProcess`'s reason for existing), and this
 * installation's `busy_timeout` PRAGMA - closed under C1 and asserted live
 * at every deploy - already bounds how long a contended write can block
 * before SQLite itself gives up and throws. Reusing that existing bound
 * rather than inventing a second one keeps this check as narrow as the row
 * calls for.
 *
 * The exception message deliberately names nothing about the failure's
 * cause (no query text, no path, no connection string) - Laravel's own
 * `/up` route never renders the message to the client (see
 * `health-up.blade.php`: it renders only a boolean "up"/"experiencing
 * problems"), but it is `report()`ed to the application log, where a
 * generic message is the correct amount of detail for an operator to start
 * from without this becoming a second place secrets could leak.
 */
final class DatabaseWriteHealthCheck
{
    public function handle(): void
    {
        try {
            DB::transaction(function () {
                DB::table('health_probes')->updateOrInsert(['id' => 1], ['probed_at' => now()]);
                $row = DB::table('health_probes')->where('id', 1)->first();

                if ($row === null || $row->probed_at === null) {
                    throw new \RuntimeException('Health probe row was not readable immediately after being written.');
                }
            });
        } catch (\Throwable $e) {
            throw new \RuntimeException(
                'Database health probe failed: could not write and read back a heartbeat row.', previous: $e,
            );
        }
    }
}
