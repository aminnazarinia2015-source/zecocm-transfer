<?php

namespace App\Domain\Ops;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * OPS-14: age of the oldest RUNNABLE pending job. Per Codex's ruling this is
 * a configured SLO (`queue_backlog.max_pending_age_seconds`), not an
 * arbitrary absolute count - a backlog is only a health failure once it is
 * old enough that whatever depends on that job being processed has actually
 * been waiting too long.
 *
 * Codex's review caught a real bug in the first version: `diffInSeconds()`
 * defaults to an ABSOLUTE value, and the query had no floor on
 * `available_at`. A job intentionally delayed until tomorrow
 * (`available_at` in the future) would have its distance from now measured
 * as a large positive number either way - reporting it as an ancient
 * backlog item instead of correctly recognizing it is not due yet. This
 * version only considers jobs whose `available_at` has already passed -
 * "is there RUNNABLE work that has waited too long", not "is there any old
 * row in the table."
 *
 * Separately: a job a worker picked up (`reserved_at` set) but never
 * finished - a crashed or wedged worker mid-job, distinct from nothing
 * consuming the queue at all - is not something this check can safely fail
 * /up over (Laravel's own `retry_after` already governs when such a
 * reservation is released back to the pool, and duplicating that logic
 * here risks fighting it). It is logged as a warning instead, so it is at
 * least "detectable somewhere" per Codex's phrasing, without inventing a
 * second execution-timeout policy.
 */
final class QueueBacklogHealthCheck
{
    public function handle(): void
    {
        $now = now();

        $oldest = DB::table('jobs')
            ->whereNull('reserved_at')
            ->where('available_at', '<=', $now->timestamp)
            ->orderBy('available_at')
            ->first();

        if ($oldest !== null) {
            $availableAt = Carbon::createFromTimestamp((int) $oldest->available_at);
            $ageSeconds = $availableAt->diffInSeconds($now, absolute: true);
            $maxAge = (int) config('zecocm_ops.queue_backlog.max_pending_age_seconds', 600);

            if ($ageSeconds > $maxAge) {
                Log::critical('ops14.queue_backlog: oldest runnable pending job exceeds max age', [
                    'age_seconds' => $ageSeconds, 'max_age_seconds' => $maxAge, 'queue' => $oldest->queue,
                ]);

                throw new \RuntimeException(
                    "The oldest runnable pending job has been waiting {$ageSeconds}s, past the configured maximum of {$maxAge}s."
                );
            }
        }

        $this->warnOnStuckReservations($now);
    }

    /**
     * Log-only: a job reserved well past this connection's own `retry_after`
     * (Laravel's built-in threshold for releasing a reservation back to the
     * pool) suggests a worker died or hung mid-job without that release
     * happening as expected. Never throws - this is a signal to look at,
     * not a distinct health contract this check owns.
     */
    private function warnOnStuckReservations(Carbon $now): void
    {
        $retryAfter = (int) config('queue.connections.'.config('queue.default').'.retry_after', 90);
        $graceMultiplier = 2;

        $stuck = DB::table('jobs')
            ->whereNotNull('reserved_at')
            ->where('reserved_at', '<=', $now->copy()->subSeconds($retryAfter * $graceMultiplier)->timestamp)
            ->orderBy('reserved_at')
            ->first();

        if ($stuck !== null) {
            $reservedAgeSeconds = Carbon::createFromTimestamp((int) $stuck->reserved_at)->diffInSeconds($now, absolute: true);

            Log::warning('ops14.queue_backlog: a job reservation is far older than this connection\'s retry_after', [
                'reserved_age_seconds' => $reservedAgeSeconds, 'retry_after_seconds' => $retryAfter, 'queue' => $stuck->queue,
            ]);
        }
    }
}
