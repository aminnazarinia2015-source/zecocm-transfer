<?php

namespace App\Domain\Ops;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * OPS-14: catches the failure mode C5 showed us `systemctl is-active` cannot
 * see - a worker process that is running but wedged on a poisoned job, or
 * listening to the wrong queue entirely, or unable to reach the database
 * queue driver. `DispatchQueueHeartbeat` (scheduled every
 * `queue_heartbeat.interval_seconds`) inserts a fresh `queue_heartbeats` row
 * and dispatches `StampQueueHeartbeat` carrying that row's token onto the
 * real production queue; this check asks whether the most recent dispatch
 * was actually completed, recently.
 *
 * Codex's review of the first version caught a real gap: checking only the
 * age of the most recent DISPATCH cannot distinguish "the scheduler stopped
 * dispatching" from "the worker stopped consuming" - a heartbeat dispatched
 * 20 seconds ago and still unhandled would pass under a single age check,
 * even though a healthy worker consumes within seconds, not minutes. This
 * version evaluates the two paths independently, each with its own reason
 * code:
 *
 *  - QUEUE_HEARTBEAT_MISSING: no row exists at all. `deploy/verify-live.sh`
 *    now calls `ops:dispatch-queue-heartbeat` once, synchronously, before
 *    curling /up - specifically so a fresh deploy always has a row to
 *    evaluate rather than this state being reachable only by a genuinely
 *    broken scheduler.
 *  - QUEUE_DISPATCH_STALE: the scheduler itself appears to have stopped -
 *    no dispatch has landed within `dispatch_stale_seconds` (default 180s,
 *    ~3x the schedule interval so a brief deploy restart never trips it).
 *  - QUEUE_HEARTBEAT_UNHANDLED: a dispatch exists and is recent enough that
 *    the scheduler is clearly still running, but it has sat unhandled past
 *    `handling_grace_seconds` (default 45s - generous next to the
 *    near-instant consumption a healthy worker actually does, but nowhere
 *    near the full dispatch-stale window). This is the case the first
 *    version missed.
 *  - QUEUE_HEARTBEAT_INCONSISTENT: `handled_at` earlier than `dispatched_at`
 *    - not reachable through this table's own writers, but worth failing
 *    loudly on rather than silently trusting corrupted data.
 *
 * Handling latency (handled_at - dispatched_at) beyond
 * `handling_latency_warning_seconds` only logs a warning - a briefly slow
 * worker under load is an alertable signal, not a reason to fail /up.
 */
final class QueueHeartbeatHealthCheck
{
    public function handle(): void
    {
        $latest = DB::table('queue_heartbeats')->orderByDesc('dispatched_at')->orderByDesc('id')->first();

        if ($latest === null) {
            Log::critical('ops14.queue_heartbeat: QUEUE_HEARTBEAT_MISSING - no heartbeat row exists at all');

            throw new \RuntimeException(
                'QUEUE_HEARTBEAT_MISSING: no queue heartbeat has ever been recorded - the scheduler may never have run.'
            );
        }

        $dispatchedAt = Carbon::parse($latest->dispatched_at);
        $dispatchAgeSeconds = $dispatchedAt->diffInSeconds(now(), absolute: true);

        $dispatchStaleSeconds = (int) config('zecocm_ops.queue_heartbeat.dispatch_stale_seconds', 180);
        $handlingGraceSeconds = (int) config('zecocm_ops.queue_heartbeat.handling_grace_seconds', 45);
        $warningSeconds = (int) config('zecocm_ops.queue_heartbeat.warning_seconds', 20);
        $handlingLatencyWarningSeconds = (int) config('zecocm_ops.queue_heartbeat.handling_latency_warning_seconds', 10);

        if ($dispatchAgeSeconds > $dispatchStaleSeconds) {
            Log::critical('ops14.queue_heartbeat: QUEUE_DISPATCH_STALE', [
                'dispatch_age_seconds' => $dispatchAgeSeconds, 'dispatch_stale_seconds' => $dispatchStaleSeconds,
            ]);

            throw new \RuntimeException(
                'QUEUE_DISPATCH_STALE: no new heartbeat has been dispatched recently - the scheduler may be stopped.'
            );
        }

        if ($latest->handled_at === null) {
            if ($dispatchAgeSeconds > $handlingGraceSeconds) {
                Log::critical('ops14.queue_heartbeat: QUEUE_HEARTBEAT_UNHANDLED', [
                    'dispatch_age_seconds' => $dispatchAgeSeconds, 'handling_grace_seconds' => $handlingGraceSeconds,
                ]);

                throw new \RuntimeException(
                    'QUEUE_HEARTBEAT_UNHANDLED: the most recent heartbeat dispatch has not been handled within the worker grace period - the worker may be stopped, wedged, or listening to the wrong queue.'
                );
            }

            if ($dispatchAgeSeconds > $warningSeconds) {
                Log::warning('ops14.queue_heartbeat: unhandled beyond warning threshold, still within grace', [
                    'dispatch_age_seconds' => $dispatchAgeSeconds, 'warning_seconds' => $warningSeconds,
                ]);
            }

            return;
        }

        $handledAt = Carbon::parse($latest->handled_at);

        if ($handledAt->lt($dispatchedAt)) {
            Log::critical('ops14.queue_heartbeat: QUEUE_HEARTBEAT_INCONSISTENT', [
                'dispatched_at' => (string) $dispatchedAt, 'handled_at' => (string) $handledAt,
            ]);

            throw new \RuntimeException(
                'QUEUE_HEARTBEAT_INCONSISTENT: the most recent heartbeat was recorded as handled before it was dispatched.'
            );
        }

        $handlingLatencySeconds = $dispatchedAt->diffInSeconds($handledAt, absolute: true);

        if ($handlingLatencySeconds > $handlingLatencyWarningSeconds) {
            Log::warning('ops14.queue_heartbeat: handling latency above warning threshold', [
                'handling_latency_seconds' => $handlingLatencySeconds, 'threshold_seconds' => $handlingLatencyWarningSeconds,
            ]);
        }
    }
}
