<?php

namespace App\Domain\Ops;

/**
 * DATA-1. Moves the bytes under an existing evidence root to a new root
 * without ever changing what a file hashes to - the one property every
 * digest already sealed against those bytes (EV-13, EV-12, media provenance)
 * depends on continuing to hold after the move. This is a one-time
 * relocation tool, not an ongoing storage layer: once EVIDENCE_STORAGE_ROOT
 * is pointed at the new root in config, the application read/writes there
 * directly through the existing `local` disk - this class only handles
 * carrying forward whatever was already on disk under the old root.
 *
 * Fails closed per file, not per run: a single file whose destination copy
 * does not rehash to the same digest is left untouched at the source and
 * reported, and the run keeps going rather than aborting or (worse) deleting
 * a source file it could not actually verify was faithfully copied.
 */
final class EvidenceRelocation
{
    /**
     * @return array{copied: list<string>, verified: list<string>, mismatched: list<string>, deleted_source: list<string>, skipped_existing: list<string>}
     */
    public static function run(string $from, string $to, bool $deleteSourceOnVerify): array
    {
        $result = [
            'copied' => [],
            'verified' => [],
            'mismatched' => [],
            'deleted_source' => [],
            'skipped_existing' => [],
        ];

        $from = rtrim($from, '/');
        $to = rtrim($to, '/');

        if (! is_dir($from)) {
            return $result;
        }

        foreach (self::walk($from) as $sourcePath) {
            $relative = ltrim(substr($sourcePath, strlen($from)), '/');
            $destPath = $to.'/'.$relative;

            if (is_file($destPath)) {
                // Already relocated in a prior run - never overwrite an
                // existing destination file, and never re-derive a
                // verification result for it from this pass.
                $result['skipped_existing'][] = $relative;

                continue;
            }

            $sourceHash = hash_file('sha256', $sourcePath);
            if ($sourceHash === false) {
                $result['mismatched'][] = $relative;

                continue;
            }

            @mkdir(dirname($destPath), 0755, true);
            if (! @copy($sourcePath, $destPath)) {
                $result['mismatched'][] = $relative;

                continue;
            }
            $result['copied'][] = $relative;

            $destHash = hash_file('sha256', $destPath);
            if ($destHash !== $sourceHash) {
                // The copy exists but does not verify - never delete the
                // source for this file, and never leave a caller thinking
                // this file relocated cleanly.
                $result['mismatched'][] = $relative;

                continue;
            }
            $result['verified'][] = $relative;

            if ($deleteSourceOnVerify) {
                @unlink($sourcePath);
                $result['deleted_source'][] = $relative;
            }
        }

        return $result;
    }

    /**
     * @return \Generator<string>
     */
    private static function walk(string $dir): \Generator
    {
        $items = @scandir($dir);
        if ($items === false) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir.'/'.$item;
            if (is_dir($path)) {
                yield from self::walk($path);
            } elseif (is_file($path)) {
                yield $path;
            }
        }
    }
}
