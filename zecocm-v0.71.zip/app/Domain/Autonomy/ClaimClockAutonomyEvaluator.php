<?php

namespace App\Domain\Autonomy;

use App\Domain\Claims\ClaimClock;
use App\Models\AutonomousAction;
use App\Models\ClaimRequirement;
use App\Models\ProjectTask;

/**
 * AUTO-2's first seeded action: "an approaching claim/notice deadline/clock
 * -> create a task/reminder." Listed as an AUTO-tier example in Codex's
 * ruling ("create reminders" - no external legal effect).
 *
 * The triggering condition is entirely ClaimClock's own, pre-existing,
 * deterministic logic (may_alert on an ESTABLISHED calculation with a
 * PRESERVATIVE or ESCALATION consequence) - this class adds no judgment of
 * its own about whether a deadline matters. Idempotency (don't spam a
 * second reminder for the same still-current deadline) is handled by
 * AutonomousActionRecorder's action_key mechanism, not by this class - the
 * calculated deadline_on is passed as state_version, so a recalculated
 * deadline (the trigger date was corrected) legitimately produces a new
 * action rather than being silently swallowed.
 *
 * epistemic_state is always 'resolved' here: ClaimClock::calculate() only
 * reaches ESTABLISHED (the only state with may_alert possibly true on a
 * preservative/escalation consequence) once both the requirement and the
 * trigger are independently confirmed - there is no unresolved-trigger case
 * that reaches this far, so there is nothing for the recorder's uncertainty
 * gate to catch here. It still passes epistemic_state explicitly rather than
 * relying on the recorder's default, so that fact is visible in the code
 * rather than assumed.
 */
final class ClaimClockAutonomyEvaluator
{
    public const ACTION_TYPE = 'claim_clock_reminder';

    public function __construct(
        private readonly AutonomousActionRecorder $recorder = new AutonomousActionRecorder,
    ) {}

    /** @return list<array{requirement_id:int, action: ?AutonomousAction}> */
    public function evaluateProject(int $tenantId, int $projectId): array
    {
        $results = [];

        ClaimRequirement::query()
            ->where('tenant_id', $tenantId)
            ->where('project_id', $projectId)
            ->where('status', 'confirmed')
            ->with('trigger')
            ->each(function (ClaimRequirement $requirement) use (&$results) {
                $result = $this->evaluateRequirement($requirement);
                if ($result !== null) {
                    $results[] = $result;
                }
            });

        return $results;
    }

    /** @return ?array{requirement_id:int, action: ?AutonomousAction} */
    public function evaluateRequirement(ClaimRequirement $requirement): ?array
    {
        $trigger = $requirement->trigger;

        $calculation = ClaimClock::calculate(
            $requirement->only([
                'status', 'period_value', 'period_unit', 'calendar_rule',
                'consequence_class', 'authority_citation', 'title',
            ]),
            $trigger?->only(['status', 'occurred_on', 'earliest_plausible_on', 'latest_plausible_on']),
            // No confirmed-calendar lookup wired up yet for this evaluator -
            // deliberately conservative: a working-day requirement with no
            // calendar here reports UNRESOLVED_CALENDAR (may_alert=false),
            // same as ClaimClock itself would with no calendar confirmed.
            [],
        );

        if (! $calculation['may_alert']) {
            return null;
        }

        $evidence = [
            'claim_requirement_id' => $requirement->id,
            'claim_trigger_event_id' => $trigger?->id,
            'calculation' => $calculation,
        ];

        $action = $this->recorder->record([
            'tenant_id' => $requirement->tenant_id,
            'project_id' => $requirement->project_id,
            'capability' => 'claims',
            'action_type' => self::ACTION_TYPE,
            'trigger_type' => 'claim_clock_may_alert',
            'trigger_record_ids' => array_filter([
                ['type' => 'ClaimRequirement', 'id' => $requirement->id],
                $trigger !== null ? ['type' => 'ClaimTriggerEvent', 'id' => $trigger->id] : null,
            ]),
            'rule_id' => 'ClaimClock::calculate.may_alert',
            'state_version' => (string) ($calculation['deadline_on'] ?? $calculation['latest_on']),
            'epistemic_state' => 'resolved',
            'evidence_used' => $evidence,
            'proposed_change' => [
                'create_task' => [
                    'task_type' => self::ACTION_TYPE,
                    'title' => 'Review approaching deadline: '.$requirement->title,
                    'due_on' => $calculation['deadline_on'] ?? $calculation['latest_on'],
                ],
            ],
            'auto_execute' => function () use ($requirement, $calculation) {
                $task = ProjectTask::create([
                    'tenant_id' => $requirement->tenant_id,
                    'project_id' => $requirement->project_id,
                    'task_type' => self::ACTION_TYPE,
                    'title' => 'Review approaching deadline: '.$requirement->title,
                    'detail' => $calculation['message'],
                    'due_on' => $calculation['deadline_on'] ?? $calculation['latest_on'],
                    'status' => 'open',
                    'subject_type' => ClaimRequirement::class,
                    'subject_id' => $requirement->id,
                ]);

                return ['project_task_id' => $task->id];
            },
        ]);

        if ($action !== null && $action->executed_change !== null) {
            $task = ProjectTask::find($action->executed_change['project_task_id']);
            $task?->update(['autonomous_action_id' => $action->id]);
        }

        return ['requirement_id' => $requirement->id, 'action' => $action];
    }
}
