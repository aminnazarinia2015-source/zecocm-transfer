<?php

namespace App\Domain\Autonomy;

/**
 * AUTO-2's five autonomy tiers, per Codex's ruling, ranked from most to least
 * permissive. `rank()` exists because "effective level = min(project policy,
 * system ceiling)" only means something once the five levels have an order -
 * min() on strings would be alphabetical nonsense.
 *
 * AUTO              - execute now. No external legal effect: calculate
 *                     clocks, create draft shells, roll forward certified
 *                     prior values, run checks, create reminders/tasks.
 * AUTO_NOTIFY       - execute now, but tell a human it happened. Only for
 *                     purely mechanical satisfaction ("file X received and
 *                     hash-valid"), never substantive judgment.
 * APPROVAL_REQUIRED - prepare the change, a human must approve before it
 *                     executes. Sending notices, certifying pay apps,
 *                     financial authorization, etc.
 * HUMAN_ONLY        - the system may prepare analysis, but a human decides
 *                     from scratch. An action record MAY exist (as prepared
 *                     analysis), but nothing is proposed as a ready-to-approve
 *                     change.
 * NOT_AUTOMATABLE   - the system must not even create an action candidate.
 *                     Used where automated framing itself could bias a human
 *                     toward a conclusion (fraud, litigation strategy,
 *                     waiver/forfeiture, contractor termination). Stricter
 *                     than HUMAN_ONLY: HUMAN_ONLY still produces a record;
 *                     this one produces nothing.
 */
final class AutonomyLevel
{
    public const AUTO = 'AUTO';

    public const AUTO_NOTIFY = 'AUTO_NOTIFY';

    public const APPROVAL_REQUIRED = 'APPROVAL_REQUIRED';

    public const HUMAN_ONLY = 'HUMAN_ONLY';

    public const NOT_AUTOMATABLE = 'NOT_AUTOMATABLE';

    /** Most permissive first - index doubles as rank for min()/max() by permissiveness. */
    private const ORDER = [
        self::AUTO,
        self::AUTO_NOTIFY,
        self::APPROVAL_REQUIRED,
        self::HUMAN_ONLY,
        self::NOT_AUTOMATABLE,
    ];

    public static function isValid(string $level): bool
    {
        return in_array($level, self::ORDER, true);
    }

    private static function rank(string $level): int
    {
        $rank = array_search($level, self::ORDER, true);

        if ($rank === false) {
            throw new \InvalidArgumentException("Unknown autonomy level: {$level}");
        }

        return $rank;
    }

    /**
     * The STRICTER (less permissive) of two levels - this is the entire
     * ceiling mechanism. A project policy can only ever narrow toward
     * NOT_AUTOMATABLE from the system ceiling, never loosen past it.
     */
    public static function stricterOf(string $a, string $b): string
    {
        return self::rank($a) >= self::rank($b) ? $a : $b;
    }
}
