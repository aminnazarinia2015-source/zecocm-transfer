<?php

namespace App\Domain\Autonomy;

use App\Models\AutonomousAction;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;

/**
 * AUTO-2's fourth seeded action. Built on Amin's direct product direction
 * (2026-08-26: pay-app chasing "manual or automatic ... up to the customer,"
 * fully traced either way, activate/deactivate at the higher-level customer's
 * discretion) - an explicit override of the standing "wait for PN 851 usage
 * evidence" sequencing, not a usage signal proving itself out. See
 * claude/auto2-pay-app-automation-design-brief.md for the full design
 * question and Codex's ruling on it.
 *
 * Codex narrowed the scope deliberately: "create draft shell from last
 * certified application... organizational work, not financial judgment."
 * This class does exactly that and nothing more. It must never:
 *   - certify or submit anything (status is always created as 'draft');
 *   - invent current-period billing (every this_period_cents starts at 0 -
 *     see createShell());
 *   - carry forward unsupported stored material as newly earned (stored
 *     materials reset to 0 - the new period has stored nothing yet);
 *   - add pending change-order amounts;
 *   - resolve withholding findings.
 * The only figure carried forward is each line's PREVIOUS COMPLETED total
 * (prior previous + prior this-period) - a settled fact about the prior,
 * closed cycle, and the exact carry-forward
 * PayApplicationController::store() already performs for a human-initiated
 * draft (see that method's own comment on why hand-typing this figure is a
 * hard-invalid finding waiting to happen).
 *
 * The triggering condition is deliberately narrow and purely observational,
 * not a guess about a future billing calendar: the most recent pay
 * application for a project has moved PAST draft (certified, submitted,
 * approved, or paid - i.e. that cycle is closed) and no later application
 * already exists. A REJECTED application is excluded on purpose - it needs a
 * human to look at why before another shell is stacked on top of it, not
 * more automation piling onto an application an agency already sent back.
 *
 * period_from/period_to on the created shell are a placeholder 30-day
 * window starting the day after the prior period closed. Choosing a window
 * is not the same as billing it: every line's this_period_cents is 0, the
 * application is a plain draft, and the dates remain as freely editable as
 * on any hand-created draft - nothing about them is asserted anywhere until
 * a human bills against the shell and it is certified.
 *
 * Per the ceiling/policy separation Codex specified: pay_app_draft_rollforward's
 * system ceiling stays AUTO (config/autonomy_action_ceilings.php - this was
 * already true before this class existed), but AutonomyPolicyResolver's
 * existing default-to-APPROVAL_REQUIRED-with-no-policy-row behavior means a
 * project only gets automatic shell creation once someone with
 * project.autonomy.manage explicitly grants it - not by omission. That
 * settings surface is a separate, not-yet-built piece (see the design
 * brief); until it exists, evaluateProject() still runs safely because the
 * recorder itself refuses to auto-execute above APPROVAL_REQUIRED.
 */
final class PayAppRollforwardEvaluator
{
    public const ACTION_TYPE = 'pay_app_draft_rollforward';

    private const CLOSED_STATUSES = ['certified', 'submitted', 'approved', 'paid'];

    public function __construct(
        private readonly AutonomousActionRecorder $recorder = new AutonomousActionRecorder,
    ) {}

    /** @return ?array{action: ?AutonomousAction} */
    public function evaluateProject(int $tenantId, int $projectId): ?array
    {
        $latest = PayApplication::query()
            ->where('tenant_id', $tenantId)
            ->where('project_id', $projectId)
            ->orderByDesc('number')
            ->with('lines')
            ->first();

        if ($latest === null || ! in_array($latest->status, self::CLOSED_STATUSES, true)) {
            // No application to roll forward from yet, or the most recent
            // one is still open (draft) or was rejected - either way there
            // is nothing for this action to do.
            return null;
        }

        $action = $this->recorder->record([
            'tenant_id' => $tenantId,
            'project_id' => $projectId,
            'capability' => 'payment',
            'action_type' => self::ACTION_TYPE,
            'trigger_type' => 'pay_application_cycle_closed',
            'trigger_record_ids' => [['type' => 'PayApplication', 'id' => $latest->id]],
            'rule_id' => 'PayAppRollforwardEvaluator.cycle_closed',
            'state_version' => $latest->status.'|'.$latest->number,
            'epistemic_state' => 'resolved',
            'evidence_used' => [
                'prior_pay_application_id' => $latest->id,
                'prior_number' => $latest->number,
                'prior_status' => $latest->status,
                'prior_period_to' => $latest->period_to?->toDateString(),
            ],
            'proposed_change' => [
                'create_pay_application_draft' => [
                    'number' => $latest->number + 1,
                    'carries_forward_from' => $latest->id,
                ],
            ],
            'auto_execute' => fn () => $this->createShell($latest),
        ]);

        if ($action !== null && $action->executed_change !== null) {
            PayApplication::query()
                ->where('id', $action->executed_change['pay_application_id'])
                ->update(['autonomous_action_id' => $action->id]);
        }

        return ['action' => $action];
    }

    /** @return array{pay_application_id:int, number:int} */
    private function createShell(PayApplication $prior): array
    {
        $periodFrom = ($prior->period_to ?? now())->copy()->addDay();
        $periodTo = $periodFrom->copy()->addDays(29);

        $application = PayApplication::create([
            'tenant_id' => $prior->tenant_id,
            'project_id' => $prior->project_id,
            'number' => $prior->number + 1,
            'period_from' => $periodFrom->toDateString(),
            'period_to' => $periodTo->toDateString(),
            'status' => 'draft',
            'retention_basis_points' => $prior->retention_basis_points,
        ]);

        foreach ($prior->lines as $line) {
            PayApplicationLine::create([
                'tenant_id' => $prior->tenant_id,
                'pay_application_id' => $application->id,
                'schedule_of_value_item_id' => $line->schedule_of_value_item_id,
                'previous_completed_cents' => (int) $line->previous_completed_cents + (int) $line->this_period_cents,
                'this_period_cents' => 0,
                'stored_materials_cents' => 0,
            ]);
        }

        return ['pay_application_id' => $application->id, 'number' => $application->number];
    }
}
