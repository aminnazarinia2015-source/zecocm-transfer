<?php

namespace App\Domain\Autonomy;

use App\Domain\Closeout\CloseoutReadiness;
use App\Models\AutonomousAction;
use App\Models\CloseoutRequirement;
use App\Models\ProjectTask;

/**
 * AUTO-2's third seeded action (second in Codex's stated wiring order):
 * "closeout obligation becomes at-risk -> create deliverable request/task."
 *
 * The triggering condition is entirely `CloseoutReadiness::assess()`'s own,
 * pre-existing, deterministic logic - this class adds no judgment of its own
 * about what counts as at-risk. What this class DOES add, honestly scoped:
 * `assess()` accepts four signals per requirement (unassigned, demobilising
 * partner, high percent-paid, broken lineage, provisional condition), but
 * only the first is computable from data that actually exists on
 * `closeout_requirements`/`closeout_deliverables` today - the other three
 * need a join to subcontract/submittal/schedule state nothing in this
 * codebase assembles yet (confirmed by search: `CloseoutReadiness::assess()`
 * had no caller anywhere before this evaluator). Rather than inventing that
 * join, this evaluator passes only what is real and lets `assess()`'s own
 * "nobody is responsible" / retention-and-payment-blocking signals do the
 * work they can honestly do. The three richer signals are a scoped-out v1
 * gap here, exactly like D4's sheet_title/steward-confirmation gaps - named,
 * not silently missing.
 */
final class CloseoutAutonomyEvaluator
{
    public const ACTION_TYPE = 'closeout_deliverable_request';

    public function __construct(
        private readonly AutonomousActionRecorder $recorder = new AutonomousActionRecorder,
    ) {}

    /** @return list<array{requirement_id:int, action: ?AutonomousAction}> */
    public function evaluateProject(int $tenantId, int $projectId): array
    {
        $results = [];

        CloseoutRequirement::query()
            ->where('tenant_id', $tenantId)
            ->where('project_id', $projectId)
            ->with('deliverable')
            ->each(function (CloseoutRequirement $requirement) use (&$results) {
                $result = $this->evaluateRequirement($requirement);
                if ($result !== null) {
                    $results[] = $result;
                }
            });

        return $results;
    }

    /** @return ?array{requirement_id:int, action: ?AutonomousAction} */
    public function evaluateRequirement(CloseoutRequirement $requirement): ?array
    {
        $deliverable = $requirement->deliverable;

        $assessment = CloseoutReadiness::assess([[
            'title' => $requirement->title,
            'deliverable_type' => $requirement->deliverable_type,
            'state' => $deliverable?->state ?? CloseoutReadiness::REQUIRED,
            'responsible_party' => $requirement->responsible_party,
            'blocks_final_payment' => (bool) $requirement->blocks_final_payment,
            'blocks_retention_release' => (bool) $requirement->blocks_retention_release,
            // partner_demobilising / partner_percent_paid / lineage_gap /
            // provisional_condition deliberately omitted - see class doc.
        ]]);

        if ($assessment['at_risk'] === 0) {
            return null;
        }

        $item = $assessment['at_risk_items'][0];

        $action = $this->recorder->record([
            'tenant_id' => $requirement->tenant_id,
            'project_id' => $requirement->project_id,
            'capability' => 'closeout',
            'action_type' => self::ACTION_TYPE,
            'trigger_type' => 'closeout_requirement_at_risk',
            'trigger_record_ids' => array_filter([
                ['type' => 'CloseoutRequirement', 'id' => $requirement->id],
                $deliverable !== null ? ['type' => 'CloseoutDeliverable', 'id' => $deliverable->id] : null,
            ]),
            'rule_id' => 'CloseoutReadiness::assess.at_risk',
            'state_version' => $item['state'].'|'.implode('|', $item['reasons']),
            'epistemic_state' => 'resolved',
            'evidence_used' => ['closeout_requirement_id' => $requirement->id, 'assessment_item' => $item],
            'proposed_change' => [
                'create_task' => [
                    'task_type' => self::ACTION_TYPE,
                    'title' => 'At-risk closeout deliverable: '.$requirement->title,
                ],
            ],
            'auto_execute' => function () use ($requirement, $item) {
                $task = ProjectTask::create([
                    'tenant_id' => $requirement->tenant_id,
                    'project_id' => $requirement->project_id,
                    'task_type' => self::ACTION_TYPE,
                    'title' => 'At-risk closeout deliverable: '.$requirement->title,
                    'detail' => implode(' ', $item['reasons']),
                    'status' => 'open',
                    'subject_type' => CloseoutRequirement::class,
                    'subject_id' => $requirement->id,
                ]);

                return ['project_task_id' => $task->id];
            },
        ]);

        return ['requirement_id' => $requirement->id, 'action' => $action];
    }
}
