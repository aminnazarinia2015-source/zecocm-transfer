<?php

namespace App\Domain\Autonomy;

use App\Models\AutonomyPolicy;

/**
 * AUTO-2: resolves the EFFECTIVE autonomy level for a given project/action
 * type - the single place "may the system do this without a human approving
 * this execution" is decided. Per Codex's ruling this is never the model's
 * call and never a runtime setting alone: it is always
 *
 *     effective = stricter(active project policy level, system ceiling)
 *
 * so a project cannot loosen past the system ceiling even by explicit
 * configuration, and a missing policy row fails toward APPROVAL_REQUIRED
 * rather than defaulting open - "never automate away accountability" means
 * AUTO is something a project must be explicitly granted, not something it
 * gets by omission.
 */
final class AutonomyPolicyResolver
{
    private readonly array $ceilings;

    public function __construct(?array $ceilings = null)
    {
        $this->ceilings = $ceilings ?? config('autonomy_action_ceilings', []);
    }

    public function ceilingFor(string $actionType): string
    {
        return $this->ceilings[$actionType] ?? AutonomyLevel::HUMAN_ONLY;
    }

    /**
     * @return array{level: string, policy: ?AutonomyPolicy, ceiling: string}
     */
    public function resolve(int $tenantId, int $projectId, string $actionType): array
    {
        $ceiling = $this->ceilingFor($actionType);

        $policy = AutonomyPolicy::query()
            ->where('tenant_id', $tenantId)
            ->where('project_id', $projectId)
            ->where('action_type', $actionType)
            ->where('status', 'active')
            ->orderByDesc('id')
            ->first();

        if ($policy === null) {
            // No explicit authorization on record for this project/action -
            // fail toward requiring a human, never toward AUTO.
            return ['level' => AutonomyLevel::stricterOf(AutonomyLevel::APPROVAL_REQUIRED, $ceiling), 'policy' => null, 'ceiling' => $ceiling];
        }

        return ['level' => AutonomyLevel::stricterOf($policy->autonomy_level, $ceiling), 'policy' => $policy, 'ceiling' => $ceiling];
    }
}
