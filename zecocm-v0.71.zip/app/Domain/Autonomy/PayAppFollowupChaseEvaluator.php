<?php

namespace App\Domain\Autonomy;

use App\Models\AutonomousAction;
use App\Models\PayApplication;
use App\Models\Project;
use DateTimeImmutable;

/**
 * AUTO-2's fifth seeded action, per Codex's explicit split on Amin's
 * pay-app-automation direction: "pay-app chasing" is two distinct actions,
 * not one, and `pay_app_followup_chase` is the one that means EXTERNAL
 * communication - "email PM/owner/accountant that payment is late /
 * application needs action." Codex: "do not let 'automatic pay-app
 * chasing' quietly reuse the safer shell-creation ceiling."
 *
 * This class is deliberately the "model it, do not implement the send"
 * half of Codex's build-sequence item 4 ("model pay_app_followup_chase
 * separately BEFORE implementing any external automated reminder"). It
 * detects the trigger and records a proposed follow-up - it never sends
 * anything. `pay_app_followup_chase`'s system ceiling is APPROVAL_REQUIRED
 * (config/autonomy_action_ceilings.php), so `record()` is never given an
 * `auto_execute` callback here: there is no level this action can resolve
 * to that would ever invoke one, and adding one now would be exactly the
 * "appearance of a strategy without an actual channel" Codex warned about
 * for EscalationDominance. A future PayAppFollowupChaseSender (the actual
 * email) is a separate, later piece, gated by a human approving this
 * action - not by this evaluator resolving to AUTO, which the ceiling
 * makes structurally impossible.
 *
 * The triggering condition reuses `PayAppClocks`/`DeadlineExpression` -
 * built earlier in this codebase's life "with nothing to attach them to"
 * (see `PayApplicationTest`'s own docblock) - via the SAME
 * `Project::clock()` lookup every other contract clock in this codebase
 * goes through: a submitted-but-not-yet-approved application whose review
 * period has passed, or an approved-but-not-yet-paid application whose
 * payment period has passed. Conservative by construction: if the project
 * has not confirmed a `pay_app_review`/`pay_app_payment` clock, this
 * produces no action at all - the same "no confirmed calendar, no alert"
 * default `ClaimClockAutonomyEvaluator` already uses, never a guessed
 * period.
 */
final class PayAppFollowupChaseEvaluator
{
    public const ACTION_TYPE = 'pay_app_followup_chase';

    private const REVIEW_CLOCK = 'pay_app_review';

    private const PAYMENT_CLOCK = 'pay_app_payment';

    public function __construct(
        private readonly AutonomousActionRecorder $recorder = new AutonomousActionRecorder,
    ) {}

    /** @return list<array{application_id:int, action: ?AutonomousAction}> */
    public function evaluateProject(int $tenantId, int $projectId): array
    {
        $project = Project::query()->where('tenant_id', $tenantId)->find($projectId);
        if ($project === null) {
            return [];
        }

        $results = [];

        PayApplication::query()
            ->where('tenant_id', $tenantId)
            ->where('project_id', $projectId)
            ->whereIn('status', ['submitted', 'approved'])
            ->each(function (PayApplication $application) use ($project, &$results) {
                $result = $this->evaluateApplication($application, $project);
                if ($result !== null) {
                    $results[] = $result;
                }
            });

        return $results;
    }

    /**
     * A chase follows the CURRENT obligation state, not merely the fact that
     * a deadline was once exceeded (Codex's invariant). This is public and
     * callable directly, independent of evaluateProject()'s own scan filter,
     * so the guard against non-actionable statuses lives here too rather
     * than only in the caller - a paid, draft, or rejected application must
     * never produce a chase regardless of which entry point reached it.
     *
     * @return ?array{application_id:int, action: ?AutonomousAction}
     */
    public function evaluateApplication(PayApplication $application, Project $project): ?array
    {
        if (! in_array($application->status, ['submitted', 'approved'], true)) {
            return null;
        }

        if ($application->status === 'submitted') {
            $clockName = self::REVIEW_CLOCK;
            $anchor = $application->submitted_at;
            $reason = 'review';
            $message = 'Pay application '.$application->number.' is past its review period without action.';
        } else {
            $clockName = self::PAYMENT_CLOCK;
            $anchor = $application->approved_at;
            $reason = 'payment';
            $message = 'Pay application '.$application->number.' is past its payment due date.';
        }

        if ($anchor === null) {
            return null;
        }

        try {
            $expr = $project->clock($clockName);
        } catch (\Throwable) {
            // No confirmed clock on this project - conservative default,
            // never a guessed period.
            return null;
        }

        $due = $expr->dueFrom(new DateTimeImmutable((string) $anchor));

        if (new DateTimeImmutable('now') <= $due) {
            return null;
        }

        $action = $this->recorder->record([
            'tenant_id' => $application->tenant_id,
            'project_id' => $application->project_id,
            'capability' => 'payment',
            'action_type' => self::ACTION_TYPE,
            'trigger_type' => 'pay_application_clock_overdue',
            'trigger_record_ids' => [['type' => 'PayApplication', 'id' => $application->id]],
            'rule_id' => 'PayAppClocks.'.$reason.'_overdue',
            'state_version' => $application->status.'|'.$due->format('Y-m-d'),
            'epistemic_state' => 'resolved',
            'evidence_used' => [
                'pay_application_id' => $application->id,
                'status' => $application->status,
                'clock' => $reason,
                'anchor_at' => (string) $anchor,
                'due_at' => $due->format('Y-m-d'),
            ],
            'proposed_change' => [
                'prepare_followup_message' => [
                    'pay_application_id' => $application->id,
                    'reason' => $message,
                ],
            ],
            // No auto_execute: this action never sends anything by itself -
            // see the class doc.
        ]);

        return ['application_id' => $application->id, 'action' => $action];
    }
}
