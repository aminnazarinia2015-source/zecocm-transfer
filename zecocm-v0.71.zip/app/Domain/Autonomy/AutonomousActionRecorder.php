<?php

namespace App\Domain\Autonomy;

use App\Models\AutonomousAction;
use App\Models\AutonomyObservation;

/**
 * AUTO-2: the single place an autonomous action candidate becomes (or does
 * not become) a persisted, explainable row.
 *
 * This class deliberately does NOT decide whether a triggering condition
 * exists - that is always a deterministic domain check made by the caller
 * (e.g. ClaimClock::calculate()'s may_alert, CloseoutReadiness::assess()'s
 * at-risk flags, an Escalation with basis === BASIS_INSUFFICIENT_EVIDENCE).
 * It only decides, given that a candidate exists, what autonomy tier applies
 * and what happens as a result.
 *
 * Three hard rules this class enforces in code, per Codex's adversarial
 * review of the first substrate, not just in a comment:
 *
 * NOT_AUTOMATABLE creates no AutonomousAction row at all - but does write an
 * AutonomyObservation, so a later reviewer can tell "Steward saw nothing"
 * from "Steward saw this and correctly refused to act."
 *
 * UNCERTAINTY LAUNDERING is refused structurally: an action whose trigger is
 * unresolved/disputed can only auto-execute if its action_type is listed in
 * config/autonomy_uncertainty_preserving_actions.php as producing an
 * executed_change that can only preserve the uncertainty, never assert a
 * governed fact. Everything else gets forced to at least APPROVAL_REQUIRED
 * regardless of policy or ceiling.
 *
 * IDEMPOTENCY is structural, not per-evaluator: `action_key` identifies "this
 * action, this trigger, this rule version, this state" and re-detecting the
 * same still-active condition returns the existing row rather than creating
 * a duplicate. A caller that wants a fresh action when state materially
 * changes must include that state in `state_version` - a different
 * state_version produces a different key.
 *
 * RE-AUTHORIZATION AT EXECUTION is a separate method
 * (executeIfStillAuthorized), not folded into record(), because Codex's
 * strongest finding was that authority resolved at proposal time must not be
 * trusted at execution time if policy or the system ceiling tightened in
 * between. The current seeded actions execute synchronously inside record()
 * (no gap exists yet), but any future deferred/queued execution MUST go
 * through executeIfStillAuthorized rather than trusting the row's stored
 * effective_autonomy_level.
 */
final class AutonomousActionRecorder
{
    public function __construct(
        private readonly AutonomyPolicyResolver $resolver = new AutonomyPolicyResolver,
    ) {}

    /**
     * @param  array{
     *     tenant_id: int, project_id: int, capability: string, action_type: string,
     *     trigger_type: string, trigger_record_ids: array, rule_id: string,
     *     rule_version?: ?string, state_version?: string, evidence_used: array,
     *     proposed_change: array, epistemic_state?: string,
     *     auto_execute?: ?callable(): array,
     * }  $params  epistemic_state: resolved (default) | unresolved | disputed -
     *             whether the TRIGGER this action is built on is itself
     *             settled. auto_execute, when given, is invoked ONLY when the
     *             (possibly epistemically-downgraded) effective level is AUTO
     *             or AUTO_NOTIFY, and its return value becomes
     *             executed_change. It must actually perform the change - this
     *             class never fabricates an executed_change on the caller's
     *             behalf.
     * @return ?AutonomousAction null exactly when the effective level is
     *                           NOT_AUTOMATABLE - no AutonomousAction row is
     *                           created (an AutonomyObservation is, instead).
     */
    public function record(array $params): ?AutonomousAction
    {
        $resolution = $this->resolver->resolve($params['tenant_id'], $params['project_id'], $params['action_type']);
        $level = $resolution['level'];

        if ($level === AutonomyLevel::NOT_AUTOMATABLE) {
            AutonomyObservation::create([
                'tenant_id' => $params['tenant_id'],
                'project_id' => $params['project_id'],
                'action_type' => $params['action_type'],
                'trigger_type' => $params['trigger_type'],
                'trigger_record_ids' => $params['trigger_record_ids'],
                'reason' => 'action_type is NOT_AUTOMATABLE - condition detected, no action candidate created',
                'observed_at' => now(),
            ]);

            return null;
        }

        $epistemicState = $params['epistemic_state'] ?? 'resolved';

        if ($epistemicState !== 'resolved' && ! $this->preservesUncertainty($params['action_type'])) {
            // Uncertainty laundering guard: an unresolved/disputed trigger
            // may not auto-execute unless this action type is registered as
            // producing only uncertainty-preserving output (e.g. a review
            // task naming the missing fact, never a settled one).
            $level = AutonomyLevel::stricterOf($level, AutonomyLevel::APPROVAL_REQUIRED);
        }

        $actionKey = $this->actionKey($params);

        $existing = AutonomousAction::query()
            ->where('tenant_id', $params['tenant_id'])
            ->where('action_key', $actionKey)
            ->whereIn('status', AutonomousAction::ACTIVE_STATUSES)
            ->first();

        if ($existing !== null) {
            return $existing;
        }

        $identity = [
            'tenant_id' => $params['tenant_id'],
            'project_id' => $params['project_id'],
            'capability' => $params['capability'],
            'action_type' => $params['action_type'],
            'trigger_type' => $params['trigger_type'],
            'trigger_record_ids' => $params['trigger_record_ids'],
            'rule_id' => $params['rule_id'],
            'rule_version' => $params['rule_version'] ?? null,
            'action_key' => $actionKey,
            'epistemic_state' => $epistemicState,
            'autonomy_policy_id' => $resolution['policy']?->id,
            'effective_autonomy_level' => $level,
            'evidence_used' => $params['evidence_used'],
            'proposed_change' => $params['proposed_change'],
        ];

        $resultHash = hash('sha256', json_encode($identity, JSON_THROW_ON_ERROR));

        $action = AutonomousAction::create($identity + [
            'result_hash' => $resultHash,
            'status' => $this->initialStatus($level),
            'executed_by' => 'system',
            'human_intervention_state' => 'none',
            'created_at' => now(),
        ]);

        if (in_array($level, [AutonomyLevel::AUTO, AutonomyLevel::AUTO_NOTIFY], true) && isset($params['auto_execute'])) {
            // Per Codex's caution: even though no time gap exists yet between
            // creation and this synchronous execution, route through the
            // SAME re-authorization path a future deferred/queued execution
            // will use - one execution semantics, not a "fast path" that
            // trusts creation-time state plus a separate deferred path that
            // rechecks it.
            $this->executeIfStillAuthorized($action, $params['auto_execute']);
        }

        return $action;
    }

    /**
     * Re-resolves the CURRENT policy and system ceiling for a previously
     * proposed-but-not-yet-executed action, and executes only if today's
     * authority still permits it. This is the method Codex's first two
     * attacks require: an action's stored effective_autonomy_level is what
     * was true at creation, never a license to execute on stale authority
     * later. If the project's policy has since been superseded to something
     * stricter, or the checked-in system ceiling has tightened, this refuses
     * and leaves the action exactly where it was for a human to see -
     * it never silently escalates OR silently executes on old authority.
     */
    public function executeIfStillAuthorized(AutonomousAction $action, callable $executor): AutonomousAction
    {
        if ($action->executed_change !== null) {
            return $action;
        }

        $resolution = $this->resolver->resolve($action->tenant_id, $action->project_id, $action->action_type);
        $currentLevel = $resolution['level'];

        if (! in_array($currentLevel, [AutonomyLevel::AUTO, AutonomyLevel::AUTO_NOTIFY], true)) {
            $action->update([
                'status' => 'pending_approval',
                'human_intervention_state' => 'reauthorization_required',
            ]);

            return $action;
        }

        $this->execute($action, $executor, $currentLevel);

        return $action;
    }

    private function execute(AutonomousAction $action, callable $executor, string $level): void
    {
        $executedChange = $executor();

        $action->executed_change = $executedChange;
        $action->executed_at = now();
        $action->status = 'executed';

        if ($level === AutonomyLevel::AUTO_NOTIFY) {
            $action->notified_at = now();
            $action->human_intervention_state = 'notified';
        }

        $action->save();
    }

    private function actionKey(array $params): string
    {
        return hash('sha256', json_encode([
            $params['tenant_id'], $params['project_id'], $params['action_type'],
            $params['trigger_record_ids'], $params['rule_id'], $params['rule_version'] ?? null,
            $params['state_version'] ?? null,
        ], JSON_THROW_ON_ERROR));
    }

    private function preservesUncertainty(string $actionType): bool
    {
        return in_array($actionType, config('autonomy_uncertainty_preserving_actions', []), true);
    }

    private function initialStatus(string $level): string
    {
        return match ($level) {
            AutonomyLevel::AUTO, AutonomyLevel::AUTO_NOTIFY => 'proposed',
            AutonomyLevel::APPROVAL_REQUIRED => 'pending_approval',
            AutonomyLevel::HUMAN_ONLY => 'awaiting_human',
            default => throw new \LogicException("record() must not be reached with level {$level}"),
        };
    }
}
