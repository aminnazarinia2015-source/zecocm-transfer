<?php

namespace App\Domain\Autonomy;

use App\Domain\Ai\Escalation;
use App\Models\AiRun;
use App\Models\AutonomousAction;
use App\Models\ProjectTask;

/**
 * AUTO-2's second seeded action, and per Codex's ordering the first one to
 * actually wire ("safest and proves the uncertainty-preserving path"):
 * TR-16 insufficient_evidence -> a human-review task that preserves the
 * missing fact, never converts it into a settled one.
 *
 * The triggering condition is entirely TR-16's own, pre-existing,
 * deterministic result: an AiRun whose result_classification is 'refusal'
 * and whose stored result.basis is Escalation::BASIS_INSUFFICIENT_EVIDENCE.
 * This class adds no judgment about whether the evidence really is
 * insufficient - that determination already happened in
 * ClaudeAssistant::parseEscalation() and RunGovernedAi, and reached the
 * database as-is.
 *
 * epistemic_state is always 'unresolved' here - that is the entire meaning
 * of BASIS_INSUFFICIENT_EVIDENCE - which is exactly why this action_type is
 * (and must remain) the one entry in
 * config/autonomy_uncertainty_preserving_actions.php: the only thing this
 * evaluator's auto_execute is allowed to do is create a task that NAMES the
 * missing fact, never one that answers it.
 */
final class InsufficientEvidenceReviewEvaluator
{
    public const ACTION_TYPE = 'insufficient_evidence_review_request';

    public function __construct(
        private readonly AutonomousActionRecorder $recorder = new AutonomousActionRecorder,
    ) {}

    public function evaluateRun(AiRun $run): ?AutonomousAction
    {
        if ($run->result_classification !== 'refusal') {
            return null;
        }

        $result = $run->result ?? [];

        if (($result['basis'] ?? null) !== Escalation::BASIS_INSUFFICIENT_EVIDENCE) {
            return null;
        }

        if ($run->project_id === null) {
            // No project to attach a review task to - nothing this evaluator
            // can act on (a run not scoped to a project has no home for the
            // task it would create).
            return null;
        }

        $missingFact = $result['missing_fact'] ?? null;
        $reason = $result['reason'] ?? 'insufficient evidence';

        return $this->recorder->record([
            'tenant_id' => $run->tenant_id,
            'project_id' => $run->project_id,
            'capability' => 'ai',
            'action_type' => self::ACTION_TYPE,
            'trigger_type' => 'ai_run_insufficient_evidence',
            'trigger_record_ids' => [['type' => 'AiRun', 'id' => $run->id]],
            'rule_id' => 'Escalation::BASIS_INSUFFICIENT_EVIDENCE',
            'state_version' => (string) $run->id,
            'epistemic_state' => 'unresolved',
            'evidence_used' => [
                'ai_run_id' => $run->id,
                'reason' => $reason,
                'missing_fact' => $missingFact,
                'conflict_citations' => $result['conflict_citations'] ?? [],
            ],
            'proposed_change' => [
                'create_task' => [
                    'task_type' => self::ACTION_TYPE,
                    'title' => 'Unresolved: '.($missingFact ?? $reason),
                ],
            ],
            'auto_execute' => function () use ($run, $reason, $missingFact) {
                $task = ProjectTask::create([
                    'tenant_id' => $run->tenant_id,
                    'project_id' => $run->project_id,
                    'task_type' => self::ACTION_TYPE,
                    // Deliberately preserves the unresolved framing rather
                    // than asserting an answer - "Review unresolved..." never
                    // "Confirm...". Codex's own example, verbatim: must
                    // produce "Review missing acceptance date", never
                    // "Confirm acceptance occurred August 12."
                    'title' => 'Review unresolved: '.($missingFact ?? $reason),
                    'detail' => $reason.($missingFact !== null ? ' Missing: '.$missingFact : ''),
                    'status' => 'open',
                    'subject_type' => AiRun::class,
                    'subject_id' => $run->id,
                ]);

                return ['project_task_id' => $task->id];
            },
        ]);
    }
}
