<?php

namespace App\Domain\Closeout;

use DateTimeImmutable;

/**
 * What happened, what was recorded, and why they must never be the same field.
 *
 * The Civil Code s. 9356 stop-payment-notice window is thirty days or ninety
 * depending on whether a notice of completion was RECORDED. So a system that
 * treats "the superintendent says we finished on the first" as equivalent to a
 * recorded instrument will count from the wrong event and display the answer
 * with total confidence. That is the same failure as reading "sent" as
 * "served", one row over and with a bigger number attached.
 *
 * Three separate questions, three separate answers, and this class exists to
 * stop anything downstream from collapsing them:
 *
 *   DID IT HAPPEN?      a fact, or somebody's determination.
 *   WAS IT RECORDED?    a county, an instrument number and a date, or not.
 *   WHICH CLOCK RUNS?   which is a consequence of the first two and never of
 *                       either one alone.
 */
final class CompletionState
{
    // What kind of thing the event is. Cessation of labour is observable.
    // Substantial completion is an OPINION about whether the work can be used
    // for its intended purpose, and calling it a fact makes a disputable date
    // look settled.
    public const FACT = 'fact';
    public const DETERMINATION = 'determination';

    public const ASSERTED = 'asserted';
    public const DETERMINED = 'determined';
    public const DISPUTED = 'disputed';
    public const SUPERSEDED = 'superseded';

    public const RECORDED = 'recorded';
    public const NOT_RECORDED = 'not_recorded';
    public const RECORDATION_UNRESOLVED = 'unresolved';

    /** Which event types are inherently determinations rather than observations. */
    public const DETERMINATIONS = ['substantial_completion', 'final_completion',
        'acceptance_by_governing_body', 'beneficial_occupancy'];

    /**
     * Whether an instrument is actually recorded, and what is missing if not.
     *
     * @param  array<string,mixed>  $instrument
     * @return array{state: string, usable_as_anchor: bool, message: string, missing: list<string>}
     */
    public static function recordation(?array $instrument): array
    {
        if ($instrument === null) {
            return [
                'state' => self::RECORDATION_UNRESOLVED,
                'usable_as_anchor' => false,
                'missing' => ['the instrument itself'],
                'message' => 'No completion instrument is recorded for this project. That is NOT the same as knowing '
                    .'none was recorded - nobody has established either way, and the two support different statutory '
                    .'windows.',
            ];
        }

        $missing = [];
        foreach ([
            'recording_county' => 'the recording county',
            'instrument_number' => 'the instrument number',
            'recorded_on' => 'the date of recordation',
        ] as $field => $label) {
            if (($instrument[$field] ?? null) === null || $instrument[$field] === '') {
                $missing[] = $label;
            }
        }

        $declared = (string) ($instrument['recordation_state'] ?? self::RECORDATION_UNRESOLVED);

        if ($declared === self::NOT_RECORDED) {
            return [
                'state' => self::NOT_RECORDED,
                'usable_as_anchor' => false,
                'missing' => [],
                'message' => 'A search established that no completion instrument was recorded. Statutory periods that '
                    .'depend on recordation run from the alternative event the statute names.',
            ];
        }

        if ($missing !== []) {
            // The commonest real state: somebody typed the notice into ZecoCM
            // and nobody went to the recorder.
            return [
                'state' => self::RECORDATION_UNRESOLVED,
                'usable_as_anchor' => false,
                'missing' => $missing,
                'message' => 'This instrument is recorded in ZecoCM but not established as recorded with the county: '
                    .implode(', ', $missing).' '.(count($missing) === 1 ? 'is' : 'are').' missing. A notice of '
                    .'completion sitting in a project file has started no clock. Recordation is what the statute turns '
                    .'on, and the difference is thirty days against ninety.',
            ];
        }

        return [
            'state' => self::RECORDED,
            'usable_as_anchor' => true,
            'missing' => [],
            'message' => 'Recorded '.$instrument['recorded_on'].' in '.$instrument['recording_county']
                .' as instrument '.$instrument['instrument_number'].'.',
        ];
    }

    /**
     * Whether a completion event may anchor a clock.
     *
     * @param  array<string,mixed>  $event
     * @return array{usable: bool, reason: ?string}
     */
    public static function anchorable(array $event): array
    {
        $type = (string) ($event['event_type'] ?? '');
        $status = (string) ($event['status'] ?? self::ASSERTED);
        $nature = (string) ($event['nature'] ?? self::FACT);

        if ($status === self::DISPUTED) {
            return ['usable' => false, 'reason' => 'The date of '.self::label($type).' is disputed, so a clock counted '
                .'from it would state a deadline nobody agrees on.'];
        }

        if ($status === self::SUPERSEDED) {
            return ['usable' => false, 'reason' => 'This event has been superseded by a later determination.'];
        }

        // A determination that nobody has actually made is an assertion, and
        // the difference matters most on exactly the events people assert
        // casually - "we were substantially complete in June".
        if ($nature === self::DETERMINATION && $status !== self::DETERMINED) {
            return ['usable' => false, 'reason' => self::label($type).' is a determination about whether the work can '
                .'be used for its intended purpose, not an observable fact. It is currently only asserted. Until a '
                .'named party with authority determines it, a clock counted from it would treat one side\'s position '
                .'as settled.'];
        }

        if (($event['occurred_on'] ?? null) === null) {
            return ['usable' => false, 'reason' => self::label($type).' carries no date.'];
        }

        return ['usable' => true, 'reason' => null];
    }

    public static function label(string $eventType): string
    {
        return match ($eventType) {
            'substantial_completion' => 'Substantial completion',
            'final_completion' => 'Final completion',
            'acceptance_by_governing_body' => 'Acceptance by the governing body',
            'cessation_of_labor' => 'Cessation of labour',
            'beneficial_occupancy' => 'Beneficial occupancy',
            default => ucfirst(str_replace('_', ' ', $eventType)),
        };
    }

    public static function isDetermination(string $eventType): bool
    {
        return in_array($eventType, self::DETERMINATIONS, true);
    }
}
