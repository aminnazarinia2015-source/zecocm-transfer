<?php

namespace App\Domain\Closeout;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * The clock that runs the wrong way.
 *
 * Every other clock in ZecoCM expires a right: miss the date and something is
 * gone. A warranty does the opposite - it CREATES an obligation that runs
 * forward from acceptance and outlives every other clock in the system. That
 * inversion is why this is not in the A3 claim-requirement graph even though it
 * looks superficially similar. The consequence of a warranty ending is not the
 * consequence of a notice deadline passing; it is nearly its opposite, and a
 * shared abstraction would have leaked one into the other.
 *
 * Two things this gets right that a naive month-adding implementation does not:
 *
 * THE ANCHOR IS A COMPLETION EVENT, WITH ALL THAT IMPLIES. A warranty running
 * from "acceptance by the governing body" cannot start until somebody has
 * actually made that determination. Counting twelve months from a date the
 * superintendent mentioned in a meeting produces an expiry date that is wrong
 * in the direction that costs the owner money.
 *
 * A REPAIR SOMETIMES RESTARTS THE PERIOD, FOR THAT ITEM ONLY. Whether it does
 * is a contract question with a real answer in the specification, so it is
 * recorded per obligation with its source rather than assumed either way.
 * Assuming it restarts inflates the contractor's exposure; assuming it does not
 * quietly discards a right the owner paid for.
 */
final class WarrantyClock
{
    public const RUNNING = 'running';
    public const EXPIRED = 'expired';
    public const NOT_STARTED = 'not_started';
    public const UNRESOLVED_ANCHOR = 'unresolved_anchor';

    /**
     * @param  array<string,mixed>  $obligation
     * @param  array<string,mixed>|null  $anchorEvent
     * @param  list<array<string,mixed>>  $events
     * @return array<string,mixed>
     */
    public static function state(array $obligation, ?array $anchorEvent, array $events = [], ?DateTimeImmutable $asOf = null): array
    {
        $asOf ??= new DateTimeImmutable('today');
        $title = (string) ($obligation['title'] ?? 'this warranty');
        $months = (int) ($obligation['duration_months'] ?? 12);

        if ($anchorEvent === null) {
            return self::out(self::UNRESOLVED_ANCHOR, null, null, [],
                'The warranty for "'.$title.'" has no anchoring completion event recorded, so its start and end cannot '
                .'be established. A warranty period counted from a date nobody determined is a date that will be '
                .'disputed exactly when it is relied on.');
        }

        $anchorable = CompletionState::anchorable($anchorEvent);

        if (! $anchorable['usable']) {
            return self::out(self::UNRESOLVED_ANCHOR, null, null, [],
                'The warranty for "'.$title.'" is anchored to '
                .CompletionState::label((string) ($anchorEvent['event_type'] ?? '')).', which cannot yet anchor a '
                .'clock. '.$anchorable['reason']);
        }

        $start = new DateTimeImmutable((string) $anchorEvent['occurred_on']);
        $end = $start->modify("+{$months} months");

        // Per-item restarts. Only the items the contract actually restarts for,
        // and only when this obligation says the contract does.
        $restarts = [];
        if ($obligation['repair_restarts_period'] ?? false) {
            foreach ($events as $event) {
                if (! ($event['restarts_period_for_item'] ?? false)) {
                    continue;
                }
                $on = $event['occurred_on'] ?? null;
                if ($on === null) {
                    continue;
                }

                $item = (string) ($event['item_reference'] ?? 'unidentified item');
                $itemStart = new DateTimeImmutable((string) $on);
                $itemEnd = $itemStart->modify("+{$months} months");

                // The latest restart for a given item wins; earlier repairs to
                // the same item are already covered by it.
                if (! isset($restarts[$item]) || $itemEnd > new DateTimeImmutable($restarts[$item]['ends_on'])) {
                    $restarts[$item] = [
                        'item' => $item,
                        'restarted_on' => $itemStart->format('Y-m-d'),
                        'ends_on' => $itemEnd->format('Y-m-d'),
                    ];
                }
            }
        }

        $state = match (true) {
            $asOf < $start => self::NOT_STARTED,
            $asOf > $end => self::EXPIRED,
            default => self::RUNNING,
        };

        $message = match ($state) {
            self::NOT_STARTED => 'The warranty for "'.$title.'" has not started. It begins '.$start->format('j M Y').'.',
            self::EXPIRED => 'The general warranty period for "'.$title.'" ran from '.$start->format('j M Y').' to '
                .$end->format('j M Y').' and has ended.'
                .($restarts !== [] ? ' '.count($restarts).' repaired item(s) carry their own later period - see below.' : ''),
            default => 'The warranty for "'.$title.'" runs from '.$start->format('j M Y').' to '.$end->format('j M Y').'.',
        };

        if ($restarts === [] && ! ($obligation['repair_restarts_period'] ?? false)) {
            // Said out loud rather than assumed silently in either direction.
            $message .= ' Repairs during the period do NOT restart it for the repaired item'
                .(($obligation['restart_rule_source'] ?? null) ? ' ('.$obligation['restart_rule_source'].').'
                    : ', and no source for that rule is recorded - which is worth resolving, because assuming wrongly '
                        .'either inflates the contractor\'s exposure or discards a right the owner paid for.');
        }

        return self::out($state, $start->format('Y-m-d'), $end->format('Y-m-d'), array_values($restarts), $message);
    }

    /**
     * The date after which nothing in this obligation is live, repaired items
     * included. This is the figure a records-retention policy should use, and
     * it is deliberately the LATEST of everything rather than the general
     * period, because destroying a record while an item is still under warranty
     * is how a defect claim becomes unanswerable.
     */
    public static function finalExposureDate(array $state): ?string
    {
        $dates = array_filter([$state['ends_on'] ?? null]);

        foreach ($state['item_restarts'] ?? [] as $restart) {
            $dates[] = $restart['ends_on'];
        }

        if ($dates === []) {
            return null;
        }

        sort($dates);

        return end($dates);
    }

    private static function out(string $state, ?string $startsOn, ?string $endsOn, array $restarts, string $message): array
    {
        return [
            'state' => $state,
            'starts_on' => $startsOn,
            'ends_on' => $endsOn,
            'item_restarts' => $restarts,
            'message' => $message,
        ];
    }
}
