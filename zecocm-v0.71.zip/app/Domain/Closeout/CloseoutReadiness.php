<?php

namespace App\Domain\Closeout;

/**
 * Closeout debt, visible in month four instead of month eighteen.
 *
 * The commercial position, and it is Codex's phrasing:
 *
 *   ZecoCM treats closeout as a process that starts when the first submittal is
 *   approved, not when construction ends.
 *
 * As-builts and O&M manuals are the deliverables everybody defers and then
 * cannot produce. By the time a project is closing, the subcontractor who had
 * the record drawings has demobilised, the supplier who owed the manual has
 * been paid, and the leverage is gone. Every one of those was foreseeable a
 * year earlier from records ZecoCM already holds.
 *
 * FOUR SIGNALS, and none of them requires anything new to be entered:
 *
 *   BROKEN LINEAGE. A product submittal approved for construction should
 *   eventually be installed, tested, documented in an O&M manual, warranted,
 *   and accepted at closeout. A missing link in that chain IS closeout debt,
 *   and it is visible the moment the link fails to appear.
 *
 *   UNASSIGNED OBLIGATIONS. A required deliverable with nobody responsible is
 *   nobody's problem until it is everybody's.
 *
 *   DEMOBILISATION RISK. The subcontractor who owes it is finished on site and
 *   nearly paid. This is the one that turns a paperwork problem into a money
 *   problem, because after final payment there is nothing to withhold.
 *
 *   PROVISIONAL CONDITIONS. A temporary repair, a deferred test, an open punch
 *   item, an unresolved NCR, an RFI whose answer has to be drawn into the
 *   record. Each is a closeout blocker long before anybody calls it one.
 *
 * AND THE OUTPUT IS A LIST, NOT A PERCENTAGE. "74% complete" hides which rung
 * everything is stuck on and tells nobody what to do this week. "Seven items at
 * risk before demobilisation, here they are" is the number that changes
 * behaviour.
 */
final class CloseoutReadiness
{
    // The ladder. Each rung is a different problem with a different owner.
    public const REQUIRED = 'required';
    public const ASSIGNED = 'assigned';
    public const EVIDENCE_READY = 'evidence_ready';
    public const SUBMITTED = 'submitted';
    public const ACCEPTED = 'accepted';

    public const LADDER = [self::REQUIRED, self::ASSIGNED, self::EVIDENCE_READY, self::SUBMITTED, self::ACCEPTED];

    /**
     * @param  list<array<string,mixed>>  $requirements  each with state, responsible_party,
     *   deliverable_type, blocks_final_payment, blocks_retention_release, and optionally
     *   partner_demobilising / partner_percent_paid / lineage_gap / provisional_condition
     * @return array<string,mixed>
     */
    public static function assess(array $requirements): array
    {
        $counts = array_fill_keys(self::LADDER, 0);
        $atRisk = [];
        $blockingPayment = 0;
        $blockingRetention = 0;

        foreach ($requirements as $requirement) {
            $state = (string) ($requirement['state'] ?? self::REQUIRED);
            if (isset($counts[$state])) {
                $counts[$state]++;
            }

            if ($state === self::ACCEPTED) {
                continue;
            }

            if ($requirement['blocks_final_payment'] ?? false) {
                $blockingPayment++;
            }
            if ($requirement['blocks_retention_release'] ?? false) {
                $blockingRetention++;
            }

            $reasons = self::risksFor($requirement, $state);

            if ($reasons !== []) {
                $atRisk[] = [
                    'title' => $requirement['title'] ?? 'Untitled deliverable',
                    'deliverable_type' => $requirement['deliverable_type'] ?? null,
                    'state' => $state,
                    'responsible_party' => $requirement['responsible_party'] ?? null,
                    'blocks_final_payment' => (bool) ($requirement['blocks_final_payment'] ?? false),
                    'blocks_retention_release' => (bool) ($requirement['blocks_retention_release'] ?? false),
                    'reasons' => $reasons,
                    // Sorting key: leverage lost is worse than merely late.
                    'severity' => self::severity($requirement, $reasons),
                ];
            }
        }

        usort($atRisk, fn ($a, $b) => $b['severity'] <=> $a['severity']);

        $total = count($requirements);

        return [
            // Cumulative, so each figure means "reached at least this rung".
            'required' => $total,
            'assigned' => $total - $counts[self::REQUIRED],
            'evidence_ready' => $counts[self::EVIDENCE_READY] + $counts[self::SUBMITTED] + $counts[self::ACCEPTED],
            'submitted' => $counts[self::SUBMITTED] + $counts[self::ACCEPTED],
            'accepted' => $counts[self::ACCEPTED],
            'at_risk' => count($atRisk),
            'at_risk_items' => $atRisk,
            'blocking_final_payment' => $blockingPayment,
            'blocking_retention_release' => $blockingRetention,
            // Said explicitly, because somebody will otherwise reduce all of
            // the above to one number on a dashboard.
            'note' => 'The at-risk list is the useful output. A single completion percentage hides which rung items '
                .'are stuck on and tells nobody what to do this week.',
        ];
    }

    /**
     * @param  array<string,mixed>  $requirement
     * @return list<string>
     */
    private static function risksFor(array $requirement, string $state): array
    {
        $reasons = [];
        $party = $requirement['responsible_party'] ?? null;

        if ($state === self::REQUIRED || $party === null || $party === '') {
            $reasons[] = 'Nobody is responsible for producing it. An unassigned closeout obligation is nobody\'s '
                .'problem until it is everybody\'s.';
        }

        // The one that turns paperwork into money.
        if (($requirement['partner_demobilising'] ?? false) && $state !== self::ACCEPTED) {
            $reasons[] = 'The party who owes it is demobilising. After they leave and are paid there is nothing left '
                .'to withhold, and this becomes a cost rather than a task.';
        }

        $paid = $requirement['partner_percent_paid'] ?? null;
        if ($paid !== null && (float) $paid >= 90.0 && $state !== self::ACCEPTED) {
            $reasons[] = 'The responsible party is '.rtrim(rtrim(number_format((float) $paid, 1), '0'), '.')
                .'% paid. Leverage to obtain this closes with the last payment.';
        }

        if (($requirement['lineage_gap'] ?? null) !== null) {
            $reasons[] = 'Broken lineage: '.$requirement['lineage_gap']
                .'. A submittal approved for construction that never becomes an installed, tested, documented and '
                .'warranted item is closeout debt already incurred.';
        }

        if (($requirement['provisional_condition'] ?? null) !== null) {
            $reasons[] = 'An unresolved provisional condition sits behind it: '.$requirement['provisional_condition']
                .'. It is a closeout blocker now, not at closeout.';
        }

        return $reasons;
    }

    private static function severity(array $requirement, array $reasons): int
    {
        $score = count($reasons);

        // Weighted by what happens if it is never produced, not by how late it
        // is. A missing manual that holds retention outranks three missing keys.
        if ($requirement['blocks_retention_release'] ?? false) {
            $score += 4;
        }
        if ($requirement['blocks_final_payment'] ?? false) {
            $score += 3;
        }
        if ($requirement['partner_demobilising'] ?? false) {
            $score += 5;
        }

        return $score;
    }

    /**
     * What this must never say.
     *
     * "The project is complete" is a determination with statutory consequences
     * - retention, warranty start, lien and stop-notice windows all move on it.
     * A readiness figure is a statement about ZecoCM's own checklist and nothing
     * more, and letting the two blur would be the whole product's failure mode
     * in one sentence.
     */
    public static function disclaimer(): string
    {
        return 'This is a readiness assessment of ZecoCM\'s own closeout checklist. It does not determine that the '
            .'project is complete, that the work is acceptable, that retention is due, or that any warranty has begun. '
            .'Those are determinations made by named parties under the contract, and several of them start statutory '
            .'clocks.';
    }
}
