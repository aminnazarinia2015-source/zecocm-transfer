<?php

namespace App\Domain\Brief;

final class BriefSection
{
    /** @param array<int,BriefLine> $lines */
    public function __construct(
        public readonly string $key,
        public readonly string $title,
        public readonly array $lines,
        public readonly ?string $emptyStatement = null,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'key' => $this->key,
            'title' => $this->title,
            'lines' => array_map(fn (BriefLine $l) => $l->toArray(), $this->lines),
            'empty_statement' => $this->lines === [] ? $this->emptyStatement : null,
        ];
    }
}
