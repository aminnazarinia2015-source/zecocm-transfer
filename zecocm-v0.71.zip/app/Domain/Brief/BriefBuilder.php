<?php

namespace App\Domain\Brief;

use App\Domain\Schedule\ProjectGrant;
use App\Models\AnalysisRun;
use App\Models\DailyReport;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\ScheduleDelta;
use App\Models\ScheduleVersion;
use App\Models\Submittal;
use App\Services\WeatherService;

/**
 * Assembles the Daily Project Success Brief.
 *
 * Deterministic by construction: there is no model call anywhere in this class, so a
 * brief cannot hallucinate. Anything that cannot be computed from the project's own
 * sealed records and its own contract clocks becomes an explicit Refusal instead of a
 * softened sentence.
 */
final class BriefBuilder
{
    /** @var array<int,Refusal> */
    private array $refusals = [];

    public function __construct(private readonly ?WeatherService $weather = null) {}

    /** @return array<string,mixed> */
    public function build(Project $project, ProjectGrant $grant, ?\DateTimeImmutable $now = null): array
    {
        $now ??= new \DateTimeImmutable();
        $this->refusals = [];

        $sections = [
            $this->whereItStands($project, $grant),
            $this->whatChanged($project),
            $this->whatNeedsADecision($project, $now),
            $this->whatIsComing($project, $now),
        ];

        return [
            'project' => [
                'id' => $project->id,
                'number' => $project->number,
                'name' => $project->name,
            ],
            'generated_at' => $now->format(DATE_ATOM),
            'method' => 'deterministic',
            'notice' => 'Every line below is assembled from this project\'s own sealed records and its own contract clocks. No language model wrote any of it. Where ZecoCM cannot know something, it says so rather than estimating.',
            'sections' => array_map(fn (BriefSection $s) => $s->toArray(), $sections),
            'refusals' => array_map(fn (Refusal $r) => $r->toArray(), $this->refusals),
            'refusals_title' => 'What ZecoCM will not tell you today',
        ];
    }

    /* ---------------- 1. Where the project stands ---------------- */

    private function whereItStands(Project $project, ProjectGrant $grant): BriefSection
    {
        $lines = [];

        $accepted = ScheduleVersion::query()
            ->where('project_id', $project->id)
            ->where('review_status', 'accepted')
            ->orderByDesc('data_date')
            ->first();

        $latest = ScheduleVersion::query()
            ->where('project_id', $project->id)
            ->orderByDesc('data_date')
            ->first();

        if ($accepted === null) {
            $this->refusals[] = new Refusal(
                question: 'Where does the schedule say this project stands?',
                reason: $latest === null
                    ? 'No schedule version has been ingested for this project.'
                    : 'The newest schedule version carries no acceptance disposition. A submitter\'s label — including the word "baseline" — is not an acceptance, and ZecoCM will not report position from a version nobody has accepted.',
                whatWouldFixIt: $latest === null
                    ? 'Upload a schedule version.'
                    : 'Record a formal accept or reject disposition on the newest version.',
                route: 'scheduleintel',
            );
        } else {
            $dataDate = $accepted->data_date ? new \DateTimeImmutable((string) $accepted->data_date) : null;
            $lines[] = BriefLine::make(
                text: 'The accepted schedule of record is "'.$accepted->label.'", data date '.($dataDate?->format('j M Y') ?? 'not stated').'.',
                classification: BriefLine::FACT,
                citations: [$this->cite('schedule_version', $accepted->label, $accepted->id, 'scheduleintel')],
                freshness: Freshness::cadence('schedule', $dataDate, 45 * 24, 'to be updated monthly'),
                route: 'scheduleintel',
            );

            if ($latest !== null && $latest->id !== $accepted->id) {
                $lines[] = BriefLine::make(
                    text: 'A newer version, "'.$latest->label.'", is on the register and has not been accepted or rejected. Position below is still read from the accepted version.',
                    classification: BriefLine::FACT,
                    citations: [$this->cite('schedule_version', $latest->label, $latest->id, 'scheduleintel')],
                    freshness: Freshness::eventDriven('schedule register', $latest->submitted_at),
                    route: 'scheduleintel',
                );
            }
        }

        $run = AnalysisRun::query()
            ->where('project_id', $project->id)
            ->where('status', 'complete')
            ->orderByDesc('finished_at')
            ->first();

        if ($run !== null) {
            $count = ScheduleDelta::query()->where('analysis_run_id', $run->id)->count();
            $lines[] = BriefLine::make(
                text: 'The most recent completed comparison recorded '.$count.' change'.($count === 1 ? '' : 's').' between the two versions it examined.',
                classification: BriefLine::CALC,
                citations: [$this->cite('analysis_run', 'run '.$run->id, $run->id, 'scheduleintel')],
                freshness: Freshness::eventDriven('analysis', $run->finished_at),
                workingOut: 'Count of delta rows written by analysis run '.$run->id.'. Runs are append-only; re-running appends a superseding run and erases nothing.',
                route: 'scheduleintel',
                restsOnAcceptedRecord: $accepted !== null,
            );
        }

        return new BriefSection('standing', 'Where this project stands', $lines,
            'ZecoCM has nothing it can truthfully say about schedule position yet. See the refusals below.');
    }

    /* ---------------- 2. What changed ---------------- */

    private function whatChanged(Project $project): BriefSection
    {
        $lines = [];
        $since = new \DateTimeImmutable('-1 day');

        $newRfis = Rfi::query()->where('project_id', $project->id)->where('created_at', '>=', $since)->count();
        $newSubs = Submittal::query()->where('project_id', $project->id)->where('created_at', '>=', $since)->count();
        $newDailies = DailyReport::query()->where('project_id', $project->id)->where('created_at', '>=', $since)->count();

        foreach ([
            ['RFI', $newRfis, 'rfis'],
            ['submittal', $newSubs, 'submittals'],
            ['daily report', $newDailies, 'daily'],
        ] as [$label, $n, $route]) {
            if ($n > 0) {
                $lines[] = BriefLine::make(
                    text: $n.' '.$label.($n === 1 ? '' : 's').' entered the register in the last 24 hours.',
                    classification: BriefLine::CALC,
                    citations: [$this->cite('register', ucfirst($label).' register', $project->id, $route)],
                    freshness: Freshness::eventDriven($label.' register'),
                    workingOut: 'Count of '.$label.' records on this project created on or after '.$since->format('j M Y H:i').'.',
                    route: $route,
                );
            }
        }

        return new BriefSection('changed', 'What changed since yesterday', $lines,
            'Nothing entered this project\'s registers in the last 24 hours. That is the finding, not a gap.');
    }

    /* ---------------- 3. What needs a decision ---------------- */

    private function whatNeedsADecision(Project $project, \DateTimeImmutable $now): BriefSection
    {
        $lines = [];
        $today = new \DateTimeImmutable($now->format('Y-m-d'));

        foreach ([
            ['submittal', ['submittal_review'], Submittal::class, 'submitted_at', 'number', 'title', 'submittals', ['no_exceptions', 'rejected']],
            ['RFI', ['rfi_response', 'rfi'], Rfi::class, 'raised_at', 'number', 'subject', 'rfis', ['answered']],
        ] as [$label, $clockNames, $model, $anchorField, $refField, $titleField, $route, $closedStatuses]) {
            $clock = null;
            foreach ($clockNames as $n) {
                try {
                    $clock = $project->clock($n);
                    break;
                } catch (\Throwable) {
                }
            }
            if ($clock === null) {
                $this->refusals[] = new Refusal(
                    question: 'Which '.$label.'s are late?',
                    reason: 'This project has no '.$label.' response clock configured, so ZecoCM cannot compute a due date. It will not assume a standard period on your behalf.',
                    whatWouldFixIt: 'Set the '.$label.' clock in project settings from the contract.',
                    route: 'projectsettings',
                );

                continue;
            }

            $open = $model::query()
                ->where('project_id', $project->id)
                ->whereNotIn('status', $closedStatuses)
                ->limit(200)->get();

            foreach ($open as $record) {
                $anchorRaw = $record->{$anchorField};
                if (! $anchorRaw) {
                    continue;
                }
                $anchor = new \DateTimeImmutable((string) $anchorRaw);
                $due = $clock->dueFrom($anchor);
                $late = (int) $clock->daysLate($anchor, $today);
                if ($late <= 0) {
                    continue;
                }
                $lines[] = BriefLine::make(
                    text: $label.' '.$record->{$refField}.' — "'.$record->{$titleField}.'" — passed its contract response date on '.$due->format('j M Y').', '.$late.' working day'.($late === 1 ? '' : 's').' ago.',
                    classification: BriefLine::CALC,
                    citations: [$this->cite(strtolower($label), (string) $record->{$refField}, $record->id, $route)],
                    freshness: Freshness::eventDriven($label.' register', $record->updated_at),
                    workingOut: 'Anchor '.$anchor->format('Y-m-d').' + the project\'s own '.$label.' clock → due '.$due->format('Y-m-d').'; '.$late.' working days elapsed since. ZecoCM states the position and does not attribute responsibility for it.',
                    route: $route,
                );
            }
        }

        $unsigned = DailyReport::query()->where('project_id', $project->id)->where('locked', false)->limit(50)->get();
        foreach ($unsigned as $d) {
            $lines[] = BriefLine::make(
                text: 'The daily report for '.$d->report_date.' is drafted but not sealed. Until it is signed it is not evidence.',
                classification: BriefLine::POLICY,
                citations: [$this->cite('daily_report', (string) $d->report_date, $d->id, 'daily')],
                freshness: Freshness::cadence('daily reports', $d->created_at, 48, 'every working day'),
                route: 'daily',
            );
        }

        usort($lines, fn (BriefLine $a, BriefLine $b) => $a->classification <=> $b->classification);

        return new BriefSection('decisions', 'What needs a decision today', $lines,
            'No record on this project is past its contract clock and nothing is waiting on a signature.');
    }

    /* ---------------- 4. What is coming ---------------- */

    private function whatIsComing(Project $project, \DateTimeImmutable $now): BriefSection
    {
        $lines = [];

        if ($project->lat === null || $project->lng === null) {
            $this->refusals[] = new Refusal(
                question: 'What weather is coming to this site?',
                reason: 'This project has no verified coordinates on its record, and ZecoCM will not report weather for a guessed location.',
                whatWouldFixIt: 'Set the project coordinates from the contract documents.',
                route: 'projectsettings',
            );

            return new BriefSection('coming', 'What is coming at us', $lines,
                'ZecoCM has no forward-looking signal it can source for this project. See the refusals below.');
        }

        $ten = $this->weather?->tenDayPrecipProbability((float) $project->lat, (float) $project->lng);
        if ($ten === null) {
            $this->refusals[] = new Refusal(
                question: 'What weather is coming to this site?',
                reason: 'The weather source did not answer. ZecoCM shows no forecast rather than a cached one presented as current.',
                whatWouldFixIt: 'Retry later; the source is open-meteo.com.',
                route: 'dashboard',
            );

            return new BriefSection('coming', 'What is coming at us', $lines,
                'No forward-looking signal could be sourced at this moment.');
        }

        $wet = array_values(array_filter($ten, fn ($d) => ($d['precip_probability'] ?? 0) >= 50));
        if ($wet !== []) {
            $days = implode(', ', array_map(fn ($d) => $d['date'].' ('.$d['precip_probability'].'%)', array_slice($wet, 0, 5)));
            $lines[] = BriefLine::make(
                text: count($wet).' of the next 10 days carry a 50% or greater chance of precipitation at this site: '.$days.'.',
                classification: BriefLine::FACT,
                citations: [$this->cite('weather', 'open-meteo.com forecast for '.$project->lat.', '.$project->lng, 0, 'dashboard')],
                freshness: Freshness::cadence('weather', $now, 6, 'hourly'),
                workingOut: 'Days from the 10-day forecast whose precipitation probability is at or above 50%. ZecoCM reports the forecast; it does not convert it into a delay claim.',
                route: 'dashboard',
            );
        }

        return new BriefSection('coming', 'What is coming at us', $lines,
            'No day in the next 10 carries a 50% or greater chance of precipitation at this site.');
    }

    /** @return array<string,mixed> */
    private function cite(string $kind, string $ref, int $id, string $route): array
    {
        return ['kind' => $kind, 'ref' => $ref, 'id' => $id, 'route' => $route];
    }
}
