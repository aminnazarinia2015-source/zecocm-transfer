<?php

namespace App\Domain\Brief;

/**
 * How old the newest evidence under a line is, judged against that source's OWN
 * expected cadence. Age alone is not staleness: an RFI register is event-driven and
 * is never stale merely because nothing happened.
 */
final class Freshness
{
    private function __construct(
        public readonly ?string $asOf,
        public readonly string $source,
        public readonly bool $stale,
        public readonly string $staleReason,
        public readonly ?int $ageHours,
    ) {}

    public static function eventDriven(string $source, ?\DateTimeInterface $newest = null): self
    {
        return new self($newest?->format(DATE_ATOM), $source, false, '', self::hours($newest));
    }

    public static function cadence(string $source, ?\DateTimeInterface $newest, int $staleAfterHours, string $cadenceLabel): self
    {
        if ($newest === null) {
            return new self(null, $source, true, "no {$source} evidence exists yet", null);
        }
        $age = self::hours($newest);
        $stale = $age !== null && $age > $staleAfterHours;

        return new self(
            $newest->format(DATE_ATOM),
            $source,
            $stale,
            $stale ? "the newest {$source} evidence is ".self::human($age)." old; this source is expected {$cadenceLabel}" : '',
            $age,
        );
    }

    private static function hours(?\DateTimeInterface $t): ?int
    {
        if ($t === null) {
            return null;
        }

        return (int) floor((time() - $t->getTimestamp()) / 3600);
    }

    private static function human(?int $hours): string
    {
        if ($hours === null) {
            return 'an unknown amount of time';
        }
        if ($hours < 48) {
            return $hours.' hour'.($hours === 1 ? '' : 's');
        }

        return intdiv($hours, 24).' days';
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'as_of' => $this->asOf,
            'source' => $this->source,
            'stale' => $this->stale,
            'stale_reason' => $this->staleReason,
            'age_hours' => $this->ageHours,
        ];
    }
}
