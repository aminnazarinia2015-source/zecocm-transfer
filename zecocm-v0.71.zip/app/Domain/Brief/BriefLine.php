<?php

namespace App\Domain\Brief;

/**
 * One sentence of the Daily Project Success Brief.
 *
 * A line may not exist without at least one citation. Its classification uses the same
 * epistemic vocabulary as the Decision Envelope, so a party's claim is never rendered
 * with the authority of a sealed record or a computation.
 */
final class BriefLine
{
    public const FACT = 'fact';

    public const CALC = 'deterministic_calculation';

    public const ASSERTION = 'assertion';

    public const POLICY = 'policy';

    /**
     * @param  array<int,array<string,mixed>>  $citations
     */
    private function __construct(
        public readonly string $text,
        public readonly string $classification,
        public readonly array $citations,
        public readonly Freshness $freshness,
        public readonly string $confidence,
        public readonly string $confidenceReason,
        public readonly ?string $workingOut,
        public readonly ?string $route,
    ) {}

    /**
     * @param  array<int,array<string,mixed>>  $citations
     */
    public static function make(
        string $text,
        string $classification,
        array $citations,
        Freshness $freshness,
        ?string $workingOut = null,
        ?string $route = null,
        bool $restsOnAcceptedRecord = true,
    ): self {
        if ($citations === []) {
            throw new \LogicException('A brief line cannot exist without a citation. Refuse instead.');
        }

        [$level, $reason] = self::confidence($classification, $freshness, $restsOnAcceptedRecord);

        return new self($text, $classification, array_values($citations), $freshness, $level, $reason, $workingOut, $route);
    }

    /** @return array{0:string,1:string} */
    private static function confidence(string $classification, Freshness $freshness, bool $accepted): array
    {
        if ($classification === self::ASSERTION) {
            return ['low', 'low - this is a party\'s statement, recorded and attributed, not adopted by ZecoCM'];
        }
        if (! $accepted) {
            return ['low', 'low - this calculation rests on a schedule version that has no acceptance disposition'];
        }
        if ($freshness->stale) {
            return ['medium', 'medium - '.$freshness->staleReason];
        }
        if ($classification === self::POLICY) {
            return ['medium', 'medium - a contract requirement, read as written; interpretation is not ZecoCM\'s to make'];
        }

        return ['high', 'high - sealed evidence within its expected cadence'];
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'text' => $this->text,
            'classification' => $this->classification,
            'citations' => $this->citations,
            'freshness' => $this->freshness->toArray(),
            'confidence' => $this->confidence,
            'confidence_reason' => $this->confidenceReason,
            'working_out' => $this->workingOut,
            'route' => $this->route,
        ];
    }
}
