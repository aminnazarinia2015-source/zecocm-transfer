<?php

namespace App\Domain\Brief;

/**
 * Something the brief will NOT say today, why, and the exact route that would let it.
 * Refusals are a rendered section, never a silent omission.
 */
final class Refusal
{
    public function __construct(
        public readonly string $question,
        public readonly string $reason,
        public readonly ?string $whatWouldFixIt = null,
        public readonly ?string $route = null,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'question' => $this->question,
            'reason' => $this->reason,
            'what_would_fix_it' => $this->whatWouldFixIt,
            'route' => $this->route,
        ];
    }
}
