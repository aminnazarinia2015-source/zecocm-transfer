<?php

namespace App\Domain\Security;

/**
 * SEC-5: the verdict `SecureUploadGate::admit()` returns. Never a bare bool -
 * a rejection always carries a machine-readable reason, because "invalid
 * file" told to a steward or logged for an incident review is not the same
 * thing as "extension_not_allowed" or "detected_type_not_allowed".
 */
final class UploadDecision
{
    private function __construct(
        public readonly bool $admitted,
        public readonly ?string $rejectionReason,
        public readonly string $safeName,
        public readonly ?string $extension,
        public readonly string $detectedMime,
    ) {}

    public static function admitted(string $safeName, string $extension, string $detectedMime): self
    {
        return new self(true, null, $safeName, $extension, $detectedMime);
    }

    public static function rejected(string $reason, string $safeName, string $detectedMime): self
    {
        return new self(false, $reason, $safeName, null, $detectedMime);
    }
}
