<?php

namespace App\Domain\Security;

/**
 * SEC-5: a parser that can hang on crafted input is a denial-of-service
 * surface, and this codebase invokes two external binaries directly on
 * uploaded bytes - `pdftotext` (text extraction) and a configurable malware
 * scanner - with no bound on either before this class existed. Both used
 * `proc_open()` and blocked on `stream_get_contents()` until the child
 * exited, however long that took.
 *
 * This wraps any external command with a wall-clock deadline. On timeout the
 * process is terminated and the caller gets a result that says so explicitly
 * - never empty output silently indistinguishable from "nothing found".
 */
final class BoundedProcess
{
    public const OK = 'ok';
    public const TIMEOUT = 'timeout';
    public const FAILED_TO_START = 'failed_to_start';

    /**
     * @param  list<string>  $command
     * @return array{status: string, exitCode: ?int, stdout: string}
     */
    public static function run(array $command, int $timeoutSeconds, ?string $stdin = null): array
    {
        // A missing binary makes proc_open() raise a PHP warning as well as
        // returning false; that failure is already handled explicitly below
        // via is_resource(), so the warning is suppressed here rather than
        // left to surface as an unhandled error in strict error-reporting
        // contexts (this codebase's test suite among them).
        $process = @proc_open($command, [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ], $pipes);

        if (! is_resource($process)) {
            return ['status' => self::FAILED_TO_START, 'exitCode' => null, 'stdout' => ''];
        }

        if ($stdin !== null) {
            fwrite($pipes[0], $stdin);
        }
        fclose($pipes[0]);

        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $deadline = microtime(true) + $timeoutSeconds;
        $stdout = '';

        while (true) {
            $status = proc_get_status($process);
            $stdout .= (string) stream_get_contents($pipes[1]);
            // Discard stderr - draining it is enough to stop the pipe buffer
            // from filling and stalling the child.
            stream_get_contents($pipes[2]);

            if (! $status['running']) {
                fclose($pipes[1]);
                fclose($pipes[2]);
                $exitCode = proc_close($process);

                return ['status' => self::OK, 'exitCode' => $exitCode, 'stdout' => trim($stdout)];
            }

            if (microtime(true) >= $deadline) {
                // SIGTERM first; the loop below gives it a moment before the
                // hard kill so a well-behaved child can exit cleanly.
                proc_terminate($process);
                usleep(200_000);
                $status = proc_get_status($process);
                if ($status['running']) {
                    proc_terminate($process, 9);
                }
                fclose($pipes[1]);
                fclose($pipes[2]);
                proc_close($process);

                return ['status' => self::TIMEOUT, 'exitCode' => null, 'stdout' => ''];
            }

            usleep(20_000);
        }
    }
}
