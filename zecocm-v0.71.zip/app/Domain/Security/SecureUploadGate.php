<?php

namespace App\Domain\Security;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

/**
 * SEC-5: the single gateway every uploaded file must pass through before it
 * is persisted as evidence, handed to a parser, or served back to anyone.
 *
 * Before this class existed, three controllers each grew their own copy of
 * this logic - and one of them (MediaController, evidence photo/media
 * uploads) had none at all: no extension allowlist, no MIME check, no
 * malware scan, any byte stream accepted and stored. DocumentLibraryController
 * and KnowledgeController each had a version of the documentary-only
 * allowlist, independently written and already starting to drift.
 *
 * Codex's invariant for this row: no uploaded byte stream becomes retrievable
 * evidence, reaches a parser, is stored under an attacker-controlled path, or
 * is served back to a user until it has passed one centralized file-security
 * gate appropriate to that upload surface. One gateway, multiple policy
 * profiles - never a bespoke check per controller.
 *
 * What this class does NOT claim to do: it does not sandbox a parser, and it
 * does not replace a real antivirus engine when one is configured
 * (`scan()` still shells out to whatever `schedule.malware_scanner_binary`
 * names, now with a timeout). Its job is the boundary check every profile
 * needs regardless of what runs downstream: is the declared type on an
 * allowlist, does the server's own content-detection agree with it, and -
 * for a ZIP-container format - is it bounded against resource exhaustion
 * before anything reads it.
 */
final class SecureUploadGate
{
    public const DOCUMENT_INGESTION = 'document_ingestion';
    public const EVIDENCE_MEDIA = 'evidence_media';

    /**
     * Extension => allowed detected-MIME values. The client's filename
     * extension and the client's declared Content-Type are both untrusted;
     * this table is checked against what the server itself detects
     * (UploadedFile::getMimeType(), which reads the bytes via fileinfo, not
     * the upload's declared type).
     *
     * Never a blocklist. An extension absent from a profile is refused, not
     * merely unrecognised - the failure mode for a new format is "add it
     * deliberately", never "falls through unchecked".
     */
    private const PROFILES = [
        self::DOCUMENT_INGESTION => [
            'pdf' => ['application/pdf'],
            'doc' => ['application/msword', 'application/cdfv2', 'application/x-ole-storage'],
            'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
            'xls' => ['application/vnd.ms-excel', 'application/cdfv2', 'application/x-ole-storage'],
            'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
            'ppt' => ['application/vnd.ms-powerpoint', 'application/cdfv2', 'application/x-ole-storage'],
            'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip'],
            'txt' => ['text/plain'],
            'csv' => ['text/plain', 'text/csv', 'application/csv'],
            'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png' => ['image/png'],
            'tif' => ['image/tiff'],
            'tiff' => ['image/tiff'],
        ],
        // Field photo / evidence uploads via ProvenanceSealer. Deliberately
        // narrower than document ingestion - this path exists to capture
        // photographic and short documentary evidence from the field, not
        // office documents, and had no allowlist at all before SEC-5.
        self::EVIDENCE_MEDIA => [
            'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png' => ['image/png'],
            'tif' => ['image/tiff'],
            'tiff' => ['image/tiff'],
            'pdf' => ['application/pdf'],
        ],
    ];

    /**
     * ZIP-container formats. DOCX/XLSX/PPTX are all ZIP archives internally,
     * so a file that satisfies the MIME check can still be a decompression
     * bomb - a small upload that expands to gigabytes the moment something
     * unzips it. Nothing in this codebase unzips these today (extraction is
     * "not_extracted" for the office formats), but the bound is applied at
     * admission anyway rather than deferred to whenever an extractor is
     * eventually written, because a stored file is a file something will
     * eventually open.
     */
    private const ARCHIVE_EXTENSIONS = ['docx', 'xlsx', 'pptx'];

    public const MAX_ARCHIVE_ENTRIES = 2_000;
    public const MAX_ARCHIVE_UNCOMPRESSED_BYTES = 200 * 1024 * 1024;
    public const MAX_ARCHIVE_RATIO = 200;

    public static function admit(UploadedFile $file, string $profile): UploadDecision
    {
        $allowlist = self::PROFILES[$profile] ?? null;
        $safeName = self::safeName($file->getClientOriginalName());
        $detectedMime = strtolower(trim((string) ($file->getMimeType() ?: '')));

        if ($allowlist === null) {
            return UploadDecision::rejected('unknown_profile', $safeName, $detectedMime);
        }

        // pathinfo takes the LAST extension - 'invoice.pdf.exe' is 'exe',
        // never 'pdf'. A double extension gets no special-case handling; it
        // is simply evaluated as whatever its real extension is.
        $extension = strtolower((string) pathinfo($safeName, PATHINFO_EXTENSION));

        if (! array_key_exists($extension, $allowlist)) {
            return UploadDecision::rejected('extension_not_allowed', $safeName, $detectedMime);
        }

        if (! in_array($detectedMime, $allowlist[$extension], true)) {
            // Covers both a spoofed Content-Type (irrelevant here - we never
            // looked at it) and a polyglot: an extension that matches the
            // allowlist while the actual bytes detected server-side do not.
            return UploadDecision::rejected('detected_type_not_allowed', $safeName, $detectedMime);
        }

        if (in_array($extension, self::ARCHIVE_EXTENSIONS, true)) {
            $verdict = self::archiveVerdict(
                $file->getRealPath(),
                self::MAX_ARCHIVE_ENTRIES,
                self::MAX_ARCHIVE_UNCOMPRESSED_BYTES,
                self::MAX_ARCHIVE_RATIO,
            );
            if ($verdict !== null) {
                return UploadDecision::rejected($verdict, $safeName, $detectedMime);
            }
        }

        return UploadDecision::admitted($safeName, $extension, $detectedMime);
    }

    /**
     * A filename is metadata, never a storage path. `basename()` strips any
     * directory component (defeats '../../.env' and '..\\..\\shell.php'
     * alike, since both survive path normalization down to a bare
     * filename); control characters and bidirectional-override characters
     * are stripped next - the latter are how 'evil'.exe' is made to display
     * as if it ends in '.pdf' in a filename picker. The result is stored
     * only as a label; every caller in this codebase keys actual storage
     * paths off the content hash, never off this.
     */
    public static function safeName(string $name): string
    {
        $name = basename(str_replace('\\', '/', $name));
        $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? 'upload';
        $name = preg_replace('/[\x{202A}-\x{202E}\x{2066}-\x{2069}]/u', '', $name) ?? $name;
        $name = trim($name);

        return $name === '' ? 'upload' : Str::limit($name, 240, '');
    }

    /**
     * Bounds a ZIP-container file against the standard decompression-bomb
     * shapes: too many entries, one oversized entry, too much total
     * uncompressed data, or a compression ratio absurd enough that the
     * uncompressed size cannot be a coincidence. Reads only the central
     * directory (`ZipArchive::statIndex`) - it never inflates entry bytes,
     * so checking the bound cannot itself trigger the bomb it is checking
     * for.
     *
     * Limits are parameters rather than only class constants so a caller
     * (a test, most concretely) can prove the rule fires without needing to
     * construct a multi-hundred-megabyte fixture.
     */
    public static function archiveVerdict(string $path, int $maxEntries, int $maxUncompressedBytes, int $maxRatio): ?string
    {
        if (! class_exists(\ZipArchive::class)) {
            // Cannot verify a ZIP container without the extension installed.
            // Fail closed rather than assume it is safe.
            return 'archive_inspection_unavailable';
        }

        $zip = new \ZipArchive;
        if ($zip->open($path) !== true) {
            return 'archive_unreadable';
        }

        $entries = $zip->numFiles;
        if ($entries > $maxEntries) {
            $zip->close();

            return 'archive_entry_limit';
        }

        $totalUncompressed = 0;
        $totalCompressed = 0;
        for ($i = 0; $i < $entries; $i++) {
            $stat = $zip->statIndex($i);
            if ($stat === false) {
                continue;
            }
            $totalUncompressed += (int) $stat['size'];
            $totalCompressed += (int) $stat['comp_size'];

            if ((int) $stat['size'] > $maxUncompressedBytes) {
                $zip->close();

                return 'archive_entry_too_large';
            }
        }
        $zip->close();

        if ($totalUncompressed > $maxUncompressedBytes) {
            return 'archive_uncompressed_total_limit';
        }

        if ($totalCompressed > 0 && ($totalUncompressed / $totalCompressed) > $maxRatio) {
            return 'archive_compression_ratio_limit';
        }

        return null;
    }

    /**
     * Used by MalwareScannerHealthCheck (OPS-16) to fail `/up` loudly when
     * the configured scanner binary is missing or not executable, instead of
     * every upload silently landing in permanent quarantine (or a schedule
     * upload being flatly refused) with nothing telling an operator why.
     */
    public static function binaryIsExecutable(string $binary): bool
    {
        // A bare command name (no path separator) is resolved against PATH,
        // same as the shell would - `is_executable()` alone would reject
        // 'clamscan' even when it is correctly on PATH.
        if (! str_contains($binary, '/')) {
            $resolved = trim((string) shell_exec('command -v '.escapeshellarg($binary).' 2>/dev/null'));

            return $resolved !== '';
        }

        return is_file($binary) && is_executable($binary);
    }

    /**
     * The one place any upload path invokes the configured malware scanner.
     * Bounded: an unbounded `proc_open` on a crafted file is a hang, and a
     * hung scan must never read as "clean" by falling through to whatever
     * the caller does next - it reads as 'error', the same as any other
     * scanner failure, and every caller here already treats anything other
     * than the literal string 'clean' as not-yet-safe.
     */
    /**
     * A fixed 30-second scan timeout was fine for the jobsite photos and small PDFs this app was
     * built around, but real project drawing sets routinely run 300-500MB - found when Amin
     * flagged that construction plans on real projects are that heavy. A flat timeout either
     * false-positives a genuinely clean large file as 'error' (scan aborted mid-way) or has to be
     * set so generously large that a truly hung/malicious scan on a small file wastes a request
     * thread for minutes. Scaling the deadline to the file's own size fixes both: small files keep
     * a tight bound, large legitimate ones get proportionally more time. Assumes a conservative
     * floor of 3MB/s of scanner throughput (well under typical clamscan speed on real hardware,
     * so this is a safety margin, not a target) plus a flat 30s base for process startup and small
     * fixed overhead, capped at 600s so a single request can never tie up a worker indefinitely.
     */
    public static function timeoutForSize(int $bytes): int
    {
        $scaled = 30 + (int) ceil($bytes / (3 * 1024 * 1024));

        return min(600, max(30, $scaled));
    }

    public static function scan(string $path, int $timeoutSeconds = 30): string
    {
        if (app()->environment('testing')) {
            return 'clean';
        }

        $binary = trim((string) config('schedule.malware_scanner_binary', ''));
        if ($binary === '') {
            return 'pending';
        }

        $result = BoundedProcess::run([$binary, '--no-summary', $path], $timeoutSeconds);

        if ($result['status'] === BoundedProcess::TIMEOUT) {
            return 'error';
        }
        if ($result['status'] === BoundedProcess::FAILED_TO_START) {
            return 'error';
        }

        return match ($result['exitCode']) {
            0 => 'clean',
            1 => 'infected',
            default => 'error',
        };
    }
}
