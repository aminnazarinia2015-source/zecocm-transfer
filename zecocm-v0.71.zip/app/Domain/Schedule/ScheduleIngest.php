<?php

namespace App\Domain\Schedule;

use App\Domain\Provenance\CaptureClocks;
use App\Domain\Provenance\ProvenanceSealer;
use App\Domain\Security\SecureUploadGate;
use App\Models\MediaItem;
use App\Models\ScheduleActivity;
use App\Models\ScheduleActivityCalendarAssignment;
use App\Models\ScheduleActivityRelationship;
use App\Models\ScheduleActivityResource;
use App\Models\ScheduleCalendar;
use App\Models\ScheduleCalendarException;
use App\Models\ScheduleCalendarExceptionPeriod;
use App\Models\ScheduleCalendarWorkingPeriod;
use App\Models\ScheduleVersion;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

final class ScheduleIngest
{
    public function __construct(
        private readonly ScheduleUploadGuard $guard,
        private readonly SpreadsheetScheduleParser $parser,
        private readonly ScheduleDispositionService $dispositions,
    ) {}

    /** @param array<string,mixed> $metadata */
    public function ingest(UploadedFile $file, ProjectGrant $grant, array $metadata): ScheduleVersion
    {
        $scan = $this->guard->inspect($file);
        $parsed = $this->parser->parse($file);
        $this->validateGraphReferences($parsed);

        $bytes = file_get_contents($file->getRealPath());
        if ($bytes === false) {
            throw new UnsafeScheduleUpload('The uploaded schedule could not be read after verification.');
        }

        $sealer = ProvenanceSealer::current();
        $sha256 = $sealer->hashMedia($bytes);
        $storagePath = 'media/'.substr($sha256, 0, 2).'/'.$sha256;
        if (! Storage::exists($storagePath) && ! Storage::put($storagePath, $bytes)) {
            throw new \RuntimeException('The verified schedule could not be stored.');
        }

        $now = now();
        $sealed = $sealer->seal(
            mediaHash: $sha256,
            context: [
                'purpose' => 'schedule_version_source',
                'tenant_id' => $grant->project->tenant_id,
                'project_id' => $grant->project->id,
                'captured_by' => $grant->userId,
                'source_format' => strtolower($file->getClientOriginalExtension()),
            ],
            capture: new CaptureClocks($now->toDateTimeImmutable(), 0.0),
            serverNow: $now->toDateTimeImmutable(),
            monotonicAtTransmit: 0.0,
        );

        return DB::transaction(function () use ($file, $grant, $metadata, $parsed, $scan, $sha256, $storagePath, $sealed, $sealer, $now) {
            $parent = null;
            if (! empty($metadata['parent_version_id'])) {
                $parent = ScheduleVersion::query()
                    ->where('project_id', $grant->project->id)
                    ->findOrFail((int) $metadata['parent_version_id']);
            }

            $media = MediaItem::create([
                'project_id' => $grant->project->id,
                'sha256' => $sha256,
                'storage_path' => $storagePath,
                'original_name' => SecureUploadGate::safeName($file->getClientOriginalName()),
                'mime' => (string) $file->getMimeType(),
                'bytes' => $file->getSize(),
                'provenance' => $sealed->payload,
                'provenance_signature' => $sealed->signature,
                'confidence' => $sealer->confidence($sealed),
                'captured_by' => $grant->userId,
            ]);

            $version = ScheduleVersion::create([
                'project_id' => $grant->project->id,
                'parent_version_id' => $parent?->id,
                'kind' => $metadata['kind'],
                'label' => $metadata['label'],
                'data_date' => $metadata['data_date'],
                'submitted_by_org' => ($metadata['submitted_by_org'] ?? null) ?: $grant->organization,
                'submitted_at' => $now,
                'review_status' => 'submitted',
                'source_file_media_id' => $media->id,
                'source_format' => strtolower($file->getClientOriginalExtension()),
                'narrative_text' => $metadata['narrative_text'] ?? null,
                'provisional' => false,
                'parser_name' => strtolower($file->getClientOriginalExtension()) === 'xml' ? 'MspdiScheduleParser' : 'SpreadsheetScheduleParser',
                'parser_version' => strtolower($file->getClientOriginalExtension()) === 'xml' ? MspdiScheduleParser::VERSION : config('schedule.parser_version'),
                'source_sha256' => $sha256,
                'row_count' => count($parsed->activities),
                'ingest_assumptions' => [
                    'items' => $parsed->assumptions,
                    'warnings' => $parsed->warnings,
                    'encoding' => $parsed->encoding,
                ],
                'security_scan' => $scan,
                'created_by' => $grant->userId,
            ]);

            $calendarByName = $this->storeCalendars($version, $parsed->calendars);
            $activityByCode = [];
            foreach ($parsed->activities as $row) {
                $activity = ScheduleActivity::create([
                    'schedule_version_id' => $version->id,
                    'canonical_id' => (string) Str::uuid(),
                    'activity_code' => $row['activity_code'],
                    'name' => $row['name'],
                    'wbs_path' => $row['wbs_path'],
                    'start_planned' => $row['start_planned'],
                    'finish_planned' => $row['finish_planned'],
                    'start_actual' => $row['start_actual'],
                    'finish_actual' => $row['finish_actual'],
                    'duration_minutes' => $row['duration_minutes'],
                    'total_float_minutes' => $row['total_float_minutes'],
                    'is_critical' => $row['is_critical'],
                    'is_near_critical' => $row['is_near_critical'],
                    'constraint_type' => $row['constraint_type'],
                    'constraint_at' => $row['constraint_at'],
                    'weather_sensitive' => $row['weather_sensitive'],
                    'header_path' => $row['header_path'],
                    'ingestion_confidence' => $row['ingestion_confidence'],
                    'confirmation_status' => $row['confirmation_status'],
                ]);
                $activityByCode[$row['activity_code']] = $activity;

                $calendar = $calendarByName[$row['calendar']] ?? null;
                if ($calendar === null) {
                    throw new \LogicException("Calendar '{$row['calendar']}' was not persisted.");
                }
                ScheduleActivityCalendarAssignment::create([
                    'schedule_activity_id' => $activity->id,
                    'schedule_calendar_id' => $calendar->id,
                    'relationship' => 'primary',
                ]);
                foreach ($row['resources'] as $resource) {
                    ScheduleActivityResource::create($resource + ['schedule_activity_id' => $activity->id]);
                }
            }

            foreach ($parsed->activities as $row) {
                foreach ($row['predecessors'] as $predecessor) {
                    ScheduleActivityRelationship::create([
                        'schedule_version_id' => $version->id,
                        'predecessor_activity_id' => $activityByCode[$predecessor['code']]->id,
                        'successor_activity_id' => $activityByCode[$row['activity_code']]->id,
                        'relationship_type' => $predecessor['type'],
                        'lag_minutes' => $predecessor['lag_minutes'],
                    ]);
                }
            }

            $this->dispositions->append(
                version: $version,
                eventType: 'schedule_version.submitted',
                disposition: 'submitted',
                payload: [
                    'source_sha256' => $sha256,
                    'source_format' => $version->source_format,
                    'row_count' => $version->row_count,
                    'parent_version_id' => $version->parent_version_id,
                    'assumptions' => $parsed->assumptions,
                ],
                actorId: $grant->userId,
            );

            return $version->fresh(['events', 'calendars', 'sourceFile']);
        });
    }

    /** @param list<array<string,mixed>> $definitions @return array<string,ScheduleCalendar> */
    private function storeCalendars(ScheduleVersion $version, array $definitions): array
    {
        $calendarByName = [];
        foreach ($definitions as $definition) {
            $calendar = ScheduleCalendar::create([
                'project_id' => $version->project_id,
                'schedule_version_id' => $version->id,
                'external_uid' => $definition['external_uid'],
                'name' => $definition['name'],
                'time_zone' => $definition['time_zone'],
                'minutes_per_day' => $definition['minutes_per_day'],
                'source_basis' => $definition['source_basis'],
            ]);
            $calendarByName[$definition['name']] = $calendar;
            foreach ($definition['periods'] as $period) {
                ScheduleCalendarWorkingPeriod::create($period + ['schedule_calendar_id' => $calendar->id]);
            }
            foreach ($definition['exceptions'] as $row) {
                $exception = ScheduleCalendarException::create([
                    'schedule_calendar_id' => $calendar->id,
                    'exception_date' => $row['date'],
                    'is_working' => $row['is_working'],
                    'label' => $row['label'],
                ]);
                foreach ($row['periods'] as $period) {
                    ScheduleCalendarExceptionPeriod::create($period + ['schedule_calendar_exception_id' => $exception->id]);
                }
            }
        }

        foreach ($definitions as $definition) {
            if (! empty($definition['inherits'])) {
                if (! isset($calendarByName[$definition['inherits']])) {
                    throw new UnsafeScheduleUpload("Calendar '{$definition['name']}' inherits an unknown calendar '{$definition['inherits']}'.");
                }
                ScheduleCalendar::query()->whereKey($calendarByName[$definition['name']]->id)->update([
                    'inherits_calendar_id' => $calendarByName[$definition['inherits']]->id,
                ]);
            }
        }

        return $calendarByName;
    }

    private function validateGraphReferences(ParsedSchedule $parsed): void
    {
        $codes = array_fill_keys(array_column($parsed->activities, 'activity_code'), true);
        foreach ($parsed->activities as $activity) {
            foreach ($activity['predecessors'] as $predecessor) {
                if (! isset($codes[$predecessor['code']])) {
                    throw new UnsafeScheduleUpload("Activity '{$activity['activity_code']}' references missing predecessor '{$predecessor['code']}'.");
                }
                if ($predecessor['code'] === $activity['activity_code']) {
                    throw new UnsafeScheduleUpload("Activity '{$activity['activity_code']}' cannot be its own predecessor.");
                }
            }
        }
    }
}
