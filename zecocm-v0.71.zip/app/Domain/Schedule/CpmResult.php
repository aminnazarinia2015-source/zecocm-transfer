<?php

namespace App\Domain\Schedule;

use DateTimeImmutable;

final readonly class CpmResult
{
    /**
     * @param  array<int|string,array<string,mixed>>  $metrics
     * @param  list<array<string,mixed>>  $issues
     * @param  list<string>  $assumptions
     */
    public function __construct(
        public array $metrics,
        public array $issues,
        public DateTimeImmutable $projectFinish,
        public array $assumptions,
    ) {}
}
