<?php

namespace App\Domain\Schedule;

final readonly class ParsedSchedule
{
    /**
     * @param  list<array<string,mixed>>  $activities
     * @param  list<array<string,mixed>>  $calendars
     * @param  list<string>  $assumptions
     * @param  list<string>  $warnings
     */
    public function __construct(
        public array $activities,
        public array $calendars,
        public array $assumptions,
        public array $warnings,
        public string $encoding,
    ) {}
}
