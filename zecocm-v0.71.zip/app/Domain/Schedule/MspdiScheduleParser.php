<?php

namespace App\Domain\Schedule;

use DateTimeImmutable;

/**
 * MS Project XML (MSPDI) parser producing the same ParsedSchedule contract as
 * SpreadsheetScheduleParser. Validated against Zeco's real PN 851 baseline and
 * Update 1 exports (117-task update: UID/WBS/outline, planned+actual dates,
 * durations, TotalSlack, Critical, PercentComplete, PredecessorLink type/lag,
 * three calendars with exceptions).
 *
 * Safety: entity/DTD declarations are rejected before parsing (XXE and
 * billion-laughs); the upload guard enforces size and mime before this runs.
 */
final class MspdiScheduleParser
{
    public const VERSION = '1.1.0';

    private const WEATHER_PATTERN = '/grad|excav|pour|concrete|pav|trench|roof|landscap|irrigat|drain|swppp|turf/i';

    /** Near-critical threshold: five 8-hour working days of float. */
    private const NEAR_CRITICAL_MINUTES = 5 * 480;

    public function parse(string $path): ParsedSchedule
    {
        $xml = file_get_contents($path);
        if ($xml === false || trim($xml) === '') {
            throw new UnsafeScheduleUpload('The schedule XML is unreadable or empty.');
        }
        if (stripos($xml, '<!DOCTYPE') !== false || stripos($xml, '<!ENTITY') !== false) {
            throw new UnsafeScheduleUpload('The schedule XML contains a DTD or entity declaration and was rejected for safety.');
        }

        $previous = libxml_use_internal_errors(true);
        $document = simplexml_load_string($xml, \SimpleXMLElement::class, LIBXML_NONET);
        libxml_use_internal_errors($previous);
        if ($document === false) {
            throw new UnsafeScheduleUpload('The schedule XML is malformed and could not be parsed.');
        }

        $namespaces = $document->getNamespaces(false);
        $root = $document->children($namespaces[''] ?? null);

        $assumptions = [];
        $warnings = [];

        [$calendars, $calendarNameByUid, $defaultCalendarName] = $this->calendars($root, $warnings);

        $uidToCode = [];
        $codesSeen = [];
        $rawTasks = [];
        foreach (($root->Tasks->Task ?? []) as $task) {
            $uid = trim((string) ($task->UID ?? ''));
            $name = trim((string) ($task->Name ?? ''));
            if ($uid === '' || $uid === '0' || $name === '') {
                continue;
            }
            $isSummary = trim((string) ($task->Summary ?? '')) === '1';
            $code = null;
            if (preg_match('/^([A-Z]{1,4}\d{2,6})\b/', $name, $match)) {
                $code = $match[1];
            }
            if ($code === null || isset($codesSeen[$code])) {
                $code = ($code !== null ? $code.'-' : 'UID').$uid;
            }
            $codesSeen[$code] = true;
            $uidToCode[$uid] = $code;
            $rawTasks[] = ['node' => $task, 'uid' => $uid, 'code' => $code, 'name' => $name, 'summary' => $isSummary];
        }
        if ($rawTasks === []) {
            throw new UnsafeScheduleUpload('No activity rows were found in the schedule XML.');
        }

        // Only non-summary rows become activities; links must land on them.
        $schedulableUids = [];
        foreach ($rawTasks as $raw) {
            if (! $raw['summary']) {
                $schedulableUids[$raw['uid']] = true;
            }
        }

        $activities = [];
        $headerStack = [];   // outline-level → summary name (drives header_path)
        foreach ($rawTasks as $raw) {
            $task = $raw['node'];
            $level = (int) trim((string) ($task->OutlineLevel ?? '0'));

            if ($raw['summary']) {
                $headerStack = array_slice($headerStack, 0, max(0, $level - 1), true);
                $headerStack[$level] = preg_replace('/\s+/', ' ', $raw['name']);
                continue;   // summaries become header paths, not activity rows
            }

            $plannedStart = $this->date((string) ($task->Start ?? ''));
            $plannedFinish = $this->date((string) ($task->Finish ?? ''));
            $duration = $this->isoDurationMinutes((string) ($task->Duration ?? ''));
            if ($duration === null && $plannedStart && $plannedFinish) {
                $elapsedDays = max(0, (int) $plannedStart->diff($plannedFinish)->days);
                $duration = $elapsedDays * 480;
                $assumptions['derived_duration'] = 'Missing durations were derived as elapsed calendar days multiplied by 480 minutes.';
            }
            if ($duration === null) {
                $warnings[] = "Activity '{$raw['code']}' has no duration and no date pair; recorded as zero duration.";
                $duration = 0;
            }

            $floatMinutes = $this->slackMinutes((string) ($task->TotalSlack ?? ''));
            $isCritical = trim((string) ($task->Critical ?? '')) === '1';
            $calendarUid = trim((string) ($task->CalendarUID ?? ''));
            $calendarName = $calendarNameByUid[$calendarUid] ?? $defaultCalendarName;

            $predecessors = [];
            foreach (($task->PredecessorLink ?? []) as $link) {
                $predUid = trim((string) ($link->PredecessorUID ?? ''));
                if (! isset($uidToCode[$predUid])) {
                    $warnings[] = "Activity '{$raw['code']}' references predecessor UID {$predUid} outside the activity set; the link was dropped.";
                    continue;
                }
                if (! isset($schedulableUids[$predUid])) {
                    // MS Project permits links to summary rows; clean CPM does not.
                    $warnings[] = "Activity '{$raw['code']}' links to summary-level task '{$uidToCode[$predUid]}'; the link was dropped and should be re-pointed to a schedulable activity.";
                    continue;
                }
                $predecessors[] = [
                    'code' => $uidToCode[$predUid],
                    'type' => $this->linkType((int) trim((string) ($link->Type ?? '1'))),
                    'lag_minutes' => $this->lagMinutes((string) ($link->LinkLag ?? '0'), (int) trim((string) ($link->LagFormat ?? '0'))),
                ];
            }

            $header = $headerStack === [] ? null : implode(' / ', array_slice($headerStack, 0, $level, true));

            $activities[] = [
                'activity_code' => $raw['code'],
                'name' => $raw['name'],
                'wbs_path' => trim((string) ($task->WBS ?? '')) ?: null,
                'start_planned' => $plannedStart,
                'finish_planned' => $plannedFinish,
                'start_actual' => $this->date((string) ($task->ActualStart ?? '')),
                'finish_actual' => $this->date((string) ($task->ActualFinish ?? '')),
                'duration_minutes' => $duration,
                'total_float_minutes' => $floatMinutes,
                'is_critical' => $isCritical,
                'is_near_critical' => ! $isCritical && $floatMinutes !== null && $floatMinutes >= 0 && $floatMinutes <= self::NEAR_CRITICAL_MINUTES,
                'calendar' => $calendarName,
                'constraint_type' => $this->constraintName((int) trim((string) ($task->ConstraintType ?? '0'))),
                'constraint_at' => $this->date((string) ($task->ConstraintDate ?? '')),
                'predecessors' => $predecessors,
                'resources' => [],
                'weather_sensitive' => (bool) preg_match(self::WEATHER_PATTERN, $raw['name']),
                'header_path' => $header,
                'ingestion_confidence' => 1.0,
                'confirmation_status' => 'confirmed',
            ];
        }

        if ($activities === []) {
            throw new UnsafeScheduleUpload('The schedule XML contained only summary rows - no schedulable activities.');
        }

        $statusDate = trim((string) ($root->StatusDate ?? ''));
        if ($statusDate !== '') {
            $assumptions['status_date'] = 'Source status date: '.$statusDate;
        }
        $assumptions['format'] = 'MS Project XML (MSPDI), parser '.self::VERSION;

        return new ParsedSchedule(
            activities: $activities,
            calendars: $calendars,
            assumptions: array_values($assumptions),
            warnings: $warnings,
            encoding: 'UTF-8 (MSPDI XML)',
        );
    }

    /**
     * @param  list<string>  $warnings
     * @return array{0: list<array<string,mixed>>, 1: array<string,string>, 2: string}
     */
    private function calendars(\SimpleXMLElement $root, array &$warnings): array
    {
        $definitions = [];
        $nameByUid = [];
        foreach (($root->Calendars->Calendar ?? []) as $calendar) {
            $uid = trim((string) ($calendar->UID ?? ''));
            $name = trim((string) ($calendar->Name ?? '')) ?: ('Calendar '.$uid);
            if (isset($definitions[$name])) {
                $name .= ' ('.$uid.')';
            }
            $nameByUid[$uid] = $name;

            $periods = [];
            foreach (($calendar->WeekDays->WeekDay ?? []) as $weekDay) {
                if (trim((string) ($weekDay->DayWorking ?? '')) !== '1') {
                    continue;
                }
                $dayType = (int) trim((string) ($weekDay->DayType ?? '0'));   // 1=Sun..7=Sat
                if ($dayType < 1 || $dayType > 7) {
                    continue;
                }
                $weekdayIso = $dayType === 1 ? 7 : $dayType - 1;               // ISO 1=Mon..7=Sun
                foreach (($weekDay->WorkingTimes->WorkingTime ?? []) as $time) {
                    $from = $this->timeOfDay((string) ($time->FromTime ?? ''));
                    $to = $this->timeOfDay((string) ($time->ToTime ?? ''));
                    if ($from !== null && $to !== null) {
                        $periods[] = ['weekday_iso' => $weekdayIso, 'starts_at' => $from, 'ends_at' => $to];
                    }
                }
            }

            $exceptions = [];
            foreach (($calendar->Exceptions->Exception ?? []) as $exception) {
                $fromRaw = trim((string) ($exception->TimePeriod->FromDate ?? ''));
                if ($fromRaw === '') {
                    continue;
                }
                $toRaw = trim((string) ($exception->TimePeriod->ToDate ?? '')) ?: $fromRaw;
                $working = trim((string) ($exception->DayWorking ?? '')) === '1';
                $label = trim((string) ($exception->Name ?? '')) ?: null;
                try {
                    $from = new DateTimeImmutable(substr($fromRaw, 0, 10));
                    $to = new DateTimeImmutable(substr($toRaw, 0, 10));
                } catch (\Throwable) {
                    $warnings[] = "Calendar '{$name}' has an exception with an unreadable date and it was skipped.";
                    continue;
                }
                $span = min(120, (int) $from->diff($to)->days);
                for ($i = 0; $i <= $span; $i++) {
                    $exceptions[] = [
                        'date' => $from->modify("+{$i} days")->format('Y-m-d'),
                        'is_working' => $working,
                        'label' => $label,
                        'periods' => [],
                    ];
                }
            }

            // De-duplicate exception dates (unique index on calendar+date).
            $byDate = [];
            foreach ($exceptions as $row) {
                $byDate[$row['date']] = $row;
            }

            $definitions[$name] = [
                'external_uid' => $uid !== '' ? $uid : $name,
                'name' => $name,
                'time_zone' => (string) config('app.timezone', 'UTC'),
                'minutes_per_day' => 480,
                'inherits' => null,
                'source_basis' => 'mspdi_calendar_element',
                'periods' => $periods,
                'exceptions' => array_values($byDate),
            ];
        }

        // Resolve inheritance by name after all calendars are known.
        foreach (($root->Calendars->Calendar ?? []) as $calendar) {
            $uid = trim((string) ($calendar->UID ?? ''));
            $baseUid = trim((string) ($calendar->BaseCalendarUID ?? ''));
            if ($baseUid !== '' && $baseUid !== '-1' && isset($nameByUid[$uid], $nameByUid[$baseUid]) && $nameByUid[$uid] !== $nameByUid[$baseUid]) {
                $definitions[$nameByUid[$uid]]['inherits'] = $nameByUid[$baseUid];
            }
        }

        $projectCalendarUid = trim((string) ($root->CalendarUID ?? ''));
        $defaultName = $nameByUid[$projectCalendarUid] ?? null;
        if ($defaultName === null) {
            $defaultName = 'Standard';
            if (! isset($definitions[$defaultName])) {
                $definitions[$defaultName] = $this->standardCalendar($defaultName);
                $warnings[] = 'The XML declared no usable project calendar; a standard 8-hour weekday calendar was synthesized.';
            }
        }

        return [array_values($definitions), $nameByUid, $defaultName];
    }

    /** @return array<string,mixed> */
    private function standardCalendar(string $name): array
    {
        $periods = [];
        foreach (range(1, 5) as $weekday) {
            $periods[] = ['weekday_iso' => $weekday, 'starts_at' => '08:00:00', 'ends_at' => '12:00:00'];
            $periods[] = ['weekday_iso' => $weekday, 'starts_at' => '13:00:00', 'ends_at' => '17:00:00'];
        }

        return [
            'external_uid' => $name,
            'name' => $name,
            'time_zone' => (string) config('app.timezone', 'UTC'),
            'minutes_per_day' => 480,
            'inherits' => null,
            'source_basis' => 'explicit_import_assumption',
            'periods' => $periods,
            'exceptions' => [],
        ];
    }

    private function date(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        try {
            return new DateTimeImmutable($value);
        } catch (\Throwable) {
            return null;
        }
    }

    private function timeOfDay(string $value): ?string
    {
        $value = trim($value);
        if (preg_match('/^(\d{2}:\d{2}:\d{2})/', $value, $match)) {
            return $match[1];
        }
        if (preg_match('/T(\d{2}:\d{2}:\d{2})/', $value, $match)) {
            return $match[1];
        }

        return null;
    }

    /** MSPDI durations look like PT2296H0M0S. */
    private function isoDurationMinutes(string $iso): ?int
    {
        if ($iso === '' || ! preg_match('/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/', trim($iso), $match)) {
            return null;
        }

        return ((int) ($match[1] ?? 0)) * 60 + (int) ($match[2] ?? 0);
    }

    /** TotalSlack arrives in tenths of minutes in MSPDI exports. */
    private function slackMinutes(string $raw): ?int
    {
        $raw = trim($raw);
        if ($raw === '' || ! is_numeric($raw)) {
            return null;
        }

        return intdiv((int) $raw, 10);
    }

    private function linkType(int $type): string
    {
        return [0 => 'FF', 1 => 'FS', 2 => 'SF', 3 => 'SS'][$type] ?? 'FS';
    }

    /** LinkLag is tenths of minutes; percent lag formats are unsupported and become zero. */
    private function lagMinutes(string $raw, int $format): int
    {
        $raw = trim($raw);
        if ($raw === '' || ! is_numeric($raw) || in_array($format, [19, 20], true)) {
            return 0;
        }

        return intdiv((int) $raw, 10);
    }

    private function constraintName(int $constraint): ?string
    {
        return [
            0 => null, 1 => 'ALAP', 2 => 'MSO', 3 => 'MFO',
            4 => 'SNET', 5 => 'SNLT', 6 => 'FNET', 7 => 'FNLT',
        ][$constraint] ?? null;
    }
}
