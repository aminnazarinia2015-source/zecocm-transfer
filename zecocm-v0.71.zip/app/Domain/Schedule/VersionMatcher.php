<?php

namespace App\Domain\Schedule;

use App\Models\ActivityMappingEdge;
use App\Models\ActivityMappingGroup;
use App\Models\ScheduleActivity;
use App\Models\ScheduleVersion;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;

final class VersionMatcher
{
    public function __construct(private readonly ActivityMatcher $matcher) {}

    /** @return Collection<int,ActivityMappingGroup> */
    public function ensureMappings(ScheduleVersion $from, ScheduleVersion $to)
    {
        $existing = ActivityMappingGroup::query()
            ->where('project_id', $from->project_id)
            ->where('from_version_id', $from->id)
            ->where('to_version_id', $to->id)
            ->where('confirmation_status', '!=', 'superseded')
            ->with('edges')
            ->get();
        if ($existing->isNotEmpty()) {
            return $existing;
        }

        $fromRows = ScheduleActivity::query()->where('schedule_version_id', $from->id)->get()->map->toArray()->all();
        $toRows = ScheduleActivity::query()->where('schedule_version_id', $to->id)->get()->map->toArray()->all();
        $matches = $this->matcher->match($fromRows, $toRows);

        DB::transaction(function () use ($from, $to, $matches): void {
            foreach ($matches as $match) {
                $group = ActivityMappingGroup::create([
                    'project_id' => $from->project_id,
                    'from_version_id' => $from->id,
                    'to_version_id' => $to->id,
                    'relation' => $match['relation'],
                    'confidence' => $match['confidence'],
                    'confirmation_status' => $match['confidence'] >= 0.80 ? 'auto_confirmed' : 'needs_review',
                    'source' => 'deterministic_matcher',
                ]);
                $fromIds = $match['from_ids'] ?: [null];
                $toIds = $match['to_ids'] ?: [null];
                foreach ($fromIds as $fromId) {
                    foreach ($toIds as $toId) {
                        ActivityMappingEdge::create([
                            'mapping_group_id' => $group->id,
                            'from_activity_id' => $fromId,
                            'to_activity_id' => $toId,
                            'edge_confidence' => $match['confidence'],
                        ]);
                    }
                }
            }
        });

        return ActivityMappingGroup::query()
            ->where('from_version_id', $from->id)
            ->where('to_version_id', $to->id)
            ->where('confirmation_status', '!=', 'superseded')
            ->with('edges')
            ->get();
    }

    /** @param list<int>|null $correctToActivityIds */
    public function confirm(ActivityMappingGroup $group, int $userId, ?array $correctToActivityIds = null): ActivityMappingGroup
    {
        abort_if($group->confirmation_status === 'confirmed', 409, 'A human-confirmed mapping is immutable; append a superseding mapping in a later workflow.');

        return DB::transaction(function () use ($group, $userId, $correctToActivityIds) {
            if ($correctToActivityIds !== null) {
                $valid = ScheduleActivity::query()
                    ->where('schedule_version_id', $group->to_version_id)
                    ->whereIn('id', $correctToActivityIds)
                    ->pluck('id')
                    ->map(fn ($id) => (int) $id)
                    ->all();
                sort($valid);
                $requested = array_values(array_unique(array_map('intval', $correctToActivityIds)));
                sort($requested);
                abort_unless($valid === $requested && $requested !== [], 422, 'Corrected targets must be activities in the destination version.');

                $fromIds = $group->edges()->whereNotNull('from_activity_id')->pluck('from_activity_id')->unique()->all() ?: [null];
                $group->forceFill([
                    'confirmation_status' => 'superseded',
                    'confirmed_by' => $userId,
                    'confirmed_at' => now(),
                ])->save();

                $replacement = ActivityMappingGroup::create([
                    'project_id' => $group->project_id,
                    'supersedes_group_id' => $group->id,
                    'from_version_id' => $group->from_version_id,
                    'to_version_id' => $group->to_version_id,
                    'relation' => $this->relationFor($fromIds, $requested),
                    'confidence' => 1.0,
                    'confirmation_status' => 'confirmed',
                    'source' => 'human_correction',
                    'confirmed_by' => $userId,
                    'confirmed_at' => now(),
                ]);
                foreach ($fromIds as $fromId) {
                    foreach ($requested as $toId) {
                        ActivityMappingEdge::create([
                            'mapping_group_id' => $replacement->id,
                            'from_activity_id' => $fromId,
                            'to_activity_id' => $toId,
                            'edge_confidence' => 1.0,
                        ]);
                    }
                }

                return $replacement->fresh('edges');
            }
            $group->confirmation_status = 'confirmed';
            $group->confirmed_by = $userId;
            $group->confirmed_at = now();
            $group->save();

            return $group->fresh('edges');
        });
    }

    /** @param list<int|null> $fromIds @param list<int> $toIds */
    private function relationFor(array $fromIds, array $toIds): string
    {
        $fromCount = count(array_filter($fromIds, fn ($id) => $id !== null));
        $toCount = count($toIds);

        return match (true) {
            $fromCount === 0 => 'added',
            $toCount === 0 => 'deleted',
            $fromCount === 1 && $toCount > 1 => 'split',
            $fromCount > 1 && $toCount === 1 => 'merge',
            default => 'matched',
        };
    }
}
