<?php

namespace App\Domain\Schedule;

use App\Models\AnalysisRun;
use App\Models\ScheduleActivity;
use App\Models\ScheduleDelta;
use App\Models\ScheduleVersion;
use Illuminate\Support\Facades\DB;

final class SchedulePresenter
{
    /**
     * Orders deltas by comparable normalized day magnitude (P0-1): elapsed wall-clock
     * minutes divide by 1440, working minutes by 480. Mixing the two raw values in one
     * sort overstated date movements 3x relative to duration/float movements.
     */
    public const NORMALIZED_DAYS_ORDER = "case
        when coalesce(magnitude_basis, case
            when delta_type in ('date','actuals','completion_movement') then 'elapsed_minutes'
            when delta_type = 'duration' then 'duration_work_minutes'
            when delta_type = 'float' then 'float_work_minutes'
            else null end) = 'elapsed_minutes' then abs(coalesce(magnitude_minutes,0)) / 1440.0
        when coalesce(magnitude_basis, case
            when delta_type = 'duration' then 'duration_work_minutes'
            when delta_type = 'float' then 'float_work_minutes'
            else null end) in ('duration_work_minutes','float_work_minutes') then abs(coalesce(magnitude_minutes,0)) / 480.0
        else null end desc";

    /** @return array<string,mixed> */
    public function version(ScheduleVersion $version, ProjectGrant $grant): array
    {
        $latestEvent = $version->events()->orderByDesc('id')->first();
        $payload = [
            'id' => $version->id,
            'project_id' => $version->project_id,
            'parent_version_id' => $version->parent_version_id,
            'kind' => $version->kind,
            'label' => $version->label,
            'data_date' => $version->data_date->format('Y-m-d'),
            'submitted_at' => $version->submitted_at->toIso8601String(),
            'review_status' => $latestEvent?->disposition ?? 'submitted',
            'review_status_projection_verified' => ($latestEvent?->disposition ?? 'submitted') === $version->review_status,
            'provisional' => $version->provisional,
            'row_count' => $version->row_count,
            'source_format' => $version->source_format,
            'parser' => ['name' => $version->parser_name, 'version' => $version->parser_version],
            'assumptions' => $version->ingest_assumptions,
            'event_chain_head' => $latestEvent?->event_hash,
            'anomalies' => $this->versionAnomalies($version, $latestEvent?->disposition ?? 'submitted'),
        ];
        if ($grant->allows('schedule.view_source_metadata')) {
            $payload['submitted_by_org'] = $version->submitted_by_org;
            $payload['source'] = [
                'media_id' => $version->source_file_media_id,
                'file_name' => $version->sourceFile?->original_name,
                'sha256' => $version->source_sha256,
                'security_scan' => $version->security_scan,
            ];
        }

        return $payload;
    }

    /**
     * Evidence-health anomalies for a version (P0-2). A baseline candidate that already
     * carries actual progress is not an untouched pre-progress baseline; the record says
     * so instead of letting the label imply approval.
     *
     * @return list<array<string,mixed>>
     */
    private function versionAnomalies(ScheduleVersion $version, string $disposition): array
    {
        $anomalies = [];
        if (in_array($version->kind, ['baseline', 'revised_baseline'], true)) {
            $withActuals = ScheduleActivity::query()
                ->where('schedule_version_id', $version->id)
                ->where(function ($query) {
                    $query->whereNotNull('start_actual')->orWhereNotNull('finish_actual');
                })
                ->count();
            if ($withActuals > 0) {
                $anomalies[] = [
                    'code' => 'actuals_in_baseline_candidate',
                    'severity' => 'warning',
                    'count' => $withActuals,
                    'message' => "Actual progress detected in baseline candidate: {$withActuals} activities. An approved baseline should not contain actuals - obtain the untouched approved export or adjudicate this anomaly before acceptance.",
                ];
            }
        }
        if ($disposition === 'submitted') {
            $anomalies[] = [
                'code' => 'no_acceptance_disposition',
                'severity' => 'info',
                'count' => null,
                'message' => 'No acceptance disposition recorded. The label is the submitter\'s wording, not a formal determination.',
            ];
        }

        return $anomalies;
    }

    /** @return array<string,mixed> */
    public function activity(ScheduleActivity $activity, ProjectGrant $grant): array
    {
        $payload = [
            'id' => $activity->id,
            'activity_code' => $activity->activity_code,
            'name' => $activity->name,
            'wbs_path' => $activity->wbs_path,
            'planned_start' => $activity->start_planned?->toIso8601String(),
            'planned_finish' => $activity->finish_planned?->toIso8601String(),
            'actual_start' => $activity->start_actual?->toIso8601String(),
            'actual_finish' => $activity->finish_actual?->toIso8601String(),
            'duration_minutes' => $activity->duration_minutes,
            'reported_total_float_minutes' => $activity->total_float_minutes,
            'reported_critical' => $activity->is_critical,
            'constraint_type' => $activity->constraint_type,
            'constraint_at' => $activity->constraint_at?->toIso8601String(),
            'calendar' => $activity->calendarAssignments->first()?->calendar?->name,
            'ingestion_confidence' => $activity->ingestion_confidence,
            'confirmation_status' => $activity->confirmation_status,
            'classification' => 'fact',
        ];
        if ($grant->allows('schedule.view_resources')) {
            $payload['resources'] = $activity->resources->map(fn ($resource) => [
                'code' => $resource->resource_code,
                'name' => $resource->resource_name,
                'type' => $resource->resource_type,
                'allocation_units' => $resource->allocation_units,
            ])->all();
        }

        return $payload;
    }

    /**
     * Magnitude basis for rows written before the typed-basis column existed
     * (P0-1). Inferred from the delta type and flagged as inferred.
     */
    public static function inferredBasis(?string $storedBasis, string $deltaType): ?string
    {
        if ($storedBasis !== null) {
            return $storedBasis;
        }

        return match ($deltaType) {
            'date', 'actuals', 'completion_movement' => 'elapsed_minutes',
            'duration' => 'duration_work_minutes',
            'float' => 'float_work_minutes',
            default => null,
        };
    }

    /** @return array<string,mixed> */
    public function delta(ScheduleDelta $delta, ProjectGrant $grant): array
    {
        $magnitude = $delta->magnitude_minutes;
        $basis = self::inferredBasis($delta->magnitude_basis, $delta->delta_type);
        $isElapsed = $basis === 'elapsed_minutes';
        $isWork = in_array($basis, ['duration_work_minutes', 'float_work_minutes'], true);
        $payload = [
            'id' => $delta->id,
            'analysis_id' => $delta->analysis_run_id,
            'mapping_group_id' => $delta->mapping_group_id,
            'from_activity_id' => $delta->from_activity_id,
            'to_activity_id' => $delta->to_activity_id,
            'delta_type' => $delta->delta_type,
            'field' => $delta->field,
            'magnitude_minutes' => $magnitude,
            'magnitude_basis' => $magnitude === null ? null : $basis,
            'magnitude_basis_inferred' => $magnitude !== null && $delta->magnitude_basis === null && $basis !== null,
            'magnitude_basis_status' => $magnitude !== null && $basis === null ? 'basis_unknown' : ($magnitude === null ? 'not_applicable' : 'named'),
            // Wall-clock date movements are calendar time. They are NEVER divided by a
            // fixed workday; a workday variance requires the versioned activity calendar,
            // which this deterministic phase does not yet compute (P0-1).
            'magnitude_calendar_days' => $magnitude !== null && $isElapsed ? round($magnitude / 1440, 2) : null,
            'magnitude_standard_work_days' => $magnitude !== null && $isWork ? round($magnitude / 480, 2) : null,
            'work_day_definition' => $magnitude !== null && $isWork ? '480-minute standard day (8h); source-schedule working minutes' : null,
            'before' => $delta->before_value,
            'after' => $delta->after_value,
            'explanation' => $delta->explanation,
            'classification' => $delta->classification,
        ];
        if ($grant->allows('schedule.view_source_metadata')) {
            $payload['sources'] = DB::table('schedule_delta_sources')
                ->where('schedule_delta_id', $delta->id)
                ->get(['schedule_version_id', 'media_item_id', 'schedule_activity_id', 'source_hash', 'retrieved_at'])
                ->all();
        }

        return $payload;
    }

    /** @return array<string,mixed> */
    /** @return array<string,mixed> */
    public function analysisHistoryRow(AnalysisRun $run, ?int $supersedesRunId): array
    {
        return [
            'id' => $run->id,
            'project_id' => $run->project_id,
            'from_version_id' => $run->from_version_id,
            'to_version_id' => $run->to_version_id,
            'status' => $run->status,
            'progress_percent' => $run->progress_percent,
            'supersedes_run_id' => $supersedesRunId,
            'superseded' => false,
            'engine_versions' => [
                'parser' => $run->parser_version,
                'cpm' => $run->cpm_engine_version,
                'rules' => $run->rules_version,
            ],
            'started_at' => $run->started_at?->toIso8601String(),
            'finished_at' => $run->finished_at?->toIso8601String(),
            'created_at' => $run->created_at?->toIso8601String(),
            'error' => $run->error,
        ];
    }

    public function analysis(AnalysisRun $run, ProjectGrant $grant): array
    {
        $payload = [
            'id' => $run->id,
            'project_id' => $run->project_id,
            'from_version_id' => $run->from_version_id,
            'to_version_id' => $run->to_version_id,
            'status' => $run->status,
            'progress_percent' => $run->progress_percent,
            'stage_status' => $run->stage_status,
            'engine_versions' => [
                'parser' => $run->parser_version,
                'cpm' => $run->cpm_engine_version,
                'rules' => $run->rules_version,
                'ai_model' => $run->ai_model,
                'ai_prompt' => $run->ai_prompt_version,
            ],
            'assumptions' => $run->assumptions,
            'retrieval_times' => $run->retrieval_times,
            'started_at' => $run->started_at?->toIso8601String(),
            'finished_at' => $run->finished_at?->toIso8601String(),
            'error' => $run->error,
            'deltas' => $run->deltas()->orderByRaw(self::NORMALIZED_DAYS_ORDER)->get()->map(fn ($delta) => $this->delta($delta, $grant))->all(),
            'validation_issues' => DB::table('schedule_validation_issues')
                ->where('analysis_run_id', $run->id)
                ->orderByRaw("case severity when 'error' then 0 when 'warning' then 1 else 2 end")
                ->get(['schedule_version_id', 'schedule_activity_id', 'code', 'severity', 'classification', 'message', 'details']),
            'unavailable_stages' => [
                'narrative_reconciliation' => 'Not implemented: requires tested authorized retrieval and human review workflow.',
                'causation_hypotheses' => 'Not implemented: the system will not infer responsibility or legal fault.',
                'counterfactual_recovery' => 'Not implemented: cost/time ranges need sourced constraints and approval gates.',
                'success_brief' => 'Not implemented: role-aware actions require explicit project capability policy.',
            ],
        ];
        if ($grant->allows('schedule.view_source_metadata')) {
            $payload['source_hashes'] = $run->source_hashes;
            $payload['authorization_scope_at_run'] = $run->authorization_scope;
        }

        return $payload;
    }
}
