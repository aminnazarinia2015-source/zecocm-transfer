<?php

namespace App\Domain\Schedule;

use App\Models\Project;

final readonly class ProjectGrant
{
    /** @param array<string,bool> $capabilities */
    public function __construct(
        public Project $project,
        public int $userId,
        public string $seat,
        public string $organization,
        public array $capabilities,
        public bool $platformSupport,
    ) {}

    public function allows(string $capability): bool
    {
        return ($this->capabilities['*'] ?? false) === true
            || ($this->capabilities[$capability] ?? false) === true;
    }

    /** @return array<string,mixed> */
    public function auditScope(): array
    {
        return [
            'tenant_id' => $this->project->tenant_id,
            'project_id' => $this->project->id,
            'user_id' => $this->userId,
            'seat' => $this->seat,
            'organization' => $this->organization,
            'capabilities' => array_keys(array_filter($this->capabilities)),
            'platform_support' => $this->platformSupport,
        ];
    }
}
