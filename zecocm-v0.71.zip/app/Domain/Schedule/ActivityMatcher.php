<?php

namespace App\Domain\Schedule;

final class ActivityMatcher
{
    /**
     * @param  list<array<string,mixed>>  $from
     * @param  list<array<string,mixed>>  $to
     * @return list<array{relation:string,confidence:float,from_ids:list<int>,to_ids:list<int>}>
     */
    public function match(array $from, array $to): array
    {
        $groups = [];
        $unmatchedFrom = array_column($from, null, 'id');
        $unmatchedTo = array_column($to, null, 'id');

        $toByCode = [];
        foreach ($to as $activity) {
            $toByCode[strtolower(trim((string) $activity['activity_code']))][] = $activity;
        }
        foreach ($from as $activity) {
            $candidates = $toByCode[strtolower(trim((string) $activity['activity_code']))] ?? [];
            if (count($candidates) !== 1) {
                continue;
            }
            $target = $candidates[0];
            if (! isset($unmatchedTo[$target['id']])) {
                continue;
            }
            $sameName = $this->normalize((string) $activity['name']) === $this->normalize((string) $target['name']);
            $groups[] = [
                'relation' => $sameName ? 'same' : 'renamed',
                'confidence' => $sameName ? 1.0 : 0.98,
                'from_ids' => [(int) $activity['id']],
                'to_ids' => [(int) $target['id']],
            ];
            unset($unmatchedFrom[$activity['id']], $unmatchedTo[$target['id']]);
        }

        // Mutual best match avoids greedily pairing one renamed activity twice.
        $scores = [];
        foreach ($unmatchedFrom as $left) {
            foreach ($unmatchedTo as $right) {
                $score = $this->similarity($left, $right);
                if ($score >= 0.80) {
                    $scores[$left['id']][$right['id']] = $score;
                }
            }
        }
        foreach ($scores as $leftId => $rightScores) {
            arsort($rightScores);
            $rightId = array_key_first($rightScores);
            $reverse = [];
            foreach ($scores as $candidateLeft => $candidateScores) {
                if (isset($candidateScores[$rightId])) {
                    $reverse[$candidateLeft] = $candidateScores[$rightId];
                }
            }
            arsort($reverse);
            if ((int) array_key_first($reverse) !== (int) $leftId || ! isset($unmatchedFrom[$leftId], $unmatchedTo[$rightId])) {
                continue;
            }
            $relation = $this->normalize((string) ($unmatchedFrom[$leftId]['wbs_path'] ?? ''))
                === $this->normalize((string) ($unmatchedTo[$rightId]['wbs_path'] ?? '')) ? 'renamed' : 'resequenced';
            $groups[] = [
                'relation' => $relation,
                'confidence' => round((float) $rightScores[$rightId], 4),
                'from_ids' => [(int) $leftId],
                'to_ids' => [(int) $rightId],
            ];
            unset($unmatchedFrom[$leftId], $unmatchedTo[$rightId]);
        }

        // Relational split/merge groups keep all identity edges instead of flattening to JSON.
        foreach (array_values($unmatchedFrom) as $left) {
            $candidates = [];
            foreach ($unmatchedTo as $right) {
                $score = $this->scopeSimilarity($left, $right);
                if ($score >= 0.55) {
                    $candidates[$right['id']] = $score;
                }
            }
            if (count($candidates) < 2) {
                continue;
            }
            arsort($candidates);
            $candidates = array_slice($candidates, 0, 4, true);
            $groups[] = [
                'relation' => 'split',
                'confidence' => round(array_sum($candidates) / count($candidates), 4),
                'from_ids' => [(int) $left['id']],
                'to_ids' => array_map('intval', array_keys($candidates)),
            ];
            unset($unmatchedFrom[$left['id']]);
            foreach (array_keys($candidates) as $id) {
                unset($unmatchedTo[$id]);
            }
        }

        foreach (array_values($unmatchedTo) as $right) {
            $candidates = [];
            foreach ($unmatchedFrom as $left) {
                $score = $this->scopeSimilarity($left, $right);
                if ($score >= 0.55) {
                    $candidates[$left['id']] = $score;
                }
            }
            if (count($candidates) < 2) {
                continue;
            }
            arsort($candidates);
            $candidates = array_slice($candidates, 0, 4, true);
            $groups[] = [
                'relation' => 'merged',
                'confidence' => round(array_sum($candidates) / count($candidates), 4),
                'from_ids' => array_map('intval', array_keys($candidates)),
                'to_ids' => [(int) $right['id']],
            ];
            unset($unmatchedTo[$right['id']]);
            foreach (array_keys($candidates) as $id) {
                unset($unmatchedFrom[$id]);
            }
        }

        foreach ($unmatchedFrom as $activity) {
            $groups[] = ['relation' => 'deleted', 'confidence' => 1.0, 'from_ids' => [(int) $activity['id']], 'to_ids' => []];
        }
        foreach ($unmatchedTo as $activity) {
            $groups[] = ['relation' => 'added', 'confidence' => 1.0, 'from_ids' => [], 'to_ids' => [(int) $activity['id']]];
        }

        return $groups;
    }

    /** @param array<string,mixed> $left @param array<string,mixed> $right */
    private function similarity(array $left, array $right): float
    {
        $name = $this->stringSimilarity((string) $left['name'], (string) $right['name']);
        $wbs = $this->stringSimilarity((string) ($left['wbs_path'] ?? ''), (string) ($right['wbs_path'] ?? ''));
        $date = $this->dateProximity($left['start_planned'] ?? null, $right['start_planned'] ?? null);

        return 0.65 * $name + 0.20 * $wbs + 0.15 * $date;
    }

    /** @param array<string,mixed> $left @param array<string,mixed> $right */
    private function scopeSimilarity(array $left, array $right): float
    {
        $leftTokens = $this->tokens((string) $left['name'].' '.(string) ($left['wbs_path'] ?? ''));
        $rightTokens = $this->tokens((string) $right['name'].' '.(string) ($right['wbs_path'] ?? ''));
        if ($leftTokens === [] || $rightTokens === []) {
            return 0.0;
        }
        $intersection = count(array_intersect($leftTokens, $rightTokens));

        return $intersection / max(1, min(count($leftTokens), count($rightTokens)));
    }

    private function stringSimilarity(string $left, string $right): float
    {
        $left = $this->normalize($left);
        $right = $this->normalize($right);
        if ($left === $right) {
            return 1.0;
        }
        $max = max(strlen($left), strlen($right));

        return $max === 0 ? 1.0 : max(0.0, 1 - levenshtein($left, $right) / $max);
    }

    private function dateProximity(mixed $left, mixed $right): float
    {
        if (! $left || ! $right) {
            return 0.5;
        }
        $a = new \DateTimeImmutable((string) $left);
        $b = new \DateTimeImmutable((string) $right);
        $days = abs((int) $a->diff($b)->format('%r%a'));

        return max(0.0, 1 - min($days, 60) / 60);
    }

    /** @return list<string> */
    private function tokens(string $value): array
    {
        $tokens = preg_split('/\s+/', $this->normalize($value)) ?: [];

        return array_values(array_unique(array_filter($tokens, fn ($token) => strlen($token) > 2)));
    }

    private function normalize(string $value): string
    {
        $value = strtolower(trim($value));

        return trim((string) preg_replace('/[^a-z0-9]+/', ' ', $value));
    }
}
