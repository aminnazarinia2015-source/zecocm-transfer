<?php

namespace App\Domain\Schedule;

final class AnalysisCancelled extends \RuntimeException {}
