<?php

namespace App\Domain\Schedule;

use DateTimeImmutable;
use DateTimeZone;

final class WorkingCalendar
{
    /**
     * @param  array<int,list<array{0:string,1:string}>>  $weeklyPeriods  ISO weekday => periods
     * @param  array<string,list<array{0:string,1:string}>>  $exceptions  Y-m-d => periods (empty = holiday)
     */
    public function __construct(
        public readonly string|int $id,
        public readonly string $name,
        public readonly DateTimeZone $timeZone,
        private readonly array $weeklyPeriods,
        private readonly array $exceptions = [],
    ) {
        $count = 0;
        foreach ($weeklyPeriods as $weekday => $periods) {
            if ($weekday < 1 || $weekday > 7) {
                throw new \InvalidArgumentException('Calendar weekday must be ISO 1 through 7.');
            }
            foreach ($periods as [$start, $end]) {
                if ($start >= $end) {
                    throw new \InvalidArgumentException("Calendar period {$start}-{$end} is not positive.");
                }
                $count++;
            }
        }
        if ($count === 0) {
            throw new \InvalidArgumentException('A working calendar needs at least one weekly period.');
        }
    }

    public function addWorkingMinutes(DateTimeImmutable $start, int $minutes): DateTimeImmutable
    {
        if ($minutes < 0) {
            return $this->subtractWorkingMinutes($start, -$minutes);
        }
        $cursor = $this->nextWorkingInstant($start);
        if ($minutes === 0) {
            return $cursor;
        }

        for ($guard = 0; $guard < 20000; $guard++) {
            foreach ($this->periodsForDate($cursor) as [$periodStart, $periodEnd]) {
                if ($cursor >= $periodEnd) {
                    continue;
                }
                $activeStart = $cursor > $periodStart ? $cursor : $periodStart;
                $available = intdiv(max(0, $periodEnd->getTimestamp() - $activeStart->getTimestamp()), 60);
                if ($minutes <= $available) {
                    return $activeStart->modify("+{$minutes} minutes");
                }
                $minutes -= $available;
                $cursor = $periodEnd;
            }
            $cursor = $this->nextWorkingInstant($cursor->modify('+1 second'));
        }

        throw new \RuntimeException('Calendar calculation exceeded its safety iteration limit.');
    }

    public function subtractWorkingMinutes(DateTimeImmutable $finish, int $minutes): DateTimeImmutable
    {
        if ($minutes < 0) {
            return $this->addWorkingMinutes($finish, -$minutes);
        }
        $cursor = $this->previousWorkingInstant($finish);
        if ($minutes === 0) {
            return $cursor;
        }

        for ($guard = 0; $guard < 20000; $guard++) {
            $periods = array_reverse($this->periodsForDate($cursor));
            foreach ($periods as [$periodStart, $periodEnd]) {
                if ($cursor <= $periodStart) {
                    continue;
                }
                $activeEnd = $cursor < $periodEnd ? $cursor : $periodEnd;
                $available = intdiv(max(0, $activeEnd->getTimestamp() - $periodStart->getTimestamp()), 60);
                if ($minutes <= $available) {
                    return $activeEnd->modify("-{$minutes} minutes");
                }
                $minutes -= $available;
                $cursor = $periodStart;
            }
            $cursor = $this->previousWorkingInstant($cursor->modify('-1 second'));
        }

        throw new \RuntimeException('Calendar calculation exceeded its safety iteration limit.');
    }

    public function workingMinutesBetween(DateTimeImmutable $from, DateTimeImmutable $to): int
    {
        if ($from == $to) {
            return 0;
        }
        if ($from > $to) {
            return -$this->workingMinutesBetween($to, $from);
        }

        $from = $from->setTimezone($this->timeZone);
        $to = $to->setTimezone($this->timeZone);
        $cursor = $from->setTime(0, 0);
        $minutes = 0;
        for ($guard = 0; $cursor <= $to && $guard < 20000; $guard++, $cursor = $cursor->modify('+1 day')) {
            foreach ($this->periodsForDate($cursor) as [$periodStart, $periodEnd]) {
                $start = $periodStart < $from ? $from : $periodStart;
                $end = $periodEnd > $to ? $to : $periodEnd;
                if ($end > $start) {
                    $minutes += intdiv($end->getTimestamp() - $start->getTimestamp(), 60);
                }
            }
        }
        if ($guard >= 20000) {
            throw new \RuntimeException('Calendar range exceeded its safety iteration limit.');
        }

        return $minutes;
    }

    public function nextWorkingInstant(DateTimeImmutable $value): DateTimeImmutable
    {
        $cursor = $value->setTimezone($this->timeZone);
        for ($guard = 0; $guard < 3660; $guard++) {
            foreach ($this->periodsForDate($cursor) as [$start, $end]) {
                if ($cursor <= $start) {
                    return $start;
                }
                if ($cursor < $end) {
                    return $cursor;
                }
            }
            $cursor = $cursor->modify('+1 day')->setTime(0, 0);
        }
        throw new \RuntimeException('No future working instant found in calendar.');
    }

    public function previousWorkingInstant(DateTimeImmutable $value): DateTimeImmutable
    {
        $cursor = $value->setTimezone($this->timeZone);
        for ($guard = 0; $guard < 3660; $guard++) {
            foreach (array_reverse($this->periodsForDate($cursor)) as [$start, $end]) {
                if ($cursor >= $end) {
                    return $end;
                }
                if ($cursor > $start) {
                    return $cursor;
                }
            }
            $cursor = $cursor->modify('-1 day')->setTime(23, 59, 59);
        }
        throw new \RuntimeException('No prior working instant found in calendar.');
    }

    /** @return list<array{0:DateTimeImmutable,1:DateTimeImmutable}> */
    private function periodsForDate(DateTimeImmutable $date): array
    {
        $date = $date->setTimezone($this->timeZone);
        $key = $date->format('Y-m-d');
        $periods = array_key_exists($key, $this->exceptions)
            ? $this->exceptions[$key]
            : ($this->weeklyPeriods[(int) $date->format('N')] ?? []);

        return array_map(
            fn (array $period) => [
                new DateTimeImmutable($key.' '.$period[0], $this->timeZone),
                new DateTimeImmutable($key.' '.$period[1], $this->timeZone),
            ],
            $periods
        );
    }
}
