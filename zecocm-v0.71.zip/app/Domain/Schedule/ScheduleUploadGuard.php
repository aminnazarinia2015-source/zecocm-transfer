<?php

namespace App\Domain\Schedule;

use Illuminate\Http\UploadedFile;
use Symfony\Component\Process\Process;
use ZipArchive;

final class ScheduleUploadGuard
{
    /** @return array<string,mixed> */
    public function inspect(UploadedFile $file): array
    {
        if (! $file->isValid() || ! is_file($file->getRealPath())) {
            throw new UnsafeScheduleUpload('The uploaded schedule did not arrive intact.');
        }

        $extension = strtolower($file->getClientOriginalExtension());
        if (! in_array($extension, ['csv', 'xlsx', 'xml'], true)) {
            throw new UnsafeScheduleUpload('CSV, XLSX, and MS Project XML schedule exports are accepted in this milestone. XER support is not yet enabled; PDF rows are never silently accepted.');
        }

        $actualMime = strtolower((string) $file->getMimeType());
        $allowedMimes = match ($extension) {
            'csv' => ['text/plain', 'text/csv', 'application/csv', 'application/vnd.ms-excel'],
            'xml' => ['text/xml', 'application/xml', 'text/plain'],
            default => ['application/zip', 'application/x-zip-compressed', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        };
        if (! in_array($actualMime, $allowedMimes, true)) {
            throw new UnsafeScheduleUpload("The file content type '{$actualMime}' does not match a {$extension} schedule export.");
        }

        $result = [
            'status' => 'passed',
            'extension' => $extension,
            'detected_mime' => $actualMime,
            'bytes' => $file->getSize(),
            'structural_checks' => ['type_match' => true],
            'malware' => $this->scanMalware($file->getRealPath()),
            'scanned_at' => now()->toIso8601String(),
        ];

        if ($extension === 'xlsx') {
            $result['structural_checks'] += $this->inspectArchive($file->getRealPath());
        } elseif ($extension === 'xml') {
            $result['structural_checks'] += $this->inspectXml($file->getRealPath());
        } else {
            $result['structural_checks'] += $this->inspectCsv($file->getRealPath());
        }

        return $result;
    }

    /** @return array<string,mixed> */
    private function inspectXml(string $path): array
    {
        $bytes = filesize($path) ?: 0;
        $maxBytes = ((int) config('schedule.max_upload_kilobytes', 25600)) * 1024;
        if ($bytes > $maxBytes) {
            throw new UnsafeScheduleUpload('The schedule XML exceeds the configured size limit.');
        }
        $head = (string) file_get_contents($path, false, null, 0, 65536);
        if (stripos($head, '<!DOCTYPE') !== false || stripos($head, '<!ENTITY') !== false) {
            throw new UnsafeScheduleUpload('The schedule XML contains a DTD or entity declaration and was rejected for safety.');
        }
        if (stripos($head, '<Project') === false) {
            throw new UnsafeScheduleUpload('The XML does not look like an MS Project (MSPDI) export.');
        }

        return ['xml_dtd_free' => true, 'mspdi_root' => true];
    }

    /** @return array<string,mixed> */
    private function scanMalware(string $path): array
    {
        $binary = trim((string) config('schedule.malware_scanner_binary', ''));
        $required = (bool) config('schedule.require_malware_scan', true);

        if ($binary === '') {
            if ($required) {
                throw new UnsafeScheduleUpload(
                    'Schedule ingestion is paused because the required malware scanner is not configured.',
                    503
                );
            }

            return ['status' => 'not_configured', 'required' => false];
        }

        $process = new Process([$binary, '--no-summary', '--infected', $path]);
        $process->setTimeout(60);
        $process->run();

        if ($process->getExitCode() === 1) {
            throw new UnsafeScheduleUpload('The schedule upload was rejected by the malware scanner.');
        }
        if (! $process->isSuccessful()) {
            throw new UnsafeScheduleUpload('The malware scanner could not verify this upload; ingestion refused.', 503);
        }

        return ['status' => 'clean', 'required' => $required, 'engine' => basename($binary)];
    }

    /** @return array<string,mixed> */
    private function inspectArchive(string $path): array
    {
        $zip = new ZipArchive;
        if ($zip->open($path, ZipArchive::RDONLY) !== true) {
            throw new UnsafeScheduleUpload('The XLSX container is malformed or encrypted.');
        }

        try {
            $maxEntries = (int) config('schedule.max_archive_entries', 10000);
            if ($zip->numFiles < 1 || $zip->numFiles > $maxEntries) {
                throw new UnsafeScheduleUpload('The XLSX archive contains an unsafe number of entries.');
            }

            $totalUncompressed = 0;
            $maxUncompressed = (int) config('schedule.max_uncompressed_bytes', 209715200);
            $maxRatio = (int) config('schedule.max_compression_ratio', 100);
            $blocked = ['vbaproject.bin', '/externallinks/', '/embeddings/', 'oleobject', 'activex'];

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                if ($stat === false) {
                    throw new UnsafeScheduleUpload('The XLSX archive directory is malformed.');
                }

                $name = str_replace('\\', '/', (string) $stat['name']);
                $lower = strtolower('/'.$name);
                if (str_starts_with($name, '/') || preg_match('~(^|/)\.\.(/|$)~', $name) || str_contains($name, ':')) {
                    throw new UnsafeScheduleUpload('The XLSX archive contains an unsafe path.');
                }
                foreach ($blocked as $fragment) {
                    if (str_contains($lower, $fragment)) {
                        throw new UnsafeScheduleUpload('Embedded code, objects, or external links are not allowed in schedule workbooks.');
                    }
                }

                $size = (int) ($stat['size'] ?? 0);
                $compressed = (int) ($stat['comp_size'] ?? 0);
                $totalUncompressed += $size;
                if ($totalUncompressed > $maxUncompressed) {
                    throw new UnsafeScheduleUpload('The XLSX expands beyond the configured safety limit.');
                }
                if ($size > 1048576 && ($compressed === 0 || $size / max(1, $compressed) > $maxRatio)) {
                    throw new UnsafeScheduleUpload('The XLSX compression ratio is unsafe.');
                }
            }

            if ($zip->locateName('[Content_Types].xml') === false || $zip->locateName('xl/workbook.xml') === false) {
                throw new UnsafeScheduleUpload('The file is not a valid XLSX workbook.');
            }

            return [
                'archive_entries' => $zip->numFiles,
                'uncompressed_bytes' => $totalUncompressed,
                'active_content_absent' => true,
            ];
        } finally {
            $zip->close();
        }
    }

    /** @return array<string,mixed> */
    private function inspectCsv(string $path): array
    {
        $sample = file_get_contents($path, false, null, 0, 1048576);
        if ($sample === false || str_contains($sample, "\0")) {
            throw new UnsafeScheduleUpload('The CSV is unreadable or contains binary null bytes.');
        }

        $encoding = mb_check_encoding($sample, 'UTF-8') ? 'UTF-8' : 'Windows-1252';

        return ['encoding_detected' => $encoding, 'binary_nulls_absent' => true];
    }
}
