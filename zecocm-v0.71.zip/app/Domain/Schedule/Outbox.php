<?php

namespace App\Domain\Schedule;

use App\Models\OutboxEvent;

final class Outbox
{
    /** @param array<string,mixed> $payload */
    public function record(int $tenantId, string $aggregateType, int $aggregateId, string $eventType, array $payload, string $idempotencyKey): OutboxEvent
    {
        return OutboxEvent::firstOrCreate(
            ['idempotency_key' => $idempotencyKey],
            [
                'tenant_id' => $tenantId,
                'aggregate_type' => $aggregateType,
                'aggregate_id' => $aggregateId,
                'event_type' => $eventType,
                'payload' => $payload,
                'status' => 'pending',
                'attempts' => 0,
                'available_at' => now(),
            ]
        );
    }
}
