<?php

namespace App\Domain\Schedule;

use DateTimeImmutable;

/** Deterministic CPM: FS/SS/FF/SF, signed lags, versioned calendars, constraints and actuals. */
final class CpmEngine
{
    /**
     * @param  list<array<string,mixed>>  $activities  each needs id, code, duration_minutes and WorkingCalendar calendar
     * @param  list<array<string,mixed>>  $relationships  predecessor_id, successor_id, type, lag_minutes
     * @param  array<string,mixed>  $options  data_date, open_end_policy, out_of_sequence_mode, near_critical_minutes
     */
    public function calculate(array $activities, array $relationships, array $options): CpmResult
    {
        if ($activities === []) {
            throw new \InvalidArgumentException('CPM needs at least one activity.');
        }
        $dataDate = $options['data_date'] instanceof DateTimeImmutable
            ? $options['data_date']
            : new DateTimeImmutable((string) ($options['data_date'] ?? 'now'));
        $openEndPolicy = $options['open_end_policy'] ?? 'warn';
        $outOfSequence = $options['out_of_sequence_mode'] ?? 'retain_logic';
        $nearCritical = (int) ($options['near_critical_minutes'] ?? 2400);
        if (! in_array($openEndPolicy, ['off', 'warn', 'error'], true)) {
            throw new \InvalidArgumentException('Invalid open_end_policy.');
        }
        if (! in_array($outOfSequence, ['retain_logic', 'progress_override'], true)) {
            throw new \InvalidArgumentException('Invalid out_of_sequence_mode.');
        }

        $byId = [];
        foreach ($activities as $activity) {
            if (! ($activity['calendar'] ?? null) instanceof WorkingCalendar) {
                throw new \InvalidArgumentException("Activity '{$activity['code']}' has no usable calendar.");
            }
            if ((int) $activity['duration_minutes'] < 0) {
                throw new \InvalidArgumentException("Activity '{$activity['code']}' has a negative duration.");
            }
            $byId[$activity['id']] = $activity;
        }

        $incoming = array_fill_keys(array_keys($byId), []);
        $outgoing = array_fill_keys(array_keys($byId), []);
        $issues = [];
        foreach ($relationships as $relationship) {
            $pred = $relationship['predecessor_id'];
            $succ = $relationship['successor_id'];
            $type = strtoupper((string) ($relationship['type'] ?? ''));
            if (! isset($byId[$pred], $byId[$succ])) {
                throw new \InvalidArgumentException('A relationship references an unknown activity.');
            }
            if (! in_array($type, ['FS', 'SS', 'FF', 'SF'], true)) {
                throw new \InvalidArgumentException("Unsupported relationship type '{$type}'.");
            }
            $relationship['type'] = $type;
            $relationship['lag_minutes'] = (int) ($relationship['lag_minutes'] ?? 0);
            $incoming[$succ][] = $relationship;
            $outgoing[$pred][] = $relationship;
            if (abs($relationship['lag_minutes']) > 2400) {
                $issues[] = $this->issue('excessive_lag', 'warning', $succ, 'Relationship lag exceeds five standard work days.', $relationship);
            }
            if ($relationship['lag_minutes'] < 0) {
                $issues[] = $this->issue('negative_lag', 'warning', $succ, 'Relationship uses negative lag (lead); verify contractual schedule options.', $relationship);
            }
        }

        $order = $this->topologicalOrder(array_keys($byId), $incoming, $outgoing);
        $metrics = [];
        $minimumPlannedStart = $this->minimumDate(array_column($activities, 'start_planned'));

        foreach ($order as $id) {
            $activity = $byId[$id];
            /** @var WorkingCalendar $calendar */
            $calendar = $activity['calendar'];
            $duration = (int) $activity['duration_minutes'];
            $actualStart = $this->date($activity['start_actual'] ?? null);
            $actualFinish = $this->date($activity['finish_actual'] ?? null);
            if ($actualStart && $actualFinish && $actualFinish < $actualStart) {
                $issues[] = $this->issue('actual_dates_reversed', 'error', $id, 'Actual finish precedes actual start.');
            }

            $earlyStart = $calendar->nextWorkingInstant($dataDate);
            foreach ($incoming[$id] as $relationship) {
                $predecessor = $metrics[$relationship['predecessor_id']];
                $required = $this->forwardRequiredStart($relationship, $predecessor, $duration, $calendar);
                if ($required > $earlyStart) {
                    $earlyStart = $required;
                }
                if ($actualStart && $actualStart < $required) {
                    $issues[] = $this->issue(
                        'out_of_sequence_progress',
                        'warning',
                        $id,
                        'Actual progress began before predecessor logic was satisfied.',
                        ['relationship' => $relationship, 'required_start' => $required->format(DATE_ATOM), 'actual_start' => $actualStart->format(DATE_ATOM)]
                    );
                }
            }

            $constraintType = strtolower((string) ($activity['constraint_type'] ?? ''));
            $constraintAt = $this->date($activity['constraint_at'] ?? null);
            if ($constraintAt && in_array($constraintType, ['start_no_earlier_than', 'snet', 'must_start_on'], true)) {
                if ($constraintAt > $earlyStart || $constraintType === 'must_start_on') {
                    $earlyStart = $calendar->nextWorkingInstant($constraintAt);
                }
            }

            if ($actualFinish) {
                $earlyFinish = $actualFinish;
                $earlyStart = $actualStart ?? $calendar->subtractWorkingMinutes($earlyFinish, $duration);
            } elseif ($actualStart) {
                $earlyStart = $actualStart;
                $resume = $outOfSequence === 'retain_logic' && $dataDate > $actualStart ? $calendar->nextWorkingInstant($dataDate) : $actualStart;
                $earlyFinish = $duration === 0 ? $resume : $calendar->addWorkingMinutes($resume, $duration);
            } else {
                $earlyFinish = $duration === 0 ? $earlyStart : $calendar->addWorkingMinutes($earlyStart, $duration);
            }

            if ($constraintAt && in_array($constraintType, ['finish_no_later_than', 'fnlt', 'must_finish_on'], true) && $earlyFinish > $constraintAt) {
                $issues[] = $this->issue('constraint_violation', 'error', $id, 'Calculated early finish violates the activity finish constraint.', [
                    'constraint_type' => $constraintType,
                    'constraint_at' => $constraintAt->format(DATE_ATOM),
                    'early_finish' => $earlyFinish->format(DATE_ATOM),
                ]);
            }

            if ($actualStart && $actualStart > $dataDate) {
                $issues[] = $this->issue('future_actual', 'error', $id, 'Actual start is later than the schedule data date.');
            }
            if ($actualFinish && $actualFinish > $dataDate) {
                $issues[] = $this->issue('future_actual', 'error', $id, 'Actual finish is later than the schedule data date.');
            }

            $metrics[$id] = [
                'early_start' => $earlyStart,
                'early_finish' => $earlyFinish,
                'late_start' => null,
                'late_finish' => null,
                'total_float_minutes' => null,
                'is_critical' => false,
                'is_near_critical' => false,
            ];
        }

        $projectFinish = $this->maximumDate(array_column($metrics, 'early_finish'))
            ?? throw new \RuntimeException('CPM produced no project finish.');

        foreach (array_reverse($order) as $id) {
            $activity = $byId[$id];
            /** @var WorkingCalendar $calendar */
            $calendar = $activity['calendar'];
            $duration = (int) $activity['duration_minutes'];
            $lateFinish = $projectFinish;
            $lateStart = $duration === 0 ? $lateFinish : $calendar->subtractWorkingMinutes($lateFinish, $duration);

            foreach ($outgoing[$id] as $relationship) {
                $successor = $metrics[$relationship['successor_id']];
                [$candidateStart, $candidateFinish] = $this->backwardLimits($relationship, $successor, $duration, $calendar);
                if ($candidateFinish < $lateFinish) {
                    $lateFinish = $candidateFinish;
                    $lateStart = $candidateStart;
                }
            }

            $constraintType = strtolower((string) ($activity['constraint_type'] ?? ''));
            $constraintAt = $this->date($activity['constraint_at'] ?? null);
            if ($constraintAt && in_array($constraintType, ['finish_no_later_than', 'fnlt', 'must_finish_on'], true) && $constraintAt < $lateFinish) {
                $lateFinish = $calendar->previousWorkingInstant($constraintAt);
                $lateStart = $duration === 0 ? $lateFinish : $calendar->subtractWorkingMinutes($lateFinish, $duration);
            }

            $float = $calendar->workingMinutesBetween($metrics[$id]['early_start'], $lateStart);
            $metrics[$id]['late_start'] = $lateStart;
            $metrics[$id]['late_finish'] = $lateFinish;
            $metrics[$id]['total_float_minutes'] = $float;
            $metrics[$id]['is_critical'] = $float <= 0;
            $metrics[$id]['is_near_critical'] = $float > 0 && $float <= $nearCritical;
        }

        if ($openEndPolicy !== 'off') {
            foreach ($order as $id) {
                $activity = $byId[$id];
                $duration = (int) $activity['duration_minutes'];
                $severity = $openEndPolicy === 'error' ? 'error' : 'warning';
                $planned = $this->date($activity['start_planned'] ?? null);
                if ($incoming[$id] === [] && $duration > 0 && $planned && $minimumPlannedStart && $planned > $minimumPlannedStart) {
                    $issues[] = $this->issue('open_start', $severity, $id, 'Non-initial activity has no predecessor.');
                }
                if ($outgoing[$id] === [] && $metrics[$id]['early_finish'] < $projectFinish) {
                    $issues[] = $this->issue('open_finish', $severity, $id, 'Activity finishes before project completion but has no successor.');
                }
            }
        }

        return new CpmResult(
            metrics: $metrics,
            issues: $issues,
            projectFinish: $projectFinish,
            assumptions: [
                'Relationship lag is evaluated on the successor calendar in the forward pass and predecessor calendar in the backward pass.',
                "Out-of-sequence option: {$outOfSequence}.",
                "Open-end policy: {$openEndPolicy}.",
            ],
        );
    }

    /** @param array<string,mixed> $relationship @param array<string,mixed> $predecessor */
    private function forwardRequiredStart(array $relationship, array $predecessor, int $duration, WorkingCalendar $successorCalendar): DateTimeImmutable
    {
        $lag = (int) $relationship['lag_minutes'];
        $offset = fn (DateTimeImmutable $date) => $lag >= 0
            ? $successorCalendar->addWorkingMinutes($date, $lag)
            : $successorCalendar->subtractWorkingMinutes($date, -$lag);

        return match ($relationship['type']) {
            'FS' => $offset($predecessor['early_finish']),
            'SS' => $offset($predecessor['early_start']),
            'FF' => $successorCalendar->subtractWorkingMinutes($offset($predecessor['early_finish']), $duration),
            'SF' => $successorCalendar->subtractWorkingMinutes($offset($predecessor['early_start']), $duration),
        };
    }

    /** @param array<string,mixed> $relationship @param array<string,mixed> $successor @return array{DateTimeImmutable,DateTimeImmutable} */
    private function backwardLimits(array $relationship, array $successor, int $duration, WorkingCalendar $predecessorCalendar): array
    {
        $lag = (int) $relationship['lag_minutes'];
        $unlag = fn (DateTimeImmutable $date) => $lag >= 0
            ? $predecessorCalendar->subtractWorkingMinutes($date, $lag)
            : $predecessorCalendar->addWorkingMinutes($date, -$lag);

        return match ($relationship['type']) {
            'FS' => $this->finishPair($unlag($successor['late_start']), $duration, $predecessorCalendar),
            'SS' => $this->startPair($unlag($successor['late_start']), $duration, $predecessorCalendar),
            'FF' => $this->finishPair($unlag($successor['late_finish']), $duration, $predecessorCalendar),
            'SF' => $this->startPair($unlag($successor['late_finish']), $duration, $predecessorCalendar),
        };
    }

    /** @return array{DateTimeImmutable,DateTimeImmutable} */
    private function finishPair(DateTimeImmutable $finish, int $duration, WorkingCalendar $calendar): array
    {
        return [$duration === 0 ? $finish : $calendar->subtractWorkingMinutes($finish, $duration), $finish];
    }

    /** @return array{DateTimeImmutable,DateTimeImmutable} */
    private function startPair(DateTimeImmutable $start, int $duration, WorkingCalendar $calendar): array
    {
        return [$start, $duration === 0 ? $start : $calendar->addWorkingMinutes($start, $duration)];
    }

    /** @param list<int|string> $ids @param array<int|string,list<array<string,mixed>>> $incoming @param array<int|string,list<array<string,mixed>>> $outgoing @return list<int|string> */
    private function topologicalOrder(array $ids, array $incoming, array $outgoing): array
    {
        $degree = array_map('count', $incoming);
        $queue = [];
        foreach ($ids as $id) {
            if (($degree[$id] ?? 0) === 0) {
                $queue[] = $id;
            }
        }
        $order = [];
        while ($queue !== []) {
            $id = array_shift($queue);
            $order[] = $id;
            foreach ($outgoing[$id] as $relationship) {
                $successor = $relationship['successor_id'];
                $degree[$successor]--;
                if ($degree[$successor] === 0) {
                    $queue[] = $successor;
                }
            }
        }
        if (count($order) !== count($ids)) {
            throw new \DomainException('Schedule logic contains a cycle; CPM refused to guess.');
        }

        return $order;
    }

    /** @param list<mixed> $dates */
    private function minimumDate(array $dates): ?DateTimeImmutable
    {
        $dates = array_values(array_filter(array_map(fn ($d) => $this->date($d), $dates)));
        usort($dates, fn ($a, $b) => $a <=> $b);

        return $dates[0] ?? null;
    }

    /** @param list<mixed> $dates */
    private function maximumDate(array $dates): ?DateTimeImmutable
    {
        $dates = array_values(array_filter(array_map(fn ($d) => $this->date($d), $dates)));
        usort($dates, fn ($a, $b) => $b <=> $a);

        return $dates[0] ?? null;
    }

    private function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }

        return $value instanceof DateTimeImmutable ? $value : new DateTimeImmutable((string) $value);
    }

    /** @param array<string,mixed> $details @return array<string,mixed> */
    private function issue(string $code, string $severity, int|string|null $activityId, string $message, array $details = []): array
    {
        return compact('code', 'severity', 'activityId', 'message', 'details');
    }
}
