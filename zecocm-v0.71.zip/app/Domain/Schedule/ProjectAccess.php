<?php

namespace App\Domain\Schedule;

use App\Models\Membership;
use App\Models\Project;
use App\Models\User;
use App\Tenancy\TenantContext;

final class ProjectAccess
{
    public function authorize(User $user, int $projectId, string $capability, bool $write = false): ProjectGrant
    {
        // findOrFail() here would let Laravel's default ModelNotFoundException
        // through untouched - a generic "No query results for model
        // [App\Models\Project] 1" message that (with APP_DEBUG on) also
        // carries the exception class, file path and full stack trace in the
        // JSON body, unlike every other refusal in this method, which uses a
        // short, consistent, human-worded abort(). Same failure whether the
        // id is genuinely wrong or just outside the caller's tenant context
        // (BelongsToTenant scopes the query either way) - the wording should
        // not depend on which reason happens to be true, and the caller
        // learns nothing about which case it was.
        $project = Project::query()->find($projectId);
        abort_if($project === null, 404, 'No project matches that id for this account.');

        if ($user->isPlatformStaff()) {
            abort_if(TenantContext::tenantId() !== $project->tenant_id, 403, 'Open the customer workspace before accessing project data.');
            abort_if($write && ! TenantContext::isSupportMode(), 403, 'Technicians are read-only in customer workspaces.');

            $grant = new ProjectGrant(
                project: $project,
                userId: $user->id,
                seat: $user->isPlatformAdmin() ? 'platform_admin_support' : 'platform_technician',
                organization: 'ZecoCM platform',
                capabilities: $user->isPlatformAdmin()
                    ? ['*' => true]
                    : [
                        'project.view' => true,
                        'weather.view' => true,
                        'documents.view' => true,
                        'assistant.use' => true,
                        'records.view' => true,
                        'schedule.view' => true,
                        'plans.view' => true,
                    ],
                platformSupport: true,
            );
        } else {
            $membership = Membership::query()
                ->where('project_id', $project->id)
                ->where('user_id', $user->id)
                ->first();
            abort_if($membership === null, 403, 'No project grant exists for this account.');
            // A revoked grant must actually stop authorizing, not just read as
            // revoked in the Users & Access screen - the status column added
            // for that screen would otherwise be cosmetic.
            abort_if($membership->status === Membership::STATUS_REVOKED, 403, 'This project grant has been revoked.');

            $grant = new ProjectGrant(
                project: $project,
                userId: $user->id,
                seat: $membership->seat,
                organization: $membership->organization,
                capabilities: $membership->capabilities ?? [],
                platformSupport: false,
            );
        }

        abort_unless($grant->allows($capability), 403, 'This project grant does not permit the requested action.');

        return $grant;
    }
}
