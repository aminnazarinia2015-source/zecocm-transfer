<?php

namespace App\Domain\Schedule;

final class UnsafeScheduleUpload extends \RuntimeException
{
    public function __construct(string $message, public readonly int $httpStatus = 422)
    {
        parent::__construct($message);
    }
}
