<?php

namespace App\Domain\Schedule;

use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Http\UploadedFile;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as SpreadsheetDate;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

final class SpreadsheetScheduleParser
{
    private const HEADER_ALIASES = [
        'activity_code' => ['activity_code', 'activity_id', 'activity', 'id', 'task_id', 'code'],
        'name' => ['name', 'activity_name', 'task_name', 'description'],
        'wbs_path' => ['wbs_path', 'wbs', 'wbs_name'],
        'start_planned' => ['start_planned', 'planned_start', 'start', 'baseline_start'],
        'finish_planned' => ['finish_planned', 'planned_finish', 'finish', 'baseline_finish'],
        'start_actual' => ['start_actual', 'actual_start'],
        'finish_actual' => ['finish_actual', 'actual_finish'],
        'duration' => ['duration_minutes', 'duration_days', 'duration', 'original_duration', 'remaining_duration'],
        'total_float' => ['total_float_minutes', 'total_float_days', 'total_float', 'float'],
        'critical' => ['is_critical', 'critical'],
        'near_critical' => ['is_near_critical', 'near_critical'],
        'calendar' => ['calendar', 'calendar_name'],
        'constraint_type' => ['constraint_type', 'constraint'],
        'constraint_at' => ['constraint_at', 'constraint_date'],
        'predecessors' => ['predecessors', 'predecessor_details', 'logic'],
        'resources' => ['resources', 'resource_names', 'resource'],
        'weather_sensitive' => ['weather_sensitive', 'weather'],
        'header_path' => ['header_path', 'group_path', 'area'],
    ];

    public function parse(UploadedFile $file): ParsedSchedule
    {
        return match (strtolower($file->getClientOriginalExtension())) {
            'csv' => $this->parseCsv($file->getRealPath()),
            'xlsx' => $this->parseXlsx($file->getRealPath()),
            'xml' => (new MspdiScheduleParser)->parse($file->getRealPath()),
            default => throw new UnsafeScheduleUpload('This schedule format is not enabled.'),
        };
    }

    private function parseCsv(string $path): ParsedSchedule
    {
        $stream = new \SplFileObject($path, 'rb');
        $firstLine = (string) $stream->fgets();
        $delimiter = $this->detectDelimiter($firstLine);
        $stream->rewind();
        $stream->setFlags(\SplFileObject::READ_CSV | \SplFileObject::SKIP_EMPTY | \SplFileObject::DROP_NEW_LINE);
        $stream->setCsvControl($delimiter);

        $rows = [];
        $encoding = 'UTF-8';
        foreach ($stream as $rowNumber => $row) {
            if (! is_array($row) || $row === [null]) {
                continue;
            }
            if (count($row) > (int) config('schedule.max_columns', 100)) {
                throw new UnsafeScheduleUpload('The CSV contains more columns than the configured safety limit.');
            }
            $converted = [];
            foreach ($row as $value) {
                $value = is_string($value) ? $value : (string) $value;
                if (! mb_check_encoding($value, 'UTF-8')) {
                    $value = mb_convert_encoding($value, 'UTF-8', 'Windows-1252');
                    $encoding = 'Windows-1252 converted to UTF-8';
                }
                $converted[] = $this->safeCell($value, $rowNumber + 1);
            }
            $rows[] = $converted;
            if (count($rows) > (int) config('schedule.max_rows', 50000) + 1) {
                throw new UnsafeScheduleUpload('The CSV exceeds the configured row limit.');
            }
        }

        return $this->fromRows($rows, [], $encoding);
    }

    private function parseXlsx(string $path): ParsedSchedule
    {
        $reader = IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(true);
        $reader->setReadEmptyCells(false);
        $book = $reader->load($path);
        try {
            if ($book->getSheetCount() > 20) {
                throw new UnsafeScheduleUpload('The workbook contains more than 20 sheets.');
            }

            $sheet = $book->getSheetByName('Activities') ?? $book->getSheet(0);
            $rows = $this->worksheetRows($sheet);
            $calendarSheet = $book->getSheetByName('Calendars');
            $calendarRows = $calendarSheet ? $this->worksheetRows($calendarSheet) : [];

            return $this->fromRows($rows, $calendarRows, 'XLSX Open XML');
        } finally {
            $book->disconnectWorksheets();
        }
    }

    /** @return list<list<mixed>> */
    private function worksheetRows(Worksheet $sheet): array
    {
        $maxRows = (int) config('schedule.max_rows', 50000) + 1;
        $maxColumns = (int) config('schedule.max_columns', 100);
        $highestRow = min($sheet->getHighestDataRow(), $maxRows);
        if ($sheet->getHighestDataRow() > $maxRows) {
            throw new UnsafeScheduleUpload("Worksheet '{$sheet->getTitle()}' exceeds the configured row limit.");
        }
        $highestColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
        if ($highestColumn > $maxColumns) {
            throw new UnsafeScheduleUpload("Worksheet '{$sheet->getTitle()}' exceeds the configured column limit.");
        }

        $rows = [];
        $lastColumn = Coordinate::stringFromColumnIndex(max(1, $highestColumn));
        for ($row = 1; $row <= $highestRow; $row++) {
            for ($column = 1; $column <= $highestColumn; $column++) {
                $cell = $sheet->getCell([$column, $row]);
                if ($cell->getDataType() === DataType::TYPE_FORMULA) {
                    throw new UnsafeScheduleUpload("Formulas are not accepted in schedule imports ({$sheet->getTitle()} row {$row}). Export values instead.");
                }
            }
            $values = $sheet->rangeToArray("A{$row}:{$lastColumn}{$row}", null, false, false, false)[0] ?? [];
            $safe = [];
            foreach ($values as $value) {
                $safe[] = is_string($value) ? $this->safeCell($value, $row) : $value;
            }
            $rows[] = $safe;
        }

        return $rows;
    }

    /**
     * @param  list<list<mixed>>  $rows
     * @param  list<list<mixed>>  $calendarRows
     */
    private function fromRows(array $rows, array $calendarRows, string $encoding): ParsedSchedule
    {
        if (count($rows) < 2) {
            throw new UnsafeScheduleUpload('The schedule must contain a header row and at least one activity.');
        }

        $headers = array_map(fn ($value) => $this->normalizeHeader((string) $value), $rows[0]);
        $map = $this->headerMap($headers);
        foreach (['activity_code', 'name'] as $required) {
            if (! isset($map[$required])) {
                throw new UnsafeScheduleUpload("The schedule is missing the required '{$required}' column.");
            }
        }

        $activities = [];
        $seenCodes = [];
        $assumptions = [];
        $warnings = [];
        $calendarNames = [];
        $durationNumericUnit = $this->numericUnitForHeader(
            isset($map['duration']) ? ($headers[$map['duration']] ?? 'duration_days') : 'duration_days'
        );
        $floatNumericUnit = $this->numericUnitForHeader(
            isset($map['total_float']) ? ($headers[$map['total_float']] ?? 'total_float_days') : 'total_float_days'
        );
        foreach (array_slice($rows, 1) as $offset => $row) {
            $rowNumber = $offset + 2;
            $code = trim((string) ($row[$map['activity_code']] ?? ''));
            $name = trim((string) ($row[$map['name']] ?? ''));
            if ($code === '' && $name === '') {
                continue;
            }
            if ($code === '' || $name === '') {
                throw new UnsafeScheduleUpload("Activity row {$rowNumber} must contain both a code and name.");
            }
            if (isset($seenCodes[$code])) {
                throw new UnsafeScheduleUpload("Duplicate activity code '{$code}' appears on rows {$seenCodes[$code]} and {$rowNumber}.");
            }
            $seenCodes[$code] = $rowNumber;

            $plannedStart = $this->dateValue($this->value($row, $map, 'start_planned'), $rowNumber, 'planned start');
            $plannedFinish = $this->dateValue($this->value($row, $map, 'finish_planned'), $rowNumber, 'planned finish');
            $duration = $this->durationMinutes($this->value($row, $map, 'duration'), numericUnit: $durationNumericUnit);
            if ($duration === null && $plannedStart && $plannedFinish) {
                $elapsedDays = max(0, (int) $plannedStart->diff($plannedFinish)->format('%a'));
                $duration = max(0, $elapsedDays * 480);
                $assumptions['derived_duration'] = 'Missing durations were derived as elapsed calendar days multiplied by 480 minutes.';
            }
            if ($duration === null) {
                throw new UnsafeScheduleUpload("Activity '{$code}' needs a duration or both planned dates.");
            }

            $calendar = trim((string) ($this->value($row, $map, 'calendar') ?? 'Standard')) ?: 'Standard';
            $calendarNames[$calendar] = true;
            $activities[] = [
                'activity_code' => $code,
                'name' => $name,
                'wbs_path' => $this->nullableString($this->value($row, $map, 'wbs_path')),
                'start_planned' => $plannedStart,
                'finish_planned' => $plannedFinish,
                'start_actual' => $this->dateValue($this->value($row, $map, 'start_actual'), $rowNumber, 'actual start'),
                'finish_actual' => $this->dateValue($this->value($row, $map, 'finish_actual'), $rowNumber, 'actual finish'),
                'duration_minutes' => $duration,
                'total_float_minutes' => $this->durationMinutes(
                    $this->value($row, $map, 'total_float'),
                    allowNegative: true,
                    numericUnit: $floatNumericUnit,
                ),
                'is_critical' => $this->boolValue($this->value($row, $map, 'critical')),
                'is_near_critical' => $this->boolValue($this->value($row, $map, 'near_critical')),
                'calendar' => $calendar,
                'constraint_type' => $this->nullableString($this->value($row, $map, 'constraint_type')),
                'constraint_at' => $this->dateValue($this->value($row, $map, 'constraint_at'), $rowNumber, 'constraint date'),
                'predecessors' => $this->predecessors((string) ($this->value($row, $map, 'predecessors') ?? ''), $rowNumber),
                'resources' => $this->resources((string) ($this->value($row, $map, 'resources') ?? '')),
                'weather_sensitive' => $this->boolValue($this->value($row, $map, 'weather_sensitive')),
                'header_path' => $this->nullableString($this->value($row, $map, 'header_path')),
                'ingestion_confidence' => 1.0,
                'confirmation_status' => 'confirmed',
            ];
        }

        if ($activities === []) {
            throw new UnsafeScheduleUpload('No activity rows were found.');
        }

        $calendars = $this->calendars($calendarRows, array_keys($calendarNames), $assumptions, $warnings);

        return new ParsedSchedule(
            activities: $activities,
            calendars: $calendars,
            assumptions: array_values($assumptions),
            warnings: $warnings,
            encoding: $encoding,
        );
    }

    /**
     * @param  list<list<mixed>>  $rows
     * @param  list<string>  $usedNames
     * @param  array<string,string>  $assumptions
     * @param  list<string>  $warnings
     * @return list<array<string,mixed>>
     */
    private function calendars(array $rows, array $usedNames, array &$assumptions, array &$warnings): array
    {
        $definitions = [];
        if ($rows !== []) {
            $headers = array_map(fn ($v) => $this->normalizeHeader((string) $v), $rows[0]);
            $indexes = array_flip($headers);
            foreach (array_slice($rows, 1) as $offset => $row) {
                $name = trim((string) ($row[$indexes['calendar_name'] ?? $indexes['calendar'] ?? -1] ?? ''));
                if ($name === '') {
                    continue;
                }
                $definition = &$definitions[$name];
                $definition ??= [
                    'external_uid' => $name,
                    'name' => $name,
                    'time_zone' => (string) ($row[$indexes['time_zone'] ?? -1] ?? config('app.timezone', 'UTC')),
                    'minutes_per_day' => 480,
                    'inherits' => null,
                    'source_basis' => 'workbook_calendars_sheet',
                    'periods' => [],
                    'exceptions' => [],
                ];
                $inherits = trim((string) ($row[$indexes['inherits'] ?? -1] ?? ''));
                if ($inherits !== '') {
                    $definition['inherits'] = $inherits;
                }
                $weekday = (int) ($row[$indexes['weekday_iso'] ?? $indexes['weekday'] ?? -1] ?? 0);
                $start = trim((string) ($row[$indexes['start_time'] ?? -1] ?? ''));
                $end = trim((string) ($row[$indexes['end_time'] ?? -1] ?? ''));
                if ($weekday >= 1 && $weekday <= 7 && $start !== '' && $end !== '') {
                    $definition['periods'][] = ['weekday_iso' => $weekday, 'starts_at' => $start, 'ends_at' => $end];
                }
                $exceptionDate = trim((string) ($row[$indexes['exception_date'] ?? -1] ?? ''));
                if ($exceptionDate !== '') {
                    $definition['exceptions'][] = [
                        'date' => (new DateTimeImmutable($exceptionDate))->format('Y-m-d'),
                        'is_working' => $this->boolValue($row[$indexes['is_working'] ?? -1] ?? false),
                        'label' => $this->nullableString($row[$indexes['label'] ?? -1] ?? null),
                        'periods' => $start !== '' && $end !== '' ? [['starts_at' => $start, 'ends_at' => $end]] : [],
                    ];
                }
                unset($definition);
            }
        }

        foreach ($usedNames as $name) {
            if (! isset($definitions[$name])) {
                $definitions[$name] = $this->standardCalendar($name);
                $assumptions['standard_calendar_'.$name] = "Calendar '{$name}' was not fully defined; Monday-Friday 08:00-12:00 and 13:00-17:00 in the application time zone was assumed.";
            } elseif ($definitions[$name]['periods'] === []) {
                $definitions[$name]['periods'] = $this->standardCalendar($name)['periods'];
                $warnings[] = "Calendar '{$name}' had no working periods; the explicit standard-day assumption was applied.";
            }
        }

        return array_values($definitions);
    }

    /** @return array<string,mixed> */
    private function standardCalendar(string $name): array
    {
        $periods = [];
        foreach (range(1, 5) as $weekday) {
            $periods[] = ['weekday_iso' => $weekday, 'starts_at' => '08:00:00', 'ends_at' => '12:00:00'];
            $periods[] = ['weekday_iso' => $weekday, 'starts_at' => '13:00:00', 'ends_at' => '17:00:00'];
        }

        return [
            'external_uid' => $name,
            'name' => $name,
            'time_zone' => config('app.timezone', 'UTC'),
            'minutes_per_day' => 480,
            'inherits' => null,
            'source_basis' => 'explicit_import_assumption',
            'periods' => $periods,
            'exceptions' => [],
        ];
    }

    /** @param list<string> $headers @return array<string,int> */
    private function headerMap(array $headers): array
    {
        $map = [];
        foreach (self::HEADER_ALIASES as $canonical => $aliases) {
            foreach ($aliases as $alias) {
                $index = array_search($alias, $headers, true);
                if ($index !== false) {
                    $map[$canonical] = $index;
                    break;
                }
            }
        }

        return $map;
    }

    private function normalizeHeader(string $value): string
    {
        $value = preg_replace('/^\xEF\xBB\xBF/', '', $value) ?? $value;
        $value = strtolower(trim($value));

        return trim((string) preg_replace('/[^a-z0-9]+/', '_', $value), '_');
    }

    /** @param list<mixed> $row @param array<string,int> $map */
    private function value(array $row, array $map, string $key): mixed
    {
        return isset($map[$key]) ? ($row[$map[$key]] ?? null) : null;
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));

        return $value === '' ? null : $value;
    }

    private function dateValue(mixed $value, int $row, string $field): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            if (is_numeric($value) && (float) $value > 1000) {
                return DateTimeImmutable::createFromMutable(SpreadsheetDate::excelToDateTimeObject((float) $value));
            }

            return new DateTimeImmutable((string) $value, new DateTimeZone((string) config('app.timezone', 'UTC')));
        } catch (\Throwable) {
            throw new UnsafeScheduleUpload("Row {$row} contains an invalid {$field} value.");
        }
    }

    private function durationMinutes(mixed $value, bool $allowNegative = false, string $numericUnit = 'days'): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (is_numeric($value)) {
            $number = (float) $value;
            $minutes = match ($numericUnit) {
                'minutes' => (int) round($number),
                'hours' => (int) round($number * 60),
                default => (int) round($number * 480),
            };
        } elseif (preg_match('/^\s*([+-]?\d+(?:\.\d+)?)\s*(d|day|days|h|hr|hrs|m|min|mins)?\s*$/i', (string) $value, $match)) {
            $number = (float) $match[1];
            $unit = strtolower($match[2] ?? 'd');
            $minutes = (int) round($number * (str_starts_with($unit, 'h') ? 60 : (str_starts_with($unit, 'm') ? 1 : 480)));
        } else {
            throw new UnsafeScheduleUpload("Invalid duration or float value '{$value}'.");
        }
        if (! $allowNegative && $minutes < 0) {
            throw new UnsafeScheduleUpload('Activity duration cannot be negative.');
        }

        return $minutes;
    }

    private function numericUnitForHeader(string $header): string
    {
        return match (true) {
            str_ends_with($header, '_minutes') => 'minutes',
            str_ends_with($header, '_hours') => 'hours',
            default => 'days',
        };
    }

    private function boolValue(mixed $value): bool
    {
        return in_array(strtolower(trim((string) $value)), ['1', 'true', 'yes', 'y', 'critical'], true);
    }

    /** @return list<array{code:string,type:string,lag_minutes:int}> */
    private function predecessors(string $value, int $row): array
    {
        $result = [];
        foreach (preg_split('/[;,]+/', $value) ?: [] as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            if (! preg_match('/^(.+?)(?:\s*[:|]\s*|\s+)?(FS|SS|FF|SF)(?:\s*([+-]\s*\d+(?:\.\d+)?\s*[dhm]?))?$/i', $part, $match)) {
                // A bare activity code is an FS relationship with zero lag.
                if (preg_match('/^[A-Za-z0-9_.\/-]+$/', $part)) {
                    $result[] = ['code' => $part, 'type' => 'FS', 'lag_minutes' => 0];

                    continue;
                }
                throw new UnsafeScheduleUpload("Row {$row} contains invalid predecessor syntax '{$part}'.");
            }
            $lag = str_replace(' ', '', $match[3] ?? '0m');
            $result[] = [
                'code' => trim($match[1]),
                'type' => strtoupper($match[2]),
                'lag_minutes' => $this->durationMinutes($lag, allowNegative: true) ?? 0,
            ];
        }

        return $result;
    }

    /** @return list<array<string,mixed>> */
    private function resources(string $value): array
    {
        $resources = [];
        foreach (preg_split('/[;,]+/', $value) ?: [] as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            $fields = array_map('trim', explode('|', $part));
            $resources[] = [
                'resource_code' => count($fields) > 1 ? ($fields[0] ?: null) : null,
                'resource_name' => count($fields) > 1 ? $fields[1] : $fields[0],
                'resource_type' => $fields[2] ?? null,
                'allocation_units' => isset($fields[3]) && is_numeric($fields[3]) ? (float) $fields[3] : null,
            ];
        }

        return $resources;
    }

    private function safeCell(string $value, int $row): string
    {
        if (strlen($value) > 10000) {
            throw new UnsafeScheduleUpload("Row {$row} contains a cell larger than 10,000 bytes.");
        }
        $trimmed = ltrim($value);
        if (preg_match('/^[=+@]/', $trimmed) || preg_match('/^-[A-Za-z(]/', $trimmed)) {
            throw new UnsafeScheduleUpload("Formula-like content is not accepted (row {$row}); export computed values instead.");
        }

        return $value;
    }

    private function detectDelimiter(string $line): string
    {
        $counts = [',' => substr_count($line, ','), "\t" => substr_count($line, "\t"), ';' => substr_count($line, ';')];
        arsort($counts);
        $delimiter = array_key_first($counts);

        return ($counts[$delimiter] ?? 0) > 0 ? $delimiter : ',';
    }
}
