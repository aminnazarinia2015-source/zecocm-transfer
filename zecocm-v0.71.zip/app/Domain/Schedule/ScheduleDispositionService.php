<?php

namespace App\Domain\Schedule;

use App\Models\ScheduleVersion;
use App\Models\ScheduleVersionEvent;
use Illuminate\Support\Facades\DB;

final class ScheduleDispositionService
{
    /** @param array<string,mixed> $payload */
    public function append(
        ScheduleVersion $version,
        string $eventType,
        ?string $disposition,
        array $payload,
        ?int $actorId,
    ): ScheduleVersionEvent {
        return DB::transaction(function () use ($version, $eventType, $disposition, $payload, $actorId) {
            $previous = ScheduleVersionEvent::query()
                ->where('schedule_version_id', $version->id)
                ->orderByDesc('id')
                ->lockForUpdate()
                ->first();
            $occurredAt = now();
            $canonical = [
                'schedule_version_id' => $version->id,
                'event_type' => $eventType,
                'disposition' => $disposition,
                'payload' => $payload,
                'actor_id' => $actorId,
                'occurred_at' => $occurredAt->toIso8601String(),
                'previous_event_hash' => $previous?->event_hash,
            ];

            $event = ScheduleVersionEvent::create($canonical + [
                'tenant_id' => $version->tenant_id,
                'event_hash' => hash('sha256', json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)),
            ]);

            if ($disposition !== null) {
                // This is a cache/projection. The event chain above is canonical.
                ScheduleVersion::query()->whereKey($version->id)->update([
                    'review_status' => $disposition,
                    'updated_at' => $occurredAt,
                ]);
                $version->review_status = $disposition;
            }

            return $event;
        });
    }
}
