<?php

namespace App\Domain\Schedule;

final class DeltaComparator
{
    /**
     * @param  array<string,mixed>|null  $from
     * @param  array<string,mixed>|null  $to
     * @return list<array<string,mixed>>
     */
    public function compare(?array $from, ?array $to, string $relation): array
    {
        if ($from === null) {
            return [[
                'delta_type' => 'added', 'field' => null, 'magnitude_minutes' => null,
                'before_value' => null, 'after_value' => $to['activity_code'],
                'explanation' => "Activity {$to['activity_code']} - {$to['name']} was added.",
                'classification' => 'fact',
            ]];
        }
        if ($to === null) {
            return [[
                'delta_type' => 'deleted', 'field' => null, 'magnitude_minutes' => null,
                'before_value' => $from['activity_code'], 'after_value' => null,
                'explanation' => "Activity {$from['activity_code']} - {$from['name']} was deleted.",
                'classification' => 'fact',
            ]];
        }

        if (in_array($relation, ['split', 'merged'], true)) {
            return [[
                'delta_type' => $relation, 'field' => 'activity_identity', 'magnitude_minutes' => null,
                'before_value' => $from['activity_code'], 'after_value' => $to['activity_code'],
                'explanation' => "Activity identity was mapped as {$relation}; review the relational mapping edges before relying on activity-level variance.",
                'classification' => 'deterministic_calculation',
            ]];
        }

        $deltas = [];
        if ($from['activity_code'] !== $to['activity_code'] || $from['name'] !== $to['name']) {
            $deltas[] = $this->delta(
                'identity', 'activity_identity', null,
                $from['activity_code'].' - '.$from['name'],
                $to['activity_code'].' - '.$to['name'],
                "Activity {$from['activity_code']} is mapped to {$to['activity_code']} ({$relation})."
            );
        }
        $this->dateDelta($deltas, 'start_planned', 'planned start', $from, $to);
        $this->dateDelta($deltas, 'finish_planned', 'planned finish', $from, $to);
        $this->dateDelta($deltas, 'start_actual', 'actual start', $from, $to, 'actuals');
        $this->dateDelta($deltas, 'finish_actual', 'actual finish', $from, $to, 'actuals');
        $this->numericDelta($deltas, 'duration_minutes', 'duration', $from, $to);
        $this->numericDelta($deltas, 'total_float_minutes', 'float', $from, $to);

        if ((bool) $from['is_critical'] !== (bool) $to['is_critical']) {
            $deltas[] = $this->delta(
                'criticality', 'is_critical', null,
                (bool) $from['is_critical'], (bool) $to['is_critical'],
                "Activity {$to['activity_code']} critical-path flag changed from ".($from['is_critical'] ? 'critical' : 'not critical').' to '.($to['is_critical'] ? 'critical' : 'not critical').'.'
            );
        }
        foreach ([
            ['logic', 'logic_signature', 'predecessor logic'],
            ['calendar', 'calendar_name', 'calendar assignment'],
            ['constraint', 'constraint_signature', 'constraint'],
        ] as [$type, $field, $label]) {
            if (($from[$field] ?? null) !== ($to[$field] ?? null)) {
                $deltas[] = $this->delta(
                    $type, $field, null, $from[$field] ?? null, $to[$field] ?? null,
                    "Activity {$to['activity_code']} {$label} changed."
                );
            }
        }

        return $deltas;
    }

    /** @param list<array<string,mixed>> $deltas @param array<string,mixed> $from @param array<string,mixed> $to */
    private function dateDelta(array &$deltas, string $field, string $label, array $from, array $to, string $type = 'date'): void
    {
        $before = $from[$field] ?? null;
        $after = $to[$field] ?? null;
        if ($this->stringValue($before) === $this->stringValue($after)) {
            return;
        }
        $magnitude = $before && $after
            ? intdiv((new \DateTimeImmutable((string) $after))->getTimestamp() - (new \DateTimeImmutable((string) $before))->getTimestamp(), 60)
            : null;
        $direction = $magnitude === null ? 'changed' : ($magnitude >= 0 ? 'moved later' : 'moved earlier');
        $deltas[] = $this->delta(
            $type, $field, $magnitude, $before, $after,
            "Activity {$to['activity_code']} {$label} {$direction}".($magnitude === null ? '.' : ' by '.round(abs($magnitude) / 1440, 2).' calendar days.'),
            // Wall-clock elapsed minutes between two timestamps - NEVER a workday quantity.
            'elapsed_minutes'
        );
    }

    /** @param list<array<string,mixed>> $deltas @param array<string,mixed> $from @param array<string,mixed> $to */
    private function numericDelta(array &$deltas, string $field, string $type, array $from, array $to): void
    {
        $before = $from[$field] ?? null;
        $after = $to[$field] ?? null;
        if ($before === $after || ($before === null && $after === null)) {
            return;
        }
        $magnitude = $before !== null && $after !== null ? (int) $after - (int) $before : null;
        $deltas[] = $this->delta(
            $type, $field, $magnitude, $before, $after,
            "Activity {$to['activity_code']} {$type} changed".($magnitude === null ? '.' : ' by '.round($magnitude / 480, 2).' standard work days.'),
            // Working minutes from the source schedule's duration/float fields.
            $type === 'duration' ? 'duration_work_minutes' : 'float_work_minutes'
        );
    }

    /** @return array<string,mixed> */
    private function delta(string $type, ?string $field, ?int $magnitude, mixed $before, mixed $after, string $explanation, ?string $magnitudeBasis = null): array
    {
        return [
            'delta_type' => $type,
            'field' => $field,
            'magnitude_minutes' => $magnitude,
            'magnitude_basis' => $magnitude === null ? null : $magnitudeBasis,
            'before_value' => $this->stringValue($before),
            'after_value' => $this->stringValue($after),
            'explanation' => $explanation,
            'classification' => 'deterministic_calculation',
        ];
    }

    private function stringValue(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }
        if ($value instanceof \DateTimeInterface) {
            return $value->format(DATE_ATOM);
        }
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }
        if (is_array($value)) {
            return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        }

        return (string) $value;
    }
}
