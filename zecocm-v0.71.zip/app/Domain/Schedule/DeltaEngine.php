<?php

namespace App\Domain\Schedule;

use App\Models\ActivityMappingGroup;
use App\Models\AnalysisRun;
use App\Models\ScheduleActivity;
use App\Models\ScheduleActivityRelationship;
use App\Models\ScheduleDelta;
use App\Models\ScheduleVersion;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class DeltaEngine
{
    public function __construct(private readonly DeltaComparator $comparator) {}

    /** @param Collection<int,ActivityMappingGroup> $groups */
    public function replaceForRun(AnalysisRun $run, Collection $groups): int
    {
        $fromVersion = ScheduleVersion::query()->findOrFail($run->from_version_id);
        $toVersion = ScheduleVersion::query()->findOrFail($run->to_version_id);
        $fromActivities = $this->activitySnapshots($fromVersion->id);
        $toActivities = $this->activitySnapshots($toVersion->id);

        return DB::transaction(function () use ($run, $groups, $fromVersion, $toVersion, $fromActivities, $toActivities) {
            // Retry replacement is scoped to this run and recorded by the job's outbox event.
            DB::table('schedule_delta_sources')->whereIn('schedule_delta_id', function ($query) use ($run) {
                $query->select('id')->from('schedule_deltas')->where('analysis_run_id', $run->id);
            })->delete();
            DB::table('schedule_delta_record_links')->whereIn('schedule_delta_id', function ($query) use ($run) {
                $query->select('id')->from('schedule_deltas')->where('analysis_run_id', $run->id);
            })->delete();
            DB::table('schedule_deltas')->where('analysis_run_id', $run->id)->delete();

            $count = 0;
            foreach ($groups as $group) {
                $fromIds = $group->edges->pluck('from_activity_id')->filter()->unique()->values();
                $toIds = $group->edges->pluck('to_activity_id')->filter()->unique()->values();
                $pairs = [];
                if ($fromIds->isEmpty()) {
                    foreach ($toIds as $toId) {
                        $pairs[] = [null, $toId];
                    }
                } elseif ($toIds->isEmpty()) {
                    foreach ($fromIds as $fromId) {
                        $pairs[] = [$fromId, null];
                    }
                } else {
                    foreach ($fromIds as $fromId) {
                        foreach ($toIds as $toId) {
                            $pairs[] = [$fromId, $toId];
                        }
                    }
                }

                foreach ($pairs as [$fromId, $toId]) {
                    $from = $fromId ? ($fromActivities[$fromId] ?? null) : null;
                    $to = $toId ? ($toActivities[$toId] ?? null) : null;
                    foreach ($this->comparator->compare($from, $to, $group->relation) as $row) {
                        $delta = ScheduleDelta::create($row + [
                            'project_id' => $run->project_id,
                            'analysis_run_id' => $run->id,
                            'from_version_id' => $run->from_version_id,
                            'to_version_id' => $run->to_version_id,
                            'mapping_group_id' => $group->id,
                            'from_activity_id' => $fromId,
                            'to_activity_id' => $toId,
                            'canonical_id' => $from['canonical_id'] ?? $to['canonical_id'] ?? null,
                        ]);
                        $this->source($delta, $fromVersion, $fromId);
                        $this->source($delta, $toVersion, $toId);
                        $count++;
                    }
                }
            }

            $fromFinish = $this->maximumFinish($fromActivities);
            $toFinish = $this->maximumFinish($toActivities);
            if ($fromFinish && $toFinish && $fromFinish != $toFinish) {
                $magnitude = intdiv($toFinish->getTimestamp() - $fromFinish->getTimestamp(), 60);
                $delta = ScheduleDelta::create([
                    'project_id' => $run->project_id,
                    'analysis_run_id' => $run->id,
                    'from_version_id' => $run->from_version_id,
                    'to_version_id' => $run->to_version_id,
                    'delta_type' => 'completion_movement',
                    'field' => 'project_completion',
                    'magnitude_minutes' => $magnitude,
                    'magnitude_basis' => 'elapsed_minutes',
                    'before_value' => $fromFinish->format(DATE_ATOM),
                    'after_value' => $toFinish->format(DATE_ATOM),
                    'explanation' => 'Latest planned project completion moved '.round(abs($magnitude) / 1440, 2).' calendar days '.($magnitude >= 0 ? 'later.' : 'earlier.'),
                    'classification' => 'deterministic_calculation',
                ]);
                $this->source($delta, $fromVersion, null);
                $this->source($delta, $toVersion, null);
                $count++;
            }

            return $count;
        });
    }

    /** @return array<int,array<string,mixed>> */
    private function activitySnapshots(int $versionId): array
    {
        $activities = ScheduleActivity::query()
            ->where('schedule_version_id', $versionId)
            ->with(['calendarAssignments.calendar'])
            ->get()
            ->keyBy('id');
        $relationships = ScheduleActivityRelationship::query()
            ->where('schedule_version_id', $versionId)
            ->get()
            ->groupBy('successor_activity_id');

        $result = [];
        foreach ($activities as $id => $activity) {
            $logic = ($relationships[$id] ?? collect())->map(function ($relationship) use ($activities) {
                $pred = $activities[$relationship->predecessor_activity_id] ?? null;

                return ($pred?->activity_code ?? '?').':'.$relationship->relationship_type.':'.$relationship->lag_minutes;
            })->sort()->values()->all();
            $constraint = trim((string) $activity->constraint_type.':'.($activity->constraint_at?->format(DATE_ATOM) ?? ''));
            $row = $activity->toArray();
            $row['logic_signature'] = json_encode($logic, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            $row['calendar_name'] = $activity->calendarAssignments->first()?->calendar?->name;
            $row['constraint_signature'] = $constraint === ':' ? null : $constraint;
            $result[(int) $id] = $row;
        }

        return $result;
    }

    private function source(ScheduleDelta $delta, ScheduleVersion $version, ?int $activityId): void
    {
        DB::table('schedule_delta_sources')->insert([
            'tenant_id' => $version->tenant_id,
            'schedule_delta_id' => $delta->id,
            'schedule_version_id' => $version->id,
            'media_item_id' => $version->source_file_media_id,
            'schedule_activity_id' => $activityId,
            'source_hash' => $version->source_sha256,
            'authorization_label' => 'schedule.view_source_metadata',
            'retrieved_at' => now(),
            'created_at' => now(),
        ]);
    }

    /** @param array<int,array<string,mixed>> $activities */
    private function maximumFinish(array $activities): ?\DateTimeImmutable
    {
        $finishes = [];
        foreach ($activities as $activity) {
            if (! empty($activity['finish_planned'])) {
                $finishes[] = new \DateTimeImmutable((string) $activity['finish_planned']);
            }
        }
        usort($finishes, fn ($a, $b) => $b <=> $a);

        return $finishes[0] ?? null;
    }
}
