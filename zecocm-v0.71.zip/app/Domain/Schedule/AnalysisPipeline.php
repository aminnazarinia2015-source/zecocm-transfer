<?php

namespace App\Domain\Schedule;

use App\Models\AnalysisRun;
use App\Models\ScheduleVersion;

final class AnalysisPipeline
{
    public function __construct(
        private readonly VersionMatcher $matcher,
        private readonly CpmAnalysisService $cpm,
        private readonly DeltaEngine $deltas,
    ) {}

    public function run(AnalysisRun $run): void
    {
        $from = ScheduleVersion::query()->where('project_id', $run->project_id)->findOrFail($run->from_version_id);
        $to = ScheduleVersion::query()->where('project_id', $run->project_id)->findOrFail($run->to_version_id);

        $this->stage($run, 'matching', 'running', 10);
        $groups = $this->matcher->ensureMappings($from, $to);
        $this->stage($run, 'matching', 'completed', 30, ['mapping_groups' => $groups->count()]);
        $this->cancelIfRequested($run);

        $this->stage($run, 'cpm_validation', 'running', 40);
        $fromCpm = $this->cpm->analyze($run, $from);
        $this->cancelIfRequested($run);
        $toCpm = $this->cpm->analyze($run, $to);
        $this->stage($run, 'cpm_validation', 'completed', 70, ['from' => $fromCpm, 'to' => $toCpm]);
        $this->cancelIfRequested($run);

        $this->stage($run, 'delta_ledger', 'running', 80);
        $count = $this->deltas->replaceForRun($run, $groups);
        $this->stage($run, 'delta_ledger', 'completed', 100, ['deltas' => $count]);

        $assumptions = $run->assumptions ?? [];
        $assumptions['cpm'] = array_values(array_unique([...$fromCpm['assumptions'], ...$toCpm['assumptions']]));
        $run->forceFill([
            'status' => 'completed',
            'progress_percent' => 100,
            'assumptions' => $assumptions,
            'finished_at' => now(),
            'error' => null,
        ])->save();
    }

    /** @param array<string,mixed> $details */
    private function stage(AnalysisRun $run, string $stage, string $status, int $progress, array $details = []): void
    {
        $stages = $run->stage_status ?? [];
        $stages[$stage] = ['status' => $status, 'at' => now()->toIso8601String()] + $details;
        $run->forceFill(['stage_status' => $stages, 'progress_percent' => $progress])->save();
    }

    private function cancelIfRequested(AnalysisRun $run): void
    {
        $run->refresh();
        if ($run->cancel_requested_at !== null) {
            $run->forceFill(['status' => 'cancelled', 'cancelled_at' => now(), 'finished_at' => now()])->save();
            throw new AnalysisCancelled('Analysis was cancelled by an authorized user.');
        }
    }
}
