<?php

namespace App\Domain\Schedule;

use App\Models\AnalysisRun;
use App\Models\ScheduleActivity;
use App\Models\ScheduleActivityRelationship;
use App\Models\ScheduleCalendar;
use App\Models\ScheduleVersion;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class CpmAnalysisService
{
    public function __construct(private readonly CpmEngine $engine) {}

    /** @return array{finish:string,issues:int,assumptions:list<string>} */
    public function analyze(AnalysisRun $run, ScheduleVersion $version): array
    {
        $calendars = ScheduleCalendar::query()
            ->where('schedule_version_id', $version->id)
            ->with(['workingPeriods', 'exceptions.periods'])
            ->get()
            ->keyBy('id');
        $built = [];
        $buildCalendar = function (int $id, array $stack = []) use (&$buildCalendar, &$built, $calendars): WorkingCalendar {
            if (isset($built[$id])) {
                return $built[$id];
            }
            if (in_array($id, $stack, true)) {
                throw new \DomainException('Calendar inheritance contains a cycle.');
            }
            $model = $calendars[$id] ?? throw new \DomainException("Calendar {$id} is missing from this schedule version.");
            $weekly = [];
            $exceptions = [];
            if ($model->inherits_calendar_id) {
                $parent = $buildCalendar((int) $model->inherits_calendar_id, [...$stack, $id]);
                // Rehydrate the parent's effective definition through its public calendar math inputs.
                // The source model is also available, so recursively merge raw relational rows here.
                [$weekly, $exceptions] = $this->rawCalendarDefinition((int) $model->inherits_calendar_id, $calendars, [...$stack, $id]);
            }
            [$ownWeekly, $ownExceptions] = $this->rawCalendarDefinition($id, $calendars, $stack, includeParent: false);
            foreach ($ownWeekly as $weekday => $periods) {
                $weekly[$weekday] = $periods;
            }
            foreach ($ownExceptions as $date => $periods) {
                $exceptions[$date] = $periods;
            }

            return $built[$id] = new WorkingCalendar(
                id: $model->id,
                name: $model->name,
                timeZone: new DateTimeZone($model->time_zone),
                weeklyPeriods: $weekly,
                exceptions: $exceptions,
            );
        };

        $activityModels = ScheduleActivity::query()
            ->where('schedule_version_id', $version->id)
            ->with('calendarAssignments')
            ->get();
        $activities = [];
        foreach ($activityModels as $activity) {
            $assignment = $activity->calendarAssignments->firstWhere('relationship', 'primary')
                ?? $activity->calendarAssignments->first();
            if ($assignment === null) {
                throw new \DomainException("Activity {$activity->activity_code} has no calendar assignment.");
            }
            $activities[] = [
                'id' => $activity->id,
                'code' => $activity->activity_code,
                'duration_minutes' => $activity->duration_minutes,
                'calendar' => $buildCalendar((int) $assignment->schedule_calendar_id),
                'start_planned' => $activity->start_planned,
                'finish_planned' => $activity->finish_planned,
                'start_actual' => $activity->start_actual,
                'finish_actual' => $activity->finish_actual,
                'constraint_type' => $activity->constraint_type,
                'constraint_at' => $activity->constraint_at,
            ];
        }
        $relationships = ScheduleActivityRelationship::query()
            ->where('schedule_version_id', $version->id)
            ->get()
            ->map(fn ($relationship) => [
                'predecessor_id' => $relationship->predecessor_activity_id,
                'successor_id' => $relationship->successor_activity_id,
                'type' => $relationship->relationship_type,
                'lag_minutes' => $relationship->lag_minutes,
            ])->all();

        $dataDate = new DateTimeImmutable($version->data_date->format('Y-m-d').' 08:00:00', new DateTimeZone(config('app.timezone', 'UTC')));
        $result = $this->engine->calculate($activities, $relationships, [
            'data_date' => $dataDate,
            'open_end_policy' => 'warn',
            'out_of_sequence_mode' => 'retain_logic',
            'near_critical_minutes' => config('schedule.near_critical_minutes'),
        ]);

        DB::transaction(function () use ($run, $version, $result): void {
            DB::table('analysis_activity_metrics')
                ->where('analysis_run_id', $run->id)
                ->whereIn('schedule_activity_id', function ($query) use ($version) {
                    $query->select('id')->from('schedule_activities')->where('schedule_version_id', $version->id);
                })->delete();
            DB::table('schedule_validation_issues')
                ->where('analysis_run_id', $run->id)
                ->where('schedule_version_id', $version->id)
                ->delete();

            foreach ($result->metrics as $activityId => $metric) {
                DB::table('analysis_activity_metrics')->insert([
                    'tenant_id' => $run->tenant_id,
                    'analysis_run_id' => $run->id,
                    'schedule_activity_id' => $activityId,
                    'early_start' => $metric['early_start'],
                    'early_finish' => $metric['early_finish'],
                    'late_start' => $metric['late_start'],
                    'late_finish' => $metric['late_finish'],
                    'total_float_minutes' => $metric['total_float_minutes'],
                    'is_critical' => $metric['is_critical'],
                    'is_near_critical' => $metric['is_near_critical'],
                    'created_at' => now(),
                ]);
            }
            foreach ($result->issues as $issue) {
                DB::table('schedule_validation_issues')->insert([
                    'tenant_id' => $run->tenant_id,
                    'analysis_run_id' => $run->id,
                    'schedule_version_id' => $version->id,
                    'schedule_activity_id' => $issue['activityId'],
                    'code' => $issue['code'],
                    'severity' => $issue['severity'],
                    'classification' => 'deterministic_calculation',
                    'message' => $issue['message'],
                    'details' => json_encode($issue['details'], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'created_at' => now(),
                ]);
            }
        });

        return [
            'finish' => $result->projectFinish->format(DATE_ATOM),
            'issues' => count($result->issues),
            'assumptions' => $result->assumptions,
        ];
    }

    /**
     * @param  Collection<int,ScheduleCalendar>  $calendars
     * @param  list<int>  $stack
     * @return array{array<int,list<array{0:string,1:string}>>,array<string,list<array{0:string,1:string}>>}
     */
    private function rawCalendarDefinition(int $id, $calendars, array $stack, bool $includeParent = true): array
    {
        if (in_array($id, $stack, true)) {
            throw new \DomainException('Calendar inheritance contains a cycle.');
        }
        $model = $calendars[$id] ?? throw new \DomainException("Calendar {$id} is missing.");
        $weekly = [];
        $exceptions = [];
        if ($includeParent && $model->inherits_calendar_id) {
            [$weekly, $exceptions] = $this->rawCalendarDefinition((int) $model->inherits_calendar_id, $calendars, [...$stack, $id]);
        }
        foreach ($model->workingPeriods->groupBy('weekday_iso') as $weekday => $periods) {
            $weekly[(int) $weekday] = $periods->map(fn ($period) => [
                substr((string) $period->starts_at, 0, 8),
                substr((string) $period->ends_at, 0, 8),
            ])->all();
        }
        foreach ($model->exceptions as $exception) {
            $exceptions[$exception->exception_date->format('Y-m-d')] = $exception->is_working
                ? $exception->periods->map(fn ($period) => [
                    substr((string) $period->starts_at, 0, 8),
                    substr((string) $period->ends_at, 0, 8),
                ])->all()
                : [];
        }

        return [$weekly, $exceptions];
    }
}
