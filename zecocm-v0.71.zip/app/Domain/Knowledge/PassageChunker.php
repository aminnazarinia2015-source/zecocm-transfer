<?php

namespace App\Domain\Knowledge;

/**
 * D3: blank-line chunking at a flat byte budget destroyed the citable unit.
 * Requirements split mid-sentence; a table's header row landed in one passage
 * and its value row in the next; a CSI section header was never a boundary
 * even though KnowledgeClassifier already regexes for the same pattern this
 * class uses to find one.
 *
 * Four boundary rules, in the order they are tried, and every emitted passage
 * says which one produced it - not for debugging, but because a retrieval
 * evaluation cannot tell "we chunked well" from "we got lucky" without seeing
 * which rule actually fired:
 *
 *   - header:  a section/sheet heading forces a new passage, and the passage
 *              carries its own header rather than a bare paragraph downstream
 *              of it with no idea what section it is under.
 *   - table:   a block detected as columnar text is never split, even when it
 *              runs over budget - a header row separated from its value row
 *              is a wrong answer; an oversized passage is only an inefficient
 *              one.
 *   - sentence: a single paragraph that alone exceeds the budget is split on
 *              sentence boundaries, never mid-sentence.
 *   - paragraph: the ordinary case - paragraphs packed to the budget, exactly
 *              as before, just no longer blind to the other three.
 */
final class PassageChunker
{
    public const BUDGET_BYTES = 1400;

    /**
     * Stamped onto every passage this chunker produces (see KnowledgeController),
     * so a chunk is traceable to the process version that drew its boundary -
     * per Codex's D3 closure criterion, not merely to the source it came from.
     * Bump this whenever the boundary rules change; a passage's chunking_version
     * is never rewritten in place.
     */
    public const VERSION = 'passage-chunker-v3-embedded-header-split';

    /**
     * D4/Codex's ruling: extraction is page-granular, but chunking stays
     * semantic-granular - a page break is a source-layout boundary, not a
     * meaning boundary, and construction specs routinely carry a sentence,
     * an exception clause, or a table across a page break. This marker lets
     * chunkPages() feed several pages' text through the SAME boundary-rule
     * logic as chunk() (untouched, unversioned by this addition) as one
     * continuous stream, then recover which page(s) each resulting passage
     * actually came from afterward - rather than duplicating or forking the
     * chunking rules themselves. \u{E000} is a Private Use Area code point;
     * it does not occur in real extracted text.
     */
    private const PAGE_MARKER = "\u{E000}";

    /**
     * Chunk several consecutive pages' text as one continuous stream so a
     * passage may span a page break, while still reporting which page(s)
     * produced it. Callers pass only pages they already know are safe to
     * stitch (currently: adjacent born-digital pages) - this method does not
     * decide that, it only preserves page provenance through the merge.
     *
     * Known v1 limitation: each page's text is trimmed before joining, so a
     * genuine blank line that existed at a page boundary in the source is
     * indistinguishable from none - the two pages are always joined as a
     * single potential paragraph and left to the same boundary rules as
     * chunk() to decide whether they actually merge. This favors wrongly
     * joining over wrongly cutting, per Codex's ruling that a hard page cut
     * is the worse failure mode.
     *
     * @param  list<array{page_number:int,text:string}>  $pages  in page order, already filtered to a stitchable run
     * @return list<array{body:string,section_ref:?string,boundary_rule:string,page_from:int,page_to:int}>
     */
    public function chunkPages(array $pages): array
    {
        if ($pages === []) {
            return [];
        }

        // The sentinel is an internal transport detail, not a promise about
        // what an untrusted PDF's text layer cannot contain. A page whose
        // extracted text happens to already carry this exact code point
        // must never be able to forge a page_from/page_to boundary that
        // did not come from this method's own join - strip it from every
        // page's text before it ever becomes part of the joined stream.
        $pages = array_map(
            fn (array $p) => array_merge($p, ['text' => str_replace(self::PAGE_MARKER, '', $p['text'])]),
            $pages,
        );

        if (count($pages) === 1) {
            return array_map(
                fn (array $c) => $c + ['page_from' => $pages[0]['page_number'], 'page_to' => $pages[0]['page_number']],
                $this->chunk($pages[0]['text']),
            );
        }

        $joined = trim($pages[0]['text']);
        for ($k = 1; $k < count($pages); $k++) {
            $joined .= "\n".self::PAGE_MARKER.'PB:'.$pages[$k]['page_number'].self::PAGE_MARKER."\n".trim($pages[$k]['text']);
        }

        $currentPage = $pages[0]['page_number'];
        $out = [];
        foreach ($this->chunk($joined) as $chunk) {
            $pageFrom = $currentPage;
            if (preg_match_all('/'.self::PAGE_MARKER.'PB:(\d+)'.self::PAGE_MARKER.'/u', $chunk['body'], $m) > 0) {
                $currentPage = (int) end($m[1]);
            }
            $body = trim(preg_replace('/\n?'.self::PAGE_MARKER.'PB:\d+'.self::PAGE_MARKER.'\n?/u', "\n", $chunk['body']) ?? $chunk['body']);

            $out[] = array_merge($chunk, ['body' => $body, 'page_from' => $pageFrom, 'page_to' => $currentPage]);
        }

        return $out;
    }

    /**
     * @return list<array{body:string,section_ref:?string,boundary_rule:string}>
     */
    public function chunk(string $text): array
    {
        // Collapse a run of spaces down to exactly two, never to one - a run
        // of two or more spaces is the columnar signal isTabular() looks for,
        // and normalizing it away to a single space here would blind the
        // table check before it ever runs.
        $text = trim(preg_replace('/ {2,}/', '  ', str_replace("\0", '', $text)) ?? '');
        if ($text === '') {
            return [];
        }

        $paragraphs = array_merge(
            ...array_map(fn ($p) => $this->splitOnEmbeddedHeaders($p), preg_split('/\n{2,}/', $text) ?: [$text])
        );
        $out = [];
        /** @var array{body:string,section_ref:?string,boundary_rule:string}|null $buffer */
        $buffer = null;

        $flush = function () use (&$buffer, &$out) {
            if ($buffer !== null && trim($buffer['body']) !== '') {
                $out[] = $buffer;
            }
            $buffer = null;
        };

        foreach ($paragraphs as $paragraph) {
            $paragraph = trim($paragraph);
            if ($paragraph === '') {
                continue;
            }

            $header = $this->detectSectionHeader($paragraph);
            if ($header !== null) {
                $flush();
                $buffer = ['body' => $paragraph, 'section_ref' => $header, 'boundary_rule' => 'header'];

                continue;
            }

            if ($this->isTabular($paragraph)) {
                $flush();
                $out[] = ['body' => $paragraph, 'section_ref' => null, 'boundary_rule' => 'table'];

                continue;
            }

            if (strlen($paragraph) > self::BUDGET_BYTES) {
                $flush();
                foreach ($this->splitOnSentences($paragraph) as $piece) {
                    $out[] = ['body' => $piece, 'section_ref' => null, 'boundary_rule' => 'sentence'];
                }

                continue;
            }

            if ($buffer === null) {
                $buffer = ['body' => $paragraph, 'section_ref' => null, 'boundary_rule' => 'paragraph'];

                continue;
            }

            if (strlen($buffer['body']) + 1 + strlen($paragraph) > self::BUDGET_BYTES) {
                $flush();
                $buffer = ['body' => $paragraph, 'section_ref' => null, 'boundary_rule' => 'paragraph'];

                continue;
            }

            $buffer['body'] .= "\n".$paragraph;
        }
        $flush();

        return array_slice($out, 0, 2000);
    }

    /**
     * A passage must never cross from one CSI section into another, even when
     * the extracted text has no blank line before the next header - real
     * extraction often runs a short section straight into the next heading
     * with a single newline. Splitting only on blank lines (as chunk() does
     * first) would let two sections ride together in one paragraph block and
     * bury the second header mid-text, past the point where detectSectionHeader
     * ever looks (it only checks a paragraph's first line). This scans every
     * line of a blank-line-delimited block and cuts a new block at each header
     * line found after the first, so the header always lands as some
     * paragraph's first line before the main loop ever sees it.
     *
     * @return list<string>
     */
    private function splitOnEmbeddedHeaders(string $paragraph): array
    {
        $lines = preg_split('/\n/', $paragraph) ?: [$paragraph];
        $blocks = [];
        $current = [];
        foreach ($lines as $i => $line) {
            if ($i > 0 && strlen(trim($line)) <= 120
                && preg_match('/\b\d{2}\s+\d{2}\s+\d{2}\b/', trim($line)) === 1
            ) {
                if ($current !== []) {
                    $blocks[] = implode("\n", $current);
                }
                $current = [$line];

                continue;
            }
            $current[] = $line;
        }
        if ($current !== []) {
            $blocks[] = implode("\n", $current);
        }

        return $blocks !== [] ? $blocks : [$paragraph];
    }

    /**
     * A section header is a CSI-numbered heading line - "SECTION 32 84 00",
     * "32 84 00 - IRRIGATION", or the bare code on its own line. The pattern
     * mirrors KnowledgeClassifier's own regex for the same code so the two
     * never disagree about what counts as a section; requiring the code to be
     * on a short first line (rather than matching anywhere in a paragraph of
     * running text) is what keeps an incidental in-sentence reference to a
     * section from being mistaken for the heading itself.
     */
    private function detectSectionHeader(string $paragraph): ?string
    {
        $firstLine = trim(strtok($paragraph, "\n") ?: $paragraph);

        if (strlen($firstLine) <= 120
            && preg_match('/\b(\d{2}\s+\d{2}\s+\d{2})\b/', $firstLine, $m) === 1
        ) {
            return $m[1];
        }

        return null;
    }

    /**
     * A paragraph reads as tabular when at least two of its lines carry a
     * columnar separator - a run of two or more spaces, or a tab - between
     * non-space tokens. That is the same shape a header row and its value row
     * take once pdftotext -layout has flattened a table to text: splitting
     * between those lines is exactly the failure the register named.
     */
    private function isTabular(string $paragraph): bool
    {
        $lines = preg_split('/\n/', $paragraph) ?: [];
        if (count($lines) < 2) {
            return false;
        }

        $columnar = 0;
        foreach ($lines as $line) {
            if (preg_match('/\S(?:  +|\t)\S/', $line) === 1) {
                $columnar++;
            }
        }

        return $columnar >= 2 && $columnar >= (int) ceil(count($lines) / 2);
    }

    /**
     * @return list<string>
     */
    private function splitOnSentences(string $paragraph): array
    {
        $sentences = preg_split('/(?<=[.!?])\s+(?=[A-Z0-9])/', $paragraph) ?: [$paragraph];
        $pieces = [];
        $buffer = '';
        foreach ($sentences as $sentence) {
            $sentence = trim($sentence);
            if ($sentence === '') {
                continue;
            }
            if ($buffer !== '' && strlen($buffer) + 1 + strlen($sentence) > self::BUDGET_BYTES) {
                $pieces[] = $buffer;
                $buffer = $sentence;

                continue;
            }
            $buffer .= ($buffer === '' ? '' : ' ').$sentence;

            // A single sentence longer than the whole budget cannot be split
            // further without inventing a boundary mid-clause; it stands alone
            // rather than being silently truncated.
            if (strlen($buffer) > self::BUDGET_BYTES) {
                $pieces[] = $buffer;
                $buffer = '';
            }
        }
        if ($buffer !== '') {
            $pieces[] = $buffer;
        }

        return $pieces;
    }
}
