<?php

namespace App\Domain\Knowledge;

final class KnowledgeClassifier
{
    /** @return array<string,mixed> */
    public function classify(string $title, string $text, string $requestedCorpus): array
    {
        $haystack = mb_strtolower($title.' '.$text);
        preg_match_all('/\b(?:section\s+)?(\d{2}\s+\d{2}\s+\d{2})\b/i', $text, $specs);
        preg_match_all('/\b([acelmpst]\d{1,3}(?:\.\d{1,3})?)\b/i', $text, $sheets);

        $discipline = match (true) {
            preg_match('/irrigation|landscape|planting/', $haystack) === 1 => 'landscape',
            preg_match('/structural|reinforcing|foundation/', $haystack) === 1 => 'structural',
            preg_match('/electrical|conduit|panelboard/', $haystack) === 1 => 'electrical',
            preg_match('/mechanical|hvac|duct/', $haystack) === 1 => 'mechanical',
            default => 'general',
        };

        return [
            'corpora' => [$requestedCorpus],
            'discipline' => $discipline,
            'specification_sections' => array_values(array_unique($specs[1] ?? [])),
            'drawing_references' => array_values(array_unique(array_map('strtoupper', $sheets[1] ?? []))),
            'classification_method' => 'deterministic-rules-v1',
            'classification_type' => 'deterministic_calculation',
        ];
    }
}
