<?php

namespace App\Domain\Knowledge;

use App\Models\AcquiredDocument;
use App\Models\AcquisitionWindow;
use DateTimeImmutable;
use Illuminate\Support\Facades\DB;

/**
 * Whether ZecoCM may reach outside the record right now, and for what.
 *
 * The resting state is SEALED. Not "sealed unless configured otherwise" -
 * sealed, with every outward reach having to name an open window that permits
 * it. A gate whose default is open and which relies on somebody remembering to
 * close it is not a gate.
 *
 * The check happens at the moment of the reach and nowhere else. This codebase
 * has already been bitten by the other pattern: a queued job read its
 * authorisation when it was DISPATCHED, and by the time a worker picked it up
 * the grant had been narrowed. A window that was open when the fetch was queued
 * and closed by the time it ran must refuse, so `permits()` takes the clock as
 * an argument and every caller passes the present moment rather than a
 * remembered one.
 *
 * WHAT THIS ENTITLES ANYONE TO CLAIM, precisely. ZecoCM does not RETRIEVE
 * anything outside your record unless a named person opened a window to let it
 * in, and the window closes on its own. It does not and cannot seal what the
 * language model already carries in its weights - nothing at this layer could.
 * That is a separate control and it is handled separately: the system prompt
 * forbids answering from general knowledge, and every answer must cite a
 * passage that was actually retrieved. Two different claims, both true, and
 * conflating them would be the kind of approximately-true security statement
 * that is worse than none.
 */
final class AcquisitionGate
{
    public const REQUESTED = 'requested';
    public const OPEN = 'open';
    public const CLOSED = 'closed';
    public const EXPIRED = 'expired';
    public const REVOKED = 'revoked';

    /**
     * The EVIDENTIARY axis. A steward's determination about what a document is
     * and whether it may support an answer. It moves.
     *
     * The other axis - whether text inside it may influence how the system
     * behaves - lives in InstructionTrust, has one value, and never moves.
     * Collapsing the two was the defect: quarantined -> verified reads as
     * "now trusted", and verification can only ever mean "admissible for its
     * stated purpose".
     */
    public const QUARANTINED = 'quarantined';
    public const VERIFIED = 'verified';
    public const REJECTED = 'rejected';
    public const RETRACTED = 'retracted';

    /**
     * May this window be used to fetch this source, right now?
     *
     * @return array{permitted: bool, reason: ?string}
     */
    public static function permits(?AcquisitionWindow $window, string $sourceIdentifier, ?DateTimeImmutable $now = null): array
    {
        $now ??= new DateTimeImmutable;

        if ($window === null) {
            return self::no('ZecoCM is sealed. Nothing outside this account\'s own governed record may be read '
                .'unless a named person has opened an acquisition window for it.');
        }

        if ($window->status !== self::OPEN) {
            return self::no('Acquisition window #'.$window->id.' is '.$window->status
                .'. Only an open window permits reading anything outside the record.');
        }

        // Checked here, at use, rather than trusted from the status column. A
        // row that says "open" and expired an hour ago is closed in fact, and
        // waiting for a scheduled task to notice would leave a real gap open.
        if ($window->expires_at !== null && $now > $window->expires_at->toDateTime()) {
            return self::no('Acquisition window #'.$window->id.' expired at '
                .$window->expires_at->toDateTimeString().'. The reach it granted is gone.');
        }

        if ($window->requires_two_person && $window->confirmed_at === null) {
            return self::no('Acquisition window #'.$window->id.' would bring in material capable of becoming '
                .'authoritative for a legal or contractual answer, so it needs a second named person to confirm it. '
                .'One person prepares and another confirms, for the same reason a payment certification does.');
        }

        $allowlist = (array) ($window->source_allowlist ?? []);

        // An empty allowlist is a window onto nowhere, never a window onto
        // everything. Default-open on an empty list is the single most common
        // way an allowlist becomes decorative.
        if ($allowlist === []) {
            return self::no('Acquisition window #'.$window->id.' names no permitted sources, so it permits nothing.');
        }

        if (! self::allowed($sourceIdentifier, $allowlist)) {
            return self::no('"'.$sourceIdentifier.'" is not among the sources acquisition window #'.$window->id
                .' permits ('.implode(', ', $allowlist).'). Widening it is a new authorisation, not a retry.');
        }

        // Reservations, not a count. Read-then-fetch lets two workers both see
        // nineteen of twenty and both proceed - the same defect the AI budget
        // gate had, three hours before this was written, which I did not carry
        // across at the time.
        $held = (int) $window->documents_reserved;

        if ($held >= (int) $window->max_documents) {
            return self::no('Acquisition window #'.$window->id.' has already taken or reserved its limit of '
                .$window->max_documents.' document(s). The count bounds how many things arrive; the clock is only a backstop.');
        }

        // Count says nothing about size. One "document" is a 2 KB page or an
        // 18 GB archive, and a window bounded only by count is not bounded.
        if ((int) $window->bytes_acquired >= (int) $window->max_total_bytes) {
            return self::no('Acquisition window #'.$window->id.' has reached its total size limit of '
                .number_format((int) $window->max_total_bytes / 1_048_576, 1).' MB. Count bounds how many documents '
                .'arrive; bytes bound how much does.');
        }

        return ['permitted' => true, 'reason' => null];
    }

    /**
     * Host matching that does not accept a lookalike.
     *
     * "dir.ca.gov" must match "dir.ca.gov" and "www.dir.ca.gov" and must NOT
     * match "dir.ca.gov.attacker.example" - which a naive str_contains or a
     * loose suffix check both cheerfully allow.
     */
    public static function allowed(string $sourceIdentifier, array $allowlist): bool
    {
        $host = strtolower((string) (parse_url($sourceIdentifier, PHP_URL_HOST) ?: $sourceIdentifier));
        $host = rtrim($host, '.');

        foreach ($allowlist as $entry) {
            $entry = strtolower(trim((string) $entry));
            if ($entry === '') {
                continue;
            }

            // A named internal corpus rather than a host: exact match only.
            if (! str_contains($entry, '.')) {
                if ($host === $entry || $sourceIdentifier === $entry) {
                    return true;
                }

                continue;
            }

            if ($host === $entry || str_ends_with($host, '.'.$entry)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Is this document readable by retrieval?
     *
     * Quarantined material is not ranked low - it is not reachable, on the same
     * fail-closed principle the tenancy scope uses. Anything that is not
     * explicitly verified is invisible, including states invented after this
     * code was written.
     */
    public static function isRetrievable(?AcquiredDocument $document): bool
    {
        return $document !== null && $document->quarantine_state === self::VERIFIED;
    }

    /**
     * Retract material that was verified in through a window which should never
     * have been opened.
     *
     * The hard case, and the one where the obvious answer is wrong. Deleting it
     * would erase what the system believed at the time it answered, and the
     * whole product is the ability to reconstruct that. So retraction stops the
     * material being retrievable going forward and leaves the record of it
     * standing, with the reason attached.
     */
    public static function retract(AcquiredDocument $document, string $reason): AcquiredDocument
    {
        $document->forceFill([
            'quarantine_state' => self::RETRACTED,
            'retracted_at' => now(),
            'retraction_reason' => $reason,
        ])->save();

        return $document;
    }

    /**
     * What TRACE is allowed to say when it needs something it does not have.
     *
     * It asks. It does not reach, and it does not answer from general knowledge
     * and hope. The request names the subject so a human can decide whether to
     * open a window, which is the entire interaction.
     */
    public static function requestText(string $subject): string
    {
        return 'This question needs material that is not in this account\'s governed record: '.$subject
            .'. ZecoCM is sealed and will not go looking for it. If it should be brought in, a named person can open '
            .'an acquisition window for that subject and a specific list of sources; what comes back is quarantined '
            .'until a steward verifies it, and the window closes on its own.';
    }


    /**
     * Take a document slot before reaching, and give it back if the reach fails.
     *
     * @return array{granted: bool, reason: ?string}
     */
    public static function reserveSlot(AcquisitionWindow $window, string $sourceIdentifier, ?DateTimeImmutable $now = null): array
    {
        return DB::transaction(function () use ($window, $sourceIdentifier, $now) {
            $locked = AcquisitionWindow::query()->whereKey($window->id)->lockForUpdate()->first();
            $verdict = self::permits($locked, $sourceIdentifier, $now);

            if (! $verdict['permitted']) {
                return ['granted' => false, 'reason' => $verdict['reason']];
            }

            $locked->increment('documents_reserved');

            return ['granted' => true, 'reason' => null];
        });
    }

    /** A reach that never happened holds nothing. */
    public static function releaseSlot(AcquisitionWindow $window): void
    {
        DB::transaction(function () use ($window) {
            $locked = AcquisitionWindow::query()->whereKey($window->id)->lockForUpdate()->first();
            if ($locked === null) {
                return;
            }
            $locked->documents_reserved = max(0, (int) $locked->documents_reserved - 1);
            $locked->save();
        });
    }

    /**
     * Every redirect hop is a NEW reach, revalidated from scratch.
     *
     * The attack is one line long: an allowed host answers 302 and points at
     * one that is not. Authorising the initial URL and following whatever comes
     * back makes the entire allowlist decorative, because the allowlisted host
     * is not the one that has to be hostile - it only has to be redirecting.
     *
     * @param  list<string>  $chain  every URL in the hop sequence, in order
     * @return array{permitted: bool, reason: ?string}
     */
    public static function permitsRedirectChain(?AcquisitionWindow $window, array $chain, ?DateTimeImmutable $now = null): array
    {
        if ($chain === []) {
            return self::no('An acquisition with no recorded URL cannot be checked against anything.');
        }

        foreach ($chain as $index => $hop) {
            $verdict = self::permits($window, (string) $hop, $now);

            if (! $verdict['permitted']) {
                return self::no($index === 0
                    ? $verdict['reason']
                    : 'Redirect hop '.($index + 1).' went to "'.$hop.'", which this window does not permit. '
                        .'Every hop is a new reach: an allowed host that redirects to a disallowed one would '
                        .'otherwise make the allowlist decorative. '.$verdict['reason']);
            }
        }

        return ['permitted' => true, 'reason' => null];
    }

    /**
     * A response that came back after the window was revoked.
     *
     * The honest position, and it is a limitation rather than a control: a
     * request already on the wire cannot be recalled, and claiming otherwise
     * would be the kind of approximately-true security statement this codebase
     * refuses to make. What CAN be guaranteed is that the response is not
     * silently admitted - it is recorded, marked, and left out of the corpus.
     */
    public static function admitLate(AcquiredDocument $document, string $reason): AcquiredDocument
    {
        $document->forceFill([
            'retrieved_after_revocation' => true,
            'quarantine_state' => self::REJECTED,
            'rejection_reason' => 'The response arrived after the acquisition window was closed or revoked. '
                .'A request already in flight cannot be recalled; what it returned is recorded and is not '
                .'admitted. '.$reason,
        ])->save();

        return $document;
    }

    /**
     * A retry is a new reach.
     *
     * Never inherits the authorisation of the attempt that failed. This
     * codebase has already shipped one bug of exactly this shape - a queued job
     * that read its authorisation at dispatch and executed under a grant that
     * had since been narrowed - and the same mistake here would mean a window
     * that closed at 4pm still fetching at 5.
     */
    public static function permitsRetry(?AcquisitionWindow $window, string $sourceIdentifier, ?DateTimeImmutable $now = null): array
    {
        return self::permits($window, $sourceIdentifier, $now ?? new DateTimeImmutable);
    }

    /** @return array{permitted: false, reason: string} */
    private static function no(string $reason): array
    {
        return ['permitted' => false, 'reason' => $reason];
    }
}
