<?php

namespace App\Domain\Knowledge\Ocr;

use App\Domain\Security\BoundedProcess;

/**
 * D4: runs Tesseract in TSV mode (`tesseract image stdout tsv`), which is
 * the one output format that preserves per-word bounding boxes and
 * per-word confidence - Codex's ruling was explicit that plain-text stdout
 * is not enough to back a `coordinates` citation. Bounded via the same
 * BoundedProcess every other external parser in this codebase uses.
 */
final class TesseractOcr
{
    /**
     * TSV level 5 rows are individual words; every other level (page,
     * block, paragraph, line) is a grouping row with no text of its own and
     * conf=-1. Only level-5 rows carry what this class needs.
     */
    private const WORD_LEVEL = '5';

    public function run(string $imagePath, int $pageWidthPx, int $pageHeightPx): OcrPageResult
    {
        $result = BoundedProcess::run(
            ['tesseract', $imagePath, 'stdout', 'tsv'],
            (int) config('zecocm_ocr.ocr_timeout_seconds', 25),
        );
        if ($result['status'] !== BoundedProcess::OK || $result['exitCode'] !== 0 || $result['stdout'] === '') {
            return OcrPageResult::empty($pageWidthPx, $pageHeightPx);
        }

        $lines = preg_split('/\r?\n/', $result['stdout']) ?: [];
        $words = [];
        $confidences = [];
        $textParts = [];

        foreach (array_slice($lines, 1) as $line) { // skip the TSV header row
            if (trim($line) === '') {
                continue;
            }
            $cols = explode("\t", $line);
            if (count($cols) < 12 || $cols[0] !== self::WORD_LEVEL) {
                continue;
            }
            $text = trim($cols[11]);
            if ($text === '') {
                continue;
            }
            $conf = (float) $cols[10];
            $words[] = [
                'text' => $text,
                'left' => (int) $cols[6],
                'top' => (int) $cols[7],
                'width' => (int) $cols[8],
                'height' => (int) $cols[9],
                'conf' => $conf,
            ];
            $textParts[] = $text;
            if ($conf >= 0) {
                $confidences[] = $conf;
            }
        }

        $meanConfidence = $confidences === [] ? null : round((array_sum($confidences) / count($confidences)) / 100, 4);

        return new OcrPageResult(implode(' ', $textParts), $words, $meanConfidence, $pageWidthPx, $pageHeightPx);
    }
}
