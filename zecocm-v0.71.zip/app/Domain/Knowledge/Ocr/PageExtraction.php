<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * D4: the outcome of processing one page (or one directly-uploaded image,
 * treated as a single page) - everything `KnowledgeSourcePage` and, where
 * text was actually extracted, the one `KnowledgePassage` built from it,
 * need to carry.
 */
final class PageExtraction
{
    /**
     * @param  'born_digital'|'ocr'|'failed'|'skipped_bound'  $method
     * @param  'none'|'detected'  $sheetDetectionStatus
     * @param  array{x:float,y:float,w:float,h:float}|null  $coordinates
     * @param  list<string>  $warnings
     * @param  list<array{token: string, scope: string, confidence: float}>  $structuralFindings
     * @param  list<array<string,mixed>>  $recoveryAttempts  VIS-1: every deterministic scan-recovery
     *                                                       attempt made for this page (empty for a born-digital
     *                                                       page, or an OCR page where the very first/baseline
     *                                                       attempt already came back reliable and no others ran).
     *                                                       Each entry carries `selected` marking the one this
     *                                                       page's own method/confidence/renderDpi fields were
     *                                                       populated from.
     */
    public function __construct(
        public readonly int $pageNumber,
        public readonly string $text,
        public readonly string $method,
        public readonly ?float $confidence,
        public readonly ?string $ocrEngine,
        public readonly ?string $ocrEngineVersion,
        public readonly ?int $renderDpi,
        public readonly ?string $sheetRef,
        public readonly string $sheetDetectionStatus,
        public readonly ?float $sheetDetectionConfidence,
        public readonly ?array $coordinates,
        public readonly array $warnings,
        /**
         * D4 confidence-gap follow-up: whether StructuralWellFormedness found at least one
         * token on this page that announces an evidentiary shape (currency, date, dimension,
         * percent, detail/sheet reference) and does not satisfy it - independent of OCR
         * confidence entirely. Always false for a non-OCR method; confidence cannot see this
         * class of corruption (a digit destroyed by becoming a non-digit), which is exactly
         * why it is a separate signal rather than a sharper confidence threshold.
         */
        public readonly bool $hasStructuralDefect = false,
        public readonly array $structuralFindings = [],
        public readonly array $recoveryAttempts = [],
    ) {}

    public function hasRetrievableText(): bool
    {
        return in_array($this->method, ['born_digital', 'ocr'], true)
            && mb_strlen(trim($this->text)) >= (int) config('zecocm_ocr.min_meaningful_chars', 40);
    }
}
