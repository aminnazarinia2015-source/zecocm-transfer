<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * D4: the parsed output of one Tesseract TSV pass over one rendered page
 * image. `words` preserves per-word bounding boxes (left/top/width/height in
 * pixels, at the render DPI that produced the image) and per-word confidence
 * - Codex's ruling was explicit that a citation's `coordinates` are only
 * defensible if real geometry is preserved, never synthesized from text
 * ordering after the fact.
 */
final class OcrPageResult
{
    /**
     * @param  list<array{text:string,left:int,top:int,width:int,height:int,conf:float}>  $words
     */
    public function __construct(
        public readonly string $text,
        public readonly array $words,
        public readonly ?float $meanConfidence,
        public readonly int $pageWidthPx,
        public readonly int $pageHeightPx,
    ) {}

    public static function empty(int $pageWidthPx = 0, int $pageHeightPx = 0): self
    {
        return new self('', [], null, $pageWidthPx, $pageHeightPx);
    }

    /**
     * The union bounding box of a contiguous slice of `words` (by array
     * index, matching how the caller located the words that make up a given
     * text span), normalized to 0..1 of the page's own dimensions so the
     * region survives being displayed at a different size. Returns null if
     * the slice is empty or page dimensions are unknown - never a fabricated
     * box.
     *
     * @param  list<int>  $wordIndexes
     * @return array{x:float,y:float,w:float,h:float}|null
     */
    public function normalizedBoundingBox(array $wordIndexes): ?array
    {
        if ($wordIndexes === [] || $this->pageWidthPx <= 0 || $this->pageHeightPx <= 0) {
            return null;
        }

        $minX = null;
        $minY = null;
        $maxX = null;
        $maxY = null;
        foreach ($wordIndexes as $i) {
            if (! isset($this->words[$i])) {
                continue;
            }
            $w = $this->words[$i];
            $left = $w['left'];
            $top = $w['top'];
            $right = $w['left'] + $w['width'];
            $bottom = $w['top'] + $w['height'];
            $minX = $minX === null ? $left : min($minX, $left);
            $minY = $minY === null ? $top : min($minY, $top);
            $maxX = $maxX === null ? $right : max($maxX, $right);
            $maxY = $maxY === null ? $bottom : max($maxY, $bottom);
        }

        if ($minX === null) {
            return null;
        }

        return [
            'x' => round($minX / $this->pageWidthPx, 6),
            'y' => round($minY / $this->pageHeightPx, 6),
            'w' => round(($maxX - $minX) / $this->pageWidthPx, 6),
            'h' => round(($maxY - $minY) / $this->pageHeightPx, 6),
        ];
    }
}
