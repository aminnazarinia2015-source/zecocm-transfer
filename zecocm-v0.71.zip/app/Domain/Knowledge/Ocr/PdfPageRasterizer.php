<?php

namespace App\Domain\Knowledge\Ocr;

use App\Domain\Security\BoundedProcess;

/**
 * D4: rendering a PDF page to a PNG for OCR is a second parser over
 * untrusted bytes (Codex's ruling, SEC-5 §7) - it gets the same
 * BoundedProcess wall-clock discipline as pdftotext/pdfinfo, plus a
 * post-render pixel-count bound, since an attacker-controlled page size can
 * make even a "normal" DPI render an enormous image.
 *
 * `-singlefile` makes pdftoppm write exactly `{prefix}.png` with no
 * page-number suffix to guess at, regardless of how many pages the source
 * document has.
 */
final class PdfPageRasterizer
{
    /**
     * @return array{path:string,width:int,height:int}|null null on any
     *                                                      failure (render failure, timeout, or a render exceeding the
     *                                                      configured pixel bound - the oversized file is deleted, never
     *                                                      handed to OCR).
     */
    public function render(string $pdfPath, int $page, int $dpi): ?array
    {
        $dir = sys_get_temp_dir().'/zecocm-ocr-'.bin2hex(random_bytes(8));
        if (! mkdir($dir, 0700, true) && ! is_dir($dir)) {
            return null;
        }
        $prefix = $dir.'/page';

        $result = BoundedProcess::run(
            ['pdftoppm', '-png', '-singlefile', '-r', (string) $dpi, '-f', (string) $page, '-l', (string) $page, $pdfPath, $prefix],
            (int) config('zecocm_ocr.render_timeout_seconds', 25),
        );

        $pngPath = $prefix.'.png';
        if ($result['status'] !== BoundedProcess::OK || $result['exitCode'] !== 0 || ! is_file($pngPath)) {
            $this->cleanup($dir);

            return null;
        }

        $dimensions = @getimagesize($pngPath);
        if ($dimensions === false) {
            $this->cleanup($dir);

            return null;
        }
        [$width, $height] = $dimensions;

        $maxPixels = (int) config('zecocm_ocr.max_render_pixels', 40_000_000);
        if ($width * $height > $maxPixels) {
            $this->cleanup($dir);

            return null;
        }

        return ['path' => $pngPath, 'width' => (int) $width, 'height' => (int) $height];
    }

    public function cleanupDirFor(string $renderedPath): void
    {
        $this->cleanup(dirname($renderedPath));
    }

    private function cleanup(string $dir): void
    {
        if (! is_dir($dir)) {
            return;
        }
        foreach (glob($dir.'/*') ?: [] as $file) {
            @unlink($file);
        }
        @rmdir($dir);
    }
}
