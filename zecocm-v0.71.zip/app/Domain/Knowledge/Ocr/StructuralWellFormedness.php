<?php

declare(strict_types=1);

namespace App\Domain\Knowledge\Ocr;

/**
 * D4 follow-up — a second, confidence-independent reliability signal.
 *
 * Round 3 of the OCR measurement lab established that OCR confidence, at any granularity
 * available from Tesseract, cannot see the worst class of extraction error this product
 * cares about: a digit destroyed by becoming a non-digit. "$1,608,540.00" read as
 * "$:" + "608,540.00" is a one-million-dollar error whose damaged token carries 84.9
 * confidence on a page whose mean confidence is 95.2. No threshold sees it, because the
 * reading is confident and the digits are simply gone.
 *
 * A token that ANNOUNCES an evidentiary shape can be validated against that shape without
 * any reference to confidence. That is the whole of this class. It judges only tokens that
 * make a structural claim — a currency amount, a percentage, a dimension, a date, a detail
 * reference, a sheet reference. Prose is never judged, because prose asserts no shape and a
 * shape check applied to prose is a false-positive generator.
 *
 * This class never deletes, repairs, or rewrites a token. It reports. The caller decides.
 */
final class StructuralWellFormedness
{
    public const SCOPE_DATE = 'date';

    public const SCOPE_DIMENSION = 'dimension';

    public const SCOPE_CURRENCY = 'currency';

    public const SCOPE_PERCENT = 'percent';

    public const SCOPE_DETAIL_REF = 'detail_ref';

    public const SCOPE_SHEET_REF = 'sheet_ref';

    /**
     * Scope resolution is ORDERED and first-match-wins, and the order is load-bearing.
     *
     * Round 4 found that adding scopes creates claim-predicate collisions that did not
     * exist with three scopes: "03/15/2026" satisfies the detail-reference claim predicate
     * (`^\d+/`) just as well as the date one, and "3/4\"" satisfies it too. Resolving a
     * token under the wrong scope makes a correct token look malformed. Any future scope
     * must be inserted at a position that has been measured, not appended.
     *
     * @var list<array{scope: string, claims: string, wellFormed: list<string>}>
     */
    private const SCOPES = [
        [
            'scope' => self::SCOPE_DATE,
            'claims' => '#^\d{1,2}/\d{1,2}/\d{2,4}$#',
            'wellFormed' => ['#^(0[1-9]|1[0-2])/(0[1-9]|[12]\d|3[01])/\d{4}$#'],
        ],
        [
            'scope' => self::SCOPE_DIMENSION,
            'claims' => '#^(?=.*\d)[\d\s/\'\-]*["\']$#',
            'wellFormed' => [
                '#^\d{1,3}\'-\d{1,2}(\s?\d{1,2}/\d{1,2})?"$#',   // 12'-6"
                '#^\d{1,3}(\s?\d{1,2}/\d{1,2})?"$#',             // 6"  /  6 1/2"
                '#^\d{1,2}/\d{1,2}"$#',                          // 3/4"
                '#^\d{1,3}\'$#',                                 // 12'
            ],
        ],
        [
            'scope' => self::SCOPE_CURRENCY,
            'claims' => '#\$#',
            'wellFormed' => ['#^\$\d{1,3}(,\d{3})*(\.\d{2})?$#'],
        ],
        [
            'scope' => self::SCOPE_PERCENT,
            'claims' => '#%$#',
            'wellFormed' => ['#^\d{1,3}(\.\d{1,3})?%$#'],
        ],
        [
            'scope' => self::SCOPE_DETAIL_REF,
            'claims' => '#^\d{1,2}/[A-Za-z]#',
            'wellFormed' => ['#^\d{1,2}/[A-Z]{1,2}-?\d{1,3}$#'],
        ],
        [
            'scope' => self::SCOPE_SHEET_REF,
            'claims' => '#^[A-Za-z]{1,2}-\d#',
            'wellFormed' => ['#^[A-Z]{1,2}-\d{1,3}(\.\d{1,2})?$#'],
        ],
    ];

    /**
     * Trailing sentence punctuation is stripped before judging, because a correct token at
     * the end of a clause ("...not later than 03/15/2026,") is not malformed. Digits, '%'
     * and '"' are never stripped, so a truncated amount stays truncated.
     */
    public static function normalise(string $token): string
    {
        // Typographic quote marks are folded to their ASCII equivalents FIRST. Round 4 found a
        // real, silent blind spot here: Tesseract reads the foot mark in 12'-6" as U+2019 often
        // enough to matter, and a claim predicate written in ASCII simply stops recognising the
        // token as a dimension at all — it becomes invisible to this class rather than malformed.
        // A foot mark is a foot mark; the glyph variant is not the evidentiary content.
        $token = strtr(trim($token), [
            "\u{2018}" => "'", "\u{2019}" => "'", "\u{02BC}" => "'", "\u{00B4}" => "'",
            "\u{201C}" => '"', "\u{201D}" => '"', "\u{2033}" => '"', "\u{2032}" => "'",
        ]);

        return rtrim($token, '.,;:)]');
    }

    /**
     * @return array{scope: string, well_formed: bool}|null null when the token makes no structural claim
     */
    public static function inspectToken(string $token): ?array
    {
        $t = self::normalise($token);

        if ($t === '') {
            return null;
        }

        foreach (self::SCOPES as $scope) {
            if (preg_match($scope['claims'], $t) !== 1) {
                continue;
            }

            foreach ($scope['wellFormed'] as $pattern) {
                if (preg_match($pattern, $t) === 1) {
                    return ['scope' => $scope['scope'], 'well_formed' => true];
                }
            }

            return ['scope' => $scope['scope'], 'well_formed' => false];
        }

        return null;
    }

    /**
     * @param  list<array{text: string, confidence: float}>  $words
     * @return array{
     *     in_scope: int,
     *     malformed: list<array{token: string, scope: string, confidence: float}>,
     *     any_malformed: bool
     * }
     */
    public static function inspectPage(array $words): array
    {
        $inScope = 0;
        $malformed = [];

        foreach ($words as $word) {
            $verdict = self::inspectToken($word['text']);

            if ($verdict === null) {
                continue;
            }

            $inScope++;

            if (! $verdict['well_formed']) {
                $malformed[] = [
                    'token' => self::normalise($word['text']),
                    'scope' => $verdict['scope'],
                    'confidence' => $word['confidence'],
                ];
            }
        }

        return [
            'in_scope' => $inScope,
            'malformed' => $malformed,
            'any_malformed' => $malformed !== [],
        ];
    }
}
