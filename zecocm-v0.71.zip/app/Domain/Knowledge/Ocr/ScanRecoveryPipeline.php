<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * VIS-1 (low-quality scan recovery). Per Codex's ruling, the goal is NOT
 * "make OCR always succeed" - it is: give a poor scan multiple bounded,
 * deterministic recovery attempts, record exactly what each attempt did, and
 * refuse (stay `unreliable`) if none of them clears the bar. This class runs
 * a fixed, versioned plan of attempts (baseline, then progressively more
 * preprocessing, then a higher-DPI re-render for a PDF page) and selects a
 * winner by a deterministic rule - never "whichever ran last".
 *
 * D4's existing rule is unchanged and this class never touches it: better
 * OCR reliability may strengthen an extraction's posture; it never changes
 * source authority.
 */
final class ScanRecoveryPipeline
{
    public const RETRY_DPI = 300;

    public function __construct(
        private readonly ImagePreprocessor $preprocessor = new ImagePreprocessor,
        private readonly TesseractOcr $ocr = new TesseractOcr,
    ) {}

    /**
     * Recovery plan for a PDF page: baseline render, two preprocessing
     * variants at the same DPI, then a re-render at a higher DPI (with and
     * without preprocessing). Each entry's `dpi` drives which render is
     * requested from the caller's $render callback - re-renders are cached
     * per DPI so a higher-DPI page is only actually rasterized once even
     * though two attempts use it.
     *
     * @param  callable(int $dpi): (array{path:string,width:int,height:int}|null)  $render
     * @return array{attempts: list<array<string,mixed>>, winner: ?array<string,mixed>}
     */
    public function recoverForPdfPage(callable $render, int $baselineDpi): array
    {
        return $this->run($render, $baselineDpi, [
            ['label' => 'baseline', 'dpi' => $baselineDpi, 'steps' => []],
            ['label' => 'grayscale_contrast', 'dpi' => $baselineDpi, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST]],
            ['label' => 'deskew', 'dpi' => $baselineDpi, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST, ImagePreprocessor::STEP_DESKEW]],
            ['label' => 'retry_300dpi', 'dpi' => self::RETRY_DPI, 'steps' => []],
            ['label' => 'retry_300dpi_full', 'dpi' => self::RETRY_DPI, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST, ImagePreprocessor::STEP_DESKEW, ImagePreprocessor::STEP_DENOISE]],
        ]);
    }

    /**
     * Recovery plan for a directly-uploaded image: there is no PDF to
     * re-render at a higher DPI, so only the preprocessing variants apply -
     * upsampling a raster that is already the source does not add real
     * information, so no DPI-retry steps are included here.
     *
     * @param  callable(int $dpi): (array{path:string,width:int,height:int}|null)  $render
     * @return array{attempts: list<array<string,mixed>>, winner: ?array<string,mixed>}
     */
    public function recoverForImage(callable $render): array
    {
        return $this->run($render, 0, [
            ['label' => 'baseline', 'dpi' => 0, 'steps' => []],
            ['label' => 'grayscale_contrast', 'dpi' => 0, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST]],
            ['label' => 'deskew', 'dpi' => 0, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST, ImagePreprocessor::STEP_DESKEW]],
            ['label' => 'denoise', 'dpi' => 0, 'steps' => [ImagePreprocessor::STEP_GRAYSCALE_CONTRAST, ImagePreprocessor::STEP_DESKEW, ImagePreprocessor::STEP_DENOISE]],
        ]);
    }

    /**
     * @param  callable(int $dpi): (array{path:string,width:int,height:int}|null)  $render
     * @param  list<array{label:string,dpi:int,steps:list<string>}>  $plan
     * @return array{attempts: list<array<string,mixed>>, winner: ?array<string,mixed>}
     */
    private function run(callable $render, int $baselineDpi, array $plan): array
    {
        $attempts = [];
        $renderedByDpi = [];
        $ordinal = 0;

        foreach ($plan as $step) {
            $ordinal++;
            $dpi = $step['dpi'] ?: $baselineDpi;

            if (! array_key_exists($dpi, $renderedByDpi)) {
                $renderedByDpi[$dpi] = $render($dpi);
            }
            $base = $renderedByDpi[$dpi];

            if ($base === null) {
                $attempts[] = $this->failedAttempt($ordinal, $step, $dpi, 'render_unavailable');

                continue;
            }

            $started = microtime(true);
            $imagePath = $base['path'];
            $preprocessedPath = null;

            if ($step['steps'] !== []) {
                $preprocessedPath = $imagePath.'.vis1-'.$ordinal.'.png';
                if (! $this->preprocessor->apply($imagePath, $step['steps'], $preprocessedPath)) {
                    $attempts[] = $this->failedAttempt($ordinal, $step, $dpi, 'preprocessing_failed');

                    continue;
                }
                $imagePath = $preprocessedPath;
            }

            $imageHash = @hash_file('sha256', $imagePath) ?: null;
            $ocrResult = $this->ocr->run($imagePath, $base['width'], $base['height']);
            $structural = StructuralWellFormedness::inspectPage(array_map(
                fn (array $w) => ['text' => $w['text'], 'confidence' => $w['conf']],
                $ocrResult->words,
            ));
            $reliability = ExtractionReliability::classify('ocr', $ocrResult->meanConfidence, $structural['any_malformed']);
            $runtimeMs = (int) round((microtime(true) - $started) * 1000);

            if ($preprocessedPath !== null) {
                @unlink($preprocessedPath);
            }

            $attempts[] = [
                'ordinal' => $ordinal,
                'label' => $step['label'],
                'transform_sequence' => $step['steps'],
                'render_dpi' => $dpi,
                'image_sha256' => $imageHash,
                'image_width' => $base['width'],
                'image_height' => $base['height'],
                'mean_confidence' => $ocrResult->meanConfidence,
                'has_structural_defect' => $structural['any_malformed'],
                'structural_findings' => $structural['malformed'],
                'reliability' => $reliability,
                'runtime_ms' => $runtimeMs,
                'text' => $ocrResult->text,
                'words' => $ocrResult->words,
                'page_width_px' => $ocrResult->pageWidthPx,
                'page_height_px' => $ocrResult->pageHeightPx,
                'failed' => false,
            ];

            if ($reliability === ExtractionReliability::RELIABLE) {
                // Deterministic short-circuit: the first attempt that clears
                // the bar wins outright. Later attempts in the plan are never
                // run once this happens - there is nothing to gain by
                // continuing, and it keeps the bounded-time budget honest.
                break;
            }
        }

        return ['attempts' => $attempts, 'winner' => $this->selectBest($attempts)];
    }

    /**
     * @param  array{label:string,dpi:int,steps:list<string>}  $step
     */
    private function failedAttempt(int $ordinal, array $step, int $dpi, string $reason): array
    {
        return [
            'ordinal' => $ordinal, 'label' => $step['label'], 'transform_sequence' => $step['steps'],
            'render_dpi' => $dpi, 'image_sha256' => null, 'image_width' => null, 'image_height' => null,
            'mean_confidence' => null, 'has_structural_defect' => false, 'structural_findings' => [],
            'reliability' => ExtractionReliability::UNRELIABLE, 'runtime_ms' => null,
            'text' => '', 'words' => [], 'page_width_px' => 0, 'page_height_px' => 0,
            'failed' => true, 'failure_reason' => $reason,
        ];
    }

    /**
     * Deterministic selection: highest reliability tier wins; ties broken by
     * higher mean confidence (nulls sort last); remaining ties broken by
     * earliest ordinal - never "whichever attempt happened to run last".
     *
     * @param  list<array<string,mixed>>  $attempts
     * @return ?array<string,mixed>
     */
    private function selectBest(array $attempts): ?array
    {
        $usable = array_values(array_filter($attempts, fn (array $a) => ! $a['failed'] && trim($a['text']) !== ''));
        if ($usable === []) {
            return null;
        }

        $rank = [ExtractionReliability::RELIABLE => 2, ExtractionReliability::REVIEW_RECOMMENDED => 1, ExtractionReliability::UNRELIABLE => 0];

        usort($usable, function (array $a, array $b) use ($rank) {
            $rankCmp = $rank[$b['reliability']] <=> $rank[$a['reliability']];
            if ($rankCmp !== 0) {
                return $rankCmp;
            }
            $confA = $a['mean_confidence'] ?? -1;
            $confB = $b['mean_confidence'] ?? -1;
            $confCmp = $confB <=> $confA;
            if ($confCmp !== 0) {
                return $confCmp;
            }

            return $a['ordinal'] <=> $b['ordinal'];
        });

        return $usable[0];
    }
}
