<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * D4: sheet-reference detection restricted to the bottom-right region of a
 * page - where a construction drawing's title block conventionally lives -
 * per Codex's ruling and the acceptance case built specifically to guard
 * against it: body text containing "COVID-19", "RFI-10", or "P-04" must
 * never be promoted to sheet_ref solely by pattern matching. The region
 * restriction is what makes that safe: "P-04" is a syntactically plausible
 * sheet code (P = plumbing), so the pattern alone cannot reject it - only
 * position can, since a plumbing sheet's own identity lives in its title
 * block, not scattered through its body text.
 *
 * v1 limitation, deliberate: matches only a single OCR word token (e.g.
 * "A-101" recognized as one token). A sheet number Tesseract happens to
 * split across multiple tokens (e.g. "A" "-" "101" as three words) is not
 * detected. Title blocks are printed in a fixed, unspaced format in
 * practice, so this is expected to cover the common case; a future
 * refinement can join adjacent region words if this proves too narrow
 * against real scanned sheets.
 */
final class SheetReferenceDetector
{
    private const PATTERN = '/^([A-Z]{1,2})-(\d{1,3}(?:\.\d{1,2})?)$/';

    /**
     * @return array{ref:string,confidence:?float,word_index:int}|null
     */
    public function detect(OcrPageResult $ocr): ?array
    {
        if ($ocr->pageWidthPx <= 0 || $ocr->pageHeightPx <= 0) {
            return null;
        }

        $minX = (float) config('zecocm_ocr.sheet_region_min_x_fraction', 0.55);
        $minY = (float) config('zecocm_ocr.sheet_region_min_y_fraction', 0.72);

        foreach ($ocr->words as $i => $word) {
            $xFraction = $word['left'] / $ocr->pageWidthPx;
            $yFraction = $word['top'] / $ocr->pageHeightPx;
            if ($xFraction < $minX || $yFraction < $minY) {
                continue;
            }

            $candidate = strtoupper(trim($word['text']));
            if (preg_match(self::PATTERN, $candidate, $m) !== 1) {
                continue;
            }

            return [
                'ref' => $m[1].'-'.$m[2],
                'confidence' => $word['conf'] >= 0 ? round($word['conf'] / 100, 4) : null,
                'word_index' => $i,
            ];
        }

        return null;
    }
}
