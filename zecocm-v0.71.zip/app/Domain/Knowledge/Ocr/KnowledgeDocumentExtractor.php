<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * D4: the orchestrator. Per Codex's ruling, extraction is page-selective -
 * born-digital text is used wherever it is usable, and OCR is invoked only
 * as a bounded fallback for the pages that actually need it, never for the
 * whole document because one page happened to be scanned.
 *
 * Every bound Codex asked for is enforced here, not left to whichever
 * subprocess wrapper happens to be called: a hard cap on pages processed at
 * all, a separate cap on how many of those may actually be OCR'd, and a
 * cumulative wall-clock OCR budget - a document that exceeds any of them
 * gets bounded partial processing (remaining pages recorded
 * `skipped_bound`, never silently dropped and never presented as complete).
 */
final class KnowledgeDocumentExtractor
{
    public function __construct(
        private readonly PdfPageInspector $inspector = new PdfPageInspector,
        private readonly PdfPageTextExtractor $textExtractor = new PdfPageTextExtractor,
        private readonly PdfPageRasterizer $rasterizer = new PdfPageRasterizer,
        private readonly TesseractOcr $ocr = new TesseractOcr,
        private readonly SheetReferenceDetector $sheetDetector = new SheetReferenceDetector,
        private readonly ScanRecoveryPipeline $recovery = new ScanRecoveryPipeline,
    ) {}

    /**
     * @return array{pages: list<PageExtraction>, summary_method: string, warnings: list<string>}
     */
    public function extractPdf(string $path): array
    {
        $pageCount = $this->inspector->pageCount($path);
        if ($pageCount === null) {
            return ['pages' => [], 'summary_method' => 'failed', 'warnings' => ['unreadable_pdf_structure']];
        }

        $maxPagesTotal = (int) config('zecocm_ocr.max_pages_total', 300);
        $maxOcrPages = (int) config('zecocm_ocr.max_ocr_pages', 50);
        $maxOcrSeconds = (float) config('zecocm_ocr.max_ocr_seconds_total', 120);
        $minChars = (int) config('zecocm_ocr.min_meaningful_chars', 40);
        $dpi = (int) config('zecocm_ocr.render_dpi', 200);

        $docWarnings = [];
        $pagesToProcess = min($pageCount, $maxPagesTotal);
        if ($pageCount > $maxPagesTotal) {
            $docWarnings[] = "pages_beyond_bound_skipped:{$pageCount}-{$maxPagesTotal}";
        }

        $pages = [];
        $seenSheetRefs = [];
        $ocrPagesUsed = 0;
        $ocrSecondsUsed = 0.0;

        for ($page = 1; $page <= $pagesToProcess; $page++) {
            $text = $this->textExtractor->extractPage($path, $page);

            if (mb_strlen(trim($text)) >= $minChars) {
                $pages[] = new PageExtraction(
                    pageNumber: $page, text: $text, method: 'born_digital', confidence: 0.75,
                    ocrEngine: null, ocrEngineVersion: null, renderDpi: null,
                    sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                    coordinates: null, warnings: [],
                );

                continue;
            }

            if ($ocrPagesUsed >= $maxOcrPages || $ocrSecondsUsed >= $maxOcrSeconds) {
                $pages[] = new PageExtraction(
                    pageNumber: $page, text: '', method: 'skipped_bound', confidence: null,
                    ocrEngine: null, ocrEngineVersion: null, renderDpi: null,
                    sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                    coordinates: null, warnings: ['ocr_budget_exceeded'],
                );

                continue;
            }

            $started = microtime(true);
            $renderedDirs = [];
            $render = function (int $attemptDpi) use ($path, $page, &$renderedDirs) {
                $render = $this->rasterizer->render($path, $page, $attemptDpi);
                if ($render !== null) {
                    $renderedDirs[] = $render['path'];
                }

                return $render;
            };

            $recovery = $this->recovery->recoverForPdfPage($render, $dpi);
            $ocrPagesUsed++;
            $ocrSecondsUsed += microtime(true) - $started;
            foreach ($renderedDirs as $renderedPath) {
                $this->rasterizer->cleanupDirFor($renderedPath);
            }

            $attempts = $this->summarizeAttempts($recovery['attempts'], $recovery['winner']);
            // The winner selected purely on OCR reliability may still fall
            // short of min_meaningful_chars - the same "not enough text to
            // call this usable" gate every method applies, preserved here so
            // VIS-1's recovery attempts never relax it.
            $winner = ($recovery['winner'] !== null && mb_strlen(trim($recovery['winner']['text'])) >= $minChars)
                ? $recovery['winner'] : null;

            if ($winner === null) {
                $pages[] = new PageExtraction(
                    pageNumber: $page, text: '', method: 'failed', confidence: null,
                    ocrEngine: (string) config('zecocm_ocr.engine'), ocrEngineVersion: (string) config('zecocm_ocr.engine_version'),
                    renderDpi: $dpi, sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                    coordinates: null, warnings: ['ocr_no_usable_text'],
                    recoveryAttempts: $attempts,
                );

                continue;
            }

            $ocrResult = new OcrPageResult($winner['text'], $winner['words'], $winner['mean_confidence'], $winner['page_width_px'], $winner['page_height_px']);
            $sheet = $this->sheetDetector->detect($ocrResult);
            $sheetRef = $sheet['ref'] ?? null;
            $pageWarnings = [];
            if ($sheetRef !== null) {
                if (isset($seenSheetRefs[$sheetRef])) {
                    $pageWarnings[] = "duplicate_sheet_ref:{$sheetRef}";
                }
                $seenSheetRefs[$sheetRef] = true;
            }

            $coordinates = $ocrResult->normalizedBoundingBox(array_keys($ocrResult->words));

            $pages[] = new PageExtraction(
                pageNumber: $page, text: $ocrResult->text, method: 'ocr', confidence: $ocrResult->meanConfidence,
                ocrEngine: (string) config('zecocm_ocr.engine'), ocrEngineVersion: (string) config('zecocm_ocr.engine_version'),
                renderDpi: $winner['render_dpi'], sheetRef: $sheetRef,
                sheetDetectionStatus: $sheetRef !== null ? 'detected' : 'none',
                sheetDetectionConfidence: $sheet['confidence'] ?? null,
                coordinates: $coordinates, warnings: $pageWarnings,
                hasStructuralDefect: $winner['has_structural_defect'],
                structuralFindings: $winner['structural_findings'],
                recoveryAttempts: $attempts,
            );
        }

        return ['pages' => $pages, 'summary_method' => $this->summarize($pages), 'warnings' => $docWarnings];
    }

    /**
     * A directly-uploaded image (jpg/png/tif/tiff) has no text layer by
     * definition - it always goes straight to OCR, never through
     * pdftotext/pdftoppm first.
     */
    public function extractImage(string $path): PageExtraction
    {
        $minChars = (int) config('zecocm_ocr.min_meaningful_chars', 40);
        $dimensions = @getimagesize($path);
        if ($dimensions === false) {
            return new PageExtraction(
                pageNumber: 1, text: '', method: 'failed', confidence: null,
                ocrEngine: null, ocrEngineVersion: null, renderDpi: null,
                sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                coordinates: null, warnings: ['unreadable_image'],
            );
        }
        [$width, $height] = $dimensions;

        $maxPixels = (int) config('zecocm_ocr.max_render_pixels', 40_000_000);
        if ($width * $height > $maxPixels) {
            return new PageExtraction(
                pageNumber: 1, text: '', method: 'failed', confidence: null,
                ocrEngine: null, ocrEngineVersion: null, renderDpi: null,
                sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                coordinates: null, warnings: ['image_exceeds_render_bound'],
            );
        }

        $recovery = $this->recovery->recoverForImage(fn () => ['path' => $path, 'width' => (int) $width, 'height' => (int) $height]);
        $attempts = $this->summarizeAttempts($recovery['attempts'], $recovery['winner']);
        $winner = ($recovery['winner'] !== null && mb_strlen(trim($recovery['winner']['text'])) >= $minChars)
            ? $recovery['winner'] : null;

        if ($winner === null) {
            return new PageExtraction(
                pageNumber: 1, text: '', method: 'failed', confidence: null,
                ocrEngine: (string) config('zecocm_ocr.engine'), ocrEngineVersion: (string) config('zecocm_ocr.engine_version'),
                renderDpi: null, sheetRef: null, sheetDetectionStatus: 'none', sheetDetectionConfidence: null,
                coordinates: null, warnings: ['ocr_no_usable_text'],
                recoveryAttempts: $attempts,
            );
        }

        $ocrResult = new OcrPageResult($winner['text'], $winner['words'], $winner['mean_confidence'], $winner['page_width_px'], $winner['page_height_px']);
        $sheet = $this->sheetDetector->detect($ocrResult);
        $coordinates = $ocrResult->normalizedBoundingBox(array_keys($ocrResult->words));

        return new PageExtraction(
            pageNumber: 1, text: $ocrResult->text, method: 'ocr', confidence: $ocrResult->meanConfidence,
            ocrEngine: (string) config('zecocm_ocr.engine'), ocrEngineVersion: (string) config('zecocm_ocr.engine_version'),
            renderDpi: null, sheetRef: $sheet['ref'] ?? null,
            sheetDetectionStatus: ($sheet['ref'] ?? null) !== null ? 'detected' : 'none',
            sheetDetectionConfidence: $sheet['confidence'] ?? null,
            coordinates: $coordinates, warnings: [],
            hasStructuralDefect: $winner['has_structural_defect'],
            structuralFindings: $winner['structural_findings'],
            recoveryAttempts: $attempts,
        );
    }

    /**
     * VIS-1: reduce ScanRecoveryPipeline's raw attempts (which carry the full
     * OCR text/words for the winner's benefit) down to the small, DB-shaped
     * summary KnowledgeController persists to `ocr_extraction_attempts` -
     * never the text/words themselves, which already live in the winning
     * page's own passage/coordinates.
     *
     * @param  list<array<string,mixed>>  $attempts
     * @param  ?array<string,mixed>  $winner
     * @return list<array<string,mixed>>
     */
    private function summarizeAttempts(array $attempts, ?array $winner): array
    {
        $winnerOrdinal = $winner['ordinal'] ?? null;

        return array_map(fn (array $a) => [
            'ordinal' => $a['ordinal'],
            'label' => $a['label'],
            'transform_sequence' => $a['transform_sequence'],
            'render_dpi' => $a['render_dpi'],
            'ocr_engine' => (string) config('zecocm_ocr.engine'),
            'ocr_engine_version' => (string) config('zecocm_ocr.engine_version'),
            'mean_confidence' => $a['mean_confidence'],
            'has_structural_defect' => $a['has_structural_defect'],
            'reliability' => $a['reliability'],
            'image_sha256' => $a['image_sha256'],
            'image_width' => $a['image_width'],
            'image_height' => $a['image_height'],
            'runtime_ms' => $a['runtime_ms'],
            'selected' => $winnerOrdinal !== null && $a['ordinal'] === $winnerOrdinal,
        ], $attempts);
    }

    /**
     * @param  list<PageExtraction>  $pages
     */
    private function summarize(array $pages): string
    {
        $methods = [];
        foreach ($pages as $page) {
            if ($page->hasRetrievableText()) {
                $methods[$page->method] = true;
            }
        }

        if ($methods === []) {
            return 'failed';
        }
        if (count($methods) > 1) {
            return 'mixed';
        }

        return array_key_first($methods);
    }
}
