<?php

namespace App\Domain\Knowledge\Ocr;

use App\Domain\Security\BoundedProcess;

/**
 * D4: page count via `pdfinfo`, bounded the same way every other parser on
 * untrusted bytes in this codebase is (SEC-5's BoundedProcess). A malformed
 * or non-PDF file returns null rather than throwing - the caller treats an
 * unreadable page count as "cannot process this as a paginated document",
 * never as zero pages (which would silently skip everything).
 */
final class PdfPageInspector
{
    public function pageCount(string $path): ?int
    {
        $result = BoundedProcess::run(['pdfinfo', $path], (int) config('zecocm_ocr.inspect_timeout_seconds', 10));
        if ($result['status'] !== BoundedProcess::OK || $result['exitCode'] !== 0) {
            return null;
        }

        if (preg_match('/^Pages:\s*(\d+)\s*$/m', $result['stdout'], $m) === 1) {
            $pages = (int) $m[1];

            return $pages > 0 ? $pages : null;
        }

        return null;
    }
}
