<?php

namespace App\Domain\Knowledge\Ocr;

use App\Domain\Security\BoundedProcess;

/**
 * D4: born-digital text for exactly one page, via `pdftotext -layout -f N
 * -l N`. Page-scoped rather than the whole-document extraction the pipeline
 * used before this row, so a single deficient page in an otherwise
 * text-rich document is detected and OCR'd individually - Codex's ruling:
 * "do not OCR the whole PDF just because one page is scanned."
 */
final class PdfPageTextExtractor
{
    public function extractPage(string $path, int $page): string
    {
        $result = BoundedProcess::run(
            ['pdftotext', '-layout', '-f', (string) $page, '-l', (string) $page, $path, '-'],
            (int) config('zecocm_ocr.text_extract_timeout_seconds', 20),
        );
        if ($result['status'] !== BoundedProcess::OK || $result['exitCode'] !== 0) {
            return '';
        }

        return $result['stdout'];
    }
}
