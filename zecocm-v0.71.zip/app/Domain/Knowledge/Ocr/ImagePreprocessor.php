<?php

namespace App\Domain\Knowledge\Ocr;

use App\Domain\Security\BoundedProcess;

/**
 * VIS-1: a small, deterministic set of image transforms ScanRecoveryPipeline
 * composes into bounded recovery attempts for a low-quality scan. Every
 * transform here is conservative on purpose - Codex's ruling: no aggressive
 * enhancement that could invent or erase linework/text without preserving
 * the original. `convert` (ImageMagick) is a second parser over
 * attacker-influenceable bytes exactly like `pdftoppm`/`tesseract`, so it
 * gets the same BoundedProcess wall-clock discipline as every other external
 * binary this codebase invokes.
 *
 * Never destructive: this always writes a NEW file at $outputPath. The
 * caller's original render is untouched, so every attempt's exact input
 * bytes remain reconstructable from the prior attempt in the chain.
 */
final class ImagePreprocessor
{
    public const STEP_GRAYSCALE_CONTRAST = 'grayscale_contrast';

    public const STEP_DESKEW = 'deskew';

    public const STEP_DENOISE = 'denoise';

    /**
     * @param  list<string>  $steps  applied in the given order
     */
    public function apply(string $inputPath, array $steps, string $outputPath): bool
    {
        if ($steps === [] || ! is_file($inputPath)) {
            return false;
        }

        $args = ['convert', $inputPath];
        foreach ($steps as $step) {
            match ($step) {
                self::STEP_GRAYSCALE_CONTRAST => array_push($args, '-colorspace', 'Gray', '-normalize'),
                self::STEP_DESKEW => array_push($args, '-deskew', '80%'),
                self::STEP_DENOISE => array_push($args, '-despeckle', '-unsharp', '0x1'),
                default => null,
            };
        }
        $args[] = $outputPath;

        $result = BoundedProcess::run($args, (int) config('zecocm_ocr.preprocess_timeout_seconds', 20));

        return $result['status'] === BoundedProcess::OK && $result['exitCode'] === 0 && is_file($outputPath);
    }
}
