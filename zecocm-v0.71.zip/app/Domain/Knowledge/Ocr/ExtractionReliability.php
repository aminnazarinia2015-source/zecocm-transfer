<?php

namespace App\Domain\Knowledge\Ocr;

/**
 * D4/Codex's ruling: source authority and extraction reliability are two
 * separate axes. HybridKnowledgeRetriever's precedence ordering is, and
 * stays, entirely blind to this classification - a governing contract is
 * never outranked or demoted because its text was recovered by OCR, and a
 * cleaner lower-authority source never displaces it on that basis either.
 * This class exists for the OTHER axis: what the answer layer is allowed to
 * claim about how confidently a passage's text was actually read, expressed
 * as a small, deterministic, code-controlled classification - never left to
 * the model to decide for itself whether an extraction is "good enough".
 *
 * Tesseract's own mean word confidence is an extraction-quality signal
 * about character/word recognition, not a calibrated probability that the
 * recovered text is legally or factually correct - these thresholds are
 * deliberately conservative defaults (config/zecocm_ocr.php), not the
 * product of a labelled accuracy study.
 */
final class ExtractionReliability
{
    public const RELIABLE = 'reliable';

    public const REVIEW_RECOMMENDED = 'review_recommended';

    public const UNRELIABLE = 'unreliable';

    /**
     * @param  ?string  $method  a KnowledgeSourcePage.extraction_method value (or null when
     *                           the passage has no single source page - see classifyForPassage()).
     * @param  bool  $hasStructuralDefect  D4 confidence-gap follow-up (OCR lab rounds 3-5):
     *                                     whether StructuralWellFormedness found at least one token on
     *                                     this page that announces an evidentiary shape (currency, date,
     *                                     dimension, percent, a detail/sheet reference) without
     *                                     satisfying it. This is a SEPARATE signal from confidence, not
     *                                     a sharper threshold on it - the round-3 decisive case ("$:" for
     *                                     "$1,608,540.00") carried 84.9 confidence on a page whose mean
     *                                     was 95.2, so no confidence threshold at any granularity would
     *                                     ever see it. When true, this always forces UNRELIABLE,
     *                                     regardless of confidence: a demonstrated structural corruption
     *                                     in a token that carries the evidentiary weight (an amount, a
     *                                     date, a dimension) must never be rescued by surrounding
     *                                     high-confidence prose.
     */
    public static function classify(?string $method, ?float $confidence, bool $hasStructuralDefect = false): string
    {
        if ($method === null || $method === 'born_digital') {
            // No OCR was involved in producing this text at all - either a
            // stitched multi-page born-digital passage (no single source
            // page to point at) or a plain-text/submitted-text source.
            return self::RELIABLE;
        }

        if ($method !== 'ocr') {
            // failed/skipped_bound pages never produce a passage in the
            // first place (see KnowledgeController) - reaching this branch
            // would mean a future method value this class does not yet
            // know about. Fail conservative rather than assume reliable.
            return self::UNRELIABLE;
        }

        if ($hasStructuralDefect) {
            return self::UNRELIABLE;
        }

        // Codex's ruling: "unknown/missing extraction confidence on an OCR
        // passage -> fail conservative, not assume reliable."
        if ($confidence === null) {
            return self::UNRELIABLE;
        }

        $high = (float) config('zecocm_ocr.reliability_high_confidence', 0.80);
        $low = (float) config('zecocm_ocr.reliability_low_confidence', 0.55);

        if ($confidence >= $high) {
            return self::RELIABLE;
        }
        if ($confidence >= $low) {
            return self::REVIEW_RECOMMENDED;
        }

        return self::UNRELIABLE;
    }

    /**
     * Human-facing wording for a reliability class, per Codex's ruling that
     * this text is fixed and code-controlled, never model-composed. Returns
     * null for RELIABLE - the common case is not annotated, to avoid
     * training readers to ignore a caveat that appears on every passage.
     */
    public static function caveat(string $reliability): ?string
    {
        return match ($reliability) {
            self::REVIEW_RECOMMENDED => 'OCR-derived text — visual confirmation of the source page is recommended before treating this as settled.',
            self::UNRELIABLE => 'OCR extraction below the threshold for confident citation — do not treat this as a settled provision without visual confirmation of the source page.',
            default => null,
        };
    }
}
