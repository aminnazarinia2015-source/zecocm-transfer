<?php

namespace App\Domain\Claims;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * When a rights-preserving deadline can be established, and when it cannot.
 *
 * The arithmetic here is trivial. Everything that matters is the refusal to do
 * the arithmetic when one of the four inputs is missing, because a deadline
 * this software displays will be trusted, and a wrong deadline is worse than
 * none - somebody relaxes on the strength of it.
 *
 * Four things must all be established before a date appears:
 *
 *   THE AUTHORITY   a confirmed requirement with a citation. There is no
 *                   default notice period anywhere in this system.
 *   THE TRIGGER     a confirmed event. Not a plausible one, not the pay
 *                   application period, not the date somebody uploaded a photo.
 *   THE COUNTING    whether weekends count, whether the trigger day counts, and
 *                   which holidays apply - each sourced, not assumed. "Within
 *                   10 working days" with no confirmed project calendar is
 *                   UNRESOLVED, and quietly using Monday to Friday would be
 *                   inventing a deadline out of a convention.
 *   THE CONSEQUENCE what missing it does. A contract saying "shall" does not
 *                   make a step preservative.
 *
 * And when the trigger is disputed, the honest output is a RANGE. "The earliest
 * plausible deadline is the 4th and the latest is the 11th, because the
 * triggering date is contested" is more useful to somebody deciding what to do
 * this week than either a confident wrong date or silence.
 */
final class ClaimClock
{
    // What missing it does. Codex's five, and the distinction between the first
    // two is the entire reason this module exists separately from every other
    // clock in the product.
    public const PRESERVATIVE = 'preservative';
    public const ADMINISTRATIVE = 'administrative';
    public const ESCALATION = 'escalation';
    public const ENFORCEMENT = 'enforcement';
    public const INFORMATIONAL = 'informational';

    public const ESTABLISHED = 'established';
    public const UNRESOLVED_TRIGGER = 'unresolved_trigger';
    public const UNRESOLVED_CALENDAR = 'unresolved_calendar';
    public const UNRESOLVED_AUTHORITY = 'unresolved_authority';

    public const TRIGGER_CONFIRMED = 'confirmed';
    public const TRIGGER_DISPUTED = 'disputed';
    public const TRIGGER_UNRESOLVED = 'unresolved';

    /**
     * @param  array<string,mixed>  $requirement
     * @param  array<string,mixed>|null  $trigger
     * @param  array<string,mixed>  $calendar  ['confirmed' => bool, 'holidays' => list<string>, 'saturday_working' => bool]
     * @return array{state: string, deadline_on: ?string, earliest_on: ?string, latest_on: ?string,
     *   consequence: string, citation: ?string, message: string, may_alert: bool}
     */
    public static function calculate(array $requirement, ?array $trigger, array $calendar = []): array
    {
        $consequence = (string) ($requirement['consequence_class'] ?? self::INFORMATIONAL);
        $citation = $requirement['authority_citation'] ?? null;
        $title = (string) ($requirement['title'] ?? 'this requirement');

        // 1. The authority.
        if (($requirement['status'] ?? null) !== 'confirmed') {
            return self::out(self::UNRESOLVED_AUTHORITY, null, null, null, $consequence, $citation,
                'No deadline is shown for "'.$title.'" because the governing requirement has not been confirmed by anybody. '
                .'ZecoCM has no default notice period: a clock exists only once a person has read the clause it comes from. '
                .'An assumed ten days that turns out to be five is worse than no clock, because a wrong deadline is trusted.');
        }

        $period = $requirement['period_value'] ?? null;
        if ($period === null) {
            return self::out(self::UNRESOLVED_AUTHORITY, null, null, null, $consequence, $citation,
                'The confirmed requirement for "'.$title.'" records no period, so nothing can be counted.');
        }

        // 2. The counting rule. Checked BEFORE the trigger, deliberately: a
        // working-day rule with no confirmed calendar cannot produce a date
        // even from a perfect trigger, and reporting the trigger as the problem
        // would send somebody to fix the wrong thing.
        $rule = (string) ($requirement['calendar_rule'] ?? 'calendar');

        if ($rule !== 'calendar' && ! ($calendar['confirmed'] ?? false)) {
            return self::out(self::UNRESOLVED_CALENDAR, null, null, null, $consequence, $citation,
                'The governing requirement for "'.$title.'" counts in working days and no confirmed project calendar is '
                .'recorded, so the deadline cannot be established. ZecoCM will not quietly assume Monday to Friday: which '
                .'days count, and which holidays apply, is a contract question and not a convention.');
        }

        // 3. The trigger.
        if ($trigger === null) {
            return self::out(self::UNRESOLVED_TRIGGER, null, null, null, $consequence, $citation,
                'No triggering event is recorded for "'.$title.'", so there is nothing to count from.');
        }

        $status = (string) ($trigger['status'] ?? self::TRIGGER_UNRESOLVED);

        if ($status === self::TRIGGER_DISPUTED || $status === self::TRIGGER_UNRESOLVED) {
            $earliest = self::date($trigger['earliest_plausible_on'] ?? null);
            $latest = self::date($trigger['latest_plausible_on'] ?? null);

            if ($earliest === null || $latest === null) {
                return self::out(self::UNRESOLVED_TRIGGER, null, null, null, $consequence, $citation,
                    'The triggering date for "'.$title.'" is '.$status
                    .' and no plausible range is recorded, so no deadline can be established.');
            }

            $from = self::add($earliest, (int) $period, $rule, $calendar);
            $to = self::add($latest, (int) $period, $rule, $calendar);

            return self::out(self::UNRESOLVED_TRIGGER, null, $from->format('Y-m-d'), $to->format('Y-m-d'),
                $consequence, $citation,
                'The deadline for "'.$title.'" cannot be established because the triggering date is '.$status
                .'. On the earliest plausible trigger the deadline is '.$from->format('j M Y')
                .'; on the latest it is '.$to->format('j M Y')
                .'. Acting to the earlier date is the conservative course, and resolving the trigger is what settles it.',
                // A range is worth alerting on. Somebody deciding what to do
                // this week is better served by "between the 4th and the 11th"
                // than by silence.
                mayAlert: $consequence === self::PRESERVATIVE);
        }

        $occurred = self::date($trigger['occurred_on'] ?? null);
        if ($occurred === null) {
            return self::out(self::UNRESOLVED_TRIGGER, null, null, null, $consequence, $citation,
                'The triggering event for "'.$title.'" is marked confirmed but carries no date.');
        }

        $due = self::add($occurred, (int) $period, $rule, $calendar);

        return self::out(self::ESTABLISHED, $due->format('Y-m-d'), null, null, $consequence, $citation,
            'If the triggering date is '.$occurred->format('j M Y').', the deadline for "'.$title.'" is '
            .$due->format('j M Y').' ('.$period.' '.str_replace('_', ' ', (string) ($requirement['period_unit'] ?? 'calendar days'))
            .' counted as '.str_replace('_', ' ', $rule).').'
            .($consequence === self::PRESERVATIVE
                ? ' Missing it may impair or bar the right this requirement preserves.'
                : ''),
            mayAlert: true);
    }

    /**
     * What may be said once a preservative deadline has passed with nothing
     * recorded against it.
     *
     * NEVER "the claim is waived". Whether a right survives turns on facts and
     * law this software does not hold - actual notice, waiver by conduct,
     * equitable tolling, an owner who knew anyway. ZecoCM can prove what is in
     * its records and what is not. It cannot pronounce on rights, and a product
     * that told a contractor his claim was gone when it was not would be worse
     * than one that said nothing.
     */
    public static function afterDeadline(array $requirement, array $calculation, bool $hasQualifyingCompliance): string
    {
        $title = (string) ($requirement['title'] ?? 'this requirement');

        if ($hasQualifyingCompliance) {
            return 'A qualifying compliance event is recorded against "'.$title.'".';
        }

        if (($requirement['consequence_class'] ?? null) !== self::PRESERVATIVE) {
            return 'The recorded deadline for "'.$title.'" passed on '.($calculation['deadline_on'] ?? 'an unrecorded date')
                .' without a qualifying compliance event. This requirement is classified '
                .str_replace('_', ' ', (string) ($requirement['consequence_class'] ?? 'informational'))
                .', so no loss of rights follows from the record alone.';
        }

        return 'The recorded deadline for "'.$title.'" passed on '.($calculation['deadline_on'] ?? 'an unrecorded date')
            .' without a qualifying compliance event being recorded. This is a rights-preservation requirement under '
            .($requirement['authority_citation'] ?? 'the cited authority')
            .', so POTENTIAL LOSS OF RIGHTS REQUIRES REVIEW. ZecoCM is reporting the state of its own records and is not '
            .'determining that any claim is barred - whether a right survives turns on facts and law outside this system.';
    }

    /**
     * Whether the next gate in a sequence has opened yet.
     *
     * A public-works claim runs through stages: notice, written claim, the
     * owner's response, a conference, mediation, then enforcement. Showing six
     * unrelated red countdowns tells somebody nothing. "You preserved stage one
     * and stage two has not opened" tells them what to do today.
     *
     * @param  list<array<string,mixed>>  $dependencies
     * @return array{open: bool, reason: ?string}
     */
    public static function gateState(array $dependencies): array
    {
        foreach ($dependencies as $dependency) {
            $type = (string) ($dependency['dependency_type'] ?? 'completion');
            $satisfied = (bool) ($dependency['satisfied'] ?? false);

            if (! $satisfied) {
                return ['open' => false, 'reason' => 'This step does not open until "'
                    .($dependency['depends_on_title'] ?? 'the previous step').'" reaches '
                    .match ($type) {
                        'denial' => 'a recorded denial',
                        'expiration' => 'its own expiry',
                        'waiver' => 'a recorded waiver',
                        default => 'completion',
                    }.'. Its clock has not started and showing one would be inventing a deadline.'];
            }
        }

        return ['open' => true, 'reason' => null];
    }

    private static function add(DateTimeImmutable $from, int $period, string $rule, array $calendar): DateTimeImmutable
    {
        if ($rule === 'calendar') {
            return $from->modify("+{$period} days");
        }

        $holidays = (array) ($calendar['holidays'] ?? []);
        $saturdayWorking = (bool) ($calendar['saturday_working'] ?? false);
        $date = $from;
        $remaining = $period;

        while ($remaining > 0) {
            $date = $date->modify('+1 day');
            $dow = (int) $date->format('N');
            $working = $dow !== 7
                && ! ($dow === 6 && ! $saturdayWorking)
                && ! in_array($date->format('Y-m-d'), $holidays, true);

            if ($working) {
                $remaining--;
            }
        }

        return $date;
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format('Y-m-d'));
        }

        try {
            return new DateTimeImmutable((string) $value);
        } catch (\Exception) {
            return null;
        }
    }

    private static function out(string $state, ?string $deadline, ?string $earliest, ?string $latest,
        string $consequence, ?string $citation, string $message, bool $mayAlert = false): array
    {
        return [
            'state' => $state,
            'deadline_on' => $deadline,
            'earliest_on' => $earliest,
            'latest_on' => $latest,
            'consequence' => $consequence,
            'citation' => $citation,
            'message' => $message,
            'may_alert' => $mayAlert,
        ];
    }
}
