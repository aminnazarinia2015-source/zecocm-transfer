<?php

namespace App\Domain\Evolution;

use App\Models\CapabilityGap;
use Illuminate\Support\Facades\DB;

/**
 * ZecoCM watching where it failed, and proposing what to build next.
 *
 * The signals already exist and all of them currently go nowhere. A no_match is
 * logged and forgotten. A steward correcting an answer writes to a table
 * nothing reads. Somebody paying for a capability the catalogue reports as
 * unbuilt is invisible to everyone. Each of those is the product telling us
 * what it is missing, in the words of somebody who actually needed it.
 *
 * THE HARD BOUNDARY, and it is a commercial decision rather than a cautious
 * one: this proposes and never applies. The claim ZecoCM sells is that its
 * record is explainable - that you can ask why it answered as it did on a
 * particular Tuesday and get a true answer. A system that rewrote its own code
 * overnight cannot answer that question about itself, and the first opposing
 * expert who understands the point ends the product. Governed self-improvement
 * compounds; self-modification is a demonstration that dies in a deposition.
 *
 * THE THRESHOLD. A queue showing every signal is a wall of noise nobody reads,
 * and that is what kills every system of this shape. So a gap is recorded from
 * the first occurrence and does NOT ask for anybody's attention until it clears
 * the bar in `PROPOSAL_THRESHOLD` - repeated, and repeated by more than one
 * person. One person asking the same unanswerable question five times is one
 * person with a habit. Five people asking it once each is a missing capability.
 *
 * THE PERVERSE INCENTIVE. A system proposing its own next feature from its own
 * failures will propose additions forever and never once propose that something
 * should be removed, or that an answer it gave confidently was wrong. Additions
 * flatter it. So the signal set deliberately includes the two kinds it would
 * never volunteer: `steward_correction`, which is the record of ZecoCM being
 * confidently wrong, and `capability_unused`, which is the case for taking
 * something away. Those two are weighted ABOVE the flattering ones.
 */
final class SelfObservation
{
    public const NO_MATCH = 'no_match';
    public const ESCALATION = 'escalation';
    public const STEWARD_CORRECTION = 'steward_correction';
    public const UNBUILT_CAPABILITY_LICENSED = 'unbuilt_capability_licensed';
    public const CAPABILITY_UNUSED = 'capability_unused';

    /**
     * The signal worth more than the other five put together.
     *
     * Codex offered this almost in passing and it is the strongest product
     * evidence available anywhere in the system. A no_match says the assistant
     * could not answer. A workflow escape says something else entirely:
     *
     *   A COMPETENT PERSON LEFT THE PATH WE DESIGNED.
     *
     * They exported the data and edited it offline. They kept a parallel
     * spreadsheet for something this product claims to handle. They overrode
     * the same governed control for the fifth time. They uploaded a finished
     * artifact produced somewhere else. None of that is a complaint anybody
     * files, and all of it is the truth about whether the product works.
     *
     * Recorded as BEHAVIOUR only. A repeated override is not evidence that the
     * rule is wrong - it may equally mean the rule is right and the metadata
     * it demands is too burdensome, or that the workflow cannot express what is
     * actually happening on the job. Which of those it is, is a human's
     * reading, and the system does not get to decide it.
     */
    public const WORKFLOW_ESCAPE = 'workflow_escape';

    public const OBSERVED = 'observed';
    public const PROPOSED = 'proposed';
    public const AUTHORIZED = 'authorized';
    public const DECLINED = 'declined';
    public const SHIPPED = 'shipped';

    /**
     * What a gap must reach before a person is asked to look at it.
     *
     * Two dimensions, not one. Occurrences alone rewards a single enthusiastic
     * user; distinct askers alone rewards a rare question lots of people asked
     * once. Both, or it stays observed.
     */
    public const PROPOSAL_THRESHOLD = [
        self::NO_MATCH => ['occurrences' => 5, 'askers' => 3],
        self::ESCALATION => ['occurrences' => 8, 'askers' => 3],
        // A steward correcting an answer is ZecoCM having been confidently
        // wrong, which is worth a person's attention far sooner than a refusal.
        // Refusals are the system working; corrections are not.
        self::STEWARD_CORRECTION => ['occurrences' => 2, 'askers' => 1],
        // Somebody has PAID for something we have not built. One is enough.
        self::UNBUILT_CAPABILITY_LICENSED => ['occurrences' => 1, 'askers' => 1],
        self::CAPABILITY_UNUSED => ['occurrences' => 1, 'askers' => 1],
        // Low, deliberately. Somebody going around the product twice is worth
        // hearing about long before somebody asking a question five times.
        self::WORKFLOW_ESCAPE => ['occurrences' => 3, 'askers' => 2],
    ];

    /**
     * Capabilities this system may never produce an actionable proposal about,
     * identified by WHAT IS TOUCHED rather than by what words were used.
     *
     * The previous version matched substrings in the proposal text, and Codex
     * was right to call that theatre: a proposal reading "the system is too
     * conservative when documents disagree" never contains the string
     * refusal_policy, and would have sailed through. Meanwhile a legitimate
     * proposal that merely MENTIONS provenance in passing was refused. Wrong in
     * both directions, which is the signature of a control matching the wrong
     * thing.
     *
     * The target capability comes from instrumentation - which component
     * emitted the refusal, which rule fired, which module produced the signal -
     * so it is a fact about the system rather than a reading of somebody's
     * prose. Enforced TWICE, at proposal and again at authorisation, because a
     * control that can be bypassed by writing directly to the second step is
     * one control wearing two hats.
     */
    public const PROTECTED_CAPABILITIES = [
        'tenancy',
        'authorization',
        'evidence_seal',
        'provenance',
        'chain_verification',
        'refusal_policy',
        'governed_determination',
        'acquisition_gate',
        'instruction_trust',
        'self_observation',
    ];

    /**
     * Record one signal, clustered.
     *
     * The cluster key is stored on the row rather than recomputed in a query,
     * so the rule by which two failures are "the same gap" is a fact in the
     * record and can be argued with, rather than a heuristic buried in SQL.
     */
    public static function observe(
        string $signalKind,
        string $clusterKey,
        string $title,
        array $evidence = [],
        ?int $tenantId = null,
        ?string $askerKey = null,
        ?string $targetCapability = null,
        ?string $projectKey = null,
        bool $fromExternalUser = false,
    ): CapabilityGap {
        // Observation is NEVER refused, including about protected capabilities.
        // Refusing to notice is not a control, it is blindness. What is refused
        // is turning it into a proposal.

        return DB::transaction(function () use ($signalKind, $clusterKey, $title, $evidence, $tenantId, $askerKey, $targetCapability, $projectKey, $fromExternalUser) {
            $gap = CapabilityGap::query()
                ->where('tenant_id', $tenantId)
                ->where('cluster_key', $clusterKey)
                ->lockForUpdate()
                ->first();

            if ($gap === null) {
                return CapabilityGap::create([
                    'tenant_id' => $tenantId,
                    'signal_kind' => $signalKind,
                    'cluster_key' => $clusterKey,
                    'title' => $title,
                    'evidence' => ['samples' => array_slice([$evidence], 0, 5),
                        'askers' => $askerKey === null ? [] : [$askerKey],
                        'projects' => $projectKey === null ? [] : [$projectKey]],
                    'occurrences' => 1,
                    'distinct_askers' => $askerKey === null ? 0 : 1,
                    'distinct_projects' => $projectKey === null ? 0 : 1,
                    'target_capability' => $targetCapability,
                    'includes_external_usage' => $fromExternalUser,
                    'first_seen_at' => now(),
                    'last_seen_at' => now(),
                    'status' => self::OBSERVED,
                ]);
            }

            $stored = (array) $gap->evidence;
            $askers = (array) ($stored['askers'] ?? []);
            if ($askerKey !== null && ! in_array($askerKey, $askers, true)) {
                $askers[] = $askerKey;
            }

            $projects = (array) ($stored['projects'] ?? []);
            if ($projectKey !== null && ! in_array($projectKey, $projects, true)) {
                $projects[] = $projectKey;
            }

            $samples = (array) ($stored['samples'] ?? []);
            // Five examples, kept from the start of the cluster's life. Enough
            // for a person to recognise the pattern; not a transcript.
            if (count($samples) < 5 && $evidence !== []) {
                $samples[] = $evidence;
            }

            $gap->forceFill([
                'evidence' => ['samples' => $samples, 'askers' => $askers, 'projects' => $projects],
                'occurrences' => (int) $gap->occurrences + 1,
                'distinct_askers' => count($askers),
                // Three people hitting the same broken project state is one
                // incident wearing three coats. Distinct askers alone would
                // have read it as three.
                'distinct_projects' => count($projects),
                'includes_external_usage' => (bool) $gap->includes_external_usage || $fromExternalUser,
                'last_seen_at' => now(),
            ])->save();

            return $gap;
        });
    }

    /** Has this gap earned somebody's attention yet? */
    public static function readyToPropose(CapabilityGap $gap): bool
    {
        if ($gap->status !== self::OBSERVED) {
            return false;
        }

        $bar = self::PROPOSAL_THRESHOLD[$gap->signal_kind] ?? ['occurrences' => 10, 'askers' => 5];

        return (int) $gap->occurrences >= $bar['occurrences']
            && (int) $gap->distinct_askers >= $bar['askers'];
    }

    /**
     * Promote a gap to a proposal, with the evidence a person needs in order to
     * spend attention on it and nothing else.
     *
     * The bar for what a proposal must carry: what failed, how often, for how
     * many different people, over what span, with real examples, and what it
     * would take. A proposal without those is an opinion, and a queue of
     * opinions is the thing nobody reads.
     */
    public static function propose(CapabilityGap $gap, string $proposal, ?string $registerRow = null): CapabilityGap
    {
        // Enforced on what the proposal TOUCHES, from instrumentation, not on
        // the words somebody chose. Enforced again at authorisation below.
        self::refuseIfProtected($gap->target_capability);

        if (! self::readyToPropose($gap)) {
            throw new \RuntimeException(
                'This gap has not earned a person\'s attention yet: '.$gap->occurrences.' occurrence(s) across '
                .$gap->distinct_askers.' asker(s). Proposing everything is how the queue becomes a wall nobody reads.'
            );
        }

        $gap->forceFill([
            'status' => self::PROPOSED,
            'proposal' => $proposal,
            'register_row' => $registerRow,
        ])->save();

        return $gap;
    }

    /**
     * The decision, either way, recorded with its reason.
     *
     * Declining is recorded as deliberately as authorising. A gap that keeps
     * recurring after somebody decided not to build it is a different and more
     * interesting fact than a gap nobody has looked at, and losing the decline
     * would make the two indistinguishable.
     */
    public static function decide(CapabilityGap $gap, int $userId, bool $authorized, string $reason): CapabilityGap
    {
        if ($gap->status !== self::PROPOSED) {
            throw new \RuntimeException('Only a proposed gap can be decided. This one is '.$gap->status.'.');
        }

        // The second gate. A control enforced only at creation is one control
        // wearing two hats - anything that writes a row directly then walks in
        // through this door.
        self::refuseIfProtected($gap->target_capability);

        $gap->forceFill([
            'status' => $authorized ? self::AUTHORIZED : self::DECLINED,
            'authorized_by' => $userId,
            'authorized_at' => now(),
            'decision_reason' => $reason,
        ])->save();

        return $gap;
    }

    /**
     * A stable identity for "the same question, asked again".
     *
     * Content words only, sorted, capped. Not a hash of the raw text - two
     * people never phrase a question identically, and a cluster key that
     * demands they do would produce a thousand clusters of one. Deliberately
     * crude: a clustering rule a human can read and disagree with beats an
     * embedding nobody can audit, in a system whose whole claim is
     * explainability.
     */
    public static function clusterKeyFor(string $question, string $scope = ''): string
    {
        $words = preg_split('/[^a-z0-9]+/', strtolower($question), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $stop = ['the', 'and', 'for', 'are', 'was', 'were', 'what', 'when', 'where', 'which', 'who', 'how',
            'does', 'did', 'can', 'could', 'should', 'would', 'this', 'that', 'with', 'from', 'have', 'has',
            'our', 'their', 'they', 'you', 'your', 'about', 'into', 'than', 'then', 'there', 'any', 'all'];
        $words = array_values(array_unique(array_filter($words, fn ($w) => strlen($w) > 2 && ! in_array($w, $stop, true))));
        sort($words);

        return trim($scope.'|'.implode('-', array_slice($words, 0, 8)), '|');
    }

    /**
     * Refuse to record an actionable proposal touching a protected capability.
     *
     * Honest about what it is and is not. A person may still change any of
     * these deliberately - that is their job. What is prevented is the machine
     * putting the idea in front of a tired person as though it came from the
     * evidence, because every constraint looks like an obstacle from the inside
     * and the justification will always read as reasonable.
     *
     * An observation about a protected capability is still RECORDED. It simply
     * never becomes a proposal. "This came up nineteen times, a human should
     * look at the architecture" is useful; "here is the change to make" is not
     * something this system may say about the things that constrain it.
     */
    public static function isProtected(?string $targetCapability): bool
    {
        return $targetCapability !== null
            && in_array($targetCapability, self::PROTECTED_CAPABILITIES, true);
    }

    private static function refuseIfProtected(?string $targetCapability): void
    {
        if (! self::isProtected($targetCapability)) {
            return;
        }

        throw new \RuntimeException(
            'ZecoCM will not produce an actionable proposal touching "'.$targetCapability.'". '
            .'That capability is one of the controls that constrain this system, and a machine proposing '
            .'changes to its own constraints will eventually propose loosening them with a justification '
            .'drawn from real user friction. The observation is still recorded, and a person may change '
            .'this deliberately - what is prevented is the suggestion arriving as though the evidence '
            .'asked for it.'
        );
    }
}
