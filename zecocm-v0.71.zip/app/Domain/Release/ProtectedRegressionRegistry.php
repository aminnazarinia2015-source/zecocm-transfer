<?php

namespace App\Domain\Release;

/**
 * REL-1: reads config/release_protected_regressions.php - the checked-in,
 * git-tracked list of test IDs this codebase already learned it cannot
 * afford to lose silently (see that file's own doc comment). This class
 * does not change enforcement - every removed test requires a justification
 * regardless of protection (see ReleaseManifestBuilder) - it only labels
 * WHICH removals are the historically-worst kind, so a build failure names
 * the stakes rather than reading as generic bookkeeping.
 */
final class ProtectedRegressionRegistry
{
    /**
     * @return array<string, string> test id (or "Class" for a whole-class
     *                               entry) => reason
     */
    public static function all(): array
    {
        return config('release_protected_regressions', []);
    }

    /**
     * Null if $testId is not protected. A protected reason is returned for
     * an exact "Class::method" match, or when $testId's class matches a
     * whole-class entry in the registry (no "::").
     */
    public static function reasonFor(string $testId): ?string
    {
        $all = self::all();

        if (isset($all[$testId])) {
            return $all[$testId];
        }

        $class = strstr($testId, '::', true) ?: $testId;

        foreach ($all as $key => $reason) {
            if (! str_contains($key, '::') && $key === $class) {
                return $reason;
            }
        }

        return null;
    }

    /**
     * Codex's first adversarial finding on this row: a protected test id
     * surviving is not proof its BODY survived - "same test id, weaker
     * test" would pass an id-only diff silently. This hashes the actual
     * method source (by line range, via Reflection) so a build can detect
     * that a protected regression's content changed even though its name
     * did not, and treat that exactly like a removal - requires an
     * explicit justification, never sails through on identity alone.
     *
     * Null when the class/method cannot be resolved (e.g. this id belongs
     * to a release this codebase's current checkout does not contain -
     * ReleaseManifestBuilder only compares ids present in both snapshots,
     * so a null here never fabricates a false "changed" signal).
     */
    public static function contentHash(string $testId): ?string
    {
        if (! str_contains($testId, '::')) {
            return null;
        }

        [$class, $method] = explode('::', $testId, 2);

        if (! class_exists($class)) {
            return null;
        }

        try {
            $reflection = new \ReflectionClass($class);
        } catch (\ReflectionException) {
            return null;
        }

        if (! $reflection->hasMethod($method)) {
            return null;
        }

        $reflectionMethod = $reflection->getMethod($method);
        $file = $reflectionMethod->getFileName();

        if ($file === false) {
            return null;
        }

        $lines = file($file);

        if ($lines === false) {
            return null;
        }

        $start = $reflectionMethod->getStartLine() - 1;
        $end = $reflectionMethod->getEndLine();
        $body = implode('', array_slice($lines, max($start, 0), max($end - $start, 0)));

        return hash('sha256', $body);
    }
}
