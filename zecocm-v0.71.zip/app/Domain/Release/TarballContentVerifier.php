<?php

namespace App\Domain\Release;

use App\Domain\Security\BoundedProcess;

/**
 * REL-1, Codex's acceptance case: "Tarball contents differ from tested
 * source -> fails." A delta tarball is built by hand from a scratch staging
 * copy (`claude/closure-progress.md`'s deploy-tarball notes) - this class is
 * the check that the bytes actually shipped are the bytes actually tested at
 * the named commit, file for file, rather than trusting the build step did
 * not drift.
 *
 * Comparison goes through git's own blob hashing (`git hash-object` /
 * `git rev-parse <commit>:<path>`) rather than reading either side's bytes
 * into a PHP string - `BoundedProcess::run()` trims stdout, which would
 * silently corrupt an exact-byte comparison for any file ending in
 * whitespace/newlines. A blob hash is a fixed-width hex string, so trimming
 * it is harmless, and this sidesteps the binary-safety question entirely.
 */
final class TarballContentVerifier
{
    /**
     * @return list<string> mismatch descriptions; empty means every file
     *                      inside the tarball matches the git blob at
     *                      $commit for the same relative path exactly.
     */
    public function verify(string $tarballPath, string $repoPath, string $commit): array
    {
        if (! is_file($tarballPath)) {
            return ["tarball not found at {$tarballPath}"];
        }

        $extractDir = sys_get_temp_dir().'/rel1-verify-'.bin2hex(random_bytes(8));
        mkdir($extractDir, 0700, true);

        try {
            BoundedProcess::run(['tar', '-xzf', $tarballPath, '-C', $extractDir], 30);

            $mismatches = [];
            $files = $this->listFiles($extractDir);

            if ($files === []) {
                return ['tarball contains no files'];
            }

            foreach ($files as $relativePath) {
                $tarballBlob = BoundedProcess::run(
                    ['git', 'hash-object', "{$extractDir}/{$relativePath}"],
                    10,
                );

                if ($tarballBlob['status'] !== BoundedProcess::OK || $tarballBlob['exitCode'] !== 0) {
                    $mismatches[] = "{$relativePath}: could not hash the tarball's own copy of this file";

                    continue;
                }

                $sourceBlob = BoundedProcess::run(
                    ['git', '-C', $repoPath, 'rev-parse', "{$commit}:{$relativePath}"],
                    10,
                );

                if ($sourceBlob['status'] !== BoundedProcess::OK || $sourceBlob['exitCode'] !== 0) {
                    $mismatches[] = "{$relativePath}: not present in source at {$commit} (tarball carries an untracked or stale file)";

                    continue;
                }

                if ($sourceBlob['stdout'] !== $tarballBlob['stdout']) {
                    $mismatches[] = "{$relativePath}: tarball content does not match source at {$commit}";
                }
            }

            return $mismatches;
        } finally {
            BoundedProcess::run(['rm', '-rf', $extractDir], 10);
        }
    }

    /** @return list<string> paths relative to $dir, files only */
    private function listFiles(string $dir): array
    {
        $result = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $result[] = ltrim(substr($file->getPathname(), strlen($dir)), '/');
            }
        }

        sort($result);

        return $result;
    }
}
