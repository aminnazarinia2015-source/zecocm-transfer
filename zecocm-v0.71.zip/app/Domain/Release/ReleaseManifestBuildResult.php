<?php

namespace App\Domain\Release;

use App\Models\ReleaseManifest;

/**
 * REL-1: the outcome of one build attempt. `manifest` is always set (a
 * failed attempt is persisted too - see the migration's doc comment);
 * `failures` is empty exactly when `manifest->verification_status ===
 * 'verified'`.
 */
final class ReleaseManifestBuildResult
{
    /** @param list<string> $failures */
    public function __construct(
        public readonly ReleaseManifest $manifest,
        public readonly array $failures,
    ) {}

    public function passed(): bool
    {
        return $this->failures === [];
    }
}
