<?php

namespace App\Domain\Release;

use App\Models\ReleaseManifest;
use Illuminate\Support\Facades\DB;

/**
 * REL-1: the single place a release candidate is judged fit to enter the
 * deploy queue. Every check here answers a specific failure mode Codex
 * named, or one this codebase has already lived through once:
 *
 * - a removed test id with no justification (protected or not) is exactly
 *   the TR-17 near-miss shape: a suite that stays green while a real
 *   protection silently disappears (`claude/closure-progress.md`'s "A
 *   near-miss worth recording").
 * - tarball-vs-source mismatch is the DATA-3/EV-14B lesson generalized:
 *   "bytes surviving with matching hashes does not mean the migrated
 *   system state was operationally correct" applies just as much to "the
 *   tarball I'm about to ship" as it did to a database migration.
 * - a required suite going missing (e.g. the tenancy/evidence invariant
 *   tests) is the same TR-17 failure mode at the level of a whole class
 *   rather than one method.
 *
 * A build attempt is ALWAYS persisted, verified or not - see the migration
 * and ReleaseManifestBuildResult's own doc comments for why a refused build
 * is itself the evidentiary record this row exists to keep.
 */
final class ReleaseManifestBuilder
{
    public function __construct(
        private readonly TarballContentVerifier $tarballVerifier = new TarballContentVerifier,
    ) {}

    /**
     * @param  array{
     *     version: string,
     *     sourceCommit: string,
     *     tarballPath: ?string,
     *     repoPath: string,
     *     migrationsDir: string,
     *     currentTests: JunitTestManifest,
     *     baseline: ?ReleaseManifest,
     *     justifications: array<string, array{reason: string, authorized_by: string, renamed_to?: string}>,
     *     requiredSuites: list<string>,
     *     dependsOn: list<string>,
     * }  $params
     */
    public function build(array $params): ReleaseManifestBuildResult
    {
        $currentTests = $params['currentTests'];
        $baseline = $params['baseline'];
        $justifications = $params['justifications'] ?? [];
        $failures = [];

        $addedIds = [];
        $removedIds = [];

        // Every protected id/class still present in this build gets its
        // method body hashed, regardless of whether there is a baseline -
        // this build's own hashes become the baseline the NEXT build diffs
        // against.
        $currentProtectedHashes = [];
        foreach ($currentTests->testIds() as $id) {
            if (ProtectedRegressionRegistry::reasonFor($id) !== null) {
                $hash = ProtectedRegressionRegistry::contentHash($id);
                if ($hash !== null) {
                    $currentProtectedHashes[$id] = $hash;
                }
            }
        }

        if ($baseline !== null) {
            $baselineTests = JunitTestManifest::fromIds($baseline->test_ids);
            $addedIds = $currentTests->addedSince($baselineTests);
            $removedIds = $currentTests->removedSince($baselineTests);

            foreach ($removedIds as $id) {
                if (isset($justifications[$id])) {
                    continue;
                }

                $protectedReason = ProtectedRegressionRegistry::reasonFor($id);
                $failures[] = $protectedReason !== null
                    ? "PROTECTED regression removed without justification: {$id} - {$protectedReason}"
                    : "test removed without justification (this is the TR-17 near-miss shape - a green suite is not proof nothing disappeared): {$id}";
            }

            // Codex's first adversarial finding: "same test id, weaker
            // test" must not sail through on identity alone. Only compare
            // ids present in BOTH snapshots - a removed id is already
            // handled above, and a brand-new id has no baseline hash to
            // differ from.
            $baselineHashes = $baseline->protected_content_hashes ?? [];
            foreach ($currentProtectedHashes as $id => $hash) {
                if (! isset($baselineHashes[$id]) || $baselineHashes[$id] === $hash) {
                    continue;
                }

                if (isset($justifications[$id])) {
                    continue;
                }

                $reason = ProtectedRegressionRegistry::reasonFor($id);
                $failures[] = "PROTECTED regression content changed without acknowledgment: {$id} - {$reason}";
            }
        }

        foreach ($params['requiredSuites'] ?? [] as $class) {
            if (! $currentTests->classIsPresent($class)) {
                $failures[] = "required suite absent from this release's test snapshot: {$class}";
            }
        }

        $tarballPath = $params['tarballPath'];
        $tarballSha256 = null;

        if ($tarballPath !== null) {
            if (! is_file($tarballPath)) {
                $failures[] = "declared tarball not found at {$tarballPath}";
            } else {
                $tarballSha256 = hash_file('sha256', $tarballPath);
                $mismatches = $this->tarballVerifier->verify($tarballPath, $params['repoPath'], $params['sourceCommit']);
                foreach ($mismatches as $mismatch) {
                    $failures[] = "tarball content mismatch: {$mismatch}";
                }
            }
        }

        $migrationFiles = $this->hashMigrations($params['migrationsDir']);

        $manifest = ReleaseManifest::create([
            'version' => $params['version'],
            'source_commit' => $params['sourceCommit'],
            'tarball_path' => $tarballPath,
            'tarball_sha256' => $tarballSha256,
            'migration_files' => $migrationFiles,
            'test_ids' => $currentTests->testIds(),
            'total_tests' => $currentTests->totalTests(),
            'total_assertions' => $currentTests->totalAssertions(),
            'baseline_version' => $baseline?->version,
            'tests_added' => $addedIds,
            'tests_removed' => $removedIds,
            'removal_justifications' => $justifications,
            'protected_content_hashes' => $currentProtectedHashes,
            'required_suites' => $params['requiredSuites'] ?? [],
            'depends_on' => $params['dependsOn'] ?? [],
            'verification_status' => $failures === [] ? 'verified' : 'failed',
            'verification_failures' => $failures,
            'created_at' => now(),
        ]);

        return new ReleaseManifestBuildResult($manifest, $failures);
    }

    /** @return list<array{file: string, sha256: string}> */
    private function hashMigrations(string $migrationsDir): array
    {
        if (! is_dir($migrationsDir)) {
            return [];
        }

        $files = glob(rtrim($migrationsDir, '/').'/*.php') ?: [];
        sort($files);

        return array_map(
            fn (string $path) => ['file' => basename($path), 'sha256' => hash_file('sha256', $path)],
            $files,
        );
    }

    public static function latestManifestFor(?string $version): ?ReleaseManifest
    {
        if ($version === null) {
            return null;
        }

        return ReleaseManifest::where('version', $version)->orderByDesc('id')->first();
    }

    /** Whether every version in $dependsOn has at least one recorded deployment. */
    public static function deployOrderSatisfied(array $dependsOn): array
    {
        $missing = [];

        foreach ($dependsOn as $version) {
            $deployed = DB::table('release_deployments')
                ->where('version', $version)
                ->where('http_healthy', true)
                ->exists();

            if (! $deployed) {
                $missing[] = $version;
            }
        }

        return $missing;
    }
}
