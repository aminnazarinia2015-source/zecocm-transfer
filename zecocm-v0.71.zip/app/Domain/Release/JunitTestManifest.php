<?php

namespace App\Domain\Release;

/**
 * REL-1: parses a PHPUnit `--log-junit` XML file into a normalized,
 * stable set of test IDs ("Class::method") plus totals. This replaces the
 * manual "read php artisan test's summary line by eye" discipline this
 * session applied at every single commit (`claude/closure-progress.md`'s
 * "Exact suite-delta discipline") with a machine-checkable snapshot -
 * exactly the primitive that would have caught the TR-17 near-miss
 * automatically instead of by hand arithmetic.
 */
final class JunitTestManifest
{
    /** @var list<string> */
    private array $testIds;

    private int $totalTests;

    private ?int $totalAssertions;

    private function __construct(array $testIds, int $totalTests, ?int $totalAssertions)
    {
        $this->testIds = $testIds;
        $this->totalTests = $totalTests;
        $this->totalAssertions = $totalAssertions;
    }

    public static function fromXmlFile(string $path): self
    {
        if (! is_file($path)) {
            throw new \RuntimeException("REL-1: JUnit log not found at {$path}.");
        }

        $xml = simplexml_load_string(
            file_get_contents($path) ?: throw new \RuntimeException("REL-1: could not read {$path}.")
        );

        if ($xml === false) {
            throw new \RuntimeException("REL-1: {$path} is not valid XML.");
        }

        $testIds = [];
        $assertions = 0;
        $cases = $xml->xpath('//testcase');
        // The true suite total is the number of <testcase> elements PHPUnit
        // actually ran - matching the "tests" figure this session has used
        // by hand at every commit (e.g. "779 -> 789"). This is deliberately
        // NOT count($testIds) below: a data-provider method produces one
        // <testcase> per data set but collapses to a single test id, so
        // total tests can legitimately exceed the unique-id count. PHPUnit's
        // own root <testsuites> element carries no "tests" attribute of its
        // own (only the nested per-file <testsuite> elements do), so reading
        // $xml->attributes() here would silently fall through and undercount
        // - counting the raw testcase elements is correct regardless of
        // how deeply PHPUnit nests its own testsuite summary elements.
        $total = count($cases);

        foreach ($cases as $case) {
            $class = (string) $case['class'];
            $name = (string) $case['name'];

            // A data-provider test case renders as "name with data set #0" -
            // strip PHPUnit's own suffix so this row's identity is the test
            // METHOD, not one particular data row, matching how this
            // session's manual exact-delta discipline always counted them.
            $name = preg_replace('/ with data set .*/', '', $name) ?? $name;

            $testIds[] = $class !== '' ? "{$class}::{$name}" : $name;
            $assertions += (int) ($case['assertions'] ?? 0);
        }

        $testIds = array_values(array_unique($testIds));
        sort($testIds);

        return new self($testIds, $total, $assertions > 0 ? $assertions : null);
    }

    /** @param list<string> $testIds */
    public static function fromIds(array $testIds, ?int $totalAssertions = null): self
    {
        $testIds = array_values(array_unique($testIds));
        sort($testIds);

        return new self($testIds, count($testIds), $totalAssertions);
    }

    /** @return list<string> */
    public function testIds(): array
    {
        return $this->testIds;
    }

    public function totalTests(): int
    {
        return $this->totalTests;
    }

    public function totalAssertions(): ?int
    {
        return $this->totalAssertions;
    }

    /** @return list<string> ids in $this but not in $baseline */
    public function addedSince(self $baseline): array
    {
        return array_values(array_diff($this->testIds, $baseline->testIds));
    }

    /** @return list<string> ids in $baseline but not in $this */
    public function removedSince(self $baseline): array
    {
        return array_values(array_diff($baseline->testIds, $this->testIds));
    }

    /** Every test method of $class currently present. */
    public function classIsPresent(string $class): bool
    {
        foreach ($this->testIds as $id) {
            if (str_starts_with($id, "{$class}::")) {
                return true;
            }
        }

        return false;
    }
}
