<?php

namespace App\Domain\Payment;

/**
 * How much may be withheld, and on what basis - resolved, not assumed.
 *
 * The first version of this hardcoded "no retention on stored materials". Codex
 * caught it, and the correction matters: on California local-agency public works,
 * Public Contract Code section 9203 limits a progress payment to 95% of the value
 * of work performed AND 95% of the value of qualifying delivered or stored
 * materials. So retention applies to stored material too, and the hardcoded
 * exemption was withholding the wrong amount in the contractor's favour - which is
 * still the wrong amount. Section 7201 generally caps retention at 5%.
 *
 * The deeper error was structural. Retention is a governing rule resolved from
 * statute and the contract together; it is not a constant, and it is not a bare
 * number on a form. Every other clock in this system already refuses to invent a
 * contract term. This now does the same: the statutory default is carried WITH ITS
 * CITATION and must be confirmed by a human at project setup, exactly like the
 * contract clocks. A rate nobody read out of a document is a guess with a decimal
 * point on it.
 */
final class RetentionRule
{
    /**
     * PCC 7201 generally caps retention on public works at 5%. Carried as a cited
     * default and a ceiling to check against - never silently applied as truth.
     */
    public const STATUTORY_CAP_BASIS_POINTS = 500;

    public const CAP_CITATION = 'California Public Contract Code s. 7201';

    /**
     * PCC 9203 measures a progress payment as 95% of work performed plus 95% of
     * qualifying delivered/stored material - i.e. retention reaches both.
     */
    public const STORED_MATERIAL_CITATION = 'California Public Contract Code s. 9203';

    public function __construct(
        public readonly int $basisPoints,
        /** Where this rate came from: a contract clause, or a cited statute. */
        public readonly string $source,
        /** Whether retention is withheld against stored/delivered materials. */
        public readonly bool $appliesToStoredMaterials = true,
        public readonly ?string $storedMaterialsSource = null,
        /** False until a human confirmed it at project setup. */
        public readonly bool $confirmed = false,
    ) {
        if ($basisPoints < 0 || $basisPoints > 10000) {
            throw new \InvalidArgumentException('Retention must be between 0 and 100 percent.');
        }

        if (trim($source) === '') {
            throw new \InvalidArgumentException(
                'A retention rate must name where it came from - a contract clause or a cited statute. A rate nobody read out of a document is a guess with a decimal point on it.'
            );
        }
    }

    /**
     * The California local-agency public works default. Cited, and NOT confirmed:
     * the caller must show it to a human before relying on it.
     */
    public static function californiaPublicWorksDefault(): self
    {
        return new self(
            basisPoints: self::STATUTORY_CAP_BASIS_POINTS,
            source: self::CAP_CITATION.' (statutory default - confirm against this contract)',
            appliesToStoredMaterials: true,
            storedMaterialsSource: self::STORED_MATERIAL_CITATION,
            confirmed: false,
        );
    }

    /**
     * Build from a project's recorded terms. Returns null when nothing was
     * recorded, so the caller must say "no retention rule is configured" rather
     * than withhold an assumed five percent of somebody's money.
     *
     * @param  array<string,mixed>|null  $terms
     */
    public static function fromProjectTerms(?array $terms): ?self
    {
        if (! is_array($terms) || ! isset($terms['basis_points'], $terms['source'])) {
            return null;
        }

        return new self(
            basisPoints: (int) $terms['basis_points'],
            source: (string) $terms['source'],
            appliesToStoredMaterials: (bool) ($terms['applies_to_stored_materials'] ?? true),
            storedMaterialsSource: $terms['stored_materials_source'] ?? null,
            confirmed: (bool) ($terms['confirmed'] ?? false),
        );
    }

    /** Retention withheld, in cents. Truncates, so the fraction falls the contractor's way. */
    public function withhold(int $earnedCents, int $storedMaterialsCents): int
    {
        $base = $earnedCents + ($this->appliesToStoredMaterials ? $storedMaterialsCents : 0);

        return intdiv($base * $this->basisPoints, 10000);
    }

    /** Above the statutory ceiling is a finding, not a preference. */
    public function exceedsStatutoryCap(): bool
    {
        return $this->basisPoints > self::STATUTORY_CAP_BASIS_POINTS;
    }
}
