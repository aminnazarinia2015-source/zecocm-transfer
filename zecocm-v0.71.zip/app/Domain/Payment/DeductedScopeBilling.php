<?php

namespace App\Domain\Payment;

/**
 * Billing against scope a change order already removed.
 *
 * Codex's second false-claim check. A deductive change order deletes work from
 * the contract; the schedule-of-values line stays on the screen; the billing
 * carries on. Cumulative value can remain comfortably under the reduced cap the
 * whole time, so the over-billing validator is silent - correctly, because the
 * total is not the problem. The composition is.
 *
 * WHAT THIS BUILD ACTUALLY PROVES, AND WHAT IT DOES NOT.
 *
 * Codex specified the general case: identify the portion of current-period
 * billing attributable to the removed scope, even while the line still has
 * headroom. I have built the part that is deterministic and I have NOT built
 * the part that is not, because the missing piece is not code.
 *
 *   Fully deleted scope is certain. When a deductive change order takes a line
 *   to zero authorized value and somebody bills work on it in a later period,
 *   there is no remaining scope for that money to belong to. Nothing has to be
 *   attributed. That is HARD_INVALID and it is decidable from what we hold.
 *
 *   Partial deduction is not. A line reduced from $200,000 to $120,000 with
 *   $40,000 previously certified and $60,000 billed this period may be entirely
 *   legitimate remaining work, or may be $40,000 of remaining work and $20,000
 *   of scope that was deleted. The money is identical in both cases. Nothing in
 *   the schedule of values distinguishes them, because a schedule-of-values line
 *   is a dollar figure, not an inventory of what the dollars are for.
 *
 * Inventing an attribution would be inventing the violation - the same mistake
 * as putting a number on an uncovered wage classification. So the partial case
 * asks rather than accuses: it names the change order, states what was removed,
 * and requires the preparer to record which remaining scope the billing is for.
 * That answer is then on the record, which is the actual product.
 *
 * Closing this properly needs scope-level allocation - a deductive change order
 * that says which components it removed, not only how many dollars. That is
 * real work and it is not done.
 */
final class DeductedScopeBilling
{
    /**
     * @param  list<array{item_number: string, scheduled_value_cents: int, original_value_cents: int, deducted_cents: int, change_order_number: ?string, effective_at: ?string, this_period_cents: int, stored_materials_cents: int, previous_completed_cents: int, attribution: ?string}>  $lines
     * @return list<array{severity: string, code: string, message: string, citation: ?string, item_number: string, invalid_billed_cents: int}>
     */
    public static function findings(array $lines): array
    {
        $findings = [];

        foreach ($lines as $line) {
            $deducted = (int) ($line['deducted_cents'] ?? 0);
            if ($deducted <= 0) {
                continue;
            }

            $billedThisPeriod = (int) ($line['this_period_cents'] ?? 0) + (int) ($line['stored_materials_cents'] ?? 0);
            if ($billedThisPeriod <= 0) {
                continue;
            }

            $itemNumber = (string) ($line['item_number'] ?? '?');
            $order = $line['change_order_number'] === null ? 'an approved deductive change order'
                : 'Change Order '.$line['change_order_number'];

            // Nothing left to bill against. Certain, and no attribution needed.
            if ((int) ($line['scheduled_value_cents'] ?? 0) <= 0) {
                $findings[] = [
                    'severity' => PayApplicationReview::HARD_INVALID,
                    'code' => 'billing_against_deleted_scope',
                    'message' => 'Billing is included for scope deleted by '.$order.'. $'
                        .number_format($billedThisPeriod / 100, 2)
                        .' is being requested on line '.$itemNumber
                        .' after that scope was removed from the contract entirely. Remove the billing, or correct the change order and schedule-of-values authorization if the deduction is recorded wrongly.',
                    'citation' => null,
                    'item_number' => $itemNumber,
                    'invalid_billed_cents' => $billedThisPeriod,
                ];

                continue;
            }

            // Partial deduction, and the line still has headroom. We can see
            // that money is being billed on a line somebody cut. We cannot see
            // whether this particular money is the part that was cut.
            if (trim((string) ($line['attribution'] ?? '')) === '') {
                $findings[] = [
                    'severity' => PayApplicationReview::RETURNABLE,
                    'code' => 'billing_on_deducted_line_unattributed',
                    'message' => 'Line '.$itemNumber.' is billed $'.number_format($billedThisPeriod / 100, 2)
                        .' this period, and '.$order.' removed $'.number_format($deducted / 100, 2)
                        .' of scope from it. Cumulative billing is still within the reduced value, so this is not over-billing - but the record does not show which remaining scope this money is for. Record that, so the answer is on the application rather than in somebody\'s memory.',
                    'citation' => null,
                    'item_number' => $itemNumber,
                    // Deliberately zero. We are not asserting that any of it is
                    // invalid, and putting a number here would do exactly that.
                    'invalid_billed_cents' => 0,
                ];
            }
        }

        return $findings;
    }
}
