<?php

namespace App\Domain\Payment;

use App\Models\PayApplication;
use App\Models\Project;
use Illuminate\Support\Facades\DB;

/**
 * AUTO-2's third missing piece, per Codex's ruling on Amin's pay-app-automation
 * direction: a structured export of a pay application and its traced payment
 * history, for the customer's OWN accountant to process the invoice - not a
 * live accounting-system integration. Codex's own framing: "a financial
 * processing artifact, not a discovery dump."
 *
 * Two outputs from the SAME snapshot (`snapshot()`), so the CSV and the
 * document can never silently disagree with each other:
 *   - `toCsv()` - one row per schedule-of-values line, for accounting
 *     ingestion/workpapers.
 *   - `toDocument()` - a single self-contained HTML document (summary,
 *     application totals, SOV, CO reconciliation, retention/withholding
 *     summary, certification/submission state, export timestamp, and a
 *     document fingerprint) for review/filing.
 *
 * Why HTML and not a binary PDF: this codebase has no PDF-rendering
 * dependency, and `TransmittalComposer` already established the pattern for
 * a formal, printable, fingerprinted document in this codebase - a single
 * self-contained HTML file with no external fonts/scripts/images, servable
 * with `?format=html` and printable to PDF client-side exactly like a
 * transmittal. Introducing a binary PDF renderer would mean a system-level
 * dependency the existing deploy runbook (unzip a delta tarball, run
 * artisan commands) cannot install - a real infrastructure change, not a
 * decision this export should make unilaterally.
 *
 * What this deliberately does NOT include, per Codex's explicit exclusion
 * list:
 *   - employee-level certified-payroll PII (never collected on
 *     PayApplication/PayApplicationLine in the first place - certified
 *     payroll is supplied per-request to PayApplicationReview::findings()
 *     for review purposes only, and is not part of this snapshot);
 *   - internal TRACE/AI reasoning (not part of the pay-application domain
 *     model at all);
 *   - cured risk flags (PayApplicationReview::findings() is computed live
 *     against CURRENT state - a finding that was cured before submission
 *     simply does not appear, nothing needs to be filtered out here);
 *   - attorney material and unrelated project evidence (out of scope by
 *     construction - this snapshot only ever touches the one application,
 *     its lines, and change orders that touch those lines);
 *   - automation observations beyond a minimal trace reference - if this
 *     application's SHELL was system-created (PayAppRollforwardEvaluator),
 *     the export names that fact and the AutonomousAction id, not the
 *     internal evidence_used/proposed_change payload behind it.
 *   - change-order NUMBERS/references, when the caller does not independently
 *     hold `changeorder.view` - per Codex's finding, `payment.view` alone
 *     must not become a side channel around SEC-3's `changeorder.view` gate.
 *     The dollar delta a change order contributes stays either way (it is
 *     already implicit in the pay application's own math), only the CO
 *     identifier itself is redacted. See `$revealChangeOrderReferences`.
 */
final class PayApplicationAccountantExport
{
    /**
     * @return array<string,mixed>
     */
    public static function snapshot(
        PayApplication $application,
        Project $project,
        RetentionRule $retention,
        int $previouslyPaidCents,
        int $withheldCents,
        bool $revealChangeOrderReferences = true,
    ): array {
        $application->loadMissing('lines.item');
        $summary = PayApplicationMath::summarize($application, $previouslyPaidCents, $retention);

        $lines = [];
        foreach ($application->lines as $line) {
            $item = $line->item;
            if ($item === null) {
                continue;
            }

            $coRows = DB::table('change_order_allocations as a')
                ->join('change_orders as c', 'c.id', '=', 'a.change_order_id')
                ->where('c.tenant_id', $project->tenant_id)
                ->where('a.schedule_of_value_item_id', $item->id)
                ->where('c.status', 'approved')
                ->orderBy('c.number')
                ->get(['c.number as number', 'a.amount_cents as amount_cents']);

            $currentCompleted = (int) $line->previous_completed_cents + (int) $line->this_period_cents;

            $lines[] = [
                'sov_item_number' => (string) $item->item_number,
                'sov_description' => (string) $item->description,
                'original_value_cents' => (int) $item->original_value_cents,
                'approved_co_delta_cents' => (int) $coRows->sum('amount_cents'),
                'current_scheduled_value_cents' => (int) $item->scheduled_value_cents,
                'prior_completed_cents' => (int) $line->previous_completed_cents,
                'current_completed_cents' => $currentCompleted,
                'stored_materials_cents' => (int) $line->stored_materials_cents,
                'current_requested_amount_cents' => (int) $line->this_period_cents + (int) $line->stored_materials_cents,
                'cumulative_billed_cents' => $currentCompleted + (int) $line->stored_materials_cents,
                'balance_to_finish_cents' => (int) $item->scheduled_value_cents - $currentCompleted,
                // Codex's finding: a viewer who holds payment.view but not
                // changeorder.view must not receive CO numbers/identifiers
                // through this export as a side channel around SEC-3 - the
                // dollar delta above (already implicit in the pay app's own
                // math) stays either way, but the CO reference string is
                // redacted unless the caller has independently confirmed the
                // viewer can see change orders directly.
                'change_order_references' => $revealChangeOrderReferences
                    ? $coRows->pluck('number')->unique()->values()->implode(', ')
                    : null,
            ];
        }

        return [
            'project' => [
                'number' => (string) $project->number,
                'name' => (string) $project->name,
            ],
            'application' => [
                'number' => $application->number,
                'period_from' => $application->period_from?->toDateString(),
                'period_to' => $application->period_to?->toDateString(),
                'status' => $application->status,
                'certified_at' => $application->certified_at?->toIso8601String(),
                'submitted_at' => $application->submitted_at?->toIso8601String(),
            ],
            'totals' => [
                'scheduled_value_cents' => $summary['scheduled_value_cents'],
                'previous_completed_cents' => $summary['previous_completed_cents'],
                'this_period_cents' => $summary['this_period_cents'],
                'stored_materials_cents' => $summary['stored_materials_cents'],
                'total_completed_and_stored_cents' => $summary['total_completed_and_stored_cents'],
                'percent_complete_basis_points' => $summary['percent_complete_basis_points'],
                'retention_cents' => $summary['retention_cents'],
                'retention_source' => $summary['retention_source'],
                'retention_confirmed' => $summary['retention_confirmed'],
                'withholding_cents' => $withheldCents,
                'earned_less_retention_cents' => $summary['earned_less_retention_cents'],
                'previously_paid_cents' => $summary['previously_paid_cents'],
                'current_payment_due_cents' => $summary['current_payment_due_cents'],
            ],
            'lines' => $lines,
            // A minimal trace reference, not the internal evidence/reasoning
            // behind it - see the class doc's exclusion list.
            'trace' => [
                'created_by_automation' => $application->autonomous_action_id !== null,
                'autonomous_action_id' => $application->autonomous_action_id,
            ],
            'exported_at' => now()->toIso8601String(),
        ];
    }

    /**
     * One row per schedule-of-values line. Header/application/total fields
     * repeat on every row so the file is immediately usable in a
     * spreadsheet without a separate lookup - an accountant should not have
     * to join two sheets to answer "what is this row part of."
     */
    public static function toCsv(array $snapshot): string
    {
        $columns = [
            'project_number', 'project_name', 'pay_application_number', 'period_from', 'period_to',
            'sov_item_number', 'sov_description', 'original_value', 'approved_co_delta',
            'current_scheduled_value', 'prior_completed', 'current_completed', 'stored_materials',
            'current_requested_amount', 'cumulative_billed', 'balance_to_finish', 'change_order_references',
            'retention', 'withholding', 'current_payment_due',
        ];

        $out = fopen('php://memory', 'r+');
        fputcsv($out, $columns);

        $dollars = fn (int $cents) => number_format($cents / 100, 2, '.', '');

        // CSV/formula-injection guard: every free-text field here (project
        // number/name, SOV item number/description) is user-entered and
        // flows unmodified into a file this endpoint explicitly hands to an
        // accountant to open in Excel/Sheets. A value starting with
        // =, +, -, @, or the tab/CR characters Excel also treats as formula
        // triggers is interpreted as a formula on open (CWE-1236) - prefixing
        // it with a leading apostrophe neutralizes that while leaving the
        // value visibly unchanged for a human reader. Dollar amounts are
        // never touched; they are computed here, never user-supplied text.
        $csvSafe = function ($value) {
            $value = (string) $value;

            return preg_match('/^[=+\-@\t\r]/', $value) === 1 ? "'".$value : $value;
        };

        foreach ($snapshot['lines'] as $line) {
            fputcsv($out, [
                $csvSafe($snapshot['project']['number']),
                $csvSafe($snapshot['project']['name']),
                $snapshot['application']['number'],
                $snapshot['application']['period_from'],
                $snapshot['application']['period_to'],
                $csvSafe($line['sov_item_number']),
                $csvSafe($line['sov_description']),
                $dollars($line['original_value_cents']),
                $dollars($line['approved_co_delta_cents']),
                $dollars($line['current_scheduled_value_cents']),
                $dollars($line['prior_completed_cents']),
                $dollars($line['current_completed_cents']),
                $dollars($line['stored_materials_cents']),
                $dollars($line['current_requested_amount_cents']),
                $dollars($line['cumulative_billed_cents']),
                $dollars($line['balance_to_finish_cents']),
                $line['change_order_references'] === null ? 'restricted' : $csvSafe($line['change_order_references']),
                $dollars($snapshot['totals']['retention_cents']),
                $dollars($snapshot['totals']['withholding_cents']),
                $dollars($snapshot['totals']['current_payment_due_cents']),
            ]);
        }

        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);

        return (string) $csv;
    }

    /**
     * A single self-contained HTML document - summary, totals, the SOV
     * table, CO reconciliation, retention/withholding, certification state,
     * export timestamp, and a SHA-256 fingerprint over the rendered content
     * (same convention `TransmittalComposer` already uses, so a copy can be
     * proved to match what was exported).
     *
     * @return array{html:string, fingerprint:string}
     */
    public static function toDocument(array $snapshot): array
    {
        $e = fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $dollars = fn (int $cents) => '$'.number_format($cents / 100, 2);

        $rows = '';
        foreach ($snapshot['lines'] as $line) {
            $rows .= '<tr>'
                .'<td>'.$e($line['sov_item_number']).'</td>'
                .'<td>'.$e($line['sov_description']).'</td>'
                .'<td class="num">'.$e($dollars($line['original_value_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['approved_co_delta_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['current_scheduled_value_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['prior_completed_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['current_completed_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['stored_materials_cents'])).'</td>'
                .'<td class="num">'.$e($dollars($line['balance_to_finish_cents'])).'</td>'
                .'<td>'.$e($line['change_order_references'] === null ? 'restricted' : ($line['change_order_references'] ?: '—')).'</td>'
                .'</tr>';
        }

        $t = $snapshot['totals'];
        $a = $snapshot['application'];
        $p = $snapshot['project'];
        $trace = $snapshot['trace']['created_by_automation']
            ? 'This application was created automatically (AutonomousAction #'.$e($snapshot['trace']['autonomous_action_id']).').'
            : 'This application was created manually.';

        $html = '<!doctype html><html lang="en"><head><meta charset="utf-8">'
            .'<title>Pay Application '.$e($a['number']).' — Accountant Export</title><style>'
            .'html,body{margin:0;padding:24px;background:#fff;color:#14201f;font:13px/1.5 "Helvetica Neue",Arial,sans-serif}'
            .'h1{font-size:18px;margin:0 0 4px}h2{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#5c6a67;margin:20px 0 6px}'
            .'.sub{color:#66736f;font-size:12px;margin-bottom:16px}'
            .'table{width:100%;border-collapse:collapse;font-size:11.5px}'
            .'th,td{border:1px solid #dfe3e1;padding:5px 7px;text-align:left}th{background:#f6f7f6;font-size:10px;letter-spacing:.05em;text-transform:uppercase;color:#5c6a67}'
            .'.num{text-align:right;font-variant-numeric:tabular-nums}'
            .'.totals td{font-weight:600}'
            .'.foot{margin-top:20px;font-size:10px;color:#8a9391}'
            .'.fingerprint{font-family:ui-monospace,Menlo,Consolas,monospace;overflow-wrap:anywhere}'
            .'</style></head><body>'
            .'<h1>Pay Application '.$e($a['number']).' — '.$e($p['name']).' ('.$e($p['number']).')</h1>'
            .'<div class="sub">Period '.$e($a['period_from']).' to '.$e($a['period_to']).' · Status: '.$e($a['status'])
            .($a['certified_at'] ? ' · Certified '.$e($a['certified_at']) : '')
            .($a['submitted_at'] ? ' · Submitted '.$e($a['submitted_at']) : '').'</div>'
            .'<h2>Application totals</h2>'
            .'<table><tr><th>Scheduled value</th><th>Previously completed</th><th>This period</th>'
            .'<th>Stored materials</th><th>Total completed &amp; stored</th><th>% complete</th></tr>'
            .'<tr class="totals">'
            .'<td class="num">'.$e($dollars($t['scheduled_value_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['previous_completed_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['this_period_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['stored_materials_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['total_completed_and_stored_cents'])).'</td>'
            .'<td class="num">'.$e(number_format($t['percent_complete_basis_points'] / 100, 2)).'%</td>'
            .'</tr></table>'
            .'<h2>Retention, withholding &amp; amount due</h2>'
            .'<table><tr><th>Retention</th><th>Retention source</th><th>Withholding</th>'
            .'<th>Previously paid</th><th>Current payment due</th></tr>'
            .'<tr class="totals">'
            .'<td class="num">'.$e($dollars($t['retention_cents'])).'</td>'
            .'<td>'.$e($t['retention_source'] ?? '—').($t['retention_confirmed'] ? '' : ' (unconfirmed)').'</td>'
            .'<td class="num">'.$e($dollars($t['withholding_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['previously_paid_cents'])).'</td>'
            .'<td class="num">'.$e($dollars($t['current_payment_due_cents'])).'</td>'
            .'</tr></table>'
            .'<h2>Schedule of values &amp; change-order reconciliation</h2>'
            .'<table><tr><th>Item</th><th>Description</th><th>Original value</th><th>Approved CO delta</th>'
            .'<th>Current scheduled value</th><th>Prior completed</th><th>Current completed</th>'
            .'<th>Stored materials</th><th>Balance to finish</th><th>CO refs</th></tr>'
            .$rows
            .'</table>'
            .'<div class="foot">'.$e($trace).' Exported '.$e($snapshot['exported_at']).'.'
            .'<div class="fingerprint">DOCUMENT FINGERPRINT __FINGERPRINT__</div>'
            .'<div>Any copy of this document whose fingerprint differs from the one on ZecoCM\'s register is not the copy that was exported.</div>'
            .'</div>'
            .'</body></html>';

        $fingerprint = hash('sha256', $html);
        $html = str_replace('__FINGERPRINT__', $fingerprint, $html);

        return ['html' => $html, 'fingerprint' => $fingerprint];
    }
}
