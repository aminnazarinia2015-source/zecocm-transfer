<?php

namespace App\Domain\Payment;

use App\Models\ChangeOrder;
use App\Models\PayApplication;

/**
 * Exactly what was certified.
 *
 * A signature on a document that can still change is not a signature. This is
 * the fingerprint of the financial content at the moment somebody put their name
 * to it, and it covers every number a change to which would alter what was
 * being certified - the billing period, the retention rate, and each line's
 * billed, stored, pending-change and adjustment values.
 *
 * Deliberately NOT covered: notes, reasons, and anything that cannot move money.
 * A certifier who has to re-sign because a typo was fixed in a comment learns to
 * re-sign without reading, and then the control is worse than nothing.
 *
 * THE HOLES I FOUND BY ATTACKING THE FIRST VERSION. It hashed only what is
 * typed on the application, which meant a certification could survive changes
 * that moved the amount due without touching a single billed number:
 *
 *   The governing retention rule lives on the project. Edit the rate from 5% to
 *   3% after certification and the withholding falls by two points of the whole
 *   contract - nothing on the application moved, and the signature stood.
 *
 *   Previously paid value is derived from the other applications on the project.
 *   Mark an earlier application paid, or unpaid, and the current payment due
 *   changes underneath a certification that named a different figure.
 *
 * Both are now inside the hash, which means the hash can change without anybody
 * editing THIS application. That is the correct behaviour and not a side effect:
 * if the amount being requested has moved, the person who signed for the old
 * amount has not seen the new one.
 *
 * AND THE ONE CODEX FOUND, which is subtler and worse, because the money does
 * not move at all. A line reading
 *
 *     original $100,000 + approved change order $20,000 = current $120,000
 *
 * can be rewritten after certification to
 *
 *     original $120,000 + approved change orders $0    = current $120,000
 *
 * Identical dollars. Completely different contractual authorization - the
 * second version claims the work was always in the contract, and the change
 * order that actually authorized it has vanished. A certification that survives
 * that has been applied to a different assertion.
 *
 * So the split is hashed, not just the total. And change orders are identified
 * by their financial identity rather than by their row id: somebody editing
 * CO-12 from +$20,000 to +$30,000 must invalidate every dependent
 * certification even though the id stayed 12.
 *
 * The principle, which is Codex's and is the right one to hold: anything whose
 * change could alter entitlement, authorization, or the meaning of the amount
 * requested belongs in this hash, even when today's dollar total does not move.
 */
final class ApplicationContentHash
{
    public static function of(PayApplication $application, ?RetentionRule $retention = null, int $previouslyPaidCents = 0): string
    {
        $application->loadMissing('lines.item');

        $material = [
            'period_from' => $application->period_from?->toDateString(),
            'period_to' => $application->period_to?->toDateString(),
            'retention_basis_points' => (int) $application->retention_basis_points,
            // The rule actually in force, not just the rate typed on the
            // application. These live on the project and can move without
            // anything here being touched.
            // The rule's identity, not only its rate. Two rules can both read 5%
            // and differ materially on stored materials, on reductions after a
            // completion threshold, and on which authority they come from.
            'retention_rule' => $retention === null ? null : [
                'basis_points' => $retention->basisPoints,
                'source' => $retention->source,
                'applies_to_stored_materials' => $retention->appliesToStoredMaterials,
                'stored_materials_source' => $retention->storedMaterialsSource,
                'confirmed' => $retention->confirmed,
            ],
            // Derived from the other applications on this project.
            'previously_paid_cents' => $previouslyPaidCents,
            'lines' => [],
        ];

        // Change orders by financial identity, not by row id.
        $material['approved_change_orders'] = ChangeOrder::query()
            ->where('project_id', $application->project_id)
            ->orderBy('id')
            ->get(['id', 'number', 'amount_cents', 'status', 'approved_at'])
            ->map(fn ($order) => [
                'id' => (int) $order->id,
                'number' => (string) $order->number,
                'amount_cents' => (int) $order->amount_cents,
                'status' => (string) $order->status,
                'approved_at' => $order->approved_at?->toIso8601String(),
            ])->all();

        foreach ($application->lines->sortBy('schedule_of_value_item_id') as $line) {
            $material['lines'][] = [
                'item' => (int) $line->schedule_of_value_item_id,
                'previous_completed_cents' => (int) $line->previous_completed_cents,
                'this_period_cents' => (int) $line->this_period_cents,
                'stored_materials_cents' => (int) $line->stored_materials_cents,
                'pending_change_value_cents' => (int) $line->pending_change_value_cents,
                'stored_material_adjustment_cents' => (int) $line->stored_material_adjustment_cents,
                // The scheduled value is the authorization the billing sits
                // against. A change order that moves it changes what is being
                // certified even when no billed number moves.
                'scheduled_value_cents' => (int) ($line->item?->scheduled_value_cents ?? 0),
                // The SPLIT, not just the total. Moving value from a change
                // order into the original leaves the dollars identical and the
                // authorization rewritten.
                'original_value_cents' => (int) ($line->item?->original_value_cents ?? 0),
                'change_order_id' => $line->item?->change_order_id === null
                    ? null : (int) $line->item->change_order_id,
            ];
        }

        return hash('sha256', json_encode($material, JSON_THROW_ON_ERROR));
    }
}
