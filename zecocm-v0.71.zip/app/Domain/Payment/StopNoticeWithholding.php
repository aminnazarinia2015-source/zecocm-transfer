<?php

namespace App\Domain\Payment;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * Money a served stop payment notice freezes in the owner's hands.
 *
 * A stop payment notice is not a deduction and not a dispute. On a California
 * public work, Civil Code s. 9358 directs the public entity to withhold from
 * money due the contractor an amount sufficient to answer the claim and to
 * provide for the public entity's costs - which the statute puts at 125 per
 * cent of the claim. The money does not become the claimant's. It does not stop
 * being owed to the contractor. It stops moving.
 *
 * Four things this class refuses to do, each of them a way real systems have
 * lost real money:
 *
 *   IT NEVER NETS A NOTICE AGAINST A RELEASE. A release says a claimant is no
 *   longer owed; a notice says do not pay. They are separate facts about
 *   separate parties and summing them pays somebody twice.
 *
 *   IT NEVER DECIDES A NOTICE IS INVALID. A claimant with no preliminary notice
 *   on file may well have no valid stop notice - Civil Code s. 9300 - but that
 *   is a legal determination. This flags the gap and keeps withholding. An
 *   owner who releases frozen money because software said the notice looked bad
 *   has assumed the liability personally.
 *
 *   IT NEVER ROUNDS THE WITHHOLDING DOWN. Under-withholding by a cent is the
 *   owner's exposure, not the claimant's, so the 125 per cent computation
 *   rounds up.
 *
 *   IT NEVER TREATS A RELEASE BOND AS FILED BECAUSE SOMEBODY SAID SO. Under
 *   s. 9364 a bond in 125 per cent of the claim frees the funds. The bond is
 *   a document; until it is on file the funds stay frozen.
 */
final class StopNoticeWithholding
{
    /** Civil Code s. 9358 - claim plus provision for the entity's costs. */
    public const WITHHOLD_BASIS_POINTS = 12_500;

    public const OPEN = 'open';
    public const RELEASED = 'released';
    public const BONDED_AROUND = 'bonded_around';
    public const WITHDRAWN = 'withdrawn';
    public const FORFEITED = 'forfeited';

    /** Service is a statutory act, not the fact that something was sent. */
    public const SERVICE_CONFIRMED = 'confirmed';
    public const SERVICE_UNRESOLVED = 'unresolved';

    /**
     * The statutory withholding for one claim, rounded up to the cent.
     */
    public static function amountFor(int $claimCents): int
    {
        if ($claimCents <= 0) {
            return 0;
        }

        return intdiv($claimCents * self::WITHHOLD_BASIS_POINTS + 9_999, 10_000);
    }

    /**
     * @param  list<array<string,mixed>>  $notices
     * @return array{total_withheld_cents: int, active: list<array<string,mixed>>, findings: list<array<string,mixed>>}
     */
    public static function required(array $notices, ?DateTimeInterface $asOf = null): array
    {
        $asOf ??= new DateTimeImmutable('today');
        $total = 0;
        $active = [];
        $findings = [];

        foreach ($notices as $notice) {
            $claimant = (string) ($notice['claimant_name'] ?? 'an unnamed claimant');
            $claim = (int) ($notice['claimed_amount_cents'] ?? 0);
            $status = (string) ($notice['status'] ?? self::OPEN);
            $served = self::date($notice['served_on'] ?? null);

            if ($status === self::BONDED_AROUND && ! ($notice['release_bond_on_file'] ?? false)) {
                // The single most expensive optimism in this whole area: the
                // bond was promised, the funds were released, and the bond
                // never arrived.
                $withheld = self::amountFor($claim);
                $total += $withheld;
                $active[] = self::row($notice, $withheld, 'bond_not_on_file');
                $findings[] = self::finding('stop_notice_release_bond_not_on_file',
                    'The stop payment notice from '.$claimant.' is marked as bonded around, but no release bond is on file. '
                    .'Until the bond document is in the record the funds are still frozen - $'
                    .number_format($withheld / 100, 2).' remains withheld.',
                    'Civil Code s. 9364');

                continue;
            }

            if ($status !== self::OPEN) {
                continue;
            }

            if ($claim <= 0) {
                $findings[] = self::finding('stop_notice_amount_not_recorded',
                    'A stop payment notice from '.$claimant.' is recorded with no claimed amount, so the amount to withhold '
                    .'cannot be computed. The notice has been served; the withholding obligation does not wait on our data entry.',
                    'Civil Code s. 9358');
                $active[] = self::row($notice, 0, 'amount_unknown');

                continue;
            }

            $withheld = self::amountFor($claim);
            $total += $withheld;

            $flag = null;

            // Civil Code s. 9300: a claimant with no direct contract with the
            // public entity must have given preliminary notice. Recorded as a
            // gap in the file, never as a conclusion about the notice.
            if (! ($notice['preliminary_notice_on_file'] ?? false)
                && ($notice['claimant_role'] ?? null) !== 'prime_contractor') {
                $flag = 'preliminary_notice_not_evidenced';
                $findings[] = self::finding('stop_notice_prerequisite_not_evidenced',
                    'No preliminary notice is on file for the stop payment notice from '.$claimant
                    .'. Whether that defeats the claim is a legal determination and not one this system makes - '
                    .'the funds stay withheld. Raise it with counsel before anything is released.',
                    'Civil Code s. 9300');
            }

            // Codex's attack, and it is the one most likely to be believed by
            // a PM: emailing the project inspector is evidence that an email
            // was sent. Civil Code s. 9300 et seq. names who must actually
            // receive a stop payment notice on a public work - for a non-state
            // entity, the controller, auditor or disbursing officer. The
            // software records what was done and refuses to conclude that
            // statutory service occurred.
            if (($notice['service_effectiveness'] ?? self::SERVICE_UNRESOLVED) !== self::SERVICE_CONFIRMED) {
                $findings[] = self::finding('stop_notice_service_unresolved',
                    'The stop payment notice from '.$claimant.' is recorded as '
                    .str_replace('_', ' ', (string) ($notice['service_state'] ?? 'prepared'))
                    .', and whether it reached the officer the statute names has not been established'
                    .(($notice['served_to_role'] ?? null) ? ' (recorded recipient: '.$notice['served_to_role'].')' : '')
                    .'. Sending is not serving. The funds stay withheld either way - a notice whose service is unresolved is not a notice this software may treat as ineffective.',
                    'Civil Code s. 9300');
                $flag ??= 'service_unresolved';
            }

            $findings[] = self::finding('stop_notice_withholding_required',
                'A stop payment notice from '.$claimant.' for $'.number_format($claim / 100, 2)
                .($served !== null ? ', served '.$served->format('j M Y') : '')
                .', requires $'.number_format($withheld / 100, 2).' to be withheld - the claim plus 25 per cent for the '
                .'public entity\'s costs. The money remains owed to the contractor and remains unpayable until the notice is resolved.',
                'Civil Code s. 9358');

            $active[] = self::row($notice, $withheld, $flag);
        }

        return ['total_withheld_cents' => $total, 'active' => $active, 'findings' => $findings];
    }

    /**
     * What is actually payable once served notices are accounted for.
     *
     * Returned as a separate figure rather than folded into the application
     * total: the contractor is still owed the whole amount, and a system that
     * silently reduces the earned figure has misstated the contract.
     *
     * @return array{earned_cents: int, frozen_cents: int, payable_cents: int, fully_frozen: bool}
     */
    public static function payable(int $earnedCents, int $frozenCents): array
    {
        $payable = max(0, $earnedCents - $frozenCents);

        return [
            'earned_cents' => $earnedCents,
            'frozen_cents' => $frozenCents,
            'payable_cents' => $payable,
            // Worth naming: when notices exceed the payment, nothing goes out at
            // all, and the contractor learns that from a zero rather than from a
            // reduced cheque.
            'fully_frozen' => $earnedCents > 0 && $payable === 0,
        ];
    }

    private static function row(array $notice, int $withheld, ?string $flag): array
    {
        return [
            'claimant_name' => (string) ($notice['claimant_name'] ?? ''),
            'claimed_amount_cents' => (int) ($notice['claimed_amount_cents'] ?? 0),
            'withhold_cents' => $withheld,
            'served_on' => $notice['served_on'] ?? null,
            'service_state' => $notice['service_state'] ?? 'prepared',
            'service_effectiveness' => $notice['service_effectiveness'] ?? self::SERVICE_UNRESOLVED,
            'flag' => $flag,
        ];
    }

    private static function finding(string $code, string $message, ?string $citation): array
    {
        return [
            'severity' => PayApplicationReview::WITHHOLD,
            'code' => $code,
            'message' => $message,
            'citation' => $citation,
            'gate' => 'internal',
        ];
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof DateTimeInterface) {
            return new DateTimeImmutable($value->format('Y-m-d'));
        }

        try {
            return new DateTimeImmutable((string) $value);
        } catch (\Exception) {
            return null;
        }
    }
}
