<?php

namespace App\Domain\Payment;

/**
 * What the person signing this is actually certifying, and what we are not.
 *
 * The problem Codex named: a green validator reads as "this invoice is true".
 * It is not. Three different assertions live under a pay application and only
 * two of them can be checked from inside a database -
 *
 *   mathematically valid      arithmetic, reconciliation, retention.
 *   contractually authorized  against the schedule of values and approved
 *                             change orders as recorded.
 *   factually substantiated   whether the work is actually in the ground.
 *
 * The third one needs a person who went and looked. Software that lets its
 * silence on the third be mistaken for a finding on it has done something worse
 * than miss a defect: it has lent its credibility to a representation it never
 * examined, on a document that is a certified claim for public money.
 *
 * So the statement says both halves out loud, and the second half is not
 * softened. Text below is final copy and goes on the screen verbatim.
 */
final class CertificationStatement
{
    public const VERSION = '2026-08-25.1';

    public const OPENING = 'I certify that, to the best of my knowledge, this pay application accurately states the amount being requested for work performed, eligible materials, and approved changes through the billing period shown.';

    /** @var list<string> */
    public const CHECKED = [
        'the mathematical consistency of this application;',
        'the amounts previously certified and paid as recorded in ZecoCM;',
        'the current Schedule of Values and approved change-order adjustments recorded in ZecoCM;',
        'retention and stored-material calculations; and',
        'recorded billing conflicts, including duplicate, unauthorized, unreconciled, or unsupported billing conditions that the system is designed to detect.',
    ];

    /** @var list<string> */
    public const NOT_VERIFIED = [
        'that the reported percentage of work is physically complete;',
        'that stated quantities were actually installed;',
        'that stored materials physically exist, remain eligible, or are in acceptable condition;',
        'that every invoice, ticket, field record, or other supporting document is factually accurate; or',
        'that every factual representation in this application is true.',
    ];

    public const CLOSING = 'I remain responsible for confirming that the work, materials, quantities, and supporting facts represented in this pay application are accurate and properly payable.';

    /** @return array<string,mixed> */
    public static function toArray(): array
    {
        return [
            'version' => self::VERSION,
            'opening' => self::OPENING,
            'checked_heading' => 'ZecoCM checked:',
            'checked' => self::CHECKED,
            'not_verified_heading' => 'ZecoCM did not independently verify:',
            'not_verified' => self::NOT_VERIFIED,
            'closing' => self::CLOSING,
        ];
    }

    public static function text(): string
    {
        return self::OPENING."\n\nZecoCM checked:\n- ".implode("\n- ", self::CHECKED)
            ."\n\nZecoCM did not independently verify:\n- ".implode("\n- ", self::NOT_VERIFIED)
            ."\n\n".self::CLOSING;
    }
}
