<?php

namespace App\Domain\Payment;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * Whether the releases on file actually cover what has been paid.
 *
 * The commonest failure in a payment file is not a missing release. It is a
 * release that is present, signed, filed, and covers the wrong thing - and
 * nobody notices, because at a glance a signed release looks like a signed
 * release. Three ways that happens, all of them recorded here as distinct
 * states rather than as one "has release" boolean:
 *
 *   1. CONDITIONAL, UNSATISFIED. A conditional release (Civil Code s. 8132 for
 *      progress, s. 8136 for final) takes effect only if the payment it is
 *      given for actually clears. Until the funds clear it is a promise. A file
 *      full of conditional releases against payments nobody confirmed cleared
 *      is a file full of promises, and the claimant's lien rights are intact.
 *
 *   2. DOES NOT REACH THE PERIOD. A release runs THROUGH A DATE. A release
 *      through 31 July does not cover August work no matter what dollar figure
 *      is written on it. This is the one that gets missed, because the amount
 *      usually looks right.
 *
 *   3. EXCEPTED. The claimant wrote disputed amounts into the exceptions box.
 *      Those are expressly NOT released, and a system that reports the release
 *      as covering the period is reporting the opposite of what the paper says.
 *
 * What this class will not do: decide that a claimant's lien rights are gone.
 * It reports what the file supports and what it does not. Release effectiveness
 * against a particular claim is a legal determination.
 */
final class ReleaseCoverage
{
    public const EFFECTIVE = 'effective';
    public const CONDITIONAL_UNSATISFIED = 'conditional_unsatisfied';
    /**
     * The cheque cleared for less than the release names.
     *
     * Codex's first attack on this class, and it was right: the statutory
     * conditional form is effective on receipt of THE PAYMENT IDENTIFIED IN IT.
     * Treating "a payment cleared" as satisfying a release for a larger amount
     * manufactures a legal conclusion the form itself does not support.
     */
    public const CONDITIONAL_UNDERPAID = 'conditional_underpaid';
    public const DOES_NOT_REACH_PERIOD = 'does_not_reach_period';
    public const NO_THROUGH_DATE = 'no_through_date';
    public const NOT_ON_FILE = 'not_on_file';

    public const CONDITIONAL_FORMS = ['conditional_progress', 'conditional_final'];
    public const FINAL_FORMS = ['conditional_final', 'unconditional_final'];

    /** Civil Code section each statutory form comes from. */
    public const CITATIONS = [
        'conditional_progress' => 'Civil Code s. 8132',
        'unconditional_progress' => 'Civil Code s. 8134',
        'conditional_final' => 'Civil Code s. 8136',
        'unconditional_final' => 'Civil Code s. 8138',
    ];

    /**
     * @param  array{form_type: string, through_date?: mixed, document_on_file?: bool, payment_cleared_on?: mixed, exceptions_stated?: bool}  $release
     * @return array{state: string, conditional: bool, covers_through: ?string, excepted: bool, message: string, citation: ?string}
     */
    public static function stateOf(array $release, DateTimeInterface $periodEnd): array
    {
        $form = (string) ($release['form_type'] ?? '');
        $conditional = in_array($form, self::CONDITIONAL_FORMS, true);
        $citation = self::CITATIONS[$form] ?? null;
        $excepted = (bool) ($release['exceptions_stated'] ?? false);
        $through = self::date($release['through_date'] ?? null);
        $throughLabel = $through?->format('Y-m-d');

        $out = function (string $state, string $message) use ($conditional, $throughLabel, $excepted, $citation) {
            return ['state' => $state, 'conditional' => $conditional, 'covers_through' => $throughLabel,
                'excepted' => $excepted, 'message' => $message, 'citation' => $citation];
        };

        // A form nobody has the paper for is a data entry, not a release. The
        // distinction matters the day somebody has to produce it.
        if (! ($release['document_on_file'] ?? false)) {
            return $out(self::NOT_ON_FILE,
                'A '.self::label($form).' is recorded for '.($release['claimant_name'] ?? 'this claimant')
                .' but the signed document is not on file. Nothing can be produced against a claim.');
        }

        // A release with no through date cannot be shown to cover any particular
        // period. Assuming it covers the period it was filed under is exactly
        // the assumption that fails in a dispute.
        if ($through === null) {
            return $out(self::NO_THROUGH_DATE,
                'This '.self::label($form).' records no through date, so the period it covers cannot be established from the record.');
        }

        if ($through < self::atMidnight($periodEnd)) {
            return $out(self::DOES_NOT_REACH_PERIOD,
                'This '.self::label($form).' runs through '.$through->format('j M Y')
                .', which is before the end of the period being considered ('.$periodEnd->format('j M Y')
                .'). Work performed after '.$through->format('j M Y').' is not released by it, whatever amount appears on its face.');
        }

        if ($conditional) {
            if (self::date($release['payment_cleared_on'] ?? null) === null) {
                return $out(self::CONDITIONAL_UNSATISFIED,
                    'This '.self::label($form).' is conditional on payment, and no evidence that the payment cleared is recorded. '
                    .'Until it does, the release has not taken effect and the claimant\'s rights are unaffected.');
            }

            // The amount, not merely the fact. A conditional release naming
            // $100,000 against which $80,000 cleared is satisfied as to
            // $80,000 and as to nothing else.
            $named = (int) ($release['amount_cents'] ?? 0);
            $cleared = $release['payment_cleared_amount_cents'] ?? null;

            if ($named > 0 && $cleared !== null && (int) $cleared < $named) {
                return $out(self::CONDITIONAL_UNDERPAID,
                    'This '.self::label($form).' names $'.number_format($named / 100, 2)
                    .' and the payment recorded as cleared is $'.number_format((int) $cleared / 100, 2)
                    .'. A conditional release takes effect on receipt of the payment identified in it, so it is satisfied as to what was paid and as to nothing more. $'
                    .number_format(($named - (int) $cleared) / 100, 2).' remains unreleased.');
            }
        }

        return $out(self::EFFECTIVE,
            'A '.self::label($form).' is on file through '.$through->format('j M Y')
            .($conditional ? ', and the payment it is conditioned on is recorded as cleared.' : '.')
            .($excepted ? ' Amounts written into its exceptions are expressly NOT released.' : ''));
    }

    /**
     * Findings for a pay application: does the file support paying this one?
     *
     * The convention this encodes is the one owners actually run: an
     * unconditional release covering the LAST paid period, plus a conditional
     * release for the period now being paid. Asking for an unconditional
     * release for money not yet paid asks the claimant to give up rights for
     * nothing, which is why the two forms exist.
     *
     * @param  list<array<string,mixed>>  $releases
     * @param  array<string,mixed>  $context  requires: period_end. Optional:
     *   prior_period_end, required_claimants (list of names), payment_is_final
     * @return list<array<string,mixed>>
     */
    public static function findings(array $releases, array $context = []): array
    {
        $periodEnd = self::date($context['period_end'] ?? null);
        if ($periodEnd === null) {
            return [];
        }

        $priorEnd = self::date($context['prior_period_end'] ?? null);
        $final = (bool) ($context['payment_is_final'] ?? false);
        $required = array_values(array_filter(array_map('strval', (array) ($context['required_claimants'] ?? []))));
        $findings = [];

        $byClaimant = [];
        foreach ($releases as $release) {
            $byClaimant[(string) ($release['claimant_name'] ?? '')][] = $release;
        }

        foreach ($required as $claimant) {
            $theirs = $byClaimant[$claimant] ?? [];

            if ($theirs === []) {
                $findings[] = self::finding('release_absent',
                    'No waiver and release of any kind is on file for '.$claimant
                    .'. Paying without one leaves the claimant\'s stop notice and payment bond rights intact against money already paid out.',
                    null, $claimant);

                continue;
            }

            // The last paid period is the one an UNCONDITIONAL release should
            // exist for. Anything still conditional back there means money went
            // out and nothing came back that has taken effect.
            if ($priorEnd !== null) {
                $settled = array_filter($theirs, function ($r) use ($priorEnd) {
                    $state = self::stateOf($r, $priorEnd);

                    return $state['state'] === self::EFFECTIVE && ! in_array($r['form_type'] ?? '', self::CONDITIONAL_FORMS, true);
                });

                if ($settled === []) {
                    $conditionalHeld = array_filter($theirs, fn ($r) => in_array($r['form_type'] ?? '', self::CONDITIONAL_FORMS, true));

                    $findings[] = self::finding('unconditional_release_missing_for_paid_period',
                        $claimant.' has been paid through '.$priorEnd->format('j M Y')
                        .' and no unconditional release covering that period is on file.'
                        .($conditionalHeld !== []
                            ? ' A conditional release is held, but a conditional release for money already paid is only as good as the recorded evidence that the payment cleared.'
                            : ''),
                        'Civil Code s. 8134', $claimant);
                }
            }

            // And for the period now being paid.
            $covering = null;
            foreach ($theirs as $release) {
                $state = self::stateOf($release, $periodEnd);
                if ($state['state'] === self::EFFECTIVE) {
                    $covering = $state;
                    break;
                }
                $covering ??= $state;
                // Prefer reporting the most informative failure over the first one.
                if (in_array($state['state'], [self::CONDITIONAL_UNSATISFIED, self::CONDITIONAL_UNDERPAID], true)) {
                    $covering = $state;
                }
            }

            if ($covering !== null && $covering['state'] !== self::EFFECTIVE) {
                $findings[] = self::finding(match ($covering['state']) {
                    self::DOES_NOT_REACH_PERIOD => 'release_does_not_cover_period',
                    self::CONDITIONAL_UNSATISFIED => 'conditional_release_unsatisfied',
                    self::CONDITIONAL_UNDERPAID => 'conditional_release_underpaid',
                    self::NO_THROUGH_DATE => 'release_has_no_through_date',
                    default => 'release_document_not_on_file',
                }, $claimant.': '.$covering['message'], $covering['citation'], $claimant);
            }

            if ($final) {
                $unconditionalFinal = array_filter($theirs, fn ($r) => ($r['form_type'] ?? '') === 'unconditional_final'
                    && ($r['document_on_file'] ?? false));

                if ($unconditionalFinal === []) {
                    $findings[] = self::finding('final_release_missing',
                        'This is a final payment and no unconditional waiver and release on final payment is on file for '
                        .$claimant.'. Retention released without it goes out with the claim rights still live.',
                        'Civil Code s. 8138', $claimant);
                }
            }

            foreach ($theirs as $release) {
                if (($release['exceptions_stated'] ?? false) && ($release['document_on_file'] ?? false)) {
                    $structured = (bool) ($release['exceptions_structured'] ?? false);

                    $findings[] = self::finding(
                        $structured ? 'release_states_exceptions' : 'release_exceptions_unstructured',
                        $claimant.' wrote exceptions into a '.self::label((string) $release['form_type'])
                        .'. Amounts in the exceptions box are expressly NOT released, so this release does not close them out: '
                        .trim((string) ($release['exceptions'] ?? 'no text recorded'))
                        .($structured ? '' : ' These exceptions have not been broken out into addressable items, so ZecoCM cannot say whether any PARTICULAR claim, change order or retention amount survives this release. It will not guess: until a person itemises them, treat nothing as released by it.'),
                        self::CITATIONS[$release['form_type'] ?? ''] ?? null, $claimant);
                }
            }
        }

        return $findings;
    }

    private static function finding(string $code, string $message, ?string $citation, string $claimant): array
    {
        return [
            // A release problem does not make the payment request improper under
            // Public Contract Code s. 20104.50 - it is the owner's own exposure.
            // Calling it returnable would start the wrong clock.
            'severity' => PayApplicationReview::WITHHOLD,
            'code' => $code,
            'message' => $message,
            'citation' => $citation,
            'gate' => 'internal',
            'claimant' => $claimant,
        ];
    }

    public static function label(string $form): string
    {
        return match ($form) {
            'conditional_progress' => 'conditional waiver and release on progress payment',
            'unconditional_progress' => 'unconditional waiver and release on progress payment',
            'conditional_final' => 'conditional waiver and release on final payment',
            'unconditional_final' => 'unconditional waiver and release on final payment',
            default => 'waiver and release',
        };
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($value instanceof DateTimeInterface) {
            return self::atMidnight($value);
        }

        try {
            return new DateTimeImmutable(((string) $value).' 00:00:00');
        } catch (\Exception) {
            return null;
        }
    }

    private static function atMidnight(DateTimeInterface $d): DateTimeImmutable
    {
        return new DateTimeImmutable($d->format('Y-m-d').' 00:00:00');
    }
}
