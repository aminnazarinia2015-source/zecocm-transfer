<?php

namespace App\Domain\Payment;

use App\Models\PaymentSubmissionRule;

/**
 * What the submit control is allowed to say.
 *
 * A returnable defect is not a fact about the finding. It is a fact about the
 * contract, and different agencies answer it differently on identical
 * paperwork: one processes a payment request with the schedule update missing,
 * the next returns it unprocessed. So the state of the button is resolved from a
 * governing rule recorded against the project, or it is not resolved at all.
 *
 * The third state is the one that matters. An unknown rule must not silently
 * become the permissive one - "we have no rule on file, so go ahead" is the
 * software telling the user something about the agency that nobody established.
 * It says it does not know, and it says which finding it does not know about.
 */
final class SubmissionPolicy
{
    public const HARD_INVALID = 'hard_invalid';
    public const RETURNABLE_BLOCKING = 'returnable_blocking';
    public const RETURNABLE_PERMITTED = 'returnable_permitted';
    public const WITHHOLD_ONLY = 'withhold_only';
    public const WARNING = 'warning';

    public const CONFIRMED = 'confirmed';
    public const UNRESOLVED = 'unresolved';

    /**
     * The state of the primary control, and the words on it.
     *
     * @param  list<array{severity: string, code: string, message: string, citation: ?string}>  $findings
     * @param  array<string,array{submission_effect: string, status: string, source_citation: string}>  $rules  keyed by finding code
     * @return array{state: string, control: string, submittable: bool, unresolved_codes: list<string>, blocking_codes: list<string>}
     */
    public static function resolve(array $findings, array $rules): array
    {
        $blocking = [];
        $unresolved = [];
        $returnable = [];

        foreach ($findings as $finding) {
            if ($finding['severity'] === PayApplicationReview::HARD_INVALID) {
                $blocking[] = $finding['code'];

                continue;
            }

            if ($finding['severity'] !== PayApplicationReview::RETURNABLE) {
                continue;
            }

            // Only the agency's questions are resolved against the agency's
            // rules. An internal readiness warning is shown and never gates.
            if (($finding['gate'] ?? 'internal') !== 'agency') {
                continue;
            }

            $rule = $rules[$finding['code']] ?? null;
            $returnable[] = $finding['code'];

            if ($rule === null || ($rule['status'] ?? self::UNRESOLVED) !== self::CONFIRMED) {
                $unresolved[] = $finding['code'];

                continue;
            }

            if (($rule['submission_effect'] ?? null) === self::RETURNABLE_BLOCKING) {
                $blocking[] = $finding['code'];
            }
        }

        // A structural defect outranks everything. No payment clock would start.
        if ($blocking !== []) {
            return self::state('cannot_submit', 'Correct Submission Errors', false, $unresolved, $blocking);
        }

        // We know of a returnable defect and we do not know what this agency does
        // with it. Saying "Submit With Outstanding Items" would be asserting a
        // permission nobody granted.
        if ($unresolved !== []) {
            return self::state('requirement_unresolved', 'Review Submission Requirement', false, $unresolved, []);
        }

        if ($returnable !== []) {
            return self::state('returnable_permitted', 'Submit With Outstanding Items', true, [], []);
        }

        return self::state('clean', 'Submit Pay Application', true, [], []);
    }

    /** @return array<string,array{submission_effect: string, status: string, source_citation: string}> */
    public static function rulesForProject(int $projectId): array
    {
        $rules = [];
        foreach (PaymentSubmissionRule::query()->where('project_id', $projectId)->get() as $rule) {
            $rules[$rule->finding_code] = [
                'submission_effect' => $rule->submission_effect,
                'status' => $rule->status,
                'source_citation' => $rule->source_citation,
            ];
        }

        return $rules;
    }

    private static function state(string $state, string $control, bool $submittable, array $unresolved, array $blocking): array
    {
        return ['state' => $state, 'control' => $control, 'submittable' => $submittable,
            'unresolved_codes' => array_values(array_unique($unresolved)),
            'blocking_codes' => array_values(array_unique($blocking))];
    }
}
