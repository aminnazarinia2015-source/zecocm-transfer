<?php

namespace App\Domain\Payment;

use App\Domain\Compliance\CertifiedPayrollCheck;
use App\Models\PayApplication;

/**
 * Why a payment application gets bounced, sorted by what bouncing it means.
 *
 * Codex's distinction, and it is a legal one rather than a UX one. Under
 * California Public Contract Code section 20104.50 an agency must return an
 * IMPROPER payment request with written reasons within seven days; an otherwise
 * proper and undisputed request starts the thirty-day payment clock. So whether a
 * problem makes the request improper, merely returnable, or simply reduces the
 * amount, decides which clock is running - and a contractor who thinks the
 * thirty-day clock started when it did not will wait a month for money that was
 * never coming.
 *
 *   HARD_INVALID  the request is structurally improper. Do not submit it. No
 *                 payment clock starts.
 *   RETURNABLE    the agency can return it as not a proper request. Fixable, but
 *                 it costs a cycle if it goes out like this.
 *   WITHHOLD      the request may be perfectly proper; the amount is reduced or
 *                 held for a separate compliance or performance reason.
 *
 * The list below is the one agencies actually use, not the three obvious checks.
 */
final class PayApplicationReview
{
    public const HARD_INVALID = 'hard_invalid';
    public const RETURNABLE = 'returnable';
    public const WITHHOLD = 'withhold';

    /**
     * @param  array<string,mixed>  $context  optional cross-checks the caller can supply:
     *   original_contract_cents, approved_change_orders_cents, current_contract_cents,
     *   prior_certified_paid_cents, previous_application_completed_cents,
     *   unapproved_change_order_line_numbers, stored_material_line_numbers_without_evidence,
     *   stored_material_line_numbers_without_sov,
     *   certified_payroll => ['records' => [...], 'determinations' => [...], 'context' => [...]]
     * @return list<array{severity: string, code: string, message: string, citation: ?string}>
     */
    public static function findings(
        PayApplication $application,
        ?RetentionRule $retention = null,
        array $context = [],
    ): array {
        $summary = PayApplicationMath::summarize($application);
        $findings = [];

        // gate: whose question is this?
        //
        //   agency   - a completeness item the awarding body may bounce the
        //              package for. Whether it actually does is contract-
        //              specific, so it is resolved against the project's
        //              governing rules before the submit control is drawn.
        //   internal - our own readiness warning. A retention rate nobody has
        //              confirmed is worth saying loudly and is not something an
        //              agency returns a payment request over. Gating submission
        //              on it would be this software inventing a rule.
        $add = function (string $severity, string $code, string $message, ?string $citation = null, string $gate = 'internal') use (&$findings) {
            $findings[] = compact('severity', 'code', 'message', 'citation', 'gate');
        };

        // ---- structurally improper -------------------------------------------------

        if ($application->lines()->count() === 0) {
            $add(self::HARD_INVALID, 'no_sov_basis',
                'This application bills nothing against an approved schedule of values. A payment request with no contract-item basis is not a proper request.');
        }

        foreach ($summary['overbilled_lines'] as $over) {
            $add(self::HARD_INVALID, 'line_over_authorized',
                'Line '.$over['item_number'].' is billed $'.number_format($over['by_cents'] / 100, 2)
                .' above its currently authorized value. Bill the change order that added the work, or correct the line.');
        }

        // The case a cumulative-total check is blind to, and Codex's example
        // exactly: a line authorized at $100,000, $70,000 of original scope
        // earned, $20,000 of pending change work performed, $90,000 billed. The
        // total stays under the cap, so an over-billing validator waves it
        // through while unapproved change value rides inside an original line.
        //
        // Change work belongs on its own line. Anything else is a change the
        // agency never approved, billed where it cannot be seen.
        foreach ($application->lines as $line) {
            $pending = (int) ($line->pending_change_value_cents ?? 0);
            if ($pending <= 0) {
                continue;
            }

            $item = $line->item;
            $isChangeOrderLine = $item !== null && $item->change_order_id !== null;

            $add(self::HARD_INVALID, 'unauthorized_change_value_in_line',
                'Line '.($item?->item_number ?? (string) $line->id).' bills $'
                .number_format($pending / 100, 2).' of change-order work that is not yet approved'
                .($isChangeOrderLine ? '.' : ', inside an original contract line.')
                .' Cumulative billing on the line may still be under its authorized value, which is exactly why this does not show up as over-billing. Move it to its own change-order line and bill it once the change order is executed.');
        }

        // Extra work hidden inside an original line is how a contractor
        // accidentally turns a legitimate change into an allegation of false claim.
        foreach ((array) ($context['unapproved_change_order_line_numbers'] ?? []) as $lineNumber) {
            $add(self::HARD_INVALID, 'unapproved_change_billed',
                'Line '.$lineNumber.' bills work from a change order that is not yet approved. Added work is not payable before the change order is executed, and billing it inside an original line is worse than billing it openly.');
        }

        if (isset($context['original_contract_cents'], $context['approved_change_orders_cents'], $context['current_contract_cents'])) {
            $expected = (int) $context['original_contract_cents'] + (int) $context['approved_change_orders_cents'];
            if ($expected !== (int) $context['current_contract_cents']) {
                $add(self::HARD_INVALID, 'contract_sum_does_not_reconcile',
                    'The current contract sum does not equal the original contract plus approved change orders. The difference is $'
                    .number_format(abs($expected - (int) $context['current_contract_cents']) / 100, 2)
                    .'. An application that does not reconcile will be returned.');
            }
        }

        if (isset($context['prior_certified_paid_cents'])
            && (int) $context['prior_certified_paid_cents'] !== $summary['previous_completed_cents']) {
            $add(self::HARD_INVALID, 'prior_payments_do_not_match',
                'Previous completed work on this application does not match the last certified application. Agencies reconcile this line first.');
        }

        // Money that was billed and then quietly disappears reads as concealment
        // even when it is an honest correction. Make the correction explicit.
        if (isset($context['previous_application_completed_cents'])
            && $summary['previous_completed_cents'] < (int) $context['previous_application_completed_cents']) {
            $add(self::HARD_INVALID, 'billing_decreased_without_adjustment',
                'Previously billed value has decreased with no recorded adjustment or reversal. If this is a correction, record it as one - an unexplained decrease reads as concealment.');
        }

        if ($retention !== null) {
            $expectedRetention = $retention->withhold($summary['previous_completed_cents'] + $summary['this_period_cents'], $summary['stored_materials_cents']);
            if ($expectedRetention !== $summary['retention_cents']) {
                $add(self::HARD_INVALID, 'retention_basis_inconsistent',
                    'Retention on this application does not match the governing rule ('.$retention->source.'). Expected $'
                    .number_format($expectedRetention / 100, 2).', application shows $'
                    .number_format($summary['retention_cents'] / 100, 2).'.',
                    $retention->source);
            }

            if ($retention->exceedsStatutoryCap()) {
                $add(self::HARD_INVALID, 'retention_above_statutory_cap',
                    'The retention rate exceeds the statutory cap for public works.',
                    RetentionRule::CAP_CITATION);
            }

            if (! $retention->confirmed) {
                $add(self::RETURNABLE, 'retention_rule_unconfirmed',
                    'The retention rate is a cited default that nobody has confirmed against this contract. Confirm it at project setup before billing against it.',
                    $retention->source);
            }
        }

        if ($application->period_from !== null && $application->period_to !== null
            && $application->period_to->lt($application->period_from)) {
            $add(self::HARD_INVALID, 'period_inverted', 'The billing period ends before it begins.');
        }

        // Where last month's stored material went. Invisible to every check
        // above, because both failure modes leave this month's arithmetic
        // perfectly valid.
        if (isset($context['prior_certified_stored'], $context['current_stored'])) {
            foreach (StoredMaterialRollForward::findings(
                (array) $context['prior_certified_stored'],
                (array) $context['current_stored'],
            ) as $finding) {
                $findings[] = $finding;
            }
        }

        // Billing on a line an approved deductive change order already cut.
        if (isset($context['deducted_lines'])) {
            foreach (DeductedScopeBilling::findings((array) $context['deducted_lines']) as $finding) {
                // The unattributed case is an agency-facing completeness item:
                // whether it must be answered before the package goes out is
                // the contract's call, not ours.
                if ($finding['severity'] === self::RETURNABLE) {
                    $finding['gate'] = 'agency';
                }
                $findings[] = $finding;
            }
        }

        // ---- returnable ------------------------------------------------------------

        foreach ((array) ($context['stored_material_line_numbers_without_sov'] ?? []) as $lineNumber) {
            $add(self::RETURNABLE, 'stored_material_untied',
                'Stored material on line '.$lineNumber.' is not tied to a schedule-of-values line. An agency can return the request for that alone.',
                null, 'agency');
        }

        foreach ((array) ($context['stored_material_line_numbers_without_evidence'] ?? []) as $lineNumber) {
            $add(self::RETURNABLE, 'stored_material_unsupported',
                'Stored material on line '.$lineNumber.' has no supporting invoice or purchase evidence attached.',
                null, 'agency');
        }

        if ($summary['total_completed_and_stored_cents'] === 0 && $application->lines()->count() > 0) {
            $add(self::RETURNABLE, 'nothing_billed', 'Nothing is billed on this application.');
        }

        // ---- withhold --------------------------------------------------------------
        //
        // Certified payroll is a condition of payment on California public works,
        // so it belongs in the same review as the arithmetic - but it must never
        // be allowed to make the request improper. An improper request restarts
        // the seven-day return window under PCC 20104.50; a compliance withholding
        // leaves the thirty-day clock running on the undisputed portion. Merging
        // the two severities would tell the contractor the wrong date.
        $payroll = $context['certified_payroll'] ?? null;
        if (is_array($payroll)) {
            foreach (CertifiedPayrollCheck::collapseOverlappingExposure(CertifiedPayrollCheck::findings(
                (array) ($payroll['records'] ?? []),
                (array) ($payroll['determinations'] ?? []),
                (array) ($payroll['context'] ?? []),
            )) as $finding) {
                // Collapsed below, once the whole payroll set is known.
                // Defensive: the payroll checker only ever emits withhold today.
                // If that ever changes, it still must not escalate a payment
                // request into an improper one from over here.
                $finding['severity'] = self::WITHHOLD;
                $findings[] = $finding;
            }
        }

        // Waiver and release coverage, and money frozen by a served stop payment
        // notice. Both are WITHHOLD and both are internal: neither makes the
        // request improper - a release gap is the owner's own file-keeping, and
        // a stop notice freezes money on a request that may be perfectly proper.
        // They are merged as two separate sets and are never netted together.
        if (isset($context['releases']) || isset($context['required_claimants'])) {
            foreach (ReleaseCoverage::findings((array) ($context['releases'] ?? []), [
                'period_end' => $context['period_end'] ?? $application->period_end ?? null,
                'prior_period_end' => $context['prior_period_end'] ?? null,
                'required_claimants' => (array) ($context['required_claimants'] ?? []),
                'payment_is_final' => (bool) ($context['payment_is_final'] ?? false),
            ]) as $finding) {
                $findings[] = $finding;
            }
        }

        if (isset($context['stop_payment_notices'])) {
            foreach (StopNoticeWithholding::required((array) $context['stop_payment_notices'])['findings'] as $finding) {
                $findings[] = $finding;
            }
        }

        return $findings;
    }

    /**
     * The findings that hold money without making the request improper. Kept
     * separate because the contractor's next action differs: a hard-invalid
     * finding means fix and resubmit, a withholding means the request can stand
     * while the compliance defect is cured.
     *
     * @param  list<array{severity: string, code: string, message: string, citation: ?string}>  $findings
     * @return list<array{severity: string, code: string, message: string, citation: ?string}>
     */
    public static function withholdings(array $findings): array
    {
        return array_values(array_filter($findings, fn ($f) => $f['severity'] === self::WITHHOLD));
    }

    /**
     * The money this software is willing to say is at risk, and nothing more.
     *
     * A condition that is grounds for withholding is not an amount. An uncovered
     * classification has no rate to compute against; an apprentice ratio is
     * measured over the whole project and is curable until it is not. Putting a
     * number on either would be asserting a violation nobody has determined.
     * Codex caught this collapse and it is the reason for the split.
     *
     * @param  list<array<string,mixed>>  $findings
     * @return array{computable_cents: int, computable: list<array<string,mixed>>, awaiting_determination: list<array<string,mixed>>, informational: list<array<string,mixed>>}
     */
    public static function exposure(array $findings): array
    {
        $held = self::withholdings($findings);

        $computable = CertifiedPayrollCheck::monetary($held);
        $cents = 0;
        foreach ($computable as $finding) {
            $cents += (int) ($finding['exposure_cents'] ?? 0);
        }

        $of = fn (string $eligibility) => array_values(array_filter(
            $held,
            fn ($f) => ($f['eligibility'] ?? null) === $eligibility,
        ));

        return [
            'computable_cents' => $cents,
            'computable' => $computable,
            'awaiting_determination' => array_merge(
                $of(CertifiedPayrollCheck::ESTIMATE_ONLY),
                $of(CertifiedPayrollCheck::REQUIRES_DETERMINATION),
            ),
            'informational' => $of(CertifiedPayrollCheck::INFORMATIONAL),
        ];
    }

    /**
     * Can this be submitted at all? Only the structurally improper stop it - a
     * returnable defect is worth warning about loudly, but it is the contractor's
     * call whether to send it.
     */
    public static function blocksSubmission(array $findings): bool
    {
        foreach ($findings as $f) {
            if ($f['severity'] === self::HARD_INVALID) {
                return true;
            }
        }

        return false;
    }
}
