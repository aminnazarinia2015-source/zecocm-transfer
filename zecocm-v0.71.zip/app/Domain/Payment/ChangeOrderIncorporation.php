<?php

namespace App\Domain\Payment;

use App\Models\ChangeOrder;
use App\Models\ScheduleOfValueItem;
use Illuminate\Support\Facades\DB;

/**
 * What an approved change order does to the schedule of values.
 *
 * Codex's rule, and it is the one that keeps the contract legible: an approved
 * change order may adjust an EXISTING line only when the change genuinely belongs
 * to that line's scope. Distinct added scope gets its own line.
 *
 * The reason is not tidiness. Once added scope is folded into a base line, the
 * line's authorized value rises and the extra work becomes invisible - cumulative
 * billing against it looks perfectly normal, because the cap moved. That is the
 * same blindness the hidden-change check exists to catch, except here it would be
 * baked into the schedule of values itself and no downstream check could see it.
 *
 * So: original_value_cents is never touched. It is the record of what the
 * contract started as, and it is what makes contract growth visible at a glance.
 * scheduled_value_cents moves; the original does not.
 *
 * And incorporation is idempotent. Applying the same change order twice would
 * inflate the contract sum silently - the exact defect the pay-app reconciliation
 * check would then report as unexplained.
 */
final class ChangeOrderIncorporation
{
    /**
     * @return list<string> reasons this change order cannot be incorporated
     */
    public static function refusals(ChangeOrder $order): array
    {
        $order->loadMissing('allocations.item');
        $refusals = [];

        if (! $order->isApproved()) {
            $refusals[] = 'Change order '.$order->number.' is '.$order->status
                .'. Only an approved change order may be incorporated into the schedule of values.';
        }

        $allocated = 0;
        foreach ($order->allocations as $allocation) {
            $allocated += (int) $allocation->amount_cents;

            if (! $allocation->createsNewLine()
                && trim((string) $allocation->same_scope_justification) === '') {
                $refusals[] = 'Allocation to line '.($allocation->item?->item_number ?? '?')
                    .' adjusts an existing line without recording why the work belongs to that line\'s scope. '
                    .'Added scope folded into a base line raises the cap and becomes invisible - if it is distinct work, give it its own line.';
            }

            if ($allocation->createsNewLine() && trim((string) $allocation->new_item_number) === '') {
                $refusals[] = 'An allocation creating a new schedule-of-values line must supply the line number.';
            }
        }

        if ($order->allocations->isEmpty()) {
            $refusals[] = 'Change order '.$order->number.' has no allocations, so its value cannot be placed anywhere in the schedule of values.';
        } elseif ($allocated !== (int) $order->amount_cents) {
            $refusals[] = 'Allocations total $'.number_format($allocated / 100, 2)
                .' but the change order is $'.number_format((int) $order->amount_cents / 100, 2)
                .'. Every dollar of a change order must land somewhere in the schedule of values.';
        }

        return $refusals;
    }

    /**
     * Apply an approved change order to the schedule of values.
     *
     * @return array{adjusted: int, created: int, contract_delta_cents: int}
     */
    public static function incorporate(ChangeOrder $order): array
    {
        $refusals = self::refusals($order);
        if ($refusals !== []) {
            throw new \RuntimeException($refusals[0]);
        }

        // Idempotent by the change order's own id. Applying twice would inflate
        // the contract sum silently, and the pay application would then report a
        // reconciliation failure nobody could explain.
        $alreadyApplied = ScheduleOfValueItem::query()
            ->where('project_id', $order->project_id)
            ->where('change_order_id', $order->id)
            ->exists();

        if ($alreadyApplied) {
            return ['adjusted' => 0, 'created' => 0, 'contract_delta_cents' => 0];
        }

        $adjusted = 0;
        $created = 0;

        DB::transaction(function () use ($order, &$adjusted, &$created) {
            foreach ($order->allocations as $allocation) {
                if ($allocation->createsNewLine()) {
                    ScheduleOfValueItem::create([
                        'tenant_id' => $order->tenant_id,
                        'project_id' => $order->project_id,
                        'item_number' => $allocation->new_item_number,
                        'description' => $allocation->new_item_description ?: ('Change order '.$order->number),
                        // A line created BY a change order has no original contract
                        // value. That zero is what tells anyone reading the schedule
                        // that this scope was not in the contract as bid.
                        //
                        // Found by a real-world "what if" pass: this must NOT be
                        // clamped to zero. A deductive/credit change order - crediting
                        // back scope that was never itemized before - creates a new
                        // line with a genuinely negative value, and clamping it to 0
                        // silently erased the credit from the contract sum. The clamp
                        // belongs only to the existing-line branch below, where it
                        // guards a running total that already has a base value.
                        'original_value_cents' => 0,
                        'scheduled_value_cents' => (int) $allocation->amount_cents,
                        'change_order_id' => $order->id,
                    ]);
                    $created++;

                    continue;
                }

                $item = $allocation->item;
                if ($item === null) {
                    continue;
                }

                // original_value_cents is deliberately untouched. It is the record
                // of what the contract started as, and it is the only thing that
                // makes contract growth visible once values start moving.
                $item->scheduled_value_cents = max(0, (int) $item->scheduled_value_cents + (int) $allocation->amount_cents);
                $item->change_order_id = $order->id;
                $item->save();
                $adjusted++;
            }
        });

        return [
            'adjusted' => $adjusted,
            'created' => $created,
            'contract_delta_cents' => (int) $order->amount_cents,
        ];
    }

    /**
     * Current contract sum: the original schedule plus every approved change
     * order. This is the figure a pay application must reconcile against, and
     * computing it from the record rather than storing it is what stops the two
     * from drifting.
     */
    public static function contractSum(int $projectId): array
    {
        $original = (int) ScheduleOfValueItem::query()
            ->where('project_id', $projectId)->sum('original_value_cents');

        $approvedChanges = (int) ChangeOrder::query()
            ->where('project_id', $projectId)->where('status', 'approved')->sum('amount_cents');

        return [
            'original_contract_cents' => $original,
            'approved_change_orders_cents' => $approvedChanges,
            'current_contract_cents' => $original + $approvedChanges,
        ];
    }
}
