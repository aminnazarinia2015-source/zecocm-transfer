<?php

namespace App\Domain\Payment;

use App\Models\PayApplication;

/**
 * What the contractor is actually owed this period.
 *
 * Every figure here is integer CENTS. Floating point money is how a retention
 * calculation ends up a penny off across forty line items and a public agency
 * rejects the whole application, which costs a month.
 *
 * The rules encoded below are the ones agencies actually reject over:
 *
 *   You cannot bill more than the scheduled value of a line. Over-billing is not
 *   a rounding argument, it is a claim for work that is not in the contract at
 *   that value.
 *
 *   Retention is withheld from earned work, not from stored materials. Stored
 *   materials are not work in place.
 *
 *   Payment due is earned, less retention, less what has already been paid. All
 *   three are shown separately, because "why is this different from what I
 *   invoiced" is the most common question on a pay app and the answer is always
 *   one of the three.
 */
final class PayApplicationMath
{
    /**
     * @return array<string,mixed>
     */
    public static function summarize(PayApplication $application, int $previouslyPaidCents = 0, ?RetentionRule $retention = null): array
    {
        $application->loadMissing('lines.item');

        $scheduled = 0;
        $previous = 0;
        $thisPeriod = 0;
        $stored = 0;
        $overbilled = [];

        foreach ($application->lines as $line) {
            $item = $line->item;
            if ($item === null) {
                continue;
            }

            $scheduled += (int) $item->scheduled_value_cents;
            $previous += (int) $line->previous_completed_cents;
            $thisPeriod += (int) $line->this_period_cents;
            $stored += (int) $line->stored_materials_cents;

            // Work in place only. Stored materials sit outside the scheduled
            // value test because they are not yet installed work.
            $completed = (int) $line->previous_completed_cents + (int) $line->this_period_cents;
            if ($completed > (int) $item->scheduled_value_cents) {
                $overbilled[] = [
                    'item_number' => (string) $item->item_number,
                    'by_cents' => $completed - (int) $item->scheduled_value_cents,
                ];
            }
        }

        $earned = $previous + $thisPeriod;
        $totalCompletedAndStored = $earned + $stored;

        // Retention comes from the governing rule when one is supplied. The first
        // version hardcoded 'no retention on stored materials'; Codex caught it
        // against Public Contract Code s. 9203, which measures a progress payment
        // as 95% of work AND 95% of qualifying stored material. Withholding the
        // wrong amount in the contractor's favour is still the wrong amount.
        //
        // Without a rule we fall back to the rate recorded on the application, and
        // the review layer flags that the rule was never confirmed.
        $retentionCents = $retention !== null
            ? $retention->withhold($earned, $stored)
            : intdiv(($earned + $stored) * (int) $application->retention_basis_points, 10000);

        $percent = $scheduled > 0 ? intdiv($totalCompletedAndStored * 10000, $scheduled) : 0;

        $earnedLessRetention = $totalCompletedAndStored - $retentionCents;

        return [
            'scheduled_value_cents' => $scheduled,
            'previous_completed_cents' => $previous,
            'this_period_cents' => $thisPeriod,
            'stored_materials_cents' => $stored,
            'total_completed_and_stored_cents' => $totalCompletedAndStored,
            'percent_complete_basis_points' => $percent,
            'retention_cents' => $retentionCents,
            'retention_source' => $retention?->source,
            'retention_confirmed' => $retention?->confirmed ?? false,
            'earned_less_retention_cents' => $earnedLessRetention,
            'previously_paid_cents' => $previouslyPaidCents,
            'current_payment_due_cents' => $earnedLessRetention - $previouslyPaidCents,
            'overbilled_lines' => $overbilled,
        ];
    }

    /**
     * Reasons this application cannot be submitted. Empty means it can.
     *
     * Refusing at submission is the point: an application rejected by the agency
     * costs a payment cycle, and on a public job that is a month of float the
     * contractor is financing.
     *
     * @return list<string>
     */
    public static function submissionRefusals(PayApplication $application): array
    {
        $summary = self::summarize($application);
        $refusals = [];

        foreach ($summary['overbilled_lines'] as $over) {
            $refusals[] = 'Line '.$over['item_number'].' is billed $'
                .number_format($over['by_cents'] / 100, 2)
                .' above its scheduled value. Bill the change order that added the work, or correct the line.';
        }

        if ($summary['total_completed_and_stored_cents'] === 0) {
            $refusals[] = 'Nothing is billed on this application.';
        }

        if ($application->period_from !== null && $application->period_to !== null
            && $application->period_to->lt($application->period_from)) {
            $refusals[] = 'The billing period ends before it begins.';
        }

        return $refusals;
    }
}
