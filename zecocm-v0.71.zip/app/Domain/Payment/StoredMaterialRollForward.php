<?php

namespace App\Domain\Payment;

/**
 * Where last month's stored material went.
 *
 * Codex's pick out of its own false-claim list, and the reason it picked it is
 * that this one is detectable from data ZecoCM already holds. It needs no field
 * verification, no inspector, no photograph: two certified applications side by
 * side are enough.
 *
 * Money paid for stored material has exactly three honest futures. It is still
 * stored. It was installed, and the stored balance falls by what moved into
 * completed work. Or it left the job, and the money comes back as a declared
 * credit. Anything else is a double payment or a disappearance.
 *
 * Both failures are invisible to every other check in this system:
 *
 *   THE DOUBLE CARRY. Application 3 bills $20,000 completed and $80,000 stored.
 *   Application 4 bills $100,000 completed and still $80,000 stored. Completed
 *   work rose by exactly the stored balance while the stored balance never
 *   moved - the same value billed twice, in two categories. Cumulative billing
 *   may still sit under the line's authorized value, so the over-billing
 *   validator stays silent. It is silent correctly. It cannot see composition.
 *
 *   THE DISAPPEARANCE. Application 3 bills $80,000 stored. Application 4 bills
 *   none, completed work does not rise, and no credit is recorded. Either the
 *   material was installed and nobody said so, or it is gone and the owner paid
 *   for it. An unexplained decrease reads as concealment even when it is an
 *   honest correction, which is why the cure is to declare it rather than to
 *   quietly type a smaller number.
 *
 * The word "potential" stays in the duplicate message on purpose. The
 * arithmetic inconsistency is certain. That the material is literally the same
 * physical material is not, and this software does not get to assert intent.
 */
final class StoredMaterialRollForward
{
    /**
     * @param  array<int,array{stored_cents: int, completed_cents: int}>  $priorCertified  keyed by schedule-of-values item id
     * @param  array<int,array{item_number: string, stored_cents: int, completed_cents: int, adjustment_cents: int, adjustment_reason: ?string}>  $current
     * @return list<array{severity: string, code: string, message: string, citation: ?string, item_number: string, unreconciled_cents: int}>
     */
    public static function findings(array $priorCertified, array $current): array
    {
        $findings = [];

        foreach ($priorCertified as $itemId => $prior) {
            $priorStored = (int) ($prior['stored_cents'] ?? 0);
            if ($priorStored <= 0) {
                continue;
            }

            $line = $current[$itemId] ?? null;
            $itemNumber = (string) ($line['item_number'] ?? ('SOV item '.$itemId));

            // The line vanished from the application entirely. That is the
            // disappearance in its purest form.
            if ($line === null) {
                $findings[] = self::finding('stored_material_rollforward_unreconciled', $itemNumber, $priorStored,
                    'Line '.$itemNumber.' carried $'.self::money($priorStored)
                    .' of stored material on the last certified application and does not appear on this one at all. Stored material that was paid for cannot leave the record without an accounting. Carry the line forward, move the value into completed work, or record an explicit credit.');

                continue;
            }

            $currentStored = (int) ($line['stored_cents'] ?? 0);
            $completedIncrease = (int) ($line['completed_cents'] ?? 0) - (int) ($prior['completed_cents'] ?? 0);
            $adjustment = (int) ($line['adjustment_cents'] ?? 0);
            $declared = trim((string) ($line['adjustment_reason'] ?? '')) !== '';

            $storedReduction = $priorStored - $currentStored;

            if ($storedReduction > 0) {
                // Released stored value must land somewhere: installed work, or
                // a declared credit. An adjustment without a reason is not a
                // declaration - it is the same silent decrease in a different
                // column.
                $accounted = max(0, $completedIncrease) + ($declared ? abs($adjustment) : 0);
                $unreconciled = $storedReduction - $accounted;

                if ($unreconciled > 0) {
                    $findings[] = self::finding('stored_material_rollforward_unreconciled', $itemNumber, $unreconciled,
                        'Stored material on line '.$itemNumber.' does not reconcile to the last certified application. $'
                        .self::money($unreconciled).' previously paid as stored material is no longer accounted for as stored material, as installed work, or as a declared adjustment.'
                        .($adjustment !== 0 && ! $declared
                            ? ' An adjustment is recorded on the line with no reason given, which does not account for it.'
                            : '')
                        .' Reconcile the prior stored-material balance before submission.');
                }

                continue;
            }

            // Stored balance held or grew while completed work rose. The value
            // that moved into completed work was never released from stored.
            if ($completedIncrease > 0 && $currentStored >= $priorStored) {
                $exposed = min($completedIncrease, $priorStored);

                if (! $declared) {
                    $findings[] = self::finding('stored_material_double_carry', $itemNumber, $exposed,
                        'Potential duplicate billing of stored material on line '.$itemNumber.'. $'
                        .self::money($priorStored).' remains billed as stored material while completed work on the same line rose by $'
                        .self::money($completedIncrease)
                        .'. If that work is the installation of the stored material, the stored balance must fall by the amount installed. If it is separate scope, say so on the line so the record shows why both stand.');
                }
            }
        }

        return $findings;
    }

    private static function finding(string $code, string $itemNumber, int $cents, string $message): array
    {
        return [
            'severity' => PayApplicationReview::HARD_INVALID,
            'code' => $code,
            'message' => $message,
            // The reconciliation duty is the contract's and the agency's; this
            // check asserts arithmetic, not a statute, so it cites none.
            'citation' => null,
            'item_number' => $itemNumber,
            'unreconciled_cents' => $cents,
        ];
    }

    private static function money(int $cents): string
    {
        return number_format($cents / 100, 2);
    }
}
