<?php

namespace App\Domain\Provenance;

final class SealedRecord
{
    /** @param array<string,mixed> $payload */
    public function __construct(
        public readonly array $payload,
        public readonly string $signature,
    ) {}
}
