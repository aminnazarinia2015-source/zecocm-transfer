<?php

namespace App\Domain\Provenance;

final class CaptureClocks
{
    public function __construct(
        public readonly \DateTimeImmutable $deviceWallClock,
        public readonly float $monotonicAtCapture,
    ) {}
}
