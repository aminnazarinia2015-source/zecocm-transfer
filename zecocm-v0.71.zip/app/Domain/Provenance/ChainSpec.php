<?php

namespace App\Domain\Provenance;

/**
 * How one hash-chained ledger is put together.
 *
 * Each ledger in this codebase computes its event hash slightly differently -
 * different fields, different JSON flags, some including timestamps and some not.
 * That drift is itself a finding (it is EV-13, canonicalization), but a verifier
 * cannot wait for the drift to be fixed: it has to describe what each chain
 * ACTUALLY does today, or it will report healthy chains as broken and nobody will
 * ever trust it again.
 *
 * So the spec is descriptive, not aspirational. When canonicalization lands, the
 * specs converge; until then they tell the truth about each table.
 */
final class ChainSpec
{
    /**
     * @param  list<string>  $payloadFields  in the exact order the writer builds them
     */
    public function __construct(
        public readonly string $name,
        public readonly string $table,
        /** Column that separates one chain from another (e.g. quality_item_id). */
        public readonly string $groupColumn,
        public readonly array $payloadFields,
        public readonly string $hashColumn = 'event_hash',
        public readonly string $previousHashColumn = 'previous_event_hash',
        public readonly string $sequenceColumn = 'id',
        public readonly int $jsonFlags = JSON_THROW_ON_ERROR,
        /** Fields whose stored value cannot be recomputed byte-for-byte. */
        public readonly array $unrecomputableFields = [],
        /** The table holding the record this chain describes, when there is one. */
        public readonly ?string $subjectTable = null,
        /** Fields of that record carrying evidentiary meaning. */
        public readonly array $subjectFields = [],
        public readonly string $subjectHashColumn = 'subject_hash',
    ) {}

    /** @return array<string,self> */
    public static function all(): array
    {
        return [
            'quality' => new self(
                name: 'Quality item events',
                table: 'quality_item_events',
                groupColumn: 'quality_item_id',
                payloadFields: ['tenant_id', 'project_id', 'quality_item_id', 'event_type',
                    'from_status', 'to_status', 'note', 'classification', 'actor_user_id',
                    'previous_event_hash'],
                subjectTable: 'quality_items',
                subjectFields: \App\Domain\Provenance\SubjectFingerprint::QUALITY_ITEM_FIELDS,
            ),
            'knowledge' => new self(
                name: 'Knowledge review events',
                table: 'knowledge_review_events',
                groupColumn: 'knowledge_source_id',
                payloadFields: ['tenant_id', 'knowledge_source_id', 'action', 'from_status',
                    'to_status', 'reason', 'actor_user_id', 'previous_event_hash',
                    'created_at', 'updated_at'],
                // The writer hashes Carbon instances; the database returns strings.
                // The two do not serialise identically, so this chain cannot be
                // recomputed byte-for-byte from stored data. Structure is still
                // verifiable. Saying so is the point - a verifier that quietly
                // skipped this would be worse than none.
                unrecomputableFields: ['created_at', 'updated_at'],
            ),
        ];
    }
}
