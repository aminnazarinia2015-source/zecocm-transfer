<?php

namespace App\Domain\Provenance;

/**
 * EV-12: the one place that resolves a signing-key id to its secret.
 *
 * Fail-closed like DigestAlgorithm - an unknown, missing, or blank key id
 * resolves to null, never a guess and never a silent fall-back to whatever
 * key happens to be active today. That silent fall-back is exactly what made
 * rotation unsafe before this row: a verifier that always used "the current
 * key" would report a seal written under a since-rotated-out key as
 * TAMPERED, when the truth is that it was correctly signed by a key the
 * verifier simply never looked for.
 *
 * `keys` in config/provenance.php is additive and permanent. Rotating never
 * removes an entry - it adds one and moves `active_key_id`. This class does
 * not enforce that (config is data, not code) but every call site in this
 * codebase treats it as an invariant; see that file's own doc comment.
 */
final class SigningKeyRing
{
    /**
     * The id every seal in this codebase carried before EV-12 existed -
     * none of them recorded a `signing_key_id` at all, because there was
     * only ever one key. ProvenanceSealer::verify() falls back to this id
     * for exactly those pre-EV-12 records; every seal from EV-12 onward
     * carries its key id explicitly and this constant is not consulted for
     * them at all.
     */
    public const LEGACY_KEY_ID = 'legacy-v1';

    public static function activeKeyId(): string
    {
        return (string) config('provenance.active_key_id');
    }

    /**
     * The secret to sign a NEW record with. Throws rather than sealing with
     * an empty string, which `hash_hmac` would accept silently and which
     * would make every seal it produces worthless.
     */
    public static function activeKey(): string
    {
        $keyId = self::activeKeyId();
        $key = self::keyFor($keyId);
        if ($key === null) {
            throw new \RuntimeException(
                "Signing key '{$keyId}' (config('provenance.active_key_id')) is not configured with a "
                .'non-empty secret. Set PROVENANCE_SIGNING_KEY (or the env var backing the active key id) '
                .'before sealing new records.'
            );
        }

        return $key;
    }

    /**
     * The secret for a SPECIFIC key id - for verifying a historical seal,
     * never for producing a new one. Null means "this record cannot be
     * verified": the id is missing, blank, or simply not one this
     * installation has ever recorded. A key that was rotated away is never
     * deleted from config/provenance.php, so null here is never "this key
     * was retired" - it is either a genuinely unknown id or a
     * misconfiguration, and a verifier must not tell those apart by
     * guessing.
     */
    public static function keyFor(?string $keyId): ?string
    {
        if ($keyId === null || $keyId === '') {
            return null;
        }

        $keys = config('provenance.keys', []);
        $key = $keys[$keyId] ?? null;

        return (is_string($key) && $key !== '') ? $key : null;
    }
}
