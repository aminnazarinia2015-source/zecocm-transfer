<?php

namespace App\Domain\Provenance;

use DateTimeImmutable;

/**
 * B5 / EV-11: what the server actually knows about when a photograph was taken.
 *
 * The defect this replaces was the sharpest thing Codex said about the media
 * module, and it was right:
 *
 *   "Your 'strong confidence' badge means someone typed consistent numbers into
 *   three form fields."
 *
 * Every input to the old confidence calculation - device wall clock, monotonic
 * counter at capture, monotonic counter at transmit - came from the client. The
 * server compared them against each other and rendered STRONG when they agreed.
 * So a client that lies CONSISTENTLY earns the strongest badge the product
 * displays, and a superintendent whose phone clock is simply wrong earns the
 * weakest. The badge measured internal consistency of unverified claims and
 * presented it as confidence in the capture time.
 *
 * What the server genuinely knows, and it is not much:
 *
 *   RECEIPT TIME       authoritative. The server's own clock, at the moment the
 *                      bytes arrived. A client cannot forge it.
 *   ORDERING           authoritative. The sequence in which uploads arrived.
 *   AN UPPER BOUND     the capture happened NO LATER than receipt. Physics, not
 *                      trust.
 *   EVERYTHING ELSE    a claim. Preserved exactly, attributed to the client,
 *                      and never promoted to a fact.
 *
 * Codex's formulation, adopted: server-authoritative receipt time with client
 * metadata PRESERVED AS EVIDENCE, NEVER AS TRUTH. EXIF belongs in the same
 * category and for the same reason - it is trivially editable, frequently
 * absent, and is evidence of what a file says about itself rather than of when
 * a shutter opened.
 *
 * The one genuinely server-side finding available here is IMPOSSIBILITY: a
 * device claiming a capture time later than the server's receipt time has
 * asserted something that cannot be true. Even that is stated carefully - an
 * unsynchronised phone clock produces the same signature as a forgery, and the
 * system reports the inconsistency rather than alleging one.
 */
final class CaptureAttestation
{
    /** The capture time is established by the server, within a bound. */
    public const BASIS_SERVER_RECEIPT = 'server_receipt';

    /** The capture time is a client assertion. Recorded, not established. */
    public const BASIS_DEVICE_CLAIM = 'device_claim';

    // What the record supports, phrased as what it IS rather than as a grade.
    // A single word like "strong" invites the reader to supply their own
    // meaning, and the meaning they supply is always stronger than the truth.
    public const ESTABLISHED_BOUND = 'established_upper_bound';
    public const CLAIM_CONSISTENT = 'claim_consistent_with_bound';
    public const CLAIM_IMPOSSIBLE = 'claim_inconsistent_with_receipt';
    public const CLAIM_ABSENT = 'no_capture_claim';

    /**
     * @param  array<string,mixed>  $clientClaims  everything the device said, verbatim
     * @return array<string,mixed>
     */
    public static function attest(
        DateTimeImmutable $serverReceivedAt,
        array $clientClaims,
        ?int $receiptSequence = null,
    ): array {
        $claimed = self::date($clientClaims['device_wall_clock'] ?? null);

        $established = [
            // The only two things here that are not somebody's word.
            'received_at' => $serverReceivedAt->format(DATE_ATOM),
            'captured_no_later_than' => $serverReceivedAt->format(DATE_ATOM),
            'receipt_sequence' => $receiptSequence,
        ];

        if ($claimed === null) {
            return self::out(self::CLAIM_ABSENT, self::BASIS_SERVER_RECEIPT, $established, $clientClaims,
                'The capture time is not established. What is established is that these bytes reached the server at '
                .$serverReceivedAt->format('j M Y H:i:s T').' and therefore were captured no later than that. The '
                .'device supplied no capture time.',
                null);
        }

        $skewSeconds = $claimed->getTimestamp() - $serverReceivedAt->getTimestamp();

        if ($skewSeconds > 0) {
            // The one finding the server can make on its own authority - and it
            // is a finding about the RECORD, not about the person. A phone with
            // an unsynchronised clock produces exactly this signature.
            return self::out(self::CLAIM_IMPOSSIBLE, self::BASIS_SERVER_RECEIPT, $established, $clientClaims,
                'The device claims a capture time of '.$claimed->format('j M Y H:i:s T').', which is '
                .self::humanInterval($skewSeconds).' AFTER the server received the file at '
                .$serverReceivedAt->format('j M Y H:i:s T').'. A capture cannot postdate its own upload, so the '
                .'claimed time cannot be correct as recorded. This is a statement about the record and not an '
                .'allegation about any person: an unsynchronised device clock produces the same result. What remains '
                .'established is that the capture happened no later than receipt.',
                $claimed->format(DATE_ATOM));
        }

        return self::out(self::CLAIM_CONSISTENT, self::BASIS_DEVICE_CLAIM, $established, $clientClaims,
            'The device claims a capture time of '.$claimed->format('j M Y H:i:s T').', '
            .self::humanInterval(abs($skewSeconds)).' before the server received the file. That claim is consistent '
            .'with the server\'s receipt time, which is the only check the server can perform on it. Consistency is '
            .'not verification: the capture time remains the device\'s assertion, and ZecoCM establishes only that the '
            .'capture happened no later than '.$serverReceivedAt->format('j M Y H:i:s T').'.',
            $claimed->format(DATE_ATOM));
    }

    /**
     * The sentence rendered on the face of a document.
     *
     * Deliberately not a one-word badge. The old one said "strong", and a
     * reader seeing "strong" beside a photograph in a claim package will
     * reasonably believe the timestamp was verified. It was not, it cannot be
     * by this system, and the label has to say so in the space where somebody
     * would otherwise assume.
     */
    public static function statement(array $attestation): string
    {
        return match ($attestation['finding']) {
            self::CLAIM_IMPOSSIBLE => 'Captured no later than '
                .self::short($attestation['established']['received_at'])
                .' (server receipt). The device\'s own claimed capture time is inconsistent with that and is recorded '
                .'unaltered for review.',
            self::CLAIM_ABSENT => 'Captured no later than '
                .self::short($attestation['established']['received_at']).' (server receipt). No device capture time.',
            default => 'Captured no later than '
                .self::short($attestation['established']['received_at'])
                .' (server receipt). Device reports '.self::short($attestation['claimed_captured_at'])
                .' — the device\'s assertion, not independently verified.',
        };
    }

    /**
     * Whether anything downstream may treat the device's time as the capture
     * time. It may not, ever, and this exists so that the next person to write
     * a report has a function to call instead of a judgement to make.
     */
    public static function captureTimeIsEstablished(array $attestation): bool
    {
        return false;
    }

    private static function humanInterval(int $seconds): string
    {
        $seconds = abs($seconds);

        return match (true) {
            $seconds < 90 => $seconds.' second(s)',
            $seconds < 5400 => round($seconds / 60).' minute(s)',
            $seconds < 172800 => round($seconds / 3600, 1).' hour(s)',
            default => round($seconds / 86400, 1).' day(s)',
        };
    }

    private static function short(?string $iso): string
    {
        if ($iso === null) {
            return 'an unrecorded time';
        }

        try {
            return (new DateTimeImmutable($iso))->format('j M Y H:i T');
        } catch (\Exception) {
            return $iso;
        }
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }

        try {
            return $value instanceof DateTimeImmutable ? $value : new DateTimeImmutable((string) $value);
        } catch (\Exception) {
            return null;
        }
    }

    /** @return array<string,mixed> */
    private static function out(string $finding, string $basis, array $established,
        array $clientClaims, string $message, ?string $claimedCapturedAt): array
    {
        return [
            'finding' => $finding,
            'capture_time_basis' => $basis,
            'established' => $established,
            // Verbatim, unparsed, unpromoted. Including EXIF when it is present:
            // a file's metadata is evidence of what the file says about itself.
            'client_claims' => $clientClaims,
            'claimed_captured_at' => $claimedCapturedAt,
            'message' => $message,
            'does_not_establish' => [
                'That the capture occurred at the time the device reported.',
                'That the device clock was correct.',
                'That the person who uploaded it took it.',
                'That the image depicts what its caption says it depicts.',
            ],
        ];
    }
}
