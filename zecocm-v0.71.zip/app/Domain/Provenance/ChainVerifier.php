<?php

namespace App\Domain\Provenance;

use Illuminate\Support\Facades\DB;

/**
 * Walks a hash-chained ledger and says whether it holds.
 *
 * Until this existed, nothing in this codebase had ever verified a chain. The
 * product told people the record was tamper-evident, and the evidence for that
 * claim was that the writing code looked correct. Recording a hash and never
 * checking it is not tamper evidence; it is a hash.
 *
 * The contract below is Codex's, and one clause in it does the real work:
 *
 *   When a link breaks, everything downstream is UNTRUSTED - not valid.
 *
 * A verifier that mutates record 37 of a 100-record chain and reports "99 valid,
 * 1 invalid" has misunderstood what a chain is. Records 38 to 100 each hash a
 * predecessor that is no longer what it claimed to be, so their internal
 * consistency proves nothing about their content. They are not evidence any more.
 * Reporting them as fine is how an altered ledger passes an audit.
 */
final class ChainVerifier
{
    public const OK = 'ok';
    public const BROKEN = 'broken';
    public const EMPTY_CHAIN = 'empty';
    public const NOT_RECOMPUTABLE = 'not_recomputable';

    /**
     * @return array{
     *   chain: string, group: mixed, status: string, records: int,
     *   first_invalid_sequence: ?int, first_invalid_reason: ?string,
     *   downstream_untrusted: int, head: ?string, findings: list<string>,
     *   hash_recomputed: bool
     * }
     */
    public static function verify(ChainSpec $spec, mixed $groupValue, ?string $expectedHead = null): array
    {
        $rows = DB::table($spec->table)
            ->where($spec->groupColumn, $groupValue)
            ->orderBy($spec->sequenceColumn)
            ->get();

        $findings = [];
        $recomputable = $spec->unrecomputableFields === [];

        if ($rows->isEmpty()) {
            // The worst case is the one that was escaping. An empty chain is
            // indistinguishable from a chain that never existed - unless
            // something outside it remembers otherwise. My first version of the
            // anchor check sat below this early return, so a cascade delete that
            // took every event still reported "empty" rather than "gone".
            $witnessed = ChainAnchor::expected($spec->name, $groupValue);

            if ($witnessed !== null && $witnessed['record_count'] > 0) {
                return self::result($spec, $groupValue, self::BROKEN, 0, 0, 'records_removed', 0, null,
                    [$witnessed['record_count'].' record(s) recorded by the anchor are no longer present in this chain. '
                        .'The chain is now empty, which from inside is indistinguishable from a chain that never existed.'],
                    $recomputable);
            }

            return self::result($spec, $groupValue, self::EMPTY_CHAIN, 0, null, null, 0, null,
                ['No events recorded for this chain.'], $recomputable);
        }

        if (! $recomputable && $rows->whereNull('hash_version')->isNotEmpty()) {
            $findings[] = 'Payload hashes on some records of this chain cannot be recomputed from stored data ('
                .implode(', ', $spec->unrecomputableFields)
                .' are not serialised identically on write and read). Linkage and sequence are still verified; content integrity is NOT. This command does not establish the cause, and will not name one.';
        }

        $firstInvalidSeq = null;
        $firstInvalidReason = null;
        $previousHash = null;
        $seenSequences = [];
        $index = 0;
        // Recomputability is a property of each RECORD, not of the table. A ledger
        // mid-migration holds both, and reporting the whole chain by its weakest
        // row would hide the fact that the fix is working.
        $contentVerified = true;
        $legacyRows = 0;

        foreach ($rows as $row) {
            $index++;
            $seq = (int) $row->{$spec->sequenceColumn};

            if (isset($seenSequences[$seq])) {
                $firstInvalidSeq ??= $seq;
                $firstInvalidReason ??= 'Duplicate sequence '.$seq.'.';
                break;
            }
            $seenSequences[$seq] = true;

            // Genesis: the first event must claim no predecessor. An event that
            // arrives with a previous hash but no predecessor means the chain has
            // been truncated from the front - the oldest records are missing.
            if ($index === 1) {
                if ($row->{$spec->previousHashColumn} !== null) {
                    $firstInvalidSeq = $seq;
                    $firstInvalidReason = 'The earliest surviving event references a predecessor that is not present. Records have been removed from the start of the chain.';
                    break;
                }
            } elseif ($row->{$spec->previousHashColumn} !== $previousHash) {
                $firstInvalidSeq = $seq;
                $firstInvalidReason = 'Linkage broken: this event records a different predecessor than the event before it.';
                break;
            }

            // A row that declares its canonicalization version is verifiable
            // whatever the spec says about the legacy default - that is the whole
            // point of versioning the algorithm rather than swapping it.
            //
            // EV-13: the digest ALGORITHM is a second, independent axis from the
            // encoding version. A row that explicitly declares V2 must ALSO
            // declare a known algorithm - a V2 row with no algorithm is an
            // incomplete write, not an old one, and is not recomputable. A row
            // that predates versioning entirely (no hash_version at all) is
            // governed by the spec's own legacy default exactly as before EV-13;
            // an absent hash_algorithm column there reflects that the column did
            // not exist yet, not an unknown primitive - sha256 is the only
            // digest this codebase has ever produced for such rows, which is why
            // the migration backfills it as history rather than guesses it. An
            // EXPLICIT algorithm value that is not recognised is never ignored,
            // on either kind of row.
            $rowVersion = $row->hash_version ?? null;
            $rowAlgorithm = $row->hash_algorithm ?? null;

            $rowRecomputable = $rowVersion === CanonicalPayload::V2
                ? ($rowAlgorithm !== null && in_array($rowAlgorithm, DigestAlgorithm::KNOWN, true))
                : ($recomputable && ($rowAlgorithm === null || in_array($rowAlgorithm, DigestAlgorithm::KNOWN, true)));

            if (! $rowRecomputable) {
                $contentVerified = false;
                $legacyRows++;
            }

            if ($rowRecomputable) {
                $payload = [];
                foreach ($spec->payloadFields as $field) {
                    $payload[$field] = $row->{$field} ?? null;
                }

                $recomputed = $rowVersion === CanonicalPayload::V2
                    ? CanonicalPayload::hash($payload, CanonicalPayload::V2)
                    : DigestAlgorithm::digest(json_encode($payload, $spec->jsonFlags), $rowAlgorithm ?? DigestAlgorithm::CURRENT);

                if ($recomputed !== $row->{$spec->hashColumn}) {
                    $firstInvalidSeq = $seq;
                    $firstInvalidReason = 'Content altered: the stored hash does not match a hash of the stored payload.';
                    break;
                }
            }

            $previousHash = $row->{$spec->hashColumn};
        }

        // Everything at or after the first break is untrusted. Not invalid one by
        // one - untrusted as a block, because each of them attests to a
        // predecessor whose content can no longer be established.
        $downstream = 0;
        if ($firstInvalidSeq !== null) {
            $downstream = $rows->filter(fn ($r) => (int) $r->{$spec->sequenceColumn} > $firstInvalidSeq)->count();
            $findings[] = 'First invalid record: sequence '.$firstInvalidSeq.'. '.$firstInvalidReason;
            $findings[] = $downstream.' later record(s) are DOWNSTREAM-UNTRUSTED. They may be internally consistent, but each attests to a predecessor whose content can no longer be established, so none of them is evidence of anything.';
        }

        $head = $rows->last()->{$spec->hashColumn} ?? null;
        if ($expectedHead !== null && $head !== $expectedHead) {
            $findings[] = 'Chain head does not match the expected head. Records may have been appended or removed at the end.';
            $firstInvalidSeq ??= (int) $rows->last()->{$spec->sequenceColumn};
            $firstInvalidReason ??= 'Unexpected chain head.';
        }

        if ($legacyRows > 0) {
            $findings[] = $legacyRows.' record(s) were written before the current canonicalization protocol and are verified for linkage only.';
        }

        // What the outside witness says this chain should look like. A hash
        // chain proves the records still present are unaltered and in order; it
        // proves nothing about records that are no longer there. Deleting the
        // tail leaves a chain that verifies perfectly and means something else.
        $expected = ChainAnchor::expected($spec->name, $groupValue);

        if ($expected !== null) {
            $anchorSelf = ChainAnchor::verifySelf();

            if ($anchorSelf['status'] !== 'intact') {
                // Do not quote a witness whose own account is inconsistent.
                $findings[] = 'The anchor chain is itself broken at anchor #'.$anchorSelf['first_invalid_id']
                    .', so its record of this chain\'s length cannot be relied on. Removal of records here cannot be ruled out.';
                $firstInvalidSeq ??= 0;
                $firstInvalidReason ??= 'anchor_chain_broken';
            } elseif ($rows->count() < $expected['record_count']) {
                $missing = $expected['record_count'] - $rows->count();
                $findings[] = $missing.' record(s) recorded by the anchor are no longer present in this chain. '
                    .'What remains links and hashes correctly, which is exactly why this cannot be seen from inside the chain. '
                    .'The anchor last witnessed '.$expected['record_count'].' record(s) with head '.substr($expected['head_hash'], 0, 12).'.';
                $firstInvalidSeq ??= 0;
                $firstInvalidReason ??= 'records_removed';
            } elseif ($head !== null && $rows->count() === $expected['record_count'] && $head !== $expected['head_hash']) {
                $findings[] = 'The head of this chain is not the head the anchor witnessed, although the count matches. '
                    .'A record was replaced rather than removed.';
                $firstInvalidSeq ??= 0;
                $firstInvalidReason ??= 'head_mismatch';
            }
        } elseif ($rows->count() > 0) {
            $findings[] = 'No anchor was ever written for this chain, so its length cannot be checked. '
                .'Records may have been removed from the end without leaving a trace. This chain predates the anchor.';
        }

        // Has the record this chain describes changed since anybody last said
        // anything about it? The chain cannot answer that on its own - none of
        // the subject's text is inside any event payload, so it can be rewritten
        // after the fact with every hash still verifying.
        if ($spec->subjectTable !== null && $spec->subjectFields !== []) {
            $newest = $rows->last();
            $witnessed = $newest->{$spec->subjectHashColumn} ?? null;
            $witnessedAlgorithm = $newest->subject_hash_algorithm ?? null;

            if ($witnessed === null) {
                $findings[] = 'The newest event on this chain carries no fingerprint of the record it describes, '
                    .'so alteration of that record cannot be detected. It was written before subject fingerprinting.';
            } else {
                $subject = DB::table($spec->subjectTable)->where('id', $groupValue)->first();

                if ($subject === null) {
                    $findings[] = 'The record this chain describes no longer exists, although its events do.';
                    $firstInvalidSeq ??= 0;
                    $firstInvalidReason ??= 'subject_missing';
                } else {
                    // EV-13: recompute in bytes, not in a hash - the fingerprint's
                    // own digest algorithm decides how those bytes get compared,
                    // never today's default silently substituted for an
                    // unrecognised one.
                    $material = [];
                    foreach ($spec->subjectFields as $field) {
                        $value = ((array) $subject)[$field] ?? null;
                        $material[$field] = $value instanceof \DateTimeInterface
                            ? $value->format('Y-m-d H:i:s')
                            : ($value === null ? null : (string) $value);
                    }
                    $outcome = DigestAlgorithm::verify(
                        json_encode($material, JSON_THROW_ON_ERROR), $witnessed, $witnessedAlgorithm,
                    );

                    if ($outcome === DigestAlgorithm::CANNOT_VERIFY) {
                        $findings[] = 'The subject fingerprint on the newest event carries no recognised digest '
                            .'algorithm, so alteration of the record cannot be checked. This does not mean the record '
                            .'was altered - it means this cannot establish either way.';
                    } elseif ($outcome === DigestAlgorithm::MISMATCH) {
                        $findings[] = 'The record this chain describes has been altered since the last event was written, '
                            .'and no event records the change. Every hash here still verifies - the chain is intact and '
                            .'is describing a document that is not the one it described.';
                        $firstInvalidSeq ??= 0;
                        $firstInvalidReason ??= 'subject_altered';
                    }
                }
            }
        }

        $status = match (true) {
            $firstInvalidSeq !== null => self::BROKEN,
            ! $contentVerified => self::NOT_RECOMPUTABLE,
            default => self::OK,
        };

        return self::result($spec, $groupValue, $status, $rows->count(), $firstInvalidSeq,
            $firstInvalidReason, $downstream, $head, $findings, $contentVerified);
    }

    /** @return list<array<string,mixed>> */
    public static function verifyAll(ChainSpec $spec): array
    {
        $groups = DB::table($spec->table)->distinct()->pluck($spec->groupColumn);

        return $groups->map(fn ($g) => self::verify($spec, $g))->values()->all();
    }

    private static function result(ChainSpec $spec, mixed $group, string $status, int $records,
        ?int $firstInvalid, ?string $reason, int $downstream, ?string $head, array $findings, bool $recomputed): array
    {
        return [
            'chain' => $spec->name,
            'group' => $group,
            'status' => $status,
            'records' => $records,
            'first_invalid_sequence' => $firstInvalid,
            'first_invalid_reason' => $reason,
            'downstream_untrusted' => $downstream,
            'head' => $head,
            'findings' => $findings,
            'hash_recomputed' => $recomputed,
        ];
    }
}
