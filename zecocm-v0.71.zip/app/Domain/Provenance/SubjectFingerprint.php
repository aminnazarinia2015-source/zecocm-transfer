<?php

namespace App\Domain\Provenance;

/**
 * The material state of the thing an evidence chain describes.
 *
 * Deliberately excludes status. A status change is what the chain records, and
 * putting it here would make every legitimate transition look like tampering
 * with the subject.
 *
 * Deliberately excludes timestamps. updated_at moves for reasons that carry no
 * meaning, and a fingerprint that changes when nothing changed teaches people to
 * ignore it.
 */
final class SubjectFingerprint
{
    /** The fields of a quality item that carry evidentiary meaning. */
    public const QUALITY_ITEM_FIELDS = [
        'title', 'description', 'classification', 'severity', 'location',
        'spec_section', 'drawing_reference', 'assigned_organization', 'due_at', 'number', 'kind',
    ];

    /**
     * @param  array<string,mixed>  $attributes
     * @param  list<string>  $fields
     */
    public static function of(array $attributes, array $fields): string
    {
        $material = [];
        foreach ($fields as $field) {
            $value = $attributes[$field] ?? null;
            // Dates arrive as Carbon on write and as strings on read. Normalise,
            // or the fingerprint reports tampering every time it is checked -
            // which is the exact defect the knowledge chain still carries.
            $material[$field] = $value instanceof \DateTimeInterface
                ? $value->format('Y-m-d H:i:s')
                : ($value === null ? null : (string) $value);
        }

        return DigestAlgorithm::digest(json_encode($material, JSON_THROW_ON_ERROR));
    }
}
