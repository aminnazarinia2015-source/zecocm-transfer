<?php

namespace App\Domain\Provenance;

use DateTimeInterface;

/**
 * One way to turn a payload into bytes, so the same record hashes the same on
 * write and on verification.
 *
 * The chain walker proved this was not true. knowledge_review_events hashes
 * Carbon instances at write time and the database hands back strings; the two do
 * not serialise identically, so the content of that ledger could never be checked
 * against its own hashes. The chain was structurally sound and evidentially
 * inert - and nobody could have known, because nothing had ever tried.
 *
 * Rules, and each one exists because its absence breaks recomputation:
 *
 *   Dates become ISO-8601 UTC strings. A Carbon object, a string, and a DateTime
 *   all serialise differently; only one of them survives a round trip.
 *   Integers stored as strings by the driver are normalised to integers.
 *   Field order is fixed by the caller and never sorted, because reordering a
 *   payload changes its bytes and would invalidate every existing hash.
 *   Slashes and unicode are left unescaped so the encoding does not depend on
 *   PHP's defaults changing under us.
 *
 * VERSIONED, because changing how a hash is computed retroactively invalidates
 * every record that used the old rule. Existing rows keep V1 and remain
 * verifiable for linkage only; new rows are V2 and are verifiable end to end.
 * Silently switching algorithms would have made the whole ledger look tampered.
 */
final class CanonicalPayload
{
    /** Legacy: whatever the writer happened to pass to json_encode. Not recomputable. */
    public const V1 = 'v1';

    /** Canonical: typed, normalised, order-preserving. */
    public const V2 = 'v2';

    /**
     * Every version a verifier is entitled to recognise.
     *
     * A record whose version is absent or not in this list is reported as
     * CANNOT VERIFY rather than falling back to a guess. A verifier that
     * guesses the algorithm reports success on records it did not actually
     * check, which is worse than reporting nothing.
     */
    public const KNOWN_VERSIONS = [self::V1, self::V2];

    public const CURRENT = self::V2;

    /**
     * @param  array<string,mixed>  $payload  in the writer's own field order
     */
    public static function encode(array $payload, string $version = self::CURRENT): string
    {
        if ($version === self::V1) {
            // Reproduce the old behaviour exactly, for reading old records only.
            return json_encode($payload, JSON_THROW_ON_ERROR);
        }

        return json_encode(
            self::normalize($payload),
            JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
        );
    }

    /**
     * EV-13: the digest primitive is a separate, independently versioned axis
     * from the encoding above - see DigestAlgorithm. This is now the only
     * place CanonicalPayload turns bytes into a digest, and it always uses
     * the current algorithm; callers that need to verify an OLDER digest go
     * through DigestAlgorithm::verify() directly with the algorithm the
     * record itself recorded, never this method.
     */
    public static function hash(array $payload, string $version = self::CURRENT): string
    {
        return DigestAlgorithm::digest(self::encode($payload, $version));
    }

    /**
     * @param  array<string,mixed>  $payload
     * @return array<string,mixed>
     */
    public static function normalize(array $payload): array
    {
        $out = [];
        foreach ($payload as $key => $value) {
            $out[$key] = self::normalizeValue($value);
        }

        return $out;
    }

    private static function normalizeValue(mixed $value): mixed
    {
        if ($value instanceof DateTimeInterface) {
            return $value->format('Y-m-d\TH:i:s\Z');
        }

        if (is_array($value)) {
            return self::normalize($value);
        }

        if (is_bool($value) || $value === null) {
            return $value;
        }

        // The driver returns integers as strings on some connections. A record
        // that hashes 7 on write and "7" on read is unverifiable for no reason.
        if (is_string($value) && $value !== '' && preg_match('/^-?\d+$/', $value) === 1) {
            return (int) $value;
        }

        // Datetime strings from the database, normalised to the same shape a
        // DateTimeInterface produces above.
        if (is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/', $value) === 1) {
            try {
                return (new \DateTimeImmutable($value, new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
            } catch (\Throwable) {
                return $value;
            }
        }

        return $value;
    }
}
