<?php

namespace App\Domain\Provenance;

/**
 * Non-destructive provenance binding + dual-clock offline sealing
 * (patent Aspects 1-3). Media bytes are NEVER modified; context lives in
 * a signed sidecar bound to the sha256 of the original. Offline captures
 * carry device wall-clock AND a monotonic counter; at sealing the server
 * records the divergence between the two intervals so the record's
 * trustworthiness is explicit, not assumed.
 */
final class ProvenanceSealer
{
    /**
     * EV-12: a sealer is now bound to a specific key ID as well as the
     * secret behind it. `$keyId` is what gets recorded in every seal this
     * instance produces, so a verifier reading that seal back - possibly
     * long after this key has been rotated out - knows which entry in
     * SigningKeyRing to check it against, instead of assuming whatever key
     * happens to be active at verification time.
     */
    public function __construct(
        private readonly string $keyId,
        private readonly string $signingKey,
    ) {
        if ($signingKey === '') {
            throw new \InvalidArgumentException('Signing key must not be empty.');
        }
        if ($keyId === '') {
            throw new \InvalidArgumentException('Signing key id must not be empty.');
        }
    }

    /**
     * The ordinary way to obtain a sealer for a NEW record: whichever key
     * this installation currently names as active, per SigningKeyRing.
     * Verifying an OLD record never goes through this - see verify() below,
     * which resolves the historical key itself rather than trusting
     * whatever sealer instance happens to be calling it.
     */
    public static function current(): self
    {
        return new self(SigningKeyRing::activeKeyId(), SigningKeyRing::activeKey());
    }

    public function hashMedia(string $bytes): string
    {
        // EV-13: the content digest (this) and the signing scheme below are two
        // different things - Codex's distinction. This is a plain digest and
        // goes through the one authoritative gateway; the HMAC signature is a
        // MAC scheme, not a digest algorithm, and its own rotation is EV-12's
        // concern, not this row's.
        return DigestAlgorithm::digest($bytes);
    }

    /**
     * @param  array<string,mixed>  $context  project/user/gps/weather/etc.
     */
    public function seal(
        string $mediaHash,
        array $context,
        CaptureClocks $capture,
        \DateTimeImmutable $serverNow,
        float $monotonicAtTransmit,
    ): SealedRecord {
        $monotonicInterval = $monotonicAtTransmit - $capture->monotonicAtCapture;
        $wallInterval = $serverNow->getTimestamp() - $capture->deviceWallClock->getTimestamp();
        $divergenceSeconds = abs($wallInterval - $monotonicInterval);

        $payload = [
            'media_hash' => $mediaHash,
            'context' => $context,
            'device_wall_clock' => $capture->deviceWallClock->format(DATE_ATOM),
            'monotonic_at_capture' => $capture->monotonicAtCapture,
            'monotonic_at_transmit' => $monotonicAtTransmit,
            'server_sealed_at' => $serverNow->format(DATE_ATOM),
            'clock_divergence_s' => round($divergenceSeconds, 3),
            // EV-12: recorded beside the signature it produces, not implied
            // by it - the one fact a later verifier needs to select the
            // right historical key. Part of the signed bytes below, so
            // tampering with it (claiming a different key signed this) is
            // caught the same way tampering with any other field is.
            'signing_key_id' => $this->keyId,
        ];

        $canonical = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $signature = hash_hmac('sha256', $canonical, $this->signingKey);

        return new SealedRecord($payload, $signature);
    }

    /**
     * EV-12: verification NEVER uses this sealer's own constructor key. It
     * reads the key id the record itself claims - `signing_key_id` in the
     * payload - and looks THAT key up through SigningKeyRing. This is what
     * makes rotation safe: a seal written last year under a key that has
     * since been retired still verifies today, because the verifier goes
     * and finds that historical key rather than checking the seal against
     * whichever key is active now.
     *
     * A record with no `signing_key_id` at all predates this row entirely -
     * every seal ever written before EV-12 used exactly one key, now
     * registered as SigningKeyRing::LEGACY_KEY_ID, so it is checked against
     * that, unchanged from this method's pre-EV-12 behaviour.
     *
     * An unrecognised or unconfigured key id fails closed (false), same as
     * a genuinely mismatched signature - a verifier cannot tell "signed by
     * a key I don't have" apart from "not signed correctly" without a key
     * to check against, and must not report success in that gap.
     */
    public function verify(SealedRecord $record): bool
    {
        $keyId = $record->payload['signing_key_id'] ?? SigningKeyRing::LEGACY_KEY_ID;
        $key = SigningKeyRing::keyFor(is_string($keyId) ? $keyId : null);
        if ($key === null) {
            return false;
        }

        $canonical = json_encode($record->payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        return hash_equals(hash_hmac('sha256', $canonical, $key), $record->signature);
    }

    public function verifyMedia(SealedRecord $record, string $bytes): bool
    {
        return hash_equals($record->payload['media_hash'], $this->hashMedia($bytes));
    }

    /** Confidence rendered on the face of documents (Aspect 3). */
    public function confidence(SealedRecord $record): string
    {
        $div = (float) $record->payload['clock_divergence_s'];
        if ($div <= 5.0) {
            return 'strong';
        }
        if ($div <= 300.0) {
            return 'review';
        }

        return 'flagged';
    }
}
