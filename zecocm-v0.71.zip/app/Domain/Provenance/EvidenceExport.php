<?php

namespace App\Domain\Provenance;

use Illuminate\Support\Facades\DB;

/**
 * EV-15: a package a third party can verify without ZecoCM, without our
 * servers, and without trusting us at all.
 *
 * The register filed this as a patent-claim obligation - Addendum B promises
 * customer-controlled hash-verifiable replication and in code it was two labels
 * in the licensing catalogue. Codex reframed it and the reframing is the whole
 * point:
 *
 *   THE DEFENSIBILITY COMES FROM CONTINUITY, NOT CAPTIVITY.
 *
 * A customer should be able to LEAVE ZecoCM and still prove their record. A
 * vendor whose moat is that departure destroys your evidence is selling a
 * hostage situation, and a public agency reads it exactly that way. So this is
 * an asset rather than a concession, and it is built to be reimplemented by
 * somebody else in an afternoon.
 *
 * WHAT THE PACKAGE IS FOR, stated in the package itself so it cannot be quoted
 * out of context: it establishes whether the exported record is internally
 * consistent with its own manifest and unaltered since export. It establishes
 * nothing whatsoever about whether the underlying facts are true. Those are
 * different questions and a package that let people confuse them would be worse
 * than no package, because it would be quoted as proof of the wrong thing.
 *
 * SCOPE IS DECLARED, because absence of a record from a scoped export proves
 * nothing about whether the record exists. An export of one project's payment
 * applications is silent on everything else, and silence that reads as absence
 * is how a partial export becomes a false statement.
 */
final class EvidenceExport
{
    public const FORMAT = 'zecocm-evidence-package';
    public const FORMAT_VERSION = '1.0';

    /**
     * Build the manifest for a scoped export.
     *
     * @param  array<string,mixed>  $scope  what this export covers and, by
     *   implication, everything it does not
     * @return array<string,mixed>
     */
    public static function manifest(int $tenantId, array $scope, array $chains = []): array
    {
        $records = [];
        $chainSummaries = [];

        foreach ($chains as $chainKey => $groupValues) {
            $spec = ChainSpec::all()[$chainKey] ?? null;
            if ($spec === null) {
                continue;
            }

            foreach ((array) $groupValues as $groupValue) {
                $rows = DB::table($spec->table)
                    ->where($spec->groupColumn, $groupValue)
                    ->orderBy($spec->sequenceColumn)
                    ->get();

                $entries = [];
                foreach ($rows as $row) {
                    $entries[] = [
                        'sequence' => (int) $row->{$spec->sequenceColumn},
                        'hash' => $row->{$spec->hashColumn},
                        'previous_hash' => $row->{$spec->previousHashColumn},
                        // Without this the verifier cannot know WHICH algorithm
                        // produced the hash, and Codex's rule is that an unknown
                        // canonicalization version means CANNOT VERIFY rather
                        // than a best-effort fallback. A fallback that guesses
                        // is a verifier that reports success on records it did
                        // not actually check.
                        'hash_version' => $row->hash_version ?? null,
                        // EV-13: the encoding version above says how the payload
                        // became bytes; this says which primitive turned those
                        // bytes into a digest. Both are independently required -
                        // an external verifier that only knew one could recompute
                        // the wrong thing and call it a mismatch.
                        'hash_algorithm' => $row->hash_algorithm ?? null,
                        'subject_hash' => $spec->subjectHashColumn !== null
                            ? ($row->{$spec->subjectHashColumn} ?? null)
                            : null,
                        'subject_hash_algorithm' => $spec->subjectHashColumn !== null
                            ? ($row->subject_hash_algorithm ?? null)
                            : null,
                    ];
                }

                $anchor = ChainAnchor::expected($spec->name, $groupValue);

                $chainSummaries[] = [
                    'chain' => $spec->name,
                    'chain_key' => $chainKey,
                    'group' => $groupValue,
                    'record_count' => count($entries),
                    'head' => $entries === [] ? null : end($entries)['hash'],
                    // The outside witness. A chain proves the records still
                    // present are unaltered and in order; it proves nothing
                    // about records that are no longer there, which is what the
                    // anchor exists to catch.
                    'anchor' => $anchor === null ? null : [
                        'record_count' => $anchor['record_count'],
                        'head_hash' => $anchor['head_hash'],
                    ],
                    'anchored' => $anchor !== null,
                    'entries' => $entries,
                ];

                $records[] = $spec->name.'#'.$groupValue;
            }
        }

        $manifest = [
            'format' => self::FORMAT,
            'format_version' => self::FORMAT_VERSION,
            'exported_at' => now()->toIso8601String(),
            'tenant_id' => $tenantId,

            // Declared, not implied. An export of one project's payment
            // applications says nothing about anything else, and a verifier
            // that let absence read as non-existence would turn a partial
            // export into a false statement.
            'scope' => $scope + [
                'completeness' => 'This package contains only what the scope above describes. The absence of a record '
                    .'from this package is NOT evidence that the record does not exist.',
            ],

            'chains' => $chainSummaries,
            'record_identifiers' => $records,

            // The honest statement about our own signing, machine-readable so
            // it cannot be dropped from a summary. Register row B1 is open: the
            // seals are HMAC with one shared secret that both signs and
            // verifies, which means they establish that the record is unaltered
            // and CANNOT establish that ZecoCM did not produce it.
            'signing' => [
                'scheme' => 'hmac-sha256',
                'signer_independence' => false,
                'limitation' => 'Seals in this package are symmetric (HMAC). They establish that the sealed content is '
                    .'unaltered relative to the seal. They do NOT establish independent signer identity, because the '
                    .'key that verifies a seal is the same key that could produce one. A party wishing to establish '
                    .'that ZecoCM itself did not manufacture this record needs asymmetric signing, which this version '
                    .'does not have.',
            ],

            'canonicalization' => [
                'current' => CanonicalPayload::CURRENT,
                'rule' => 'Every record carries the canonicalization version its hash was produced under. A record '
                    .'whose version is absent or unrecognised is reported as CANNOT VERIFY. There is no best-effort '
                    .'fallback: a verifier that guesses the algorithm reports success on records it did not check.',
            ],

            // EV-13: a second, independent axis from canonicalization above.
            // Canonicalization says how a payload became bytes; this says which
            // primitive turned those bytes into a digest. An external verifier
            // needs both, and needs to know it is entitled to refuse when either
            // one is missing or unrecognised - the manifest hash itself included.
            'hashing' => [
                'current' => DigestAlgorithm::CURRENT,
                'known' => DigestAlgorithm::KNOWN,
                'manifest_hash_algorithm' => DigestAlgorithm::CURRENT,
                'rule' => 'Every stored digest in this package carries the algorithm that produced it, independently '
                    .'of its canonicalization version. A digest whose algorithm is absent or unrecognised is reported '
                    .'as CANNOT VERIFY. There is no fallback to the current algorithm and no attempt to try several '
                    .'algorithms until one matches - either of those would turn corruption into apparent validity.',
            ],

            'establishes' => [
                'That the records in this package are internally consistent with this manifest.',
                'That each chain links and is in sequence, and where it first fails if it does not.',
                'That the record count and head hash match the outside anchor, where one exists.',
                'That the subject of each chain has not been altered since its last recorded event, where a subject '
                    .'fingerprint was written.',
            ],

            // Page one of the spec, and in the manifest as well so that a
            // machine reading only the JSON cannot miss it.
            'does_not_establish' => [
                'That the underlying project facts are true.',
                'That any human determination recorded here was legally correct.',
                'That a document is authentic merely because ZecoCM held it.',
                'That a record absent from this package never existed.',
                'That the HMAC-era seals establish independent signer identity.',
                'That cryptographic integrity establishes legal admissibility. Those are different questions.',
            ],
        ];

        // The package hash is computed over everything above, so that the
        // statement of limitations is inside the thing being verified rather
        // than beside it. Removing the caveats changes the hash.
        $manifest['manifest_hash'] = self::hashOf($manifest);

        return $manifest;
    }

    /**
     * Deterministic across languages, which is what makes the spec
     * reimplementable. Sorted keys, no float formatting, no locale.
     */
    public static function hashOf(array $manifest): string
    {
        unset($manifest['manifest_hash']);

        return DigestAlgorithm::digest(self::canonicalJson($manifest));
    }

    public static function canonicalJson(mixed $value): string
    {
        if (is_array($value)) {
            $isList = array_is_list($value);

            if (! $isList) {
                ksort($value);
            }

            $parts = [];
            foreach ($value as $key => $item) {
                $parts[] = $isList
                    ? self::canonicalJson($item)
                    : json_encode((string) $key, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR).':'.self::canonicalJson($item);
            }

            return ($isList ? '[' : '{').implode(',', $parts).($isList ? ']' : '}');
        }

        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }
        if ($value === null) {
            return 'null';
        }
        if (is_int($value)) {
            return (string) $value;
        }

        return json_encode((string) $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }
}
