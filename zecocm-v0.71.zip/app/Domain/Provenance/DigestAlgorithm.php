<?php

namespace App\Domain\Provenance;

/**
 * EV-13: the digest primitive itself was never versioned.
 *
 * `CanonicalPayload` already versions how a payload becomes bytes (V1 legacy,
 * V2 typed-normalised). What it does not version is the last step - `hash('sha256',
 * ...)` was called literally, in eight separate places across this codebase
 * (chain events, chain anchors, canonicalization transitions, provenance
 * seals, evidence export manifests, subject fingerprints), with no record
 * anywhere of which primitive produced a given stored digest.
 *
 * That is invisible until the day it matters: if sha256 ever needed to be
 * rotated - a disclosed weakness, a compliance requirement, simply moving to a
 * stronger primitive - there would be no way to do it without either silently
 * breaking verification of every existing record with no record of why, or a
 * verifier that guesses which algorithm a legacy digest used. A verifier that
 * guesses reports success on records it did not actually check, which is worse
 * than reporting nothing (the same principle `CanonicalPayload::KNOWN_VERSIONS`
 * already enforces for encoding - this enforces it one layer over, for the
 * digest itself).
 *
 * This is the one place in the codebase allowed to call PHP's `hash()` for an
 * evidentiary digest. Nothing else should.
 */
final class DigestAlgorithm
{
    public const SHA256 = 'sha256';

    public const CURRENT = self::SHA256;

    /**
     * Every algorithm a verifier is entitled to recognise. A digest whose
     * algorithm is absent or not in this list is CANNOT_VERIFY, never a
     * guess and never a fallback to today's default.
     */
    public const KNOWN = [self::SHA256];

    public const MATCH = 'match';

    public const MISMATCH = 'mismatch';

    public const CANNOT_VERIFY = 'cannot_verify';

    public static function digest(string $bytes, string $algorithm = self::CURRENT): string
    {
        if (! in_array($algorithm, self::KNOWN, true)) {
            throw new \InvalidArgumentException(
                "Cannot produce a digest with unrecognised algorithm '{$algorithm}'. "
                .'Known algorithms: '.implode(', ', self::KNOWN).'.'
            );
        }

        return hash($algorithm, $bytes);
    }

    /**
     * Never guesses from digest length, never falls back to sha256, never
     * tries several algorithms until one matches - any of those would turn
     * corruption into apparent validity.
     */
    public static function verify(string $bytes, string $expectedDigest, ?string $algorithm): string
    {
        if ($algorithm === null || ! in_array($algorithm, self::KNOWN, true)) {
            return self::CANNOT_VERIFY;
        }

        return hash_equals($expectedDigest, hash($algorithm, $bytes)) ? self::MATCH : self::MISMATCH;
    }
}
