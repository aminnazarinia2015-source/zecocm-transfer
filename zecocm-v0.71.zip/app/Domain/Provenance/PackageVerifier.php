<?php

namespace App\Domain\Provenance;

/**
 * The reference verifier: five phases, in order, and six things it refuses to
 * conclude.
 *
 * It reads a manifest and nothing else. No database, no ZecoCM installation, no
 * network, no key material - because the party running it is frequently the
 * party trying to disprove the record, and a verifier that needs anything from
 * us is not a verifier they will accept.
 *
 * It exists here mainly as PROOF THAT THE SPECIFICATION IS IMPLEMENTABLE. If
 * the reference implementation needed anything the specification does not
 * describe, the specification is wrong and somebody reimplementing it in Python
 * on the other side of a dispute would find out the hard way.
 *
 * THE ORDER MATTERS. Each phase can only run if the one before it held: there
 * is no point checking chain linkage on records whose payload hashes could not
 * be recomputed, and reporting a linkage failure on top of an unverifiable
 * payload tells somebody to fix the wrong thing.
 */
final class PackageVerifier
{
    public const PASS = 'pass';
    public const FAIL = 'fail';
    public const CANNOT_VERIFY = 'cannot_verify';

    /** Page one. Not a footnote, not a help page, not a licence clause. */
    public const DOES_NOT_ESTABLISH = [
        'That the underlying project facts are true.',
        'That any human determination recorded here was legally correct.',
        'That a document is authentic merely because ZecoCM held it.',
        'That a record absent from this package never existed.',
        'That the HMAC-era seals establish independent signer identity.',
        'That cryptographic integrity establishes legal admissibility. Those are different questions.',
    ];

    /**
     * @param  array<string,mixed>  $manifest
     * @return array<string,mixed>
     */
    public static function verify(array $manifest): array
    {
        $findings = [];
        $phases = [];

        // ---- Phase 1: the manifest describes itself -------------------------
        $format = $manifest['format'] ?? null;

        if ($format !== EvidenceExport::FORMAT) {
            return self::result(self::CANNOT_VERIFY, [
                ['phase' => 'manifest', 'status' => self::CANNOT_VERIFY,
                    'finding' => 'This is not a ZecoCM evidence package, or its format field has been removed.'],
            ], []);
        }

        $declared = $manifest['manifest_hash'] ?? null;
        $recomputed = EvidenceExport::hashOf($manifest);

        if ($declared === null) {
            $phases[] = self::phase('manifest', self::CANNOT_VERIFY,
                'The manifest carries no hash of itself, so alteration of the manifest cannot be detected.');
        } elseif (! hash_equals((string) $declared, $recomputed)) {
            // Everything downstream is now meaningless: the list of what should
            // be here is itself untrustworthy.
            return self::result(self::FAIL, [
                self::phase('manifest', self::FAIL,
                    'The manifest does not hash to its declared value. It has been altered since export, so nothing '
                    .'it claims about the records can be relied on - including the list of which records should be here.'),
            ], []);
        } else {
            $phases[] = self::phase('manifest', self::PASS, 'The manifest is unaltered since export.');
        }

        // ---- Phase 2: canonicalization AND digest algorithm are known, per
        // record. Two independent axes (EV-13): the encoding version says how
        // a payload became bytes, the algorithm says what turned those bytes
        // into a digest. Both have to be recognised before a content hash can
        // be called recomputable - a known encoding under an unknown algorithm
        // is exactly as unverifiable as an unknown encoding.
        $unknownVersions = 0;
        $unknownAlgorithms = 0;
        $totalRecords = 0;

        foreach ((array) ($manifest['chains'] ?? []) as $chain) {
            foreach ((array) ($chain['entries'] ?? []) as $entry) {
                $totalRecords++;
                $version = $entry['hash_version'] ?? null;
                $algorithm = $entry['hash_algorithm'] ?? null;

                if ($version === null || ! in_array($version, CanonicalPayload::KNOWN_VERSIONS, true)) {
                    $unknownVersions++;
                }
                if ($algorithm === null || ! in_array($algorithm, DigestAlgorithm::KNOWN, true)) {
                    $unknownAlgorithms++;
                }
            }
        }

        if ($unknownVersions > 0 || $unknownAlgorithms > 0) {
            $phases[] = self::phase('canonicalization', self::CANNOT_VERIFY,
                $unknownVersions.' of '.$totalRecords.' record(s) carry no recognised canonicalization version, and '
                .$unknownAlgorithms.' of '.$totalRecords.' carry no recognised digest algorithm. Their payload hashes '
                .'CANNOT be recomputed and are not verified here. There is deliberately no best-effort fallback: a '
                .'verifier that guessed either the encoding or the algorithm would report success on records it did '
                .'not check. Linkage and sequence are still verified for those records; content integrity is not.');
        } else {
            $phases[] = self::phase('canonicalization', self::PASS,
                'Every record declares a recognised canonicalization version and digest algorithm.');
        }

        // ---- Phase 3 and 4: chain linkage -----------------------------------
        $chainResults = [];

        foreach ((array) ($manifest['chains'] ?? []) as $chain) {
            $chainResults[] = self::verifyChain($chain);
        }

        $brokenChains = array_filter($chainResults, fn ($c) => $c['status'] === self::FAIL);

        $phases[] = self::phase('linkage',
            $brokenChains === [] ? self::PASS : self::FAIL,
            $brokenChains === []
                ? count($chainResults).' chain(s) link correctly and are in sequence.'
                : count($brokenChains).' of '.count($chainResults).' chain(s) are broken.');

        // ---- Phase 5: the outside witness -----------------------------------
        $unanchored = array_filter($chainResults, fn ($c) => ! $c['anchored']);

        $phases[] = self::phase('anchor',
            $unanchored === [] ? self::PASS : self::CANNOT_VERIFY,
            $unanchored === []
                ? 'Every chain matches the record count and head the anchor witnessed.'
                : count($unanchored).' chain(s) carry no anchor, so records may have been removed from the end without '
                    .'leaving a trace inside the chain. What remains links correctly, which is exactly why this cannot '
                    .'be seen from inside.');

        $status = match (true) {
            in_array(self::FAIL, array_column($phases, 'status'), true) => self::FAIL,
            in_array(self::CANNOT_VERIFY, array_column($phases, 'status'), true) => self::CANNOT_VERIFY,
            default => self::PASS,
        };

        return self::result($status, $phases, $chainResults, $manifest);
    }

    /**
     * @param  array<string,mixed>  $chain
     * @return array<string,mixed>
     */
    private static function verifyChain(array $chain): array
    {
        $entries = (array) ($chain['entries'] ?? []);
        $name = (string) ($chain['chain'] ?? 'unnamed chain');
        $group = $chain['group'] ?? null;

        $anchor = $chain['anchor'] ?? null;
        $anchored = false;
        $findings = [];
        $firstInvalid = null;

        if ($entries === []) {
            // The worst case, and the one that escapes a naive verifier: an
            // empty chain is indistinguishable from a chain that never existed
            // unless something outside it remembers otherwise.
            if ($anchor !== null && (int) $anchor['record_count'] > 0) {
                return self::chainResult($name, $group, self::FAIL, 0, 0, true, [
                    $anchor['record_count'].' record(s) the anchor witnessed are not present. The chain is now empty, '
                    .'which from inside is indistinguishable from a chain that never existed.',
                ]);
            }

            return self::chainResult($name, $group, self::CANNOT_VERIFY, 0, 0, $anchor !== null,
                ['No records, and no anchor to say whether there should have been any.']);
        }

        $previousHash = null;
        $seen = [];
        $index = 0;

        foreach ($entries as $entry) {
            $index++;
            $sequence = (int) ($entry['sequence'] ?? 0);

            if (isset($seen[$sequence])) {
                $firstInvalid = $sequence;
                $findings[] = 'Duplicate sequence '.$sequence.'.';
                break;
            }
            $seen[$sequence] = true;

            if ($index === 1) {
                // Genesis. An earliest surviving record that names a
                // predecessor means the front of the chain has been removed.
                if (($entry['previous_hash'] ?? null) !== null) {
                    $firstInvalid = $sequence;
                    $findings[] = 'The earliest record present names a predecessor that is not here. Records have been '
                        .'removed from the START of the chain.';
                    break;
                }
            } elseif (($entry['previous_hash'] ?? null) !== $previousHash) {
                $firstInvalid = $sequence;
                $findings[] = 'Linkage broken at sequence '.$sequence.': this record names a different predecessor '
                    .'than the record before it.';
                break;
            }

            $previousHash = $entry['hash'] ?? null;
        }

        $head = end($entries)['hash'] ?? null;
        $count = count($entries);

        if ($firstInvalid !== null) {
            $downstream = count(array_filter($entries, fn ($e) => (int) ($e['sequence'] ?? 0) > $firstInvalid));
            $findings[] = $downstream.' later record(s) are DOWNSTREAM-UNTRUSTED. Each attests to a predecessor whose '
                .'content can no longer be established, so none of them is evidence of anything - however internally '
                .'consistent it looks.';

            return self::chainResult($name, $group, self::FAIL, $count, $downstream, $anchor !== null, $findings);
        }

        // The outside witness, checked last because it answers a question the
        // chain structurally cannot: what is no longer here.
        if ($anchor !== null) {
            $anchored = true;

            if ($count < (int) $anchor['record_count']) {
                $findings[] = ((int) $anchor['record_count'] - $count).' record(s) the anchor witnessed are missing. '
                    .'What remains links and hashes correctly, which is precisely why this cannot be seen from inside '
                    .'the chain.';

                return self::chainResult($name, $group, self::FAIL, $count, 0, true, $findings);
            }

            if ($head !== null && $count === (int) $anchor['record_count'] && $head !== $anchor['head_hash']) {
                $findings[] = 'The head does not match the head the anchor witnessed although the count agrees. '
                    .'A record was REPLACED rather than removed.';

                return self::chainResult($name, $group, self::FAIL, $count, 0, true, $findings);
            }
        } else {
            $findings[] = 'No anchor was written for this chain, so its length cannot be checked and records may have '
                .'been removed from the end without trace.';
        }

        return self::chainResult($name, $group, $anchored ? self::PASS : self::CANNOT_VERIFY,
            $count, 0, $anchored, $findings);
    }

    private static function chainResult(string $name, mixed $group, string $status, int $records,
        int $downstream, bool $anchored, array $findings): array
    {
        return compact('name', 'group', 'status', 'records', 'downstream', 'anchored', 'findings');
    }

    private static function phase(string $phase, string $status, string $finding): array
    {
        return compact('phase', 'status', 'finding');
    }

    /** @return array<string,mixed> */
    private static function result(string $status, array $phases, array $chains, array $manifest = []): array
    {
        return [
            'status' => $status,
            'phases' => $phases,
            'chains' => $chains,
            'scope' => $manifest['scope'] ?? null,
            'signing' => $manifest['signing'] ?? null,
            // Repeated in the OUTPUT, not only in the manifest, because the
            // output is what somebody pastes into a report.
            'does_not_establish' => self::DOES_NOT_ESTABLISH,
            'statement' => match ($status) {
                self::PASS => 'The exported record is internally consistent with its manifest and unaltered since '
                    .'export. This says nothing about whether the facts it records are true.',
                self::FAIL => 'The exported record is NOT internally consistent with its manifest. See the findings.',
                default => 'Parts of this package could not be verified. What could not be checked is listed, and is '
                    .'not reported as either sound or unsound.',
            },
        ];
    }
}
