<?php

namespace App\Domain\Provenance;

use Illuminate\Support\Facades\DB;

/**
 * The outside witness to how long a chain is.
 *
 * Deliberately NOT tenant-scoped, and deliberately one chain across every
 * ledger. Both of those are the point: an attacker who can delete a record in
 * their own tenant's chain would have to rewrite anchors belonging to chains
 * they cannot see in order to hide it.
 *
 * WHAT THIS DOES NOT DO, stated precisely, because a security claim that is
 * approximately true is worse than none.
 *
 * Deleting a record and its matching anchor together hides the deletion IF AND
 * ONLY IF that anchor is the last row in the whole anchors table. Any anchor
 * written afterwards - for any chain, in any tenant - names the deleted anchor's
 * hash as its predecessor, so removing it breaks the anchor chain and the
 * verifier refuses to quote a witness whose own account is inconsistent.
 *
 * So the residual window is exactly one row wide and closes the moment any other
 * append happens anywhere in the system. On a live installation that is seconds.
 * On an idle one it is real, and an attacker who deletes the most recent event
 * in the entire system plus its anchor leaves nothing behind.
 *
 * Closing that last row would need an anchor for the anchors, and one for those,
 * without end. The regress is not closed here and pretending otherwise would be
 * the same kind of false statement this whole subsystem exists to prevent. What
 * the anchor does buy: accidental loss - the cascade delete, the cleanup script,
 * the restored backup - becomes impossible to miss, and deliberate removal of
 * anything but the very newest record requires rewriting a chain that spans
 * tenants the attacker cannot see.
 *
 * Nothing here is confidential. An anchor row is a chain name, a group id, a
 * count and two hashes. It reveals that a chain exists and how many events it
 * has - which is why the group is stored as an opaque string and never joined
 * back to anything readable.
 */
final class ChainAnchor
{
    /** Record the head of a chain immediately after an append. */
    public static function record(string $chainName, string|int $group, int $recordCount, string $headHash): void
    {
        $previous = DB::table('chain_anchors')->orderByDesc('id')->value('anchor_hash');

        $payload = [
            'chain_name' => $chainName,
            'chain_group' => (string) $group,
            'record_count' => $recordCount,
            'head_hash' => $headHash,
            'previous_anchor_hash' => $previous,
            'created_at' => now(),
        ];

        $payload['anchor_hash'] = DigestAlgorithm::digest(json_encode([
            $payload['chain_name'], $payload['chain_group'], $payload['record_count'],
            $payload['head_hash'], $payload['previous_anchor_hash'],
        ], JSON_THROW_ON_ERROR));
        // EV-13: recorded beside the digest, not implied by it.
        $payload['anchor_hash_algorithm'] = DigestAlgorithm::CURRENT;

        DB::table('chain_anchors')->insert($payload);
    }

    /**
     * What the anchors say this chain should look like. Null when no anchor was
     * ever written - which is itself worth saying, because a chain with events
     * and no anchors predates this witness and cannot be checked for length.
     *
     * @return array{record_count: int, head_hash: string}|null
     */
    public static function expected(string $chainName, string|int $group): ?array
    {
        // The HIGHEST count ever witnessed, not the most recent one.
        //
        // My first version took the latest anchor, and my own test broke it in
        // one move: delete the last event AND the last anchor, and the previous
        // anchor - which says three records - agrees with the three records that
        // remain. The tail-deletion problem reappears one level up, which is
        // exactly the shape of the bug the anchor exists to fix.
        //
        // Taking the maximum means hiding a deletion requires deleting EVERY
        // anchor for the chain, and a chain with records and no anchors at all
        // is itself reported.
        $row = DB::table('chain_anchors')
            ->where('chain_name', $chainName)
            ->where('chain_group', (string) $group)
            ->orderByDesc('record_count')
            ->orderByDesc('id')
            ->first(['record_count', 'head_hash']);

        return $row === null ? null : ['record_count' => (int) $row->record_count, 'head_hash' => $row->head_hash];
    }

    /**
     * Verify the anchor chain itself. If this is broken, every length claim it
     * makes is worthless, and the verifier has to say so rather than quoting it.
     *
     * @return array{status: string, records: int, first_invalid_id: ?int}
     */
    public static function verifySelf(): array
    {
        $previous = null;
        $count = 0;

        foreach (DB::table('chain_anchors')->orderBy('id')->cursor() as $row) {
            $count++;

            $bytes = json_encode([
                $row->chain_name, $row->chain_group, (int) $row->record_count,
                $row->head_hash, $previous,
            ], JSON_THROW_ON_ERROR);

            // EV-13: an anchor whose algorithm is absent or unrecognised is
            // reported as such, not silently checked against today's default -
            // the same fail-closed rule the ledger verifier applies to events.
            $algorithm = $row->anchor_hash_algorithm ?? null;
            $outcome = DigestAlgorithm::verify($bytes, $row->anchor_hash, $algorithm);

            if ($outcome === DigestAlgorithm::CANNOT_VERIFY) {
                return ['status' => 'cannot_verify', 'records' => $count, 'first_invalid_id' => (int) $row->id];
            }

            if ($row->previous_anchor_hash !== $previous || $outcome === DigestAlgorithm::MISMATCH) {
                return ['status' => 'broken', 'records' => $count, 'first_invalid_id' => (int) $row->id];
            }

            $previous = $row->anchor_hash;
        }

        return ['status' => 'intact', 'records' => $count, 'first_invalid_id' => null];
    }
}
