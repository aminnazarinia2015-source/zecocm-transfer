<?php

namespace App\Domain\Provenance;

use App\Models\CanonicalizationFinding;
use App\Models\CanonicalizationTransitionRecord;
use App\Models\User;
use RuntimeException;

/**
 * Who is allowed to say why the evidence cannot be checked.
 *
 * The verifier detects and proposes. A named steward explains. The split is not
 * ceremony - it is the difference between a fact and an interpretation, and the
 * interpretation is the part that matters to anyone reading the record later.
 *
 * A machine can honestly state: historical serialization cannot be reproduced
 * under the current canonicalization protocol.
 *
 * A machine cannot honestly state: this was only a writer defect and no
 * tampering occurred. That sentence requires knowing what did NOT happen, and
 * the only check that could establish it is the one that is unavailable. A
 * system that writes it anyway is authoring its own alibi.
 *
 * So findings are created automatically and are inert. Nothing about them
 * explains anything. Until a steward signs a transition record, the honest
 * status of the condition is "detected, unexplained" - and the verifier says so
 * rather than filling the silence itself.
 */
final class CanonicalizationTransition
{
    public const CAUSE_WRITER_DEFECT = 'writer_serialization_defect';
    public const CAUSE_PROTOCOL_CHANGE = 'canonicalization_protocol_change';
    public const CAUSE_UNDETERMINED = 'undetermined';
    public const CAUSE_UNDER_INVESTIGATION = 'under_investigation';

    /**
     * System-generated, facts only. Idempotent per chain and detection moment so
     * that running the verifier twice does not manufacture a second condition.
     */
    public static function record(array $observation): CanonicalizationFinding
    {
        foreach (['chain_name', 'chain_group', 'record_count', 'mismatch_type',
            'linkage_result', 'content_verification_result', 'verifier_version', 'detected_at'] as $required) {
            if (! array_key_exists($required, $observation)) {
                throw new RuntimeException("A canonicalization finding cannot omit {$required}.");
            }
        }

        // Re-running the verifier re-observes the same condition; it does not
        // create a second one. The first detection time is the one that matters
        // and is never moved forward.
        return CanonicalizationFinding::firstOrCreate([
            'chain_name' => $observation['chain_name'],
            'chain_group' => (string) $observation['chain_group'],
            'mismatch_type' => $observation['mismatch_type'],
        ], $observation);
    }

    /**
     * Human-authored. Takes the finding as immutable input and adds the part a
     * machine may not supply.
     */
    public static function explain(
        CanonicalizationFinding $finding,
        User $steward,
        string $authorRole,
        string $causeClassification,
        string $narrative,
        string $canonicalizationVersion,
        ?string $supportingReleaseEvidence = null,
        ?string $diagnosticRecomputedHash = null,
    ): CanonicalizationTransitionRecord {
        if (trim($narrative) === '') {
            throw new RuntimeException('A transition record without a narrative explains nothing. Say what you concluded and why.');
        }

        if (trim($authorRole) === '') {
            throw new RuntimeException('Record the role the steward held when they signed this. "Somebody at the company" is not accountability.');
        }

        if (! in_array($causeClassification, [self::CAUSE_WRITER_DEFECT, self::CAUSE_PROTOCOL_CHANGE,
            self::CAUSE_UNDETERMINED, self::CAUSE_UNDER_INVESTIGATION], true)) {
            throw new RuntimeException('Unknown cause classification. Undetermined is an available and respectable answer.');
        }

        if ($finding->isExplained()) {
            throw new RuntimeException('This finding already carries a transition record. A conclusion that changed is a new record, not an edited one.');
        }

        $payload = [
            'canonicalization_finding_id' => $finding->id,
            'authored_by' => $steward->id,
            'author_role' => $authorRole,
            'cause_classification' => $causeClassification,
            'explanatory_narrative' => $narrative,
            'supporting_release_evidence' => $supportingReleaseEvidence,
            'canonicalization_version_introduced' => $canonicalizationVersion,
            // Explicitly non-authoritative, and never written into the chain.
            // What the payload would hash to today is a diagnostic, not a seal.
            'diagnostic_recomputed_hash' => $diagnosticRecomputedHash,
            'authored_at' => now(),
        ];

        // EV-13: routed through the one authoritative digest gateway. Not
        // given its own hash_algorithm column - unlike chain events, anchors,
        // and exports, this record's hash is never read back and re-verified
        // against a stored expectation anywhere in the codebase; it is a
        // write-once seal on an already-immutable row. Adding a column nothing
        // ever checks would document a fact nobody uses rather than closing a
        // real gap.
        $payload['record_hash'] = DigestAlgorithm::digest(json_encode($payload, JSON_THROW_ON_ERROR));

        return CanonicalizationTransitionRecord::create($payload);
    }
}
