<?php

namespace App\Domain\Integrations;

use App\Domain\Ops\PlatformSecretStore;

final class ProviderRegistry
{
    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        return [
            'autodesk' => self::provider(
                'Autodesk Construction Cloud / APS',
                ['plans', 'files', 'models', 'issues', 'webhooks'],
                ['AUTODESK_CLIENT_ID', 'AUTODESK_CLIENT_SECRET', 'AUTODESK_REDIRECT_URI'],
                'Three-legged OAuth and Autodesk Platform Services access are required. Model translation, federation and clash workflows require the applicable Autodesk products and customer permissions.'
            ),
            'procore' => self::provider(
                'Procore',
                ['documents', 'drawings', 'rfis', 'submittals', 'projects', 'webhooks'],
                ['PROCORE_CLIENT_ID', 'PROCORE_CLIENT_SECRET', 'PROCORE_REDIRECT_URI'],
                'A registered OAuth application, company/project authorization and approved API scopes are required. Sync direction and system-of-record ownership must be selected per object type.'
            ),
            'bluebeam' => self::provider(
                'Bluebeam',
                ['pdf_sessions', 'markups', 'documents'],
                ['BLUEBEAM_CLIENT_ID', 'BLUEBEAM_CLIENT_SECRET', 'BLUEBEAM_REDIRECT_URI'],
                'Bluebeam partner/API product approval is required. ZecoCM will not advertise Studio or markup synchronization until the contracted API exposes and accepts the required operations.'
            ),
            'microsoft365' => self::provider(
                'Microsoft 365 / SharePoint / OneDrive',
                ['files', 'folders', 'permissions', 'webhooks'],
                ['MICROSOFT365_CLIENT_ID', 'MICROSOFT365_CLIENT_SECRET', 'MICROSOFT365_TENANT_ID', 'MICROSOFT365_REDIRECT_URI'],
                'An Entra application and administrator consent are required. Use site-scoped least privilege where possible; broad Graph file permissions require an explicit security decision.'
            ),
        ];
    }

    /** @return array<string,mixed> */
    public static function publicStatus(string $key, array $definition): array
    {
        $missing = array_values(array_filter($definition['required_configuration'], fn ($name) => self::value($name) === ''));

        return [
            'key' => $key,
            'label' => $definition['label'],
            'capabilities' => $definition['capabilities'],
            'authorization' => 'oauth2',
            'configuration_ready' => $missing === [],
            'missing_configuration' => $missing,
            'connection_state' => 'not_connected',
            'requirements_note' => $definition['requirements_note'],
        ];
    }

    /** @return array<string,mixed> */
    private static function provider(string $label, array $capabilities, array $required, string $note): array
    {
        return ['label' => $label, 'capabilities' => $capabilities, 'required_configuration' => $required, 'requirements_note' => $note];
    }

    private static function value(string $name): string
    {
        $configMap = [
            'AUTODESK_CLIENT_ID' => 'integrations.autodesk.client_id', 'AUTODESK_CLIENT_SECRET' => 'integrations.autodesk.client_secret', 'AUTODESK_REDIRECT_URI' => 'integrations.autodesk.redirect_uri',
            'PROCORE_CLIENT_ID' => 'integrations.procore.client_id', 'PROCORE_CLIENT_SECRET' => 'integrations.procore.client_secret', 'PROCORE_REDIRECT_URI' => 'integrations.procore.redirect_uri',
            'BLUEBEAM_CLIENT_ID' => 'integrations.bluebeam.client_id', 'BLUEBEAM_CLIENT_SECRET' => 'integrations.bluebeam.client_secret', 'BLUEBEAM_REDIRECT_URI' => 'integrations.bluebeam.redirect_uri',
            'MICROSOFT365_CLIENT_ID' => 'integrations.microsoft365.client_id', 'MICROSOFT365_CLIENT_SECRET' => 'integrations.microsoft365.client_secret', 'MICROSOFT365_TENANT_ID' => 'integrations.microsoft365.tenant_id', 'MICROSOFT365_REDIRECT_URI' => 'integrations.microsoft365.redirect_uri',
        ];
        $fallback = (string) config($configMap[$name] ?? '', '');

        return str_ends_with($name, '_SECRET')
            ? PlatformSecretStore::resolve($name, $fallback)
            : $fallback;
    }
}
