<?php

namespace App\Domain\Identity;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;

/**
 * Creates passwordless onboarding material without exposing a usable secret.
 *
 * New accounts receive a high-entropy, unknown placeholder hash and a signed,
 * expiring, one-time password setup URL. The URL becomes unusable as soon as
 * SetPasswordController records password_set_at.
 */
final class PasswordSetupInvitation
{
    public static function placeholderHash(): string
    {
        return Hash::make(bin2hex(random_bytes(32)));
    }

    public static function url(User $user): string
    {
        return URL::temporarySignedRoute(
            'onboarding.password.show',
            now()->addDays(7),
            ['user' => $user->id],
        );
    }
}
