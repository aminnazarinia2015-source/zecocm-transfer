<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14B: one state transition in a tombstone's execution history.
 *
 * EvidenceTombstone itself is append-only (EV-14A) - its own `state` column
 * can only ever be AUTHORIZED_PENDING_EXECUTION, forever. Execution progress
 * lives here instead, one row per transition, resolved the same way
 * HoldStatus resolves hold state: the latest event for a tombstone_id wins,
 * never a mutable "current state" field on the tombstone itself. See
 * EvidenceDestructionExecutor::currentState().
 */
class EvidenceTombstoneExecutionEvent extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'evidence_tombstone_id', 'state', 'actor_id', 'detail', 'occurred_at',
    ];

    protected $casts = [
        'detail' => 'array',
        'occurred_at' => 'immutable_datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Tombstone execution events are append-only; a new state is a new event, never an edit.'));
        static::deleting(fn () => throw new \LogicException('Tombstone execution events are append-only and cannot be deleted.'));
    }
}
