<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleActivityResource extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'schedule_activity_id', 'resource_code', 'resource_name',
        'resource_type', 'allocation_units',
    ];
}
