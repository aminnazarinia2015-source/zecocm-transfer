<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * A contractor's labor/equipment hours for a pay period, as its own
 * first-class record - not a hidden sub-array of a Daily Report submission.
 * See database/migrations/2026_08_27_070000_create_time_cards_table.php.
 */
class TimeCard extends Model
{
    use BelongsToTenant;

    public const STATUS_SUBMITTED = 'submitted';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';

    protected $fillable = [
        'tenant_id', 'project_id', 'submitted_by', 'pay_period_start', 'pay_period_end',
        'status', 'submitted_at', 'approved_by', 'approved_at', 'determination', 'edit_history',
    ];

    protected $casts = [
        'pay_period_start' => 'date',
        'pay_period_end' => 'date',
        'submitted_at' => 'datetime',
        'approved_at' => 'datetime',
        'edit_history' => 'array',
    ];

    public function lines()
    {
        return $this->hasMany(TimeCardLine::class);
    }

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function submittedBy()
    {
        return $this->belongsTo(User::class, 'submitted_by');
    }

    public function approvedBy()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function totalHours(): string
    {
        return (string) $this->lines()->sum('hours');
    }
}
