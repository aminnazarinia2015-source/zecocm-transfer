<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleCalendar extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $fillable = [
        'tenant_id', 'project_id', 'schedule_version_id', 'inherits_calendar_id',
        'external_uid', 'name', 'time_zone', 'minutes_per_day', 'source_basis',
    ];

    public function workingPeriods()
    {
        return $this->hasMany(ScheduleCalendarWorkingPeriod::class);
    }

    public function exceptions()
    {
        return $this->hasMany(ScheduleCalendarException::class);
    }
}
