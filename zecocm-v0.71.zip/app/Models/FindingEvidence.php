<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * The real citation/audit trail behind an AiFinding - one row per source
 * record the finding actually rests on, never a JSON blob of IDs embedded in
 * the finding itself. Append-only, matching RetrievalTrace's existing
 * pattern: a finding's evidence is fixed at evaluation time; a later
 * re-evaluation writes new AiFinding + FindingEvidence rows rather than
 * editing these.
 */
class FindingEvidence extends Model
{
    use BelongsToTenant;

    public const UPDATED_AT = null;

    public const ROLE_SUPPORTS = 'SUPPORTS';
    public const ROLE_CONTRADICTS = 'CONTRADICTS';
    public const ROLE_EXPECTED_BUT_MISSING = 'EXPECTED_BUT_MISSING';
    public const ROLE_CONTEXT = 'CONTEXT';
    public const ROLE_MAPPING_BASIS = 'MAPPING_BASIS';

    protected $fillable = [
        'tenant_id', 'ai_finding_id', 'source_type', 'source_id', 'source_revision_id',
        'evidence_role', 'locator',
    ];

    protected $casts = [
        'locator' => 'array',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('FindingEvidence is append-only; a re-evaluation writes new evidence rows, never edits existing ones.'));
        static::deleting(fn () => throw new \LogicException('FindingEvidence is append-only and cannot be deleted.'));
    }

    public function finding()
    {
        return $this->belongsTo(AiFinding::class, 'ai_finding_id');
    }
}
