<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ActivityMappingGroup extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'supersedes_group_id', 'from_version_id', 'to_version_id', 'relation',
        'confidence', 'confirmation_status', 'source', 'confirmed_by', 'confirmed_at',
    ];

    protected $casts = ['confidence' => 'float', 'confirmed_at' => 'immutable_datetime'];

    public function edges()
    {
        return $this->hasMany(ActivityMappingEdge::class, 'mapping_group_id');
    }
}
