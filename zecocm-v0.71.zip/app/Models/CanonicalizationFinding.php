<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CanonicalizationFinding extends Model
{
    protected $guarded = [];

    protected $casts = ['detected_at' => 'immutable_datetime', 'record_count' => 'integer'];

    public function transitionRecord()
    {
        return $this->hasOne(CanonicalizationTransitionRecord::class);
    }

    /** Has a named human classified this yet, or is it still an unexplained fact? */
    public function isExplained(): bool
    {
        return $this->transitionRecord()->exists();
    }
}
