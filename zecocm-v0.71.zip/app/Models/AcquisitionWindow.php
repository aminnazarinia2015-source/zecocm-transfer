<?php

namespace App\Models;

use App\Domain\Knowledge\AcquisitionGate;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AcquisitionWindow extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'source_allowlist' => 'array',
        'max_documents' => 'integer',
        'max_total_bytes' => 'integer',
        'bytes_acquired' => 'integer',
        'documents_reserved' => 'integer',
        'requires_two_person' => 'boolean',
        'opened_at' => 'immutable_datetime',
        'expires_at' => 'immutable_datetime',
        'closed_at' => 'immutable_datetime',
        'confirmed_at' => 'immutable_datetime',
    ];

    public function documents()
    {
        return $this->hasMany(AcquiredDocument::class);
    }

    /**
     * The two fields nobody may widen after the fact.
     *
     * A window is an authorisation with a shape, and quietly growing the shape
     * of an authorisation somebody already granted is the same act as granting
     * a new one without asking. Widening is a new window.
     */
    protected static function booted(): void
    {
        static::updating(function (self $window) {
            if ($window->status === AcquisitionGate::OPEN || $window->opened_at !== null) {
                foreach (['source_allowlist', 'max_documents', 'max_total_bytes'] as $field) {
                    if ($window->isDirty($field)) {
                        throw new \RuntimeException(
                            'The '.str_replace('_', ' ', $field).' of an acquisition window cannot be changed once it '
                            .'has been opened. The person who authorised this window authorised its shape as well as '
                            .'its existence. Widening it is a new window.'
                        );
                    }
                }
            }
        });
    }
}
