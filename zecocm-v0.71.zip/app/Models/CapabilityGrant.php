<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CapabilityGrant extends Model
{
    protected $fillable = [
        'tenant_id', 'capability_key', 'status', 'starts_at', 'ends_at', 'plan_reference',
        'granted_by_user_id', 'granted_by_tenant_id', 'reason', 'metered', 'usage_limit', 'usage_count',
        'model_tier', 'allowed_tasks', 'budget_limit_micros', 'budget_used_micros',
        'budget_reserved_micros', 'unmeasured_run_count',
    ];

    protected $casts = [
        'starts_at' => 'immutable_datetime',
        'ends_at' => 'immutable_datetime',
        'metered' => 'boolean',
        'allowed_tasks' => 'array',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }
}
