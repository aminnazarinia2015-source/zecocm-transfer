<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * What the screen said, and why, on the day it said it.
 *
 * Append-only. When a steward corrects a trigger date, the deadline does not
 * get updated in place - a new calculation is written that supersedes the old
 * one, and the old one stays exactly as it was. Two years later the question is
 * rarely only "what is the deadline". It is "what did this system TELL the
 * project team on 1 September, and on what basis", and a table that overwrites
 * cannot answer it.
 */
class ClaimClockCalculation extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'trigger_snapshot' => 'array',
        'authority_snapshot' => 'array',
        'deadline_on' => 'date',
        'calculated_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(function () {
            throw new \RuntimeException(
                'A clock calculation cannot be edited. It is the record of what ZecoCM displayed on a particular day '
                .'and on what basis, which is the only thing that can answer "why did the system show that date". '
                .'A corrected trigger produces a NEW calculation superseding this one.'
            );
        });

        static::deleting(function () {
            throw new \RuntimeException('A clock calculation cannot be deleted.');
        });
    }
}
