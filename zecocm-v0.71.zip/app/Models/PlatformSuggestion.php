<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlatformSuggestion extends Model
{
    protected $fillable = ['suggested_by', 'tenant_id', 'about', 'suggestion', 'status', 'resolved_by', 'resolved_at'];

    protected $casts = ['resolved_at' => 'datetime'];
}
