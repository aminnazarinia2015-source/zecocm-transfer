<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

/**
 * Generic, polymorphic, immutable attestation - generalizes the two
 * hardcoded mechanisms this codebase had before (pay-application
 * certification's hash-bind, and SignatureAttestation's one-immutable-row-
 * per-worker). A signature is never edited or deleted once written; the
 * only way to change your mind is to void this row (void_at/void_reason)
 * and write a new one. See the create_document_templates_table migration
 * for the full rationale.
 */
class Signature extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'signable_type', 'signable_id', 'signer_id', 'signer_name',
        'content_hash', 'signed_at', 'signature_data', 'void_at', 'void_reason',
    ];

    protected $casts = [
        'signature_data' => 'array',
        'signed_at' => 'datetime',
        'void_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(function (Signature $signature) {
            // The only mutation ever allowed on a written signature is
            // voiding it - everything else about a signature (who, what,
            // when, the hash of what they signed) is permanent.
            $dirty = array_keys($signature->getDirty());
            $allowed = ['void_at', 'void_reason'];
            if (array_diff($dirty, $allowed) !== []) {
                throw new \LogicException('Signatures are immutable. Void this one and create a new one instead.');
            }
        });
        static::deleting(fn () => throw new \LogicException('Signatures are immutable and cannot be deleted. Void instead.'));
    }

    public function delete()
    {
        throw new \LogicException('Signatures are immutable and cannot be deleted. Void instead.');
    }

    public function signable(): MorphTo
    {
        return $this->morphTo();
    }

    public function signer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'signer_id');
    }
}
