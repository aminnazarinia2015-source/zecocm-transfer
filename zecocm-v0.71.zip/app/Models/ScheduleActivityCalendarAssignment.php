<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleActivityCalendarAssignment extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $fillable = ['tenant_id', 'schedule_activity_id', 'schedule_calendar_id', 'relationship'];

    public function calendar()
    {
        return $this->belongsTo(ScheduleCalendar::class, 'schedule_calendar_id');
    }
}
