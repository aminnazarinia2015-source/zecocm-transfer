<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanSet extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    public function sheets()
    {
        return $this->hasMany(PlanSheet::class);
    }
}
