<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CapabilityGrantEvent extends Model
{
    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'capability_grant_id', 'capability_key', 'action', 'effective_from', 'effective_until',
        'actor_user_id', 'actor_tenant_id', 'reason', 'before', 'after', 'correlation_id',
        'previous_event_hash', 'event_hash', 'created_at',
    ];

    protected $casts = [
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
        'before' => 'array',
        'after' => 'array',
        'created_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Licence events are append-only.'));
        static::deleting(fn () => throw new \LogicException('Licence events are append-only.'));
    }
}
