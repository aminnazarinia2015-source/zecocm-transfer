<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use Illuminate\Database\Eloquent\Model;

/**
 * REL-1: append-only ledger of actual deploy attempts, one row per attempt -
 * mirrors EV-14B's execution-ledger-not-mutable-column pattern. A version's
 * deploy history (including a failed attempt) is never overwritten.
 */
class ReleaseDeployment extends Model
{
    use ImmutableImportedScheduleRecord;

    public $timestamps = false;

    protected $guarded = [];

    protected $casts = [
        'deployed_at' => 'datetime',
        'http_healthy' => 'boolean',
    ];

    public function manifest()
    {
        return $this->belongsTo(ReleaseManifest::class, 'release_manifest_id');
    }
}
