<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use Illuminate\Database\Eloquent\Model;

/**
 * REL-1: one immutable row per release-candidate build attempt, including
 * failed ones. See the migration's own doc comment for why failed attempts
 * are persisted rather than discarded - a refused build is the evidentiary
 * event this row exists to prove happened.
 */
class ReleaseManifest extends Model
{
    use ImmutableImportedScheduleRecord;

    public $timestamps = false;

    protected $guarded = [];

    protected $casts = [
        'migration_files' => 'array',
        'test_ids' => 'array',
        'tests_added' => 'array',
        'tests_removed' => 'array',
        'removal_justifications' => 'array',
        'protected_content_hashes' => 'array',
        'required_suites' => 'array',
        'depends_on' => 'array',
        'verification_failures' => 'array',
        'created_at' => 'datetime',
    ];

    public function deployments()
    {
        return $this->hasMany(ReleaseDeployment::class);
    }

    public function isVerified(): bool
    {
        return $this->verification_status === 'verified';
    }
}
