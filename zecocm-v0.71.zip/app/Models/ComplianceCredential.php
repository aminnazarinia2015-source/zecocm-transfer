<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ComplianceCredential extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'effective_from' => 'date',
        'expires_on' => 'date',
        'document_on_file' => 'boolean',
        'limit_cents' => 'integer',
        'verified_at' => 'immutable_datetime',
    ];

    public function partner()
    {
        return $this->belongsTo(TradePartner::class, 'trade_partner_id');
    }
}
