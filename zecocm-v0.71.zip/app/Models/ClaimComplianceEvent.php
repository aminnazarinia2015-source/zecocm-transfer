<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * What was actually done about a requirement, kept apart from whether it worked.
 *
 * A notice is not compliant because somebody uploaded a PDF before the
 * deadline. Three separate findings, three separate columns, and nothing
 * derives one from another:
 *
 *   TIMELY   it went out before the deadline.
 *   COMPLETE it contained what the requirement demands.
 *   SATISFIED somebody determined that this requirement is met.
 *
 * A notice sent two days early, to the project inspector rather than to the
 * officer the contract names, missing the cost impact the clause requires, is
 * TIMELY and not COMPLIANT and certainly not SATISFIED. A system that showed
 * one green tick for it would be telling the contractor he is safe.
 */
class ClaimComplianceEvent extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'prepared_at' => 'immutable_datetime',
        'signed_at' => 'immutable_datetime',
        'sent_at' => 'immutable_datetime',
        'received_at' => 'immutable_datetime',
        'determined_at' => 'immutable_datetime',
    ];

    /** Sent is not served, and neither of them is satisfied. */
    public function qualifies(): bool
    {
        return $this->satisfaction === 'satisfied';
    }
}
