<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class TemplateAssignment extends Model
{
    use BelongsToTenant;

    public const STATUS_PENDING = 'pending';

    public const STATUS_COMPLETED = 'completed';

    protected $fillable = [
        'tenant_id', 'project_id', 'document_template_id', 'party_label',
        'assigned_to_user_id', 'status', 'values', 'completed_at',
    ];

    protected $casts = [
        'values' => 'array',
        'completed_at' => 'datetime',
    ];

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }

    public function template(): BelongsTo
    {
        return $this->belongsTo(DocumentTemplate::class, 'document_template_id');
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to_user_id');
    }

    /**
     * A signable can carry more than one signature over time (a voided one
     * superseded by a fresh one) - all of them, active or void, stay in the
     * history. Callers filter to activeSignature() for "the one that counts".
     */
    public function signatures(): MorphMany
    {
        return $this->morphMany(Signature::class, 'signable');
    }

    public function activeSignature(): ?Signature
    {
        return $this->signatures()->whereNull('void_at')->latest('signed_at')->first();
    }
}
