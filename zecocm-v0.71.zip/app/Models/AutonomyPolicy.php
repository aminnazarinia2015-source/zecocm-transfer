<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * AUTO-2: what a project has actually authorized the system to do, per action
 * type. See the migration's doc comment for why this is a separate axis from
 * capability licensing.
 *
 * Frozen once active, for the same reason a confirmed ClaimRequirement is
 * frozen (see ClaimRequirement::booted()): "what did this project authorize
 * the system to do, and as of when" must stay answerable after the fact. An
 * amendment supersedes - it does not edit history.
 */
class AutonomyPolicy extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'set_at' => 'immutable_datetime',
        'effective_at' => 'immutable_datetime',
    ];

    public function supersedes()
    {
        return $this->belongsTo(self::class, 'supersedes_policy_id');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    /**
     * Once a policy is active, every field except `status` (and only the
     * active -> superseded transition) is frozen. A change to the level
     * itself, the authority it cites, or which action type it governs is a
     * NEW policy row superseding this one - identical reasoning to why a
     * confirmed ClaimRequirement cannot have its period edited in place.
     */
    protected static function booted(): void
    {
        static::updating(function (self $policy) {
            if ($policy->getOriginal('status') !== 'active') {
                return;
            }

            if ($policy->isDirty('status')) {
                if ($policy->status !== 'superseded') {
                    throw new \RuntimeException(
                        'An active autonomy policy may only transition to superseded, never back to draft '
                        .'or to any other status.'
                    );
                }
            }

            foreach (['tenant_id', 'project_id', 'capability', 'action_type', 'autonomy_level',
                'authority_source', 'set_by', 'set_at', 'effective_at'] as $field) {
                if ($policy->isDirty($field)) {
                    throw new \RuntimeException(
                        'An active autonomy policy cannot be edited. "'.str_replace('_', ' ', $field).'" is part '
                        .'of what this project authorized the system to do, and TRACE has relied on it since '
                        .'set_at. A change is a NEW policy superseding this one, so "what was authorized as of '
                        .'date X" stays answerable.'
                    );
                }
            }
        });

        static::deleting(function (self $policy) {
            throw new \RuntimeException('An autonomy policy is never deleted, only superseded.');
        });
    }
}
