<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContractorRegistration extends Model
{
    // Deliberately NOT tenant-scoped — see the migration's docblock. A registration exists before
    // any tenant does.

    public const STATUS_PENDING_PAYMENT = 'pending_payment';

    public const STATUS_PAYMENT_CONFIRMED = 'payment_confirmed';

    public const STATUS_PROVISIONING = 'provisioning';

    public const STATUS_PROVISIONED = 'provisioned';

    public const STATUS_PAYMENT_FAILED = 'payment_failed';

    // Found by a "what if" pass: two people (or one person twice, after a browser refresh dropped
    // their client-held registration_id) can both pass step 1 with the same email before either
    // pays - nothing there ever checked for a duplicate, because at that point neither has a real
    // account yet. Whichever pays SECOND then collides with users.email's global uniqueness at the
    // moment provisioning tries to create its admin user. This status is where that registration
    // lands: payment was real and already confirmed, but no tenant could be created, and it needs
    // a human (support, via the platform registrations queue) to resolve - never a silent retry.
    public const STATUS_PROVISIONING_FAILED_DUPLICATE_EMAIL = 'provisioning_failed_duplicate_email';

    protected $fillable = [
        'registration_id', 'legal_name', 'business_name', 'entity_type', 'country',
        'admin_first_name', 'admin_last_name', 'phone', 'address', 'email', 'plan',
        'payment_provider', 'payment_provider_customer_id', 'payment_provider_subscription_id',
        'status', 'payment_confirmed_at', 'tenant_id',
    ];

    protected $casts = [
        'address' => 'array',
        'payment_confirmed_at' => 'datetime',
    ];

    public static function entityTypes(): array
    {
        return [
            'sole_proprietorship' => 'Sole proprietorship',
            'llc' => 'LLC',
            'corporation' => 'Corporation',
            'partnership' => 'Partnership',
            'other' => 'Other',
        ];
    }

    /**
     * The three self-serve tiers offered on the homepage pricing section. "Agency" is
     * intentionally absent — that tier is negotiated/manual, never self-serve checkout.
     */
    public static function plans(): array
    {
        return [
            'field' => 'Field',
            'project' => 'Project',
            'program' => 'Program',
        ];
    }

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function isProvisioned(): bool
    {
        return $this->status === self::STATUS_PROVISIONED && $this->tenant_id !== null;
    }
}
