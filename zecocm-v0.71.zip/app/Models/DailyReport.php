<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class DailyReport extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'report_date', 'foreman_id', 'weather',
        'work_performed', 'site_conditions', 'delays', 'cost_code_notes',
        'locked', 'lock_seal', 'corrections',
    ];

    protected $casts = [
        // Found via an external audit (A-014): a plain calendar date was
        // serializing to the API as a full ISO timestamp with a fake
        // midnight-UTC time component (e.g. "2026-08-27T00:00:00.000000Z"),
        // which the frontend then rendered raw. report_date has no time of
        // day - it's just a date - so this now serializes as one, everywhere
        // this field is used, instead of patching each call site.
        'report_date' => 'date:Y-m-d',
        'weather' => 'array',
        'cost_code_notes' => 'array',
        'locked' => 'boolean',
        'lock_seal' => 'array',
        'corrections' => 'array',
    ];

    public function timeCardEntries()
    {
        return $this->hasMany(TimeCardEntry::class);
    }

    public function signatureAttestations()
    {
        return $this->hasMany(SignatureAttestation::class);
    }

    public function activities()
    {
        return $this->hasMany(DailyReportActivity::class);
    }

    /** Locked on signature; corrections APPEND, never overwrite (delay-claim evidence). */
    public function correct(string $field, string $newValue, int $userId, string $reason): void
    {
        if (! $this->locked) {
            throw new \LogicException('Corrections are for locked reports; edit directly before locking.');
        }
        $c = $this->corrections ?? [];
        $c[] = [
            'field' => $field, 'new_value' => $newValue, 'reason' => $reason,
            'user_id' => $userId, 'at' => now()->toIso8601String(),
        ];
        $this->corrections = $c;
    }
}
