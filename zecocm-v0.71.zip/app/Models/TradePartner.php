<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class TradePartner extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    public function credentials()
    {
        return $this->hasMany(ComplianceCredential::class);
    }

    public function subcontracts()
    {
        return $this->hasMany(Subcontract::class);
    }
}
