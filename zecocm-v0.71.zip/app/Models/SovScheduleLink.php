<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * An explicit, human-verified relationship between a Pay Application SOV
 * line and a schedule activity. AI may create a row with
 * mapping_source=AI_SUGGESTED, but a row only counts as evidence for a
 * finding once mapping_status is VERIFIED by a human - never inferred at
 * request time from label similarity (that hand-wave is exactly what Codex's
 * review rejected in Gemini's original proposal).
 *
 * Only the verification fields may ever change after creation - the pairing
 * itself (which SOV line, which activity, which schedule version) is fixed
 * at creation; verifying, rejecting, or re-reviewing a link never rewrites
 * what it links, only its status.
 */
class SovScheduleLink extends Model
{
    use BelongsToTenant;

    public const STATUS_UNVERIFIED = 'UNVERIFIED';
    public const STATUS_VERIFIED = 'VERIFIED';
    public const STATUS_REJECTED = 'REJECTED';

    public const SOURCE_CONTRACTOR = 'CONTRACTOR';
    public const SOURCE_PM = 'PM';
    public const SOURCE_IMPORT = 'IMPORT';
    public const SOURCE_AI_SUGGESTED = 'AI_SUGGESTED';

    public const RELATIONSHIP_DIRECT = 'DIRECT';
    public const RELATIONSHIP_CONTRIBUTES_TO = 'CONTRIBUTES_TO';
    public const RELATIONSHIP_SUPPORTS = 'SUPPORTS';
    public const RELATIONSHIP_NOT_PROGRESS_BEARING = 'NOT_PROGRESS_BEARING';

    protected $fillable = [
        'tenant_id', 'schedule_of_value_item_id', 'schedule_activity_id', 'schedule_version_id',
        'relationship_type', 'mapping_source', 'mapping_status', 'allocation_weight',
        'verified_by', 'verified_at', 'effective_from', 'effective_to', 'notes',
    ];

    protected $casts = [
        'allocation_weight' => 'float',
        'verified_at' => 'immutable_datetime',
        'effective_from' => 'date',
        'effective_to' => 'date',
    ];

    protected static function booted(): void
    {
        static::creating(function (self $link): void {
            $link->mapping_status ??= self::STATUS_UNVERIFIED;
        });

        static::updating(function (self $link): void {
            $changed = array_keys($link->getDirty());
            $allowed = ['mapping_status', 'verified_by', 'verified_at', 'notes', 'updated_at'];
            if (array_diff($changed, $allowed) !== []) {
                throw new \LogicException(
                    'An SovScheduleLink\'s pairing (SOV line, activity, schedule version) is fixed at '
                    .'creation - only its verification status may change. Create a new link instead.'
                );
            }
        });
    }

    public function scheduleOfValueItem()
    {
        return $this->belongsTo(ScheduleOfValueItem::class);
    }

    public function scheduleActivity()
    {
        return $this->belongsTo(ScheduleActivity::class);
    }

    public function scheduleVersion()
    {
        return $this->belongsTo(ScheduleVersion::class);
    }

    public function verifiedBy()
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    public function isVerified(): bool
    {
        return $this->mapping_status === self::STATUS_VERIFIED;
    }
}
