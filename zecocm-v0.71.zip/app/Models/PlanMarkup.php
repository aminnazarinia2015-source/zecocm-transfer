<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanMarkup extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'geometry' => 'array',
        'resolved_at' => 'immutable_datetime',
    ];

    public function version()
    {
        return $this->belongsTo(PlanSheetVersion::class, 'plan_sheet_version_id');
    }
}
