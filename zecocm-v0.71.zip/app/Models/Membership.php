<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Membership extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'user_id', 'organization', 'seat',
        'capabilities', 'discipline_scope', 'status', 'revoked_at',
    ];

    protected $casts = [
        'capabilities' => 'array',
        'discipline_scope' => 'array',
        'revoked_at' => 'datetime',
    ];

    public const STATUS_ACTIVE = 'active';
    public const STATUS_REVOKED = 'revoked';

    public function allows(string $capability): bool
    {
        if ($this->status === self::STATUS_REVOKED) {
            return false;
        }
        $capabilities = $this->capabilities ?? [];

        return ($capabilities['*'] ?? false) === true
            || ($capabilities[$capability] ?? false) === true;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
