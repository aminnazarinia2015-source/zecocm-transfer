<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleVersionEvent extends Model
{
    use BelongsToTenant;

    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'schedule_version_id', 'event_type', 'disposition', 'payload',
        'actor_id', 'occurred_at', 'previous_event_hash', 'event_hash',
    ];

    protected $casts = ['payload' => 'array', 'occurred_at' => 'immutable_datetime'];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Schedule disposition events are append-only.'));
        static::deleting(fn () => throw new \LogicException('Schedule disposition events are append-only.'));
    }
}
