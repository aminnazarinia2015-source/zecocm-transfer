<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class KnowledgeSource extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'verified_at' => 'immutable_datetime',
    ];

    public function versions()
    {
        return $this->hasMany(KnowledgeSourceVersion::class);
    }

    public function documentFolder()
    {
        return $this->belongsTo(DocumentFolder::class, 'document_folder_id');
    }
}
