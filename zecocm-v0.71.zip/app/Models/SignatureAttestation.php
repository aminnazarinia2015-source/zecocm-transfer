<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class SignatureAttestation extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'daily_report_id', 'worker_code', 'worker_name', 'language',
        'safety_training_received', 'breaks_and_lunch_taken', 'exception_reason',
        'signature_data', 'seal',
    ];

    protected $casts = [
        'safety_training_received' => 'boolean',
        'breaks_and_lunch_taken' => 'boolean',
        'seal' => 'array',
    ];

    /**
     * Immutable: a correction is a NEW record referencing this one (Aspect 12).
     *
     * Blocking delete() alone was not enough. An attestation that can be UPDATED
     * after the fact is not an attestation - a meal/rest-break record under CA
     * Labor Code 226.7/512 is precisely the record an opposing wage-and-hour
     * expert will test for post-hoc mutation, and it was mutable via ->update().
     */
    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Attestations are immutable. Create a correcting record instead.'));
        static::deleting(fn () => throw new \LogicException('Attestations are immutable. Create a correcting record instead.'));
    }

    public function delete()
    {
        throw new \LogicException('Attestations are immutable. Create a correcting record instead.');
    }
}
