<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AiFeedbackEvent extends Model
{
    use BelongsToTenant;

    protected $guarded = [];
    protected $casts = ['correction' => 'array', 'outcome' => 'array'];
}
