<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * EV-14B: one entry in the explicit, deliberately small set of storage
 * locations EV-14B is willing to certify destruction against. Not
 * tenant-scoped - this describes the application's own storage topology,
 * not a customer's data.
 *
 * v1 ships exactly one governed row (see the EV-14B migration): the primary
 * evidence disk DATA-1 already moved outside the app's deployment tree. A
 * row here is never invented ahead of the storage actually existing - when
 * DATA-2 adds off-host backup, that is a new row, not a code change.
 */
class EvidenceStorageLocation extends Model
{
    public const TYPE_PRIMARY = 'primary';

    public const TYPE_OBJECT_VERSION = 'object_version';

    public const TYPE_REPLICA = 'replica';

    public const TYPE_BACKUP = 'backup';

    public const TYPE_EXPORT_CACHE = 'export_cache';

    public const TYPE_OTHER = 'other';

    public const CAPABILITY_IMMEDIATE = 'immediate';

    public const CAPABILITY_LIFECYCLE = 'lifecycle';

    public const CAPABILITY_UNSUPPORTED = 'unsupported';

    protected $fillable = [
        'location_key', 'type', 'disk', 'governed', 'destruction_capability',
        'verification_method', 'retention_behavior', 'versioning_enabled',
        'effective_from', 'effective_to',
    ];

    protected $casts = [
        'governed' => 'boolean',
        'versioning_enabled' => 'boolean',
        'effective_from' => 'immutable_datetime',
        'effective_to' => 'immutable_datetime',
    ];
}
