<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Submittal extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'number', 'spec_section', 'title', 'type',
        'submitted_by_org', 'contact_person', 'submitted_at', 'ball_in_court',
        'status', 'stamp', 'routing_history',
    ];

    protected $casts = [
        'submitted_at' => 'date',
        'stamp' => 'array',
        'routing_history' => 'array',
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    /** Spec section -> reviewing discipline, derived not hand-picked. */
    public function defaultDiscipline(): string
    {
        $division = (int) substr(preg_replace('/\D/', '', $this->spec_section) ?: '0', 0, 2);

        return match (true) {
            in_array($division, [3, 4, 5], true) => 'structural',
            $division === 22 => 'plumbing',
            $division === 23 => 'mechanical',
            in_array($division, [26, 27, 28], true) => 'electrical',
            in_array($division, [31, 32, 33], true) => 'civil_landscape',
            default => 'architect',
        };
    }

    /** @param array<string,mixed> $entry */
    public function route(string $toSeat, array $entry): void
    {
        $history = $this->routing_history ?? [];
        $history[] = $entry + ['to' => $toSeat, 'at' => now()->toIso8601String()];
        $this->routing_history = $history;
        $this->ball_in_court = $toSeat;
    }
}
