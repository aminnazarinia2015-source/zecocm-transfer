<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class MediaItem extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'sha256', 'storage_path', 'original_name',
        'mime', 'bytes', 'provenance', 'provenance_signature', 'confidence', 'captured_by',
        'server_received_at', 'receipt_sequence', 'capture_time_basis', 'capture_finding', 'client_claims',
        'malware_scan_status', 'quarantine_reason', 'retention_class',
    ];

    protected $casts = [
        'provenance' => 'array',
        'client_claims' => 'array',
        'server_received_at' => 'immutable_datetime',
        'receipt_sequence' => 'integer',
    ];

    /**
     * The `confidence` column is a legacy value and must not be read as a
     * statement about the capture time.
     *
     * It was computed from three numbers the client supplied, compared against
     * each other. A client that lied consistently earned "strong". It is kept
     * because historical records asserted it and rewriting what a record said
     * at the time it was made is the one thing this system does not do - but
     * nothing new should consult it, so the accessor that replaces it is named
     * for what it actually reports.
     */
    public function captureTimeBasisIsServer(): bool
    {
        return $this->capture_time_basis === 'server_receipt';
    }

    public function links()
    {
        return $this->hasMany(EvidenceLink::class);
    }
}
