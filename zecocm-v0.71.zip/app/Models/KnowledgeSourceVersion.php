<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class KnowledgeSourceVersion extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = [
        'effective_from' => 'immutable_datetime',
        'effective_until' => 'immutable_datetime',
        'classification' => 'array',
        'extraction_confidence' => 'float',
    ];

    public function source()
    {
        return $this->belongsTo(KnowledgeSource::class, 'knowledge_source_id');
    }

    public function passages()
    {
        return $this->hasMany(KnowledgePassage::class);
    }
}
