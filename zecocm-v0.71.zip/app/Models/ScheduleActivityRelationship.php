<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleActivityRelationship extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'schedule_version_id', 'predecessor_activity_id',
        'successor_activity_id', 'relationship_type', 'lag_minutes',
    ];
}
