<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/** EV-14A / B9: the append-only record of an evidence link being superseded. See EvidenceLink. */
class EvidenceUnlinkEvent extends Model
{
    use BelongsToTenant;

    protected $fillable = ['tenant_id', 'evidence_link_id', 'actor_id', 'reason', 'occurred_at'];

    protected $casts = [
        'occurred_at' => 'immutable_datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Unlink events are append-only.'));
        static::deleting(fn () => throw new \LogicException('Unlink events are append-only and cannot be deleted.'));
    }

    public function link()
    {
        return $this->belongsTo(EvidenceLink::class, 'evidence_link_id');
    }
}
