<?php

namespace App\Models;

use App\Domain\Payment\ReleaseCoverage;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class LienRelease extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'through_date' => 'date',
        'signed_on' => 'date',
        'payment_cleared_on' => 'date',
        'document_on_file' => 'boolean',
        'exceptions_stated' => 'boolean',
        'amount_cents' => 'integer',
        'exceptions_structured' => 'boolean',
    ];

    public function partner()
    {
        return $this->belongsTo(TradePartner::class, 'trade_partner_id');
    }

    public function isConditional(): bool
    {
        return in_array($this->form_type, ReleaseCoverage::CONDITIONAL_FORMS, true);
    }

    /**
     * A conditional release has not taken effect until the payment cleared.
     * Deliberately not a database default or an accessor on a stored column:
     * "in effect" is a conclusion drawn from two facts, and storing it would
     * let the two drift.
     */
    public function hasTakenEffect(): bool
    {
        if (! $this->document_on_file) {
            return false;
        }

        return ! $this->isConditional() || $this->payment_cleared_on !== null;
    }
}
