<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleDelta extends Model
{
    use BelongsToTenant;

    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'project_id', 'analysis_run_id', 'from_version_id', 'to_version_id',
        'mapping_group_id', 'from_activity_id', 'to_activity_id', 'canonical_id',
        'delta_type', 'field', 'magnitude_minutes', 'magnitude_basis', 'before_value', 'after_value',
        'explanation', 'classification',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Schedule deltas are immutable.'));
        static::deleting(fn () => throw new \LogicException('Schedule deltas are immutable outside retry replacement.'));
    }
}
