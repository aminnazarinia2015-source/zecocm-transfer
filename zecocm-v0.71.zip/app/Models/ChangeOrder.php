<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ChangeOrder extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'identified_at' => 'date',
        'approved_at' => 'immutable_datetime',
        'amount_cents' => 'integer',
        'time_extension_days' => 'integer',
        'seal' => 'array',
        'edit_history' => 'array',
    ];

    public function allocations()
    {
        return $this->hasMany(ChangeOrderAllocation::class);
    }

    public function isApproved(): bool
    {
        return $this->status === 'approved';
    }
}
