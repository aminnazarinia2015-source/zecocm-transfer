<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class QualityItem extends Model
{
    use BelongsToTenant;

    protected $guarded = [];
    // Found via an external audit (A-014): same fix as DailyReport::report_date -
    // due_at is a plain calendar date, not a timestamp, so it should never
    // serialize with a fabricated midnight-UTC time component.
    protected $casts = ['due_at' => 'date:Y-m-d'];

    public function events()
    {
        return $this->hasMany(QualityItemEvent::class);
    }

    public function media()
    {
        return $this->belongsToMany(MediaItem::class, 'quality_item_media')->withPivot(['linked_by', 'created_at']);
    }
}
