<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class UploadSession extends Model
{
    use BelongsToTenant;

    public const STATUS_IN_PROGRESS = 'in_progress';

    public const STATUS_COMPLETED = 'completed';

    public const STATUS_FAILED = 'failed';

    public const TARGET_DOCUMENT = 'document';

    public const TARGET_DOCUMENT_VERSION = 'document_version';

    protected $guarded = [];

    protected $casts = [
        'target_context' => 'array',
        'declared_total_bytes' => 'integer',
        'bytes_received' => 'integer',
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
