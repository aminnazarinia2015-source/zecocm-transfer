<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PayApplicationLine extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'previous_completed_cents' => 'integer',
        'this_period_cents' => 'integer',
        'stored_materials_cents' => 'integer',
        'pending_change_value_cents' => 'integer',
        'stored_material_adjustment_cents' => 'integer',
    ];

    public function item()
    {
        return $this->belongsTo(ScheduleOfValueItem::class, 'schedule_of_value_item_id');
    }

    public function application()
    {
        return $this->belongsTo(PayApplication::class, 'pay_application_id');
    }
}
