<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ChangeOrderAllocation extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = ['amount_cents' => 'integer'];

    public function changeOrder()
    {
        return $this->belongsTo(ChangeOrder::class);
    }

    public function item()
    {
        return $this->belongsTo(ScheduleOfValueItem::class, 'schedule_of_value_item_id');
    }

    /** An allocation with no existing line creates one for distinct added scope. */
    public function createsNewLine(): bool
    {
        return $this->schedule_of_value_item_id === null;
    }
}
