<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Singleton row (id=1) backing the editable homepage: news items and the
 * pilot customer-count showcase. See HomepageContentController.
 */
class HomepageContent extends Model
{
    protected $fillable = ['news', 'customer_counts', 'counts_are_pilot_data', 'updated_by'];

    protected $casts = [
        'news' => 'array',
        'customer_counts' => 'array',
        'counts_are_pilot_data' => 'boolean',
    ];

    public static function defaultCounts(): array
    {
        return ['contractors' => 0, 'public_entities' => 0, 'construction_managers' => 0];
    }

    /** There is exactly one row - creating it lazily keeps the migration itself data-free. */
    public static function current(): self
    {
        return static::query()->firstOrCreate(['id' => 1], [
            'news' => [],
            'customer_counts' => static::defaultCounts(),
            'counts_are_pilot_data' => true,
        ]);
    }
}
