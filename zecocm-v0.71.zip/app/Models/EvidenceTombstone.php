<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14A: "Content may be destroyed. The fact of the content - its identity,
 * its integrity metadata, its position in the chain, and the authority under
 * which it was destroyed - is never destroyed." This row retains the digest
 * forever (Codex's ruling: the digest is the evidentiary commitment binding
 * the tombstone to what existed, not the content itself) and never the bytes.
 *
 * `state` on THIS row can ONLY ever be `AUTHORIZED_PENDING_EXECUTION` -
 * that column is fixed forever by the append-only guard below, exactly like
 * every other field. EV-14B does not lift that guard or write to this
 * column; it records what actually happened in a separate append-only
 * ledger, `evidence_tombstone_execution_events`, resolved the same way
 * `HoldStatus` resolves hold state - latest event wins, never a mutable
 * "current state" field. The constants below are the vocabulary that ledger
 * uses; `EvidenceDestructionExecutor` is the only code that writes them, and
 * `DestructionCertificate` is structurally incapable of claiming one it does
 * not recognise.
 */
class EvidenceTombstone extends Model
{
    use BelongsToTenant;

    /** The only state this row's own `state` column can ever hold. Authorized; nothing executed. */
    public const AUTHORIZED_PENDING_EXECUTION = 'authorized_pending_execution';

    /** EV-14B execution ledger: primary location cleared, other governed locations still pending/unresolved. */
    public const PRIMARY_REMOVED = 'primary_removed';

    /** EV-14B execution ledger: a delete attempt left content verifiably still present at a governed location. */
    public const RESIDUAL_COPY_EXISTS = 'residual_copy_exists';

    /** EV-14B execution ledger: every governed location resolved absent. The one true terminal success state. */
    public const DESTROYED_WITHIN_GOVERNED_SCOPE = 'destroyed_within_governed_scope';

    /** EV-14B execution ledger: a worker has begun processing this tombstone's governed locations. */
    public const EXECUTION_IN_PROGRESS = 'execution_in_progress';

    /** EV-14B execution ledger: the object's current bytes no longer hash to the tombstone's digest. Refuse. */
    public const EXECUTION_BLOCKED_CONTENT_MISMATCH = 'execution_blocked_content_mismatch';

    /** EV-14B execution ledger: a fresh hold check at execution time found an active hold before any location was touched. */
    public const EXECUTION_BLOCKED_HOLD = 'execution_blocked_hold';

    /** EV-14B execution ledger: a hold appeared mid-batch, after some but not all governed locations were cleared. */
    public const EXECUTION_STOPPED_PARTIAL_HOLD = 'execution_stopped_partial_hold';

    /** EV-14B execution ledger: no governed storage location is known for this instant. Refuse rather than assume primary-only. */
    public const EXECUTION_BLOCKED_TOPOLOGY_UNKNOWN = 'execution_blocked_topology_unknown';

    /** EV-14B execution ledger: a governed location's bytes were absent before any delete was attempted. Never auto-treated as success. */
    public const EXECUTION_DISCREPANCY_UNEXPECTED_ABSENCE = 'execution_discrepancy_unexpected_absence';

    protected $fillable = [
        'tenant_id', 'media_item_id', 'destruction_request_id', 'digest', 'digest_algorithm',
        'bytes', 'mime', 'original_name', 'authorized_by', 'authorized_at',
        'authority_citation', 'hold_check_result', 'state',
    ];

    protected $casts = [
        'authorized_at' => 'immutable_datetime',
    ];

    /** Tombstones are append-only, same discipline as every other evidentiary record. */
    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Tombstones are append-only; a status change is a new tombstone-lineage event, never an edit.'));
        static::deleting(fn () => throw new \LogicException('Tombstones are append-only and cannot be deleted - deleting the record of a destruction is worse than the destruction itself.'));
    }
}
