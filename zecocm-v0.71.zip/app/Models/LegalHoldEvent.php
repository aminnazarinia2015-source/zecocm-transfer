<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14A: append-only. A hold is PLACED by one row and, later, RELEASED by a
 * second row sharing the same `hold_id` - never one mutable row whose
 * `released_at` gets set in place. A hold that silently expired because
 * nobody renewed it would otherwise be indistinguishable, afterwards, from a
 * hold that was never placed. Every row here says who did what, when, and why.
 */
class LegalHoldEvent extends Model
{
    use BelongsToTenant;

    public const PLACED = 'placed';

    public const RELEASED = 'released';

    public const SCOPE_PROJECT = 'project';

    public const SCOPE_TENANT = 'tenant';

    public const SCOPE_MEDIA_ITEM = 'media_item';

    protected $fillable = [
        'tenant_id', 'hold_id', 'event_type', 'scope_type', 'scope_value',
        'matter_reference', 'actor_id', 'reason', 'occurred_at',
    ];

    protected $casts = [
        'scope_value' => 'array',
        'occurred_at' => 'immutable_datetime',
    ];

    /** Holds are append-only, same discipline as an imported schedule fact. */
    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Legal hold events are append-only; release a hold with a new event, never edit the placement.'));
        static::deleting(fn () => throw new \LogicException('Legal hold events are append-only and cannot be deleted.'));
    }
}
