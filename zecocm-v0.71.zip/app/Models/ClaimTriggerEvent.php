<?php

namespace App\Models;

use App\Domain\Claims\ClaimClock;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ClaimTriggerEvent extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'occurred_on' => 'date',
        'earliest_plausible_on' => 'date',
        'latest_plausible_on' => 'date',
        'confirmed_at' => 'immutable_datetime',
    ];

    /**
     * A clock may only run from a confirmed trigger.
     *
     * "When was the differing condition discovered" is a question with a
     * contested answer far more often than an obvious one, and it is frequently
     * only recognised as a trigger weeks after the fact. Counting from
     * somebody's first guess and displaying the result as a deadline is how a
     * contractor relaxes on the strength of a date that was never right.
     */
    public function isCountable(): bool
    {
        return $this->status === ClaimClock::TRIGGER_CONFIRMED && $this->occurred_on !== null;
    }

    public function toArray(): array
    {
        return parent::toArray();
    }
}
