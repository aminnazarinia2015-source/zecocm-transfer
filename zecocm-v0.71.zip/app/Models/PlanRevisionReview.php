<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanRevisionReview extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = ['reviewed_at' => 'immutable_datetime'];

    public function version()
    {
        return $this->belongsTo(PlanSheetVersion::class, 'plan_sheet_version_id');
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }
}
