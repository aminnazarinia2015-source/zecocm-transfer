<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * D4: one row per page of an ingested document version, carrying exactly
 * what Codex's ruling asked to stop conflating into a single document-level
 * scalar - extraction method, confidence, OCR engine/version, render DPI,
 * and sheet identity are all per-page facts. Immutable once written, the
 * same discipline every other evidentiary record in this codebase already
 * carries: a re-extraction (different OCR engine version, a corrected
 * source version) is a new set of rows against a new source version, never
 * an edit in place.
 */
class KnowledgeSourcePage extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = ['warnings' => 'array', 'structural_findings' => 'array'];

    public function version()
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'knowledge_source_version_id');
    }

    public function passages()
    {
        return $this->hasMany(KnowledgePassage::class, 'source_page_id');
    }
}
