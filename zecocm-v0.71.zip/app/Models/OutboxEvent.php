<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class OutboxEvent extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'aggregate_type', 'aggregate_id', 'event_type', 'payload',
        'idempotency_key', 'status', 'attempts', 'available_at', 'published_at', 'last_error',
    ];

    protected $casts = ['payload' => 'array', 'available_at' => 'immutable_datetime', 'published_at' => 'immutable_datetime'];
}
