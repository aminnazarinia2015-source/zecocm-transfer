<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * AUTO-2: the explainable, append-only log that is the actual product
 * surface (TRACE Project Steward). Every row must be able to answer, forever:
 * what triggered it, what rule authorized it, what evidence it used, what it
 * changed, and whether a human could or did intervene.
 *
 * Split, deliberately, like DestructionRequest (EV-14A): the IDENTITY of an
 * action - what triggered it, under what rule, with what evidence, at what
 * autonomy level - is frozen the instant the row is created and can never
 * change. Only its LIFECYCLE - status, executed_change/executed_at (set once,
 * going from proposed to executed), notified_at, approved_by/at,
 * cancelled_by/at, human_intervention_state - may move, and only forward.
 * This is not a new idiom; it is the same "immutable facts, mutable
 * workflow" split this codebase already uses for its other governed
 * records, applied to autonomy instead of destruction.
 */
class AutonomousAction extends Model
{
    use BelongsToTenant;

    public $timestamps = false;

    protected $guarded = [];

    protected $casts = [
        'trigger_record_ids' => 'array',
        'evidence_used' => 'array',
        'proposed_change' => 'array',
        'executed_change' => 'array',
        'executed_at' => 'immutable_datetime',
        'notified_at' => 'immutable_datetime',
        'approved_at' => 'immutable_datetime',
        'cancelled_at' => 'immutable_datetime',
        'created_at' => 'immutable_datetime',
    ];

    public const IDENTITY_FIELDS = [
        'tenant_id', 'project_id', 'capability', 'action_type', 'trigger_type',
        'trigger_record_ids', 'rule_id', 'rule_version', 'action_key', 'epistemic_state',
        'autonomy_policy_id', 'effective_autonomy_level', 'evidence_used', 'proposed_change',
        'result_hash',
    ];

    /** Statuses that still count as "the same condition is already being tracked" for action_key uniqueness. */
    public const ACTIVE_STATUSES = ['proposed', 'executed', 'pending_approval', 'awaiting_human', 'approved'];

    public function policy()
    {
        return $this->belongsTo(AutonomyPolicy::class, 'autonomy_policy_id');
    }

    public function tasks()
    {
        return $this->hasMany(ProjectTask::class, 'autonomous_action_id');
    }

    protected static function booted(): void
    {
        static::updating(function (self $action) {
            foreach (self::IDENTITY_FIELDS as $field) {
                if ($action->isDirty($field)) {
                    throw new \RuntimeException(
                        'An autonomous action\'s identity ("'.str_replace('_', ' ', $field).'") is frozen at '
                        .'creation and can never change - it is the record of what triggered this action and '
                        .'what authorized it. Only its lifecycle fields (status, executed_change, notified_at, '
                        .'approved_by/at, cancelled_by/at, human_intervention_state) may move.'
                    );
                }
            }

            // executed_change and executed_at are set exactly once, at
            // execution - not part of IDENTITY_FIELDS (they start null) but
            // still not editable once written, or "what actually changed"
            // could quietly drift from what really happened.
            foreach (['executed_change', 'executed_at'] as $field) {
                if ($action->isDirty($field) && $action->getOriginal($field) !== null) {
                    throw new \RuntimeException(
                        '"'.str_replace('_', ' ', $field).'" is written once, at execution, and is not editable '
                        .'afterward - it is the evidentiary record of what actually happened, not a status a '
                        .'later process may revise.'
                    );
                }
            }
        });

        static::deleting(function () {
            throw new \RuntimeException('An autonomous action is never deleted - it is the audit trail itself.');
        });
    }
}
