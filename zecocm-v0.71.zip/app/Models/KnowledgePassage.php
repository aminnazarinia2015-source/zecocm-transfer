<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class KnowledgePassage extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = ['coordinates' => 'array', 'classification' => 'array'];

    public function version()
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'knowledge_source_version_id');
    }

    /**
     * D4: null for a passage stitched from more than one page (source_page_id
     * is deliberately null then - see KnowledgeController) or for a
     * plain-text/submitted-text source with no page structure at all. Never
     * assume this relation is loaded without a null-safe access - a passage
     * spanning pages has no single source page to point at.
     */
    public function sourcePage()
    {
        return $this->belongsTo(KnowledgeSourcePage::class, 'source_page_id');
    }
}
