<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleOfValueItem extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'scheduled_value_cents' => 'integer',
        'original_value_cents' => 'integer',
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
