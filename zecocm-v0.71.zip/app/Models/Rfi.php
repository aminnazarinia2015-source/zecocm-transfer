<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Rfi extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'number', 'subject', 'question', 'raised_by_org',
        'raised_at', 'ball_in_court', 'cost_impact', 'status', 'response',
        'response_seal', 'ai_dispositions', 'routing_history',
        'spec_section', 'plan_sheets', 'reference', 'schedule_impact',
        'linked_submittal_id', 'cost_impact_state',
    ];

    protected $casts = [
        'raised_at' => 'date',
        'response_seal' => 'array',
        'ai_dispositions' => 'array',
        'routing_history' => 'array',
    ];

    /** The submittal this question came out of, when there is one. */
    public function linkedSubmittal()
    {
        return $this->belongsTo(Submittal::class, 'linked_submittal_id');
    }

    /**
     * Three-state impact. "Not stated" is a real answer and is printed as such -
     * ZecoCM never renders silence as "No".
     */
    public function impact(string $which): string
    {
        $raw = $which === 'cost'
            ? ($this->cost_impact_state ?? ($this->cost_impact === null ? null : ($this->cost_impact ? 'yes' : 'no')))
            : $this->schedule_impact;

        return in_array($raw, ['yes', 'no'], true) ? $raw : 'not_stated';
    }

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    /**
     * Every AI suggestion/escalation AND what the human did with it is
     * appended here permanently (Aspect 19). Nothing is ever removed.
     */
    public function recordAiDisposition(array $result, string $action, int $userId): void
    {
        $log = $this->ai_dispositions ?? [];
        $log[] = [
            'result' => $result,
            'action' => $action,          // accepted|edited|rejected|escalation_followed
            'user_id' => $userId,
            'at' => now()->toIso8601String(),
        ];
        $this->ai_dispositions = $log;
    }
}
