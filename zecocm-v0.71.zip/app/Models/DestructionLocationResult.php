<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14B: one destruction attempt against one governed storage location, for
 * one tombstone. Append-only per attempt - a retried worker records a new
 * row rather than mutating a prior one, so what was actually observed on an
 * earlier pass is never lost. `EvidenceDestructionExecutor` treats a
 * location with an existing row whose post_delete_presence is false as
 * already resolved and skips re-deleting it (idempotency, E14B-11).
 */
class DestructionLocationResult extends Model
{
    use BelongsToTenant;

    protected $table = 'evidence_destruction_location_results';

    public const DELETED = 'deleted';

    public const NOT_FOUND = 'not_found';

    public const ERROR = 'error';

    public const SKIPPED_ALREADY_RESOLVED = 'skipped_already_resolved';

    protected $fillable = [
        'tenant_id', 'evidence_tombstone_id', 'location_key', 'attempted_at',
        'expected_digest', 'pre_delete_presence', 'delete_result',
        'post_delete_presence', 'verification_method', 'verified_at', 'error',
    ];

    protected $casts = [
        'attempted_at' => 'immutable_datetime',
        'verified_at' => 'immutable_datetime',
        'pre_delete_presence' => 'boolean',
        'post_delete_presence' => 'boolean',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Destruction location results are append-only; record a new attempt, never edit a prior one.'));
        static::deleting(fn () => throw new \LogicException('Destruction location results are append-only and cannot be deleted.'));
    }
}
