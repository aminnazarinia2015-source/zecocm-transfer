<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * The structured link between a daily report and the schedule activity it
 * documents work against - the missing piece that let TRACE-01/02 ask "does
 * a finalized daily report reference this activity, and on what date"
 * instead of guessing from free-text narrative. Follows the same lifecycle
 * as the DailyReport it belongs to (editable until locked on signature) -
 * this table does not invent a stricter immutability rule of its own.
 */
class DailyReportActivity extends Model
{
    use BelongsToTenant;

    public const STATUS_PERFORMED = 'performed';
    public const STATUS_NO_WORK_THIS_VISIT = 'no_work_this_visit';

    protected $fillable = [
        'tenant_id', 'daily_report_id', 'schedule_activity_id', 'work_status', 'notes',
    ];

    public function dailyReport()
    {
        return $this->belongsTo(DailyReport::class);
    }

    public function scheduleActivity()
    {
        return $this->belongsTo(ScheduleActivity::class);
    }
}
