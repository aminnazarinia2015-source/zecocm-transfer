<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * VIS-1: one row per deterministic scan-recovery attempt made for one page -
 * the append-only log Codex's ruling asked for, so a poor scan's recovery
 * path is fully reconstructable (what transform ran, at what DPI, against
 * which exact image bytes, with what result) rather than only the winning
 * attempt's numbers surviving. Immutable once written, the same discipline
 * every other evidentiary record in this codebase carries.
 */
class OcrExtractionAttempt extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $guarded = [];

    protected $casts = ['transform_sequence' => 'array', 'selected' => 'bool', 'has_structural_defect' => 'bool'];

    public function version()
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'knowledge_source_version_id');
    }
}
