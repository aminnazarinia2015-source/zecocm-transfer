<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PaymentSubmissionRule extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'effective_date' => 'date',
        'confirmed_at' => 'immutable_datetime',
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
