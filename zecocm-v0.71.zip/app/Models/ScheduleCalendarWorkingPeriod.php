<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleCalendarWorkingPeriod extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $fillable = ['tenant_id', 'schedule_calendar_id', 'weekday_iso', 'starts_at', 'ends_at'];
}
