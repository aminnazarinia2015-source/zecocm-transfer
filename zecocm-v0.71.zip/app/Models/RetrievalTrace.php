<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TR-18: one row per TRACE retrieval. Append-only - a retrieval already
 * happened by the time this row exists, and nothing about the past is ever
 * corrected in place, only superseded by a new retrieval's own new row (see
 * migration doc comment). Never carries passage body text, only locators and
 * scoring/authority facts.
 */
class RetrievalTrace extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'ai_run_id', 'query', 'retriever_version',
        'chunking_versions', 'authorization_state', 'sql_candidate_count',
        'stages', 'final_candidates', 'passages_cited', 'result_kind', 'escalation_basis',
    ];

    protected $casts = [
        'chunking_versions' => 'array',
        'authorization_state' => 'array',
        'stages' => 'array',
        'final_candidates' => 'array',
        'passages_cited' => 'array',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Retrieval traces are append-only; a new retrieval writes a new row, never edits a prior one.'));
        static::deleting(fn () => throw new \LogicException('Retrieval traces are append-only and cannot be deleted.'));
    }
}
