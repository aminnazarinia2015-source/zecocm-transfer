<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * One row per provider webhook event ever received. Existence of a row with this
 * `provider_event_id` means "already processed" — checked BEFORE acting on an event, per the
 * idempotency requirement both design reviews (Gemini, Codex) called mandatory. A retried webhook
 * is a guaranteed no-op, never a second provisioning attempt.
 */
class PaymentWebhookEvent extends Model
{
    protected $fillable = ['provider', 'provider_event_id', 'event_type', 'payload', 'processed_at'];

    protected $casts = [
        'payload' => 'array',
        'processed_at' => 'datetime',
    ];
}
