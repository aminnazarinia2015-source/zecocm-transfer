<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * Append-only register of documents that were actually issued. A transmittal can be
 * previewed any number of times; issuing one writes a row here and that row never changes.
 */
class IssuedDocument extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'record_type', 'record_id', 'document_number',
        'revision', 'content_sha256', 'parties', 'clock', 'attachments', 'issued_by', 'issued_at',
    ];

    protected $casts = [
        'parties' => 'array',
        'clock' => 'array',
        'attachments' => 'array',
        'issued_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Issued documents are immutable; issue a new revision.'));
        static::deleting(fn () => throw new \LogicException('Issued documents cannot be deleted.'));
    }
}
