<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Subcontract extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'listed_at_bid' => 'boolean',
        'original_amount_cents' => 'integer',
        'retention_basis_points' => 'integer',
        'executed_on' => 'date',
    ];

    public function partner()
    {
        return $this->belongsTo(TradePartner::class, 'trade_partner_id');
    }

    public function credentials()
    {
        return $this->hasMany(ComplianceCredential::class);
    }

    /**
     * A listed subcontractor cannot simply be swapped out.
     *
     * The Subletting and Subcontracting Fair Practices Act (Public Contract Code
     * s. 4107) requires the awarding authority's written consent to substitute a
     * sub listed at bid, on one of the specific statutory grounds. Silent
     * substitution is a violation with penalties attached, so the fact of
     * listing is recorded rather than inferred from anything.
     */
    public function requiresConsentToSubstitute(): bool
    {
        return (bool) $this->listed_at_bid;
    }
}
