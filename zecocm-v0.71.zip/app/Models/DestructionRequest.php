<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14A: a PROPOSAL to destroy, never an action. Governed self-improvement
 * already established this codebase's habit - "proposes and never applies" -
 * and destruction inherits it. Authorization is a separate, explicit event
 * (see EvidenceDestructionService::authorize()); nothing here executes.
 */
class DestructionRequest extends Model
{
    use BelongsToTenant;

    public const PENDING = 'pending';

    public const AUTHORIZED = 'authorized';

    public const REFUSED = 'refused';

    protected $fillable = [
        'tenant_id', 'media_item_id', 'requested_by', 'requested_at', 'reason',
        'status', 'refusal_reason', 'authorized_by', 'authorized_at',
        'authority_citation', 'hold_check_result',
    ];

    protected $casts = [
        'requested_at' => 'immutable_datetime',
        'authorized_at' => 'immutable_datetime',
    ];

    public function tombstone()
    {
        return $this->hasOne(EvidenceTombstone::class);
    }
}
