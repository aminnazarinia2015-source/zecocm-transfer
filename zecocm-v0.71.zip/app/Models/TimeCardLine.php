<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class TimeCardLine extends Model
{
    use BelongsToTenant;

    public const RESOURCE_LABOR = 'labor';
    public const RESOURCE_EQUIPMENT = 'equipment';

    protected $fillable = [
        'tenant_id', 'time_card_id', 'schedule_activity_id', 'work_date',
        'resource_code', 'resource_name', 'resource_type', 'pay_class', 'cost_code', 'hours', 'notes',
    ];

    protected $casts = [
        'work_date' => 'date',
        'hours' => 'decimal:2',
    ];

    public function timeCard()
    {
        return $this->belongsTo(TimeCard::class);
    }

    public function scheduleActivity()
    {
        return $this->belongsTo(ScheduleActivity::class);
    }
}
