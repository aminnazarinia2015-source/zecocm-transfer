<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * EV-14A / B9: "Evidence can be silently unlinked from the RFI it supports"
 * was the finding. A link is now append-only, the same discipline as an
 * imported schedule fact - see `ImmutableImportedScheduleRecord`, whose
 * pattern this mirrors directly. An association is never removed; it is
 * superseded by an `EvidenceUnlinkEvent`, so the original link still proves
 * the evidence was once associated with the record, and `unlink()` always
 * has an actor and a reason attached. See `EvidenceLinkService::unlink()`.
 */
class EvidenceLink extends Model
{
    use BelongsToTenant;

    protected $fillable = ['tenant_id', 'media_item_id', 'record_type', 'record_id', 'linked_by'];

    protected static function boot(): void
    {
        parent::boot();
        static::updating(fn () => throw new \LogicException('Evidence links are append-only; unlink with EvidenceLinkService::unlink(), never edit a link in place.'));
        static::deleting(fn () => throw new \LogicException('Evidence links are append-only and cannot be deleted; see EvidenceLinkService::unlink().'));
    }

    public function unlinkEvents()
    {
        return $this->hasMany(EvidenceUnlinkEvent::class);
    }

    /** True once an unlink event has been recorded against this link. */
    public function isUnlinked(): bool
    {
        return $this->unlinkEvents()->exists();
    }
}
