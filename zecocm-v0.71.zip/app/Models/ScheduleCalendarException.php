<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleCalendarException extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    public const UPDATED_AT = null;

    protected $fillable = ['tenant_id', 'schedule_calendar_id', 'exception_date', 'is_working', 'label'];

    protected $casts = ['exception_date' => 'date', 'is_working' => 'boolean'];

    public function periods()
    {
        return $this->hasMany(ScheduleCalendarExceptionPeriod::class);
    }
}
