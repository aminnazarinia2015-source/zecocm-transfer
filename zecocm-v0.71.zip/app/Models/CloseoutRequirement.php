<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * A7's closeout obligation (as-built, O&M manual, training, etc.). This model
 * did not exist before AUTO-2 - A7 (`database/migrations/
 * 2026_08_25_000046_create_closeout_and_warranty.php`) shipped the schema
 * and `App\Domain\Closeout\CloseoutReadiness` (pure logic, array in/out) but
 * nothing had yet wired either to Eloquent or to real project data.
 */
class CloseoutRequirement extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    public function deliverable()
    {
        return $this->hasOne(CloseoutDeliverable::class);
    }
}
