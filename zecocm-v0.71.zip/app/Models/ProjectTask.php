<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * A generic project task/reminder record. Did not exist anywhere in this
 * codebase before AUTO-2 (confirmed by search) - built here because several
 * of AUTO-2's seeded AUTO-tier actions ("create a task/reminder", "create a
 * deliverable request") need somewhere to put the result, and none of the
 * existing domain models (ClaimRequirement, ClosoutDeliverable, ...) is a
 * generic to-do.
 *
 * Deliberately NOT append-only: a task is a working record a human completes
 * or dismisses, not an evidentiary fact. What IS preserved is which
 * AutonomousAction (if any) created it, and that link is frozen - see
 * booted().
 */
class ProjectTask extends Model
{
    use BelongsToTenant;

    protected $table = 'tasks';

    protected $guarded = [];

    protected $casts = [
        'due_on' => 'date',
        'completed_at' => 'immutable_datetime',
    ];

    public function autonomousAction()
    {
        return $this->belongsTo(AutonomousAction::class, 'autonomous_action_id');
    }

    public function subject()
    {
        return $this->morphTo();
    }

    protected static function booted(): void
    {
        static::updating(function (self $task) {
            if ($task->isDirty('autonomous_action_id') && $task->getOriginal('autonomous_action_id') !== null) {
                throw new \RuntimeException(
                    'A task\'s originating autonomous action cannot be changed once set - it is part of the '
                    .'audit trail for why this task exists.'
                );
            }
        });
    }
}
