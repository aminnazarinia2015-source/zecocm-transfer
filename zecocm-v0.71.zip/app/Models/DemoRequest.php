<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * A "show me the full product" lead from an entity/contractor via the homepage - not an
 * account, not a payment, just a request a human follows up on and schedules. Distinct from
 * ContractorRegistration (that's a paid-signup state machine) and from an instant demo Tenant
 * (that's a real, working, limited account provisioned immediately, no human involved).
 */
class DemoRequest extends Model
{
    public const STATUS_PENDING = 'pending';

    public const STATUS_CONTACTED = 'contacted';

    public const STATUS_SCHEDULED = 'scheduled';

    public const STATUS_CLOSED = 'closed';

    protected $fillable = [
        'company', 'contact_name', 'email', 'phone', 'entity_type', 'note', 'status',
    ];
}
