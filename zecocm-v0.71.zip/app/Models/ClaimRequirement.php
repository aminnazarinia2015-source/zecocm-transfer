<?php

namespace App\Models;

use App\Domain\Claims\ClaimClock;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ClaimRequirement extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'period_value' => 'integer',
        'confirmed_at' => 'immutable_datetime',
    ];

    public function trigger()
    {
        return $this->belongsTo(ClaimTriggerEvent::class, 'claim_trigger_event_id');
    }

    public function calculations()
    {
        return $this->hasMany(ClaimClockCalculation::class);
    }

    public function complianceEvents()
    {
        return $this->hasMany(ClaimComplianceEvent::class);
    }

    /**
     * Missing this bars the claim.
     *
     * The one distinction the whole module exists for. Everything else in the
     * product can be late and merely embarrassing.
     */
    public function isPreservative(): bool
    {
        return $this->consequence_class === ClaimClock::PRESERVATIVE;
    }

    /**
     * A confirmed requirement is a statement about the contract, and changing
     * what the contract says after somebody relied on it is not an edit.
     *
     * The period, the counting rule, the authority and the consequence are
     * frozen at confirmation. A contract amendment that changes a notice period
     * is a NEW requirement superseding this one - which is what preserves the
     * ability to say "on 1 September the governing period was ten days, and it
     * became five on the 14th."
     */
    protected static function booted(): void
    {
        static::updating(function (self $requirement) {
            if ($requirement->getOriginal('status') !== 'confirmed') {
                return;
            }

            foreach (['period_value', 'period_unit', 'calendar_rule', 'authority_citation',
                'authority_type', 'consequence_class', 'trigger_type'] as $field) {
                if ($requirement->isDirty($field)) {
                    throw new \RuntimeException(
                        'A confirmed claim requirement cannot be edited. "'.str_replace('_', ' ', $field)
                        .'" is part of what somebody confirmed the contract says, and people have relied on it. '
                        .'An amendment that changes the requirement is a NEW requirement superseding this one - which is '
                        .'what lets ZecoCM still answer what the governing period was on a date in the past.'
                    );
                }
            }
        });
    }
}
