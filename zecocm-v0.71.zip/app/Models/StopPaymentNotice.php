<?php

namespace App\Models;

use App\Domain\Payment\StopNoticeWithholding;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class StopPaymentNotice extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'served_on' => 'date',
        'preliminary_notice_served_on' => 'date',
        'resolved_on' => 'date',
        'preliminary_notice_on_file' => 'boolean',
        'release_bond_on_file' => 'boolean',
        'claimed_amount_cents' => 'integer',
        'served_amount_locked_at' => 'immutable_datetime',
    ];

    /**
     * Civil Code s. 9352 limits the claim to the amount due for work provided
     * THROUGH THE NOTICE DATE. A served notice is a historical act; later
     * unpaid work does not enlarge it, and a claimed amount wired to a live
     * accounts-payable balance would quietly do exactly that. Enlarging the
     * claim takes a new notice, which is a new record.
     */
    protected static function booted(): void
    {
        static::updating(function (self $notice) {
            if ($notice->served_amount_locked_at !== null && $notice->isDirty('claimed_amount_cents')) {
                throw new \RuntimeException(
                    'The claimed amount on a served stop payment notice cannot be changed. Civil Code section 9352 '
                    .'limits it to the amount due for work provided through the notice date, so the figure froze when '
                    .'the notice was served. A larger claim is a new notice, not an edit to this one.'
                );
            }
        });
    }

    public function partner()
    {
        return $this->belongsTo(TradePartner::class, 'trade_partner_id');
    }

    /** Civil Code s. 9358: the claim plus 25 per cent, rounded up. */
    public function withholdCents(): int
    {
        return StopNoticeWithholding::amountFor((int) $this->claimed_amount_cents);
    }

    /**
     * Whether this notice still freezes money. A notice marked bonded around
     * without the bond in the file freezes it exactly as before.
     */
    public function stillFreezesFunds(): bool
    {
        if ($this->status === StopNoticeWithholding::BONDED_AROUND) {
            return ! $this->release_bond_on_file;
        }

        return $this->status === StopNoticeWithholding::OPEN;
    }
}
