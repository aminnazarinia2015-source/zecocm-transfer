<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AnalysisRun extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'from_version_id', 'to_version_id', 'idempotency_key',
        'status', 'progress_percent', 'stage_status', 'parser_version', 'cpm_engine_version',
        'rules_version', 'ai_model', 'ai_prompt_version', 'source_hashes',
        'authorization_scope', 'assumptions', 'retrieval_times', 'error', 'queued_by',
        'started_at', 'finished_at', 'cancel_requested_at', 'cancelled_at',
    ];

    protected $casts = [
        'stage_status' => 'array',
        'source_hashes' => 'array',
        'authorization_scope' => 'array',
        'assumptions' => 'array',
        'retrieval_times' => 'array',
        'started_at' => 'immutable_datetime',
        'finished_at' => 'immutable_datetime',
        'cancel_requested_at' => 'immutable_datetime',
        'cancelled_at' => 'immutable_datetime',
    ];

    public function deltas()
    {
        return $this->hasMany(ScheduleDelta::class);
    }
}
