<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AiRun extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'authorization_scope' => 'array', 'retrieval_scope' => 'array', 'source_manifest' => 'array',
        'assumptions' => 'array', 'result' => 'array', 'screen_context' => 'array', 'cancel_requested_at' => 'immutable_datetime',
        'started_at' => 'immutable_datetime', 'completed_at' => 'immutable_datetime',
        'cost_measured' => 'boolean',
    ];
}
