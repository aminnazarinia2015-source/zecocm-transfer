<?php

namespace App\Models;

use App\Domain\Knowledge\AcquisitionGate;
use App\Domain\Knowledge\InstructionTrust;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AcquiredDocument extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'retrieved_at' => 'immutable_datetime',
        'verified_at' => 'immutable_datetime',
        'retracted_at' => 'immutable_datetime',
        'byte_size' => 'integer',
        'acquisition_metadata' => 'array',
        'redirect_chain' => 'array',
        'retrieved_after_revocation' => 'boolean',
    ];

    /**
     * The axis that never moves.
     *
     * Verification changes whether this document may support an answer. It
     * does not, cannot, and must never change whether text inside it may
     * influence how the system behaves. Written as a method returning a
     * constant rather than read from the column, so that a stray UPDATE cannot
     * make it say something else.
     */
    public function instructionTrust(): string
    {
        return InstructionTrust::EXTERNAL_UNTRUSTED;
    }

    protected static function booted(): void
    {
        static::saving(function (self $document) {
            // There is one legal value and this is what makes that true rather
            // than merely intended.
            $document->instruction_trust = InstructionTrust::EXTERNAL_UNTRUSTED;
        });
    }

    public function window()
    {
        return $this->belongsTo(AcquisitionWindow::class, 'acquisition_window_id');
    }

    /**
     * The only scope retrieval may ever use for acquired material.
     *
     * Written as a scope rather than left to each caller because "remember to
     * filter out the quarantined ones" is not a control. Anything not
     * explicitly verified is invisible - including a state somebody adds next
     * year without thinking about this query.
     */
    public function scopeRetrievable($query)
    {
        return $query->where('quarantine_state', AcquisitionGate::VERIFIED);
    }
}
