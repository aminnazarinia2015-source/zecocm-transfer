<?php

namespace App\Models;

use App\Models\Concerns\ImmutableImportedScheduleRecord;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PlanSheetVersion extends Model
{
    use BelongsToTenant, ImmutableImportedScheduleRecord;

    protected $guarded = [];

    protected $casts = ['issued_at' => 'date'];

    public function sheet()
    {
        return $this->belongsTo(PlanSheet::class, 'plan_sheet_id');
    }

    public function sourceVersion()
    {
        return $this->belongsTo(KnowledgeSourceVersion::class, 'knowledge_source_version_id');
    }

    public function markups()
    {
        return $this->hasMany(PlanMarkup::class);
    }

    public function review()
    {
        return $this->hasOne(PlanRevisionReview::class);
    }
}
