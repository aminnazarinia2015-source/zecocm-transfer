<?php

namespace App\Models;

use App\Domain\Licensing\CapabilityCatalog;
use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    protected $fillable = [
        'name', 'type', 'entitlements', 'status',
        'sponsor_role', 'parent_tenant_id', 'branch_name', 'is_account_owner',
        'legal_name', 'address_lines', 'brand_accent', 'brand_mark',
        'is_demo', 'demo_expires_at',
    ];

    protected $casts = [
        'entitlements' => 'array',
        'address_lines' => 'array',
        'is_account_owner' => 'boolean',
        'is_demo' => 'boolean',
        'demo_expires_at' => 'datetime',
    ];

    public function projects()
    {
        return $this->hasMany(Project::class);
    }

    /** Portals this account created for its counterparties. */
    public function portals()
    {
        return $this->hasMany(self::class, 'parent_tenant_id');
    }

    /** The account that created this portal, if it is not itself the buyer. */
    public function sponsor()
    {
        return $this->belongsTo(self::class, 'parent_tenant_id');
    }

    public function capabilityGrants()
    {
        return $this->hasMany(CapabilityGrant::class);
    }

    /**
     * The seat a purchasing organisation occupies. ZecoCM does not assume a fixed
     * City -> CM -> contractor chain: whoever buys the system is the top of their own
     * world and defines the counterparties beneath them.
     *
     * @return array<string,string>
     */
    public static function sponsorRoles(): array
    {
        return [
            'owner_agency' => 'Owner agency (City, county, state, federal)',
            'cm_firm' => 'Construction management firm',
            'contractor' => 'Contractor',
            'designer' => 'Design firm / discipline',
            'internal' => 'Internal use only',
        ];
    }

    /** Counterparty portals this sponsor may create - everyone except its own seat. */
    public function assignableRoles(): array
    {
        $roles = self::sponsorRoles();
        unset($roles['internal']);
        if ($this->sponsor_role !== null) {
            unset($roles[$this->sponsor_role]);
        }

        return $roles;
    }

    /** Sector-honest licence defaults by customer type; the grantor edits freely after. */
    public static function defaultEntitlements(string $type): array
    {
        // Defaults must never pre-sell roadmap entries. Planned capabilities
        // remain visible in the catalogue but require an explicit future grant
        // after they are genuinely operational.
        $all = CapabilityCatalog::operationalLicensableKeys();

        return match (true) {
            str_contains(strtolower($type), 'internal') => array_values(array_diff($all, ['schedule_intelligence'])),
            default => $all,
        };
    }

    /**
     * Legacy section check retained for older call sites. Licence truth now lives in
     * capability_grants and is answered by App\Domain\Licensing\CapabilityLicense.
     */
    public function hasSection(string $section): bool
    {
        return in_array($section, $this->entitlements ?? [], true);
    }
}
