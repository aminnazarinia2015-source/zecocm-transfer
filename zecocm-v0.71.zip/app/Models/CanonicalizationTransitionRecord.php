<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CanonicalizationTransitionRecord extends Model
{
    protected $guarded = [];

    protected $casts = ['authored_at' => 'immutable_datetime'];

    public function finding()
    {
        return $this->belongsTo(CanonicalizationFinding::class, 'canonicalization_finding_id');
    }

    public function author()
    {
        return $this->belongsTo(User::class, 'authored_by');
    }
}
