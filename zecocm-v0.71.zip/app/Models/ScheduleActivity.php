<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleActivity extends Model
{
    use BelongsToTenant;

    /**
     * TRACE Progress Evidence Cross-Check eligibility (Codex's point 10): only
     * CONSTRUCTION is treated as real field-production work that a missing
     * daily report can be flagged against. Everything else - including an
     * unclassified (null) activity_type - is excluded from TRACE-01/02 and
     * surfaced as a MAPPING_GAP finding instead of silently skipped. See
     * App\Domain\Trace\ProgressEvidenceCrossCheckService.
     */
    public const FIELD_PRODUCTION_TYPES = ['CONSTRUCTION'];

    protected $fillable = [
        'tenant_id', 'schedule_version_id', 'canonical_id', 'activity_code', 'name', 'activity_type',
        'wbs_path', 'start_planned', 'finish_planned', 'start_actual', 'finish_actual',
        'duration_minutes', 'total_float_minutes', 'is_critical', 'is_near_critical',
        'constraint_type', 'constraint_at', 'weather_sensitive', 'header_path',
        'ingestion_confidence', 'confirmation_status',
    ];

    protected $casts = [
        'constraint_at' => 'immutable_datetime',
        'start_planned' => 'immutable_datetime',
        'finish_planned' => 'immutable_datetime',
        'start_actual' => 'immutable_datetime',
        'finish_actual' => 'immutable_datetime',
        'is_critical' => 'boolean',
        'is_near_critical' => 'boolean',
        'weather_sensitive' => 'boolean',
        'ingestion_confidence' => 'float',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Imported schedule activities are immutable.'));
        static::deleting(fn () => throw new \LogicException('Imported schedule activities are immutable.'));
    }

    public function calendarAssignments()
    {
        return $this->hasMany(ScheduleActivityCalendarAssignment::class);
    }

    public function resources()
    {
        return $this->hasMany(ScheduleActivityResource::class);
    }

    public function dailyReportActivities()
    {
        return $this->hasMany(DailyReportActivity::class);
    }

    public function isFieldProduction(): bool
    {
        return in_array($this->activity_type, self::FIELD_PRODUCTION_TYPES, true);
    }
}
