<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ScheduleVersion extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'parent_version_id', 'kind', 'label', 'data_date',
        'submitted_by_org', 'submitted_at', 'review_status', 'source_file_media_id',
        'source_format', 'narrative_text', 'provisional', 'parser_name', 'parser_version',
        'source_sha256', 'row_count', 'ingest_assumptions', 'security_scan', 'created_by',
    ];

    protected $casts = [
        'data_date' => 'date',
        'submitted_at' => 'immutable_datetime',
        'provisional' => 'boolean',
        'ingest_assumptions' => 'array',
        'security_scan' => 'array',
    ];

    protected static function booted(): void
    {
        static::updating(function (ScheduleVersion $version): void {
            $changed = array_keys($version->getDirty());
            if (array_diff($changed, ['review_status', 'updated_at']) !== []) {
                throw new \LogicException('Schedule versions are immutable; create a new version or append a disposition event.');
            }
        });
        static::deleting(fn () => throw new \LogicException('Schedule versions are immutable and cannot be deleted.'));
    }

    public function activities()
    {
        return $this->hasMany(ScheduleActivity::class);
    }

    public function events()
    {
        return $this->hasMany(ScheduleVersionEvent::class);
    }

    public function calendars()
    {
        return $this->hasMany(ScheduleCalendar::class);
    }

    public function sourceFile()
    {
        return $this->belongsTo(MediaItem::class, 'source_file_media_id');
    }
}
