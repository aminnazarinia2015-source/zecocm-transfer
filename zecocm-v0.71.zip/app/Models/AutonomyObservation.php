<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * AUTO-2: the record that a NOT_AUTOMATABLE condition was seen, even though
 * no AutonomousAction was created for it.
 *
 * Codex's point, verbatim: "no action object - correct. No historical
 * observation whatsoever - potentially too silent... you may not be able to
 * explain why Steward saw a problem but generated no action." This is
 * intentionally NOT an AutonomousAction (it has no trigger/rule/evidence
 * chain leading to a proposed change, because none is ever proposed for a
 * NOT_AUTOMATABLE action type) and it is intentionally append-only for the
 * same reason every other evidentiary record in this codebase is: it is the
 * proof a refusal happened, not a working record.
 */
class AutonomyObservation extends Model
{
    use BelongsToTenant;

    public $timestamps = false;

    protected $guarded = [];

    protected $casts = [
        'trigger_record_ids' => 'array',
        'observed_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(function () {
            throw new \RuntimeException('An autonomy observation cannot be edited.');
        });

        static::deleting(function () {
            throw new \RuntimeException('An autonomy observation cannot be deleted.');
        });
    }
}
