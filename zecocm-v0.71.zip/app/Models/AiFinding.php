<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * Codex's ruling that closed this design: every TRACE finding must be one of
 * three logical classes - OBSERVATION ("record X says A, record Y says B"),
 * DATA_GAP ("expected evidence could not be located"), or PROPOSAL ("you may
 * want to review X") - and never an ADJUDICATION ("contractor is delayed",
 * "payment is unsupported", "withhold $X"). CLASSES below is the enforced
 * list; there is deliberately no fourth value. This is a system-wide TRACE
 * doctrine, not just a rule for this one feature, so any future feature
 * reusing this table inherits the same guard.
 *
 * A finding is never a payment classification (no WITHHOLD/REJECT/INVALID
 * category) - it is orthogonal to PayApplicationReview and only ever
 * connects to that workflow through a human explicitly promoting it
 * (status=PROMOTED), recorded here as a fact about this finding.
 *
 * Only status/resolution fields may change after creation - what was found,
 * against what evidence, is fixed at evaluation time.
 */
class AiFinding extends Model
{
    use BelongsToTenant;

    public const CLASSES = ['OBSERVATION', 'DATA_GAP', 'PROPOSAL'];

    public const CATEGORIES = [
        'RECORD_MISMATCH', 'CORROBORATION_GAP', 'SCHEDULE_STATUS_MISMATCH',
        'MAPPING_GAP', 'DATA_STALENESS', 'PERIOD_ALIGNMENT_ISSUE',
    ];

    public const SEVERITIES = ['INFO', 'REVIEW', 'HIGH_ATTENTION'];

    public const STATUS_OPEN = 'OPEN';
    public const STATUS_DISMISSED = 'DISMISSED';
    public const STATUS_PROMOTED = 'PROMOTED';

    protected $fillable = [
        'tenant_id', 'pay_application_id', 'pay_application_review_context_id', 'ai_run_id',
        'rule_id', 'rule_version', 'category', 'finding_class', 'severity', 'summary',
        'searched_universe', 'status', 'resolved_by', 'resolved_at', 'resolution_note',
        'evaluated_at',
    ];

    protected $casts = [
        'searched_universe' => 'array',
        'resolved_at' => 'immutable_datetime',
        'evaluated_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::creating(function (self $finding): void {
            $finding->status ??= self::STATUS_OPEN;

            if (! in_array($finding->finding_class, self::CLASSES, true)) {
                throw new \LogicException(
                    "AiFinding.finding_class must be one of ".implode(', ', self::CLASSES)
                    ." - TRACE never records an adjudication. Got: {$finding->finding_class}."
                );
            }
        });

        static::updating(function (self $finding): void {
            $changed = array_keys($finding->getDirty());
            $allowed = ['status', 'resolved_by', 'resolved_at', 'resolution_note', 'updated_at'];
            if (array_diff($changed, $allowed) !== []) {
                throw new \LogicException(
                    'An AiFinding\'s evaluation (what was found, against what evidence) is fixed at '
                    .'creation - only its resolution status may change. A re-evaluation writes a new finding.'
                );
            }
        });
    }

    public function payApplication()
    {
        return $this->belongsTo(PayApplication::class);
    }

    public function reviewContext()
    {
        return $this->belongsTo(PayApplicationReviewContext::class, 'pay_application_review_context_id');
    }

    public function evidence()
    {
        return $this->hasMany(FindingEvidence::class);
    }

    public function resolvedBy()
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }
}
