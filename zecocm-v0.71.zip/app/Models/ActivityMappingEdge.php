<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class ActivityMappingEdge extends Model
{
    use BelongsToTenant;

    public const UPDATED_AT = null;

    protected $fillable = [
        'tenant_id', 'mapping_group_id', 'from_activity_id', 'to_activity_id', 'edge_confidence',
    ];

    protected $casts = ['edge_confidence' => 'float'];
}
