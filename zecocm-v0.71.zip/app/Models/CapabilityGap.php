<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class CapabilityGap extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'evidence' => 'array',
        'occurrences' => 'integer',
        'distinct_askers' => 'integer',
        'distinct_projects' => 'integer',
        'reproducible' => 'boolean',
        'includes_external_usage' => 'boolean',
        'first_seen_at' => 'immutable_datetime',
        'last_seen_at' => 'immutable_datetime',
        'authorized_at' => 'immutable_datetime',
    ];
}
