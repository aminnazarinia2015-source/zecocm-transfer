<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class TimeCardEntry extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'daily_report_id', 'resource_code', 'resource_name',
        'resource_type', 'pay_class', 'cost_code', 'hours',
    ];

    protected $casts = ['hours' => 'decimal:2'];
}
