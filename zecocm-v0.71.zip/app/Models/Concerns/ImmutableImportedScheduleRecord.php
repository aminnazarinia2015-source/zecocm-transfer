<?php

namespace App\Models\Concerns;

trait ImmutableImportedScheduleRecord
{
    public static function bootImmutableImportedScheduleRecord(): void
    {
        static::updating(fn () => throw new \LogicException('Imported schedule facts are immutable; ingest a new schedule version.'));
        static::deleting(fn () => throw new \LogicException('Imported schedule facts are immutable and cannot be deleted.'));
    }
}
