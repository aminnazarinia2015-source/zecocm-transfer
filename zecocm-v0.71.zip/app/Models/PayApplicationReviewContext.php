<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/**
 * TRACE Progress Evidence Cross-Check - see
 * claude/trace-progress-vs-schedule-deviation-design-brief.md.
 *
 * A frozen snapshot of which schedule version/data-date applied when a pay
 * application entered TRACE review. Fixes the "active ScheduleVersion" bug
 * Codex's review caught: without a frozen reference, re-running the analysis
 * later (after newer schedule versions exist) could silently change what an
 * old pay application's findings say. Write-once - a later re-evaluation
 * against a newer schedule version creates its own new context row, it never
 * edits this one.
 */
class PayApplicationReviewContext extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'pay_application_id', 'period_start', 'period_end',
        'schedule_version_id', 'schedule_data_date', 'created_by', 'frozen_at',
    ];

    protected $casts = [
        'period_start' => 'date',
        'period_end' => 'date',
        'schedule_data_date' => 'date',
        'frozen_at' => 'immutable_datetime',
    ];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException(
            'A PayApplicationReviewContext is frozen at creation and never edited - a re-evaluation '
            .'against a different schedule version creates a new context row.'
        ));
        static::deleting(fn () => throw new \LogicException(
            'A PayApplicationReviewContext cannot be deleted - it is the record of what was compared '
            .'to produce past findings.'
        ));
    }

    public function payApplication()
    {
        return $this->belongsTo(PayApplication::class);
    }

    public function scheduleVersion()
    {
        return $this->belongsTo(ScheduleVersion::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function findings()
    {
        return $this->hasMany(AiFinding::class);
    }
}
