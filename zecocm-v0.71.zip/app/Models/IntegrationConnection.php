<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class IntegrationConnection extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'provider', 'status', 'external_account_id',
        'external_account_name', 'scopes', 'token_expires_at', 'sync_cursor',
        'settings', 'last_synced_at', 'last_error', 'authorized_by',
    ];

    protected $hidden = ['access_token_ciphertext', 'refresh_token_ciphertext', 'sync_cursor'];

    protected $casts = [
        'scopes' => 'array',
        'settings' => 'array',
        'token_expires_at' => 'immutable_datetime',
        'last_synced_at' => 'immutable_datetime',
    ];

    public function setTokens(string $accessToken, ?string $refreshToken): void
    {
        $this->access_token_ciphertext = Crypt::encryptString($accessToken);
        $this->refresh_token_ciphertext = $refreshToken !== null ? Crypt::encryptString($refreshToken) : null;
    }

    public function accessToken(): ?string
    {
        return $this->access_token_ciphertext ? Crypt::decryptString($this->access_token_ciphertext) : null;
    }

    public function refreshToken(): ?string
    {
        return $this->refresh_token_ciphertext ? Crypt::decryptString($this->refresh_token_ciphertext) : null;
    }
}
