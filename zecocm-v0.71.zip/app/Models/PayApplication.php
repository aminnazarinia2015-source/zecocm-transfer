<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class PayApplication extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'period_from' => 'date',
        'period_to' => 'date',
        'submitted_at' => 'immutable_datetime',
        'approved_at' => 'immutable_datetime',
        'paid_at' => 'immutable_datetime',
        'certified_at' => 'immutable_datetime',
        'retention_basis_points' => 'integer',
        'clock_snapshot' => 'array',
        'seal' => 'array',
    ];

    public function lines()
    {
        return $this->hasMany(PayApplicationLine::class);
    }

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function autonomousAction()
    {
        return $this->belongsTo(AutonomousAction::class, 'autonomous_action_id');
    }

    /**
     * Mirrors ProjectTask::booted(): what created this application, if
     * something did so autonomously, is part of the audit trail and cannot
     * be changed once set.
     */
    protected static function booted(): void
    {
        static::updating(function (self $application) {
            if ($application->isDirty('autonomous_action_id') && $application->getOriginal('autonomous_action_id') !== null) {
                throw new \RuntimeException(
                    'A pay application\'s originating autonomous action cannot be changed once set - it is part '
                    .'of the audit trail for why this application exists.'
                );
            }
        });
    }
}
