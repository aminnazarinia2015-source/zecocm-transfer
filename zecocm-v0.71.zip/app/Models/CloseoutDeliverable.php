<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

/** The ladder state (required/assigned/evidence_ready/submitted/accepted) for one CloseoutRequirement. */
class CloseoutDeliverable extends Model
{
    use BelongsToTenant;

    protected $guarded = [];

    protected $casts = [
        'submitted_at' => 'immutable_datetime',
        'accepted_at' => 'immutable_datetime',
    ];

    public function requirement()
    {
        return $this->belongsTo(CloseoutRequirement::class, 'closeout_requirement_id');
    }
}
