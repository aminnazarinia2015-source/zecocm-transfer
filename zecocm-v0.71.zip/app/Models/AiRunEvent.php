<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class AiRunEvent extends Model
{
    use BelongsToTenant;

    protected $guarded = [];
    protected $casts = ['payload' => 'array'];
}
