<?php

namespace App\Console\Commands;

use App\Domain\Release\ReleaseManifestBuilder;
use Illuminate\Console\Command;

/**
 * REL-1: Codex's second and third adversarial findings, closed by the same
 * mechanism because they are the same failure at bottom - "prove exact
 * expected release/commit/package identity, not merely that this is A
 * valid package."
 *
 * - Tarball swapped/modified after its manifest was verified -> this
 *   command re-hashes the actual file on disk right now and refuses if it
 *   no longer matches what the manifest recorded.
 * - The wrong (but otherwise valid) release deployed - e.g. v0.90's
 *   tarball staged while v0.92 was intended - fails for the same reason:
 *   the file's real hash right now will not match v0.92's manifest, since
 *   each version's package is genuinely different content.
 *
 * Run this immediately before typing the deploy command that extracts the
 * tarball on the droplet - it is deliberately a separate, later check than
 * release:build-manifest, which only proves the artifact was correct AT
 * BUILD TIME.
 *
 *   php artisan release:verify-artifact 0.92 --tarball=deploy/zecocm-v0.92-delta.tar.gz
 */
class VerifyReleaseArtifact extends Command
{
    protected $signature = 'release:verify-artifact {version} {--tarball= : path to the tarball you are about to deploy}';

    protected $description = 'REL-1: prove the tarball about to be deployed is exactly the one this version\'s manifest verified';

    public function handle(): int
    {
        $version = $this->argument('version');
        $manifest = ReleaseManifestBuilder::latestManifestFor($version);

        if ($manifest === null) {
            $this->error("No release manifest found for {$version}. Run release:build-manifest first.");

            return self::FAILURE;
        }

        if (! $manifest->isVerified()) {
            $this->error("{$version}'s own manifest is not verified (status: {$manifest->verification_status}) - it must not be deployed.");

            return self::FAILURE;
        }

        $tarballPath = $this->option('tarball') ?? $manifest->tarball_path;

        if ($tarballPath === null || ! is_file($tarballPath)) {
            $this->error("Tarball not found at {$tarballPath}.");

            return self::FAILURE;
        }

        $actualHash = hash_file('sha256', $tarballPath);

        if ($actualHash !== $manifest->tarball_sha256) {
            $this->error(
                "ARTIFACT MISMATCH: {$tarballPath} hashes to {$actualHash}, but {$version}'s verified ".
                "manifest recorded {$manifest->tarball_sha256}. This is either a swapped/modified tarball ".
                "or the wrong version's package - refusing. Do not deploy this file as {$version}."
            );

            return self::FAILURE;
        }

        $this->info("{$version} artifact confirmed: {$tarballPath} matches the verified manifest exactly (commit {$manifest->source_commit}). Safe to deploy.");

        return self::SUCCESS;
    }
}
