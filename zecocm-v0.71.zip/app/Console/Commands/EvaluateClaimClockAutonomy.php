<?php

namespace App\Console\Commands;

use App\Domain\Autonomy\ClaimClockAutonomyEvaluator;
use Illuminate\Console\Command;

/**
 * AUTO-2's first seeded action, run on a schedule: for every confirmed claim
 * requirement in a project, evaluate whether its clock now says may_alert,
 * and - subject to the project's autonomy policy and the system ceiling for
 * claim_clock_reminder (AUTO by default, see config/autonomy_action_ceilings.php)
 * - create a reminder task, recorded as an explainable AutonomousAction.
 *
 *   php artisan autonomy:evaluate-claim-clocks {tenant} {project}
 */
class EvaluateClaimClockAutonomy extends Command
{
    protected $signature = 'autonomy:evaluate-claim-clocks {tenant : tenant id} {project : project id}';

    protected $description = 'AUTO-2: evaluate confirmed claim requirements for approaching deadlines and record/act on any that qualify';

    public function handle(ClaimClockAutonomyEvaluator $evaluator): int
    {
        $results = $evaluator->evaluateProject((int) $this->argument('tenant'), (int) $this->argument('project'));

        $created = 0;
        $skippedAlreadyOpen = 0;

        foreach ($results as $result) {
            if ($result['action'] === null) {
                $skippedAlreadyOpen++;

                continue;
            }

            $created++;
            $this->info("requirement #{$result['requirement_id']}: autonomous_action #{$result['action']->id} ({$result['action']->status})");
        }

        $this->info("Done. {$created} action(s) recorded, {$skippedAlreadyOpen} skipped (reminder already open).");

        return self::SUCCESS;
    }
}
