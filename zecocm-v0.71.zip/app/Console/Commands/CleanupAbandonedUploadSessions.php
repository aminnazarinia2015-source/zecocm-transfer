<?php

namespace App\Console\Commands;

use App\Models\UploadSession;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

/**
 * Scheduled hourly in routes/console.php (same pattern as
 * ops:dispatch-queue-heartbeat / ops:report-failed-job-delta). A chunked
 * upload session (see upload_sessions migration, UploadSessionController)
 * whose client never came back - closed tab, abandoned upload, a device that
 * died mid-transfer - would otherwise sit `in_progress` forever with its
 * partial assembly file silently taking up disk space. This sweeps any
 * session still `in_progress` after the configured age, marks it `failed`,
 * and deletes its assembly file.
 *
 * Deliberately conservative on the age threshold (24h default) - a genuinely
 * slow but still-in-progress resumable upload (a large drawing set over a
 * poor connection, resumed across several sessions of jobsite work) must
 * not be cut off by a routine sweep just because it is taking a while.
 */
class CleanupAbandonedUploadSessions extends Command
{
    protected $signature = 'uploads:cleanup-abandoned-sessions {--hours=24 : Age in hours after which an in_progress session is considered abandoned}';

    protected $description = 'Mark stale in_progress upload sessions failed and delete their partial assembly files.';

    public function handle(): int
    {
        $hours = max(1, (int) $this->option('hours'));
        $cutoff = now()->subHours($hours);

        $stale = UploadSession::query()
            ->withoutGlobalScopes()
            ->where('status', UploadSession::STATUS_IN_PROGRESS)
            ->where('created_at', '<', $cutoff)
            ->get();

        $count = 0;
        foreach ($stale as $session) {
            if (Storage::disk('local')->exists($session->storage_path)) {
                Storage::disk('local')->delete($session->storage_path);
            }
            $session->update(['status' => UploadSession::STATUS_FAILED, 'failure_reason' => 'Abandoned: no activity for over '.$hours.'h.']);
            $count++;
        }

        $this->info("Marked {$count} abandoned upload session(s) failed and cleaned up their assembly files.");

        return self::SUCCESS;
    }
}
