<?php

namespace App\Console\Commands;

use App\Jobs\StampQueueHeartbeat;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * OPS-14: scheduled once per `zecocm_ops.queue_heartbeat.interval_seconds`
 * (see routes/console.php). Inserts a new `queue_heartbeats` row with a
 * fresh, unique token and dispatches `StampQueueHeartbeat` carrying that
 * token onto the real queue. Deliberately does not upsert a single row -
 * see the migration's doc comment for why a stale/replayed stamp must not
 * be able to make a stopped worker look healthy.
 *
 * `--wait=N`: block for up to N seconds, polling until THIS token is
 * actually stamped handled, exiting non-zero on timeout. Per Codex's
 * review: `deploy/verify-live.sh` dispatching a heartbeat and immediately
 * curling /up would otherwise race the worker - a dispatch that hasn't
 * been picked up yet within a second or two is normal, not unhealthy, but
 * a bare dispatch-then-curl could still intermittently fail /up on a
 * perfectly healthy deploy depending on scheduling luck. Waiting here
 * (default unset - ordinary scheduled runs don't need it) makes deploy
 * verification prove actual consumption rather than merely hoping for it.
 */
class DispatchQueueHeartbeat extends Command
{
    protected $signature = 'ops:dispatch-queue-heartbeat {--wait=0 : Seconds to block for this exact heartbeat to be handled before exiting}';

    protected $description = 'OPS-14: insert a fresh queue heartbeat row and dispatch its worker-side stamp job.';

    public function handle(): int
    {
        $queue = (string) config('zecocm_ops.queue_heartbeat.queue', 'default');
        $token = (string) Str::uuid();

        DB::table('queue_heartbeats')->insert([
            'dispatch_token' => $token,
            'queue_name' => $queue,
            'dispatched_at' => now(),
            'handled_at' => null,
            'worker_identity' => null,
        ]);

        StampQueueHeartbeat::dispatch($token);

        $this->info("Dispatched queue heartbeat {$token} on queue {$queue}.");

        $waitSeconds = (int) $this->option('wait');
        if ($waitSeconds <= 0) {
            return self::SUCCESS;
        }

        $deadline = microtime(true) + $waitSeconds;
        while (microtime(true) < $deadline) {
            $handled = DB::table('queue_heartbeats')->where('dispatch_token', $token)->value('handled_at');
            if ($handled !== null) {
                $this->info("Heartbeat {$token} was handled within {$waitSeconds}s.");

                return self::SUCCESS;
            }
            usleep(500_000);
        }

        $this->error("Heartbeat {$token} was NOT handled within {$waitSeconds}s - the worker may not be consuming.");

        return self::FAILURE;
    }
}
