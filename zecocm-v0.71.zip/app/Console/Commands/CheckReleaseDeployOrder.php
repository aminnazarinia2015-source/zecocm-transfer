<?php

namespace App\Console\Commands;

use App\Domain\Release\ReleaseManifestBuilder;
use Illuminate\Console\Command;

/**
 * REL-1: "v0.87 -> v0.90 -> v0.92 deployment order can be verified from
 * manifest dependencies rather than human memory" (Codex's own framing).
 * Run this before typing a deploy command into the console - it reports
 * whether every version this one `depends_on` already has a healthy,
 * recorded deployment, instead of trusting whoever is at the keyboard to
 * remember the queue order correctly.
 */
class CheckReleaseDeployOrder extends Command
{
    protected $signature = 'release:check-deploy-order {version}';

    protected $description = 'REL-1: verify a release manifest\'s dependencies were actually deployed first';

    public function handle(): int
    {
        $manifest = ReleaseManifestBuilder::latestManifestFor($this->argument('version'));

        if ($manifest === null) {
            $this->error("No release manifest found for {$this->argument('version')}.");

            return self::FAILURE;
        }

        $missing = ReleaseManifestBuilder::deployOrderSatisfied($manifest->depends_on);

        if ($missing === []) {
            $this->info("{$manifest->version} is clear to deploy - all dependencies (".implode(', ', $manifest->depends_on).') are confirmed healthy-deployed.');

            return self::SUCCESS;
        }

        $this->error("{$manifest->version} is NOT clear to deploy - missing confirmed healthy deployment for: ".implode(', ', $missing));

        return self::FAILURE;
    }
}
