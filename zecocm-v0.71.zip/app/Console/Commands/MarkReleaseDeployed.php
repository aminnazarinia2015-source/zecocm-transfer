<?php

namespace App\Console\Commands;

use App\Domain\Release\ReleaseManifestBuilder;
use App\Models\ReleaseDeployment;
use Illuminate\Console\Command;

/**
 * REL-1: append-only record of an actual deploy attempt, written by whoever
 * ran the deploy command and observed deploy/verify-live.sh's own output -
 * mirrors EV-14B's execution-ledger pattern (a fact about what happened,
 * never a mutable status column on the manifest itself). Intended usage:
 * paste verify-live.sh's own printed line straight into --result.
 *
 *   php artisan release:mark-deployed 0.92 --by=Amin \
 *     --result="V092_LIVE d4=yes worker=active up_bare=200"
 */
class MarkReleaseDeployed extends Command
{
    protected $signature = 'release:mark-deployed {version}
        {--by= : who ran the deploy}
        {--result= : the exact line verify-live.sh printed}';

    protected $description = 'REL-1: record a real deploy attempt against a release manifest';

    public function handle(): int
    {
        $version = $this->argument('version');
        $result = $this->option('result') ?? '';
        $healthy = (bool) preg_match('/_LIVE\b.*\bhttp(_bare)?=200\b/', $result);

        ReleaseDeployment::create([
            'version' => $version,
            'release_manifest_id' => ReleaseManifestBuilder::latestManifestFor($version)?->id,
            'deployed_at' => now(),
            'deployed_by' => $this->option('by') ?? 'unknown',
            'verify_live_result' => $result,
            'http_healthy' => $healthy,
        ]);

        $this->info(($healthy ? 'Recorded healthy deploy' : 'Recorded UNHEALTHY deploy attempt')." for {$version}.");

        return self::SUCCESS;
    }
}
