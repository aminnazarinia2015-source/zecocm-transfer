<?php

namespace App\Console\Commands;

use App\Domain\Release\JunitTestManifest;
use App\Domain\Release\ReleaseManifestBuilder;
use Illuminate\Console\Command;

/**
 * REL-1: build (and persist, verified or failed) a release manifest for one
 * version, before that version's tarball is uploaded to the deploy queue.
 *
 * Usage:
 *   php artisan release:build-manifest 0.93 \
 *     --commit=$(git rev-parse HEAD) \
 *     --tarball=deploy/zecocm-v0.93-delta.tar.gz \
 *     --junit=/tmp/junit.xml \
 *     --baseline=0.92 \
 *     --required-suite="Tests\Feature\EvidenceInvariantTest" \
 *     --required-suite="Tests\Unit\GovernedContextBuilderTest" \
 *     --depends-on=0.92 \
 *     --justify="Tests\Feature\FooTest::test_bar=reason text|authorized by Amin"
 *
 * --junit must already exist (`php vendor/bin/phpunit --log-junit /tmp/junit.xml`
 * run first) - this command does not run the suite itself, so it is safe to
 * call against whatever junit log the actual CI/test run just produced.
 */
class BuildReleaseManifest extends Command
{
    protected $signature = 'release:build-manifest
        {version}
        {--commit= : source commit sha this build was tested at}
        {--tarball= : path to the packaged delta tarball, if one exists yet}
        {--junit= : path to a phpunit --log-junit XML file for this build}
        {--baseline= : prior release version to diff test IDs against}
        {--required-suite=* : test class names this release must still carry}
        {--depends-on=* : versions this release depends on being deployed first}
        {--justify=* : "TestId=reason|authorized_by[|renamed_to]" for each removed test}
        {--repo=. : path to the git repository}
        {--migrations=database/migrations : path to the migrations directory}';

    protected $description = 'REL-1: build and persist a release verification manifest';

    public function handle(ReleaseManifestBuilder $builder): int
    {
        $junitPath = $this->option('junit');
        if ($junitPath === null) {
            $this->error('--junit is required (run phpunit --log-junit first).');

            return self::FAILURE;
        }

        $currentTests = JunitTestManifest::fromXmlFile($junitPath);
        $baseline = ReleaseManifestBuilder::latestManifestFor($this->option('baseline'));

        $justifications = [];
        foreach ($this->option('justify') as $entry) {
            [$testId, $rest] = array_pad(explode('=', $entry, 2), 2, '');
            $parts = explode('|', $rest);
            $justifications[$testId] = [
                'reason' => $parts[0] ?? '',
                'authorized_by' => $parts[1] ?? '',
                'renamed_to' => $parts[2] ?? null,
            ];
        }

        $result = $builder->build([
            'version' => $this->argument('version'),
            'sourceCommit' => $this->option('commit') ?? 'unknown',
            'tarballPath' => $this->option('tarball'),
            'repoPath' => $this->option('repo'),
            'migrationsDir' => $this->option('migrations'),
            'currentTests' => $currentTests,
            'baseline' => $baseline,
            'justifications' => $justifications,
            'requiredSuites' => $this->option('required-suite'),
            'dependsOn' => $this->option('depends-on'),
        ]);

        if ($result->passed()) {
            $this->info("release:build-manifest {$this->argument('version')} VERIFIED - {$result->manifest->total_tests} tests, ".count($result->manifest->tests_added).' added, '.count($result->manifest->tests_removed).' removed (justified).');

            return self::SUCCESS;
        }

        $this->error("release:build-manifest {$this->argument('version')} FAILED:");
        foreach ($result->failures as $failure) {
            $this->line("  - {$failure}");
        }

        return self::FAILURE;
    }
}
