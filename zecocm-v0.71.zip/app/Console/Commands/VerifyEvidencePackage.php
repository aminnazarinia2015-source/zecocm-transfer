<?php

namespace App\Console\Commands;

use App\Domain\Provenance\PackageVerifier;
use Illuminate\Console\Command;

/**
 * The CLI the register asks for, and the reason it exists here is slightly
 * unusual: it is the PROOF that the specification is complete.
 *
 * This command reads a manifest file and nothing else. No database connection,
 * no ZecoCM installation state, no key material, no network. If it needed any
 * of those, the published specification would be incomplete and somebody
 * reimplementing it in Python on the other side of a dispute would discover
 * that at the worst possible moment.
 *
 * Exit codes are meant to be used by somebody else's script:
 *   0  verified
 *   1  failed - the record is not internally consistent with its manifest
 *   2  parts could not be verified, and are reported as neither sound nor unsound
 */
class VerifyEvidencePackage extends Command
{
    protected $signature = 'zecocm:verify-package {path : Path to manifest.json} {--json : Machine-readable output}';

    protected $description = 'Verify a ZecoCM evidence package against its own manifest, using nothing else.';

    public function handle(): int
    {
        $path = (string) $this->argument('path');

        if (! is_readable($path)) {
            $this->error('Cannot read '.$path);

            return 2;
        }

        $manifest = json_decode((string) file_get_contents($path), true);

        if (! is_array($manifest)) {
            $this->error('That file is not valid JSON.');

            return 2;
        }

        $result = PackageVerifier::verify($manifest);

        if ($this->option('json')) {
            $this->line(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

            return $this->exitCode($result['status']);
        }

        $this->newLine();
        $this->line('  '.strtoupper($result['status']));
        $this->line('  '.$result['statement']);
        $this->newLine();

        foreach ($result['phases'] as $phase) {
            $this->line(sprintf('  %-18s %-14s %s', $phase['phase'], $phase['status'], $phase['finding']));
        }

        foreach ($result['chains'] as $chain) {
            if ($chain['findings'] === []) {
                continue;
            }
            $this->newLine();
            $this->line('  '.$chain['name'].' #'.$chain['group'].'  ('.$chain['status'].')');
            foreach ($chain['findings'] as $finding) {
                $this->line('    - '.$finding);
            }
        }

        // Printed on every run, including successful ones. A verifier whose
        // limits appear only on failure is a verifier whose successes get
        // quoted as proof of more than they prove.
        $this->newLine();
        $this->line('  This verification DOES NOT establish:');
        foreach ($result['does_not_establish'] as $limit) {
            $this->line('    - '.$limit);
        }
        $this->newLine();

        return $this->exitCode($result['status']);
    }

    private function exitCode(string $status): int
    {
        return match ($status) {
            PackageVerifier::PASS => 0,
            PackageVerifier::FAIL => 1,
            default => 2,
        };
    }
}
