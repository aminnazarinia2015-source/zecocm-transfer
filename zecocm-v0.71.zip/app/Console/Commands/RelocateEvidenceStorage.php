<?php

namespace App\Console\Commands;

use App\Domain\Ops\EvidenceRelocation;
use Illuminate\Console\Command;

/**
 * `php artisan evidence:relocate-storage --from=... --to=... [--commit]`
 *
 * DATA-1's migration step: carries every file that already existed under the
 * old evidence root forward to the new one, verifying each file's sha256
 * before treating it as relocated. Without --commit this is a dry run - it
 * copies and verifies, but never deletes anything at the source, so it is
 * always safe to run first and read the report. Only pass --commit once the
 * dry-run report shows zero mismatches for the files you actually intend to
 * carry forward.
 */
class RelocateEvidenceStorage extends Command
{
    protected $signature = 'evidence:relocate-storage {--from=} {--to=} {--commit : delete each source file once its destination copy is hash-verified}';

    protected $description = 'Copy evidence bytes from an old storage root to a new one, verifying sha256 before ever touching the source.';

    public function handle(): int
    {
        $from = $this->option('from');
        $to = $this->option('to');

        if (! $from || ! $to) {
            $this->error('Both --from and --to are required.');

            return self::FAILURE;
        }

        if (rtrim($from, '/') === rtrim($to, '/')) {
            $this->error('--from and --to must differ.');

            return self::FAILURE;
        }

        $commit = (bool) $this->option('commit');

        $this->info(($commit ? 'Relocating' : 'Dry run: would relocate').' evidence from '.$from.' to '.$to);

        $result = EvidenceRelocation::run($from, $to, $commit);

        $this->line('  copied:           '.count($result['copied']));
        $this->line('  verified:         '.count($result['verified']));
        $this->line('  mismatched:       '.count($result['mismatched']));
        $this->line('  deleted_source:   '.count($result['deleted_source']));
        $this->line('  skipped_existing: '.count($result['skipped_existing']));

        if ($result['mismatched'] !== []) {
            $this->error('Mismatched files (left untouched at source, NOT deleted):');
            foreach ($result['mismatched'] as $path) {
                $this->line('  - '.$path);
            }

            return self::FAILURE;
        }

        if (! $commit && $result['verified'] !== []) {
            $this->comment('Dry run only - source files were not deleted. Re-run with --commit once this report looks right.');
        }

        return self::SUCCESS;
    }
}
