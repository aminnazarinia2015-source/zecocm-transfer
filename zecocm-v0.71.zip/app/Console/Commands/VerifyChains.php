<?php

namespace App\Console\Commands;

use App\Domain\Provenance\ChainSpec;
use App\Domain\Provenance\CanonicalPayload;
use App\Domain\Provenance\CanonicalizationTransition;
use App\Domain\Provenance\ChainVerifier;
use Illuminate\Console\Command;

/**
 * `php artisan chains:verify`
 *
 * The thing that had never been run. An evidence product that cannot answer
 * "is the ledger intact?" on demand is asking to be trusted rather than checked.
 */
class VerifyChains extends Command
{
    protected $signature = 'chains:verify {--chain= : quality|knowledge} {--group= : verify one chain only}';

    protected $description = 'Walk the hash-chained ledgers and report the first broken link in each.';

    public function handle(): int
    {
        $specs = ChainSpec::all();
        $only = $this->option('chain');
        if ($only !== null) {
            if (! isset($specs[$only])) {
                $this->error('Unknown chain: '.$only.'. Known: '.implode(', ', array_keys($specs)));

                return self::FAILURE;
            }
            $specs = [$only => $specs[$only]];
        }

        $broken = 0;
        $unexplained = 0;
        $checked = 0;
        $unverifiable = 0;

        foreach ($specs as $spec) {
            $results = $this->option('group') !== null
                ? [ChainVerifier::verify($spec, $this->option('group'))]
                : ChainVerifier::verifyAll($spec);

            foreach ($results as $r) {
                $checked++;
                $label = $spec->name.' #'.$r['group'].' ('.$r['records'].' records)';

                match ($r['status']) {
                    // Not "no evidence of tampering". The verifier observed
                    // that linkage and content agree; it is not a forensic
                    // authority on everything that could have happened.
                    ChainVerifier::OK => $this->line('  <fg=green>verified</> '.$label.' - linkage verified, content verified, no integrity discrepancies detected'),
                    ChainVerifier::EMPTY_CHAIN => $this->line('  <fg=gray>empty</>  '.$label),
                    // Deliberately not "clean", "failed", "compromised" or
                    // "tampered". Content verification is exactly what would
                    // detect content tampering, and for these chains it is
                    // unavailable - so the honest statement is what we cannot
                    // say, phrased without accusation.
                    ChainVerifier::NOT_RECOMPUTABLE => $this->line('  <fg=yellow>legacy</>   '.$label.' - LINKAGE VERIFIED / CONTENT NOT REVERIFIABLE'),
                    default => $this->line('  <fg=red>BROKEN</> '.$label),
                };

                if ($r['status'] === ChainVerifier::BROKEN) {
                    $broken++;
                }
                if ($r['status'] === ChainVerifier::NOT_RECOMPUTABLE) {
                    $unverifiable++;

                    // Record the observation. Facts only - the row explains
                    // nothing and is inert until a steward signs a transition
                    // record against it.
                    $finding = CanonicalizationTransition::record([
                        'chain_name' => $spec->name,
                        'chain_group' => (string) $r['group'],
                        'record_count' => (int) $r['records'],
                        'mismatch_type' => 'payload_not_recomputable',
                        'linkage_result' => 'verified',
                        'content_verification_result' => 'unavailable',
                        'verifier_version' => CanonicalPayload::CURRENT,
                        'detected_at' => now(),
                    ]);

                    if (! $finding->isExplained()) {
                        $unexplained++;
                    }
                }

                foreach ($r['findings'] as $finding) {
                    $this->line('         '.$finding);
                }
            }
        }

        $this->newLine();
        // The strongest statement this verifier can actually support, split by
        // dimension. Rolling the legacy chains into a single "no tampering"
        // claim would assert something content verification was never run to
        // establish.
        $verified = $checked - $broken - $unverifiable;
        $this->line($checked.' chain(s) checked: '.($checked - $broken).' linkage-valid; '
            .$verified.' content-verified and passed; '
            .$unverifiable.' not independently content-reverifiable under the current canonicalization protocol; '
            .$broken.' linkage failure(s).');

        if ($unverifiable > 0) {
            // Facts only. The previous version of this line said the limitation
            // was "a recorded defect in the writer" - which is a conclusion, and
            // not one a verifier is entitled to reach. A machine that authors
            // its own explanation for why its evidence cannot be checked is
            // doing what the automated knowledge verification did, and that had
            // to be torn out.
            //
            // What can be stated: the serialization cannot be reproduced.
            // What cannot: that nothing else happened.
            $this->line('Historical serialization on those chains cannot be reproduced under the current canonicalization protocol. Original seals were preserved without modification; no historic hash has been rebuilt.');
            $this->line('The cause of that condition is not established by this command. It is recorded as a finding for a named evidence steward to classify.');

            if ($unexplained > 0) {
                $this->line($unexplained.' of them carry no signed transition record yet. Until one exists, the honest status is: detected, unexplained.');
            }
        }

        // A broken ledger is a failure exit code so this can gate a deploy or a
        // nightly job. Silence is not the same as intact.
        return $broken > 0 ? self::FAILURE : self::SUCCESS;
    }
}
