<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * OPS-14, Codex's explicit ruling: a failed job is an alertable event, not
 * a /up failure - C5 already proved that conflating the two lets one
 * permanently-failed job keep health red forever. This command is the
 * alert side: it advances a single-row watermark
 * (`failed_job_watermarks.last_seen_failed_job_id`) past `failed_jobs`'
 * highest id and logs how many new failures appeared since the last run,
 * at `critical` if any appeared (so it reaches whatever log-based alerting
 * is wired up) and `info` otherwise. It never touches `/up` or throws -
 * this table is never registered on `DiagnosingHealth`.
 */
class ReportFailedJobDelta extends Command
{
    protected $signature = 'ops:report-failed-job-delta';

    protected $description = 'OPS-14: log how many jobs have newly failed since the last check (alert-only, never gates /up).';

    public function handle(): int
    {
        if (! config('zecocm_ops.failed_job_watch.enabled', true)) {
            return self::SUCCESS;
        }

        // A fixed monitor_name (unique in the schema) makes "exactly one
        // row" a database constraint rather than an assumption this command
        // makes - updateOrInsert() keyed on it can never touch more than
        // the one row it means to, even if this command is ever extended to
        // watch more than one thing.
        $monitorName = 'failed_jobs';
        $watermark = DB::table('failed_job_watermarks')->where('monitor_name', $monitorName)->first();
        $lastSeenId = $watermark === null ? 0 : (int) $watermark->last_seen_failed_job_id;

        $newFailures = DB::table('failed_jobs')->where('id', '>', $lastSeenId)->orderBy('id')->get();
        $highestId = $newFailures->max('id') ?? $lastSeenId;

        DB::table('failed_job_watermarks')->updateOrInsert(
            ['monitor_name' => $monitorName],
            ['last_seen_failed_job_id' => $highestId, 'checked_at' => now()],
        );

        if ($newFailures->isNotEmpty()) {
            Log::critical('ops14.failed_job_delta: new job failures since last check', [
                'count' => $newFailures->count(),
                'failed_job_ids' => $newFailures->pluck('id')->all(),
                'queues' => $newFailures->pluck('queue')->unique()->values()->all(),
            ]);
            $this->warn("{$newFailures->count()} new job failure(s) since last check.");
        } else {
            Log::info('ops14.failed_job_delta: no new job failures since last check');
            $this->info('No new job failures.');
        }

        return self::SUCCESS;
    }
}
