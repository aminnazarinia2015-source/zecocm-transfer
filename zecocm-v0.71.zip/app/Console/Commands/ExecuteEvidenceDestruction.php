<?php

namespace App\Console\Commands;

use App\Domain\Evidence\DestructionCertificate;
use App\Domain\Evidence\EvidenceDestructionExecutor;
use App\Models\EvidenceTombstone;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Console\Command;

/**
 * `php artisan evidence:execute-destruction {tombstone} --actor=<user_id>`
 *
 * EV-14B's operational entry point. This is the only console command in the
 * codebase that can remove evidence bytes - everything EV-14A built
 * (request, authorize, tombstone) only ever proposed or authorized. Every
 * safety check lives in EvidenceDestructionExecutor itself, not here; this
 * command is deliberately thin.
 */
class ExecuteEvidenceDestruction extends Command
{
    protected $signature = 'evidence:execute-destruction {tombstone : evidence_tombstones.id} {--actor= : users.id of the operator running this}';

    protected $description = 'Execute (or advance) verified destruction for one authorized tombstone against the governed storage topology.';

    public function handle(): int
    {
        $tombstoneId = (int) $this->argument('tombstone');
        $actorId = $this->option('actor');

        if (! $actorId) {
            $this->error('--actor is required: destruction execution is never anonymous.');

            return self::FAILURE;
        }

        $tombstone = EvidenceTombstone::withoutGlobalScopes()->find($tombstoneId);
        if ($tombstone === null) {
            $this->error("No evidence_tombstones row with id {$tombstoneId}.");

            return self::FAILURE;
        }

        $actor = User::withoutGlobalScopes()->find((int) $actorId);
        if ($actor === null) {
            $this->error("No users row with id {$actorId}.");

            return self::FAILURE;
        }

        $previousTenant = TenantContext::tenantId();
        TenantContext::set($tombstone->tenant_id);

        try {
            $result = EvidenceDestructionExecutor::execute($tombstone, $actor);
            $this->info('Execution state: '.$result['state']);
            if ($result['detail'] !== []) {
                $this->line('Detail: '.json_encode($result['detail']));
            }
            $this->line('');
            $this->line(DestructionCertificate::render($tombstone->fresh()));
        } finally {
            if ($previousTenant === null) {
                TenantContext::clear();
            } else {
                TenantContext::set($previousTenant);
            }
        }

        return self::SUCCESS;
    }
}
