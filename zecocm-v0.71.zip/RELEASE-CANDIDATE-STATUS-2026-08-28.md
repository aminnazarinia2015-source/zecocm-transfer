# ZecoCM source hardening status — 2026-08-28

This source package is a hardened engineering candidate. It is **not a production certification** and must complete the deployment and human acceptance gates in the master audit before launch.

## Corrected in this candidate

- Regenerated `composer.lock` so the declared PHP 8.3 platform resolves PHP 8.3-compatible Symfony 7.4 packages. Strict Composer validation and a clean dependency install now succeed.
- Removed plaintext temporary passwords from customer, portal, platform-staff, and project-member provisioning responses.
- Added signed, expiring, one-use password setup links backed by unknown high-entropy placeholder passwords.
- Updated the browser interface to hand off the setup link without displaying or copying a password.
- Added a dedicated rate limit to password-setup routes.
- Made customer creation atomic across the tenant, administrator, and initial licence events.
- Made sponsored portal creation atomic across the portal, administrator, and grant events, while preserving explicit per-capability refusals.
- Prevented default and self-serve plans from granting roadmap capabilities, and removed marketing claims for unshipped closeout and trade-partner workflows.
- Added the operational Plans & BIM coordination foundation: governed categorized plan sets and sheets, safe native browser preview for PDF/JPEG/PNG/WebP, immutable revisions linked to clean document bytes, append-only accepted/rejected review determinations, normalized markups and resolutions, project-serialized self-verifying hash-chain events, external Autodesk/Bluebeam/Procore references, distinct view/manage/markup/review grants, and TRACE screen context.
- Added the vendor-neutral integration foundation for Autodesk, Procore, Bluebeam and Microsoft 365: fail-closed configuration readiness, project connection status, encrypted non-serializable token storage, idempotent sync-run records, deduplicated webhook receipts, future-integration authorization, admin-managed application secrets and a provider-specific implementation handoff. No provider is represented as connected until customer OAuth actually exists.
- Added TRACE's governed bulk-corpus plan and manifest for project authority, public-works law, jurisdiction/effective dates, all major trades, content rights, steward publication and golden-question testing. This is retrieval/citation infrastructure, not an unsupported claim that a model already memorized every source.
- Corrected production storage guidance so real evidence stays on a persistent, backed-up local evidence volume instead of an incompatible S3 default.
- Updated the affected feature-test contracts.

## Verification completed

- Composer manifest/lock strict validation: pass.
- PHP dependency installation from lock with scripts disabled: pass (121 packages).
- PHP parse check: pass (612 project PHP files, zero parse failures).
- Laravel application boot and package discovery: pass.
- Laravel route discovery: pass (181 routes; 11 Plans/BIM routes plus the integration-readiness route).
- Fresh SQLite migration: pass (all 88 migrations).
- Unit tests: 104/105 pass (338 assertions), including plan audit-chain tamper detection; one runner-sensitive subprocess timeout took 5.03 seconds against a 4-second ceiling in the WebAssembly test environment.
- JavaScript syntax validation: pass.
- Vite production build: pass.
- pnpm audit: pass, zero known vulnerabilities.
- Composer dependency advisory query: no cached advisories or abandoned packages reported, but Packagist was unreachable from this sandbox; rerun on CI with normal Packagist access.

## Mandatory gates still outside this source-only run

- Run the complete PHPUnit feature suite on native PHP 8.3 in CI. The sandbox WebAssembly runtime crashes inside Laravel's feature-test harness, so this package does not claim a full green feature suite.
- Run the production deployment rehearsal, backup/restore, queue, scheduler, malware scanner, mail, payment webhook, object storage, observability, load, accessibility, cross-browser, mobile, and tenant-isolation acceptance gates from the master audit.
- Complete human construction-workflow acceptance testing with representative City/owner, CM, GC, subcontractor, accounting, and field roles.
- Treat Plans/BIM as a governed coordination foundation with safe browser preview, not a native DWG/IFC authoring engine: deep Autodesk/Bluebeam/Procore OAuth sync, model federation/clash detection, and a CAD-grade viewer remain roadmap work.
- Treat each provider as integration-ready, not connected, until its vendor application, customer OAuth, scopes, sync workers, webhook verification and sandbox acceptance satisfy `INTEGRATION-HANDOFF.md`.
- Populate TRACE through the controlled workflow in `TRACE-CORPUS-LOAD-PLAN.md`; commercial standards and codes require appropriate content rights before ingestion.
- Roadmap-labelled modules in `public/app.html` remain intentionally unavailable and must not be represented as shipped capabilities.

## Deployment note

Deploy with PHP 8.3 or newer and install exactly from the committed lock. Run Composer without development dependencies, then execute the documented bootstrap, migration, queue, scheduler, health, and rollback checks in `deploy/RUNBOOK.md`.

Use `REAL-DATA-PILOT-GATES.md` as the go/no-go checklist. A source package cannot certify its hosting, credentials, external services, backup recovery, performance, browser behavior, or human workflow acceptance by itself.
