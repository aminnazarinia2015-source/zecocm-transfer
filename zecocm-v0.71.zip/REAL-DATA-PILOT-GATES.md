# ZecoCM real-data pilot gates

This is a go/no-go checklist, not a marketing certification. Do not enter
customer production data until every **Blocker** is evidenced by a named owner
and a retained test result.

## Blockers

- [ ] Deploy this exact package on native PHP 8.3+ and run the complete PHPUnit
  suite with zero failures. The WebAssembly source-review runner is not the
  production test gate.
- [ ] Set `APP_ENV=production`, `APP_DEBUG=false`, HTTPS `APP_URL`, secure
  session/cookie settings, a production mailer from `support@zecocm.com`, and
  unique production secrets. No secret may be placed in source control or chat.
- [ ] Keep `FILESYSTEM_DISK=local` and mount `EVIDENCE_STORAGE_ROOT` on an
  encrypted, persistent, capacity-monitored volume outside the application
  release directory.
- [ ] Configure and prove the malware scanner. A clean PDF must pass; a harmless
  EICAR test file must remain quarantined and unavailable everywhere.
- [ ] Run scheduler and queue workers under process supervision. Prove queued
  ingestion, OCR/AI jobs, heartbeat freshness, retry behavior, and failed-job
  alerting.
- [ ] Restore an encrypted database backup and matching evidence-volume backup
  into an isolated environment; open and hash-check restored documents.
- [ ] Verify tenant isolation and permissions with two tenants and the owner,
  CM, GC, subcontractor, accounting, field, read-only, and platform-technician
  roles. Attempt cross-tenant IDs and every prohibited write directly by API.
- [ ] Prove password setup links expire, are one-use, are rate-limited, and are
  delivered only to the intended mailbox. Verify revoke/reactivate behavior.
- [ ] If paid signup is enabled, validate Stripe/PayPal webhook signatures,
  duplicate delivery, retry, cancellation, and price-to-capability mapping in
  sandbox before production keys are installed.
- [ ] Run accessibility, keyboard, mobile, Chrome, Edge, Safari, Firefox, load,
  soak, error-observability, and disaster/rollback acceptance tests.
- [ ] Confirm the integration-readiness screen never labels a blank provider
  configured or connected. Before enabling any provider, complete every gate in
  `INTEGRATION-HANDOFF.md`, including OAuth revoke/refresh, sync replay,
  signature verification, conflict handling and cross-tenant attacks.
- [ ] Load a representative TRACE corpus batch using
  `trace-corpus-manifest.example.csv`; verify rights, jurisdiction, effective
  windows, supersession, conflicts, extraction coverage and golden questions
  before steward publication.

## Construction workflow acceptance

- [ ] Create a real pilot project and verify organizations, memberships,
  routing, contract clocks, calendars, and working-day calculations against the
  signed contract.
- [ ] Upload specifications, addenda, schedules, photos, correspondence, and
  drawings. Confirm immutable hashes, malware state, extraction/OCR quality,
  authority, supersession, citations, download, and retention/hold behavior.
- [ ] Complete real role-based lifecycles for daily reports, RFIs, submittals,
  quality items, change orders, pay applications, time cards, and schedule
  updates. Confirm edits, determinations, signatures, notices, and audit history.
- [ ] Plans/BIM: create categorized sets and sheets, append at least two
  revisions, open a PDF through authenticated browser preview, preserve both
  downloads, record an accepted/rejected determination, add and resolve
  markups, validate external reference links, test view/manage/markup/review
  grants independently, and ask TRACE while the sheet is open.
- [ ] Independently recalculate a sample of schedule, payment, retention,
  quantity, and deadline results. No inferred value may be treated as an
  authorized contract fact.
- [ ] Review TRACE answers containing supporting, conflicting, superseded, and
  insufficient evidence. Every claim must cite retrievable authorized evidence
  or refuse clearly.

## Explicit product boundary

The Plans/BIM release slice is a secure coordination and evidence layer with
safe native browser preview for PDF/JPEG/PNG/WebP. It is not yet a native
AutoCAD/DWG or IFC authoring system, a Bluebeam-equivalent PDF editor, an
Autodesk model federation/clash engine, or a live Procore/ACC/M365 sync
connector. Those require separately authorized vendor integrations,
viewer licensing, sync conflict handling, webhook/retry infrastructure, and
vendor-specific acceptance tests. External links and provider identifiers are
stored now so those connectors can be added without rewriting the plan record.

## Go/no-go record

- Package SHA-256:
- Environment / deployment ID:
- Test-suite evidence URL:
- Backup-restore evidence URL:
- Security review owner:
- Construction acceptance owner:
- Approved pilot data classification:
- Go/no-go decision and date:
