# ZecoCM Full-System Delivery and Acceptance Plan

## Delivery principle

Ship complete vertical workflows with evidence, permissions, empty/error/offline states, audit, accessibility, and tests. Do not build a broad collection of visually finished but disconnected modules.

## Release gates

### Gate 0 - Trust and platform safety

- One login/session restore/logout/profile/password/logo path.
- Platform/customer hierarchy, support mode, read-only technicians, portal creation, and one-time credentials.
- Fail-closed tenant context across data, search, cache, jobs, exports, counts, and errors.
- Capability licensing, time/quota/budget/task/model controls, sponsor ceilings, and truthful unavailable states.
- Security baseline, runtime health, queue, object storage, backups, monitoring, and incident controls.

Exit: independent isolation tests pass; refresh/back/mobile navigation works; no hard-coded project facts or counts remain.

### Gate 1 - Evidence-to-decision core

- One complete RFI, submittal, and daily workflow.
- Immutable media and source documents, references, clocks, routing, response/review, issue/receipt, decision envelopes, corrections, and exports.
- Offline mobile field capture with sync/conflict receipts.
- Knowledge Atlas ingestion, quarantine, verification, source viewer, and citations.

Exit: owner, CM, contractor, inspector, designer, and auditor complete scenario tests without database intervention.

### Gate 2 - Schedule and production intelligence

- Schedule versions/calendars/relationships/resources/mapping/deltas/CPM validation.
- Accepted-version authority, run history, provenance export, narrative reconciliation, hypotheses, and bounded recovery studio.
- Look-ahead, commitments, constraints, quantities, weather, and daily-to-schedule reconciliation.

Exit: independent CPM benchmark passes relationship, lag, calendar, constraint, actual, open-end, out-of-sequence, and option scenarios.

### Gate 3 - Commercial and contract administration

- Changes, notices, quotations, independent estimates, TIA links, negotiations, modifications, budgets, commitments, pay applications, retainage, funding, and payment receipts.
- Formal notices/payments/signatures remain human-authorized.

Exit: a complete change and pay cycle reconciles to immutable evidence, schedule, cost, authority, and accounting export.

### Gate 4 - Quality, safety, plans, meetings, and labor

- Plans/models, inspections, testing, NCR/punch, safety, meetings/correspondence, and labor compliance.
- AI restrictions for design, life safety, legal/compliance determinations.

Exit: discipline-specific pilots pass mobile, accessibility, audit, and authority scenarios.

### Gate 5 - Closeout, portfolio, and civic delivery

- Asset handover, commissioning, warranties, training, as-builts, final dependencies, portfolio/program intelligence, Send to City, and approved public transparency.

Exit: auditor replays a project; owner receives a complete sealed package; public view exposes only approved redacted information.

### Gate 6 - Compounding intelligence

- Official-source feeds, semantic/graph retrieval, evaluation dashboard, private-model gateway, approved learning datasets, and model release/rollback.

Exit: model/prompt candidates beat the incumbent without citation, refusal, privacy, authority, or leakage regression.

## Required screen-state contract

Every applicable surface has designed and tested loading, first-use empty, filtered empty, offline, queued, syncing, scan pending, quarantined, rejected, provisional, verified, stale, conflicting, superseded, correction appended, insufficient evidence, permission denied, authority required, support mode, partial failure, validation error, irreversible confirmation, success receipt, and unavailable states.

## Acceptance matrix

| Domain | Required proof |
|---|---|
| Identity | Session persists; logout revokes; credentials shown once; password/profile/logo flows validated |
| Tenant isolation | Cross-tenant ID, count, search, export, autocomplete, cache, queue, source, and error tests fail closed |
| Evidence | Source bytes/hash/version/author/time/device/clock captured; corrections append |
| Authority | Formal actions require a permitted accountable person and produce a receipt |
| AI | Every claim is cited or refused; scope/model/prompt/freshness/confidence/assumptions visible |
| Schedule | Immutable versions, full calendars, mapping edges, deterministic CPM, replayable deltas |
| Cost | Quantities, commitments, changes, pay apps, retainage, approvals, and payments reconcile |
| Mobile | Field workflows work offline at 320 px with 44 px targets and recoverable sync |
| Accessibility | WCAG 2.2 AA, keyboard, focus, screen reader, 200% zoom, reduced motion, contrast |
| Operations | Idempotency, retries, cancellation, outbox, monitoring, backup/restore, incident response |
| Packaging | No secrets, data, logs, caches, vendor/node_modules, or generated manifests |

## Team workstreams

- Product/contract administration: workflow policy, terminology, clocks, authority, and acceptance scenarios.
- UX/content/accessibility: product map, prototypes, state matrix, design system, content rules, and testing.
- Platform/security: tenancy, identity, permissions, licensing, infrastructure, observability, and compliance.
- Evidence/documents/mobile: ingestion, media, offline, provenance, records, transmittals, and exports.
- Schedule/project controls: parsers, calendars, CPM, mapping, deltas, TIA, look-ahead, and recovery.
- Cost/commercial: budget, commitments, changes, pay apps, funding, accounting integration, and controls.
- AI/knowledge: atlas, feeds, retrieval, graph, model gateway, evaluations, learning, and governance.
- Quality engineering: automated, adversarial, performance, accessibility, browser/device, and disaster tests.

Each workstream owns working software and evidence of acceptance—not only mockups or tickets.

## Pilot strategy

Begin with Zeco projects but use formal pilot charters. Select an active project with real RFI/submittal/daily/schedule activity and a closed project for replay/closeout. Establish baseline task time, error rate, late decisions, missing evidence, schedule review duration, and user satisfaction. Release to limited roles, observe, correct, then expand. Do not import fourteen projects until lifecycle, idempotency, confirmation ledger, source ownership, retention, and rollback gates pass.

## Team review decisions

The team must return explicit decisions—not “looks good”—for:

1. Product hierarchy and purchaser/sponsored-portal authority.
2. Formal action authority by role and organization.
3. Evidence classifications and retention/legal-hold rules.
4. Contract clocks/calendars and source precedence.
5. City/organization knowledge promotion authority.
6. External source licences and approved connectors.
7. Cross-customer learning consent and privacy standard.
8. AI providers, private/local deployment, budgets, and allowed tasks.
9. P0/P1 workflow order and pilot projects.
10. Security, recovery, availability, and support commitments.

No implementation assumption may silently substitute for these accountable business decisions.
