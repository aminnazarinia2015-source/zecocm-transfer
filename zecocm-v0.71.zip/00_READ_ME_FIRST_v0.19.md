# ZecoCM v0.19 - Governed Construction Intelligence Foundation

This package is an implementation milestone built from the supplied v0.18 source. It is not a production deployment and contains no production data or secrets.

## Delivered

- Governed knowledge sources with immutable sealed bytes, versions, passages, hashes, classification, authority, access, verification, and supersession/relationship edges.
- Provisional-by-default ingestion and a named-steward promotion ceremony. Automatic classification never constitutes adoption.
- Tenant- and project-safe structured/lexical retrieval that enforces the server-derived jurisdiction corpus.
- Citation validation that refuses model output with missing or invalid passage references.
- Asynchronous, idempotent, cancellable AI runs with immutable scope, prompt/model/retrieval/policy identity, source manifest, progress, result classification, and event chain.
- Append-only feedback events and successful-work-only usage metering.
- AI licence extensions for model tier, task permissions, usage quota, monetary budget ceiling, time window, and sponsor delegation ceiling.
- Universal command bar, Knowledge Atlas, review queue, source register, and AI run register.
- Full SHA-256 display on transmittals.
- Missing database-session migration and runtime storage directories required for reliable refresh/back navigation.

## Validation

- PHP syntax: 0 failures across application, migrations, and routes.
- Automated suite: 66 tests passed, 270 assertions.
- JavaScript syntax: passed for both script blocks in `public/app.html`.
- Fresh SQLite migration and seed: passed through migration 000022.
- Browser: login/session restore, dashboard, Knowledge Atlas, AI register, command center, and 390x844 mobile reflow inspected.

## Honest boundary

This milestone does not ship a vector database, OCR/table/drawing extraction, an arbitrary web crawler, a local foundation-model runtime, production cost reconciliation, or a completed evaluation dashboard. Those capabilities require infrastructure, source licensing, security review, and representative evaluation data. The code stores the provenance and feedback needed to build them safely.

Start with `IMPLEMENTATION_HANDOFF_v0.19.md` and `AI_KNOWLEDGE_OPERATING_MODEL.md`.
