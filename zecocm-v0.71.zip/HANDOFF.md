# ZecoCM Engineering Audit and Handoff

Date: 2026-08-24  
Audit scope: supplied source archive, supplied implementation specification, supplied product blueprint, and a read-only review of the signed-in production website at `https://app.zecocm.com/app.html`.

## Executive result

This package is a coherent, tested foundation—not a claim that the entire envisioned platform is finished. The strongest safe milestone implemented is:

1. repaired account/session/password/profile/logo flows on a clean database;
2. fail-closed project and tenant authorization for the highest-risk existing endpoints;
3. immutable Schedule Intelligence phases A–B: source ingestion, calendars, CPM validation, identity mapping, deltas, lineage, asynchronous analysis, and an authorization-filtered API;
4. a truthful version-timeline and delta-ledger UI that refuses unsupported formats and clearly marks later AI stages unavailable;
5. signed-in suppression of browser-only sample claims in modules that do not yet have a verified server workflow.

The package does **not** declare legal fault, accept schedules, issue formal notices, authorize payments, sign on behalf of a human, make design/life-safety judgments, or present unsupported AI conclusions.

## Source integrity

- Original archive was never modified: `C:\Users\ZecoInc\ZECO INC\ZecoCM Design Docs\zecocm-app-code.zip`
- Original archive SHA-256: `20720830457F89604F15D759B4E12FCEB33291173193D321E9C49AC2E72E0055`
- Work was performed in a new extracted copy.
- No production deployment, production data mutation, email, account creation, commit, or push was performed.
- No real secret is included in this package.

## What the supplied archive actually was

- Laravel 13 application, Sanctum token authentication, SQLite-ready migrations.
- A very large, inline `public/app.html` prototype mixing real API calls with browser-only sample records and claims.
- Domain primitives for deadlines, provenance sealing, tenancy scope, and cited/refusal-oriented AI.
- No dependency lock files or installed dependencies.
- No schedule schema, parser, CPM engine, version lineage, schedule API, or schedule tests.
- No Sanctum `personal_access_tokens` migration, meaning clean-install login failed even though the controller tried to issue tokens.

## Production website findings (read-only)

The signed-in site showed genuine API-backed records in some places while retaining fixed sample values in others. The most serious visible issue was the old Schedule Intelligence screen: it displayed a fixed baseline/update comparison, an “Owner-caused” attribution, contract/code conclusions, and an estimated `$10,200` liquidated-damages exposure without a visible immutable version ledger, calculation provenance, or accountable approval gate. Those values were not treated as verified facts in this package; the screen was replaced.

At a 390 × 844 mobile viewport, the live site retained the 240 px sidebar and left roughly 83 px for content, with horizontal overflow (`scrollWidth` about 696 vs. `clientWidth` about 375). Navigation items were generic `div` elements without keyboard semantics, and several primary controls measured about 27 px high. The account UI lacked a confirmation field for a new password and exposed looser image-upload affordances than the repaired server. “Open project” navigated but also showed a contradictory “not wired” toast.

Important: these live-site findings remain on production until an authorized deployment of reviewed code occurs. This task did not deploy.

## Implemented engineering work

### Account and session correctness

- Added the missing Sanctum token migration.
- Added login rate limiting keyed by normalized email and IP.
- Added confirmed, minimum-12-character password changes.
- Kept the active token and revoked other tokens after a password change.
- Logout revokes only the current token.
- Restricted avatar/logo uploads to content-verified JPG, PNG, or WebP.
- Rejected SVG; enforced file, dimension, and expanded-pixel limits; used UUID storage names.
- Deleted superseded images only after the replacement stored successfully.
- Added account regression tests for login, session revocation, password confirmation, logout, SVG rejection, and raster upload.

### Tenant and project isolation

- Caller-supplied `role` input is rejected; perspective is derived from the authenticated account and project grant.
- Customer access requires a matching project membership/capability and fails closed without one.
- Platform support browsing requires an explicit tenant context and remains read-only for tenant writes.
- Corrected middleware ordering so tenant context exists before tenant-scoped implicit route binding.
- Applied project authorization and tenant filtering to AI assist, weather, document, My Court, RFI, submittal, daily-report, media, and schedule paths touched by this milestone.
- Removed request-derived project scope from AI retrieval; retrieval now requires an authorization-derived project attribute and tenant context.
- Project listing is membership-scoped for customer users; project creation adds the creator membership.
- API presentation filters source metadata and resources by capability even though deterministic calculation remains invariant.

This is application-level isolation. Database row-level security, tenant-specific encryption keys, and adversarial multi-database tests are still recommended before enterprise production.

### Immutable Schedule Intelligence schema

Migration `2026_08_24_000014_create_schedule_intelligence_tables.php` adds tenant/project-scoped relational structures for:

- immutable schedule versions and append-only disposition events with hash-chain fields;
- full calendars, weekly working periods, exceptions, holidays, time zone, and inheritance;
- activities, activity-calendar assignments, FS/SS/FF/SF predecessor relationships, resources;
- activity mapping groups and relational edges for exact, fuzzy, split, merge, added, deleted, confirmed, and superseded mappings;
- analysis runs, validation issues, computed metrics, deltas;
- relational delta sources and linked-record citations;
- outbox events.

Imported schedule records use immutable model guards. Disposition state is canonical in append-only events; the `review_status` column is only a verified projection.

### Upload and parser safety

- Accepts tabular `.csv` and `.xlsx` schedule exports only.
- Deliberately refuses PDF schedule rows rather than silently treating extraction as fact.
- Deliberately refuses `.mpp`; Microsoft Project XML/export is the next supported import path unless a tested native parser is selected.
- Verifies MIME/content agreement, size, row/column/cell limits, encoding, null bytes, spreadsheet formulas, archive path traversal, entry count, expanded size, compression ratio, macros, external links, embeddings, ActiveX, and object payloads.
- In production, schedule upload fails closed unless a malware scanner is configured.
- Preserves original source bytes through media provenance and SHA-256.
- Records parser name/version, security scan, assumptions, row count, data date, lineage, and source format.
- Parses activity IDs/names/WBS, planned/actual dates, duration/float, constraints, predecessor types and signed lags, resources, and explicit/default calendars.

The parser is a controlled interchange format, not a full Primavera XER/P6 XML or Microsoft Project engine.

### Deterministic CPM and comparison

- Working-time math honors shifts, breaks, weekends, holidays, custom exceptions, time zone, and reverse calculations.
- CPM supports FS, SS, FF, and SF relationships with positive or negative lags.
- Validation covers cycles, missing/open ends, unsupported options, constraints, actuals, and out-of-sequence progress mode.
- Analysis distinguishes critical/near-critical calculations and stores computed metrics separately from imported assertions.
- Identity matching supports exact ID, mutual fuzzy match, split, merge, added, deleted, human-confirmed correction, and supersession.
- Delta types include identity, date, actual, duration, float, criticality, logic, calendar, and constraint changes.
- Delta citations are relational and carry version/activity/media/source-hash references.

Known CPM boundary: this engine is an independently testable foundation, not yet a validated replacement for P6/Primavera Cloud. Resource leveling, multi-project links, LOE/WBS rollups, all constraint options, full remaining-duration/percent-complete semantics, multiple float-path/longest-path analysis, Monte Carlo risk, and vendor fixture parity remain future work.

### Asynchronous, reproducible analysis

- Analysis requires an `Idempotency-Key` bound to the exact project/version pair.
- Jobs are retry-safe and persist queued/running/completed/failed/cancel states and progress.
- Cancellation is checked at safe stage boundaries.
- Analysis records parser/CPM/rules/AI model and prompt versions, source hashes, authorization scope, assumptions, and retrieval times.
- An outbox row is committed with domain events.
- Failed runs can safely be requeued with the same logical identity.

An actual production queue worker, dead-letter policy, outbox publisher, dashboards, and operational alerts still need infrastructure configuration and soak testing.

### Truthful UI milestone

- Replaced the fabricated schedule claims with:
  - immutable version upload and parent lineage;
  - version timeline;
  - deterministic from/to comparison;
  - asynchronous progress and cancellation;
  - authorization-filtered delta ledger;
  - explicit unavailable states for narrative reconciliation, causation, recovery ranges, and success briefs.
- Added responsive off-canvas navigation at mobile widths and 44 px mobile targets.
- Added keyboard roles, focusability, and Enter/Space activation to navigation.
- Added password confirmation and safe image accept types.
- In a signed-in session, prototype-only modules now route to an explicit fail-closed screen instead of displaying sample records as live facts.
- Live RFI and submittal details no longer show hardcoded AI answers; unsupported assistance is marked unavailable.
- The browser-only design concepts remain visible in demo/design mode for the designer, but not as authenticated project truth.

The long inline HTML/JS file remains a maintainability and security liability. Componentization is a next milestone.

## Validation completed

Final validation commands are listed so the receiving team can reproduce them:

```text
composer install
php artisan migrate:fresh --force
php vendor/bin/phpunit --testdox
php tests/DomainTest.php
php vendor/bin/pint --test app bootstrap/app.php bootstrap/providers.php config database routes tests
php composer.phar validate --strict
php composer.phar check-platform-reqs
php composer.phar audit --locked
pnpm audit
pnpm build
```

Observed results before packaging:

- PHPUnit: 16 tests, 72 assertions, all passed.
- Framework-free legacy domain suite: 23 passed, 0 failed.
- Fresh SQLite migration: all 15 application/framework migrations passed.
- PHP syntax: application, configuration, migrations, routes, and tests passed.
- Laravel Pint: passed after mechanical formatting.
- Composer manifest: valid; platform requirements passed.
- Composer audit: no known advisories.
- pnpm audit: no known vulnerabilities.
- Vite production build: passed.
- Inline application JavaScript: two script blocks parsed successfully.
- Schedule API route discovery: 10 routes loaded.

No browser E2E suite, load test, penetration test, accessibility certification, independent CPM fixture certification, or production queue/infrastructure test was performed.

## Release blockers before production

### P0 — must be resolved

1. Replace `localStorage` bearer-token authentication with secure, HttpOnly, SameSite cookies or an equivalent hardened first-party session design; add CSRF protection and token rotation.
2. Add a strict Content Security Policy and remove inline event handlers/scripts through frontend componentization.
3. Configure and prove malware scanning, object-storage quarantine, and safe promotion for every upload path—not only schedule imports.
4. Add database defense in depth: PostgreSQL, row-level security or equivalent enforced tenant predicates, separate privileged paths, and cross-tenant adversarial tests.
5. Remove/separate any remaining demo bootstrap credentials and require secure invitations, forced password reset, MFA/passkeys, and enterprise SSO readiness.
6. Complete security review of document ingestion; the legacy PDF text path invokes an external process and lacks the schedule guard’s full quarantine policy.
7. Establish backups, restore drills, data retention, legal hold, evidence export, encryption/key rotation, audit log retention, and incident response.
8. Validate all formal actions as append-only command/event workflows with explicit human authorization; do not rely on mutable record columns for legal/signature history.

### P1 — required for market parity

1. Build a component-based frontend with typed API contracts, end-to-end tests, accessibility tests, and responsive/offline field workflows.
2. Finish drawings/revisions, documents/specs, photos/360 evidence, RFIs, submittals, daily reports, inspections/punch, change management, pay applications, cost controls, meetings/transmittals, notifications, closeout, and portfolio reporting on the verified factual core.
3. Add iOS/Android field applications or a proven offline-first web layer with queued capture, conflict resolution, encryption, remote revoke, and background sync.
4. Add SSO/SAML/OIDC, SCIM, MFA/passkeys, granular ABAC, delegated administration, segregation of duties, and support impersonation with recorded approval.
5. Add public-owner controls: program/portfolio hierarchy, funding sources, grants, board/council approvals, public-record export/redaction, asset handover, and jurisdiction-configurable workflows.
6. Build integrations and stable APIs/webhooks for P6/Primavera Cloud, Microsoft Project XML, Autodesk, Procore, ERP/accounting, document storage, GIS, BIM, email, and identity providers.

### P2 — ZecoCM differentiation

1. Authorized narrative reconciliation over evidence snapshots.
2. Causation **hypotheses** with supporting and contradicting evidence—never a fault declaration.
3. Bounded counterfactual recovery options with sourced cost/time ranges and explicit assumptions.
4. Role-aware Daily Project Success Brief from one invariant computation and authorization-filtered evidence payload.
5. Decision replay: show exactly which immutable sources, policy version, model/prompt, permissions, and human approvals produced each recommendation.

## Deployment/migration sequence

Use a staging environment first.

1. Provision supported PHP 8.4 extensions shown by `composer check-platform-reqs`.
2. Copy `.env.example` to a secret-managed environment; generate a fresh `APP_KEY`; do not reuse test values.
3. Configure PostgreSQL (recommended), Redis-backed cache/queue, object storage, private buckets, signed URLs, and malware scanner/quarantine.
4. Set `SCHEDULE_REQUIRE_MALWARE_SCAN=true` and the scanner binary/service configuration.
5. Run `composer install --no-dev --classmap-authoritative` from the committed lock file.
6. Run `pnpm install --frozen-lockfile` and `pnpm build` in the build environment.
7. Run migrations against a restored staging snapshot; verify rollback/forward strategy and indexes at realistic scale.
8. Run PHPUnit/domain/static/build checks plus tenant-adversarial, E2E, accessibility, upload-fuzz, and CPM fixture suites.
9. Configure queue workers, retry/dead-letter policy, cancellation, and an outbox publisher; monitor queue age and failed analyses.
10. Configure HTTPS/HSTS, CSP, secure cookies, CSRF, rate limiting, WAF, observability, immutable audit export, backup, and restore monitoring.
11. Perform security review and accountable product acceptance before promoting any build.

## Recommended next milestone

Build “Verified Schedule Intelligence Phase C” without enabling free-form AI actions:

1. import Primavera P6 XML/XER and Microsoft Project XML through tested adapters;
2. assemble a golden fixture corpus covering all relationship/lag/calendar/constraint/actual/OOS options and compare results with accepted reference engines;
3. add an activity mapping review workstation for split/merge/uncertain identity;
4. add schedule health, longest-path/multiple-float-path, logic quality, change attribution evidence graph, and source-opening UI;
5. add a policy-controlled human disposition workflow for schedule submission/review that explicitly stops short of contractual acceptance;
6. then introduce retrieval-only narrative reconciliation with fake model providers in tests and no authority to execute formal actions.

See `DESIGNER_BUILD_SPEC.md` for the one-pass product and interface specification.
