#!/usr/bin/env bash
# Build the deploy zip. Excludes vendor/node_modules/env/db/storage AND bootstrap/cache
# generated manifests (packages.php/services.php/config.php) - those are built from the
# LOCAL composer install (which includes dev deps like laravel/pail) and must never ship
# to the server, whose vendor is --no-dev. Shipping them crashes boot with
# "Class Laravel\Pail\PailServiceProvider not found". (Incident: v0.12, 24 Aug 2026.)
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-/home/claude/zecocm-$(git describe --tags --always).zip}"
rm -f bootstrap/cache/packages.php bootstrap/cache/services.php bootstrap/cache/config.php bootstrap/cache/routes-*.php
rm -f "$OUT"
zip -rq "$OUT" . \
  -x ".git/*" -x "vendor/*" -x "node_modules/*" -x ".env" \
  -x ".phpunit.result.cache" -x ".phpunit.cache/*" \
  -x "database/database.sqlite" -x "storage/logs/*" \
  -x "storage/framework/cache/data/*" -x "storage/framework/sessions/*" -x "storage/framework/views/*" \
  -x "storage/app/private/knowledge/*" -x "storage/framework/testing/*" \
  -x "storage/app/private/documents/*" -x "storage/app/private/media/*" \
  -x "bootstrap/cache/*.php" \
  -x "deploy/out/*" -x "deploy/*.tar.gz"
echo "built $OUT"; sha256sum "$OUT"
