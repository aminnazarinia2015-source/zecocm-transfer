#!/usr/bin/env bash
# ZecoCM one-paste server bootstrap - run as root on zecocm-app-01
# Prereq: /root/zecocm-app.zip present (see RUNBOOK for transfer options)
set -euo pipefail

apt-get update -y
apt-get install -y php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-xml \
  php8.3-curl php8.3-zip php8.3-gd nginx unzip
command -v composer >/dev/null || { curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer; }

mkdir -p /var/www && cd /var/www
rm -rf zecocm && unzip -q /root/zecocm-app.zip -d /var/www && mv zecocm-deploy zecocm && cd zecocm

composer install --no-dev --optimize-autoloader --no-interaction
composer require laravel/sanctum --no-interaction
cp -n .env.example .env
php artisan key:generate --force
grep -q '^PROVENANCE_SIGNING_KEY=..' .env || sed -i "s/^PROVENANCE_SIGNING_KEY=.*/PROVENANCE_SIGNING_KEY=$(openssl rand -hex 32)/" .env

# OPS-17: found during a real-world audit that a real 5MB test photo failed
# to upload with a bare, unhelpful "The file failed to upload" 422. PHP's
# stock upload_max_filesize/post_max_size (2M/8M) silently cap every upload
# well below what nginx already allows and what this app's own validation
# rules promise - and nothing here ever raised them before this line.
# Raised again from 110M/120M to 800M/820M after Amin flagged that real
# project drawing sets routinely run 300-500MB (DocumentLibraryController's
# own max:768000 = 750MB rule is the largest single upload this app claims
# to accept - see that controller and UploadLimitsHealthCheck). max_execution_time
# and memory_limit are raised alongside it: a multi-hundred-MB file takes
# real wall-clock time to hash, malware-scan (SecureUploadGate::timeoutForSize()
# scales that scan's own deadline to the file size), and write to storage, and
# needs more than one file's worth of memory headroom while doing it.
# A drop-in file (not editing the shipped php.ini directly) survives a
# package upgrade cleanly. UploadLimitsHealthCheck (OPS-17) now fails /up
# loudly if this is ever missing or reverted below the required threshold.
cat > /etc/php/8.3/fpm/conf.d/99-zecocm-uploads.ini <<'PHPINI'
; ZecoCM: match PHP's upload limits to what nginx and the app's own
; validation already allow. See UploadLimitsHealthCheck (OPS-17).
upload_max_filesize = 800M
post_max_size = 820M
max_execution_time = 600
memory_limit = 1024M
PHPINI

echo ""
echo ">>> NOW EDIT /var/www/zecocm/.env - set DB_*, AWS_*, ANTHROPIC_API_KEY, SEED_ADMIN_PASSWORD,"
echo "    SCHEDULE_MALWARE_SCANNER_BINARY (install ClamAV: apt install -y clamav clamav-daemon && freshclam,"
echo "    then set this to the clamscan/clamdscan path - MalwareScannerHealthCheck (OPS-16) fails /up without it)"
echo ">>> then run:  cd /var/www/zecocm && php artisan migrate --force && php artisan db:seed --force"
echo ">>> verify:    php tests/DomainTest.php   (must end: 23 passed, 0 failed)"
echo ">>> serve:     cp deploy/nginx.conf /etc/nginx/sites-enabled/zecocm.conf && nginx -t && systemctl reload nginx php8.3-fpm"
