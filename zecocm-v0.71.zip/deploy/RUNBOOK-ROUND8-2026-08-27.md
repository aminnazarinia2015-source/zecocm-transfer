# ZecoCM — Round 8: capability-toggle fixes, TRACE Greenbook answer, PDF transmittals for Change Orders/Pay Apps, accountant CSV export

Tag: v0.42. Package: `zecocm-app-2026-08-27b.zip` (sent to you directly in this chat).
sha256: `bc36fbce35e2b8e5b91705f91ff421735ff19d030476335e70f580bc995cdcde`

I could not push to the `zecocm-transfer` GitHub repo this session (this session isn't
authorized for that repo), so this time the package came straight to you as a chat
download instead of a `curl` URL. Get it onto the droplet with `scp` from your own
computer's terminal (not the DigitalOcean web console itself, which can't receive an
upload directly):

```bash
# From YOUR OWN computer's terminal (wherever the file downloaded to), not the web console:
scp ~/Downloads/zecocm-app-2026-08-27b.zip root@<droplet-ip>:/var/www/
```

Then everything below runs in the DigitalOcean web console (or an SSH session), on the droplet.

```bash
cd /var/www/zecocm

# back up first
sudo tar czf ~/zecocm-backup-$(date +%Y%m%d-%H%M%S).tar.gz --exclude=storage/logs --exclude=vendor .

echo "expected: bc36fbce35e2b8e5b91705f91ff421735ff19d030476335e70f580bc995cdcde"
sha256sum /var/www/zecocm-app-2026-08-27b.zip

unzip -o /var/www/zecocm-app-2026-08-27b.zip -d /var/www/zecocm
cd /var/www/zecocm

composer install --no-dev --optimize-autoloader

php artisan route:clear
php artisan config:clear
php artisan route:cache
php artisan config:cache
php artisan migrate --force

sudo systemctl reload php8.3-fpm 2>/dev/null || sudo systemctl reload php-fpm 2>/dev/null
sudo systemctl reload nginx
sudo systemctl restart zecocm-worker 2>/dev/null || true

bash deploy/verify-live.sh V042
```

## Two things worth a 10-second check while you're in there (found this session, can't verify from here)

1. **`ANTHROPIC_API_KEY`** in the server's `.env` — if it's blank, TRACE's paid project-assistance
   tier will always say "AI service is not configured" instead of actually answering. Free-tier
   "how does ZecoCM work" questions don't need it; paid per-project questions do.
   `grep ANTHROPIC_API_KEY .env`
2. **Queue worker** — `systemctl status zecocm-worker` should show `active (running)`. If it's not,
   paid AI runs will sit at "queued" forever in the UI. `verify-live.sh` above checks this for you
   and will print `QUEUE_HEARTBEAT_MISSING`/fail `/up` if it isn't.

## What's in this round

- Fixed 3 capability toggles in the "Add Person" invite wizard that silently granted the wrong
  permission (or nothing at all) — pay-app certify, document origination, and verify/field-check.
- TRACE now gives a correct, informative answer when asked about the Greenbook/SSPWC or other
  licensed standards, instead of a near-empty response.
- Change Orders and Pay Applications can now generate a real branded PDF-ready transmittal
  ("Prepare transmittal →" → open & print/save as PDF), same pipeline RFIs/Submittals already had.
- Pay Application detail now has a working "Download accountant export (CSV)" button — the
  backend for this already existed and had no way to reach it.

No new migrations beyond what's already in the package are destructive; `php artisan migrate`
only adds the `document_templates`/`template_assignments`/`signatures` tables from earlier
tonight if they aren't already on the server.

Paste back the `verify-live.sh` output when it's done.
