#!/usr/bin/env bash
# OPS-15: run this as the LAST step of every deploy, on the droplet, after
# reload/restart. Codex's explicit closure requirement for this row: "the
# deployment script must treat /up failure as deployment failure." Before
# this script existed, every deploy ended in a hand-typed echo that PRINTED
# the /up status code but never acted on it - a deploy that broke /up still
# reported success, which is exactly how a four-hour outage of the health
# endpoint passed through several deploys marked "verified live"
# (claude/up-health-endpoint-finding.md).
#
# Usage: bash deploy/verify-live.sh V0XX <space-separated k=v pairs to append>
# Example:
#   bash deploy/verify-live.sh V080 tr16=yes
#
# Exits 0 and prints "<TAG>_LIVE ... http=200" only when /up is genuinely
# healthy. Exits 1 and prints "<TAG>_DEPLOY_FAILED ..." otherwise - this is
# the line a deploy chain should treat as a real failure, not a status to
# eyeball.
set -uo pipefail

TAG="${1:?usage: verify-live.sh <TAG> [extra=fields ...]}"
shift || true
EXTRA="$*"

WORKER="$(systemctl is-active zecocm-worker 2>/dev/null || echo unknown)"

# OPS-14: QueueHeartbeatHealthCheck fails /up outright when no heartbeat row
# has EVER been recorded (QUEUE_HEARTBEAT_MISSING) - correct for a genuinely
# stopped scheduler, but it would also fire on every fresh deploy's first
# verify-live run, before the crontabbed scheduler has had its first minute
# to tick. Dispatching one heartbeat here proves the real worker just
# restarted can consume one - but per Codex's review, dispatching and
# immediately curling /up would RACE the worker: a dispatch not yet picked
# up after a few hundred milliseconds is completely normal, not unhealthy,
# so a bare dispatch-then-curl could intermittently fail /up on a perfectly
# healthy deploy depending on scheduling luck. --wait blocks here until
# this exact token is actually stamped handled (or times out), so /up is
# only checked once real consumption is proven or has genuinely failed to
# happen - never on a race.
if php artisan list 2>/dev/null | grep -q 'ops:dispatch-queue-heartbeat'; then
    if ! php artisan ops:dispatch-queue-heartbeat --wait=30; then
        echo "${TAG}_WARNING queue_heartbeat_not_handled_within_30s - worker may not be consuming; checking /up anyway"
    fi
fi

HTTP="$(curl -s -o /dev/null -w '%{http_code}' https://app.zecocm.com/up)"

# OPS-14: soft, non-fatal check - the scheduler cron entry is a one-time
# server setup item (deploy/RUNBOOK.md), not something this tarball
# installs. Warn rather than fail so a deploy that happens before that line
# is added doesn't get marked failed for an unrelated reason.
if ! crontab -l 2>/dev/null | grep -q 'schedule:run'; then
    echo "${TAG}_WARNING scheduler_cron_missing - queue heartbeat and failed-job-delta will never run until 'php artisan schedule:run' is crontabbed (see deploy/RUNBOOK.md)"
fi

if [ "$HTTP" = "200" ]; then
    echo "${TAG}_LIVE ${EXTRA} worker=${WORKER} up_bare=${HTTP}"
    exit 0
fi

# /up itself is now dependency-aware (App\Domain\Ops\DatabaseWriteHealthCheck)
# - a non-200 here means a real dependency failed its probe, not just that
# something returned a page. Treat it as the deploy having failed.
echo "${TAG}_DEPLOY_FAILED ${EXTRA} worker=${WORKER} up_bare=${HTTP}"
exit 1
