# ZecoCM — Deploy Runbook (DigitalOcean droplet zecocm-app-01)

Use the DigitalOcean **Web Console** (Droplets → zecocm-app-01 → Console) — SSH from
Amin's laptop works too once he generates his own key.

## One-time server setup
```bash
apt update && apt install -y php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring \
  php8.3-xml php8.3-curl php8.3-zip php8.3-gd nginx unzip clamav nodejs npm
curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer
freshclam
```

## App deploy
```bash
mkdir -p /var/www && cd /var/www
# Upload zecocm-app.zip via the console (or scp once SSH is set up), then:
unzip zecocm-app.zip -d zecocm && cd zecocm
composer install --no-dev --optimize-autoloader   # packagist works from the droplet
cp .env.example .env && php artisan key:generate
```

## Persistent evidence volume

All document, schedule, media, and plan bytes currently use ZecoCM's private
`local` disk so that malware scanning and chunk assembly operate on real local
paths. Do not set `FILESYSTEM_DISK=s3` for this release. Mount a persistent,
encrypted, backed-up volume outside `/var/www/zecocm`:

```bash
install -d -o www-data -g www-data -m 0750 /var/lib/zecocm/evidence
```

## .env — fill from the DigitalOcean control panel
```
APP_ENV=production
APP_DEBUG=false
APP_URL=https://app.zecocm.com
DB_CONNECTION=mysql
DB_HOST=<managed MySQL private host>   # Databases → zecocm-db → Connection details → PRIVATE network
DB_PORT=25060
DB_DATABASE=defaultdb
DB_USERNAME=doadmin
DB_PASSWORD=<from control panel>       # never in chat
FILESYSTEM_DISK=local
EVIDENCE_STORAGE_ROOT=/var/lib/zecocm/evidence
QUEUE_CONNECTION=database
MAIL_MAILER=<production mail transport>
MAIL_FROM_ADDRESS=support@zecocm.com
ANTHROPIC_API_KEY=<create at console.anthropic.com - powers the AI layer>
PROVENANCE_SIGNING_KEY=<generate: openssl rand -hex 32>
PROVENANCE_ACTIVE_KEY_ID=legacy-v1
SCHEDULE_REQUIRE_MALWARE_SCAN=true
SCHEDULE_MALWARE_SCANNER_BINARY=/usr/bin/clamscan
```

## Migrate + verify
```bash
composer validate --strict
php artisan optimize:clear
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan test
npm ci && npm run build
```

Do not continue to real-data acceptance unless the full native-PHP test suite
passes. The source-review WebAssembly runtime cannot provide that gate.

## Serve
Point nginx at /var/www/zecocm/public (standard Laravel vhost), then the
`app.zecocm.com` A record (already pointing at this droplet) goes live.
Add Cloudflare in front when ready (open decision).

Run the queue worker under systemd or Supervisor; a scheduler heartbeat proves
nothing if no worker consumes it:

```bash
php artisan queue:work --queue=default --tries=3 --timeout=120
```

## OPS-14 — one-time cron entry (required for the queue heartbeat health check)
Laravel's scheduler has to actually run for `ops:dispatch-queue-heartbeat` (every
minute) and `ops:report-failed-job-delta` (hourly) to fire at all — nothing on this
droplet was running `artisan schedule:run` before OPS-14, so this is a one-time
addition, not something the deploy tarball itself can install. As root:
```bash
crontab -e
# add this line:
* * * * * cd /var/www/zecocm && php artisan schedule:run >> /dev/null 2>&1
```
Without this, `QueueHeartbeatHealthCheck` never sees a `queue_heartbeats` row and
silently passes `/up` forever — it is written to treat "no row yet" as "nothing to
call stale," which is correct for a fresh deploy but means a missing cron entry
looks identical to a healthy one until enough time passes that stale rows exist. Confirm
it's working by querying the production database's `queue_heartbeats` table; it
should show rows within the last couple of minutes, most with `handled_at`
filled in.

## Real-data release gates

- Prove an encrypted database backup and `/var/lib/zecocm/evidence` backup can
  both be restored into an isolated environment.
- Confirm TLS, secure cookies, mail delivery, password-setup links, and payment
  webhook signature verification using production-like endpoints.
- Upload a clean PDF and a harmless EICAR test file; the PDF must become usable
  and the EICAR file must remain quarantined.
- Create a plan set, register two revisions, add and resolve a markup, download
  both immutable revisions, and verify TRACE names the current plan sheet.
- Exercise owner/City, CM, GC, subcontractor, accounting, field, read-only, and
  platform-technician roles. Verify denied actions on the server, not just the UI.
- Run queue, scheduler, health, failed-job, storage-capacity, load, accessibility,
  mobile, and cross-browser checks before entering customer production data.

## Security notes
- Tenant isolation is FAIL-CLOSED (app/Tenancy/TenantScope.php). Never "fix" the 1=0.
- Platform staff writes into tenant data are rejected SERVER-SIDE (controllers), not just hidden in UI.
- Restrict the firewall SSH rule to Amin's IP (still open — noted in hosting-decision.md).
