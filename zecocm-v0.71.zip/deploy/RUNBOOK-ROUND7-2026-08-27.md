# ZecoCM — Round 7: homepage logo link + copyright entity fix

Small, safe patch on top of round 6 (which you already deployed and verified tonight — TRACE key,
AI budget cap, app reachable, and the new homepage all checked out). This round fixes two cosmetic
but real bugs found in tonight's site audit: the "ZecoCM" wordmark in the top nav and footer wasn't
a link (clicking it did nothing), and the footer copyright read "© 2026 Zeco Inc." instead of
"© 2026 ZecoCM" — mixing up the software company with your separate construction company account.
No database migrations in this round, no config changes, no restart of anything AI-related needed.

```bash
cd /var/www/zecocm

# back up first
sudo tar czf ~/zecocm-backup-$(date +%Y%m%d-%H%M%S).tar.gz --exclude=storage/logs --exclude=vendor .

curl -L -o /tmp/zecocm-app-2026-08-27a.zip \
  https://raw.githubusercontent.com/aminnazarinia2015-source/zecocm-transfer/main/zecocm-app-2026-08-27a.zip

echo "expected: a738123a44e93e69b9b733c4fffad2f001afc0241780eee870e5e40884d64979"
sha256sum /tmp/zecocm-app-2026-08-27a.zip

unzip -o /tmp/zecocm-app-2026-08-27a.zip -d /var/www/zecocm
cd /var/www/zecocm

php artisan route:clear
php artisan config:clear
php artisan route:cache
php artisan config:cache
php artisan migrate --force

sudo systemctl reload php8.3-fpm 2>/dev/null || sudo systemctl reload php-fpm 2>/dev/null
sudo systemctl reload nginx

echo "=== VERIFY ==="
echo "--- homepage logo now links home? ---"
curl -s https://zecocm.com/ --resolve zecocm.com:443:127.0.0.1 | grep -o '<a class="brand" href="/"'
echo "--- copyright fixed? ---"
curl -s https://zecocm.com/ --resolve zecocm.com:443:127.0.0.1 | grep -o "© 2026 ZecoCM"
echo "--- app still reachable? ---"
curl -Ik https://app.zecocm.com/ --resolve app.zecocm.com:443:127.0.0.1 | head -1
```

Paste back the three verify lines when done.

## What's still open after this (not in this round, not blocking tonight)

- **Bare `zecocm.com` (no www) still 404s** — this is a separate nginx vhost/DNS issue I can't fix
  from here (no console access); worth a look at the nginx config on the droplet directly when you
  have a minute, or tell me to draft the exact vhost change for you to paste.
- **A stray duplicate "Zeco, inc." test customer** in the live database — it's not in the seed
  data I control, so it must have been created directly in production at some point. I can't see or
  touch the live database from here; if you check Platform → Customers and tell me which one is the
  duplicate, I'll write the exact one-line cleanup command for you to run, or delete it yourself
  from the admin panel if that's supported there.
- **Payment/self-serve onboarding round** — built and fully tested (934/934) but intentionally NOT
  in this package. It's a separate, bigger feature that doesn't affect tonight's city
  demo/test and isn't wired to real Stripe/PayPal accounts yet.
