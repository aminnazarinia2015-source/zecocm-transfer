# ZecoCM — ONE deploy, everything included

Sorry for splitting this into 5 runbooks earlier — that was more friction
than you needed. Each build already contained everything before it, so
this single script below deploys ALL of it in one shot: DNS/homepage,
Ask TRACE + back button + suspend/reactivate, the actual TRACE fix, AI
budget caps, AI budget visibility, and the Knowledge Library cross-project
sharing fix (LIB-1). Nothing else to run after this.

Your Anthropic key is already sitting in `.env` from earlier — this script
does not touch it or need it again.

```bash
cd /var/www/zecocm

# back up first
sudo tar czf ~/zecocm-backup-$(date +%Y%m%d-%H%M%S).tar.gz --exclude=storage/logs --exclude=vendor .

curl -L -o /tmp/zecocm-app-2026-08-26f.zip \
  https://raw.githubusercontent.com/aminnazarinia2015-source/zecocm-transfer/main/zecocm-app-2026-08-26f.zip

echo "expected: fcfddb02efd496c8346e86240918de73decf84e7bf1f0670280da3352d015a2f"
sha256sum /tmp/zecocm-app-2026-08-26f.zip

unzip -o /tmp/zecocm-app-2026-08-26f.zip -d /var/www/zecocm
cd /var/www/zecocm

php artisan route:clear
php artisan config:clear
php artisan route:cache
php artisan config:cache
php artisan migrate --force

sudo systemctl reload php8.3-fpm 2>/dev/null || sudo systemctl reload php-fpm 2>/dev/null
sudo systemctl reload nginx

echo "=== VERIFY ==="
echo "--- TRACE key resolves? ---"
php artisan tinker --execute="echo config('zecocm_ai.api_key') ? 'set (length '.strlen(config('zecocm_ai.api_key')).')' : 'MISSING';"
echo ""
echo "--- Zeco Inc AI budget cap set? ---"
php artisan tinker --execute="echo App\Models\CapabilityGrant::where('capability_key','ai.assist')->first()->budget_limit_micros;"
echo ""
echo "--- app reachable? ---"
curl -Ik https://app.zecocm.com/ --resolve app.zecocm.com:443:127.0.0.1 | head -1
echo "--- new homepage live? ---"
curl -s https://zecocm.com/ --resolve zecocm.com:443:127.0.0.1 | grep -o "What's running today"
```

Paste the whole thing back to me when it's done — all four verify lines.

Then go test it for real in the browser: open a real project, click "Ask
TRACE" (not "Ask ZecoCM" anymore), ask it a real question about the
project, and check Platform → Customers → Zeco Inc. → Licences for the new
"AI spend: \$X / \$Y" line under TRACE. Tell me what you see on both.

Also worth testing once this is live: a document ingested into the
Knowledge Library as a tenant-wide "regulatory" or "organization" source
under one project should now actually be retrievable by TRACE from a
*different* project in the same account — that was silently broken before
this build (round 6 / LIB-1) and is now fixed and covered by 4 new tests.

I'm continuing to work through the rest of the list right now — the stray
duplicate "Zeco, inc." test account, System Settings scope, and whatever
else turns up — while you run this.
