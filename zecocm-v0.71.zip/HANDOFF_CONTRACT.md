# ZecoCM — Build Handoff Contract

Two build sides work on this system. This file is the contract between them. It is short
on purpose. If a rule below is broken, the other side loses work and the product loses
truthfulness — both have already happened.

## 1. Cut every bundle from the repository, never from the last package you sent

**Source of truth: `github.com/aminnazarinia2015-source/zecocm`, branch `main`, the
highest-numbered `zecocm-vX.Y.zip`.**

Five consecutive bundles were cut from the previous package instead. Each one arrived
reverting fixes and deleting tests that had been added in between. Nothing was lost, but
only because every incoming file is now diffed rather than copied, and that costs an hour
a round. What v0.25 alone would have silently reverted:

- both contract-clock fixes (the system inventing contract terms and printing them as
  contract terms);
- `inspections` capability `operational => true`, without which the finished Quality
  module disappears from live navigation;
- four regression tests.

**Before starting a bundle: download the newest zip from `main`. Diff your tree against
it. Start from it.**

## 2. Never delete a test you did not write

If a test looks wrong, leave it and say so in the release notes. A deleted regression test
is how a fixed defect ships again. Three of the defects found in the live sweep had tests
written for them the same hour; two of those tests were removed by the next bundle.

## 3. Server-side green is not evidence that anything works

Every defect found in the first live browser sweep passed the full automated suite:

| Defect | What the suite saw |
|---|---|
| Document library and Quality unreachable — a stale routing guard | modules 200, tests green |
| Project creation inventing contract clocks and printing them as contract terms | 201 created |
| New Project wizard never calling the server, announcing success anyway | nothing to see; no request was made |
| Support Mode unable to upload any file — multipart dropped the tenant header | server correctly 404'd the wrong tenant |
| A false "not wired" toast after successful navigation | not observable server-side |

A release is not validated until someone has opened it in a browser, signed in, and
written a record. Four consecutive validation files stated the browser could not reach a
server; that is a blocker to release, not a footnote.

## 4. Division of work

- **Build side (OpenAI/Codex):** new modules, migrations, controllers, documentation.
  Fast, broad, well documented.
- **Verification side (Claude):** diff and merge every bundle, adversarial tests against
  the rules that matter, live browser sweeps against the deployed site, deployment.

This is not a compromise. It is where each side is measurably stronger.

## 5. Rules the product cannot break

These are not preferences. Breaking one makes the product worthless in its market.

1. **Never invent a contract term.** No default clock, period, or interpretation. If it is
   not recorded, refuse and say what is missing.
2. **Never manufacture a success.** If nothing reached the server, say nothing was saved.
3. **Never present a party's claim as a finding**, and never attribute fault.
4. **Never let a claim or a recommendation complete a formal act.** Closure, sealing and
   issuance require an accountable human determination.
5. **Never overwrite evidence.** Versions, dispositions and events append.
6. **Fail closed.** Missing tenant context matches nothing.
7. **A transmittal carries the account owner's identity, never the platform's.**

## 6. Packaging

No `.env`, vendor, node_modules, caches, logs, uploads, or **test databases**.
`storage/framework/testing-*.sqlite` shipped in four consecutive packages.

## 7. Before calling a release healthy

Deployed, then in a browser: sign in, Back/Forward, refresh, create a record, seal it,
issue a document, upload a file in Support Mode, and walk one state machine to closure.
On a phone as well as a desktop.
