# ZecoCM Full-System AI and Data Architecture

## Intelligence layers

1. **Free Product Guide** - released product documentation, guided tours, terminology, and public-work basics. No project evidence and no paid model dependency.
2. **Project Evidence Assistant** - paid, project-scoped retrieval, drafting, comparison, and education from authorized evidence.
3. **Organization/City Atlas** - steward-approved standards, policies, templates, interpretations, and lessons reusable inside the account.
4. **Regulatory Library** - official or licensed primary sources with jurisdiction, edition, effective dates, and usage rights.
5. **Portfolio Pattern Engine** - authorized historical behavior and outcomes labeled as patterns, never governing rules.
6. **Cross-Customer Learning** - opt-in, de-identified, thresholded aggregate features; no raw record or recognizable counterparty exposure.

## Ingestion plane

All inputs enter a quarantine-first pipeline:

`upload/feed -> idempotency/hash -> malware and archive inspection -> immutable object storage -> parser/OCR/layout extraction -> deterministic classification -> page/coordinate mapping -> duplicate/supersession/conflict candidates -> review queue -> verified/adopted retrieval`

Supported production targets: PDF, PDF/A, text, CSV/XLSX with formula defenses, Microsoft Project XML, Primavera exports, images, email packages, common Office formats, drawing sheets, and model metadata. Native MPP is accepted only with a tested parser. Scanned and uncertain extraction remains provisional.

Bulk ingestion uses a manifest, resumable uploads, per-file state, cancellation, retry safety, and a completion receipt. ZIPs are never blindly expanded: inspect path traversal, entry count, compression ratio, nested archives, encrypted entries, names, MIME, and total expanded size.

## Online source feeds

External information arrives only through registered connectors. Each connector defines owner, approved domains and paths, jurisdiction, authority, collection, license, schedule, MIME and size limits, authentication, steward, and retention. Workers run with restricted egress and block private/reserved addresses and unsafe redirects.

Each retrieval creates an immutable snapshot with URL, redirect chain, headers, retrieved time, edition/effective dates, hash, parser, license, and change diff. New or changed material stays provisional until reviewed. General web search provides research leads only and cannot become an authoritative citation without promotion.

## Retrieval

Retrieval scope is server-derived from authenticated tenant, project grants, organization, discipline, evidence classification, jurisdiction, funding, contract, date, and requested task. Callers never select a role or hidden corpus.

The retrieval stack combines:

- structured filters;
- exact identifiers and references;
- full-text/BM25;
- semantic embeddings stored in tenant-aware indexes;
- graph expansion across citations, supersession, related records, schedules, costs, and decisions;
- authority/freshness weighting;
- reranking;
- conflict and missing-source detection.

Results include immutable source/version/passage IDs, page/sheet/section, hash, authority, access class, retrieval time, effective dates, and score explanation. Authorization filtering happens before ranking and again before serialization.

## Model gateway

All models sit behind a provider-neutral gateway. Task policy selects an approved provider/model tier based on licence, risk, privacy, latency, context, and budget. The gateway supports cloud, customer-private, and locally hosted models while preserving the same run envelope.

Every run records tenant/project, requester, task, idempotency key, authorization scope, retrieval scope, source manifest, provider/model, prompt and policy versions, assumptions, tokens, cost, latency, confidence, classification, refusal, evaluation, progress, cancellation, and event hashes.

Model output is structured. Unknown or out-of-range passage references, unsupported claims, conflicting sources, missing authority, stale governing material, professional judgment, and insufficient evidence produce refusal or escalation.

## Continuous learning

Never “train on everything.” Capture append-only accepted, rejected, corrected, and outcome events. Preserve who labeled them and under what authority. Create candidate examples only after permissions, de-identification, quality checks, and steward approval.

Fine-tune stable behavior—classification, routing, extraction normalization, terminology, formatting, and drafting style. Keep mutable facts, regulations, standards, contract clauses, and decisions in retrieval.

The model registry stores dataset manifest/hash, code version, base model, training configuration, evaluator, benchmark results, safety results, approval, release window, rollback target, and permitted tasks. Promotion requires no regression in citation precision, refusal correctness, tenant isolation, high-risk escalation, and human acceptance.

## Evaluation system

Maintain versioned test sets by city, role, discipline, task, document type, risk class, language, and source condition. Metrics include retrieval recall, citation precision/coverage, claim support, refusal precision/recall, authority routing, leakage, hallucination, stale-source handling, latency, cost, and human acceptance.

Red-team scenarios include cross-tenant identifiers, prompt injection inside documents, hidden instructions, conflicting standards, superseded rules, malicious PDFs, poisoned historical examples, adversarial citations, role escalation, and requests for legal fault or professional judgment.

## Knowledge graph

Nodes: sources, versions, passages, organizations, people, projects, assets, locations, contract clauses, specification sections, drawings, activities, costs, records, evidence, assertions, calculations, disputes, decisions, and outcomes.

Edges: supersedes, amends, cites, governs, conflicts with, interprets, derived from, submitted by, reviewed by, authorized by, related to, predecessor, resource, calendar, affected by, paid by, decided by, and corrected by. Important relationships are relational and tenant-scoped; JSON is not the sole source of truth.

## Privacy and cross-customer value

Raw records remain inside the originating account. City libraries remain private unless explicitly published. Cross-customer learning requires contractual opt-in, minimum aggregation thresholds, rare-category suppression, entity removal, leakage tests, purpose limitation, and revocation strategy. An aggregate pattern can advise; it cannot cite or expose another customer's record.

## Infrastructure target

- Managed relational database with row-level tenant enforcement and read replicas as needed.
- Encrypted object storage with immutable/versioned retention.
- Redis-backed queue and cache with tenant-aware keys.
- Search plus vector infrastructure with hard tenant partitions.
- Restricted ingestion and external-feed workers.
- Centralized secrets, KMS/HSM-backed signing, observability, SIEM, backups, restore drills, and multi-region recovery appropriate to customer commitments.
- Separate development, test, staging, pilot, and production environments; sanitized fixtures only outside production.
