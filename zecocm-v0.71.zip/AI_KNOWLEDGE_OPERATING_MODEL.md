# ZecoCM AI Knowledge Operating Model

## Loading information

Use the Knowledge Atlas to upload authorized PDFs or text. For large migrations, the next ingestion worker should accept a manifest plus files and process each object independently. Archives must be inspected for path traversal, compression ratio, file count, encrypted entries, active content, malformed names, and duplicate hashes before extraction.

The ingestion pipeline is: quarantine -> malware and format validation -> immutable storage -> extraction/OCR -> deterministic classification -> page/section mapping -> duplicate and supersession candidates -> human review -> verified/adopted retrieval.

## Learning over time

Do not retrain a foundation model whenever a document arrives. Current facts, standards, contract clauses, editions, and decisions stay in retrieval so they remain versioned, permission-filtered, and correctable.

Capture accepted, rejected, corrected, and outcome-labeled AI runs. After de-identification and steward approval, use these examples to improve stable behavior: routing, classification, document structure, terminology, and drafting style. A candidate model or prompt is released only when its evaluation set shows no loss in citation precision, refusal correctness, tenant isolation, or high-risk escalation.

## Outside and online sources

Use allowlisted connectors, not an autonomous crawler. Each feed has an owner, approved domain/path, jurisdiction, collection, license, polling schedule, maximum size, expected MIME types, and knowledge steward. Every retrieval creates a new immutable snapshot. Changes create review tasks; they never silently overwrite the prior edition.

Recommended source order:

1. Project contract documents and issued amendments.
2. Adopted city standards and official city publications.
3. State and federal primary sources.
4. Licensed standards under valid contractual rights.
5. Approved organizational lessons and historical patterns.
6. General web material only as non-authoritative research leads.

Online material is never a formal determination. If currency, applicability, authority, or licensing cannot be proven, ZecoCM labels it provisional and refuses to rely on it.

## Private/local AI

A private deployment can route approved tasks to a customer-isolated or ZecoCM-hosted model. The gateway must expose the same audited run envelope and refusal policy as cloud providers. Begin with classification and drafting style. Do not fine-tune legal conclusions, design/life-safety judgments, or mutable city requirements into model weights.
