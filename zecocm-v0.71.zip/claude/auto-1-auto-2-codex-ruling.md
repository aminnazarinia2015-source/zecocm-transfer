# AUTO-1 / AUTO-2 — Codex's ruling on Amin's strategic direction (26 Aug 2026)

Amin proposed two new roadmap rows and explicitly asked they be run past Codex as product
direction, not decided unilaterally by either AI. Full ruling below, captured verbatim from the
ChatGPT conversation (tab "Test").

## Amin's proposal, in brief

- **AUTO-1 — Self-Service Commercial Lifecycle**: registration → plan selection → online payment →
  automatic tenant provisioning → project wizard → invite team → immediate use, plus automated
  renewals, receipts, subscription status, usage limits, failed-payment recovery/grace periods,
  upgrades/downgrades, cancellation. No Zeco staff touches ordinary-contractor accounts.
  Enterprise/public-agency accounts keep negotiated invoicing.
- **AUTO-2 — Governed Project Autopilot**: a layer above the existing modules that continuously
  inspects project state and decides the next safe action, with four autonomy levels stored per
  capability, never decided by the model: **AUTO**, **AUTO+NOTIFY**, **APPROVAL REQUIRED**,
  **HUMAN ONLY**. Product surface concept: **TRACE Project Steward**, a live per-project state
  line. Amin's stated rule: *"Automate execution. Escalate judgment. Never automate away
  accountability."* Design requirement: *"Every autonomous action must be explainable afterward:
  what triggered it, what rule authorized it, what evidence it used, what it changed, and whether a
  human could or did intervene."*

## Codex's ruling

**Both become roadmap rows. Neither is a current blocking closure row. Only AUTO-2 needs an
architectural design decision now, because it touches the trust boundaries this project has spent
the day hardening; AUTO-1 is mostly commercial plumbing.**

### AUTO-1 — roadmap, not blocking

Eventual closure should cover: company registration, plan selection, payment, tenant provisioning,
entitlement/license issuance, project creation, team invitation, billing lifecycle, failed-payment
state, renewal/cancellation, receipts/invoices, plan changes, usage enforcement. Enterprise/public-
agency commercial terms stay separate. Must not block PN 851 or current product closure.

**The architectural rule to preserve**: *"Commercial entitlement can grant access to a capability;
it cannot grant evidentiary authority inside a project."* Payment success may provision a tenant.
It must never mean verified source, confirmed precedence, approved change order, authorized
destruction, or any other project-governance state. Licensing and authority remain different
dimensions.

### AUTO-2 — yes, but needs its own authorization primitive, not reused capability_grants

A capability grant answers "may this tenant/user use feature X?" Autonomy answers "may the system
perform action X without a human immediately approving this particular execution?" Different
questions — a user can be licensed for pay apps while TRACE is still forbidden from submitting one
automatically.

**New primitive: `autonomy_policies`.** At minimum: `tenant_id`, `project_id`, `capability`,
`action_type`, `autonomy_level`, `authority_source`, `set_by`, `set_at`, `effective_at`, `status`,
`supersedes_policy_id`. Enum: `AUTO` / `AUTO_NOTIFY` / `APPROVAL_REQUIRED` / `HUMAN_ONLY`.

**Critical additional field: `maximum_allowed_level`** — hardcoded/system-governed by action class,
cannot be raised by customer configuration, not even by an admin. E.g. `send_contractual_notice`
maximum = `APPROVAL_REQUIRED`; `destroy_evidence` maximum = `HUMAN_ONLY`. Effective level is always
`min(project policy, system maximum autonomy)` — a ceiling the customer cannot accidentally weaken.

**A fifth state below HUMAN_ONLY: `NOT_AUTOMATABLE`.** HUMAN_ONLY means the system may prepare
analysis but a human must decide. NOT_AUTOMATABLE means the system must not even create the action
automatically from the triggering condition — used sparingly where automated framing itself could
bias the decision (e.g. determining fraud, litigation strategy, waiver/forfeiture, contractor
termination). TRACE can surface facts but must not create a pre-framed "Approve contractor
termination" action just because signals exist — that anchors a human toward a conclusion.

**A first-class `autonomous_actions` log is the product, not an afterthought.** Every action
records: `action_id`, `tenant/project`, `capability`, `action_type`, `trigger_type`,
`trigger_record_ids`, `rule_id/version`, `autonomy_policy_id`, `effective_autonomy_level`,
`evidence_used`, `proposed_change`, `executed_change`, `status`, `executed_by = system`,
`human_intervention_state`, `created_at`, `executed_at`, `notified_at`, `approved_by`,
`approved_at`, `cancelled_by`, `cancelled_at`, `result_hash`. This is exactly what satisfies Amin's
explainability requirement.

**Triggering must be deterministic where possible** — domain triggers (notice clock at T-5 days,
pay-app period opened, CO approved, closeout obligation at risk, warranty repair completed, TR-16
insufficient_evidence) decide whether an action candidate exists. The model may help draft content
but never decides whether the action exists or what autonomy tier applies.

**Separate "decide action" from "generate content."** A3 determines a deadline is approaching (deterministic);
AUTO-2 decides by rule that a draft should be prepared (deterministic); TRACE may draft the wording
from governed evidence; the action policy (e.g. `send_contractual_notice = APPROVAL_REQUIRED`)
decides whether it sends itself. The model never gets to decide "this seems routine, I'll send it."

**Tier guidance, sharper than Amin's own draft**:
- **AUTO** — calculate clocks, create draft shells, roll forward certified prior values, run
  checks, generate internal packages, create reminders, update derived readiness state, organize
  records. No external legal effect.
- **AUTO+NOTIFY** — narrower than proposed. Only when satisfaction is purely mechanical ("required
  file X received and hash-valid"), never substantive ("notice requirement satisfied" is judgment).
- **APPROVAL REQUIRED** — send notices, external communications, certify pay application,
  approve/change financial authorization, verify an authoritative source, open an acquisition
  window, submit an agency package, reclassify a governing source, finalize closeout deliverable
  acceptance.
- **HUMAN ONLY** — legal effect, disputed scope, evidence destruction authorization, two-person
  governed determinations, final conflict resolution where authority is genuinely ambiguous.

**The biggest AUTO-2 failure mode, named explicitly for the roadmap**: *automation laundering
judgment into execution.* Example given: TR-16 says evidence is insufficient (trench depth
conflicts between two sources); AUTO-2 must never create "Approve 36-inch trench depth" — that
already presumes an answer. The correct action is "Review unresolved trench-depth conflict: sources
A and B differ; authority/applicability unresolved." **The governing invariant**: *"Autonomous
actions inherit the epistemic state of their trigger. They may not convert unresolved/refused state
into a proposed conclusion."*

**TRACE Project Steward** is endorsed as a strong product surface, with one correction: show state
transitions, not anthropomorphic "decisions" — each item expands into trigger / authority-rule /
evidence / action taken-or-proposed / current status / next step. This is Temporal Epistemic
Integrity in operational form.

**Relationship to existing code, confirmed as the right precedents**: `CapabilityCatalog` (what
exists), `capability_grants` (who may use it), `RefusalPolicy` (when the model must not conclude),
`Escalation::basis` (why judgment is deferred), governed determinations (how humans confer
authority). AUTO-2 is the next layer on top — what the system may execute automatically once those
other layers have established the state. It replaces none of them.

## Standing invariant to carry into any future AUTO-2 build

> Autonomy policy is a separate authorization layer from capability licensing. The model never
> chooses its own autonomy level. Autonomous actions inherit the certainty, authority, and
> limitations of the evidence state that triggered them. No automated execution may elevate an
> unresolved condition into a resolved judgment.

## Disposition

Neither AUTO-1 nor AUTO-2 expands the current blocking closure register. Both are recorded as
roadmap items, alongside TR-19/SCALE-1-5/MOBILE-1. **Sequencing is unchanged: TR-18 → OPS-14**,
Codex explicit that neither AUTO row should interrupt that sequence.
