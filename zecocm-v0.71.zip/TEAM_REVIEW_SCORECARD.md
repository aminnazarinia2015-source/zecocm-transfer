# ZecoCM Team Review Scorecard

Score each item **Accept**, **Revise**, or **Reject**. For Revise/Reject, name one accountable owner and due date. A release cannot pass on an average score; every P0 item must be accepted.

## P0 governance and truth

- [ ] Platform console contains no projects and exposes only platform administration.
- [ ] New customer worlds start with zero projects.
- [ ] Purchaser hierarchy and sponsored-portal ceilings are correct for City, CM, contractor, and designer buyers.
- [ ] Tenant isolation fails closed everywhere, including support tools, search, jobs, counts, and exports.
- [ ] Technicians are read-only; platform-admin support writes are stamped.
- [ ] Facts, assertions, calculations, correlations, inferences, disputes, recommendations, and determinations are structurally distinct.
- [ ] Formal actions require accountable human authority.
- [ ] AI never declares fault or performs professional/legal determinations.

## P0 workflows

- [ ] Login, restore, logout, password, profile, logo, and credential handoff.
- [ ] Project creation, people, structure, assignments, permissions, and clocks.
- [ ] Complete RFI workflow with references, evidence, response authority, issue, receipt, and correction.
- [ ] Complete submittal workflow with requirements, routing, stamp, resubmittal, issue, and procurement/schedule links.
- [ ] Complete daily workflow with offline field capture, evidence, signatures, lock, and correction.
- [ ] Schedule vault, accepted-version gate, CPM/delta audit, and disposition events.
- [ ] Knowledge ingestion, quarantine, review, source viewer, and cited/refused answers.

## Design quality

- [ ] Universal command center reduces menu memorization without hiding navigation.
- [ ] Project Success Home answers “where do we stand and what should I do?”
- [ ] Mobile is a field tool, not a compressed desktop.
- [ ] Every screen includes its complete state contract.
- [ ] Every consequential value opens its source/version.
- [ ] Accessibility acceptance is annotated and tested.
- [ ] English/Spanish expansion, explicit units/time zones, and plain-language content are supported.

## Intelligence quality

- [ ] Product help and paid project AI are unmistakably separated.
- [ ] Retrieval scope is derived server-side and authorization-filtered.
- [ ] Every supported claim has immutable citations; unsupported claims refuse.
- [ ] City standards, historical behavior, and project contract requirements cannot be confused.
- [ ] External sources are allowlisted, snapshotted, hashed, licensed, and reviewed.
- [ ] Feedback appends; original AI output and human decisions are preserved.
- [ ] Model releases require evaluation and rollback.

## Operational readiness

- [ ] Production database, queue, object storage, malware scanning, secrets, monitoring, and backups configured.
- [ ] Restore, rollback, incident, retention, and legal-hold procedures tested.
- [ ] Penetration, load, accessibility, browser/device, and tenant-leakage tests pass.
- [ ] No secret, customer data, cache, test database, or dependency directory ships in the release archive.
- [ ] Pilot success metrics and go/no-go authority are documented.

## Final disposition

- Product owner: ____________________  Decision/date: ____________________
- Design lead: ______________________  Decision/date: ____________________
- Engineering lead: _________________  Decision/date: ____________________
- Security lead: ____________________  Decision/date: ____________________
- Construction operations lead: _____  Decision/date: ____________________
- Public owner/agency reviewer: ______  Decision/date: ____________________
