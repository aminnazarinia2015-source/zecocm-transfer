# ZecoCM — Deploy Runbook (DigitalOcean droplet zecocm-app-01)

Use the DigitalOcean **Web Console** (Droplets → zecocm-app-01 → Console) — SSH from
Amin's laptop works too once he generates his own key.

## One-time server setup
```bash
apt update && apt install -y php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring \
  php8.3-xml php8.3-curl php8.3-zip php8.3-gd nginx unzip
curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer
```

## App deploy
```bash
mkdir -p /var/www && cd /var/www
# Upload zecocm-app.zip via the console (or scp once SSH is set up), then:
unzip zecocm-app.zip -d zecocm && cd zecocm
composer install --no-dev --optimize-autoloader   # packagist works from the droplet
cp .env.example .env && php artisan key:generate
```

## .env — fill from the DigitalOcean control panel
```
DB_CONNECTION=mysql
DB_HOST=<managed MySQL private host>   # Databases → zecocm-db → Connection details → PRIVATE network
DB_PORT=25060
DB_DATABASE=defaultdb
DB_USERNAME=doadmin
DB_PASSWORD=<from control panel>       # never in chat
FILESYSTEM_DISK=s3
AWS_ACCESS_KEY_ID=<Spaces access key>
AWS_SECRET_ACCESS_KEY=<the secret Amin saved>
AWS_DEFAULT_REGION=sfo3
AWS_BUCKET=zecocm-files
AWS_ENDPOINT=https://sfo3.digitaloceanspaces.com
ANTHROPIC_API_KEY=<create at console.anthropic.com - powers the AI layer>
PROVENANCE_SIGNING_KEY=<generate: openssl rand -hex 32>
```

## Migrate + verify
```bash
php artisan migrate
php tests/DomainTest.php    # must print "23 passed, 0 failed"
```

## Serve
Point nginx at /var/www/zecocm/public (standard Laravel vhost), then the
`app.zecocm.com` A record (already pointing at this droplet) goes live.
Add Cloudflare in front when ready (open decision).

## OPS-14 — one-time cron entry (required for the queue heartbeat health check)
Laravel's scheduler has to actually run for `ops:dispatch-queue-heartbeat` (every
minute) and `ops:report-failed-job-delta` (hourly) to fire at all — nothing on this
droplet was running `artisan schedule:run` before OPS-14, so this is a one-time
addition, not something the deploy tarball itself can install. As root:
```bash
crontab -e
# add this line:
* * * * * cd /var/www/zecocm && php artisan schedule:run >> /dev/null 2>&1
```
Without this, `QueueHeartbeatHealthCheck` never sees a `queue_heartbeats` row and
silently passes `/up` forever — it is written to treat "no row yet" as "nothing to
call stale," which is correct for a fresh deploy but means a missing cron entry
looks identical to a healthy one until enough time passes that stale rows exist. Confirm
it's working after adding it: `sqlite3 database/database.sqlite "select * from
queue_heartbeats order by id desc limit 3;"` should show rows within the last
couple of minutes, most with `handled_at` filled in.

## Security notes
- Tenant isolation is FAIL-CLOSED (app/Tenancy/TenantScope.php). Never "fix" the 1=0.
- Platform staff writes into tenant data are rejected SERVER-SIDE (controllers), not just hidden in UI.
- Restrict the firewall SSH rule to Amin's IP (still open — noted in hosting-decision.md).
