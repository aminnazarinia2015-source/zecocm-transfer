<?php

/**
 * EV-12: the signing-key ring for ProvenanceSealer's HMAC seals.
 *
 * Before this row there was exactly one signing key - PROVENANCE_SIGNING_KEY,
 * one mutable environment variable - and nothing in a sealed record said
 * which value of that variable produced its signature. Rotating it (a
 * disclosed leak, routine hygiene) would have silently invalidated every
 * seal ever written, because verification always used whatever the variable
 * currently held at the moment `verify()` ran.
 *
 * `active_key_id` names the key NEW seals are signed with. `keys` is every
 * key this installation has EVER signed with, keyed by that same id -
 * historical entries are retained here, never deleted, so a seal written
 * under a retired key can still be verified after rotation.
 *
 * Rotating means: add a new entry below, point `active_key_id` at it, and
 * leave every existing entry exactly as it was. This file (plus its .env
 * values) IS the append-only rotation log - see SigningKeyRing's own doc
 * comment for how a missing or unrecognised key id is handled.
 */
return [
    'active_key_id' => env('PROVENANCE_ACTIVE_KEY_ID', \App\Domain\Provenance\SigningKeyRing::LEGACY_KEY_ID),

    'keys' => [
        // The one key this codebase has ever signed with before EV-12,
        // named so historical seals (which predate signing_key_id entirely -
        // see ProvenanceSealer::verify()) can still be checked against it.
        // Never rename or remove this entry: doing so strands every seal
        // written before the first rotation.
        \App\Domain\Provenance\SigningKeyRing::LEGACY_KEY_ID => env('PROVENANCE_SIGNING_KEY', ''),

        // Example of what a rotation adds (uncomment and set a real env var
        // when EV-12's rotation is actually exercised):
        // 'v2-2026-09' => env('PROVENANCE_SIGNING_KEY_V2', ''),
    ],
];
