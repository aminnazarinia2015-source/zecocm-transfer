<?php

namespace Tests\Feature;

use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * TR-13: effective-date and jurisdiction handling for statutes and contract
 * documents. `knowledge_source_versions.effective_from`/`effective_until` and
 * `knowledge_sources.jurisdiction` both existed in the schema, both could be
 * set at ingest (`KnowledgeController`), and neither was ever consulted by
 * `HybridKnowledgeRetriever` - the same "written by a human, read by nothing"
 * shape D5 had before TR-17 closed it. A regulatory determination amended
 * next month, or one licensed for a different state's public contract code,
 * was retrievable and rankable exactly like current, correctly-scoped text.
 *
 * Scope, stated rather than silently assumed: only the shared `regulatory`
 * collection is jurisdiction-gated, and only against a two-letter state code
 * - `Project` has no city or county field to check a city-level source
 * against, so city/federal/free-text jurisdiction values are left alone (see
 * `JurisdictionMatch`'s own doc comment, and the unit-level test file for
 * that boundary in isolation).
 */
class Tr13EffectiveDateJurisdictionTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Constructors', 'type' => 'Contractor',
            'status' => 'active', 'entitlements' => Tenant::defaultEntitlements('Contractor'),
            'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend Levee',
            'sector' => 'public', 'owner_name' => 'City of Riverbend', 'state' => 'CA',
            'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate Constructors', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_not_yet_effective_regulatory_provision_is_never_retrieved(): void
    {
        $this->seedRegulatorySource('CA', now()->addYear(), null,
            'Effective next year, the retention rate on public works contracts shall be 5 percent.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertSame([], $found, 'A provision not yet in force must not be retrievable.');
    }

    public function test_a_lapsed_regulatory_provision_is_never_retrieved(): void
    {
        $this->seedRegulatorySource('CA', now()->subYears(3), now()->subYear(),
            'Under the prior rule, the retention rate on public works contracts was 10 percent.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertSame([], $found, 'A provision whose effective window has lapsed must not be retrievable.');
    }

    public function test_a_currently_effective_regulatory_provision_is_retrieved(): void
    {
        // The control case: same shape, in-window dates, proving the two
        // refusals above are the date check and not a broken fixture.
        $this->seedRegulatorySource('CA', now()->subYear(), now()->addYear(),
            'The retention rate on public works contracts shall be 5 percent.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertNotEmpty($found, 'A provision within its effective window should have been retrievable.');
        $this->assertStringContainsString('5 percent', $found[0]->text);
    }

    public function test_an_open_ended_effective_from_with_no_end_date_is_retrieved(): void
    {
        // Most regulatory content never gets an effective_until at all - it is
        // simply in force until superseded. Absent bounds must not be treated
        // as "not yet effective."
        $this->seedRegulatorySource('CA', now()->subYears(5), null,
            'The retention rate on public works contracts shall be 5 percent.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertNotEmpty($found);
    }

    public function test_a_regulatory_source_licensed_for_a_different_state_is_never_retrieved(): void
    {
        // This project is in CA. A Nevada public-contract-code determination
        // must not answer its questions merely because both tagged the same
        // corpus name.
        $this->seedRegulatorySource('NV', now()->subYear(), null,
            'Under Nevada law, the retention rate on public works contracts shall be 2 percent.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertSame([], $found, 'A different state\'s regulatory text must not be retrievable for this project.');
    }

    public function test_a_same_state_regulatory_source_is_retrieved(): void
    {
        // The control case for the jurisdiction check.
        $this->seedRegulatorySource('CA', now()->subYear(), null,
            'The retention rate on public works contracts shall be 5 percent under California law.');

        $found = $this->retrieve('what is the retention rate on public works contracts');

        $this->assertNotEmpty($found);
    }

    public function test_a_project_collection_source_is_never_jurisdiction_gated(): void
    {
        // The project's own contract is not "regulatory" - jurisdiction on a
        // project-collection source is metadata, never a retrieval gate.
        // (Uses a corpus this project's JurisdictionScope actually requests:
        // project_specs, always in scope regardless of sector.)
        TenantContext::set($this->tenant->id);
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'project',
            'title' => 'Riverbend Project Specifications', 'source_type' => 'specification',
            'jurisdiction' => 'NV', 'discipline' => 'civil', 'authority_level' => 'project_contract',
            'access_classification' => 'project_private', 'verification_status' => 'verified',
            'ingestion_status' => 'ready', 'mime_type' => 'text/plain', 'storage_path' => 'test/spec',
            'byte_size' => 1, 'sha256' => str_repeat('a', 64), 'malware_scan_status' => 'clean']);
        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'sha256' => str_repeat('a', 64), 'extraction_method' => 'plain-text', 'extraction_confidence' => 1.0,
            'parser_version' => 'test', 'classification' => ['corpora' => ['project_specs']],
            'storage_path' => 'test/spec', 'mime_type' => 'text/plain', 'byte_size' => 1,
            'malware_scan_status' => 'clean']);
        $body = 'The retention rate under this contract shall be 5 percent.';
        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
        TenantContext::clear();

        $found = $this->retrieve('what is the retention rate under this contract');

        $this->assertNotEmpty($found, 'jurisdiction=NV on a project-collection source wrongly blocked retrieval.');
    }

    /** @param list<\App\Domain\Ai\RetrievedPassage> $found */
    private function retrieve(string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function seedRegulatorySource(string $jurisdiction, $effectiveFrom, $effectiveUntil, string $body): void
    {
        TenantContext::set($this->tenant->id);
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) \Illuminate\Support\Str::uuid(), 'collection' => 'regulatory',
            'title' => 'Public Contract Code Retention Provisions', 'source_type' => 'regulation',
            'jurisdiction' => $jurisdiction, 'discipline' => null, 'authority_level' => 'published_regulation',
            'access_classification' => 'project_private', 'verification_status' => 'verified',
            'ingestion_status' => 'ready', 'mime_type' => 'text/plain', 'storage_path' => 'test/reg',
            'byte_size' => 1, 'sha256' => str_repeat('b', 64), 'malware_scan_status' => 'clean']);
        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'effective_from' => $effectiveFrom, 'effective_until' => $effectiveUntil,
            'sha256' => str_repeat('b', 64), 'extraction_method' => 'plain-text', 'extraction_confidence' => 1.0,
            'parser_version' => 'test', 'classification' => ['corpora' => ['state_public_contract_code']],
            'storage_path' => 'test/reg', 'mime_type' => 'text/plain', 'byte_size' => 1,
            'malware_scan_status' => 'clean']);
        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
        TenantContext::clear();
    }
}
