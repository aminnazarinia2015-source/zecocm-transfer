<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The context header in every project view reads ZAPI.account.tenant_name
 * to show the signed-in customer's real company name - GET /account never
 * included that field, so every customer, every time, saw the "Your
 * account" fallback instead of their actual company name.
 */
class AccountShowTenantNameTest extends TestCase
{
    use RefreshDatabase;

    public function test_account_show_includes_the_users_tenant_name(): void
    {
        $tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($user);

        $this->getJson('/api/account')->assertOk()->assertJsonPath('tenant_name', 'Northgate Builders');
    }

    public function test_account_show_reports_null_tenant_name_for_platform_staff(): void
    {
        $staff = User::create(['tenant_id' => null, 'name' => 'Amin', 'email' => 'admin@zecocm.test', 'password' => bcrypt('password'), 'platform_role' => 'admin']);
        Sanctum::actingAs($staff);

        $this->getJson('/api/account')->assertOk()->assertJsonPath('tenant_name', null);
    }
}
