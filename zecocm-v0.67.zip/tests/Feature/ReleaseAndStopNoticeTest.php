<?php

namespace Tests\Feature;

use App\Domain\Payment\ReleaseCoverage;
use App\Domain\Payment\StopNoticeWithholding;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

/**
 * A5: releases and stop payment notices.
 *
 * The two halves of the same file drawer, and the pair that must never be
 * netted against each other. A release reduces exposure; a stop notice freezes
 * money. An owner who treats a signed release as an answer to a served notice
 * pays twice.
 */
class ReleaseAndStopNoticeTest extends TestCase
{
    private function release(array $overrides = []): array
    {
        return array_merge([
            'claimant_name' => 'Valley Electric',
            'form_type' => 'unconditional_progress',
            'through_date' => '2026-07-31',
            'document_on_file' => true,
            'exceptions_stated' => false,
            'payment_cleared_on' => null,
        ], $overrides);
    }

    public function test_a_release_through_july_does_not_cover_august_work(): void
    {
        // The one that gets missed, because the dollar figure usually looks right.
        $state = ReleaseCoverage::stateOf($this->release(), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::DOES_NOT_REACH_PERIOD, $state['state']);
        $this->assertStringContainsString('whatever amount appears on its face', $state['message']);
    }

    public function test_a_conditional_release_is_not_a_release_until_the_payment_clears(): void
    {
        $state = ReleaseCoverage::stateOf($this->release([
            'form_type' => 'conditional_progress', 'through_date' => '2026-08-31',
        ]), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::CONDITIONAL_UNSATISFIED, $state['state']);
        $this->assertSame('Civil Code s. 8132', $state['citation']);

        // And it becomes one when the clearing is recorded - not before.
        $cleared = ReleaseCoverage::stateOf($this->release([
            'form_type' => 'conditional_progress', 'through_date' => '2026-08-31',
            'payment_cleared_on' => '2026-09-15',
        ]), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::EFFECTIVE, $cleared['state']);
    }

    public function test_a_release_nobody_has_the_paper_for_is_not_a_release(): void
    {
        $state = ReleaseCoverage::stateOf($this->release(['document_on_file' => false]),
            new DateTimeImmutable('2026-07-31'));

        $this->assertSame(ReleaseCoverage::NOT_ON_FILE, $state['state']);
    }

    public function test_a_release_with_no_through_date_covers_nothing_that_can_be_shown(): void
    {
        // Assuming it covers the period it was filed under is the assumption
        // that fails in a dispute.
        $state = ReleaseCoverage::stateOf($this->release(['through_date' => null]),
            new DateTimeImmutable('2026-07-31'));

        $this->assertSame(ReleaseCoverage::NO_THROUGH_DATE, $state['state']);
    }

    public function test_exceptions_written_on_the_form_are_reported_as_not_released(): void
    {
        $findings = ReleaseCoverage::findings([
            $this->release(['exceptions_stated' => true, 'exceptions' => 'Disputed backcharge $12,400']),
        ], ['period_end' => '2026-07-31', 'required_claimants' => ['Valley Electric']]);

        // Unstructured by default, and the code says so: the system will not
        // answer whether any PARTICULAR item survived the release.
        $codes = array_column($findings, 'code');
        $this->assertContains('release_exceptions_unstructured', $codes);
        $excepted = $findings[array_search('release_exceptions_unstructured', $codes, true)];
        $this->assertStringContainsString('Disputed backcharge $12,400', $excepted['message']);
        $this->assertStringContainsString('cannot say whether any PARTICULAR', $excepted['message']);

        // Once a person itemises them, it reports them as exceptions proper.
        $itemised = ReleaseCoverage::findings([
            $this->release(['exceptions_stated' => true, 'exceptions_structured' => true,
                'exceptions' => 'Disputed backcharge $12,400']),
        ], ['period_end' => '2026-07-31', 'required_claimants' => ['Valley Electric']]);
        $this->assertContains('release_states_exceptions', array_column($itemised, 'code'));
    }

    public function test_a_claimant_with_no_release_at_all_is_reported(): void
    {
        $findings = ReleaseCoverage::findings([], [
            'period_end' => '2026-08-31', 'required_claimants' => ['Valley Electric'],
        ]);

        $this->assertSame('release_absent', $findings[0]['code']);
        $this->assertSame('Valley Electric', $findings[0]['claimant']);
    }

    public function test_a_release_problem_withholds_and_never_returns_the_request(): void
    {
        // Calling this returnable would start the seven-day clock under Public
        // Contract Code s. 20104.50 over the owner's own file-keeping.
        $findings = ReleaseCoverage::findings([], [
            'period_end' => '2026-08-31', 'required_claimants' => ['Valley Electric'],
        ]);

        $this->assertSame('withhold', $findings[0]['severity']);
        $this->assertSame('internal', $findings[0]['gate']);
    }

    public function test_money_already_paid_wants_an_unconditional_release_behind_it(): void
    {
        $findings = ReleaseCoverage::findings([
            $this->release(['form_type' => 'conditional_progress', 'through_date' => '2026-08-31']),
        ], [
            'period_end' => '2026-08-31', 'prior_period_end' => '2026-07-31',
            'required_claimants' => ['Valley Electric'],
        ]);

        $codes = array_column($findings, 'code');
        $this->assertContains('unconditional_release_missing_for_paid_period', $codes);
    }

    public function test_final_payment_wants_the_final_form_not_the_progress_form(): void
    {
        $findings = ReleaseCoverage::findings([
            $this->release(['through_date' => '2026-08-31']),
        ], [
            'period_end' => '2026-08-31', 'payment_is_final' => true,
            'required_claimants' => ['Valley Electric'],
        ]);

        $codes = array_column($findings, 'code');
        $this->assertContains('final_release_missing', $codes);
        $final = $findings[array_search('final_release_missing', $codes, true)];
        $this->assertSame('Civil Code s. 8138', $final['citation']);
    }

    // ---- stop payment notices ------------------------------------------------

    public function test_the_statutory_withholding_is_the_claim_plus_twenty_five_per_cent(): void
    {
        $this->assertSame(125_000_00, StopNoticeWithholding::amountFor(100_000_00));
    }

    public function test_the_withholding_rounds_up_because_under_withholding_is_the_owners_exposure(): void
    {
        // 125% of $0.03 is $0.0375. Rounding to $0.03 leaves the owner short.
        $this->assertSame(4, StopNoticeWithholding::amountFor(3));
        $this->assertSame(0, StopNoticeWithholding::amountFor(0));
        $this->assertSame(0, StopNoticeWithholding::amountFor(-500));
    }

    public function test_a_served_notice_freezes_money_and_says_so_in_dollars(): void
    {
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => true,
        ]]);

        $this->assertSame(50_000_00, $result['total_withheld_cents']);

        $codes = array_column($result['findings'], 'code');
        $this->assertContains('stop_notice_withholding_required', $codes);
        $required = $result['findings'][array_search('stop_notice_withholding_required', $codes, true)];
        $this->assertSame('Civil Code s. 9358', $required['citation']);
        $this->assertStringContainsString('remains owed to the contractor', $required['message']);
    }

    public function test_a_missing_preliminary_notice_is_flagged_and_the_money_stays_frozen(): void
    {
        // The refusal that matters. Software does not get to decide a claim is
        // bad and hand the money over.
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => false,
        ]]);

        $codes = array_column($result['findings'], 'code');
        $this->assertContains('stop_notice_prerequisite_not_evidenced', $codes);
        $this->assertSame(50_000_00, $result['total_withheld_cents']);
        $this->assertSame('preliminary_notice_not_evidenced', $result['active'][0]['flag']);
    }

    public function test_a_notice_marked_bonded_around_without_the_bond_still_freezes_the_money(): void
    {
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'bonded_around', 'release_bond_on_file' => false,
        ]]);

        $this->assertSame(50_000_00, $result['total_withheld_cents']);
        $this->assertSame('stop_notice_release_bond_not_on_file', $result['findings'][0]['code']);
        $this->assertSame('Civil Code s. 9364', $result['findings'][0]['citation']);
    }

    public function test_a_bond_actually_on_file_frees_the_funds(): void
    {
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'status' => 'bonded_around', 'release_bond_on_file' => true, 'served_on' => '2026-08-10',
        ]]);

        $this->assertSame(0, $result['total_withheld_cents']);
        $this->assertSame([], $result['active']);
    }

    public function test_a_notice_with_no_amount_recorded_is_not_silently_zero(): void
    {
        // The obligation was created by service, not by our data entry.
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 0,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => true,
        ]]);

        $this->assertSame('stop_notice_amount_not_recorded', $result['findings'][0]['code']);
        $this->assertSame('amount_unknown', $result['active'][0]['flag']);
    }

    public function test_released_and_withdrawn_notices_stop_freezing_money(): void
    {
        $result = StopNoticeWithholding::required([
            ['claimant_name' => 'A', 'claimed_amount_cents' => 10_000_00, 'status' => 'released', 'served_on' => '2026-01-01'],
            ['claimant_name' => 'B', 'claimed_amount_cents' => 10_000_00, 'status' => 'withdrawn', 'served_on' => '2026-01-01'],
        ]);

        $this->assertSame(0, $result['total_withheld_cents']);
        $this->assertSame([], $result['findings']);
    }

    public function test_the_earned_amount_is_never_reduced_only_the_payable_amount(): void
    {
        // The contractor is still owed the whole figure. A system that quietly
        // lowers the earned amount has misstated the contract.
        $payable = StopNoticeWithholding::payable(100_000_00, 50_000_00);

        $this->assertSame(100_000_00, $payable['earned_cents']);
        $this->assertSame(50_000_00, $payable['payable_cents']);
        $this->assertFalse($payable['fully_frozen']);
    }

    public function test_notices_exceeding_the_payment_freeze_it_entirely(): void
    {
        $payable = StopNoticeWithholding::payable(40_000_00, 125_000_00);

        $this->assertSame(0, $payable['payable_cents']);
        $this->assertTrue($payable['fully_frozen']);
        $this->assertSame(40_000_00, $payable['earned_cents']);
    }

    public function test_a_release_is_never_netted_against_a_stop_notice(): void
    {
        // Belt and braces on the invariant: the release side and the notice side
        // do not share a total, and neither function has any knowledge of the
        // other's figures. If this ever changes, this test is where it shows.
        $releaseFindings = ReleaseCoverage::findings([
            $this->release(['through_date' => '2026-08-31']),
        ], ['period_end' => '2026-08-31', 'required_claimants' => ['Sierra Rebar', 'Valley Electric']]);

        $notice = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => true,
        ]]);

        // Valley Electric's release does nothing whatsoever to Sierra Rebar's notice.
        $this->assertSame(50_000_00, $notice['total_withheld_cents']);
        $this->assertContains('release_absent', array_column($releaseFindings, 'code'));
    }

    // ---- the four defects Codex found an hour after A5 shipped ---------------

    public function test_a_conditional_release_is_satisfied_only_up_to_what_actually_cleared(): void
    {
        // The statutory conditional form is effective on receipt of THE PAYMENT
        // IDENTIFIED IN IT. A release naming $100,000 against which $80,000
        // cleared releases $80,000 and manufactures nothing.
        $state = ReleaseCoverage::stateOf($this->release([
            'form_type' => 'conditional_progress', 'through_date' => '2026-08-31',
            'amount_cents' => 100_000_00,
            'payment_cleared_on' => '2026-09-15', 'payment_cleared_amount_cents' => 80_000_00,
        ]), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::CONDITIONAL_UNDERPAID, $state['state']);
        $this->assertStringContainsString('$20,000.00 remains unreleased', $state['message']);
    }

    public function test_a_conditional_release_paid_in_full_is_effective(): void
    {
        $state = ReleaseCoverage::stateOf($this->release([
            'form_type' => 'conditional_progress', 'through_date' => '2026-08-31',
            'amount_cents' => 100_000_00,
            'payment_cleared_on' => '2026-09-15', 'payment_cleared_amount_cents' => 100_000_00,
        ]), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::EFFECTIVE, $state['state']);
    }

    public function test_a_cleared_amount_of_zero_is_not_the_same_as_no_record_of_clearing(): void
    {
        // Nullable on purpose. Zero says the payment cleared for nothing, which
        // releases nothing; null says nobody recorded it.
        $zero = ReleaseCoverage::stateOf($this->release([
            'form_type' => 'conditional_progress', 'through_date' => '2026-08-31',
            'amount_cents' => 50_000_00, 'payment_cleared_on' => '2026-09-15',
            'payment_cleared_amount_cents' => 0,
        ]), new DateTimeImmutable('2026-08-31'));

        $this->assertSame(ReleaseCoverage::CONDITIONAL_UNDERPAID, $zero['state']);
    }

    public function test_sending_a_stop_notice_is_not_serving_it(): void
    {
        // Emailing the project inspector is evidence that an email was sent.
        // The software records it and refuses to conclude statutory service.
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => true,
            'service_state' => 'sent', 'served_to_role' => 'project inspector',
        ]]);

        $codes = array_column($result['findings'], 'code');
        $this->assertContains('stop_notice_service_unresolved', $codes);
        $finding = $result['findings'][array_search('stop_notice_service_unresolved', $codes, true)];
        $this->assertStringContainsString('Sending is not serving', $finding['message']);
        $this->assertStringContainsString('project inspector', $finding['message']);

        // And unresolved service never releases the money.
        $this->assertSame(50_000_00, $result['total_withheld_cents']);
    }

    public function test_confirmed_service_stops_the_service_finding(): void
    {
        $result = StopNoticeWithholding::required([[
            'claimant_name' => 'Sierra Rebar', 'claimed_amount_cents' => 40_000_00,
            'served_on' => '2026-08-10', 'status' => 'open', 'preliminary_notice_on_file' => true,
            'service_state' => 'statutory_recipient_verified',
            'service_effectiveness' => StopNoticeWithholding::SERVICE_CONFIRMED,
        ]]);

        $this->assertNotContains('stop_notice_service_unresolved', array_column($result['findings'], 'code'));
        $this->assertSame(50_000_00, $result['total_withheld_cents']);
    }
}
