<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\DocumentFolder;
use App\Models\KnowledgeSource;
use App\Models\MediaItem;
use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleVersion;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Dedicated adversarial ("what if") pass on every upload surface: Document
 * Library documents/versions, Knowledge source uploads, Schedule/CPM version
 * uploads, and Evidence/photo media uploads. Two real bugs were found and
 * fixed here, each with its own class-doc explaining what was wrong:
 *
 *   1. DocumentLibraryController's routes (folders/documents/versions/
 *      download/index) carried no `capability:documents` licence gate at
 *      all, even though the "Documents" nav item (NAV_TO_CAP docs =>
 *      documents in app.html) is hidden client-side for an unlicensed
 *      tenant. An authenticated user of an unlicensed tenant could still
 *      upload, list, and download through the Document Library API
 *      directly - the exact "phantom endpoint" bug class
 *      PhantomEndpointLicenseGateTest already covers for eleven other
 *      capabilities, just missed for this controller. Fixed in
 *      routes/api.php by moving those five routes inside the existing
 *      `capability:documents` group.
 *
 *   2. ScheduleIngest had its own private safeOriginalName() that stripped
 *      control characters but NOT bidirectional-override characters
 *      (U+202A-U+202E, U+2066-U+2069) - the exact class of character
 *      SecureUploadGate::safeName() strips specifically because it is how
 *      'evil{RLO}fdp.exe' is made to display as 'evil.exe' spelled
 *      backwards or as an unrelated extension in a filename picker. Every
 *      other upload surface (documents, knowledge, media) already routed
 *      through SecureUploadGate::safeName(); the schedule upload path had
 *      quietly drifted onto its own weaker copy. Fixed by deleting
 *      ScheduleIngest::safeOriginalName() and calling
 *      SecureUploadGate::safeName() directly, same as every other surface.
 *
 * Everything else exercised below (content-based type detection surviving
 * an extension spoof on surfaces not covered by SecureUploadGateEnforcedTest,
 * path-traversal and null-byte filenames, cross-project folder_id/
 * parent_version_id references, size-ceiling enforcement, zero-byte files,
 * and malformed/incomplete multipart bodies) held correctly already and is
 * captured here as regression coverage.
 */
class AdversarialUploadTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'app.provenance_key' => 'test-provenance-signing-key',
            'schedule.require_malware_scan' => false,
            'queue.default' => 'sync',
        ]);
        Storage::fake('local');

        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'documents', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'photos', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'schedule_intelligence', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function realPdf(string $name = 'file.pdf'): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'adv-up');
        file_put_contents($path, "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF");

        return new UploadedFile($path, $name, 'application/pdf', null, true);
    }

    private function phpDisguisedAsImage(string $name): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'adv-up');
        file_put_contents($path, "<?php echo 'pwned '.shell_exec(\$_GET['c']); ?>");

        return new UploadedFile($path, $name, 'image/jpeg', null, true);
    }

    private function scheduleCsv(string $filename, int $paddingBytes = 0): UploadedFile
    {
        $csv = implode("\n", [
            'activity_code,name,duration_minutes,planned_start,planned_finish,predecessors,calendar',
            'A100,Mobilize,480,2026-08-24 08:00,2026-08-24 17:00,,Standard',
            'A200,Excavate,600,2026-08-25 08:00,2026-08-27 17:00,A100 FS,Standard',
        ]);
        if ($paddingBytes > 0) {
            // Padding lands in a comment-ish trailing column value on an
            // unused header would break the parser, so pad via a narrative
            // file suffix the parser never reads: extra blank trailing
            // newlines are cheap, deterministic byte filler.
            $csv .= "\n".str_repeat("\n", 0).str_repeat('#', $paddingBytes);
        }

        return UploadedFile::fake()->createWithContent($filename, $csv);
    }

    // ============================================================
    // BUG #1 regression: Document Library phantom endpoint
    // ============================================================

    public function test_document_library_upload_is_refused_without_the_documents_license(): void
    {
        $unlicensed = Tenant::create(['name' => 'No License Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $unlicensedUser = User::create(['tenant_id' => $unlicensed->id, 'name' => 'Unlicensed',
            'email' => 'unlicensed@nolicense.test', 'password' => bcrypt('password')]);
        TenantContext::set($unlicensed->id);
        $unlicensedProject = Project::create(['number' => 'U-1', 'name' => 'Unlicensed Project', 'sector' => 'public',
            'owner_name' => 'x', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $unlicensedProject->id, 'user_id' => $unlicensedUser->id,
            'organization' => 'No License Co', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($unlicensedUser);

        $res = $this->postJson('/api/document-library/documents', [
            'project_id' => $unlicensedProject->id,
            'file' => $this->realPdf(),
        ]);

        $res->assertStatus(402);
        $this->assertSame(0, DB::table('knowledge_sources')->count());
    }

    public function test_document_library_index_and_folder_creation_are_also_refused_without_the_documents_license(): void
    {
        $unlicensed = Tenant::create(['name' => 'No List Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $unlicensedUser = User::create(['tenant_id' => $unlicensed->id, 'name' => 'Unlicensed',
            'email' => 'unlicensed2@nolicense.test', 'password' => bcrypt('password')]);
        TenantContext::set($unlicensed->id);
        $unlicensedProject = Project::create(['number' => 'U-2', 'name' => 'Unlicensed Project 2', 'sector' => 'public',
            'owner_name' => 'x', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $unlicensedProject->id, 'user_id' => $unlicensedUser->id,
            'organization' => 'No List Co', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($unlicensedUser);

        $this->getJson('/api/document-library?project_id='.$unlicensedProject->id)->assertStatus(402);
        $this->postJson('/api/document-library/folders', ['project_id' => $unlicensedProject->id, 'name' => 'x'])
            ->assertStatus(402);
    }

    public function test_document_library_upload_reaches_its_own_validation_once_licensed(): void
    {
        // The positive control proving the 402 above is really the licence
        // gate, not a broken route: the already-licensed tenant from setUp()
        // succeeds normally.
        $res = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf('spec.pdf'),
        ], ['Accept' => 'application/json']);

        $res->assertCreated();
    }

    // ============================================================
    // BUG #2 regression: schedule upload filename RTL-override stripping
    // ============================================================

    public function test_schedule_upload_strips_bidirectional_override_characters_from_the_stored_filename(): void
    {
        // U+202E (RIGHT-TO-LEFT OVERRIDE) makes everything after it render
        // reversed - the classic "invoice{RLO}fdp.exe" displaying as
        // "invoice.exe" trick. The real (last) extension stays '.csv' so the
        // upload is admitted; what this proves is that the override
        // character itself never survives into the stored display name.
        $evilName = "base\u{202E}line.csv";
        $file = $this->scheduleCsv($evilName);

        $res = $this->post('/api/schedule-versions', [
            'project_id' => $this->project->id,
            'file' => $file,
            'kind' => 'baseline',
            'label' => 'Baseline',
            'data_date' => '2026-08-24',
        ], ['Accept' => 'application/json']);

        $res->assertCreated();
        $versionId = $res->json('id');
        TenantContext::set($this->tenant->id);
        $version = ScheduleVersion::query()->findOrFail($versionId);
        $mediaId = $version->source_file_media_id;
        $media = MediaItem::withoutGlobalScopes()->findOrFail($mediaId);
        TenantContext::clear();

        $this->assertStringNotContainsString("\u{202E}", $media->original_name);
        $this->assertStringNotContainsString("\u{202A}", $media->original_name);
        $this->assertStringNotContainsString("\u{202D}", $media->original_name);
    }

    // ============================================================
    // Content-based type detection surviving an extension spoof, on
    // surfaces SecureUploadGateEnforcedTest does not already cover.
    // ============================================================

    public function test_knowledge_source_upload_rejects_php_content_disguised_as_a_jpeg(): void
    {
        $before = DB::table('knowledge_sources')->count();

        $res = $this->post('/api/knowledge/sources', [
            'project_id' => $this->project->id,
            'collection' => 'project',
            'corpus' => 'project_specs',
            'title' => 'Spoofed image',
            'source_type' => 'specification',
            'authority_level' => 'project_contract',
            'file' => $this->phpDisguisedAsImage('sitephoto.jpg'),
        ], ['Accept' => 'application/json']);

        $res->assertStatus(422);
        $this->assertSame($before, DB::table('knowledge_sources')->count());
    }

    public function test_media_upload_rejects_php_content_disguised_as_a_jpeg(): void
    {
        $before = MediaItem::withoutGlobalScopes()->count();

        $res = $this->postJson('/api/media', [
            'project_id' => $this->project->id,
            'file' => $this->phpDisguisedAsImage('field-photo.jpg'),
        ]);

        $res->assertStatus(422);
        $this->assertSame($before, MediaItem::withoutGlobalScopes()->count());
    }

    // ============================================================
    // Malformed / adversarial filenames
    // ============================================================

    public function test_document_library_upload_sanitizes_a_path_traversal_filename(): void
    {
        $res = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf('../../../../etc/passwd.pdf'),
        ], ['Accept' => 'application/json']);

        $res->assertCreated();
        $document = KnowledgeSource::withoutGlobalScopes()->latest('id')->first();
        $this->assertNotNull($document);
        $this->assertSame('passwd.pdf', $document->original_filename);
        $this->assertStringNotContainsString('..', $document->original_filename);
        $this->assertStringNotContainsString('/', $document->original_filename);
    }

    public function test_document_library_upload_truncates_an_extremely_long_filename(): void
    {
        // Long enough to trigger SecureUploadGate::safeName()'s 240-char
        // truncation, short enough that the '.pdf' extension survives the
        // truncation (it comes off the front, so the file must stay under
        // the 240 cap to keep its extension) and the upload is admitted.
        $longName = str_repeat('a', 230).'.pdf';
        $this->assertGreaterThan(230, strlen($longName));

        $res = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf($longName),
        ], ['Accept' => 'application/json']);

        $res->assertCreated();
        $document = KnowledgeSource::withoutGlobalScopes()->latest('id')->first();
        $this->assertLessThanOrEqual(240, strlen($document->original_filename));
        $this->assertStringEndsWith('.pdf', $document->original_filename);

        // A name so long it loses its extension under the 240-char cap must
        // still fail safely (a 422, never a 500) rather than crash.
        $unrecoverableName = str_repeat('b', 5000).'.pdf';
        $overflow = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf($unrecoverableName),
        ], ['Accept' => 'application/json']);
        $overflow->assertStatus(422);
    }

    public function test_media_upload_sanitizes_null_bytes_and_control_characters_in_filename(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'adv-up');
        file_put_contents($path, "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF");
        $file = new UploadedFile($path, "evidence\x00\x01\x02.pdf", 'application/pdf', null, true);

        $res = $this->postJson('/api/media', [
            'project_id' => $this->project->id,
            'file' => $file,
        ]);

        $res->assertCreated();
        $item = MediaItem::withoutGlobalScopes()->latest('id')->first();
        $this->assertNotNull($item);
        $this->assertDoesNotMatchRegularExpression('/[\x00-\x1F]/', $item->original_name);
    }

    // ============================================================
    // Cross-project references reachable only through an upload endpoint
    // ============================================================

    public function test_document_library_upload_rejects_a_folder_id_from_another_project(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['number' => 'P-999', 'name' => 'Other Project', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'org_structure' => [], 'contract_clocks' => []]);
        $foreignFolder = DocumentFolder::create(['project_id' => $otherProject->id, 'name' => 'Foreign Folder',
            'created_by' => $this->user->id]);
        TenantContext::clear();

        $res = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'folder_id' => $foreignFolder->id,
            'file' => $this->realPdf(),
        ], ['Accept' => 'application/json']);

        $res->assertStatus(404);
        $this->assertSame(0, DB::table('knowledge_sources')->count());
    }

    public function test_schedule_upload_rejects_a_parent_version_id_from_another_project(): void
    {
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['number' => 'P-998', 'name' => 'Other Schedule Project', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $otherProject->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();

        $foreignVersionId = (int) $this->post('/api/schedule-versions', [
            'project_id' => $otherProject->id,
            'file' => $this->scheduleCsv('foreign-baseline.csv'),
            'kind' => 'baseline',
            'label' => 'Foreign Baseline',
            'data_date' => '2026-08-24',
        ], ['Accept' => 'application/json'])->assertCreated()->json('id');

        $res = $this->post('/api/schedule-versions', [
            'project_id' => $this->project->id,
            'parent_version_id' => $foreignVersionId,
            'file' => $this->scheduleCsv('update.csv'),
            'kind' => 'update',
            'label' => 'Update',
            'data_date' => '2026-08-25',
        ], ['Accept' => 'application/json']);

        $res->assertStatus(404);
    }

    // ============================================================
    // Size ceiling
    // ============================================================

    public function test_schedule_upload_enforces_the_configured_size_ceiling(): void
    {
        config(['schedule.max_upload_kilobytes' => 2]); // 2 KB ceiling for this test

        $withinCeiling = $this->post('/api/schedule-versions', [
            'project_id' => $this->project->id,
            'file' => $this->scheduleCsv('small.csv'),
            'kind' => 'baseline',
            'label' => 'Small',
            'data_date' => '2026-08-24',
        ], ['Accept' => 'application/json']);
        $withinCeiling->assertCreated();

        $overCeiling = $this->post('/api/schedule-versions', [
            'project_id' => $this->project->id,
            'file' => $this->scheduleCsv('big.csv', paddingBytes: 4000),
            'kind' => 'update',
            'label' => 'Too Big',
            'data_date' => '2026-08-25',
        ], ['Accept' => 'application/json']);
        $overCeiling->assertStatus(422);
        $overCeiling->assertJsonValidationErrors('file');
    }

    // ============================================================
    // Zero-byte files and malformed/incomplete request bodies
    // ============================================================

    public function test_media_upload_rejects_a_zero_byte_file(): void
    {
        // UploadedFile::fake()->create() reports a MIME type guessed from
        // the extension rather than sniffing real (empty) bytes, which
        // would make this assert the wrong thing for a content-based check -
        // a genuinely empty file, constructed the same way
        // SecureUploadGateEnforcedTest builds its real-content fixtures, so
        // getMimeType() actually reads the zero bytes on disk.
        $path = tempnam(sys_get_temp_dir(), 'adv-up');
        file_put_contents($path, '');
        $file = new UploadedFile($path, 'empty.jpg', 'image/jpeg', null, true);
        $before = MediaItem::withoutGlobalScopes()->count();

        $res = $this->postJson('/api/media', [
            'project_id' => $this->project->id,
            'file' => $file,
        ]);

        $res->assertStatus(422);
        $this->assertSame($before, MediaItem::withoutGlobalScopes()->count());
    }

    public function test_media_upload_missing_project_id_returns_422_not_500(): void
    {
        $res = $this->postJson('/api/media', [
            'file' => $this->realPdf('no-project.pdf'),
        ]);

        $res->assertStatus(422);
        $res->assertJsonValidationErrors('project_id');
    }

    public function test_document_library_version_upload_missing_file_returns_422_not_500(): void
    {
        $documentId = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf('base.pdf'),
        ], ['Accept' => 'application/json'])->assertCreated()->json('document.id');

        $res = $this->postJson("/api/document-library/documents/{$documentId}/versions", [
            'revision' => 'Rev 1',
        ]);

        $res->assertStatus(422);
        $res->assertJsonValidationErrors('file');
    }
}
