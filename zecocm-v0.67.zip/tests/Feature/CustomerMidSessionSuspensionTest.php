<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * CustomerStatusTest already proves a suspended tenant's users cannot LOG IN.
 * That is not the same guarantee as cutting off a session that was already
 * open when the suspension happened - a Sanctum token issued before
 * suspension has no expiry tied to tenant status, so it keeps being a valid
 * token for every request after that unless the tenant is re-checked on
 * every request, not just at login.
 *
 * Adversarial "what if" finding: EstablishTenantContext (the middleware that
 * runs on every authenticated tenant-context request) never checked tenant
 * status at all for the customer branch - it set TenantContext from
 * $user->tenant_id unconditionally. A user holding a token issued while
 * their tenant was active could keep reading and writing that tenant's data
 * indefinitely after an admin suspended the account, exactly the access the
 * login-time check exists to remove. Same gap covered a tenant deleted
 * mid-session (the row simply no longer exists to act as).
 */
class CustomerMidSessionSuspensionTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function tenantWithUser(string $status = 'active'): array
    {
        $tenant = Tenant::create(['name' => 'Testco', 'type' => 'Contractor', 'status' => $status,
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'Casey', 'email' => 'casey@testco.test', 'password' => bcrypt('secret123')]);

        return [$tenant, $user];
    }

    /** A live token stops working the moment the tenant behind it is suspended. */
    public function test_a_valid_token_stops_working_once_the_tenant_is_suspended_mid_session(): void
    {
        [$tenant, $user] = $this->tenantWithUser('active');
        Sanctum::actingAs($user);

        // Sanity: the session works fine while the tenant is active.
        $this->getJson('/api/projects')->assertOk();

        $tenant->update(['status' => 'suspended']);

        $response = $this->getJson('/api/projects');
        $response->assertStatus(403);

        // Not just reads - a write attempt with the same still-valid token
        // must be refused the same way.
        $this->postJson('/api/projects', ['name' => 'Sneaky project'])->assertStatus(403);
    }

    /** Reactivating the tenant restores the same token's access, no re-login required. */
    public function test_reactivating_the_tenant_restores_the_existing_tokens_access(): void
    {
        [$tenant, $user] = $this->tenantWithUser('suspended');
        Sanctum::actingAs($user);

        $this->getJson('/api/projects')->assertStatus(403);

        $tenant->update(['status' => 'active']);

        $this->getJson('/api/projects')->assertOk();
    }

    /**
     * A user record pointing at a tenant id nothing backs (the real-world
     * case: the tenant row was deleted mid-session) must fail closed, never
     * fall through to an unscoped or all-tenant query. Exercised directly
     * against the middleware rather than over HTTP: the users/tenants FK
     * constraint (rightly) prevents a real request from ever reaching this
     * state through normal writes, and SQLite (this suite's test driver)
     * cannot toggle FK enforcement inside RefreshDatabase's wrapping
     * transaction to fabricate it at the database layer either - but the
     * middleware itself must not assume the foreign key is the only thing
     * standing between it and a dangling tenant_id.
     */
    public function test_a_dangling_tenant_id_fails_closed_in_the_middleware(): void
    {
        $user = new User(['name' => 'Casey', 'email' => 'casey@ghostco.test']);
        $user->id = 999001;
        $user->tenant_id = 999002; // no Tenant row with this id exists
        $user->exists = true;

        $middleware = new \App\Http\Middleware\EstablishTenantContext;
        $request = \Illuminate\Http\Request::create('/api/projects', 'GET');
        $request->setUserResolver(fn () => $user);

        try {
            $middleware->handle($request, fn ($req) => response('should not reach here'));
            $this->fail('Expected the middleware to abort for a dangling tenant_id.');
        } catch (\Symfony\Component\HttpKernel\Exception\HttpException $e) {
            $this->assertSame(403, $e->getStatusCode());
        }
    }
}
