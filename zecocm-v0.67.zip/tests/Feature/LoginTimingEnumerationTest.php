<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

/**
 * Adversarial "what if" finding: AuthController::login only ran Hash::check() when a user row
 * was found for the submitted email - `$user === null || ! Hash::check(...)` short-circuits
 * before the (deliberately slow, bcrypt) hash comparison for an email that doesn't exist. Both
 * outcomes returned the same "Invalid credentials." message, but a nonexistent-email attempt
 * returned in a fraction of the time a wrong-password attempt for a real account took - a timing
 * side channel that lets an attacker enumerate which emails have accounts on the platform without
 * ever seeing a different response body.
 *
 * Fixed by always running Hash::check() - against a fixed dummy bcrypt hash when no user matches
 * - so the bcrypt work (and therefore the response time) is the same whether the email exists or
 * not.
 */
class LoginTimingEnumerationTest extends TestCase
{
    use RefreshDatabase;

    public function test_response_body_is_identical_for_unknown_email_and_wrong_password(): void
    {
        $user = $this->realUser();

        $unknownEmail = $this->postJson('/api/login', [
            'email' => 'nobody-here@example.test',
            'password' => 'whatever-guess-1',
        ]);
        $wrongPassword = $this->postJson('/api/login', [
            'email' => $user->email,
            'password' => 'definitely-not-it',
        ]);

        $unknownEmail->assertStatus(422)->assertExactJson(['message' => 'Invalid credentials.']);
        $wrongPassword->assertStatus(422)->assertExactJson(['message' => 'Invalid credentials.']);
    }

    /**
     * A nonexistent email must cost real bcrypt work too, not a near-instant short circuit. We
     * can't assert exact timing equality in CI, but we can assert the unknown-email path is not
     * suspiciously fast compared to the real-hash path - averaged over several trials to smooth
     * out noise, with a generous (10x) margin so this never flakes on a loaded CI box.
     */
    public function test_unknown_email_attempt_pays_the_same_bcrypt_cost_as_a_real_account(): void
    {
        $user = $this->realUser();
        $trials = 5;

        $knownElapsed = $this->timeLoginAttempts($trials, $user->email, 'definitely-not-it');
        $unknownElapsed = $this->timeLoginAttempts($trials, 'nobody-here@example.test', 'definitely-not-it');

        $this->assertGreaterThan(
            $knownElapsed / 10,
            $unknownElapsed,
            'A login attempt against an email with no account returned far faster than one against '.
            'a real account with a wrong password - that gap is a timing side channel an attacker '.
            'can use to enumerate valid emails.'
        );
    }

    private function timeLoginAttempts(int $trials, string $email, string $password): float
    {
        $start = microtime(true);
        for ($i = 0; $i < $trials; $i++) {
            $this->postJson('/api/login', ['email' => $email, 'password' => $password])
                ->assertStatus(422);
        }

        return microtime(true) - $start;
    }

    private function realUser(): User
    {
        $tenant = Tenant::create([
            'name' => 'Timing Co',
            'type' => 'contractor',
            'entitlements' => Tenant::defaultEntitlements('contractor'),
            'status' => 'active',
        ]);

        return User::create([
            'tenant_id' => $tenant->id,
            'name' => 'Real User',
            'email' => 'real-user@example.test',
            'password' => Hash::make('SomeRealPassword!23'),
            'platform_role' => null,
            'platform_permissions' => [],
        ]);
    }
}
