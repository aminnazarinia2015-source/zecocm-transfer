<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ScheduleIntelligenceFlowTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'app.provenance_key' => 'test-provenance-signing-key',
            'schedule.require_malware_scan' => false,
            'queue.default' => 'sync',
        ]);
        Storage::fake(config('filesystems.default'));

        $this->tenant = Tenant::create(['name' => 'Alpha CM', 'type' => 'CM firm', 'entitlements' => Tenant::defaultEntitlements('CM firm')]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Scheduler', 'email' => 'scheduler@example.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create([
            'number' => 'P-100', 'name' => 'Civic Works', 'sector' => 'public', 'owner_name' => 'City of Alpha',
            'state' => 'CA', 'funding_source' => 'local', 'contract_clocks' => [], 'org_structure' => [],
        ]);
        Membership::create([
            'project_id' => $this->project->id,
            'user_id' => $this->user->id,
            'organization' => 'Alpha CM',
            'seat' => 'project_manager',
            'capabilities' => ['*' => true],
        ]);
        // The account is licensed for schedule intelligence - the server-side gate
        // refuses the whole capability otherwise (402), which is its job.
        (new CapabilityLicense)->grant($this->tenant, 'schedule_intelligence', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_upload_lineage_async_analysis_deltas_and_append_only_disposition(): void
    {
        $baseline = $this->upload('Baseline', 'baseline', null, 480);
        $update = $this->upload('Update 01', 'update', $baseline, 960);

        $analysis = $this->withHeader('Idempotency-Key', 'pair-100-01')->postJson('/api/schedule/analyze', [
            'project_id' => $this->project->id,
            'from_version_id' => $baseline,
            'to_version_id' => $update,
        ])->assertStatus(202)->assertJsonPath('status', 'completed');

        self::assertNotEmpty($analysis->json('deltas'));
        $this->getJson('/api/schedule/deltas?project_id='.$this->project->id.'&from_version_id='.$baseline.'&to_version_id='.$update)
            ->assertOk()->assertJsonPath('analysis_id', $analysis->json('id'));

        $this->postJson('/api/schedule-versions/'.$update.'/accept', ['note' => 'Human review completed.'])
            ->assertOk()->assertJsonPath('version.review_status', 'accepted');
        $this->assertDatabaseCount('schedule_version_events', 3);

        TenantContext::set($this->tenant->id);
        $activity = ScheduleActivity::query()->where('schedule_version_id', $update)->firstOrFail();
        $this->expectException(\LogicException::class);
        $activity->update(['name' => 'Attempted overwrite']);
    }

    public function test_role_input_is_rejected_idempotency_is_bound_and_sources_are_authorization_filtered(): void
    {
        $baseline = $this->upload('Baseline', 'baseline', null, 480);
        $update = $this->upload('Update 01', 'update', $baseline, 600);

        $this->getJson('/api/schedule-versions?project_id='.$this->project->id.'&role=owner')->assertStatus(422);
        $this->withHeader('Idempotency-Key', 'fixed-key')->postJson('/api/schedule/analyze', [
            'project_id' => $this->project->id, 'from_version_id' => $baseline, 'to_version_id' => $update,
        ])->assertStatus(202);
        $this->withHeader('Idempotency-Key', 'fixed-key')->postJson('/api/schedule/analyze', [
            'project_id' => $this->project->id, 'from_version_id' => $update, 'to_version_id' => $baseline,
        ])->assertStatus(409);

        TenantContext::set($this->tenant->id);
        Membership::query()->where('user_id', $this->user->id)->update(['capabilities' => json_encode(['schedule.view' => true])]);
        TenantContext::clear();
        $payload = $this->getJson('/api/schedule-versions?project_id='.$this->project->id)->assertOk()->json('versions.0');
        self::assertArrayNotHasKey('source', $payload);
        self::assertArrayNotHasKey('submitted_by_org', $payload);
    }

    public function test_tenant_scope_fails_closed_for_another_tenants_project(): void
    {
        $otherTenant = Tenant::create(['name' => 'Other Co', 'type' => 'CM firm', 'entitlements' => []]);
        TenantContext::set($otherTenant->id);
        $otherProject = Project::create([
            'number' => 'OTHER', 'name' => 'Other Project', 'sector' => 'public', 'owner_name' => 'Other City',
            'state' => 'CA', 'contract_clocks' => [], 'org_structure' => [],
        ]);
        TenantContext::clear();

        $this->getJson('/api/schedule-versions?project_id='.$otherProject->id)->assertNotFound();
    }

    private function upload(string $label, string $kind, ?int $parentId, int $secondDuration): int
    {
        $csv = implode("\n", [
            'activity_code,name,duration_minutes,planned_start,planned_finish,predecessors,calendar',
            'A100,Mobilize,480,2026-08-24 08:00,2026-08-24 17:00,,Standard',
            'A200,Excavate,'.$secondDuration.',2026-08-25 08:00,2026-08-27 17:00,A100 FS,Standard',
        ]);
        $payload = [
            'project_id' => $this->project->id,
            'file' => UploadedFile::fake()->createWithContent(str_replace(' ', '-', strtolower($label)).'.csv', $csv),
            'kind' => $kind,
            'label' => $label,
            'data_date' => '2026-08-24',
        ];
        if ($parentId !== null) {
            $payload['parent_version_id'] = $parentId;
        }

        return (int) $this->post('/api/schedule-versions', $payload, ['Accept' => 'application/json'])
            ->assertCreated()
            ->assertJsonPath('parent_version_id', $parentId)
            ->json('id');
    }
}
