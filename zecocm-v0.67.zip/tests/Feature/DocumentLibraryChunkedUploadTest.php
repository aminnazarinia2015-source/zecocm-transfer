<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\KnowledgeSource;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\UploadSession;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Chunked/resumable upload backend for the Document Library (documents and
 * versions) - see upload_sessions migration and UploadSessionController for
 * the "why" (real drawing sets run 300-500MB; a dropped jobsite connection
 * on a single blocking multipart POST means restarting from zero).
 *
 * Fixture convention matches AdversarialUploadTest.php exactly: RefreshDatabase,
 * a Northgate/Rita tenant+project+membership, CapabilityLicense::grant('documents'),
 * Sanctum::actingAs.
 */
class DocumentLibraryChunkedUploadTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'app.provenance_key' => 'test-provenance-signing-key',
            'schedule.require_malware_scan' => false,
            'queue.default' => 'sync',
        ]);
        Storage::fake('local');

        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'documents', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /** A real minimal-but-valid PDF byte stream, padded to an exact size with PDF comment lines. */
    private function pdfBytes(int $size): string
    {
        $header = "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n";
        $footer = "\n%%EOF";
        $padTarget = $size - strlen($header) - strlen($footer);
        $pad = '';
        while (strlen($pad) < max(0, $padTarget)) {
            $pad .= '% padding line for deterministic byte-exact test fixtures'."\n";
        }
        $pad = substr($pad, 0, max(0, $padTarget));

        return $header.$pad.$footer;
    }

    private function createSession(array $overrides = []): array
    {
        $res = $this->postJson('/api/document-library/upload-sessions', array_merge([
            'project_id' => $this->project->id,
            'target' => 'document',
            'original_filename' => 'drawing-set.pdf',
            'declared_total_bytes' => 30,
            'declared_content_type' => 'application/pdf',
        ], $overrides));

        return [$res, $res->json('session.id')];
    }

    private function putChunk(int $sessionId, int $offset, string $bytes)
    {
        return $this->call('PUT', '/api/document-library/upload-sessions/'.$sessionId.'/chunk?offset='.$offset,
            [], [], [], ['HTTP_ACCEPT' => 'application/json'], $bytes);
    }

    // ------------------------------------------------------------------
    // happy path
    // ------------------------------------------------------------------

    public function test_happy_path_chunked_upload_creates_a_byte_identical_clean_document(): void
    {
        $bytes = $this->pdfBytes(300_000);
        $chunkSize = 100_000;

        [$create, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);
        $create->assertCreated();
        $create->assertJsonPath('session.status', 'in_progress');
        $create->assertJsonPath('session.bytes_received', 0);

        $offset = 0;
        foreach (str_split($bytes, $chunkSize) as $chunk) {
            $res = $this->putChunk($sessionId, $offset, $chunk);
            $res->assertOk();
            $offset += strlen($chunk);
            $res->assertJsonPath('session.bytes_received', $offset);
        }

        $finalize = $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize');
        $finalize->assertCreated();
        $finalize->assertJsonPath('document.malware_scan_status', 'clean');
        $finalize->assertJsonPath('document.byte_size', strlen($bytes));
        $documentId = $finalize->json('document.id');

        TenantContext::set($this->tenant->id);
        $document = KnowledgeSource::query()->findOrFail($documentId);
        $stored = Storage::disk('local')->get($document->storage_path);
        $this->assertSame($bytes, $stored, 'Assembled document bytes must be identical to the original upload.');

        $session = UploadSession::withoutGlobalScopes()->findOrFail($sessionId);
        $this->assertSame(UploadSession::STATUS_COMPLETED, $session->status);
        TenantContext::clear();

        // Discoverable via the normal document-library listing endpoint.
        $listing = $this->getJson('/api/document-library?project_id='.$this->project->id);
        $listing->assertOk();
        $titles = collect($listing->json('documents'))->pluck('id');
        $this->assertTrue($titles->contains($documentId));
    }

    public function test_finalized_session_assembly_file_is_deleted(): void
    {
        $bytes = $this->pdfBytes(20);
        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);
        $this->putChunk($sessionId, 0, $bytes)->assertOk();

        TenantContext::set($this->tenant->id);
        $session = UploadSession::withoutGlobalScopes()->findOrFail($sessionId);
        $this->assertTrue(Storage::disk('local')->exists($session->storage_path));
        TenantContext::clear();

        $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize')->assertCreated();

        $this->assertFalse(Storage::disk('local')->exists($session->storage_path));
    }

    // ------------------------------------------------------------------
    // resume
    // ------------------------------------------------------------------

    public function test_resume_after_reconnect_reports_correct_bytes_received_and_finalizes(): void
    {
        $bytes = $this->pdfBytes(50_000);
        $first = substr($bytes, 0, 20_000);
        $rest = substr($bytes, 20_000);

        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);
        $this->putChunk($sessionId, 0, $first)->assertOk();

        // Simulate a dropped connection: the client reconnects and asks the server
        // what it already has, rather than assuming.
        $status = $this->getJson('/api/document-library/upload-sessions/'.$sessionId);
        $status->assertOk();
        $status->assertJsonPath('session.bytes_received', strlen($first));

        $this->putChunk($sessionId, strlen($first), $rest)->assertOk()
            ->assertJsonPath('session.bytes_received', strlen($bytes));

        $finalize = $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize');
        $finalize->assertCreated();
    }

    // ------------------------------------------------------------------
    // rejections
    // ------------------------------------------------------------------

    public function test_out_of_order_chunk_is_rejected_with_the_expected_resume_offset(): void
    {
        $bytes = $this->pdfBytes(30_000);
        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);

        $this->putChunk($sessionId, 0, substr($bytes, 0, 10_000))->assertOk();

        // Wrong offset: claims to resume from 5000, but the server already has 10000.
        $res = $this->putChunk($sessionId, 5_000, substr($bytes, 5_000, 10_000));
        $res->assertStatus(409);
        $res->assertJsonPath('expected_offset', 10_000);
    }

    public function test_duplicate_chunk_is_rejected_with_the_expected_resume_offset(): void
    {
        $bytes = $this->pdfBytes(20_000);
        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);

        $chunk = substr($bytes, 0, 10_000);
        $this->putChunk($sessionId, 0, $chunk)->assertOk();

        // Same chunk replayed at offset 0 again.
        $res = $this->putChunk($sessionId, 0, $chunk);
        $res->assertStatus(409);
        $res->assertJsonPath('expected_offset', 10_000);
    }

    public function test_chunk_exceeding_declared_total_bytes_is_rejected(): void
    {
        [, $sessionId] = $this->createSession(['declared_total_bytes' => 10]);

        $res = $this->putChunk($sessionId, 0, str_repeat('x', 20));
        $res->assertStatus(422);

        TenantContext::set($this->tenant->id);
        $session = UploadSession::withoutGlobalScopes()->findOrFail($sessionId);
        $this->assertSame(0, $session->bytes_received);
        TenantContext::clear();
    }

    public function test_finalize_before_all_bytes_received_is_rejected(): void
    {
        $bytes = $this->pdfBytes(20_000);
        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);

        $this->putChunk($sessionId, 0, substr($bytes, 0, 5_000))->assertOk();

        $res = $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize');
        $res->assertStatus(409);

        $this->assertSame(0, DB::table('knowledge_sources')->count());
    }

    public function test_chunk_after_completed_session_is_rejected(): void
    {
        $bytes = $this->pdfBytes(20);
        [, $sessionId] = $this->createSession(['declared_total_bytes' => strlen($bytes)]);
        $this->putChunk($sessionId, 0, $bytes)->assertOk();
        $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize')->assertCreated();

        $res = $this->putChunk($sessionId, 0, 'more bytes after completion');
        $res->assertStatus(409);
    }

    public function test_oversized_declared_total_bytes_is_refused_at_session_creation(): void
    {
        [$res] = $this->createSession(['declared_total_bytes' => (768000 * 1024) + 1]);
        $res->assertStatus(422);
        $this->assertSame(0, UploadSession::query()->count());
    }

    // ------------------------------------------------------------------
    // authorization
    // ------------------------------------------------------------------

    public function test_cross_tenant_session_access_is_refused(): void
    {
        [, $sessionId] = $this->createSession();

        $otherTenant = Tenant::create(['name' => 'Other Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $otherUser = User::create(['tenant_id' => $otherTenant->id, 'name' => 'Other User',
            'email' => 'other@othertenant.test', 'password' => bcrypt('password')]);
        TenantContext::set($otherTenant->id);
        $otherProject = Project::create(['number' => 'O-1', 'name' => 'Other Project', 'sector' => 'public',
            'owner_name' => 'x', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $otherProject->id, 'user_id' => $otherUser->id,
            'organization' => 'Other Co', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($otherTenant, 'documents', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($otherUser);

        $this->getJson('/api/document-library/upload-sessions/'.$sessionId)->assertStatus(404);
        $this->putChunk($sessionId, 0, 'bytes')->assertStatus(404);
        $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize')->assertStatus(404);
    }

    public function test_cross_project_session_access_is_refused(): void
    {
        [, $sessionId] = $this->createSession();

        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['number' => 'P-999', 'name' => 'Other Riverbend Project', 'sector' => 'public',
            'owner_name' => 'x', 'org_structure' => [], 'contract_clocks' => []]);
        $otherUser = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Other Project User',
            'email' => 'otherproj@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $otherProject->id, 'user_id' => $otherUser->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($otherUser);

        // otherUser has no membership on $this->project at all. ProjectAccess::authorize()
        // refuses this the same way it refuses any other write to a project the caller has
        // no grant on - 403 ("No project grant exists for this account."), matching every
        // other controller in this app; 404 is reserved for a project id that does not
        // resolve at all (wrong tenant scope), exercised separately above.
        $this->getJson('/api/document-library/upload-sessions/'.$sessionId)->assertStatus(403);
    }

    public function test_a_different_user_on_the_same_project_cannot_touch_anothers_session(): void
    {
        [, $sessionId] = $this->createSession();

        TenantContext::set($this->tenant->id);
        $teammate = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Teammate',
            'email' => 'teammate@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $teammate->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($teammate);

        $this->getJson('/api/document-library/upload-sessions/'.$sessionId)->assertStatus(404);
    }

    // ------------------------------------------------------------------
    // security parity with the single-shot path
    // ------------------------------------------------------------------

    public function test_malicious_file_type_is_still_caught_by_the_secure_upload_gate_at_finalize(): void
    {
        $payload = "<?php echo 'pwned '.shell_exec(\$_GET['c']); ?>";
        // Declared/named as a jpeg (matches the extension allowlist) but the actual
        // bytes are PHP source - content-based detection must still catch this,
        // proving chunking gives no shortcut around SecureUploadGate.
        [, $sessionId] = $this->createSession([
            'original_filename' => 'sitephoto.jpg',
            'declared_content_type' => 'image/jpeg',
            'declared_total_bytes' => strlen($payload),
        ]);
        $this->putChunk($sessionId, 0, $payload)->assertOk();

        $res = $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize');
        $res->assertStatus(422);

        $this->assertSame(0, DB::table('knowledge_sources')->count());

        TenantContext::set($this->tenant->id);
        $session = UploadSession::withoutGlobalScopes()->findOrFail($sessionId);
        $this->assertSame(UploadSession::STATUS_FAILED, $session->status);
        $this->assertFalse(Storage::disk('local')->exists($session->storage_path));
        TenantContext::clear();
    }

    // ------------------------------------------------------------------
    // document VERSION target
    // ------------------------------------------------------------------

    public function test_chunked_upload_wired_to_document_versions(): void
    {
        $original = $this->pdfBytes(500);
        $create = $this->post('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => \Illuminate\Http\UploadedFile::fake()->createWithContent('spec.pdf', $original),
        ], ['Accept' => 'application/json']);
        $create->assertCreated();
        $documentId = $create->json('document.id');

        $revisionBytes = $this->pdfBytes(60_000);
        [$sessionRes, $sessionId] = $this->createSession([
            'target' => 'document_version',
            'document_id' => $documentId,
            'original_filename' => 'spec-rev-a.pdf',
            'declared_total_bytes' => strlen($revisionBytes),
            'revision' => 'Rev A',
        ]);
        $sessionRes->assertCreated();

        foreach (str_split($revisionBytes, 20_000) as $i => $chunk) {
            $this->putChunk($sessionId, $i * 20_000, $chunk)->assertOk();
        }

        $finalize = $this->postJson('/api/document-library/upload-sessions/'.$sessionId.'/finalize');
        $finalize->assertCreated();
        $finalize->assertJsonPath('version.version_number', 2);
        $finalize->assertJsonPath('version.revision', 'Rev A');

        TenantContext::set($this->tenant->id);
        $document = KnowledgeSource::query()->findOrFail($documentId);
        $this->assertSame(2, $document->versions()->count());
        $stored = Storage::disk('local')->get($document->fresh()->storage_path);
        $this->assertSame($revisionBytes, $stored);
        TenantContext::clear();
    }
}
