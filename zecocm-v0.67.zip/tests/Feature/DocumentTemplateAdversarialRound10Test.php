<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Round 10 adversarial pass on DocumentTemplateController.
 *
 * Two real bugs found and fixed here:
 *
 *  1. store() checked "does the caller belong to some tenant" for an
 *     org-wide (project_id omitted) template, not "does the caller hold
 *     template.manage anywhere" - the exact check the project-scoped branch
 *     enforces. Any tenant user, including a view-only member with no
 *     template.manage grant on any project, could bypass authorization
 *     entirely by simply omitting project_id.
 *
 *  2. assign() accepted a raw assigned_to_user_id with no tenant scoping at
 *     all - User::find() carries no tenant scope, so a caller could name a
 *     user id belonging to a completely different tenant/company. That
 *     user's name would then be shown to this project's own members as the
 *     assigned party (identity confusion), and the endpoint doubled as an
 *     existence oracle for arbitrary user ids across tenants.
 */
class DocumentTemplateAdversarialRound10Test extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $pm;

    private User $viewerOnly;

    private Project $project;

    private Tenant $otherTenant;

    private User $otherTenantUser;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->pm = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate10.test', 'password' => bcrypt('password')]);
        $this->viewerOnly = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Viewer', 'email' => 'viewer@northgate10.test', 'password' => bcrypt('password')]);
        $this->project = Project::create(['number' => 'P-510', 'name' => 'Riverbend Pump Station 2', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true], 'status' => 'active']);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->viewerOnly->id,
            'organization' => 'Northgate Builders', 'seat' => 'viewer', 'capabilities' => ['template.view' => true], 'status' => 'active']);
        TenantContext::clear();

        $this->otherTenant = Tenant::create(['name' => 'Rival Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->otherTenant->id);
        $this->otherTenantUser = User::create(['tenant_id' => $this->otherTenant->id, 'name' => 'Rival Employee', 'email' => 'rival@rival10.test', 'password' => bcrypt('password')]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    /** Bug 1: a view-only member cannot create a project template directly ... */
    public function test_a_viewer_without_template_manage_cannot_create_a_project_template(): void
    {
        Sanctum::actingAs($this->viewerOnly);

        $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'X', 'document_type' => 'x',
            'fields' => [['key' => 'a', 'label' => 'A', 'type' => 'text', 'required' => true]],
        ])->assertStatus(403);
    }

    /** ... and cannot bypass that check by simply omitting project_id. */
    public function test_a_viewer_without_template_manage_cannot_bypass_by_omitting_project_id(): void
    {
        Sanctum::actingAs($this->viewerOnly);

        $this->postJson('/api/document-templates', [
            'name' => 'Org Wide Bypass', 'document_type' => 'x',
            'fields' => [['key' => 'a', 'label' => 'A', 'type' => 'text', 'required' => true]],
        ])->assertStatus(403);

        TenantContext::set($this->tenant->id);
        $this->assertDatabaseMissing('document_templates', ['name' => 'Org Wide Bypass']);
        TenantContext::clear();
    }

    /** A user who genuinely holds template.manage somewhere can still create an org-wide template. */
    public function test_a_pm_with_template_manage_can_create_an_org_wide_template(): void
    {
        Sanctum::actingAs($this->pm);

        $this->postJson('/api/document-templates', [
            'name' => 'Org Wide Legit', 'document_type' => 'x',
            'fields' => [['key' => 'a', 'label' => 'A', 'type' => 'text', 'required' => true]],
        ])->assertCreated();
    }

    /** Bug 2: assigning a template to a user from a different tenant is refused. */
    public function test_assigning_a_template_to_a_cross_tenant_user_id_is_refused(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => [['key' => 'a', 'label' => 'A', 'type' => 'text', 'required' => true]],
        ])->json();

        $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'],
            'party_label' => 'Rival Co', 'assigned_to_user_id' => $this->otherTenantUser->id,
        ])->assertStatus(422);

        TenantContext::set($this->tenant->id);
        $this->assertDatabaseMissing('template_assignments', ['assigned_to_user_id' => $this->otherTenantUser->id]);
        TenantContext::clear();
    }
}
