<?php

namespace Tests\Feature;

use App\Domain\Decisions\DecisionState;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The evidence-to-decision workflow: an envelope describes a formal action before
 * it happens, and authorisation runs through that same envelope so the preview and
 * the gate can never drift apart.
 */
class DecisionEnvelopeTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $user;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config(['queue.default' => 'sync']);

        $this->tenant = Tenant::create([
            'name' => 'Envelope CM', 'type' => 'CM firm', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('CM firm'),
            'sponsor_role' => 'cm_firm', 'is_account_owner' => true,
        ]);
        $this->user = User::create([
            'tenant_id' => $this->tenant->id, 'name' => 'Dana Reyes',
            'email' => 'dana@example.test', 'password' => bcrypt('password'),
        ]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create([
            'number' => 'P-900', 'name' => 'Envelope Park', 'sector' => 'public', 'owner_name' => 'City of Testing',
            'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [],
            'contract_clocks' => ['rfi_response' => ['days' => 5, 'basis' => 'working']],
        ]);
        Membership::create([
            'project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Envelope CM', 'seat' => 'project_manager', 'capabilities' => ['*' => true],
        ]);
        (new CapabilityLicense)->grant($this->tenant, 'rfis', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function rfi(array $overrides = []): Rfi
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(array_merge([
            'project_id' => $this->project->id, 'number' => 'RFI-0001',
            'subject' => 'Rebar clearance at the corner condition',
            'question' => 'Detail 7 conflicts with the section callout. Which governs?',
            'raised_by_org' => 'Prime contractor', 'raised_at' => now()->subDays(3)->toDateString(),
            'ball_in_court' => 'Structural engineer', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ], $overrides));
        TenantContext::clear();

        return $rfi;
    }

    public function test_the_envelope_reports_readiness_evidence_clock_and_consequences(): void
    {
        $rfi = $this->rfi();
        $res = $this->getJson('/api/decisions/rfi/'.$rfi->id.'/envelope')->assertOk();
        $e = $res->json();

        $this->assertSame('rfi.respond', $e['action']);
        $this->assertSame(DecisionState::READY, $e['state']);
        $this->assertTrue($e['ready']);

        // The clock is a deterministic calculation from the project's own contract.
        $this->assertTrue($e['clock']['configured']);
        $this->assertSame(5, $e['clock']['period_days']);
        $this->assertSame('working', $e['clock']['basis']);
        $this->assertArrayHasKey('due', $e['clock']);

        // Consequences are stated before the act, and the act is irreversible.
        $this->assertFalse($e['consequences']['reversible']);
        $this->assertStringContainsString('append', $e['consequences']['corrections']);

        // The question is labelled an assertion, never a finding.
        $q = collect($e['checklist'])->firstWhere('key', 'question');
        $this->assertSame('assertion', $q['classification']);

        // Missing evidence is disclosed but does not block a response.
        $ev = collect($e['checklist'])->firstWhere('key', 'evidence');
        $this->assertFalse($ev['satisfied']);
        $this->assertFalse($ev['blocking']);

        $this->assertStringContainsString('does not issue formal actions on its own', $e['notice']);
    }

    public function test_authorising_requires_an_explicit_human_confirmation(): void
    {
        $rfi = $this->rfi();
        // No confirm flag: refused.
        $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', ['response' => 'Section governs.'])
            ->assertStatus(422);
        $this->assertSame('open', $rfi->fresh()->status);
    }

    public function test_authorising_seals_the_record_and_routes_the_next_action(): void
    {
        $rfi = $this->rfi();
        $res = $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', [
            'confirm' => true,
            'response' => 'The section callout governs; provide #5 bars at 12 inches on centre.',
        ])->assertOk();

        $this->assertTrue($res->json('sealed'));
        $this->assertSame($this->user->id, $res->json('seal.by'));
        $this->assertNotNull($res->json('seal.sealed_at'));
        $this->assertSame('rfis', $res->json('next.view'));

        $fresh = $rfi->fresh();
        $this->assertSame('answered', $fresh->status);
        $this->assertSame($this->user->id, $fresh->response_seal['by']);

        // The envelope returned afterwards reports the decision as complete.
        $this->assertSame(DecisionState::COMPLETE, $res->json('envelope.state'));
    }

    public function test_a_sealed_decision_cannot_be_authorised_twice(): void
    {
        $rfi = $this->rfi();
        $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', [
            'confirm' => true, 'response' => 'First and only answer.',
        ])->assertOk();

        $again = $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', [
            'confirm' => true, 'response' => 'A different answer.',
        ])->assertStatus(409);

        $this->assertSame(DecisionState::COMPLETE, $again->json('state'));
        $this->assertSame('First and only answer.', $rfi->fresh()->response);
    }

    public function test_an_empty_response_is_refused_even_when_confirmed(): void
    {
        $rfi = $this->rfi();
        $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', ['confirm' => true, 'response' => '   '])
            ->assertStatus(422);
        $this->assertSame('open', $rfi->fresh()->status);
    }

    public function test_another_tenants_record_fails_closed_without_revealing_it_exists(): void
    {
        $other = Tenant::create(['name' => 'Other Co', 'type' => 'CM firm', 'entitlements' => [], 'status' => 'active']);
        TenantContext::set($other->id);
        $otherProject = Project::create([
            'number' => 'P-999', 'name' => 'Not Yours', 'sector' => 'public', 'owner_name' => 'City of Elsewhere',
            'state' => 'CA', 'funding_source' => 'local', 'contract_clocks' => [], 'org_structure' => [],
        ]);
        $otherRfi = Rfi::create([
            'project_id' => $otherProject->id, 'number' => 'RFI-9999', 'subject' => 'Theirs',
            'question' => 'Theirs', 'raised_by_org' => 'Them', 'raised_at' => now()->toDateString(),
            'ball_in_court' => 'Them', 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => [],
        ]);
        TenantContext::clear();

        $this->getJson('/api/decisions/rfi/'.$otherRfi->id.'/envelope')->assertNotFound();
    }
}
