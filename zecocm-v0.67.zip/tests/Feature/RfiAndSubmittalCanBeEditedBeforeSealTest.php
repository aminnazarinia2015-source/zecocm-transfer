<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Found during a real-world audit: RFIs and submittals had no way to fix so
 * much as a typo before they were answered/stamped - the only options were
 * "live with the mistake" or "raise a whole new record," even though the
 * app's own UI copy ("Draft or coordinate...") and the submittal's own
 * initial status ('draft') both imply a correctable stage exists. This
 * mirrors the pattern DailyReportController::update() already established:
 * editable up to the point of a seal, refused afterward with a clear
 * message pointing at the real path (a revision or resubmittal), never a
 * silent rewrite of sealed evidence.
 */
class RfiAndSubmittalCanBeEditedBeforeSealTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'rfis', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'submittals', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    public function test_an_unanswered_rfi_can_be_edited(): void
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(['project_id' => $this->project->id, 'number' => 'RFI-1', 'subject' => 'Orignial typo',
            'question' => 'x', 'raised_by_org' => 'Fieldco', 'raised_at' => now(),
            'ball_in_court' => 'architect', 'cost_impact' => false, 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->putJson('/api/rfis/'.$rfi->id, ['subject' => 'Fixed subject']);

        $res->assertOk();
        $this->assertSame('Fixed subject', $rfi->fresh()->subject);
    }

    public function test_a_sealed_rfi_cannot_be_edited(): void
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(['project_id' => $this->project->id, 'number' => 'RFI-1', 'subject' => 'x',
            'question' => 'x', 'raised_by_org' => 'Fieldco', 'raised_at' => now(),
            'ball_in_court' => 'architect', 'cost_impact' => false, 'status' => 'answered',
            'response' => 'Answered', 'response_seal' => ['by' => 1, 'sealed_at' => now()->toIso8601String()],
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->putJson('/api/rfis/'.$rfi->id, ['subject' => 'Trying to rewrite sealed evidence']);

        $res->assertStatus(422);
        $this->assertStringContainsString('sealed', $res->json('message'));
        $this->assertSame('x', $rfi->fresh()->subject);
    }

    public function test_a_draft_submittal_can_be_edited(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['project_id' => $this->project->id, 'number' => 'SUB-1',
            'title' => 'Original title', 'type' => 'shop_drawing', 'spec_section' => '03 30 00',
            'submitted_by_org' => 'Fieldco', 'submitted_at' => now(),
            'ball_in_court' => 'structural', 'status' => 'draft', 'ai_findings' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->putJson('/api/submittals/'.$submittal->id, ['title' => 'Corrected title']);

        $res->assertOk();
        $this->assertSame('Corrected title', $submittal->fresh()->title);
    }

    public function test_a_stamped_submittal_cannot_be_edited(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['project_id' => $this->project->id, 'number' => 'SUB-1',
            'title' => 'x', 'type' => 'shop_drawing', 'spec_section' => '03 30 00',
            'submitted_by_org' => 'Fieldco', 'submitted_at' => now(),
            'ball_in_court' => 'closed', 'status' => 'no_exceptions',
            'stamp' => ['action' => 'no_exceptions', 'stamped_by' => 1, 'sealed_at' => now()->toIso8601String()],
            'ai_findings' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->putJson('/api/submittals/'.$submittal->id, ['title' => 'Trying to rewrite a sealed stamp']);

        $res->assertStatus(422);
        $this->assertStringContainsString('stamped', $res->json('message'));
        $this->assertSame('x', $submittal->fresh()->title);
    }
}
