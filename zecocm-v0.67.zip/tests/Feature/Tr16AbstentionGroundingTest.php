<?php

namespace Tests\Feature;

use App\Domain\Ai\ClaudeAssistant;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\NoMatch;
use App\Domain\Ai\RetrievalClient;
use App\Domain\Ai\RetrievedPassage;
use Tests\TestCase;

/**
 * TR-16: abstention when evidence is insufficient or contradictory.
 *
 * Codex's closure criterion, verbatim: "TRACE can never produce a
 * substantive answer without valid citations; when retrieved evidence is
 * insufficient or contradictory, the refusal itself identifies the
 * evidentiary basis or the specific missing fact/authority, and an
 * unsupported model claim of conflict cannot masquerade as a grounded
 * escalation."
 *
 * Every case below drives ClaudeAssistant::parse() directly via reflection,
 * the same pattern Tr14CitationAddressabilityTest established - parse() is
 * private and the HTTP call above it is out of scope; only the response
 * parsing this row actually changed is under test.
 */
class Tr16AbstentionGroundingTest extends TestCase
{
    /** @return list<RetrievedPassage> */
    private function passages(int $count): array
    {
        $out = [];
        for ($i = 0; $i < $count; $i++) {
            $out[] = new RetrievedPassage(
                source: "Spec Section {$i}",
                edition: '2026',
                text: "Passage {$i} text.",
            );
        }

        return $out;
    }

    private function parse(string $raw, array $passages)
    {
        $assistant = new ClaudeAssistant('test-key', $this->nullRetrievalClient());
        $method = new \ReflectionMethod(ClaudeAssistant::class, 'parse');
        $method->setAccessible(true);

        return $method->invoke($assistant, $raw, $passages);
    }

    private function nullRetrievalClient(): RetrievalClient
    {
        return new class implements RetrievalClient
        {
            public function retrieve(string $query, \App\Domain\Ai\JurisdictionScope $scope): array
            {
                return [];
            }
        };
    }

    private function rawWith(array $decoded): string
    {
        return json_encode(['content' => [['text' => json_encode($decoded)]]]);
    }

    // ---- acceptance case: two valid conflicting refs -> grounded conflict ----

    public function test_conflict_with_two_valid_refs_is_a_grounded_conflict_escalation(): void
    {
        $passages = $this->passages(2);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'conflict',
            'reason' => 'Spec section 0 requires 5%, section 1 requires 10%.',
            'route_to' => 'design professional', 'passage_refs' => [0, 1],
        ]), $passages);

        $this->assertInstanceOf(Escalation::class, $result);
        $this->assertSame(Escalation::BASIS_CONFLICT, $result->basis);
        $this->assertCount(2, $result->conflictCitations);
        $this->assertNull($result->missingFact);
    }

    // ---- acceptance case: one valid, one invalid ref -> not a verified conflict ----

    public function test_conflict_with_one_valid_and_one_invalid_ref_is_not_verified(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'conflict',
            'reason' => 'Claims a conflict.', 'route_to' => 'design professional',
            'passage_refs' => [0, 7], // 7 does not exist in the retrieved set
        ]), $passages);

        $this->assertInstanceOf(Escalation::class, $result);
        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis);
        $this->assertSame([], $result->conflictCitations);
    }

    // ---- acceptance case: zero valid refs -> ungrounded, not a normal conflict escalation ----

    public function test_conflict_with_zero_valid_refs_is_ungrounded_not_a_conflict(): void
    {
        $passages = $this->passages(2);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'conflict',
            'reason' => 'The documents disagree.', 'route_to' => 'design professional',
            'passage_refs' => [],
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis);
        $this->assertStringContainsString('did not cite at least two', $result->reason);
        $this->assertStringContainsString('The documents disagree.', $result->reason, 'The original unverified claim must not be discarded, only downgraded.');
    }

    // ---- acceptance case: refs outside the retrieved candidate set are invalid even if in-bounds elsewhere ----

    public function test_refs_pointing_outside_the_retrieved_set_are_rejected(): void
    {
        $passages = $this->passages(1); // only index 0 exists
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'conflict',
            'reason' => 'Conflict claimed.', 'route_to' => 'design professional',
            'passage_refs' => [0, 1, 2],
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis, 'Only one of the three refs is real - still not a verified two-source conflict.');
    }

    // ---- acceptance case: duplicate refs must not fake a two-source conflict ----

    public function test_duplicate_refs_are_deduped_and_do_not_satisfy_the_two_source_bar(): void
    {
        $passages = $this->passages(2);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'conflict',
            'reason' => 'Conflict claimed.', 'route_to' => 'design professional',
            'passage_refs' => [0, 0, 0],
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis, 'One passage cited three times is one source, not two conflicting ones.');
    }

    // ---- insufficient_evidence: grounded with citations ----

    public function test_insufficient_evidence_with_citations_and_missing_fact_is_grounded(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'insufficient_evidence',
            'reason' => 'The warranty clause sets the period but the start date is undetermined.',
            'route_to' => 'manual evidence review', 'passage_refs' => [0],
            'missing_fact' => 'No confirmed acceptance event was found to determine the warranty start date.',
        ]), $passages);

        $this->assertSame(Escalation::BASIS_INSUFFICIENT_EVIDENCE, $result->basis);
        $this->assertCount(1, $result->conflictCitations);
        $this->assertSame('No confirmed acceptance event was found to determine the warranty start date.', $result->missingFact);
    }

    // ---- insufficient_evidence: a named missing fact with zero passage refs is still grounded ----

    public function test_insufficient_evidence_with_only_a_missing_fact_string_is_grounded(): void
    {
        $passages = $this->passages(0);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'insufficient_evidence',
            'reason' => 'No applicable retention rate provision was found for this jurisdiction.',
            'route_to' => 'manual evidence review', 'passage_refs' => [],
            'missing_fact' => 'A jurisdiction-specific retention rate provision.',
        ]), $passages);

        $this->assertSame(Escalation::BASIS_INSUFFICIENT_EVIDENCE, $result->basis);
        $this->assertSame('A jurisdiction-specific retention rate provision.', $result->missingFact);
    }

    // ---- insufficient_evidence with neither refs nor a missing-fact string is ungrounded ----

    public function test_insufficient_evidence_with_no_refs_and_no_missing_fact_is_ungrounded(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'insufficient_evidence',
            'reason' => 'Not enough information.', 'route_to' => 'manual evidence review',
            'passage_refs' => [], 'missing_fact' => '   ',
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis);
        $this->assertStringContainsString('Not enough information.', $result->reason);
    }

    // ---- a basis the model never sent, or an unrecognised one, is a protocol failure ----

    public function test_escalation_with_no_recognised_basis_is_ungrounded(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'reason' => 'Needs review.', 'route_to' => 'manual review',
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis);
    }

    public function test_escalation_with_an_unrecognised_basis_string_is_ungrounded(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'escalation', 'basis' => 'because_i_said_so', 'reason' => 'Needs review.', 'route_to' => 'manual review',
        ]), $passages);

        $this->assertSame(Escalation::BASIS_UNGROUNDED_CLAIM, $result->basis);
    }

    // ---- regression: zero retrieved passages remains deterministic NoMatch, never model-controlled ----

    public function test_suggestion_with_zero_citations_still_falls_back_to_a_policy_escalation(): void
    {
        $passages = $this->passages(1);
        $result = $this->parse($this->rawWith([
            'kind' => 'suggestion', 'text' => 'An answer with nothing backing it.', 'passage_refs' => [],
        ]), $passages);

        $this->assertInstanceOf(Escalation::class, $result);
        $this->assertSame(Escalation::BASIS_POLICY, $result->basis, 'This is the pre-existing malformed-suggestion path, unchanged by TR-16 - not a model-declared basis.');
    }

    public function test_no_match_is_returned_as_is_and_never_carries_a_basis_field(): void
    {
        $result = new NoMatch('project_specs, building_code');
        $this->assertSame('no_match', $result->kind());
    }
}
