<?php

namespace Tests\Feature;

use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

/**
 * LIB-1: before this, KnowledgePassage retrieval was hard-scoped to
 * `project_id = $projectId` no matter what a source's own collection or
 * access_classification said - so a regulation ingested once as
 * 'organization'/'regulatory' with access_classification 'tenant_private'
 * (the entire point of the Knowledge Library: ingest a code section once,
 * not per project) was structurally invisible to every project except the
 * one it happened to be ingested under. Found while investigating why the
 * Library ingest sweep's own manifest assumed a real customer knowledge
 * base couldn't work this way at all.
 *
 * These tests prove the fix's actual claim, not just its happy path: a
 * tenant-wide source now reaches a SECOND project under the SAME tenant,
 * a project-private source still never does, and no source ever crosses
 * to a DIFFERENT tenant no matter what its access_classification says -
 * that boundary is a separate, structural guarantee (TenantScope) this
 * change must not need to reimplement or accidentally weaken.
 */
class Lib1TenantWideKnowledgeSharingTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function tenantWithTwoProjects(string $name): array
    {
        $tenant = Tenant::create(['name' => $name, 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'PM',
            'email' => strtolower(Str::random(8)).'@'.strtolower(str_replace(' ', '', $name)).'.test', 'password' => bcrypt('password')]);
        TenantContext::set($tenant->id);
        $projectA = Project::create(['number' => 'P-A', 'name' => 'Project A', 'sector' => 'public',
            'owner_name' => 'City of A', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $projectB = Project::create(['number' => 'P-B', 'name' => 'Project B', 'sector' => 'public',
            'owner_name' => 'City of B', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $projectA->id, 'user_id' => $user->id,
            'organization' => $name, 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        Membership::create(['project_id' => $projectB->id, 'user_id' => $user->id,
            'organization' => $name, 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();

        return [$tenant, $projectA, $projectB];
    }

    /** Ingested under $anchorProject, but attributed (tenant_id) to that project's tenant. */
    private function seedRegulatorySource(
        Tenant $tenant, Project $anchorProject, string $jurisdiction, string $body,
        string $accessClassification = 'tenant_private',
    ): void {
        TenantContext::set($tenant->id);
        $title = 'Reg-'.Str::random(6);
        $source = KnowledgeSource::create(['tenant_id' => $tenant->id, 'project_id' => $anchorProject->id,
            'public_id' => (string) Str::uuid(), 'collection' => 'regulatory', 'title' => $title,
            'source_type' => 'regulation', 'jurisdiction' => $jurisdiction, 'discipline' => 'general',
            'authority_level' => 'published_regulation', 'access_classification' => $accessClassification,
            'verification_status' => 'verified', 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$title, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2026', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['state_public_contract_code']], 'storage_path' => 'test/'.$title,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        KnowledgePassage::create(['tenant_id' => $tenant->id, 'project_id' => $anchorProject->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);
        TenantContext::clear();
    }

    /** @return list<\App\Domain\Ai\RetrievedPassage> */
    private function retrieveFor(Tenant $tenant, Project $project, string $question): array
    {
        TenantContext::set($tenant->id);
        request()->attributes->set('authorized_project_id', $project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve($question, $project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    public function test_a_tenant_wide_source_ingested_under_one_project_is_retrievable_from_a_second_project_same_tenant(): void
    {
        [$tenant, $projectA, $projectB] = $this->tenantWithTwoProjects('Shared Library Co');

        $this->seedRegulatorySource($tenant, $projectA, 'CA', 'Retention on public works contracts shall not exceed 5 percent.');

        $foundOnA = $this->retrieveFor($tenant, $projectA, 'retention on public works contracts');
        $foundOnB = $this->retrieveFor($tenant, $projectB, 'retention on public works contracts');

        $this->assertNotEmpty($foundOnA, 'The anchor project itself should still see its own ingested source.');
        $this->assertNotEmpty($foundOnB, 'LIB-1: a tenant_private regulatory source must reach every project in the same tenant, not only the one it was ingested under.');
    }

    public function test_a_tenant_wide_source_still_respects_jurisdiction_for_a_different_project(): void
    {
        [$tenant, $projectA, $projectB] = $this->tenantWithTwoProjects('Cross State Co');
        TenantContext::set($tenant->id);
        $projectB->update(['state' => 'NV']);
        TenantContext::clear();

        // Ingested for CA, anchored under project A.
        $this->seedRegulatorySource($tenant, $projectA, 'CA', 'Retention on public works contracts shall not exceed 5 percent.');

        $foundOnB = $this->retrieveFor($tenant, $projectB, 'retention on public works contracts');

        $this->assertEmpty($foundOnB, 'A CA-jurisdiction source must not surface for an NV project, tenant-wide sharing or not.');
    }

    public function test_a_project_private_source_never_reaches_a_different_project_even_in_the_same_tenant(): void
    {
        [$tenant, $projectA, $projectB] = $this->tenantWithTwoProjects('Private Docs Co');

        $this->seedRegulatorySource($tenant, $projectA, 'CA', 'This project'."'"."s executed contract sets a 90-day notice period.",
            accessClassification: 'project_private');

        $foundOnA = $this->retrieveFor($tenant, $projectA, 'notice period executed contract');
        $foundOnB = $this->retrieveFor($tenant, $projectB, 'notice period executed contract');

        $this->assertNotEmpty($foundOnA, 'A project should still see its own project-private source.');
        $this->assertEmpty($foundOnB, 'A project_private source must never reach a different project - sharing is opt-in via tenant_private, not automatic.');
    }

    public function test_a_tenant_wide_source_never_crosses_to_a_different_tenant(): void
    {
        [$tenantA, $projectA1] = $this->tenantWithTwoProjects('Tenant A Co');
        [$tenantB, $projectB1] = $this->tenantWithTwoProjects('Tenant B Co');

        $this->seedRegulatorySource($tenantA, $projectA1, 'CA', 'Retention on public works contracts shall not exceed 5 percent.');

        $foundOnOtherTenant = $this->retrieveFor($tenantB, $projectB1, 'retention on public works contracts');

        $this->assertEmpty($foundOnOtherTenant, 'TenantScope must still hold: a tenant_private source is tenant-wide WITHIN its own tenant, never across tenants.');
    }
}
