<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\DB;
use Tests\TestCase;

/**
 * The PRAGMAs have to actually run.
 *
 * This is the shape of the original defect and the reason the test asserts
 * behaviour rather than configuration: the three settings WERE present in
 * config/database.php, all set to null. Laravel's SQLite connector guards each
 * one with isset(), so every statement was skipped and the file ran on the
 * library defaults - rollback journal, no busy timeout.
 *
 * A test that read the config array would have passed the whole time. The only
 * honest check is to ask the live connection what it is actually doing.
 */
class DatabaseConcurrencyTest extends TestCase
{
    public function test_the_busy_timeout_pragma_is_actually_applied_to_the_connection(): void
    {
        // Without this, two writers in the same second produce
        // 'database is locked' as a 500 rather than a short wait.
        $timeout = DB::connection()->select('PRAGMA busy_timeout')[0]->timeout ?? null;

        $this->assertNotNull($timeout, 'busy_timeout was never issued to the connection.');
        $this->assertGreaterThanOrEqual(1000, (int) $timeout,
            'busy_timeout is set too low to survive a concurrent daily-report submission.');
    }

    public function test_a_file_backed_database_runs_in_wal_and_normal_synchronous(): void
    {
        // The test suite runs on :memory:, which cannot do WAL - so asserting
        // WAL against the test connection would be asserting nothing. Open a
        // real file the way production does and check that one.
        $path = sys_get_temp_dir().'/zecocm-pragma-'.bin2hex(random_bytes(6)).'.sqlite';
        touch($path);

        config(['database.connections.pragma_probe' => array_merge(
            config('database.connections.sqlite'),
            ['database' => $path],
        )]);

        try {
            $connection = DB::connection('pragma_probe');

            $this->assertSame('wal',
                strtolower($connection->select('PRAGMA journal_mode')[0]->journal_mode),
                'The database is not in WAL, so a single write blocks every read on the droplet.');

            // 1 is NORMAL. 2 is FULL, 0 is OFF - OFF would be a durability
            // failure and is worth failing the build over.
            $this->assertSame(1, (int) $connection->select('PRAGMA synchronous')[0]->synchronous);

            $connection->disconnect();
        } finally {
            foreach ([$path, $path.'-wal', $path.'-shm'] as $f) {
                if (file_exists($f)) {
                    @unlink($f);
                }
            }
        }
    }

    public function test_concurrent_writers_do_not_produce_a_locked_database_error(): void
    {
        // The failure as it actually happens: a write is open, another arrives.
        // With a busy timeout the second waits; without one it throws.
        $path = sys_get_temp_dir().'/zecocm-lock-'.bin2hex(random_bytes(6)).'.sqlite';
        touch($path);

        config(['database.connections.lock_probe_a' => array_merge(config('database.connections.sqlite'), ['database' => $path])]);
        config(['database.connections.lock_probe_b' => array_merge(config('database.connections.sqlite'), ['database' => $path])]);

        try {
            $a = DB::connection('lock_probe_a');
            $b = DB::connection('lock_probe_b');

            $a->statement('CREATE TABLE reports (id INTEGER PRIMARY KEY, body TEXT)');
            $a->beginTransaction();
            $a->insert('INSERT INTO reports (body) VALUES (?)', ['Foreman one, 07:12.']);

            // Second writer arrives mid-transaction. Under WAL this reads fine
            // and, once the first commits, writes without the caller ever seeing
            // an error.
            $this->assertSame(0, (int) $b->select('SELECT COUNT(*) as c FROM reports')[0]->c,
                'The uncommitted write was visible to another connection.');

            $a->commit();
            $b->insert('INSERT INTO reports (body) VALUES (?)', ['Foreman two, 07:12.']);

            $this->assertSame(2, (int) $b->select('SELECT COUNT(*) as c FROM reports')[0]->c);

            $a->disconnect();
            $b->disconnect();
        } finally {
            foreach ([$path, $path.'-wal', $path.'-shm'] as $f) {
                if (file_exists($f)) {
                    @unlink($f);
                }
            }
        }
    }
}
