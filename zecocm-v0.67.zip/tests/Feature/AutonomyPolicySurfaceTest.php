<?php

namespace Tests\Feature;

use App\Domain\Autonomy\AutonomyLevel;
use App\Domain\Autonomy\PayAppRollforwardEvaluator;
use App\Models\AutonomyPolicy;
use App\Models\Membership;
use App\Models\PayApplication;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * AUTO-2's second missing piece over HTTP: the customer-facing surface for
 * `AutonomyPolicy`, per Codex's explicit list (see AutonomyPolicyController's
 * doc comment). This suite defends the specific acceptance case Codex asked
 * for: a project owner can turn automation on, and turning it back off
 * actually stops the next detected condition from auto-executing - without
 * this surface silently clamping a request above the ceiling, and without a
 * mere policy change ever executing anything by itself.
 *
 * Every direct model touch below is wrapped in TenantContext::set()/clear(),
 * since EstablishTenantContext (the real `tenant.context` middleware) clears
 * the ambient context again once each HTTP request finishes - the same
 * pattern PayApplicationSurfaceTest already uses.
 */
class AutonomyPolicySurfaceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $owner;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->owner = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Project Owner',
            'email' => 'owner@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-851', 'name' => 'Autonomy Surface', 'sector' => 'public',
            'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->owner->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_executive',
            'capabilities' => ['project.autonomy.manage' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($this->owner);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_user_without_the_capability_is_refused(): void
    {
        TenantContext::set($this->tenant->id);
        $bystander = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $bystander->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['payment.view' => true]]);
        TenantContext::clear();
        Sanctum::actingAs($bystander);

        $this->postJson('/api/autonomy-policies', $this->payload())->assertStatus(403);
    }

    public function test_setting_a_policy_above_the_system_ceiling_is_refused_not_silently_clamped(): void
    {
        // send_contractual_notice's system ceiling is APPROVAL_REQUIRED.
        $response = $this->postJson('/api/autonomy-policies', $this->payload(
            actionType: 'send_contractual_notice',
            level: AutonomyLevel::AUTO,
        ))->assertStatus(422)->json();

        $this->assertTrue($response['refused']);
        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, $response['system_ceiling']);

        TenantContext::set($this->tenant->id);
        $this->assertSame(0, AutonomyPolicy::count(), 'a refused request must create no row at all');
        TenantContext::clear();
    }

    public function test_an_unrecognized_action_type_is_rejected(): void
    {
        $this->postJson('/api/autonomy-policies', $this->payload(actionType: 'invent_a_new_action_type'))
            ->assertStatus(422);
    }

    public function test_an_unrecognized_autonomy_level_is_rejected(): void
    {
        $this->postJson('/api/autonomy-policies', $this->payload(level: 'SUPER_AUTO'))
            ->assertStatus(422);
    }

    public function test_setting_a_policy_within_the_ceiling_succeeds_and_records_actor_time_and_reason(): void
    {
        $response = $this->postJson('/api/autonomy-policies', $this->payload(
            reason: 'Pilot customer wants automatic draft shells.',
        ))->assertCreated()->json();

        TenantContext::set($this->tenant->id);
        $policy = AutonomyPolicy::firstOrFail();
        $this->assertSame(AutonomyLevel::AUTO, $policy->autonomy_level);
        $this->assertSame($this->owner->id, $policy->set_by);
        $this->assertSame('Pilot customer wants automatic draft shells.', $policy->authority_source);
        $this->assertSame('active', $policy->status);
        $this->assertSame($policy->id, $response['policy']['id']);
        TenantContext::clear();
    }

    public function test_a_second_policy_for_the_same_action_type_supersedes_the_first_rather_than_editing_it(): void
    {
        $this->postJson('/api/autonomy-policies', $this->payload(level: AutonomyLevel::AUTO))->assertCreated();

        TenantContext::set($this->tenant->id);
        $first = AutonomyPolicy::firstOrFail();
        TenantContext::clear();

        $this->postJson('/api/autonomy-policies', $this->payload(
            level: AutonomyLevel::APPROVAL_REQUIRED,
            reason: 'Reverting to manual pending review.',
        ))->assertCreated();

        TenantContext::set($this->tenant->id);
        $this->assertSame('superseded', $first->fresh()->status);
        $this->assertSame(2, AutonomyPolicy::count());
        $second = AutonomyPolicy::where('id', '!=', $first->id)->firstOrFail();
        $this->assertSame($first->id, $second->supersedes_policy_id);
        $this->assertSame('active', $second->status);
        TenantContext::clear();
    }

    public function test_index_reports_the_system_ceiling_effective_level_and_full_history(): void
    {
        $before = $this->getJson('/api/autonomy-policies?project_id='.$this->project->id)->assertOk()->json();
        $rollforward = collect($before['action_types'])->firstWhere('action_type', PayAppRollforwardEvaluator::ACTION_TYPE);
        $this->assertSame(AutonomyLevel::AUTO, $rollforward['system_ceiling']);
        // No policy on file yet - defaults to APPROVAL_REQUIRED even though
        // the ceiling allows AUTO. "Never automate away accountability."
        $this->assertSame(AutonomyLevel::APPROVAL_REQUIRED, $rollforward['effective_level']);
        $this->assertNull($rollforward['active_policy']);
        $this->assertSame([], $rollforward['history']);

        $this->postJson('/api/autonomy-policies', $this->payload(level: AutonomyLevel::AUTO))->assertCreated();

        $after = $this->getJson('/api/autonomy-policies?project_id='.$this->project->id)->assertOk()->json();
        $rollforward = collect($after['action_types'])->firstWhere('action_type', PayAppRollforwardEvaluator::ACTION_TYPE);
        $this->assertSame(AutonomyLevel::AUTO, $rollforward['effective_level']);
        $this->assertNotNull($rollforward['active_policy']);
        $this->assertCount(1, $rollforward['history']);
    }

    public function test_setting_the_policy_to_auto_lets_the_evaluator_actually_auto_execute(): void
    {
        $this->postJson('/api/autonomy-policies', $this->payload(level: AutonomyLevel::AUTO))->assertCreated();

        TenantContext::set($this->tenant->id);
        PayApplication::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 1, 'period_from' => '2026-07-01', 'period_to' => '2026-07-31', 'status' => 'certified']);

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertSame('executed', $result['action']->status);
        $this->assertSame(2, PayApplication::count());
        TenantContext::clear();
    }

    public function test_superseding_back_to_approval_required_stops_the_next_detected_condition_from_auto_executing(): void
    {
        // Codex's acceptance case, part one: owner sets AUTO, later changes
        // it to APPROVAL_REQUIRED - a SUBSEQUENTLY detected rollforward must
        // be held for approval, not executed.
        $this->postJson('/api/autonomy-policies', $this->payload(level: AutonomyLevel::AUTO))->assertCreated();
        $this->postJson('/api/autonomy-policies', $this->payload(
            level: AutonomyLevel::APPROVAL_REQUIRED,
            reason: 'Reverting to manual pending review.',
        ))->assertCreated();

        TenantContext::set($this->tenant->id);
        PayApplication::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 1, 'period_from' => '2026-07-01', 'period_to' => '2026-07-31', 'status' => 'certified']);

        $result = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);

        $this->assertSame('pending_approval', $result['action']->status);
        $this->assertSame(1, PayApplication::count(), 'no shell should be created once the policy was reverted');
        TenantContext::clear();
    }

    public function test_superseding_a_policy_never_executes_anything_by_itself(): void
    {
        // A stale pending action (created under a stricter/no policy) must
        // stay exactly as it was when a LATER policy change loosens things -
        // executeIfStillAuthorized has to be invoked explicitly, never
        // triggered as a side effect of writing a new AutonomyPolicy row.
        TenantContext::set($this->tenant->id);
        PayApplication::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'number' => 1, 'period_from' => '2026-07-01', 'period_to' => '2026-07-31', 'status' => 'certified']);

        $pending = (new PayAppRollforwardEvaluator)->evaluateProject($this->tenant->id, $this->project->id);
        $this->assertSame('pending_approval', $pending['action']->status);
        TenantContext::clear();

        $this->postJson('/api/autonomy-policies', $this->payload(level: AutonomyLevel::AUTO))->assertCreated();

        TenantContext::set($this->tenant->id);
        $this->assertSame('pending_approval', $pending['action']->fresh()->status);
        $this->assertNull($pending['action']->fresh()->executed_change);
        $this->assertSame(1, PayApplication::count());
        TenantContext::clear();
    }

    // ---- helpers ------------------------------------------------------

    private function payload(
        string $actionType = PayAppRollforwardEvaluator::ACTION_TYPE,
        string $level = AutonomyLevel::AUTO,
        string $reason = 'Pilot customer requested automatic draft shells.',
    ): array {
        return [
            'project_id' => $this->project->id,
            'action_type' => $actionType,
            'autonomy_level' => $level,
            'reason' => $reason,
        ];
    }
}
