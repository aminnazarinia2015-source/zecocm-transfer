<?php

namespace Tests\Feature;

use Tests\TestCase;

/**
 * DatabaseSeeder granted the "field" seat (Dario Chavez, Frank Dominguez on
 * every real Zeco Inc. project) capabilities keyed 'daily_reports', 'rfis',
 * 'submittals', 'photos' - those are CapabilityCatalog/licensing keys, not
 * project-grant capability keys. ProjectAccess/ProjectGrant::allows() checks
 * literal strings like 'records.view', 'daily.create', 'rfi.create',
 * 'submittal.create', 'documents.view', 'media.upload' (see any controller's
 * ->authorize() calls) - none of which matched, so every action the seeder's
 * own comment says these two real employees should have was silently refused
 * in production. This locks the fixed keys in place.
 */
class SeederGrantsRealCapabilityKeysTest extends TestCase
{
    public function test_the_field_seat_seeded_for_dario_and_frank_uses_real_project_grant_capability_keys(): void
    {
        $php = file_get_contents(base_path('database/seeders/DatabaseSeeder.php'));
        $this->assertIsString($php);

        // The old, wrong keys must be gone from the field-seat grant entirely.
        foreach (["'daily_reports' => true", "'rfis' => true", "'submittals' => true", "'photos' => true"] as $wrong) {
            $this->assertStringNotContainsString($wrong, $php,
                "DatabaseSeeder must not grant '{$wrong}' - that is a licensing/catalogue key, not a real ProjectGrant capability string.");
        }
        // The real permission strings the controllers actually check must be present.
        foreach (['records.view', 'daily.create', 'rfi.create', 'submittal.create', 'documents.view', 'media.upload'] as $real) {
            $this->assertStringContainsString("'{$real}' => true", $php,
                "DatabaseSeeder's field-seat grant must include '{$real}' so Dario and Frank can actually do field work.");
        }
    }
}
