<?php

namespace Tests\Feature;

use App\Domain\Clocks\DeadlineExpression;
use App\Domain\Clocks\PayAppClocks;
use App\Domain\Payment\PayApplicationMath;
use App\Domain\Payment\PayApplicationReview;
use App\Domain\Payment\RetentionRule;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleOfValueItem;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use DateTimeImmutable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * The money path.
 *
 * PayAppClocks has implemented the two sequential statutory clocks since early on
 * with nothing to attach them to. This is the thing they attach to.
 *
 * Amounts are integer cents throughout. A retention calculation that drifts a
 * penny across forty lines gets the whole application rejected, and a rejected
 * application costs a payment cycle - on public work, a month of float the
 * contractor is financing.
 */
class PayApplicationTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_the_three_numbers_a_contractor_argues_about_are_each_shown_separately(): void
    {
        // $100,000 scheduled. $40,000 billed previously, $25,000 this period,
        // $5,000 of material sitting in the yard. 5% retention. $38,000 paid.
        $app = $this->application(retentionBasisPoints: 500);
        $this->line($app, scheduled: 10_000_000, previous: 4_000_000, thisPeriod: 2_500_000, stored: 500_000);

        $summary = PayApplicationMath::summarize($app, previouslyPaidCents: 3_800_000);

        $this->assertSame(6_500_000, $summary['total_completed_and_stored_cents'] - 500_000, 'earned work');
        $this->assertSame(7_000_000, $summary['total_completed_and_stored_cents']);
        // Retention reaches BOTH work and qualifying stored material: PCC s. 9203
        // measures the progress payment as 95% of each. 5% of $70,000.
        $this->assertSame(350_000, $summary['retention_cents']);
        $this->assertSame(6_650_000, $summary['earned_less_retention_cents']);
        $this->assertSame(2_850_000, $summary['current_payment_due_cents']);
        $this->assertSame(7000, $summary['percent_complete_basis_points'], '70.00% complete');
    }

    public function test_retention_reaches_stored_materials_under_the_statute(): void
    {
        // This test asserted the opposite until Codex checked it against Public
        // Contract Code s. 9203, which limits a progress payment to 95% of work
        // performed AND 95% of qualifying delivered or stored material. The
        // hardcoded exemption withheld too little - and withholding the wrong
        // amount in the contractor's favour is still the wrong amount, because the
        // application will not reconcile against the agency's own arithmetic.
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, previous: 0, thisPeriod: 0, stored: 1_000_000);

        $summary = PayApplicationMath::summarize($app, retention: RetentionRule::californiaPublicWorksDefault());

        $this->assertSame(50_000, $summary['retention_cents']);
        $this->assertSame(950_000, $summary['earned_less_retention_cents']);
    }

    public function test_a_contract_may_exempt_stored_materials_but_only_by_saying_so(): void
    {
        // Some contracts do exempt stored material. That is a contract term with a
        // clause behind it, not a default anyone gets to assume.
        $rule = RetentionRule::fromProjectTerms([
            'basis_points' => 500,
            'source' => 'General Conditions 9.3.2',
            'applies_to_stored_materials' => false,
            'confirmed' => true,
        ]);

        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, previous: 0, thisPeriod: 0, stored: 1_000_000);

        $this->assertSame(0, PayApplicationMath::summarize($app, retention: $rule)['retention_cents']);
    }

    public function test_no_retention_rule_is_invented_when_the_project_recorded_none(): void
    {
        $this->assertNull(RetentionRule::fromProjectTerms(null));
        $this->assertNull(RetentionRule::fromProjectTerms(['basis_points' => 500]));
    }

    public function test_a_retention_rate_must_name_where_it_came_from(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        new RetentionRule(500, '');
    }

    public function test_the_statutory_default_arrives_cited_and_unconfirmed(): void
    {
        $rule = RetentionRule::californiaPublicWorksDefault();

        $this->assertFalse($rule->confirmed, 'A statutory default must be confirmed against the contract before it is relied on.');
        $this->assertStringContainsString('7201', $rule->source);
        $this->assertTrue($rule->appliesToStoredMaterials);
        $this->assertFalse($rule->exceedsStatutoryCap());
        $this->assertTrue((new RetentionRule(1000, 'GC 9.3'))->exceedsStatutoryCap());
    }

    public function test_retention_never_rounds_against_the_contractor(): void
    {
        // 5% of $333.33 is $16.6665. Truncating withholds $16.66, not $16.67.
        // Never withhold a fraction of a cent you cannot justify.
        $app = $this->application(retentionBasisPoints: 500);
        $this->line($app, scheduled: 100_000, previous: 0, thisPeriod: 33_333, stored: 0);

        $this->assertSame(1_666, PayApplicationMath::summarize($app)['retention_cents']);
    }

    public function test_billing_a_line_above_its_scheduled_value_is_refused_with_the_amount(): void
    {
        // The single most common reason an agency bounces an application.
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, previous: 8_000_000, thisPeriod: 3_000_000, stored: 0);

        $refusals = PayApplicationMath::submissionRefusals($app);

        $this->assertNotEmpty($refusals);
        $this->assertStringContainsString('$10,000.00 above its scheduled value', $refusals[0]);
        $this->assertStringContainsString('change order', $refusals[0]);
    }

    public function test_an_empty_application_and_a_backwards_period_are_both_refused(): void
    {
        $empty = $this->application();
        $this->line($empty, scheduled: 10_000_000, previous: 0, thisPeriod: 0, stored: 0);
        $this->assertContains('Nothing is billed on this application.',
            PayApplicationMath::submissionRefusals($empty));

        $backwards = $this->application(from: '2026-08-31', to: '2026-08-01');
        $this->line($backwards, scheduled: 10_000_000, previous: 0, thisPeriod: 100_000, stored: 0);
        $this->assertContains('The billing period ends before it begins.',
            PayApplicationMath::submissionRefusals($backwards));
    }

    public function test_a_clean_application_has_nothing_to_refuse(): void
    {
        $app = $this->application();
        $this->line($app, scheduled: 10_000_000, previous: 0, thisPeriod: 2_500_000, stored: 0);

        $this->assertSame([], PayApplicationMath::submissionRefusals($app));
    }

    public function test_the_payment_clock_anchors_at_approval_and_the_statutory_backstop_at_submission(): void
    {
        // The two clocks are SEQUENTIAL and anchored to different events. Running
        // the payment clock from submission is how a contractor believes it is
        // owed money weeks before it is.
        $clocks = new PayAppClocks(
            review: new DeadlineExpression(7, DeadlineExpression::BASIS_CALENDAR),
            payment: new DeadlineExpression(30, DeadlineExpression::BASIS_CALENDAR),
            statutoryBackstopCalendarDays: 39,
            backstopCitation: 'Public Contract Code s. 20104.50',
        );

        $submitted = new DateTimeImmutable('2026-08-01');
        $approved = new DateTimeImmutable('2026-08-06');

        $this->assertSame('2026-08-08', $clocks->reviewDue($submitted)->format('Y-m-d'));
        $this->assertSame('2026-09-05', $clocks->paymentDue($approved)->format('Y-m-d'));
        $this->assertSame('2026-09-09', $clocks->backstopDeemedApprovedAt($submitted)->format('Y-m-d'));
    }

    public function test_no_statutory_backstop_is_asserted_when_none_was_confirmed(): void
    {
        // Same rule as every other clock in this system: never invent a period.
        $clocks = new PayAppClocks(
            review: new DeadlineExpression(7, DeadlineExpression::BASIS_CALENDAR),
            payment: new DeadlineExpression(30, DeadlineExpression::BASIS_CALENDAR),
        );

        $this->assertNull($clocks->backstopDeemedApprovedAt(new DateTimeImmutable('2026-08-01')));
    }

    private function application(int $retentionBasisPoints = 500, string $from = '2026-08-01', string $to = '2026-08-31'): PayApplication
    {
        static $n = 0;
        $n++;

        return PayApplication::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'number' => $n,
            'period_from' => $from,
            'period_to' => $to,
            'retention_basis_points' => $retentionBasisPoints,
        ]);
    }

    private function line(PayApplication $app, int $scheduled, int $previous, int $thisPeriod, int $stored): void
    {
        static $i = 0;
        $i++;

        $item = ScheduleOfValueItem::create([
            'tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id,
            'item_number' => str_pad((string) $i, 3, '0', STR_PAD_LEFT),
            'description' => 'Line item '.$i,
            'scheduled_value_cents' => $scheduled,
            'original_value_cents' => $scheduled,
        ]);

        PayApplicationLine::create([
            'tenant_id' => $this->tenant->id,
            'pay_application_id' => $app->id,
            'schedule_of_value_item_id' => $item->id,
            'previous_completed_cents' => $previous,
            'this_period_cents' => $thisPeriod,
            'stored_materials_cents' => $stored,
        ]);

        $app->load('lines.item');
    }
}
