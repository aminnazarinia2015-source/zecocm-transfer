<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * "Staff & permissions" was a hardcoded roadmap stub with zero backing
 * route - PlatformStaffController is the real thing. Deliberately
 * admin-only and deliberately careful about self-demotion/self-revocation,
 * since a platform_role of 'admin' reaches every tenant's data.
 */
class PlatformStaffManagementTest extends TestCase
{
    use RefreshDatabase;

    private User $platformAdmin;
    private User $technician;
    private User $customerUser;

    protected function setUp(): void
    {
        parent::setUp();
        $this->platformAdmin = User::create(['tenant_id' => null, 'name' => 'Amin', 'email' => 'admin@zecocm.test', 'password' => bcrypt('password'), 'platform_role' => 'admin']);
        $this->technician = User::create(['tenant_id' => null, 'name' => 'Tech', 'email' => 'tech@zecocm.test', 'password' => bcrypt('password'), 'platform_role' => 'technician', 'platform_permissions' => []]);
        $this->customerUser = User::create(['tenant_id' => null, 'name' => 'Customer', 'email' => 'customer@zecocm.test', 'password' => bcrypt('password')]);
    }

    public function test_a_platform_admin_can_list_staff(): void
    {
        Sanctum::actingAs($this->platformAdmin);

        $body = $this->getJson('/api/platform/staff')->assertOk()->json();

        $this->assertCount(2, $body['staff']);
    }

    public function test_a_non_admin_cannot_list_staff(): void
    {
        Sanctum::actingAs($this->technician);
        $this->getJson('/api/platform/staff')->assertStatus(403);

        Sanctum::actingAs($this->customerUser);
        $this->getJson('/api/platform/staff')->assertStatus(403);
    }

    public function test_a_platform_admin_can_add_a_new_technician_with_a_temp_password(): void
    {
        Sanctum::actingAs($this->platformAdmin);

        $body = $this->postJson('/api/platform/staff', [
            'name' => 'New Tech', 'email' => 'newtech@zecocm.test', 'platform_role' => 'technician',
            'platform_permissions' => ['create_customers' => true],
        ])->assertCreated()->json();

        $this->assertNotEmpty($body['temp_password']);
        $this->assertSame('technician', $body['staff']['platform_role']);
        $this->assertDatabaseHas('users', ['email' => 'newtech@zecocm.test', 'tenant_id' => null]);
    }

    public function test_an_admin_cannot_revoke_their_own_platform_access(): void
    {
        Sanctum::actingAs($this->platformAdmin);

        $this->postJson('/api/platform/staff/' . $this->platformAdmin->id . '/revoke')->assertStatus(422);
    }

    public function test_revoking_a_technician_clears_their_platform_role(): void
    {
        Sanctum::actingAs($this->platformAdmin);

        $this->postJson('/api/platform/staff/' . $this->technician->id . '/revoke')->assertOk();

        $this->assertDatabaseHas('users', ['id' => $this->technician->id, 'platform_role' => null]);
    }

    public function test_a_regular_customer_user_is_not_platform_staff_and_cannot_be_managed_here(): void
    {
        Sanctum::actingAs($this->platformAdmin);

        $this->putJson('/api/platform/staff/' . $this->customerUser->id, ['platform_role' => 'technician'])
            ->assertStatus(404);
    }
}
