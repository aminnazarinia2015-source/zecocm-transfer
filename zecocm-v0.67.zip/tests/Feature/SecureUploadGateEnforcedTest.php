<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\MediaItem;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * SEC-5, end to end: the gate is not just a unit-testable class, it is
 * actually in the request path of all three upload controllers. These tests
 * go through real HTTP requests rather than calling SecureUploadGate
 * directly, so a controller that quietly stopped calling admit() (or called
 * it and ignored the verdict) would fail here even though the unit tests
 * still pass.
 */
class SecureUploadGateEnforcedTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'photos', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'documents', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function fakeExecutable(string $name): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'sec5feat');
        file_put_contents($path, "\x7FELF".str_repeat("\x00", 32));

        return new UploadedFile($path, $name, 'application/octet-stream', null, true);
    }

    private function realPdf(string $name): UploadedFile
    {
        $path = tempnam(sys_get_temp_dir(), 'sec5feat');
        file_put_contents($path, "%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF");

        return new UploadedFile($path, $name, 'application/pdf', null, true);
    }

    // ---- MediaController::store() ---------------------------------------------

    public function test_media_upload_rejects_a_disallowed_file_and_creates_no_row(): void
    {
        $before = MediaItem::withoutGlobalScopes()->count();

        $response = $this->postJson('/api/media', [
            'project_id' => $this->project->id,
            'file' => $this->fakeExecutable('field-note.exe'),
        ]);

        $response->assertStatus(422);
        $this->assertSame($before, MediaItem::withoutGlobalScopes()->count());
    }

    public function test_media_upload_admits_a_real_pdf_and_marks_it_clean(): void
    {
        $response = $this->postJson('/api/media', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf('site-photo.pdf'),
        ]);

        $response->assertStatus(201);
        $item = MediaItem::withoutGlobalScopes()->latest('id')->first();
        $this->assertNotNull($item);
        $this->assertSame('clean', $item->malware_scan_status);
        $this->assertStringContainsString('sealed', $item->storage_path);
    }

    // ---- DocumentLibraryController::store() ------------------------------------

    public function test_document_library_upload_rejects_a_disallowed_file_and_creates_no_row(): void
    {
        $before = DB::table('knowledge_sources')->count();

        $response = $this->postJson('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->fakeExecutable('spec.pdf'),
        ]);

        $response->assertStatus(422);
        $this->assertSame($before, DB::table('knowledge_sources')->count());
    }

    public function test_document_library_upload_admits_a_real_pdf(): void
    {
        $response = $this->postJson('/api/document-library/documents', [
            'project_id' => $this->project->id,
            'file' => $this->realPdf('spec.pdf'),
        ]);

        $response->assertStatus(201);
    }
}
