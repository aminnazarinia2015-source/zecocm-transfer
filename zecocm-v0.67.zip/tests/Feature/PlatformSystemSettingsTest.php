<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The old "System settings" nav item was a hardcoded fail-closed placeholder with no backend at
 * all. This replaces it with a real, read-only status screen for the integrations this deploy
 * actually depends on (payment providers, mail) - live config() reads, never sample values, so
 * an admin can check whether keys they just added actually took effect without shelling in.
 */
class PlatformSystemSettingsTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::create(['name' => 'Amin', 'email' => 'amin@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'admin']);
    }

    public function test_platform_staff_sees_the_real_unconfigured_state_in_this_test_environment(): void
    {
        Sanctum::actingAs($this->admin());

        $res = $this->getJson('/api/platform/system-settings')->assertOk();

        $this->assertFalse($res->json('payment.stripe.configured'));
        $this->assertFalse($res->json('payment.paypal.configured'));
        $this->assertFalse($res->json('mail.sends_real_mail'));
        $this->assertContains($res->json('mail.driver'), ['log', 'array']);
    }

    public function test_reflects_stripe_configuration_once_keys_are_set(): void
    {
        config([
            'services.stripe.secret_key' => 'sk_test_x',
            'services.stripe.webhook_secret' => 'whsec_x',
            'services.stripe.price_id_field' => 'price_field',
        ]);
        Sanctum::actingAs($this->admin());

        $res = $this->getJson('/api/platform/system-settings')->assertOk();

        $this->assertTrue($res->json('payment.stripe.configured'));
        $this->assertTrue($res->json('payment.stripe.webhook_secret_set'));
        $this->assertTrue($res->json('payment.stripe.plans.field'));
        $this->assertFalse($res->json('payment.stripe.plans.project'));
    }

    public function test_never_exposes_the_actual_secret_values(): void
    {
        config(['services.stripe.secret_key' => 'sk_test_super_secret_value']);
        Sanctum::actingAs($this->admin());

        $res = $this->getJson('/api/platform/system-settings')->assertOk();

        $this->assertStringNotContainsString('sk_test_super_secret_value', $res->getContent());
    }

    public function test_a_non_staff_user_is_refused(): void
    {
        $tenant = \App\Models\Tenant::create(['name' => 'X', 'type' => 'Contractor', 'entitlements' => [], 'status' => 'active']);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'U', 'email' => 'u@x.test', 'password' => bcrypt('x')]);
        Sanctum::actingAs($user);

        $this->getJson('/api/platform/system-settings')->assertStatus(403);
    }

    public function test_an_unauthenticated_request_is_refused(): void
    {
        $this->getJson('/api/platform/system-settings')->assertStatus(401);
    }
}
