<?php

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Suspending a customer account is deliberately NOT a delete - the platform's
 * core invariant is that nothing is silently erased. Suspending only blocks
 * that tenant's users from signing in; it's fully reversible and touches no
 * project data. Prompted by Amin finding there was no way at all to retire a
 * test customer he created while trying the platform live.
 */
class CustomerStatusTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function admin(): User
    {
        return User::create(['name' => 'Amin', 'email' => 'amin@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'admin']);
    }

    private function technician(): User
    {
        return User::create(['name' => 'Tech', 'email' => 'tech@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'technician']);
    }

    private function tenantWithUser(string $status = 'active'): array
    {
        $tenant = Tenant::create(['name' => 'Testco', 'type' => 'Contractor', 'status' => $status,
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'Casey', 'email' => 'casey@testco.test', 'password' => bcrypt('secret123')]);

        return [$tenant, $user];
    }

    /** The platform admin can suspend a customer - no projects/users are touched. */
    public function test_admin_can_suspend_a_customer(): void
    {
        [$tenant] = $this->tenantWithUser('active');
        Sanctum::actingAs($this->admin());

        $response = $this->putJson("/api/platform/customers/{$tenant->id}/status", ['status' => 'suspended']);
        $response->assertOk();
        $this->assertSame('suspended', $tenant->fresh()->status);
    }

    /** Suspending is reversible - the admin can set it straight back to active. */
    public function test_admin_can_reactivate_a_suspended_customer(): void
    {
        [$tenant] = $this->tenantWithUser('suspended');
        Sanctum::actingAs($this->admin());

        $response = $this->putJson("/api/platform/customers/{$tenant->id}/status", ['status' => 'active']);
        $response->assertOk();
        $this->assertSame('active', $tenant->fresh()->status);
    }

    /** A technician (platform staff but not admin) cannot change account status. */
    public function test_technician_cannot_change_customer_status(): void
    {
        [$tenant] = $this->tenantWithUser('active');
        Sanctum::actingAs($this->technician());

        $response = $this->putJson("/api/platform/customers/{$tenant->id}/status", ['status' => 'suspended']);
        $response->assertStatus(403);
        $this->assertSame('active', $tenant->fresh()->status);
    }

    /** An invalid status value is rejected outright. */
    public function test_invalid_status_value_is_rejected(): void
    {
        [$tenant] = $this->tenantWithUser('active');
        Sanctum::actingAs($this->admin());

        $response = $this->putJson("/api/platform/customers/{$tenant->id}/status", ['status' => 'deleted']);
        $response->assertStatus(422);
    }

    /** A user whose tenant is suspended cannot sign in. */
    public function test_user_of_a_suspended_tenant_cannot_log_in(): void
    {
        [, $user] = $this->tenantWithUser('suspended');

        $response = $this->postJson('/api/login', ['email' => $user->email, 'password' => 'secret123']);
        $response->assertStatus(403);
    }

    /** Once reactivated, that same user can sign in normally again. */
    public function test_user_of_a_reactivated_tenant_can_log_in(): void
    {
        [$tenant, $user] = $this->tenantWithUser('suspended');
        $tenant->update(['status' => 'active']);

        $response = $this->postJson('/api/login', ['email' => $user->email, 'password' => 'secret123']);
        $response->assertOk();
        $response->assertJsonStructure(['token', 'user']);
    }

    /** Platform staff have no tenant_id and are never blocked by tenant suspension. */
    public function test_platform_admin_login_is_unaffected_by_any_tenant_suspension(): void
    {
        $this->tenantWithUser('suspended');
        $admin = $this->admin();

        $response = $this->postJson('/api/login', ['email' => $admin->email, 'password' => 'x']);
        $response->assertOk();
    }
}
