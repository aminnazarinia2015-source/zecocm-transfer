<?php

namespace Tests\Feature;

use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Adversarial "what if" pass on the three features built this session:
 *
 *  1. PlatformController::updateCustomer() gaining admin_name/admin_email editing.
 *  2. PlatformController::deleteCustomer() (backend unchanged, re-verified).
 *  3. PlatformAssistant + AssistController's routing to it.
 *
 * Most of what was tried here already held correctly (documented in each test's own
 * comment where relevant) - only one real bug turned up, covered by the first test.
 */
class AdversarialNewFeaturesRound7Test extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private User $technician;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::create(['tenant_id' => null, 'name' => 'Platform Admin',
            'email' => 'admin@zecocm.test', 'password' => bcrypt('password'), 'platform_role' => 'admin']);

        $this->technician = User::create(['tenant_id' => null, 'name' => 'Tech One',
            'email' => 'tech@zecocm.test', 'password' => bcrypt('password'), 'platform_role' => 'technician',
            'platform_permissions' => []]);
    }

    // ---------------------------------------------------------------
    // BUG FOUND & FIXED: updateCustomer() was not atomic. $tenant->update($data)
    // ran BEFORE the admin_email uniqueness check, so a request that legitimately
    // changed tenant fields (name, type, etc.) alongside an admin_email that was
    // already taken would abort(422, ...) for the email - but the tenant field
    // change had already been persisted to the database. The caller saw a 422
    // "failed" response while the tenant's name silently changed anyway. Fixed by
    // wrapping the tenant update + admin-contact update in a single DB::transaction
    // so any abort() inside it rolls back everything, not just the admin fields.
    // ---------------------------------------------------------------

    public function test_a_rejected_admin_email_change_rolls_back_the_tenant_field_changes_too(): void
    {
        $tenant = Tenant::create(['name' => 'Old Name Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        User::create(['tenant_id' => $tenant->id, 'name' => 'First', 'email' => 'first@rollback.test',
            'password' => bcrypt('password')]);
        User::create(['tenant_id' => null, 'name' => 'Other', 'email' => 'taken@zecocm.test',
            'password' => bcrypt('password'), 'platform_role' => 'technician', 'platform_permissions' => []]);

        Sanctum::actingAs($this->admin);

        $res = $this->putJson('/api/platform/customers/'.$tenant->id, [
            'name' => 'New Name Co',
            'type' => 'Owner',
            'admin_email' => 'taken@zecocm.test',
        ]);

        $res->assertStatus(422);
        $tenant->refresh();
        $this->assertSame('Old Name Co', $tenant->name, 'tenant name must not persist when the request as a whole failed');
        $this->assertSame('Contractor', $tenant->type);
    }

    public function test_a_rejected_admin_contact_edit_on_a_tenant_with_no_admin_user_also_rolls_back_tenant_fields(): void
    {
        $tenant = Tenant::create(['name' => 'No Admin Yet', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);

        Sanctum::actingAs($this->admin);

        $res = $this->putJson('/api/platform/customers/'.$tenant->id, [
            'name' => 'Renamed While Broken',
            'admin_name' => 'Someone',
        ]);

        $res->assertStatus(422);
        $tenant->refresh();
        $this->assertSame('No Admin Yet', $tenant->name);
    }

    // ---------------------------------------------------------------
    // Already correct - re-verified live, no fix needed for any of these.
    // ---------------------------------------------------------------

    /** Multiple users on one tenant: the edit must land on the oldest-by-id row,
     * matching the same "who counts as the admin" convention customers() uses. */
    public function test_editing_admin_contact_on_a_multi_user_tenant_hits_the_oldest_user_only(): void
    {
        $tenant = Tenant::create(['name' => 'Multi User Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $first = User::create(['tenant_id' => $tenant->id, 'name' => 'First', 'email' => 'first@multi.test',
            'password' => bcrypt('password')]);
        $second = User::create(['tenant_id' => $tenant->id, 'name' => 'Second', 'email' => 'second@multi.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($this->admin);
        $res = $this->putJson('/api/platform/customers/'.$tenant->id, ['admin_name' => 'Changed']);
        $res->assertOk();

        $first->refresh();
        $second->refresh();
        $this->assertSame('Changed', $first->name);
        $this->assertSame('Second', $second->name);
    }

    /** Setting admin_email to the tenant's own existing admin email must be a no-op,
     * not a false "already in use by another account" 422. */
    public function test_setting_admin_email_to_its_own_current_value_is_a_silent_no_op(): void
    {
        $tenant = Tenant::create(['name' => 'Same Email Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        User::create(['tenant_id' => $tenant->id, 'name' => 'Owner', 'email' => 'owner@same.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($this->admin);
        $res = $this->putJson('/api/platform/customers/'.$tenant->id, ['admin_email' => 'owner@same.test']);

        $res->assertOk();
        $this->assertSame('owner@same.test', $res->json('admin_email'));
    }

    /** An empty-string admin_email/admin_name is normalised to null by
     * ConvertEmptyStringsToNull and must be treated as "not supplied", not as a
     * request to blank out the contact's real name/email. */
    public function test_empty_string_admin_fields_do_not_wipe_the_existing_contact(): void
    {
        $tenant = Tenant::create(['name' => 'Empty String Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $tenant->id, 'name' => 'Keep Me', 'email' => 'keep@empty.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($this->admin);
        $res = $this->putJson('/api/platform/customers/'.$tenant->id, ['admin_name' => '', 'admin_email' => '']);

        $res->assertOk();
        $user->refresh();
        $this->assertSame('Keep Me', $user->name);
        $this->assertSame('keep@empty.test', $user->email);
    }

    /** A platform technician (non-admin) must still be refused both mutating
     * endpoints - the frontend's new type-to-confirm dialog is not a security
     * boundary, the backend isPlatformAdmin() gate is. */
    public function test_technician_cannot_update_or_delete_a_customer_directly_via_the_api(): void
    {
        $tenant = Tenant::create(['name' => 'Guarded Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        User::create(['tenant_id' => $tenant->id, 'name' => 'Owner', 'email' => 'owner@guarded.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($this->technician);

        $this->putJson('/api/platform/customers/'.$tenant->id, ['admin_name' => 'Hijacked'])->assertStatus(403);
        $this->deleteJson('/api/platform/customers/'.$tenant->id)->assertStatus(403);

        $tenant->refresh();
        $this->assertSame('Guarded Co', $tenant->name);
        $this->assertNotNull(Tenant::find($tenant->id));
    }

    /** deleteCustomer() still cascades ALL users for the tenant (not just the
     * "admin" row), and still refuses when the tenant has any project. */
    public function test_delete_customer_cascades_every_user_and_still_refuses_when_projects_exist(): void
    {
        $tenant = Tenant::create(['name' => 'Deletable Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        User::create(['tenant_id' => $tenant->id, 'name' => 'First', 'email' => 'first@deletable.test',
            'password' => bcrypt('password')]);
        User::create(['tenant_id' => $tenant->id, 'name' => 'Second', 'email' => 'second@deletable.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($this->admin);
        $res = $this->deleteJson('/api/platform/customers/'.$tenant->id);
        $res->assertOk();
        $this->assertSame(0, User::where('tenant_id', $tenant->id)->count());
        $this->assertNull(Tenant::find($tenant->id));

        $blockedTenant = Tenant::create(['name' => 'Has Project Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        Project::create(['tenant_id' => $blockedTenant->id, 'number' => 'P-1', 'name' => 'Real Project',
            'sector' => 'public', 'owner_name' => 'City', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);

        $blockedRes = $this->deleteJson('/api/platform/customers/'.$blockedTenant->id);
        $blockedRes->assertStatus(422);
        $this->assertNotNull(Tenant::find($blockedTenant->id));
    }

    /** A tenant/customer user can never reach PlatformAssistant, even when the
     * question text matches its keyword patterns - gated on isPlatformStaff(),
     * verified with a real HTTP request rather than just reading the code. */
    public function test_tenant_user_asking_a_platform_stats_question_gets_ordinary_help_not_platform_stats(): void
    {
        $tenant = Tenant::create(['name' => 'Customer Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $customer = User::create(['tenant_id' => $tenant->id, 'name' => 'Cust', 'email' => 'cust@customer.test',
            'password' => bcrypt('password')]);

        Sanctum::actingAs($customer);
        $res = $this->postJson('/api/assist', ['question' => 'how many customers are active in total']);

        $res->assertOk();
        $this->assertNotSame('Platform snapshot', $res->json('answer.0.title'));
    }

    /** A non-admin platform technician still gets platform stats answers -
     * isPlatformStaff() covers both roles, only mutations are admin-only. */
    public function test_technician_can_still_get_platform_stats_answers(): void
    {
        $tenant = Tenant::create(['name' => 'Stats Co', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);

        Sanctum::actingAs($this->technician);
        $res = $this->postJson('/api/assist', ['question' => 'give me a snapshot of customers and projects']);

        $res->assertOk();
        $this->assertSame('Platform snapshot', $res->json('answer.0.title'));
    }

    /** SQL-special characters in the question are inert - the string is only ever
     * used for keyword regex matching, never interpolated into a query. */
    public function test_sql_special_characters_in_the_question_are_totally_inert(): void
    {
        Sanctum::actingAs($this->admin);

        $res = $this->postJson('/api/assist', [
            'question' => "how many customers'; DROP TABLE users;-- and projects do we have",
        ]);

        $res->assertOk();
        $this->assertSame(2, User::count(), 'the admin fixture user plus nothing else - no table was touched');
    }

    /** Zero tenants/projects in the database: report clean zeros, no crash, no
     * divide-by-zero. */
    public function test_zero_tenants_and_projects_reports_clean_zeros(): void
    {
        Sanctum::actingAs($this->technician);

        $res = $this->postJson('/api/assist', ['question' => 'how many customers do we have in total']);

        $res->assertOk();
        $this->assertStringContainsString('0 total', $res->json('answer.0.body'));
    }

    /** A 2000-char (validation max) garbage question does not error. */
    public function test_a_maximum_length_garbage_question_does_not_error(): void
    {
        Sanctum::actingAs($this->admin);
        $garbage = substr(str_repeat('how many customers projects active zz ', 60), 0, 2000);

        $res = $this->postJson('/api/assist', ['question' => $garbage]);

        $res->assertOk();
    }
}
