<?php

namespace Tests\Feature;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\AiResult;
use App\Domain\Ai\AiRunLedger;
use App\Domain\Ai\Citation;
use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\NoMatch;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Ai\RetrievalClient;
use App\Domain\Ai\RetrievalTraceWriter;
use App\Domain\Ai\RetrievedPassage;
use App\Domain\Licensing\CapabilityLicense;
use App\Jobs\RunGovernedAi;
use App\Models\AiRun;
use App\Models\KnowledgePassage;
use App\Models\KnowledgeSource;
use App\Models\KnowledgeSourceVersion;
use App\Models\Membership;
use App\Models\Project;
use App\Models\RetrievalTrace;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * TR-18: a retrieval that cannot be reconstructed afterward is a black box,
 * and "trust the model's own account of what it did" is exactly the failure
 * mode Codex's ruling exists to close. These tests prove the structured
 * retrieval_trace answers Codex's five questions from stored data alone -
 * never from re-running the model, never from free text - and that the
 * trace itself cannot leak what an unauthorized viewer could not otherwise
 * read.
 */
class RetrievalTraceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        $user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_a_successful_retrieval_records_query_stage_and_candidate_facts(): void
    {
        // What ran, what survived, and what it looked like - all four of
        // Codex's structural questions except "why cited over other
        // survivors", which the writer test below covers separately.
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA',
            'Irrigation mainline trench depth shall be 24 in below finish grade.');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $found = $this->retrieveVia($retriever, 'irrigation mainline trench depth');
        $this->assertNotEmpty($found, 'Fixture query returned nothing; trace assertions below would be vacuous.');

        $trace = $retriever->lastTrace()->toArray();

        $this->assertSame(1, $trace['sql_candidate_count']);
        $this->assertNotEmpty($trace['final_candidates']);
        $candidate = $trace['final_candidates'][0];
        $this->assertArrayHasKey('source_public_id', $candidate);
        $this->assertArrayHasKey('version_number', $candidate);
        $this->assertArrayHasKey('ordinal', $candidate);
        $this->assertArrayHasKey('body_hash', $candidate);
        $this->assertArrayHasKey('lexical_score', $candidate);
        $this->assertArrayHasKey('operative_state', $candidate);
        $this->assertSame('current', $candidate['operative_state']);
        $this->assertTrue($trace['authorization_state']['authorized_evidence_read']);
        $this->assertSame($this->project->id, $trace['authorization_state']['project_id']);

        // Never the passage body - only locators and facts about it.
        $encoded = json_encode($trace);
        $this->assertStringNotContainsString('trench depth shall be 24 in', $encoded);
    }

    public function test_a_jurisdiction_mismatch_is_excluded_with_a_named_reason(): void
    {
        // Why a candidate did NOT survive is exactly as much a structural
        // fact as why one did.
        TenantContext::set($this->tenant->id);
        $this->seedSource('regulation', 'Nevada Public Works Code', 'NV',
            'Excavation trenches deeper than 5 ft require shoring.', collection: 'regulatory');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'excavation trenches require shoring');
        $trace = $retriever->lastTrace()->toArray();

        $reasons = [];
        foreach ($trace['stages'] as $stage) {
            foreach ($stage['excluded'] as $exclusion) {
                $reasons[] = $exclusion['reason'];
            }
        }
        $this->assertContains('jurisdiction', $reasons,
            'A source licensed for a different state was not recorded as excluded for jurisdiction.');
    }

    public function test_a_superseded_passage_is_recorded_with_its_operative_state_and_replacement(): void
    {
        TenantContext::set($this->tenant->id);
        $old = $this->seedSource('addendum', 'Addendum No. 2', 'CA', 'Trench depth shall be 24 in.');
        $new = $this->seedSource('addendum', 'Addendum No. 3', 'CA', 'Trench depth shall be 36 in.');
        DB::table('knowledge_source_edges')->insert([
            'tenant_id' => $this->tenant->id, 'from_version_id' => $new, 'to_version_id' => $old,
            'relationship' => 'supersedes', 'status' => 'confirmed', 'confirmed_by' => 1,
            'confirmed_at' => now(), 'created_at' => now(), 'updated_at' => now(),
        ]);
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'trench depth');
        $trace = $retriever->lastTrace()->toArray();

        $stale = collect($trace['final_candidates'])->firstWhere('operative_state', 'superseded');
        $this->assertNotNull($stale, 'The superseded candidate was not present in final_candidates at all.');
        $this->assertSame('Addendum No. 3', $stale['superseded_by']);
        $this->assertFalse($stale['controls_answer']);
    }

    public function test_an_unauthorized_retrieval_records_no_candidates_at_all(): void
    {
        // The gate fails closed, and the trace of a gate closing must say
        // exactly that - not merely be silent about it.
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', false);

        $retriever = new HybridKnowledgeRetriever;
        $found = $retriever->retrieve('trench depth', $this->project->jurisdictionScope());
        TenantContext::clear();

        $this->assertSame([], $found);
        $trace = $retriever->lastTrace()->toArray();
        $this->assertFalse($trace['authorization_state']['authorized_evidence_read']);
        $this->assertSame(0, $trace['sql_candidate_count']);
        $this->assertSame([], $trace['stages']);
        $this->assertSame([], $trace['final_candidates']);
    }

    public function test_a_no_match_result_still_gets_a_trace_written(): void
    {
        // "Nothing survived" is itself evidence of what happened and must be
        // reconstructable exactly like a cited answer is.
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'unrelated question about paint colors');

        $trace = RetrievalTraceWriter::write(
            $retriever->lastTrace(), 'unrelated question about paint colors',
            $this->tenant->id, $this->project->id, null, new NoMatch('project_specs'),
        );

        $this->assertSame('no_match', $trace->result_kind);
        $this->assertSame([], $trace->passages_cited);
    }

    public function test_a_cited_suggestion_records_only_the_passages_actually_cited(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'trench depth');

        $citation = new Citation(
            source: 'Spec 32 84 00', edition: '2026', retrievedAt: new \DateTimeImmutable,
            sourcePublicId: 'src-public-1', versionNumber: 1, ordinal: 1, bodyHash: str_repeat('b', 64),
        );
        $trace = RetrievalTraceWriter::write(
            $retriever->lastTrace(), 'trench depth', $this->tenant->id, $this->project->id, null,
            new CitedSuggestion('Trench depth shall be 24 in.', [$citation]),
        );

        $this->assertSame('suggestion', $trace->result_kind);
        $this->assertCount(1, $trace->passages_cited);
        $this->assertSame('Spec 32 84 00', $trace->passages_cited[0]['source']);
        $this->assertNotNull($trace->passages_cited[0]['anchor']);
    }

    public function test_writing_an_incomplete_trace_directly_uses_the_model_failed_sentinel(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'trench depth');

        $trace = RetrievalTraceWriter::writeIncomplete(
            $retriever->lastTrace(), 'trench depth', $this->tenant->id, $this->project->id, null,
        );

        $this->assertSame('model_failed', $trace->result_kind);
        $this->assertSame([], $trace->passages_cited);
        $this->assertNull($trace->escalation_basis);
        $this->assertNotEmpty($trace->final_candidates, 'The retrieval facts themselves were lost, not just the model outcome.');
    }

    public function test_a_retrieval_trace_still_exists_when_the_model_call_fails_after_retrieval_succeeds(): void
    {
        // TR-18, Codex's second finding: retrieval already happened by the
        // time anything downstream can fail, and its trace must survive that
        // failure. This runs the real RunGovernedAi::handle() with a fake
        // AiAssistant that performs the SAME retrieval a real one would, then
        // throws - simulating an unexpected failure ClaudeAssistant's own
        // error handling does not already convert into an Escalation.
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        $run = AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'requested_by' => User::where('email', 'rita@northgate.test')->firstOrFail()->id,
            'public_id' => (string) Str::uuid(), 'idempotency_key' => Str::uuid(), 'task_type' => 'answer',
            'category' => 'general_administration', 'question' => 'trench depth', 'status' => 'queued',
            'provider' => 'test', 'model' => 'test-model', 'prompt_version' => 'v1',
            'retrieval_version' => HybridKnowledgeRetriever::VERSION, 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
        ]);
        TenantContext::clear();

        $failingAssistant = new class implements AiAssistant
        {
            public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): AiResult
            {
                app(RetrievalClient::class)->retrieve($task, $scope);
                throw new \RuntimeException('simulated unexpected failure after retrieval');
            }
        };

        try {
            (new RunGovernedAi($run->id))->handle($failingAssistant, app(AiRunLedger::class));
            $this->fail('Expected the simulated failure to propagate.');
        } catch (\RuntimeException $e) {
            $this->assertSame('simulated unexpected failure after retrieval', $e->getMessage());
        }

        // handle()'s own finally block clears TenantContext on the way out,
        // and RetrievalTrace's fail-closed tenant scope matches nothing
        // without one - re-establish it purely to read back what was written.
        TenantContext::set($this->tenant->id);
        $trace = RetrievalTrace::query()->where('ai_run_id', $run->id)->first();
        TenantContext::clear();
        $this->assertNotNull($trace, 'Retrieval succeeded but its trace was lost when the model call failed.');
        $this->assertSame('model_failed', $trace->result_kind);
        $this->assertNotEmpty($trace->final_candidates);
    }

    public function test_a_job_that_never_reaches_retrieval_does_not_write_a_stale_prior_trace(): void
    {
        // The singleton retriever's lastTrace() can still hold a PREVIOUS
        // job's trace when this job fails before calling retrieve() at all -
        // the object-identity guard in RunGovernedAi must not mistake that
        // leftover for this run's own retrieval.
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        $requester = User::where('email', 'rita@northgate.test')->firstOrFail();
        TenantContext::clear();

        // Populate lastTrace() with a real, unrelated prior retrieval.
        $retriever = app(RetrievalClient::class);
        $this->retrieveVia($retriever, 'trench depth');
        $priorTraceCount = RetrievalTrace::withoutGlobalScopes()->count();

        TenantContext::set($this->tenant->id);
        $run = AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'requested_by' => $requester->id,
            'public_id' => (string) Str::uuid(), 'idempotency_key' => Str::uuid(), 'task_type' => 'answer',
            'category' => 'general_administration', 'question' => 'trench depth', 'status' => 'queued',
            'provider' => 'test', 'model' => 'test-model', 'prompt_version' => 'v1',
            'retrieval_version' => HybridKnowledgeRetriever::VERSION, 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
        ]);
        TenantContext::clear();

        // Reaches suggest() (a valid project, so nothing earlier in handle()
        // throws) but this fake never calls retrieve() itself - simulating
        // any failure that happens before retrieval, not after it.
        $neverRetrievesAssistant = new class implements AiAssistant
        {
            public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): AiResult
            {
                throw new \RuntimeException('failure before this run ever called retrieve().');
            }
        };

        try {
            (new RunGovernedAi($run->id))->handle($neverRetrievesAssistant, app(AiRunLedger::class));
            $this->fail('Expected the simulated failure to propagate.');
        } catch (\RuntimeException) {
            // Expected; only the trace-count assertion below matters.
        }

        $this->assertSame($priorTraceCount, RetrievalTrace::withoutGlobalScopes()->count(),
            'A stale prior-job trace was written against a run that never reached retrieval.');
    }

    public function test_an_escalation_records_its_basis_and_conflict_citations(): void
    {
        TenantContext::set($this->tenant->id);
        $this->seedSource('specification', 'Spec 32 84 00', 'CA', 'Trench depth shall be 24 in.');
        TenantContext::clear();

        $retriever = new HybridKnowledgeRetriever;
        $this->retrieveVia($retriever, 'trench depth');

        $trace = RetrievalTraceWriter::write(
            $retriever->lastTrace(), 'trench depth', $this->tenant->id, $this->project->id, null,
            new Escalation('two passages disagree on depth', 'project engineer', [], Escalation::BASIS_CONFLICT),
        );

        $this->assertSame('escalation', $trace->result_kind);
        $this->assertSame(Escalation::BASIS_CONFLICT, $trace->escalation_basis);
    }

    public function test_a_retrieval_trace_is_append_only(): void
    {
        $trace = RetrievalTrace::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'ai_run_id' => null,
            'query' => 'trench depth', 'retriever_version' => HybridKnowledgeRetriever::VERSION,
            'chunking_versions' => [], 'authorization_state' => [], 'sql_candidate_count' => 0,
            'stages' => [], 'final_candidates' => [], 'passages_cited' => [], 'result_kind' => 'no_match',
        ]);

        $this->expectException(\LogicException::class);
        $trace->update(['query' => 'a different question']);
    }

    public function test_a_retrieval_trace_cannot_be_deleted(): void
    {
        $trace = RetrievalTrace::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'ai_run_id' => null,
            'query' => 'trench depth', 'retriever_version' => HybridKnowledgeRetriever::VERSION,
            'chunking_versions' => [], 'authorization_state' => [], 'sql_candidate_count' => 0,
            'stages' => [], 'final_candidates' => [], 'passages_cited' => [], 'result_kind' => 'no_match',
        ]);

        $this->expectException(\LogicException::class);
        $trace->delete();
    }

    public function test_documents_view_is_the_only_read_gate_ever_checked_for_evidence_content(): void
    {
        // TR-18, Codex's third finding: AiRunController's redaction keys off
        // one project-level capability, 'documents.view', rather than a
        // per-source ACL. That is only correct because this codebase has no
        // second, finer-grained read gate anywhere - every controller that
        // ever returns document/source content or metadata checks this exact
        // capability and none other. If a per-source ACL is ever introduced,
        // it will add a capability string matching this pattern and this test
        // fails, which is exactly the signal to revisit the redaction check
        // rather than silently leave it covering only part of the surface.
        $readingControllers = [
            'AiRunController.php', 'KnowledgeController.php', 'DocumentLibraryController.php',
            'IntelligenceController.php', 'AssistController.php',
        ];

        foreach ($readingControllers as $file) {
            $source = file_get_contents(app_path('Http/Controllers/'.$file));
            $this->assertStringContainsString(
                "'documents.view'", $source,
                "{$file} reads document content but does not check 'documents.view' anywhere.",
            );

            preg_match_all("/'(documents\.[a-z_]+)'/s", $source, $matches);
            $foreignReadCapabilities = array_diff(array_unique($matches[1]), ['documents.view', 'documents.ingest', 'documents.transmittal']);
            $this->assertSame([], array_values($foreignReadCapabilities),
                "{$file} checks an unexpected documents.* capability: ".implode(', ', $foreignReadCapabilities)
                .". A new per-source read gate exists - AiRunController's redaction must be revisited against it.");
        }
    }

    public function test_a_viewer_without_documents_view_sees_a_redacted_trace(): void
    {
        // AiRunController::show() re-checks documents.view for the CURRENT
        // viewer - never inherits whatever the original requester held.
        TenantContext::set($this->tenant->id);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        $viewer = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Assistant-Only Viewer',
            'email' => 'viewer@northgate.test', 'password' => bcrypt('password')]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $viewer->id,
            'organization' => 'Northgate', 'seat' => 'viewer', 'capabilities' => ['assistant.use' => true]]);

        $run = AiRun::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'requested_by' => $viewer->id,
            'public_id' => (string) Str::uuid(), 'idempotency_key' => Str::uuid(), 'task_type' => 'answer',
            'category' => 'general_administration', 'question' => 'trench depth', 'status' => 'refused',
            'provider' => 'test', 'model' => 'test-model', 'prompt_version' => 'v1',
            'retrieval_version' => HybridKnowledgeRetriever::VERSION, 'policy_version' => 'refusal-v1',
            'authorization_scope' => [], 'retrieval_scope' => [], 'assumptions' => [],
            'result' => ['kind' => 'no_match'], 'completed_at' => now(),
        ]);
        RetrievalTrace::create([
            'tenant_id' => $this->tenant->id, 'project_id' => $this->project->id, 'ai_run_id' => $run->id,
            'query' => 'trench depth', 'retriever_version' => HybridKnowledgeRetriever::VERSION,
            'chunking_versions' => [], 'authorization_state' => [], 'sql_candidate_count' => 3,
            'stages' => [['stage' => 'candidate_filters', 'excluded' => []]],
            'final_candidates' => [['source_public_id' => 'secret-source']], 'passages_cited' => [],
            'result_kind' => 'no_match',
        ]);
        TenantContext::clear();

        Sanctum::actingAs($viewer);
        $response = $this->getJson('/api/ai-runs/'.$run->id)->assertOk()->json();

        $this->assertTrue($response['trace']['redacted']);
        $this->assertArrayNotHasKey('final_candidates', $response['trace']);
        $encoded = json_encode($response['trace']);
        $this->assertStringNotContainsString('secret-source', $encoded);
    }

    /** @return list<RetrievedPassage> */
    private function retrieveVia(HybridKnowledgeRetriever $retriever, string $question): array
    {
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = $retriever->retrieve($question, $this->project->jurisdictionScope());
        TenantContext::clear();

        return $found;
    }

    private function seedSource(string $type, string $title, string $jurisdiction, string $body, string $collection = 'project'): int
    {
        $source = KnowledgeSource::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'public_id' => (string) Str::uuid(), 'collection' => $collection, 'title' => $title,
            'source_type' => $type, 'jurisdiction' => $jurisdiction, 'discipline' => 'landscape',
            'authority_level' => 'project_contract', 'access_classification' => 'project_private',
            'verification_status' => 'verified', 'ingestion_status' => 'ready', 'mime_type' => 'text/plain',
            'storage_path' => 'test/'.$title, 'byte_size' => 1, 'sha256' => hash('sha256', $title),
            'malware_scan_status' => 'clean']);

        $version = KnowledgeSourceVersion::create(['knowledge_source_id' => $source->id, 'version_number' => 1,
            'edition' => '2026', 'sha256' => hash('sha256', $title), 'extraction_method' => 'plain-text',
            'extraction_confidence' => 1.0, 'parser_version' => 'test',
            'classification' => ['corpora' => ['project_specs']], 'storage_path' => 'test/'.$title,
            'mime_type' => 'text/plain', 'byte_size' => 1, 'malware_scan_status' => 'clean']);

        KnowledgePassage::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'knowledge_source_version_id' => $version->id, 'ordinal' => 1, 'body' => $body,
            'body_sha256' => hash('sha256', $body)]);

        return $version->id;
    }
}
