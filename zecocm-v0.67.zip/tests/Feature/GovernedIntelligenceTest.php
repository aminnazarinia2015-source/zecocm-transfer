<?php

namespace Tests\Feature;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\Citation;
use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\CapabilityGrant;
use App\Models\KnowledgeSource;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Jobs\RunGovernedAi;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class GovernedIntelligenceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        config(['queue.default' => 'sync']);
        $this->tenant = Tenant::create(['name' => 'Atlas CM', 'type' => 'CM firm', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('CM firm'), 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Knowledge Steward',
            'email' => 'steward@atlas.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'A-1', 'name' => 'Atlas Library', 'sector' => 'public',
            'owner_name' => 'City of Atlas', 'state' => 'CA', 'funding_source' => 'local', 'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Atlas CM', 'seat' => 'knowledge_steward', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'ai.assist', usageLimit: 10);
        TenantContext::clear(); Sanctum::actingAs($this->user);
    }

    protected function tearDown(): void
    {
        TenantContext::clear(); parent::tearDown();
    }

    public function test_provisional_material_is_not_retrieved_until_a_steward_verifies_it(): void
    {
        $created = $this->postJson('/api/knowledge/sources', $this->sourcePayload())->assertCreated();
        $sourceId = $created->json('source.id');

        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $scope = $this->project->jurisdictionScope();
        $this->assertSame([], (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $scope));
        TenantContext::clear();

        $this->postJson("/api/knowledge/sources/{$sourceId}/review", ['action' => 'verify', 'reason' => 'Checked against issued specification'])->assertOk();
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $found = (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $scope);
        $this->assertCount(1, $found);
        $this->assertNotNull($found[0]->sourceHash);
        $this->assertSame('project_contract', $found[0]->authorityLevel);
    }

    public function test_corpus_scope_is_enforced_and_wrong_corpus_is_not_returned(): void
    {
        $payload = $this->sourcePayload(); $payload['corpus'] = 'building_code';
        $id = $this->postJson('/api/knowledge/sources', $payload)->assertCreated()->json('source.id');
        $this->postJson("/api/knowledge/sources/{$id}/review", ['action' => 'verify', 'reason' => 'Wrong corpus on purpose'])->assertOk();
        TenantContext::set($this->tenant->id); request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        request()->attributes->set('authorized_evidence_read', true);
        $this->assertSame([], (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $this->project->jurisdictionScope()));
    }

    public function test_a_steward_decision_will_not_be_recorded_without_a_reason_the_steward_wrote(): void
    {
        // The ledger's value is that it shows who decided and why. A defaulted or
        // boilerplate reason asserts a review that the record cannot evidence, so the
        // API refuses the decision outright rather than inventing the justification.
        $id = $this->postJson('/api/knowledge/sources', $this->sourcePayload())->assertCreated()->json('source.id');

        $this->postJson("/api/knowledge/sources/{$id}/review", ['action' => 'verify'])
            ->assertStatus(422)->assertJsonValidationErrors('reason');
        $this->postJson("/api/knowledge/sources/{$id}/review", ['action' => 'verify', 'reason' => 'ok'])
            ->assertStatus(422)->assertJsonValidationErrors('reason');

        $this->assertSame('provisional', KnowledgeSource::withoutGlobalScopes()->find($id)->verification_status);
    }

    public function test_a_mistaken_verification_is_correctable_without_rejecting_the_document(): void
    {
        // A steward who promotes the wrong source must be able to put it back. Before
        // this existed the only exit from 'verified' was 'rejected', which would have
        // condemned a legitimate document in order to undo a click.
        $id = $this->postJson('/api/knowledge/sources', $this->sourcePayload())->assertCreated()->json('source.id');
        $this->postJson("/api/knowledge/sources/{$id}/review", ['action' => 'verify', 'reason' => 'Checked against issued specification'])->assertOk();

        $this->postJson("/api/knowledge/sources/{$id}/review",
            ['action' => 'return_to_provisional', 'reason' => 'Promoted by a stray click; nobody read this edition.'])->assertOk();

        $source = KnowledgeSource::withoutGlobalScopes()->find($id);
        $this->assertSame('provisional', $source->verification_status);
        $this->assertSame('review_required', $source->ingestion_status);
        $this->assertNull($source->verified_by);
        $this->assertNull($source->verified_at);

        // Withdrawn from retrieval again.
        TenantContext::set($this->tenant->id);
        request()->attributes->set('authorized_project_id', $this->project->id);
        request()->attributes->set('authorized_evidence_read', true);
        $this->assertSame([], (new HybridKnowledgeRetriever)->retrieve('irrigation trench depth', $this->project->jurisdictionScope()));
        TenantContext::clear();

        // The correction is appended. The earlier decision is still in the ledger.
        $events = \Illuminate\Support\Facades\DB::table('knowledge_review_events')
            ->where('knowledge_source_id', $id)->orderBy('id')->pluck('action')->all();
        $this->assertContains('verify', $events);
        $this->assertSame('return_to_provisional', end($events));

        $this->postJson("/api/knowledge/sources/{$id}/review",
            ['action' => 'return_to_provisional', 'reason' => 'Nothing left to return here.'])->assertStatus(409);
    }

    public function test_a_source_with_no_extractable_text_cannot_be_verified(): void
    {
        // Live finding, PN 851 Appendix C: a scanned PDF ingested cleanly, produced zero
        // passages, and was still promoted to 'verified'. In the library it looked exactly
        // like a source TRACE could cite. It could never cite a word of it.
        $payload = $this->sourcePayload();
        unset($payload['text']);
        $path = tempnam(sys_get_temp_dir(), 'scan').'.txt';
        file_put_contents($path, "   \n\n   \n");
        $payload['file'] = new \Illuminate\Http\UploadedFile($path, 'appendix-c-scan.txt', 'text/plain', null, true);
        $id = $this->post('/api/knowledge/sources', $payload)->assertCreated()->json('source.id');

        $this->postJson("/api/knowledge/sources/{$id}/review",
            ['action' => 'verify', 'reason' => 'Looks like the right appendix from the cover page.'])
            ->assertStatus(422);

        $this->assertSame('provisional', KnowledgeSource::withoutGlobalScopes()->find($id)->verification_status);

        // Rejecting an unreadable source is still allowed - that is how it leaves the queue.
        $this->postJson("/api/knowledge/sources/{$id}/review",
            ['action' => 'reject', 'reason' => 'Scanned image with no text layer; a text-bearing copy is needed.'])
            ->assertOk();
        $this->assertSame('rejected', KnowledgeSource::withoutGlobalScopes()->find($id)->verification_status);
    }

    public function test_cross_tenant_source_identifier_fails_closed(): void
    {
        $id = $this->postJson('/api/knowledge/sources', $this->sourcePayload())->assertCreated()->json('source.id');
        $other = Tenant::create(['name' => 'Other', 'type' => 'CM firm', 'status' => 'active', 'entitlements' => [], 'sponsor_role' => 'cm_firm', 'is_account_owner' => true]);
        $otherUser = User::create(['tenant_id' => $other->id, 'name' => 'Other User', 'email' => 'other@tenant.test', 'password' => bcrypt('password')]);
        Sanctum::actingAs($otherUser);
        $this->getJson("/api/knowledge/sources/{$id}")->assertNotFound();
    }

    public function test_successful_ai_work_is_audited_and_metered_only_after_success(): void
    {
        $this->app->instance(AiAssistant::class, new class implements AiAssistant {
            public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): \App\Domain\Ai\AiResult
            {
                return new CitedSuggestion('Draft grounded in the cited source.', [new Citation('Spec 32 84 00', '2026', new \DateTimeImmutable, 7, 'source-1', str_repeat('a', 64), 12, 12, '3.4.A', 'project_contract')]);
            }
        });
        $response = $this->postJson('/api/ai-runs', ['project_id' => $this->project->id, 'question' => 'Draft the trench RFI',
            'task_type' => 'draft', 'idempotency_key' => 'test-success'])->assertAccepted();
        $this->assertSame('queued', $response->json('run.status'));
        $this->app->call([new RunGovernedAi((int) $response->json('run.id')), 'handle']);
        $this->assertDatabaseHas('ai_runs', ['idempotency_key' => 'test-success', 'result_classification' => 'recommendation']);
        $this->assertDatabaseCount('ai_run_events', 3);
        $this->assertSame(1, CapabilityGrant::where('tenant_id', $this->tenant->id)->where('capability_key', 'ai.assist')->value('usage_count'));
    }

    public function test_refusal_is_not_billed_and_idempotent_replay_creates_no_second_run(): void
    {
        $this->app->instance(AiAssistant::class, new class implements AiAssistant {
            public function suggest(string $task, string $category, JurisdictionScope $scope, RefusalPolicy $policy): \App\Domain\Ai\AiResult
            { return new Escalation('Insufficient evidence.', 'manual review'); }
        });
        $body = ['project_id' => $this->project->id, 'question' => 'Determine fault', 'idempotency_key' => 'same-request'];
        $first = $this->postJson('/api/ai-runs', $body)->assertAccepted()->assertJsonPath('run.status', 'queued');
        $this->app->call([new RunGovernedAi((int) $first->json('run.id')), 'handle']);
        $this->postJson('/api/ai-runs', $body)->assertOk()->assertJsonPath('replayed', true);
        $this->assertDatabaseCount('ai_runs', 1);
        $this->assertSame(0, CapabilityGrant::where('tenant_id', $this->tenant->id)->where('capability_key', 'ai.assist')->value('usage_count'));
    }

    private function sourcePayload(): array
    {
        return ['project_id' => $this->project->id, 'collection' => 'project', 'corpus' => 'project_contract',
            'title' => 'Irrigation Specification', 'source_type' => 'specification', 'authority_level' => 'project_contract',
            'edition' => '2026', 'jurisdiction' => 'City of Atlas',
            'text' => str_repeat('Specification Section 32 84 00 requires irrigation trench depth and verified backfill. ', 3)];
    }
}
