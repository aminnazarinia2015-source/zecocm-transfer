<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Rfi;
use App\Models\Submittal;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Found during a real-world walkthrough: both the RFI register and the
 * Submittal register show "ball in court" to users as a live fact (the RFI
 * detail view literally labels it "Current ball in court - recorded fact",
 * and toast messages say "ball with X"), but the field was set once at
 * creation and never moved again - not on RfiController::store(), not on
 * DecisionController::authorize() when the RFI is answered or the submittal
 * is stamped. Every RFI showed "with architect" forever, and every
 * submittal showed its reviewing discipline forever, even after the
 * question was answered or the submittal was closed out. Fixed in
 * DecisionController::authorize() to move the ball on seal: back to the
 * raiser when an RFI is answered, back to the submitter when a submittal
 * needs corrections/resubmission, and to "closed" on a final disposition.
 */
class BallInCourtActuallyMovesTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;
    private User $user;
    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM',
            'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        TenantContext::set($this->tenant->id);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => [
                'rfi' => ['days' => 10, 'basis' => 'working'],
                'submittal_review' => ['days' => 14, 'basis' => 'working'],
            ]]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->user->id,
            'organization' => 'Northgate', 'seat' => 'project_manager', 'capabilities' => ['*' => true]]);
        (new CapabilityLicense)->grant($this->tenant, 'rfis', planReference: 'Test fixture');
        (new CapabilityLicense)->grant($this->tenant, 'submittals', planReference: 'Test fixture');
        TenantContext::clear();
        Sanctum::actingAs($this->user);
    }

    public function test_answering_an_rfi_hands_the_ball_back_to_the_raiser(): void
    {
        TenantContext::set($this->tenant->id);
        $rfi = Rfi::create(['project_id' => $this->project->id, 'number' => 'RFI-1', 'subject' => 'x',
            'question' => 'x', 'raised_by_org' => 'Fieldco', 'raised_at' => now(),
            'ball_in_court' => 'architect', 'cost_impact' => false, 'status' => 'open',
            'ai_dispositions' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->postJson('/api/decisions/rfi/'.$rfi->id.'/authorize', [
            'confirm' => true,
            'response' => 'Use detail 4/A501.',
        ]);

        $res->assertOk();
        $this->assertSame('Fieldco', $rfi->fresh()->ball_in_court);
    }

    public function test_a_submittal_sent_back_for_revision_hands_the_ball_to_the_submitter(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['project_id' => $this->project->id, 'number' => 'SUB-1',
            'title' => 'Rebar shop drawings', 'type' => 'shop_drawing', 'spec_section' => '03 30 00', 'submitted_by_org' => 'Fieldco', 'submitted_at' => now(),
            'ball_in_court' => 'structural', 'status' => 'in_review', 'ai_findings' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->postJson('/api/decisions/submittal/'.$submittal->id.'/authorize', [
            'confirm' => true,
            'disposition' => 'revise_resubmit',
        ]);

        $res->assertOk();
        $this->assertSame('Fieldco', $submittal->fresh()->ball_in_court);
    }

    public function test_a_submittal_closed_with_no_exceptions_clears_the_ball(): void
    {
        TenantContext::set($this->tenant->id);
        $submittal = Submittal::create(['project_id' => $this->project->id, 'number' => 'SUB-2',
            'title' => 'Mix design', 'type' => 'shop_drawing', 'spec_section' => '03 30 00', 'submitted_by_org' => 'Fieldco', 'submitted_at' => now(),
            'ball_in_court' => 'structural', 'status' => 'in_review', 'ai_findings' => [], 'routing_history' => []]);
        TenantContext::clear();

        $res = $this->postJson('/api/decisions/submittal/'.$submittal->id.'/authorize', [
            'confirm' => true,
            'disposition' => 'no_exceptions',
        ]);

        $res->assertOk();
        $this->assertSame('closed', $submittal->fresh()->ball_in_court);
    }
}
