<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * One row per admin-managed secret (currently just ANTHROPIC_API_KEY). The
 * ciphertext column is Laravel's own Crypt (APP_KEY-bound) output - never a
 * plaintext value, never logged, never returned by any API response.
 * See App\Domain\Ops\PlatformSecretStore for the read/write path.
 */
class PlatformSecret extends Model
{
    protected $fillable = ['key', 'ciphertext', 'updated_by_user_id'];
}
