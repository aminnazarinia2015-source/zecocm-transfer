<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class QualityItem extends Model
{
    use BelongsToTenant;

    protected $guarded = [];
    protected $casts = ['due_at' => 'date'];

    public function events()
    {
        return $this->hasMany(QualityItemEvent::class);
    }

    public function media()
    {
        return $this->belongsToMany(MediaItem::class, 'quality_item_media')->withPivot(['linked_by', 'created_at']);
    }
}
