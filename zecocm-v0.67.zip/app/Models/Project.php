<?php

namespace App\Models;

use App\Domain\Ai\JurisdictionScope;
use App\Domain\Clocks\DeadlineExpression;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'number', 'name', 'sector', 'owner_name', 'state', 'funding_source',
        'ntp_date', 'duration_days', 'duration_basis', 'extension_days', 'ld_per_day',
        'contract_clocks', 'org_structure',
        'site_address', 'owner_address_lines', 'owner_contact',
    ];

    protected $casts = [
        'ntp_date' => 'date',
        'contract_clocks' => 'array',
        'org_structure' => 'array',
        'payment_terms' => 'array',
        'payment_workflow' => 'array',
        'owner_address_lines' => 'array',
        'ld_per_day' => 'decimal:2',
    ];

    /** Every clock in the system derives from here - entered once (Aspect 8). */
    public function clock(string $name): DeadlineExpression
    {
        $c = $this->contract_clocks[$name]
            ?? throw new \RuntimeException("Project has no '{$name}' clock configured.");

        return new DeadlineExpression(
            periodDays: (int) $c['days'],
            basis: $c['basis'] ?? DeadlineExpression::BASIS_WORKING,
            holidays: $c['holidays'] ?? [],
        );
    }

    /** AI retrieval scope derived from the project record, never user-picked (Aspect 17). */
    public function jurisdictionScope(): JurisdictionScope
    {
        return JurisdictionScope::forProject($this->sector, $this->state, $this->funding_source);
    }
}
