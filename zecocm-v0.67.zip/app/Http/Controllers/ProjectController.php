<?php

namespace App\Http\Controllers;

use App\Models\Membership;
use App\Models\Project;
use App\Tenancy\TenantContext;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProjectController
{
    public function index(Request $request)
    {
        $query = Project::query();
        if (! $request->user()->isPlatformStaff()) {
            // A revoked grant must actually stop authorizing here too, not just
            // in ProjectAccess - the same "revoked status column is not merely
            // cosmetic" rule ProjectAccess::authorize() already enforces for
            // every project-scoped action. Found during the adversarial "what
            // if" pass: a revoked member's every real endpoint call already
            // 403'd, but this list still returned the project's id/number/
            // name/sector/owner_name to them - the exact continued-visibility
            // leak this list exists to prevent for a member who was never
            // granted the project at all.
            $query->whereIn('id', Membership::query()
                ->where('user_id', $request->user()->id)
                ->where('status', '!=', Membership::STATUS_REVOKED)
                ->select('project_id'));
        }

        return $query->orderBy('number')->get(['id', 'number', 'name', 'sector', 'owner_name']);
    }

    public function store(Request $request)
    {
        if (TenantContext::writesBlocked()) {
            abort(403, 'Technicians cannot create projects - suggest it; the admin applies.');
        }
        // Dead-condition bug found by adversarial testing: TenantContext::isPlatformStaff()
        // is only ever true together with a non-null tenantId() (they're set together in
        // EstablishTenantContext), so "isPlatformStaff() && tenantId() === null" could never
        // fire - not for staff with no X-Browse-Tenant header, and not for staff who browsed a
        // nonexistent tenant id (which fails closed to no context, same as no header at all).
        // Both cases fell through to BelongsToTenant's creating() guard, which throws a raw
        // RuntimeException - an unhandled 500 instead of a clean 403. The actual staff/customer
        // distinction lives on the authenticated user, not on the (possibly unset) context.
        if ($request->user()->isPlatformStaff() && TenantContext::tenantId() === null) {
            abort(403, 'Open a customer account first - projects always belong to a customer.');
        }
        $data = $request->validate([
            'number' => 'required|string|max:32',
            'name' => 'required|string|max:255',
            'sector' => 'required|in:public,commercial,residential',
            'owner_name' => 'required|string|max:255',
            'state' => 'nullable|string|max:8',
            'funding_source' => 'nullable|in:local,state,federal',
            'ntp_date' => 'nullable|date',
            'duration_days' => 'nullable|integer|min:1',
            'duration_basis' => 'nullable|in:calendar,working',
            'ld_per_day' => 'nullable|numeric|min:0',

            // Contract clocks are terms of THIS contract. They are accepted from the
            // caller, validated, and stored with the clause they came from.
            'contract_clocks' => 'nullable|array',
            'contract_clocks.*.days' => 'required_with:contract_clocks|integer|min:0|max:3650',
            'contract_clocks.*.basis' => 'required_with:contract_clocks|in:working,calendar',
            'contract_clocks.*.source' => 'nullable|string|max:255',
        ]);
        $project = DB::transaction(function () use ($data, $request) {
            /*
             * NEVER invent a contract clock.
             *
             * This previously wrote a fixed set of periods - submittal 14 calendar days,
             * RFI 5 working days - and discarded whatever the caller sent. Downstream, the
             * decision envelope and the issued transmittal then printed those invented
             * numbers under the words "the contract governs, not a system default", and a
             * due date computed from them went out to an owner agency on a real document.
             * A fabricated contract term is the most damaging thing this system could
             * assert, and it was asserting one with a sentence denying that it was.
             *
             * Clocks now come from the caller or they do not exist. With none recorded,
             * every downstream surface already refuses honestly: the brief says it cannot
             * compute what is late, and the transmittal prints "A period is never assumed."
             */
            $clocks = [];
            foreach (($data['contract_clocks'] ?? []) as $name => $clock) {
                $clocks[$name] = array_filter([
                    'days' => (int) $clock['days'],
                    'basis' => $clock['basis'],
                    'source' => $clock['source'] ?? null,
                ], fn ($v) => $v !== null);
            }

            $project = Project::create(array_diff_key($data, ['contract_clocks' => true]) + [
                'state' => $data['state'] ?? 'CA',
                'contract_clocks' => $clocks,
                'org_structure' => [],
            ]);

            if (! $request->user()->isPlatformStaff()) {
                Membership::create([
                    'project_id' => $project->id,
                    'user_id' => $request->user()->id,
                    'organization' => $data['owner_name'] ?? 'Project team',
                    'seat' => 'project_admin',
                    'capabilities' => ['*' => true],
                ]);
            }

            return $project;
        });

        return response()->json($project, 201);
    }

    public function me(Request $request)
    {
        $u = $request->user();

        return response()->json([
            'id' => $u->id, 'name' => $u->name, 'email' => $u->email,
            'platform_role' => $u->platform_role, 'tenant_id' => $u->tenant_id,
        ]);
    }
}
