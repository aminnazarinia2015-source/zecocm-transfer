<?php

namespace App\Http\Controllers;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\PlatformSuggestion;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;

/**
 * The ZecoCM owner console. Admin-only for mutations; technicians get
 * read access per their permission switches and a suggestions outbox.
 */
class PlatformController
{
    public function customers(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        // Counts must bypass tenant scoping - platform staff have no tenant
        // context, and fail-closed scoping would report 0 for everyone.
        return Tenant::orderBy('name')->get()->map(function ($t) {
            $admin = User::where('tenant_id', $t->id)->orderBy('id')->first();

            return [
                'id' => $t->id,
                'name' => $t->name,
                'type' => $t->type,
                'status' => $t->status,
                'entitlements' => $t->entitlements,
                'sections_count' => is_array($t->entitlements) ? count(array_filter($t->entitlements)) : 0,
                'projects_count' => Project::withoutGlobalScopes()->where('tenant_id', $t->id)->count(),
                'users_count' => User::where('tenant_id', $t->id)->count(),
                'admin_name' => $admin?->name,
                'admin_email' => $admin?->email,
                'created_at' => $t->created_at,
            ];
        });
    }

    /** Staff drill-down: a customer's projects, read-only. */
    public function customerProjects(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        return Project::withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->orderBy('number')
            ->get(['id', 'number', 'name', 'sector', 'owner_name', 'state']);
    }

    public function storeCustomer(Request $request)
    {
        abort_unless(
            $request->user()->isPlatformAdmin() || $request->user()->can_('create_customers'),
            403, 'Your profile cannot create customers.'
        );

        $data = $request->validate([
            'name' => 'required|string|max:128',
            'type' => 'required|string|max:64',        // extendable - data, not enum
            'entitlements' => 'array',
            'admin_name' => 'required|string|max:128',
            'admin_email' => 'required|email|unique:users,email',
        ]);

        $entitlements = $data['entitlements'] ?? Tenant::defaultEntitlements($data['type']);
        $tenant = Tenant::create([
            'name' => $data['name'],
            'type' => $data['type'],
            'entitlements' => $entitlements,
            'status' => 'trial',
        ]);

        $tempPassword = bin2hex(random_bytes(8));
        User::create([
            'tenant_id' => $tenant->id,
            'name' => $data['admin_name'],
            'email' => $data['admin_email'],
            'password' => bcrypt($tempPassword),
        ]);

        // Entitlements drive presentation; capability grants enforce access and
        // preserve an auditable commercial history. Create both atomically in intent.
        $licenses = app(CapabilityLicense::class);
        foreach ($entitlements as $capability) {
            if (CapabilityCatalog::has($capability) && ! CapabilityCatalog::isFree($capability)) {
                $licenses->grant($tenant, $capability, planReference: 'Initial account configuration',
                    actorUserId: $request->user()->id, reason: 'Granted when account was created');
            }
        }

        // TODO(mail): send invite. Returned once here so the admin can relay it.
        return response()->json(['tenant' => $tenant, 'admin_temp_password' => $tempPassword], 201);
    }

    /**
     * Edit a customer's own identifying details - name, legal name, address,
     * brand, and now (per Amin's explicit ask - "all the information should
     * be editable for admin") the primary admin contact's own name/email.
     * This is distinct from assignSections() (what they're licensed for) and
     * setStatus() (whether they can sign in): those already existed; basic
     * identity fields did not have any edit path at all.
     *
     * admin_name/admin_email edit the FIRST user row for this tenant (the
     * same "who counts as the admin" convention customers()/customerProjects()
     * already use - User::where('tenant_id', ...)->orderBy('id')->first()).
     * This never touches the password - changing sign-in credentials stays a
     * separate, deliberate action (registrationPasswordLink), not something
     * that happens as a side effect of editing a display name.
     */
    public function updateCustomer(Request $request, Tenant $tenant)
    {
        // The "Add technician" / "Edit staff" forms in public/app.html have offered a
        // "Can modify customer info?" toggle (platform_permissions.modify_customer_info)
        // since they were built, and PlatformStaffController happily stores it - but
        // nothing ever read it here. An admin who granted a technician this permission
        // got no error and no indication anything was wrong; the technician's PUT just
        // 403'd every time, identically to a technician with no permissions at all.
        // Found via adversarial audit: same shape as LicenseController::mine()'s
        // documented history (a permission the UI implies is real doing nothing).
        abort_unless(
            $request->user()->isPlatformAdmin() || $request->user()->can_('modify_customer_info'),
            403, 'Your profile cannot edit customer details.'
        );

        $data = $request->validate([
            'name' => 'sometimes|required|string|max:128',
            'type' => 'sometimes|required|string|max:64',
            'legal_name' => 'nullable|string|max:255',
            'address_lines' => 'nullable|array',
            'address_lines.*' => 'string|max:255',
            'brand_accent' => 'nullable|string|max:16',
            'brand_mark' => 'nullable|string|max:8',
            'admin_name' => 'sometimes|nullable|string|max:128',
            'admin_email' => 'sometimes|nullable|email|max:255',
        ]);

        $adminName = $data['admin_name'] ?? null;
        $adminEmail = $data['admin_email'] ?? null;
        unset($data['admin_name'], $data['admin_email']);

        // Wrapped in a transaction: the tenant-fields update below and the admin-contact
        // update further down are one logical edit from the caller's point of view (one
        // PUT, one response). Without a transaction, a rejected admin_email (already in
        // use, or no admin user to edit) would abort() AFTER $tenant->update($data) had
        // already committed - the caller sees a 422 "failed" but the tenant's name/type/
        // address etc. silently persisted anyway. Found via adversarial audit: PUT with
        // both 'name' and a taken 'admin_email' returned 422 yet the tenant's new name was
        // still in the database. abort() throws an HttpException, which DB::transaction()
        // catches, rolls back for, and rethrows - so a rejected admin-contact change now
        // leaves the tenant fields untouched too, same as if the whole request never ran.
        \Illuminate\Support\Facades\DB::transaction(function () use ($tenant, $data, $adminName, $adminEmail) {
            $tenant->update($data);

            if ($adminName !== null || $adminEmail !== null) {
                $admin = User::where('tenant_id', $tenant->id)->orderBy('id')->first();
                if ($admin === null) {
                    abort(422, 'This account has no admin user yet to edit - it was created without one.');
                }
                $adminUpdate = [];
                if ($adminName !== null) {
                    $adminUpdate['name'] = $adminName;
                }
                if ($adminEmail !== null && $adminEmail !== $admin->email) {
                    $taken = User::where('email', $adminEmail)->where('id', '!=', $admin->id)->exists();
                    abort_if($taken, 422, 'That email address is already in use by another account.');
                    $adminUpdate['email'] = $adminEmail;
                }
                if ($adminUpdate !== []) {
                    $admin->update($adminUpdate);
                }
            }
        });

        $fresh = $tenant->fresh();
        $admin = User::where('tenant_id', $tenant->id)->orderBy('id')->first();
        $fresh->admin_name = $admin?->name;
        $fresh->admin_email = $admin?->email;

        return response()->json($fresh);
    }

    /**
     * Delete a customer record outright - deliberately narrow. The platform's
     * core invariant is that real records are never silently erased (see
     * setStatus() above); a tenant that has ever created a project carries
     * that history and must be suspended, not deleted, if access needs to
     * end. This exists for the one honest case that invariant doesn't cover:
     * an account created by mistake (a duplicate, a test entry) that was
     * never actually used. If it has any project, it fails closed.
     */
    public function deleteCustomer(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin deletes a customer account.');

        $projectCount = Project::withoutGlobalScopes()->where('tenant_id', $tenant->id)->count();
        abort_if($projectCount > 0, 422,
            "This account has {$projectCount} project(s) on it and cannot be deleted - that would erase real "
            .'project history. Suspend it instead (Status), or contact support if it must be removed anyway.');

        User::where('tenant_id', $tenant->id)->delete();
        $tenant->delete();

        return response()->json(['message' => 'Customer account deleted - it had no projects on it.']);
    }

    public function assignSections(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin assigns sections.');
        $data = $request->validate(['entitlements' => 'required|array']);
        $tenant->update(['entitlements' => $data['entitlements']]);

        return response()->json($tenant);
    }

    /**
     * Suspend or reactivate a customer account. This is deliberately NOT a
     * delete: the platform's core design invariant is that records are never
     * silently erased (see the Security & Trust page - "the present never
     * rewrites the past"). Suspending blocks that tenant's users from
     * signing in; it does not touch their projects, documents, or history,
     * and can be reversed by setting status back to 'active'.
     */
    public function setStatus(Request $request, Tenant $tenant)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin changes account status.');
        $data = $request->validate(['status' => 'required|in:active,trial,suspended']);
        $tenant->update(['status' => $data['status']]);

        return response()->json($tenant);
    }

    /**
     * Read-only queue of self-serve requests from the homepage's "Get
     * started" form (Onboarding\RegistrationController::store). That form
     * only captures an organization profile - no payment happens there -
     * so every row here is 'pending_payment': a human still has to follow
     * up to complete payment setup and provision the account.
     */
    public function registrations(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        return \App\Models\ContractorRegistration::orderByDesc('created_at')->limit(200)->get([
            'id', 'registration_id', 'legal_name', 'business_name', 'entity_type', 'plan', 'country',
            'admin_first_name', 'admin_last_name', 'phone', 'email', 'status', 'created_at',
        ]);
    }

    /**
     * Read-only(ish) queue of "show me the full product" leads from the homepage's
     * "Request a full demo" form (Onboarding\DemoController::requestFullDemo). A human follows up
     * and schedules the demo directly; updateDemoRequest() below just tracks that follow-up
     * (contacted/scheduled/closed) — it never provisions anything itself.
     */
    public function demoRequests(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        return \App\Models\DemoRequest::orderByDesc('created_at')->limit(200)->get();
    }

    public function updateDemoRequest(Request $request, \App\Models\DemoRequest $demoRequest)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $data = $request->validate(['status' => 'required|in:pending,contacted,scheduled,closed']);
        $demoRequest->update($data);

        return response()->json($demoRequest);
    }

    /**
     * A real, server-backed status screen for the integrations this deploy actually depends on
     * (payment providers, mail) - built specifically so an admin can check whether keys they just
     * added actually took effect, without shelling into the server. Booleans only: never returns
     * the key/secret values themselves, only whether each is configured, consistent with the
     * platform's fail-closed rule against showing prototype/sample data as fact - here the "fact"
     * is real config state, read live from config(), never hardcoded.
     */
    public function systemSettings(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        $stripeSecret = config('services.stripe.secret_key') !== '';
        $paypalCreds = config('services.paypal.client_id') !== '' && config('services.paypal.client_secret') !== '';
        $mailDriver = config('mail.default');

        return response()->json([
            'payment' => [
                'stripe' => [
                    'configured' => $stripeSecret,
                    'webhook_secret_set' => config('services.stripe.webhook_secret') !== '',
                    'plans' => [
                        'field' => config('services.stripe.price_id_field') !== '',
                        'project' => config('services.stripe.price_id_project') !== '',
                        'program' => config('services.stripe.price_id_program') !== '',
                    ],
                ],
                'paypal' => [
                    'configured' => $paypalCreds,
                    'webhook_id_set' => config('services.paypal.webhook_id') !== '',
                    'mode' => config('services.paypal.mode'),
                    'plans' => [
                        'field' => config('services.paypal.plan_id_field') !== '',
                        'project' => config('services.paypal.plan_id_project') !== '',
                        'program' => config('services.paypal.plan_id_program') !== '',
                    ],
                ],
            ],
            'mail' => [
                'driver' => $mailDriver,
                'sends_real_mail' => ! in_array($mailDriver, ['log', 'array', null], true),
                'from_address' => config('mail.from.address'),
            ],
            'app' => [
                'env' => config('app.env'),
                'debug' => config('app.debug'),
            ],
        ]);
    }

    /**
     * The admin-settable secrets list (currently just ANTHROPIC_API_KEY) - status
     * only, never the value. Restricted to admin, not general platform staff:
     * this changes what the AI provider actually calls out to, a materially
     * different consequence than the read-only status booleans in
     * systemSettings() above, which any platform technician can already see.
     */
    public function secrets(Request $request)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Platform administrator only.');

        $envFallbacks = ['ANTHROPIC_API_KEY' => (string) config('zecocm_ai.api_key', '')];

        return response()->json(collect(\App\Domain\Ops\PlatformSecretStore::known())->map(function ($def, $key) use ($envFallbacks) {
            return array_merge(
                ['key' => $key, 'label' => $def['label'], 'hint' => $def['hint']],
                \App\Domain\Ops\PlatformSecretStore::status($key, $envFallbacks[$key] ?? '')
            );
        })->values());
    }

    /**
     * Sets one allow-listed secret. The value is validated as present and
     * non-trivially short, encrypted, and stored - never logged, never
     * echoed back. The response carries only the same status shape
     * secrets() returns, so the admin can confirm length/last-4 without the
     * value ever appearing in a network response body.
     */
    public function updateSecret(Request $request, string $key)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Platform administrator only.');
        abort_unless(\App\Domain\Ops\PlatformSecretStore::isKnown($key), 404, 'Unknown secret key.');

        $data = $request->validate(['value' => 'required|string|min:8|max:4096']);

        \App\Domain\Ops\PlatformSecretStore::set($key, trim($data['value']), $request->user()->id);

        $envFallbacks = ['ANTHROPIC_API_KEY' => (string) config('zecocm_ai.api_key', '')];

        return response()->json(\App\Domain\Ops\PlatformSecretStore::status($key, $envFallbacks[$key] ?? ''));
    }

    /**
     * A provisioned self-serve registration's password-setup link is normally emailed
     * automatically (Mail\ContractorAccountProvisioned) - but until production has a real mail
     * service configured (see systemSettings() above), that email goes nowhere and the customer
     * has no way to actually sign in. This regenerates a fresh signed link on demand so an admin
     * can hand it to the customer directly in the meantime; harmless to call more than once -
     * each call is just a new 7-day link, never a second account or a second charge.
     */
    public function registrationPasswordLink(Request $request, \App\Models\ContractorRegistration $registration)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        abort_unless($registration->isProvisioned(), 422, 'This registration has not been provisioned yet - there is no account to sign into.');

        $admin = \App\Models\User::where('tenant_id', $registration->tenant_id)->where('email', $registration->email)->firstOrFail();
        $url = \Illuminate\Support\Facades\URL::temporarySignedRoute('onboarding.password.show', now()->addDays(7), ['user' => $admin->id]);

        return response()->json(['password_setup_url' => $url, 'email' => $admin->email]);
    }

    public function suggestions(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');

        return PlatformSuggestion::orderByDesc('created_at')->paginate(50);
    }

    public function storeSuggestion(Request $request)
    {
        abort_unless($request->user()->isPlatformStaff(), 403, 'Platform staff only.');
        $data = $request->validate([
            'tenant_id' => 'nullable|integer|exists:tenants,id',
            'about' => 'required|string|max:255',
            'suggestion' => 'required|string',
        ]);

        return response()->json(PlatformSuggestion::create($data + [
            'suggested_by' => $request->user()->id,
        ]), 201);
    }

    public function resolveSuggestion(Request $request, PlatformSuggestion $suggestion)
    {
        abort_unless($request->user()->isPlatformAdmin(), 403, 'Only the admin resolves suggestions.');
        $data = $request->validate(['status' => 'required|in:approved,dismissed']);
        $suggestion->update($data + [
            'resolved_by' => $request->user()->id,
            'resolved_at' => now(),
        ]);

        return response()->json($suggestion);
    }
}
