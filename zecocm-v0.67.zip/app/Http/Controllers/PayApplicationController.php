<?php

namespace App\Http\Controllers;

use App\Domain\Payment\ApplicationContentHash;
use App\Domain\Payment\CertificationStatement;
use App\Domain\Payment\PayApplicationMath;
use App\Domain\Payment\PayApplicationReview;
use App\Domain\Payment\RetentionRule;
use App\Domain\Payment\StopNoticeWithholding;
use App\Domain\Payment\SubmissionPolicy;
use App\Domain\Schedule\ProjectAccess;
use App\Domain\Trace\ProgressEvidenceCrossCheckService;
use App\Models\AiFinding;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\LienRelease;
use App\Models\ScheduleOfValueItem;
use App\Models\StopPaymentNotice;
use App\Models\Subcontract;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * The money path, exposed.
 *
 * Two rules govern everything here, and both are server-side because a control
 * the front end merely hides is not a control:
 *
 *   1. A HARD_INVALID finding refuses submission. The request would be
 *      structurally improper, no payment clock would start, and letting it go
 *      out costs the contractor a cycle.
 *   2. A WITHHOLD finding never refuses submission. The request can be perfectly
 *      proper while money is held for a separate compliance reason. Conflating
 *      the two would start the wrong statutory clock - the seven-day return
 *      window under PCC s. 20104.50 instead of the thirty-day payment clock.
 *
 * The review runs on read as well as on write, so what the screen shows and what
 * the server will accept are computed by the same code path. There is no second
 * validator in JavaScript to drift out of agreement with this one.
 */
class PayApplicationController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'payment.view')->project;

        $applications = PayApplication::query()->where('project_id', $project->id)
            ->orderByDesc('number')->limit(200)->get()
            ->map(fn (PayApplication $a) => $this->digest($a, $project));

        return response()->json([
            'applications' => $applications,
            'schedule_of_values' => ScheduleOfValueItem::query()->where('project_id', $project->id)
                ->orderBy('sort_order')->orderBy('item_number')->get(),
            'computed_at' => now()->toIso8601String(),
        ]);
    }

    public function show(Request $request, PayApplication $application)
    {
        $project = $this->access->authorize($request->user(), (int) $application->project_id, 'payment.view')->project;

        return response()->json($this->envelope($application, $project));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'project_id' => 'required|integer',
            'period_from' => 'required|date',
            'period_to' => 'required|date|after_or_equal:period_from',
            'retention_basis_points' => 'nullable|integer|min:0|max:2000',
        ]);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'payment.create', write: true)->project;

        $application = DB::transaction(function () use ($project, $data) {
            $next = ((int) PayApplication::query()->where('project_id', $project->id)->max('number')) + 1;
            $previous = PayApplication::query()->where('project_id', $project->id)
                ->orderByDesc('number')->with('lines')->first();

            $application = PayApplication::create([
                'tenant_id' => $project->tenant_id,
                'project_id' => $project->id,
                'number' => $next,
                'period_from' => $data['period_from'],
                'period_to' => $data['period_to'],
                'status' => 'draft',
                'prepared_by' => $data['prepared_by'] ?? null,
                'retention_basis_points' => (int) ($data['retention_basis_points']
                    ?? $previous?->retention_basis_points
                    ?? RetentionRule::STATUTORY_CAP_BASIS_POINTS),
            ]);

            // Every schedule-of-values line carries forward, with previous
            // completed value seeded from the last application. Seeding it is
            // not a convenience: a hand-typed "previous completed" column is how
            // an application stops reconciling against the last certified one,
            // and that is a hard-invalid finding.
            $carry = [];
            foreach ($previous?->lines ?? [] as $line) {
                $carry[(int) $line->schedule_of_value_item_id] =
                    (int) $line->previous_completed_cents + (int) $line->this_period_cents;
            }

            foreach (ScheduleOfValueItem::query()->where('project_id', $project->id)->get() as $item) {
                PayApplicationLine::create([
                    'tenant_id' => $project->tenant_id,
                    'pay_application_id' => $application->id,
                    'schedule_of_value_item_id' => $item->id,
                    'previous_completed_cents' => $carry[$item->id] ?? 0,
                    'this_period_cents' => 0,
                    'stored_materials_cents' => 0,
                ]);
            }

            return $application;
        });

        return response()->json($this->envelope($application->fresh(), $project), 201);
    }

    /**
     * Bill a line. Draft only - an application that has gone out is a record of
     * what was asserted on a date, and editing it afterwards would destroy the
     * only thing that makes it evidence.
     */
    public function updateLine(Request $request, PayApplication $application, PayApplicationLine $line)
    {
        $project = $this->access->authorize($request->user(), (int) $application->project_id, 'payment.bill', write: true)->project;
        abort_unless((int) $line->pay_application_id === (int) $application->id, 404, 'That line does not belong to this pay application.');
        abort_unless(in_array($application->status, ['draft', 'certified'], true), 422,
            'This application has already been submitted. Bill the correction on the next application - a submitted application is a dated assertion and is not edited afterwards.');

        $data = $request->validate([
            'this_period_cents' => 'nullable|integer|min:0',
            'stored_materials_cents' => 'nullable|integer|min:0',
            'pending_change_value_cents' => 'nullable|integer|min:0',
            'stored_material_adjustment_cents' => 'nullable|integer',
            'stored_material_adjustment_reason' => 'nullable|string|max:500',
            'deducted_scope_attribution' => 'nullable|string|max:1000',
        ]);

        $changes = array_filter($data, fn ($v) => $v !== null);

        // A request carrying only unrecognized fields validates down to an
        // empty $changes array - a true no-op. Updating prepared_by anyway
        // would misattribute the line to whoever happened to send the dead
        // request, which is exactly the "fake edit" the audit trail must not
        // record (see EditEndpointsDoNotLogNoOpEditsTest for the same rule
        // applied to RFIs/submittals/quality items).
        if ($changes === []) {
            return response()->json($this->envelope($application, $project));
        }

        $before = ApplicationContentHash::of($application, $this->retention($application, $project), $this->previouslyPaid($application));
        $line->update($changes);

        // Whoever last touched the numbers is the preparer. It is a fact about
        // what happened, not a role somebody was assigned.
        $application->forceFill(['prepared_by' => $request->user()->id])->save();

        $application = $application->fresh();
        $voided = false;

        if ($application->status === 'certified'
            && ApplicationContentHash::of($application, $this->retention($application, $project), $this->previouslyPaid($application)) !== $before) {
            // A certification that survives an edit to the numbers it covered is
            // a signature on a document that changed afterwards. Two-person
            // review would be cosmetic.
            $application->forceFill([
                'status' => 'draft', 'certified_by' => null,
                'certified_at' => null, 'certified_content_hash' => null,
                'seal' => array_merge((array) $application->seal, [
                    'certification_voided_at' => now()->toIso8601String(),
                    'certification_voided_by' => $request->user()->id,
                    'certification_voided_reason' => 'The financial content changed after certification.',
                ]),
            ])->save();
            $voided = true;
            $application = $application->fresh();
        }

        return response()->json(array_merge($this->envelope($application, $project), $voided
            ? ['notice' => 'The certification on this application is void. The numbers it covered have changed, so it needs certifying again.']
            : []));
    }

    /**
     * Certify. A person puts their name to an exact set of numbers.
     *
     * Separate from submission because on any project above a couple of dozen
     * people they are separate acts by separate people, and collapsing them
     * would make the two-person control unrepresentable.
     */
    public function certify(Request $request, PayApplication $application)
    {
        $project = $this->access->authorize($request->user(), (int) $application->project_id, 'payment.certify', write: true)->project;
        abort_unless($application->status === 'draft', 422, 'Only a draft application can be certified.');

        if ($request->boolean('certification_accepted') !== true) {
            return response()->json([
                'refused' => true,
                'reason' => 'This application has not been certified. A pay application is a signed representation, and ZecoCM does not make it on anyone\'s behalf.',
                'certification' => CertificationStatement::toArray(),
            ], 422);
        }

        // Two-person certification, where the project's payment workflow says so.
        // Holding both permissions is not the same as being two people.
        $workflow = (array) ($project->payment_workflow ?? []);
        if (($workflow['requires_separate_certifier'] ?? false) === true
            && (int) $application->prepared_by === (int) $request->user()->id) {
            return response()->json([
                'refused' => true,
                'reason' => 'This project requires the person certifying to be someone other than the person who prepared the billing. You entered the numbers on this application.',
            ], 422);
        }

        // THE RACE, and it is the worst bug available in this whole module.
        //
        // The preparer opens version A. The certifier opens version A. Before
        // the certifier clicks, the preparer raises a line to version B. The
        // certifier's screen still shows A. They click Certify, and the server
        // applies the certification to B.
        //
        // ZecoCM would then hold a record saying a second person independently
        // certified figures they never saw. That is far worse than a disabled
        // button failing, because the evidentiary record itself becomes false -
        // and this system's entire claim is that its record is not.
        //
        // So the certifier tells us which version they are signing, and if it
        // is not the current one we refuse with 409 rather than 422. This is a
        // conflict, not a validation failure, and the difference matters to
        // anyone writing a client against it.
        $seen = (string) $request->input('content_hash_seen', '');
        $current = ApplicationContentHash::of($application, $this->retention($application, $project), $this->previouslyPaid($application));

        if ($seen === '') {
            return response()->json([
                'refused' => true,
                'reason' => 'Certification must name the version being certified. Send content_hash_seen with the hash shown on the screen the certifier reviewed.',
                'current_content_hash' => $current,
            ], 422);
        }

        if ($seen !== $current) {
            return response()->json([
                'refused' => true,
                'reason' => 'This pay application changed after you opened it. Your certification was not recorded. Review the current version before certifying.',
                'current_content_hash' => $current,
            ], 409);
        }

        $findings = $this->review($application, $project, $request);

        if (PayApplicationReview::blocksSubmission($findings)) {
            return response()->json([
                'refused' => true,
                'reason' => 'This request would be structurally improper. No payment clock would start on it.',
                'findings' => $findings,
            ], 422);
        }

        $application->forceFill([
            'status' => 'certified',
            'certified_by' => $request->user()->id,
            'certified_at' => now(),
            // Exactly what was certified. A signature on a document that can
            // still change is not a signature.
            // Exactly the version the certifier confirmed they had reviewed.
            'certified_content_hash' => $current,
            'seal' => array_merge((array) $application->seal, [
                'certified_by_name' => $request->user()->name,
                'certification_version' => CertificationStatement::VERSION,
                'certified_at' => now()->toIso8601String(),
            ]),
        ])->save();

        return response()->json(array_merge($this->envelope($application->fresh(), $project), [
            'notice' => 'Certified. Any change to the billed numbers from here voids this certification.',
        ]));
    }

    /**
     * Submit. The refusal here is the product.
     */
    public function submit(Request $request, PayApplication $application)
    {
        $project = $this->access->authorize($request->user(), (int) $application->project_id, 'payment.submit', write: true)->project;
        abort_unless(in_array($application->status, ['draft', 'certified'], true), 422, 'This application has already been submitted.');

        // The stale-certification check runs FIRST, before the findings. If
        // something moved after somebody signed, that is the primary fact about
        // this application. Reporting that the retention is inconsistent, when
        // the actual news is that the rule changed underneath a signed document,
        // sends the user to fix the wrong thing.
        if ($application->status === 'certified'
            && $application->certified_content_hash !== ApplicationContentHash::of($application, $this->retention($application, $project), $this->previouslyPaid($application))) {
            return response()->json([
                'refused' => true,
                'reason' => 'The billed numbers have changed since this application was certified. It needs certifying again by someone who has seen the current figures.',
            ], 422);
        }

        $findings = $this->review($application, $project, $request);

        if (PayApplicationReview::blocksSubmission($findings)) {
            return response()->json([
                'refused' => true,
                'reason' => 'This request would be structurally improper. No payment clock would start on it.',
                'findings' => $findings,
            ], 422);
        }

        // The certification is a person's assertion, so it is made by a person.
        // Defaulting it to accepted would make this software the certifier of a
        // claim for public money on facts it never examined.
        if ($application->status === 'certified') {
            // Verified above, before anything else.
        } elseif ($request->boolean('certification_accepted') !== true) {
            return response()->json([
                'refused' => true,
                'reason' => 'This application has not been certified. A pay application is a signed representation, and ZecoCM does not make it on anyone\'s behalf.',
                'certification' => CertificationStatement::toArray(),
            ], 422);
        } elseif ((($project->payment_workflow ?? [])['requires_separate_certifier'] ?? false) === true) {
            return response()->json([
                'refused' => true,
                'reason' => 'This project requires a separate certifier. Certify the application as its own step so that the two acts are recorded as two acts by two people.',
            ], 422);
        }

        $policy = SubmissionPolicy::resolve($findings, SubmissionPolicy::rulesForProject($project->id));

        // A returnable defect the contract makes mandatory stops it here.
        if ($policy['state'] === 'cannot_submit') {
            return response()->json([
                'refused' => true,
                'reason' => 'A governing rule on this project makes the outstanding item a condition of a processable payment request.',
                'findings' => $findings, 'submission' => $policy,
            ], 422);
        }

        // And where no governing rule is on file, this software will not guess
        // that the agency accepts it. A named person can proceed anyway - that
        // is a judgement, and it is recorded as one rather than absorbed as a
        // default.
        if ($policy['state'] === 'requirement_unresolved') {
            $acknowledgement = trim((string) $request->input('acknowledgement', ''));

            if ($acknowledgement === '') {
                return response()->json([
                    'refused' => true,
                    'reason' => 'This application has an outstanding item and no governing rule on file says whether this agency processes a request without it. ZecoCM will not assume it does. Record the contract or agency procedure that governs, or submit with a written acknowledgement that you are proceeding without one.',
                    'findings' => $findings, 'submission' => $policy,
                ], 422);
            }

            $application->forceFill(['clock_snapshot' => array_merge((array) $application->clock_snapshot, [
                'unresolved_submission_requirements' => $policy['unresolved_codes'],
                'acknowledged_by' => $request->user()->id,
                'acknowledgement' => $acknowledgement,
                'acknowledged_at' => now()->toIso8601String(),
            ])])->save();
        }

        $application->forceFill(array_merge(
            ['status' => 'submitted', 'submitted_at' => now()],
            $application->certified_by === null
                ? ['certified_by' => $request->user()->id, 'certified_at' => now(),
                    'certified_content_hash' => ApplicationContentHash::of($application, $this->retention($application, $project), $this->previouslyPaid($application)),
                    'seal' => array_merge((array) $application->seal, [
                        'certified_by_name' => $request->user()->name,
                        'certification_version' => CertificationStatement::VERSION,
                        'certified_at' => now()->toIso8601String(),
                    ])]
                : [],
        ))->save();

        $withheld = PayApplicationReview::withholdings($findings);
        $exposure = PayApplicationReview::exposure($findings);

        return response()->json([
            'application' => $this->envelope($application->fresh(), $project),
            'notice' => $withheld === []
                ? 'Submitted. The thirty-day payment clock runs from receipt of a proper, undisputed request.'
                : 'Submitted. '.count($withheld).' compliance finding(s) may reduce or hold the amount paid'
                    .($exposure['computable_cents'] > 0
                        ? ', of which $'.number_format($exposure['computable_cents'] / 100, 2).' is computable from a governing determination'
                        : '; none of them carries an amount this system is willing to assert')
                    .'. The request itself is proper - the payment clock still runs.',
            'exposure' => $exposure,
            'submission' => $policy,
        ]);
    }

    /**
     * A human decided this TRACE finding needs no further action - float
     * absorbed it, the work was documented elsewhere, whatever the reason.
     * Recorded, never silently deleted: the resolution_note is the audit
     * trail for why a real gap was not pursued.
     */
    public function dismissTraceFinding(Request $request, PayApplication $application, AiFinding $finding)
    {
        $this->access->authorize($request->user(), (int) $application->project_id, 'payment.trace_review', write: true);
        abort_unless($finding->pay_application_id === $application->id, 404, 'That finding does not belong to this pay application.');
        abort_unless($finding->status === AiFinding::STATUS_OPEN, 422, 'This finding has already been resolved.');

        $data = $request->validate(['note' => 'nullable|string|max:2000']);
        $finding->update(['status' => AiFinding::STATUS_DISMISSED, 'resolved_by' => $request->user()->id,
            'resolved_at' => now(), 'resolution_note' => $data['note'] ?? null]);

        return response()->json(['finding' => $finding->fresh()]);
    }

    /**
     * A human decided a TRACE finding is worth pursuing as a real payment
     * review item. This is the ONLY path from an AiFinding into anything
     * that can affect an amount paid - TRACE itself never withholds. What
     * "pursuing" means today is recorded here, on the finding; a specific
     * WITHHOLD/RETURNABLE line item on this or a later pay application is
     * the reviewer's own subsequent, ordinary action, not something this
     * endpoint creates automatically.
     */
    public function promoteTraceFinding(Request $request, PayApplication $application, AiFinding $finding)
    {
        $this->access->authorize($request->user(), (int) $application->project_id, 'payment.trace_review', write: true);
        abort_unless($finding->pay_application_id === $application->id, 404, 'That finding does not belong to this pay application.');
        abort_unless($finding->status === AiFinding::STATUS_OPEN, 422, 'This finding has already been resolved.');

        $data = $request->validate(['note' => 'required|string|max:2000']);
        $finding->update(['status' => AiFinding::STATUS_PROMOTED, 'resolved_by' => $request->user()->id,
            'resolved_at' => now(), 'resolution_note' => $data['note']]);

        return response()->json(['finding' => $finding->fresh()]);
    }

    // ---- shared computation ----------------------------------------------------

    private function envelope(PayApplication $application, Project $project): array
    {
        $findings = $this->review($application, $project);
        $retention = $this->retention($application, $project);
        $summary = PayApplicationMath::summarize($application, $this->previouslyPaid($application), $retention);

        return [
            'application' => $application->load('lines.item'),
            'summary' => $summary,
            'findings' => $findings,
            'withholdings' => PayApplicationReview::withholdings($findings),
            // Split, because a condition that is grounds for withholding is not
            // an amount. Only computable exposure carries a number.
            'exposure' => PayApplicationReview::exposure($findings),
            'blocks_submission' => PayApplicationReview::blocksSubmission($findings),
            // What the button is allowed to say, resolved from the project's
            // governing rules rather than from a default.
            'submission' => SubmissionPolicy::resolve($findings, SubmissionPolicy::rulesForProject($project->id)),
            'retention_rule' => ['basis_points' => $retention->basisPoints, 'source' => $retention->source,
                'confirmed' => $retention->confirmed],
            // Shown beside the submit control, never behind a link. What this
            // software did not examine is half the statement.
            'certification' => CertificationStatement::toArray(),
            // The version identifier a certifier must send back. Without it on
            // the screen, the client cannot tell us what it showed.
            'content_hash' => ApplicationContentHash::of($application, $retention, $this->previouslyPaid($application)),
            // Frozen money is reported BESIDE the amount due, never subtracted
            // from it. The contractor is still owed the full earned figure; a
            // served stop payment notice stops it moving, and a system that
            // quietly lowered the earned amount would have misstated the
            // contract to both parties.
            'stop_notice_funds' => $this->frozenFunds($application, $project, $summary['current_payment_due_cents']),
            // TRACE Progress Evidence Cross-Check - deliberately its own key,
            // never merged into `findings`/`blocks_submission`/`submission`
            // above. Those are payment-review conclusions this software is
            // willing to assert (HARD_INVALID/RETURNABLE/WITHHOLD); TRACE
            // never adjudicates, so a TRACE finding cannot itself withhold or
            // block anything - a human converts one into a real review item
            // by calling promoteTraceFinding() below, which is the only path
            // from this key into the findings above (a future
            // finding/withhold on THIS OR A LATER pay application, at the
            // reviewer's own judgment, not automatically).
            'trace_cross_check' => $this->traceCrossCheck($application),
            'computed_at' => now()->toIso8601String(),
        ];
    }

    /** @return array{items: list<array<string,mixed>>, open_count: int} */
    private function traceCrossCheck(PayApplication $application): array
    {
        (new ProgressEvidenceCrossCheckService)->evaluate($application);

        $findings = AiFinding::where('pay_application_id', $application->id)
            ->with('evidence')->orderByDesc('id')->get();

        return [
            'items' => $findings->map(fn (AiFinding $f) => [
                'id' => $f->id,
                'rule_id' => $f->rule_id,
                'rule_version' => $f->rule_version,
                'category' => $f->category,
                'finding_class' => $f->finding_class,
                'severity' => $f->severity,
                'summary' => $f->summary,
                'status' => $f->status,
                'evaluated_at' => $f->evaluated_at?->toIso8601String(),
                'resolution_note' => $f->resolution_note,
                'evidence' => $f->evidence->map(fn ($e) => [
                    'source_type' => $e->source_type, 'source_id' => $e->source_id,
                    'evidence_role' => $e->evidence_role,
                ])->all(),
            ])->all(),
            'open_count' => $findings->where('status', AiFinding::STATUS_OPEN)->count(),
        ];
    }

    /**
     * @return array{earned_cents: int, frozen_cents: int, payable_cents: int, fully_frozen: bool, notices: list<array<string,mixed>>}
     */
    private function frozenFunds(PayApplication $application, Project $project, int $earnedCents): array
    {
        $notices = StopPaymentNotice::query()->where('project_id', $project->id)->get()
            ->map(fn ($n) => [
                'claimant_name' => $n->claimant_name,
                'claimant_role' => $n->claimant_role,
                'claimed_amount_cents' => (int) $n->claimed_amount_cents,
                'served_on' => $n->served_on?->toDateString(),
                'status' => $n->status,
                'preliminary_notice_on_file' => (bool) $n->preliminary_notice_on_file,
                'release_bond_on_file' => (bool) $n->release_bond_on_file,
            ])->all();

        $required = StopNoticeWithholding::required($notices);

        return StopNoticeWithholding::payable($earnedCents, $required['total_withheld_cents'])
            + ['notices' => $required['active']];
    }

    private function digest(PayApplication $application, Project $project): array
    {
        $summary = PayApplicationMath::summarize($application, $this->previouslyPaid($application), $this->retention($application, $project));

        return ['id' => $application->id, 'number' => $application->number, 'status' => $application->status,
            'period_from' => $application->period_from?->toDateString(), 'period_to' => $application->period_to?->toDateString(),
            'current_payment_due_cents' => $summary['current_payment_due_cents'],
            'percent_complete_basis_points' => $summary['percent_complete_basis_points']];
    }

    /** @return list<array{severity: string, code: string, message: string, citation: ?string}> */
    private function review(PayApplication $application, Project $project, ?Request $request = null): array
    {
        $context = [];

        $prior = PayApplication::query()->where('project_id', $project->id)
            ->where('number', '<', $application->number)->orderByDesc('number')->with('lines')->first();
        if ($prior !== null) {
            $context['prior_certified_paid_cents'] = 0;
            foreach ($prior->lines as $line) {
                $context['prior_certified_paid_cents'] += (int) $line->previous_completed_cents + (int) $line->this_period_cents;
            }
        }

        // Stored-material roll-forward needs the last certified application
        // beside this one. Neither alone can show the movement.
        if ($prior !== null) {
            $priorStored = [];
            foreach ($prior->lines as $line) {
                $priorStored[(int) $line->schedule_of_value_item_id] = [
                    'stored_cents' => (int) $line->stored_materials_cents,
                    'completed_cents' => (int) $line->previous_completed_cents + (int) $line->this_period_cents,
                ];
            }

            $currentStored = [];
            $application->loadMissing('lines.item');
            foreach ($application->lines as $line) {
                $currentStored[(int) $line->schedule_of_value_item_id] = [
                    'item_number' => (string) ($line->item?->item_number ?? $line->id),
                    'stored_cents' => (int) $line->stored_materials_cents,
                    'completed_cents' => (int) $line->previous_completed_cents + (int) $line->this_period_cents,
                    'adjustment_cents' => (int) $line->stored_material_adjustment_cents,
                    'adjustment_reason' => $line->stored_material_adjustment_reason,
                ];
            }

            $context['prior_certified_stored'] = $priorStored;
            $context['current_stored'] = $currentStored;
        }

        // Deductive change orders touching the lines on this application. The
        // deduction is read from the approved allocations rather than inferred
        // from a value that moved, because a scheduled value can fall for more
        // than one reason.
        $application->loadMissing('lines.item');
        $itemIds = $application->lines->pluck('schedule_of_value_item_id')->filter()->all();

        if ($itemIds !== []) {
            // Raw query: no global scope reaches it, so the tenant is named.
            $deductions = DB::table('change_order_allocations as a')
                ->join('change_orders as c', 'c.id', '=', 'a.change_order_id')
                ->where('c.tenant_id', $project->tenant_id)
                ->whereIn('a.schedule_of_value_item_id', $itemIds)
                ->where('c.status', 'approved')
                ->where('a.amount_cents', '<', 0)
                ->groupBy('a.schedule_of_value_item_id')
                ->selectRaw('a.schedule_of_value_item_id as item_id, SUM(a.amount_cents) as total, MIN(c.number) as co_number, MIN(c.approved_at) as effective_at')
                ->get()->keyBy('item_id');

            $deductedLines = [];
            foreach ($application->lines as $line) {
                $deduction = $deductions[$line->schedule_of_value_item_id] ?? null;
                if ($deduction === null) {
                    continue;
                }

                $deductedLines[] = [
                    'item_number' => (string) ($line->item?->item_number ?? $line->id),
                    'scheduled_value_cents' => (int) ($line->item?->scheduled_value_cents ?? 0),
                    'original_value_cents' => (int) ($line->item?->original_value_cents ?? 0),
                    'deducted_cents' => abs((int) $deduction->total),
                    'change_order_number' => $deduction->co_number,
                    'effective_at' => $deduction->effective_at,
                    'this_period_cents' => (int) $line->this_period_cents,
                    'stored_materials_cents' => (int) $line->stored_materials_cents,
                    'previous_completed_cents' => (int) $line->previous_completed_cents,
                    'attribution' => $line->deducted_scope_attribution,
                ];
            }

            if ($deductedLines !== []) {
                $context['deducted_lines'] = $deductedLines;
            }
        }

        // Certified payroll is supplied by the caller for now: the payroll import
        // is a separate surface, and inventing an empty record set here would
        // silently report a clean payroll on a project that has filed none.
        if ($request !== null && is_array($request->input('certified_payroll'))) {
            $context['certified_payroll'] = $request->input('certified_payroll');
        }

        // Who has to have released, what they have released, and what is frozen.
        //
        // The claimant list is drawn from executed subcontracts rather than from
        // whoever happens to have filed a release: a sub that has never sent one
        // is precisely the one worth naming, and a list built from the releases
        // on file could never contain it.
        $claimants = Subcontract::query()
            ->where('project_id', $project->id)
            ->whereIn('status', ['executed', 'complete'])
            ->with('partner')
            ->get()
            ->map(fn ($s) => $s->partner?->legal_name)
            ->filter()
            ->unique()
            ->values()
            ->all();

        if ($claimants !== []) {
            $context['required_claimants'] = $claimants;
            $context['period_end'] = $application->period_to?->toDateString();
            $context['prior_period_end'] = $prior?->period_to?->toDateString();
            $context['releases'] = LienRelease::query()
                ->where('project_id', $project->id)
                ->get()
                ->map(fn ($r) => [
                    'claimant_name' => $r->claimant_name,
                    'form_type' => $r->form_type,
                    'through_date' => $r->through_date?->toDateString(),
                    'document_on_file' => (bool) $r->document_on_file,
                    'exceptions_stated' => (bool) $r->exceptions_stated,
                    'exceptions' => $r->exceptions,
                    'payment_cleared_on' => $r->payment_cleared_on?->toDateString(),
                ])->all();
        }

        $notices = StopPaymentNotice::query()->where('project_id', $project->id)->get();
        if ($notices->isNotEmpty()) {
            $context['stop_payment_notices'] = $notices->map(fn ($n) => [
                'claimant_name' => $n->claimant_name,
                'claimant_role' => $n->claimant_role,
                'claimed_amount_cents' => (int) $n->claimed_amount_cents,
                'served_on' => $n->served_on?->toDateString(),
                'status' => $n->status,
                'preliminary_notice_on_file' => (bool) $n->preliminary_notice_on_file,
                'release_bond_on_file' => (bool) $n->release_bond_on_file,
            ])->all();
        }

        return PayApplicationReview::findings($application, $this->retention($application, $project), $context);
    }

    private function retention(PayApplication $application, Project $project): RetentionRule
    {
        // The contract's rule when a human has read it out of the contract.
        // Otherwise the rate typed on the application, explicitly unconfirmed -
        // which raises a returnable finding rather than pretending to know.
        return RetentionRule::fromProjectTerms($project->payment_terms)
            ?? new RetentionRule(
                basisPoints: (int) $application->retention_basis_points,
                source: 'Rate recorded on this application. Not confirmed against the contract.',
                confirmed: false,
            );
    }

    private function previouslyPaid(PayApplication $application): int
    {
        $paid = 0;
        foreach (PayApplication::query()->where('project_id', $application->project_id)
            ->where('number', '<', $application->number)->where('status', 'paid')->with('lines')->get() as $earlier) {
            $summary = PayApplicationMath::summarize($earlier);
            $paid += $summary['earned_less_retention_cents'];
        }

        return $paid;
    }
}
