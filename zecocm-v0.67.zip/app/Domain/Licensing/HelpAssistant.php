<?php

namespace App\Domain\Licensing;

use App\Models\Tenant;

/**
 * The FREE tier: ZecoCM explaining itself.
 *
 * Deterministic retrieval over the capability catalogue plus a small set of
 * how-the-system-works topics. It costs nothing to run, cannot leak tenant data
 * because it never touches project evidence, and cannot draft a contract document.
 * Every account gets it, always.
 */
final class HelpAssistant
{
    /** How-the-system-works topics, generated from the product's own rules. */
    private const TOPICS = [
        'evidence' => [
            'title' => 'How evidence works in ZecoCM',
            'body' => 'Every record you submit is sealed: the file is hashed, the author and time are bound to it, and it cannot be edited or replaced afterwards. Corrections append to the record instead of overwriting it, so the history of what was known - and when - stays intact.',
            'keywords' => ['evidence', 'seal', 'sealed', 'immutable', 'hash', 'provenance', 'correction', 'audit', 'history'],
        ],
        'authority' => [
            'title' => 'Who can authorise what',
            'body' => 'ZecoCM computes facts and clocks the same way for everyone, then filters what each person may see by their project grant. Formal actions - issuing a notice, approving payment, signing, accepting a schedule, making a design or life-safety judgement - always require an accountable human. The system never issues them on its own.',
            'keywords' => ['authority', 'authorise', 'authorize', 'approve', 'sign', 'permission', 'role', 'who can', 'seat'],
        ],
        'tenant' => [
            'title' => 'How accounts stay separate',
            'body' => 'Each customer account is walled off. A request without a valid account context matches nothing at all rather than falling back to a default, so one customer can never see another customer\'s records.',
            'keywords' => ['tenant', 'account', 'separate', 'isolation', 'other customer', 'privacy', 'wall'],
        ],
        'ai' => [
            'title' => 'The two levels of AI assistance',
            'body' => 'This help assistant is free with every account and answers questions about ZecoCM itself - how a screen works, what a capability does, the basics of public-works administration. It never reads your project records. The paid AI project assistance tier is different: it answers from your own project evidence with citations, and helps you draft and prepare RFIs, submittals and notices. It is licensed per account for a set period.',
            'keywords' => ['ai', 'assistant', 'help', 'draft', 'drafting', 'chatbot', 'ask', 'licence', 'license', 'cost', 'price', 'pay', 'upgrade'],
        ],
        'clocks' => [
            'title' => 'Contract clocks',
            'body' => 'Review periods come from the project\'s own contract settings, not from a fixed default. When something is submitted, its clock starts; when the ball moves to another party, the clock follows it. Anything past its window shows up in your court and generates its own notice.',
            'keywords' => ['clock', 'due', 'deadline', 'review period', 'late', 'overdue', 'my court', 'days'],
        ],
        'schedule' => [
            'title' => 'Schedule intelligence',
            'body' => 'You submit a schedule export (CSV, XLSX or Microsoft Project XML) and it is stored as an immutable version. Comparing two versions runs a deterministic check - no AI - and produces a change ledger where date movements are reported in calendar days and duration or float movements in working days, each carrying the source hashes of both versions.',
            'keywords' => ['schedule', 'cpm', 'baseline', 'update', 'delta', 'compare', 'float', 'critical path', 'xml', 'primavera', 'microsoft project'],
        ],
        'start' => [
            'title' => 'Getting started',
            'body' => 'Open a project from your projects list, then work from "In my court" - it shows only what is waiting on you, computed from the project\'s real records and clocks. Capabilities your account is licensed for appear in the sidebar; anything not licensed or not yet built is labelled honestly rather than hidden or faked.',
            'keywords' => ['start', 'begin', 'how do i', 'getting started', 'first', 'new', 'training', 'learn', 'tutorial'],
        ],
        'licensed_standards' => [
            'title' => 'Why TRACE will not quote the Greenbook (or other licensed standards)',
            'body' => 'The Greenbook / SSPWC, and standards like ICC/Title 24, NFPA and AIA documents, are copyrighted publications ZecoCM does not hold a redistribution licence for. TRACE never ingests their text, so it cannot quote or paraphrase specific sections from them - reproducing that would be infringement no matter how the retrieval is designed. What TRACE CAN do: cite the standard by title, edition and section number as a reference (a "citation stub"), and tell you the standard applies to a question, while pointing you to your own licensed copy for the actual wording. If TRACE gave you a vague or empty answer on a Greenbook question, that is this rule working as intended, not a malfunction - ask it to name which section applies instead of asking it to quote the text.',
            'keywords' => ['greenbook', 'green book', 'sspwc', 'standard specifications', 'icc', 'title 24', 'nfpa', 'copyrighted standard', 'licensed standard'],
        ],
    ];

    /** @return array<string,mixed> */
    public function answer(string $question, ?Tenant $tenant = null): array
    {
        $q = mb_strtolower(trim($question));
        $license = new CapabilityLicense;

        $topics = [];
        foreach (self::TOPICS as $key => $topic) {
            $score = 0;
            foreach ($topic['keywords'] as $kw) {
                if (str_contains($q, $kw)) {
                    $score += mb_strlen($kw);
                }
            }
            if ($score > 0) {
                $topics[] = ['key' => $key, 'score' => $score] + $topic;
            }
        }

        $capabilities = [];
        foreach (CapabilityCatalog::all() as $key => $meta) {
            $haystack = mb_strtolower($meta['label'].' '.$key.' '.($meta['summary'] ?? '').' '.($meta['group'] ?? ''));
            $score = 0;
            foreach (preg_split('/[^a-z0-9]+/', $q, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $word) {
                if (mb_strlen($word) >= 4 && str_contains($haystack, $word)) {
                    $score += mb_strlen($word);
                }
            }
            if ($score > 0) {
                $entry = ['capability' => $key, 'label' => $meta['label'], 'summary' => $meta['summary'] ?? null, 'score' => $score];
                if ($tenant !== null) {
                    $state = $license->state($tenant, $key);
                    $entry['state'] = $state->state;
                    $entry['available_to_you'] = $state->allows();
                }
                $capabilities[] = $entry;
            }
        }

        usort($topics, fn ($a, $b) => $b['score'] <=> $a['score']);
        usort($capabilities, fn ($a, $b) => $b['score'] <=> $a['score']);
        $topics = array_slice($topics, 0, 2);
        $capabilities = array_slice($capabilities, 0, 4);

        if ($topics === [] && $capabilities === []) {
            return [
                'kind' => 'no_match',
                'tier' => 'free_help',
                'message' => 'I could not match that to anything in the ZecoCM handbook. This free assistant explains how ZecoCM works - screens, capabilities, evidence rules and contract clocks. Questions about the facts inside your own project need the AI project assistance tier, which reads your authorised project records.',
                'suggested_topics' => array_map(fn ($t) => $t['title'], array_values(self::TOPICS)),
            ];
        }

        return [
            'kind' => 'help',
            'tier' => 'free_help',
            'answer' => array_map(fn ($t) => ['title' => $t['title'], 'body' => $t['body']], $topics),
            'capabilities' => array_map(fn ($c) => array_diff_key($c, ['score' => 1]), $capabilities),
            'source' => 'ZecoCM capability catalogue and product rules',
            'boundary' => 'This free assistant answers about ZecoCM itself. It does not read your project records and cannot draft contract documents.',
        ];
    }
}
