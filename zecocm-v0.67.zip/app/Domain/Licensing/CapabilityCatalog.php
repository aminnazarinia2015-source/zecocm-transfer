<?php

namespace App\Domain\Licensing;

/**
 * The single source of truth for what ZecoCM can do, what it costs, and what is
 * actually built. The catalogue is also the corpus the FREE help assistant answers
 * from - the system documents its own capabilities.
 *
 * tier:        free      - always on for every account, never billed, never licensed
 *              licensed  - requires an active, in-window capability grant
 * operational: true      - really works end to end today
 *              false     - planned; shown as roadmap, never sold as available
 */
final class CapabilityCatalog
{
    public const TIER_FREE = 'free';

    public const TIER_LICENSED = 'licensed';

    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        return [
            // ---- FREE, always on -------------------------------------------------
            'ai.help' => [
                'label' => 'TRACE help & training',
                'tier' => self::TIER_FREE,
                'operational' => true,
                'group' => 'Assistance',
                'summary' => 'TRACE answering questions about ZecoCM itself: how to use each screen, what a capability does, and the basics of public-works administration. Reads the ZecoCM knowledge base only - never your project evidence - and cannot draft contract documents.',
            ],
            'account' => [
                'label' => 'Account & profile',
                'tier' => self::TIER_FREE,
                'operational' => true,
                'group' => 'Core',
                'summary' => 'Profile, password, company logo, sign-in security.',
            ],
            'projects' => [
                'label' => 'Projects',
                'tier' => self::TIER_FREE,
                'operational' => true,
                'group' => 'Core',
                'summary' => 'Create and open the projects inside your own account.',
            ],

            // ---- LICENSED, operational today ------------------------------------
            'ai.assist' => [
                'label' => 'TRACE project assistance',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Assistance',
                'metered' => true,
                'summary' => 'TRACE - Traceable Record-Anchored Cited Evidence. Cited answers grounded in THIS project\'s own authorised records, plus drafting and preparation help for RFIs, submittals and notices. TRACE cites or refuses; it never decides, and every formal action still requires an accountable human.',
            ],
            'submittals' => [
                'label' => 'Submittals',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Deliver & review',
                'summary' => 'Submittal register, spec-section routing, review clocks and stamping.',
            ],
            'rfis' => [
                'label' => 'RFIs',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Deliver & review',
                'summary' => 'RFI register, ball-in-court clocks and sealed responses.',
            ],
            'daily_reports' => [
                'label' => 'Daily reports',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Deliver & review',
                'summary' => 'Field daily reports with sealed signatures; corrections append.',
            ],
            'daily_brief' => [
                'label' => 'Daily Project Success Brief',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Plan & control',
                'summary' => 'A daily position statement assembled deterministically from this project\'s own sealed records and contract clocks. Every line carries its citations, its epistemic type, its freshness and a derived confidence, and anything the system cannot know is printed as an explicit refusal. No language model writes any part of it.',
            ],
            'documents.transmittal' => [
                'label' => 'Branded RFI & submittal documents',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Information & evidence',
                'summary' => 'Issue-ready RFI and submittal transmittals composed from the record itself and branded to YOUR account and your counterparty - never to ZecoCM. Parties, precedence of contract instruments, contract clock and sealed attachment hashes are derived, not typed.',
            ],
            'schedule_intelligence' => [
                'label' => 'Schedule intelligence',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Plan & control',
                'summary' => 'Immutable schedule versions, deterministic CPM checks and an authorisation-filtered delta ledger.',
            ],
            'documents' => [
                'label' => 'Project documents',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Information & evidence',
                'summary' => 'Ingest specifications and contracts as searchable, tenant-scoped evidence.',
            ],
            'photos' => [
                'label' => 'Photos & media',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Information & evidence',
                'summary' => 'Media upload with SHA-256 provenance sealing.',
            ],
            'weather' => [
                'label' => 'Weather intelligence',
                'tier' => self::TIER_LICENSED,
                'operational' => true,
                'group' => 'Plan & control',
                'summary' => 'Live forecast bound to project coordinates, with cited weather notices.',
            ],

            // ---- LICENSED, planned (roadmap - never sold as available) -----------
            'lookahead' => ['label' => 'Look-ahead schedule', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Plan & control', 'summary' => 'Three-week rolling look-ahead with constraint tracking.'],
            // Built in v0.22: inspection/observation/deficiency/punch capture with an
            // accountable closure rule and a hash-chained event history. Leaving this
            // 'operational' => false hid the finished module from live navigation.
            'inspections' => ['label' => 'Inspections & punch', 'tier' => self::TIER_LICENSED, 'operational' => true, 'group' => 'Deliver & review', 'summary' => 'Inspection, observation, deficiency and punch capture. Closure requires an accountable formal determination - a party claim or an AI recommendation cannot close an item - and every status change appends a hash-chained event.'],
            // Both were marked operational=false long after they shipped. The
            // catalogue lying about itself is a defect in either direction: it
            // hid two finished modules from navigation, which is how the
            // change-order screen sat built and unreachable for a day.
            'change_management' => ['label' => 'Change orders', 'tier' => self::TIER_LICENSED, 'operational' => true, 'group' => 'Contract & commercial', 'summary' => 'Change orders with approval and incorporation kept as two separate acts, allocation to the schedule of values, and a contract-growth bridge that never touches the original contract value.'],
            'pay_apps' => ['label' => 'Payment applications', 'tier' => self::TIER_LICENSED, 'operational' => true, 'group' => 'Contract & commercial', 'summary' => 'Progress billing on a schedule of values, with server-authoritative refusal of structurally improper requests, two-person certification bound to a content hash, and compliance withholdings that reduce the amount without stopping the payment clock.'],
            'payment_security' => ['label' => 'Releases & stop notices', 'tier' => self::TIER_LICENSED, 'operational' => true, 'group' => 'Contract & commercial', 'summary' => 'Waivers and releases under Civil Code ss. 8132-8138 and public-works stop payment notices under ss. 9300-9364. Reported as two totals that are never netted against each other: a release reduces exposure to a claimant, a notice freezes money still owed to the contractor.'],
            // Found marked operational=true with NOTHING built behind it: no route, no
            // controller, no nav view - only a TradePartner model and migration exist.
            // This is the opposite-direction version of the catalogue/gate lying bug
            // (inspections/change_management/timesheets/photos were real features hidden
            // as unavailable; this one was an unbuilt feature sold as available). An
            // account owner licensing this to a sponsored counterparty would find
            // nothing behind it - marking it honestly until it actually ships.
            'trade_partners' => ['label' => 'Trade partners & credentials', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Contract & commercial', 'summary' => 'Subcontractors, suppliers and their subcontracts, with licence, DIR registration, bond and insurance standing answered for the day the work was done rather than for today.'],
            'labor_compliance' => ['label' => 'Labor compliance', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Contract & commercial', 'summary' => 'Certified payroll, prevailing wage and apprenticeship tracking.'],
            'meetings' => ['label' => 'Meetings', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Deliver & review', 'summary' => 'Minutes and action items.'],
            'transmittals' => ['label' => 'Transmittals', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Information & evidence', 'summary' => 'Outbound package transmittals with manifests.'],
            'job_walk' => ['label' => 'Job walk', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Deliver & review', 'summary' => 'Field walk capture with photos and voice notes.'],
            'plans' => ['label' => 'Plans', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Information & evidence', 'summary' => 'Plan sheets and revision identity.'],
            'safety' => ['label' => 'Safety & observations', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Deliver & review', 'summary' => 'Toolbox talks, trainings and break attestations.'],
            'budget' => ['label' => 'Budget & costs', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Contract & commercial', 'summary' => 'Budget, commitments and cost tracking.'],
            // Fully wired: TimeCardController (index/store/show/approve), real time_cards
            // migration, tenant-scoped ProjectAccess authorization, and a live UI (app.html
            // 'timesheets' view - not gated in the client's prototypeOnly list, unlike the
            // other roadmap entries below). Found marked operational=false while genuinely
            // shipped - the same "catalogue lying about itself" bug class as the earlier
            // inspections/change_management mismarkings.
            'timesheets' => ['label' => 'Timesheets', 'tier' => self::TIER_LICENSED, 'operational' => true, 'group' => 'Contract & commercial', 'summary' => 'Crew and equipment hours by cost code.'],
            'closeout' => ['label' => 'Closeout', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Complete & hand over', 'summary' => 'As-builts, O&M, warranties and closeout packages.'],
            'send_to_city' => ['label' => 'Send to City', 'tier' => self::TIER_LICENSED, 'operational' => false, 'group' => 'Complete & hand over', 'summary' => 'Agency-ready sealed package with manifest and hashes.'],
        ];
    }

    public static function has(string $key): bool
    {
        return array_key_exists($key, self::all());
    }

    /** @return array<string,mixed>|null */
    public static function get(string $key): ?array
    {
        return self::all()[$key] ?? null;
    }

    public static function isFree(string $key): bool
    {
        return (self::get($key)['tier'] ?? null) === self::TIER_FREE;
    }

    public static function isOperational(string $key): bool
    {
        return (bool) (self::get($key)['operational'] ?? false);
    }

    /** @return list<string> */
    public static function freeKeys(): array
    {
        return array_keys(array_filter(self::all(), fn ($c) => $c['tier'] === self::TIER_FREE));
    }

    /** @return list<string> */
    public static function licensableKeys(): array
    {
        return array_keys(array_filter(self::all(), fn ($c) => $c['tier'] === self::TIER_LICENSED));
    }
}
