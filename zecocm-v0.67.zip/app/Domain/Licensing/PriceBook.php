<?php

namespace App\Domain\Licensing;

/**
 * What ZecoCM costs to run, and what it may therefore be sold for.
 *
 * This is the back-of-house price book, not a marketing page. Its job is to
 * hold two numbers apart that every software company eventually confuses:
 *
 *   COST TO SERVE  what one account of this size actually consumes in a month -
 *                  infrastructure, model tokens, storage, support time. A real
 *                  number, measured where it can be measured.
 *
 *   PRICE          what the market will pay. Set against the incumbents, not
 *                  against the cost, and constrained from below by the cost.
 *
 * The rule the code enforces, rather than merely documenting: a price below the
 * fully loaded floor is REFUSED. Discounting into a loss is a decision a human
 * may make deliberately, and it must never happen because a sales figure was
 * typed into a box and nothing checked it.
 *
 * The floor is not the raw cost to serve. Cost to serve pays for the servers.
 * The floor also has to carry the people, the selling, and the fact that some
 * accounts leave - so the floor is cost to serve grossed up by the loading in
 * LOADING_BASIS_POINTS below, and that gross-up is the part that pays Zeco's
 * staff and advertising.
 *
 * WHY THE PRICES ARE WHERE THEY ARE. Published incumbent pricing, August 2026:
 * Procore quotes on annual construction volume rather than seats and lands
 * around $4,000-6,000/year under $10M of work, $10,000-15,000 between $10M and
 * $100M, and $20,000+ above that, plus $10,000-25,000 of implementation.
 * Autodesk Build is roughly $1,680 per user per year. Fieldwire runs $39-104
 * per user per month. Buildertrend is $299-499 a month for unlimited users.
 * ZecoCM's structural advantage is that it is one small team and a single
 * droplet rather than a sales organisation, so it can sit materially under the
 * volume-priced incumbents and still clear its floor by a wide margin. That is
 * the whole commercial thesis and it only holds while the floor is checked.
 *
 * NOTHING IN HERE IS A CUSTOMER NUMBER. Every cost figure is a modelled
 * assumption with its basis named, and the ones that are guesses say so. No
 * revenue, traction, or customer count is recorded anywhere in this class.
 */
final class PriceBook
{
    public const DEMO = 'demo';
    public const FIELD = 'field';
    public const PROJECT = 'project';
    public const PROGRAM = 'program';
    public const AGENCY = 'agency';

    /**
     * The gross-up from cost-to-serve to the minimum defensible price.
     *
     * 2.2x. Support time is already inside cost to serve below, so this
     * multiplier does not have to carry it twice. What it carries is the work
     * that exists whether or not this particular account does: building the
     * product, finding the customer, and the accounts that leave before they
     * repay their own onboarding. A price at exactly the floor earns nothing;
     * it merely does not lose.
     */
    public const LOADING_BASIS_POINTS = 22_000;

    /**
     * Monthly cost to serve one account, in micros (millionths of a dollar).
     *
     * `measured` marks a line whose figure comes from something the system
     * actually records. Today only the model spend is measured - D8 put real
     * token accounting behind it - and saying which lines are estimates keeps
     * this table honest as the estimates get replaced.
     *
     * @return array<string,array{micros: int, measured: bool, basis: string}>
     */
    public static function costToServe(string $tier): array
    {
        $line = self::COST_LINES[$tier] ?? self::COST_LINES[self::FIELD];

        return [
            'compute' => [
                'micros' => $line[0],
                'measured' => false,
                'basis' => 'This account\'s share of the application droplet and its bandwidth, apportioned across the projects it runs. Estimate. The droplet is a fixed monthly cost carrying every account, so this line falls as accounts are added and is the single most favourable number in the model.',
            ],
            'storage' => [
                'micros' => $line[1],
                'measured' => false,
                'basis' => 'Evidence media, documents and the off-host backup copy. Estimate. Grows with the AGE of a project rather than with its seats, which is why it is the line that will surprise us in year three.',
            ],
            'model_spend' => [
                'micros' => $line[2],
                'measured' => true,
                'basis' => 'TRACE token cost at the published Anthropic rate. Recorded per run in ai_runs.cost_micros and accumulated on the licence by BudgetGate. This is the only line the system actually measures, it is the largest variable line, and it is the one a heavy user can move on their own.',
            ],
            'support' => [
                'micros' => $line[3],
                'measured' => false,
                'basis' => 'Human support and onboarding time, amortised monthly at a loaded hourly rate. Estimate, and the line most likely to be wrong early - a first customer costs several times this and a settled one costs a fraction.',
            ],
        ];
    }

    /**
     * Monthly cost to serve, in micros, per tier: compute, storage, model, support.
     *
     * Absolute figures rather than a multiplier off one base, because the lines
     * do not scale together. Compute barely moves with seats; model spend moves
     * with USE and can be moved by one enthusiastic user; support moves with the
     * number of humans who might ring up. A single scale factor across all four
     * would be a tidy model of something that is not true.
     */
    private const COST_LINES = [
        //              compute      storage       model        support
        self::DEMO =>  [ 1_200_000,    300_000,   5_000_000,   6_000_000],
        self::FIELD => [ 2_500_000,    750_000,  12_000_000,  18_000_000],
        self::PROJECT=>[ 7_000_000,  3_000_000,  45_000_000,  45_000_000],
        self::PROGRAM=>[22_000_000, 14_000_000, 150_000_000, 120_000_000],
        self::AGENCY =>[55_000_000, 45_000_000, 380_000_000, 300_000_000],
    ];

    /** Total monthly cost to serve, in micros. */
    public static function costToServeMicros(string $tier): int
    {
        return array_sum(array_column(self::costToServe($tier), 'micros'));
    }

    /**
     * The lowest price this tier may be sold at: cost to serve, loaded.
     */
    public static function floorMicros(string $tier): int
    {
        return intdiv(self::costToServeMicros($tier) * self::LOADING_BASIS_POINTS + 9_999, 10_000);
    }

    /**
     * List price per month, in micros, and what it is priced against.
     *
     * @return array<string,array{monthly_micros: ?int, seats: ?int, projects: ?int,
     *   label: string, against: string, positioning: string}>
     */
    public static function tiers(): array
    {
        return [
            self::DEMO => [
                'monthly_micros' => 0,
                'seats' => 3,
                'projects' => 1,
                'label' => 'Demonstration',
                'against' => 'Nothing. This is the sample, and it is free by design.',
                'positioning' => 'One seeded demonstration project, three seats, thirty days, every operational capability switched on. It carries a demonstration banner on every screen and its records are marked as demonstration evidence, because a demo record that can be mistaken for a real one is a liability rather than a sales tool.',
            ],
            self::FIELD => [
                'monthly_micros' => 149_000_000,
                'seats' => 5,
                'projects' => 2,
                'label' => 'Field',
                'against' => 'Fieldwire at $39-104 per user per month; five seats there is $195-520.',
                'positioning' => 'A small contractor running one or two public jobs. Daily reports, RFIs, submittals, photos, evidence. Priced under five Fieldwire seats and doing considerably more than Fieldwire does.',
            ],
            self::PROJECT => [
                'monthly_micros' => 449_000_000,
                'seats' => 15,
                'projects' => 6,
                'label' => 'Project',
                'against' => 'Procore at $4,000-6,000 a year under $10M of work, plus $10,000-25,000 of implementation.',
                'positioning' => 'The main tier. $5,388 a year against a Procore quote that starts near the same number and then adds implementation. The whole contract and commercial set - pay applications, change orders, releases and stop notices, trade partner credentials - is in here rather than sold as a module.',
            ],
            self::PROGRAM => [
                'monthly_micros' => 1_290_000_000,
                'seats' => 50,
                'projects' => 25,
                'label' => 'Program',
                'against' => 'Procore at $10,000-15,000 a year between $10M and $100M of construction volume.',
                'positioning' => '$15,480 a year for fifty seats. Deliberately at the TOP of the incumbent mid-market band rather than under it: at this size the buyer is comparing capability and evidentiary defensibility, and a price that looks cheap reads as a smaller product.',
            ],
            self::AGENCY => [
                'monthly_micros' => null,
                'seats' => null,
                'projects' => null,
                'label' => 'Agency',
                'against' => 'Procore enterprise at $20,000+, Oracle Aconex at $29-49 per user per month.',
                'positioning' => 'Public owners administering many contracts and many contractors. Quoted, because the work is the integration and the retention schedule rather than the seats - and because a published number here would be either too low to do the work or too high to win it.',
            ],
        ];
    }

    /**
     * Everything about one tier, with the floor check already applied.
     *
     * @return array<string,mixed>
     */
    public static function tier(string $tier): array
    {
        $definition = self::tiers()[$tier] ?? throw new \InvalidArgumentException('Unknown pricing tier: '.$tier);
        $cost = self::costToServeMicros($tier);
        $floor = self::floorMicros($tier);
        $price = $definition['monthly_micros'];

        return $definition + [
            'key' => $tier,
            'cost_to_serve_micros' => $cost,
            'cost_lines' => self::costToServe($tier),
            'floor_micros' => $floor,
            'above_floor' => $price === null ? null : $price >= $floor,
            'headroom_micros' => $price === null ? null : $price - $floor,
            // Gross margin over cost to serve alone, in basis points. Reported
            // separately from the floor because they answer different
            // questions: the floor asks "may we sell this", the margin asks
            // "what does it earn".
            'gross_margin_basis_points' => ($price === null || $price === 0)
                ? null
                : (int) round((($price - $cost) / $price) * 10_000),
        ];
    }

    /**
     * May this account be sold at this price?
     *
     * The demonstration tier is the one deliberate exception: it is priced at
     * zero on purpose, and pretending it clears a floor would be a fiction.
     * Everything else is refused below the floor, with the number said out
     * loud, so that going below it is always somebody's decision on the record.
     *
     * @return array{allowed: bool, reason: ?string, floor_micros: int, shortfall_micros: int}
     */
    public static function mayQuote(string $tier, int $monthlyMicros): array
    {
        if ($tier === self::DEMO) {
            return ['allowed' => $monthlyMicros === 0, 'floor_micros' => 0, 'shortfall_micros' => 0,
                'reason' => $monthlyMicros === 0 ? null : 'The demonstration tier is free. A priced demonstration is a paid pilot and belongs on a paid tier.'];
        }

        $floor = self::floorMicros($tier);

        if ($monthlyMicros >= $floor) {
            return ['allowed' => true, 'reason' => null, 'floor_micros' => $floor, 'shortfall_micros' => 0];
        }

        return [
            'allowed' => false,
            'floor_micros' => $floor,
            'shortfall_micros' => $floor - $monthlyMicros,
            'reason' => 'A monthly price of $'.number_format($monthlyMicros / 1_000_000, 2)
                .' is below the loaded floor of $'.number_format($floor / 1_000_000, 2)
                .' for the '.(self::tiers()[$tier]['label'] ?? $tier).' tier. Cost to serve alone is $'
                .number_format(self::costToServeMicros($tier) / 1_000_000, 2)
                .'; the rest of the floor pays for the people and for finding the customer. Selling below it is a decision somebody has to make deliberately, not a number that slips through.',
        ];
    }

    /**
     * What the demonstration account gets, and what it must never be mistaken
     * for.
     *
     * The second half is the part that matters. A demonstration environment
     * that produces records indistinguishable from real ones is a liability:
     * this product's entire claim is that its records are evidence, and the day
     * a demonstration daily report turns up in a dispute the claim is finished.
     * So demonstration data is marked in the record itself, not only on the
     * screen, and it is never exportable as a sealed package.
     *
     * @return array<string,mixed>
     */
    public static function demo(): array
    {
        return [
            'duration_days' => 30,
            'seats' => 3,
            'projects' => 1,
            'capabilities' => 'Every capability the catalogue reports as operational. Nothing is held back, because a demonstration that hides the product is a demonstration of a different product.',
            'seeded' => 'One worked public-works project carried end to end: schedule of values, two payment applications, an approved change order, a served stop payment notice, a conditional release awaiting evidence of payment, and a TRACE question that refuses rather than answers.',
            'marking' => [
                'Every record created in a demonstration account carries the demonstration flag in the record itself, not only in the interface.',
                'Sealed export and the agency package are DISABLED. A demonstration record must never be capable of presenting itself as evidence.',
                'Demonstration accounts are never counted in any operational or capacity figure.',
            ],
            'conversion' => 'Converting to a paid tier keeps the account and discards the seeded demonstration project rather than promoting it. Promoting demonstration records into a live project would put fabricated evidence into a real contract file.',
        ];
    }
}
