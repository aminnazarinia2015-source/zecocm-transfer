<?php

namespace App\Jobs;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\AiRunLedger;
use App\Domain\Ai\CitedSuggestion;
use App\Domain\Ai\Escalation;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\NoMatch;
use App\Domain\Ai\RefusalPolicy;
use App\Domain\Ai\RetrievalClient;
use App\Domain\Ai\RetrievalTraceWriter;
use App\Domain\Ai\TokenSpend;
use App\Domain\Evolution\SelfObservation;
use App\Domain\Licensing\BudgetGate;
use App\Domain\Schedule\ProjectAccess;
use App\Models\AiRun;
use App\Models\CapabilityGrant;
use App\Models\Project;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\DB;
use Throwable;

class RunGovernedAi implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public int $timeout = 120;

    public function __construct(public readonly int $runId)
    {
        $this->afterCommit();
    }

    public function handle(AiAssistant $assistant, AiRunLedger $ledger): void
    {
        $prior = TenantContext::tenantId();

        // TenantContext is restored in the finally below, but the evidence gate
        // does not live there - it lives on the request, and in a queue worker
        // the request object is a single long-lived instance shared by every job
        // the worker picks up. On the sync driver it is the USER'S request,
        // which continues after the job returns.
        //
        // So authorized_evidence_read set true for one run would still be true
        // for whatever runs next on that worker, or for the rest of the request
        // that dispatched it. Every path here happens to set it before reading
        // anything - but "happens to" is not a control, and this one guards
        // whether evidence may be read at all.
        $priorAuthorizedRead = request()->attributes->get('authorized_evidence_read');
        $priorAuthorizedProject = request()->attributes->get('authorized_project_id');

        $run = AiRun::withoutGlobalScopes()->findOrFail($this->runId);
        TenantContext::set($run->tenant_id);
        // TR-18: defined here, ahead of anything in the try block that could
        // throw before reaching the lines that actually set them, so the
        // catch block below never reads an undefined variable.
        $traceBeforeThisRun = null;
        $traceWritten = false;
        try {
            if (in_array($run->status, ['completed', 'refused', 'cancelled'], true)) {
                return;
            }
            if ($run->cancel_requested_at) {
                $run->update(['status' => 'cancelled', 'progress' => 100, 'completed_at' => now()]);
                $ledger->record($run, 'cancelled');

                return;
            }
            $run->update(['status' => 'running', 'progress' => 15, 'started_at' => $run->started_at ?: now(), 'error' => null]);
            $ledger->record($run, 'started');
            request()->attributes->set('authorized_project_id', $run->project_id);
            // Re-authorize the requester at execution time, not at queue time. A
            // grant can be narrowed or revoked between the click and the worker
            // picking the job up, and evidence must be read under the permissions
            // in force when it is actually read.
            $requester = User::find($run->requested_by);
            $mayRead = false;
            if ($requester !== null) {
                try {
                    $mayRead = app(ProjectAccess::class)
                        ->authorize($requester, (int) $run->project_id, 'documents.view')
                        ->allows('documents.view');
                } catch (Throwable) {
                    $mayRead = false;
                }
            }
            request()->attributes->set('authorized_evidence_read', $mayRead === true);
            $project = Project::query()->findOrFail($run->project_id);

            // TR-18, Codex's finding: the retriever is a singleton and a
            // worker process is long-lived, so lastTrace() can still be
            // holding a PRIOR job's trace object right up until this job's
            // own retrieve() call replaces it. Capturing its identity here,
            // before suggest() is even called, is how the catch block below
            // can tell "this job's own retrieval ran and then something else
            // threw" apart from "this job never reached retrieval at all" -
            // retrieve() always assigns a brand new RetrievalTraceRecorder as
            // its first act, so the object identity changes the moment this
            // job's own retrieval is attempted, even if it returns early.
            $retriever = app(RetrievalClient::class);
            $traceBeforeThisRun = $retriever instanceof HybridKnowledgeRetriever ? $retriever->lastTrace() : null;

            $result = $assistant->suggest($run->question, $run->category, $project->jurisdictionScope(), new RefusalPolicy);

            // TR-18: write the retrieval trace from whatever the retriever
            // actually recorded during this run's own retrieve() call, even
            // when the outcome is a refusal or a no-match - a no-match's trace
            // (nothing survived, or nothing was retrieved at all) is exactly
            // as much evidence of what happened as a cited suggestion's is.
            if ($retriever instanceof HybridKnowledgeRetriever && $retriever->lastTrace() !== null) {
                RetrievalTraceWriter::write(
                    $retriever->lastTrace(), $run->question, $run->tenant_id, $run->project_id, $run->id, $result,
                );
                $traceWritten = true;
            }

            // Settle BEFORE branching on the outcome. Every shape of result
            // costs something or costs a known nothing, and settling inside the
            // success branch would undercount exactly the runs that go wrong.
            // An assistant that reported no spend at all is unknown, not free.
            BudgetGate::settle($run, $result->spend ?? TokenSpend::unmeasured((string) $run->model));

            $run->refresh();
            if ($run->cancel_requested_at) {
                $run->update(['status' => 'cancelled', 'progress' => 100, 'completed_at' => now()]);
                $ledger->record($run, 'cancelled');

                return;
            }

            if ($result instanceof CitedSuggestion) {
                $citations = array_map(fn ($citation) => $citation->toArray(), $result->citations);
                $run->update(['status' => 'completed', 'progress' => 100, 'result_classification' => 'recommendation',
                    'confidence' => 'medium', 'result' => ['kind' => 'suggestion', 'text' => $result->text, 'citations' => $citations],
                    'source_manifest' => $citations, 'completed_at' => now()]);
                DB::transaction(function () use ($run) {
                    $grant = CapabilityGrant::query()->where('tenant_id', $run->tenant_id)->where('capability_key', 'ai.assist')->lockForUpdate()->first();
                    if ($grant?->metered) {
                        $grant->increment('usage_count');
                    }
                });
                $ledger->record($run, 'completed', ['classification' => 'recommendation']);
            } elseif ($result instanceof Escalation) {
                // TR-16: an escalation is an abstention, and the ledger and the
                // run record must both carry WHY, not just that a refusal
                // happened - basis, whatever citations grounded it (conflict or
                // insufficient_evidence), and the named missing fact when there
                // is one. See Escalation's own doc comment for what each basis means.
                $run->update(['status' => 'refused', 'progress' => 100, 'result_classification' => 'refusal',
                    'confidence' => 'high', 'result' => [
                        'kind' => 'escalation',
                        'reason' => $result->reason,
                        'route_to' => $result->routeTo,
                        'basis' => $result->basis,
                        'conflict_citations' => array_map(fn ($c) => $c->toArray(), $result->conflictCitations),
                        'missing_fact' => $result->missingFact,
                    ], 'completed_at' => now()]);
                $ledger->record($run, 'refused', ['reason' => $result->reason, 'basis' => $result->basis]);

                // TRACE proposing its own next build (trace-independence.md,
                // Part 3): an escalation is the system correctly declining to
                // guess, but repeated across enough people it is also the
                // product naming what it cannot yet do. Never blocks the
                // response and never itself decides anything - observe() only
                // clusters and counts; a person still has to read a proposal
                // before anything changes.
                SelfObservation::observe(
                    signalKind: SelfObservation::ESCALATION,
                    clusterKey: SelfObservation::clusterKeyFor($run->question, (string) $run->category),
                    title: 'Escalated ('.$result->basis.'): '.mb_substr($run->question, 0, 120),
                    evidence: ['run_id' => $run->id, 'basis' => $result->basis, 'reason' => $result->reason, 'missing_fact' => $result->missingFact],
                    tenantId: $run->tenant_id,
                    askerKey: (string) $run->requested_by,
                    targetCapability: null,
                    projectKey: (string) $run->project_id,
                );
            } else {
                /** @var NoMatch $result */
                $run->update(['status' => 'refused', 'progress' => 100, 'result_classification' => 'refusal',
                    'confidence' => 'high', 'result' => ['kind' => 'no_match', 'scope_searched' => $result->scopeSearched], 'completed_at' => now()]);
                $ledger->record($run, 'refused', ['reason' => 'no_match']);

                // Same signal, the other named source: retrieval found nothing
                // at all in scope, which is the strongest "we do not have this"
                // fact this codebase produces.
                SelfObservation::observe(
                    signalKind: SelfObservation::NO_MATCH,
                    clusterKey: SelfObservation::clusterKeyFor($run->question, (string) $run->category),
                    title: 'No match in scope "'.$result->scopeSearched.'": '.mb_substr($run->question, 0, 120),
                    evidence: ['run_id' => $run->id, 'scope_searched' => $result->scopeSearched],
                    tenantId: $run->tenant_id,
                    askerKey: (string) $run->requested_by,
                    targetCapability: null,
                    projectKey: (string) $run->project_id,
                );
            }
        } catch (Throwable $e) {
            // TR-18, Codex's finding: retrieval already happened and is its
            // own historical fact even when everything after it - the model
            // call, parsing, an unrelated exception - fails. Only write here
            // when THIS job's own retrieve() actually ran (its trace object
            // identity differs from whatever lastTrace() held before this job
            // reached that call) and the success path above never already
            // wrote it - never on a job that threw before reaching retrieval
            // at all, and never twice for the same run.
            if (! $traceWritten) {
                $retrieverAfterFailure = app(RetrievalClient::class);
                if ($retrieverAfterFailure instanceof HybridKnowledgeRetriever
                    && $retrieverAfterFailure->lastTrace() !== null
                    && $retrieverAfterFailure->lastTrace() !== $traceBeforeThisRun) {
                    RetrievalTraceWriter::writeIncomplete(
                        $retrieverAfterFailure->lastTrace(), $run->question, $run->tenant_id, $run->project_id, $run->id,
                    );
                }
            }

            $run->update(['status' => 'failed', 'progress' => 100, 'error' => mb_substr($e->getMessage(), 0, 4000), 'completed_at' => now()]);
            $ledger->record($run, 'failed', ['error_class' => $e::class]);

            // A job that threw may have spent tokens before it threw, so the
            // cost is unknown rather than zero. The RESERVATION, though, is only
            // given back when this run is finally over - releasing it on an
            // attempt that is about to be retried would let the retry run with
            // no money held against it.
            if ($this->attempts() >= $this->tries) {
                BudgetGate::settle($run, TokenSpend::unmeasured((string) $run->model));
            }

            throw $e;
        } finally {
            $prior === null ? TenantContext::clear() : TenantContext::set($prior);

            // Put the evidence gate back exactly as it was found, including
            // putting it back to absent.
            $priorAuthorizedRead === null
                ? request()->attributes->remove('authorized_evidence_read')
                : request()->attributes->set('authorized_evidence_read', $priorAuthorizedRead);
            $priorAuthorizedProject === null
                ? request()->attributes->remove('authorized_project_id')
                : request()->attributes->set('authorized_project_id', $priorAuthorizedProject);
        }
    }
}
