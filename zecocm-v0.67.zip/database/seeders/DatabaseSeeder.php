<?php

namespace Database\Seeders;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\Membership;
use App\Models\Project;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Platform admin - Amin. Password is set at first deploy:
        // php artisan db:seed then CHANGE IT immediately via the app.
        User::firstOrCreate(
            ['email' => 'amin.nazarinia2015@gmail.com'],
            [
                'name' => 'Amin Nazarinia',
                'password' => Hash::make(env('SEED_ADMIN_PASSWORD', bin2hex(random_bytes(12)))),
                'platform_role' => 'admin',
            ]
        );

        // Customer #1: Zeco Inc. itself, with its two REAL live projects.
        $zeco = Tenant::firstOrCreate(
            ['name' => 'Zeco Inc.'],
            ['type' => 'CM firm', 'entitlements' => Tenant::defaultEntitlements('CM firm'), 'status' => 'active']
        );

        $dpark = User::firstOrCreate(
            ['email' => 'dpark@zecoinc.com'],
            [
                'tenant_id' => $zeco->id,
                'name' => 'David Park',
                'password' => Hash::make(env('SEED_ADMIN_PASSWORD', bin2hex(random_bytes(12)))),
            ]
        );

        TenantContext::set($zeco->id);

        $licenses = new CapabilityLicense;
        foreach (Tenant::defaultEntitlements('CM firm') as $capability) {
            if (CapabilityCatalog::has($capability) && ! CapabilityCatalog::isFree($capability) && ! $licenses->allows($zeco, $capability)) {
                $licenses->grant($zeco, $capability, planReference: 'Seeded account defaults', reason: 'Initial seeded capability');
            }
        }

        $clocks = [
            'submittal_review' => ['days' => 10, 'basis' => 'working', 'source' => 'contract general conditions'],
            'rfi' => ['days' => 5,  'basis' => 'working', 'source' => 'contract general conditions'],
            'payapp_review' => ['days' => 15, 'basis' => 'working', 'source' => 'contract; PCC 20104.50 backstop 30cal'],
            'payment' => ['days' => 30, 'basis' => 'calendar', 'source' => 'contract'],
            'change_notice' => ['days' => 10, 'basis' => 'calendar', 'source' => 'contract changes clause'],
        ];

        $demuth = Project::firstOrCreate(
            ['tenant_id' => $zeco->id, 'number' => '3114'],
            [
                'name' => 'Demuth Park Improvements 21-16',
                'sector' => 'public', 'owner_name' => 'City of Riverside', 'state' => 'CA',
                'funding_source' => 'local', 'duration_basis' => 'working',
                'contract_clocks' => $clocks, 'org_structure' => [],
            ]
        );
        $melville = Project::firstOrCreate(
            ['tenant_id' => $zeco->id, 'number' => '3115'],
            [
                'name' => 'Melville J. Courson Park Revitalization PN 851',
                'sector' => 'public', 'owner_name' => 'City of Paramount', 'state' => 'CA',
                'funding_source' => 'local', 'duration_basis' => 'working',
                'contract_clocks' => $clocks, 'org_structure' => [],
            ]
        );

        // Rogers Park Baseball Fields Improvement Project - City of Inglewood, CB-25-11.
        // This is the third real job Amin referred to as "Roger Baseball" in a voice
        // transcript; confirmed from the bid-portal project files (Invitation to Bid /
        // Notice of Intent to Award, both from the City of Inglewood Public Works
        // Department, addressed to Amin Nazarinia at Zeco Inc.).
        $rogers = Project::updateOrCreate(
            ['tenant_id' => $zeco->id, 'number' => '3111'],
            [
                'name' => 'Rogers Park Baseball Fields Improvement Project (CB-25-11)',
                'sector' => 'public', 'owner_name' => 'City of Inglewood', 'state' => 'CA',
                'funding_source' => 'local', 'duration_basis' => 'working',
                'contract_clocks' => $clocks, 'org_structure' => [],
            ]
        );

        // Northwood Park Improvements - City of Irvine, CIP 362401 / bid PK-26-0052. Zeco
        // was the apparent low bidder ($4,252,000) per the PlanetBids bid-result report in
        // the project folder; confirmed from that document. Not yet under construction
        // (Amin: "we are planning to start it right now").
        $northwood = Project::updateOrCreate(
            ['tenant_id' => $zeco->id, 'number' => '3116'],
            [
                'name' => 'Northwood Park Improvements (CIP 362401)',
                'sector' => 'public', 'owner_name' => 'City of Irvine', 'state' => 'CA',
                'funding_source' => 'local', 'duration_basis' => 'working',
                'contract_clocks' => $clocks, 'org_structure' => [],
            ]
        );

        foreach ([$demuth, $melville, $rogers, $northwood] as $project) {
            Membership::firstOrCreate(
                ['tenant_id' => $zeco->id, 'project_id' => $project->id, 'user_id' => $dpark->id],
                [
                    'organization' => 'Zeco Inc.',
                    'seat' => 'project_manager',
                    'capabilities' => ['*' => true],
                    'discipline_scope' => [],
                ]
            );
        }

        // Team accounts Amin asked for. Test-domain emails (zeco-int.com) per his
        // instruction, to be swapped for real addresses once this passes testing.
        // Passwords are randomly generated, never typed/known by Claude - each person
        // resets their own password on first sign-in, same as the existing accounts.
        $daniel = User::firstOrCreate(
            ['email' => 'dalcaraz@zeco-int.com'],
            [
                'tenant_id' => $zeco->id,
                'name' => 'Daniel Alcaraz',
                'password' => Hash::make(env('SEED_ADMIN_PASSWORD', bin2hex(random_bytes(12)))),
            ]
        );
        $dario = User::firstOrCreate(
            ['email' => 'dchavez@zeco-int.com'],
            [
                'tenant_id' => $zeco->id,
                'name' => 'Dario Chavez',
                'password' => Hash::make(env('SEED_ADMIN_PASSWORD', bin2hex(random_bytes(12)))),
            ]
        );
        $frank = User::firstOrCreate(
            ['email' => 'fdomingos@zeco-int.com'],
            [
                'tenant_id' => $zeco->id,
                'name' => 'Frank Dominguez',
                'password' => Hash::make(env('SEED_ADMIN_PASSWORD', bin2hex(random_bytes(12)))),
            ]
        );

        foreach ([$demuth, $melville, $rogers, $northwood] as $project) {
            // Daniel Alcaraz: project manager, full access to project details - as Amin asked.
            Membership::firstOrCreate(
                ['tenant_id' => $zeco->id, 'project_id' => $project->id, 'user_id' => $daniel->id],
                [
                    'organization' => 'Zeco Inc.',
                    'seat' => 'project_manager',
                    'capabilities' => ['*' => true],
                    'discipline_scope' => [],
                ]
            );
            // Dario Chavez and Frank Dominguez: field-level access (daily reports, RFIs,
            // submittals, photos) - Amin didn't specify their role, so this is a
            // conservative default, not a guess presented as his instruction. Easy to
            // widen to full access via the app once confirmed.
            //
            // These keys must match the literal capability strings every controller's
            // ProjectAccess::authorize() call checks for (grep app/Http/Controllers for
            // "->authorize(" to see the full vocabulary) - 'daily_reports', 'rfis',
            // 'submittals' and 'photos' are CapabilityCatalog/licensing keys, not
            // project-grant capability keys, and matched none of them. As seeded before
            // this fix, Dario and Frank could not view OR create a single daily report,
            // RFI, or submittal, and could not view or upload a single photo - every
            // action the comment above says they should have was silently refused.
            foreach ([$dario, $frank] as $teamMember) {
                Membership::firstOrCreate(
                    ['tenant_id' => $zeco->id, 'project_id' => $project->id, 'user_id' => $teamMember->id],
                    [
                        'organization' => 'Zeco Inc.',
                        'seat' => 'field',
                        'capabilities' => [
                            'records.view' => true, 'daily.create' => true, 'rfi.create' => true,
                            'submittal.create' => true, 'documents.view' => true, 'media.upload' => true,
                            'weather.view' => true, 'project.view' => true,
                        ],
                        'discipline_scope' => [],
                    ]
                );
            }
        }

        TenantContext::clear();
    }
}
