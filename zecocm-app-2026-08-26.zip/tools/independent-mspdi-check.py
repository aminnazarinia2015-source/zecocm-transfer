#!/usr/bin/env python3
"""Independent MSPDI cross-check - Python/ElementTree, no shared code with the PHP parser.

Addresses the Final Verification Directive's common-mode finding: the earlier ground
truth used the same PHP parser as production. This reader independently extracts
tasks, dates, durations, actuals and links from the raw XML and recomputes the
comparison categories.
"""
import re
import sys
import xml.etree.ElementTree as ET
from datetime import datetime

NS = '{http://schemas.microsoft.com/project}'
BASE = '/home/claude/Courson_Park_PN851_Baseline_CPM.xml'
UPD = ('/mnt/user-data/uploads/Project Folder/'
       '3115-Melville J. Courson Park Revitalization PN 851/CPM/Courson_Park_PN851_Update1_DD0731.xml')

CODE_RE = re.compile(r'^([A-Z]{1,4}\d{2,6})\b')


def text(el, tag):
    child = el.find(NS + tag)
    return child.text if child is not None and child.text else None


def dur_minutes(value):
    if not value:
        return None
    m = re.match(r'^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$', value)
    if not m:
        return None
    return int(m.group(1) or 0) * 60 + int(m.group(2) or 0)


def parse(path):
    root = ET.parse(path).getroot()
    tasks = {}
    for task in root.iter(NS + 'Task'):
        uid = text(task, 'UID')
        name = text(task, 'Name')
        if uid is None or name is None or uid == '0':
            continue
        summary = text(task, 'Summary') == '1'
        code_match = CODE_RE.match(name.strip())
        code = code_match.group(1) if code_match else 'UID' + uid
        tasks[uid] = {
            'uid': uid, 'code': code, 'name': name.strip(), 'summary': summary,
            'start': text(task, 'Start'), 'finish': text(task, 'Finish'),
            'astart': text(task, 'ActualStart'), 'afinish': text(task, 'ActualFinish'),
            'duration': dur_minutes(text(task, 'Duration')),
            'preds': [text(link, 'PredecessorUID') for link in task.findall(NS + 'PredecessorLink')],
        }
    # Dedupe repeated codes exactly by suffixing UID (naming convention only).
    seen = {}
    for t in tasks.values():
        if t['summary']:
            continue
        if t['code'] in seen:
            t['code'] = t['code'] + '-' + t['uid']
        seen[t['code']] = True
    sched = {t['code']: t for t in tasks.values() if not t['summary']}
    non_summary_uids = {t['uid'] for t in tasks.values() if not t['summary']}
    links = sum(1 for t in tasks.values() if not t['summary']
                for p in t['preds'] if p in non_summary_uids)
    dropped = sum(1 for t in tasks.values() if not t['summary']
                  for p in t['preds'] if p not in non_summary_uids)
    return sched, links, dropped


def dt(value):
    return datetime.fromisoformat(value) if value else None


def cal_days(a, b):
    return round((dt(b) - dt(a)).total_seconds() / 86400, 2)


base, base_links, base_dropped = parse(BASE)
upd, upd_links, upd_dropped = parse(UPD)

added = sorted(set(upd) - set(base))
removed = sorted(set(base) - set(upd))

date_moves, dur_changes, actualized = [], [], []
for code in sorted(set(base) & set(upd)):
    b, u = base[code], upd[code]
    for field, label in (('start', 'start'), ('finish', 'finish')):
        if b[field] != u[field] and b[field] and u[field]:
            date_moves.append((code, label, cal_days(b[field], u[field])))
    if b['duration'] is not None and u['duration'] is not None and b['duration'] != u['duration']:
        dur_changes.append((code, round((u['duration'] - b['duration']) / 480, 2)))
    if (u['astart'] or u['afinish']) and not (b['astart'] or b['afinish']):
        actualized.append(code)
    elif b['afinish'] != u['afinish'] and b['afinish'] and u['afinish']:
        actualized.append(code + ' (actual finish moved)')

max_finish = lambda sched: max(t['finish'] for t in sched.values() if t['finish'])[:10]

print(f"BASELINE: {len(base)} schedulable activities, {base_links} valid links, {base_dropped} dropped (summary-level) links")
print(f"UPDATE 1: {len(upd)} schedulable activities, {upd_links} valid links, {upd_dropped} dropped (summary-level) links")
print(f"ADDED ({len(added)}): {', '.join(added)}")
print(f"REMOVED ({len(removed)}): {', '.join(removed) or 'none'}")
print(f"PLANNED DATE MOVES ({len(date_moves)}):")
for code, field, days in sorted(date_moves, key=lambda x: -abs(x[2])):
    print(f"  {code} {field}: {days:+} calendar days")
print(f"DURATION CHANGES ({len(dur_changes)}):")
for code, wd in sorted(dur_changes, key=lambda x: -abs(x[1])):
    print(f"  {code}: {wd:+} work days")
print(f"NEWLY ACTUALIZED ({len(actualized)}): {', '.join(actualized)}")
print(f"MAX PLANNED FINISH: baseline {max_finish(base)} | update {max_finish(upd)}")

# Hard expectations from the live engine's ledger (analysis 2, 74 deltas).
checks = {
    'baseline activity count 84': len(base) == 84,
    'update activity count 90': len(upd) == 90,
    'added set is C020-C070': added == ['C020', 'C030', 'C040', 'C050', 'C060', 'C070'],
    'nothing removed': removed == [],
    'A120 start +25 calendar days': ('A120', 'start', 25.0) in date_moves,
    'A120 finish +23 calendar days': ('A120', 'finish', 23.0) in date_moves,
    'P200 finish +13 calendar days': ('P200', 'finish', 13.0) in date_moves,
    'UID122 start +12 calendar days': ('UID122', 'start', 12.0) in date_moves,
    'UID96 duration +11 work days': ('UID96', 11.0) in dur_changes,
    'nine duration changes': len(dur_changes) == 9,
    'P200 and P210 newly actualized': 'P200' in actualized and 'P210' in actualized,
    'finish unchanged 2027-08-26': max_finish(base) == '2027-08-26' == max_finish(upd),
    'one dropped summary link each': base_dropped == 1 and upd_dropped == 1,
}
print('\nCROSS-CHECK vs live engine ledger:')
failures = 0
for name, ok in checks.items():
    print(f"  {'PASS' if ok else 'FAIL'}  {name}")
    failures += 0 if ok else 1
print(f"\nRESULT: {'ALL CHECKS PASS - independent implementation agrees with the live engine' if failures == 0 else str(failures) + ' CHECK(S) FAILED'}")
sys.exit(1 if failures else 0)
