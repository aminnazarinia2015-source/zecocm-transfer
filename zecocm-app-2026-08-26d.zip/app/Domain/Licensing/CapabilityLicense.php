<?php

namespace App\Domain\Licensing;

use App\Models\CapabilityGrant;
use App\Models\CapabilityGrantEvent;
use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Reads and writes the capability licence book.
 *
 * Effective capability =
 *     licence active AND now within its window
 *     AND the capability is actually operational
 *     AND (metered ? allowance remaining : true)
 *
 * Project grants and support/technician mode are enforced separately by
 * ProjectAccess - this class answers only "is this account licensed for it".
 */
final class CapabilityLicense
{
    /** Free capabilities are never licensed and can never be switched off. */
    public function state(Tenant $tenant, string $capabilityKey): LicenseState
    {
        if (! CapabilityCatalog::has($capabilityKey)) {
            return new LicenseState($capabilityKey, LicenseState::NOT_LICENSED, note: 'Unknown capability.');
        }
        if (CapabilityCatalog::isFree($capabilityKey)) {
            return new LicenseState($capabilityKey, LicenseState::FREE, note: 'Included with every account.');
        }

        $grant = CapabilityGrant::query()
            ->where('tenant_id', $tenant->id)
            ->where('capability_key', $capabilityKey)
            ->first();

        if ($grant === null || $grant->status === 'revoked') {
            return new LicenseState($capabilityKey, LicenseState::NOT_LICENSED);
        }

        $endsAt = $grant->ends_at?->toIso8601String();
        $daysRemaining = $grant->ends_at ? (int) floor((($grant->ends_at->getTimestamp() - now()->getTimestamp()) / 86400)) : null;

        if ($grant->status === 'suspended') {
            return new LicenseState($capabilityKey, LicenseState::SUSPENDED, $endsAt, $daysRemaining, $grant->plan_reference, note: $grant->reason);
        }

        $now = now();
        if ($grant->starts_at->greaterThan($now)) {
            return new LicenseState($capabilityKey, LicenseState::NOT_LICENSED, $endsAt, $daysRemaining, $grant->plan_reference,
                note: 'Licence begins '.$grant->starts_at->toDateString().'.');
        }
        if ($grant->ends_at !== null && $grant->ends_at->lessThan($now)) {
            return new LicenseState($capabilityKey, LicenseState::EXPIRED, $endsAt, $daysRemaining, $grant->plan_reference);
        }
        if ($grant->metered && $grant->usage_limit !== null && $grant->usage_count >= $grant->usage_limit) {
            return new LicenseState($capabilityKey, LicenseState::LIMIT_REACHED, $endsAt, $daysRemaining, $grant->plan_reference,
                $grant->usage_count, $grant->usage_limit);
        }
        if (! CapabilityCatalog::isOperational($capabilityKey)) {
            return new LicenseState($capabilityKey, LicenseState::NOT_OPERATIONAL, $endsAt, $daysRemaining, $grant->plan_reference,
                note: 'Licensed, but this capability is not built yet - you are not being charged for unavailable work.');
        }

        return new LicenseState($capabilityKey, LicenseState::AVAILABLE, $endsAt, $daysRemaining, $grant->plan_reference,
            $grant->metered ? $grant->usage_count : null, $grant->usage_limit);
    }

    public function allows(Tenant $tenant, string $capabilityKey): bool
    {
        return $this->state($tenant, $capabilityKey)->allows();
    }

    /** @return list<array<string,mixed>> every capability with its state for this account */
    public function book(Tenant $tenant): array
    {
        $out = [];
        foreach (array_keys(CapabilityCatalog::all()) as $key) {
            $out[] = $this->state($tenant, $key)->toArray();
        }

        return $out;
    }

    /**
     * Grant or replace a licence for one capability on one account.
     *
     * @param  Tenant|null  $grantorTenant  null = granted by the ZecoCM platform.
     *                                      Set = a sponsor delegating to its own portal, which
     *                                      can never exceed what the sponsor itself holds.
     */
    public function grant(
        Tenant $tenant,
        string $capabilityKey,
        ?\DateTimeInterface $startsAt = null,
        ?\DateTimeInterface $endsAt = null,
        ?string $planReference = null,
        ?int $actorUserId = null,
        ?Tenant $grantorTenant = null,
        ?string $reason = null,
        ?int $usageLimit = null,
        ?string $modelTier = null,
        ?array $allowedTasks = null,
        ?int $budgetLimitMicros = null,
    ): CapabilityGrant {
        if (! CapabilityCatalog::has($capabilityKey)) {
            throw new LicensingRefused("Unknown capability '{$capabilityKey}'.");
        }
        if (CapabilityCatalog::isFree($capabilityKey)) {
            throw new LicensingRefused("'{$capabilityKey}' is included free with every account and is not licensed.");
        }
        if ($grantorTenant !== null && ! $this->allows($grantorTenant, $capabilityKey)) {
            throw new LicensingRefused(
                "Your account is not licensed for '{$capabilityKey}', so it cannot be granted to a portal you sponsor."
            );
        }
        if ($grantorTenant !== null && (int) $tenant->parent_tenant_id !== (int) $grantorTenant->id) {
            throw new LicensingRefused('You may only license portals your account sponsors.');
        }
        if ($grantorTenant !== null && $capabilityKey === 'ai.assist') {
            $parent = CapabilityGrant::query()->where('tenant_id', $grantorTenant->id)->where('capability_key', $capabilityKey)->first();
            $rank = ['standard' => 1, 'premium' => 2, 'private' => 3];
            if (($rank[$modelTier ?? 'standard'] ?? 99) > ($rank[$parent?->model_tier ?? 'standard'] ?? 1)) {
                throw new LicensingRefused('A sponsored portal cannot receive a higher AI model tier than its sponsor.');
            }
            if ($parent?->allowed_tasks && array_diff($allowedTasks ?? [], $parent->allowed_tasks)) {
                throw new LicensingRefused('A sponsored portal cannot receive AI tasks outside its sponsor allowance.');
            }
            if ($parent?->budget_limit_micros !== null && ($budgetLimitMicros === null || $budgetLimitMicros > $parent->budget_limit_micros)) {
                throw new LicensingRefused('A sponsored portal AI budget cannot exceed its sponsor ceiling.');
            }
        }

        $meta = CapabilityCatalog::get($capabilityKey);
        $starts = $startsAt ? \Carbon\CarbonImmutable::instance(\Carbon\Carbon::instance($startsAt)) : now()->toImmutable();
        $ends = $endsAt ? \Carbon\CarbonImmutable::instance(\Carbon\Carbon::instance($endsAt)) : null;
        if ($ends !== null && $ends->lessThanOrEqualTo($starts)) {
            throw new LicensingRefused('The licence end date must be after its start date.');
        }

        // A grantor who never sets a number here gets BudgetGate::UNLIMITED,
        // silently - no cap, no warning, a real bill running against real
        // Anthropic usage with nothing on this side watching it. PriceBook
        // already models exactly how much monthly model spend each tier's
        // price is supposed to carry (its 'model_spend' cost line); this is
        // that number actually reaching the grant that enforces it, rather
        // than living only as a reference figure nothing reads. An admin who
        // deliberately wants no ceiling can still pass an explicit, very
        // large budgetLimitMicros - the one thing this refuses to do is
        // default to no ceiling at all just because nobody typed a number in.
        if ($capabilityKey === 'ai.assist' && $budgetLimitMicros === null) {
            $budgetLimitMicros = self::defaultAiBudgetMicros($planReference);
        }

        return DB::transaction(function () use ($tenant, $capabilityKey, $starts, $ends, $planReference, $actorUserId, $grantorTenant, $reason, $usageLimit, $modelTier, $allowedTasks, $budgetLimitMicros, $meta) {
            $existing = CapabilityGrant::query()
                ->where('tenant_id', $tenant->id)->where('capability_key', $capabilityKey)->first();
            $before = $existing?->only(['status', 'starts_at', 'ends_at', 'plan_reference', 'usage_limit']);

            $grant = CapabilityGrant::updateOrCreate(
                ['tenant_id' => $tenant->id, 'capability_key' => $capabilityKey],
                [
                    'status' => 'active',
                    'starts_at' => $starts,
                    'ends_at' => $ends,
                    'plan_reference' => $planReference,
                    'granted_by_user_id' => $actorUserId,
                    'granted_by_tenant_id' => $grantorTenant?->id,
                    'reason' => $reason,
                    'metered' => (bool) ($meta['metered'] ?? false),
                    'usage_limit' => $usageLimit,
                    'usage_count' => $existing?->usage_count ?? 0,
                    'model_tier' => $modelTier,
                    'allowed_tasks' => $allowedTasks,
                    'budget_limit_micros' => $budgetLimitMicros,
                    'budget_used_micros' => $existing?->budget_used_micros ?? 0,
                ]
            );

            $this->record($tenant, $grant, $capabilityKey, $existing ? 'extended' : 'granted', $starts, $ends,
                $actorUserId, $grantorTenant?->id, $reason, $before, $grant->only(['status', 'starts_at', 'ends_at', 'plan_reference', 'usage_limit']));

            return $grant;
        });
    }

    /**
     * The monthly AI budget PriceBook already models for this account's
     * tier, read off its plan_reference. Falls back to the FIELD tier's
     * model-spend line - the smallest PAID tier, deliberately not DEMO's
     * even-smaller one - for a plan reference that does not name a known
     * tier, rather than falling back to no cap at all. An admin who actually
     * wants a bigger ceiling still has to type one in; this only removes the
     * silent, unintentional case.
     */
    public static function defaultAiBudgetMicros(?string $planReference): int
    {
        $tier = strtolower(trim((string) $planReference));
        $known = [\App\Domain\Licensing\PriceBook::DEMO, \App\Domain\Licensing\PriceBook::FIELD,
            \App\Domain\Licensing\PriceBook::PROJECT, \App\Domain\Licensing\PriceBook::PROGRAM,
            \App\Domain\Licensing\PriceBook::AGENCY];
        $resolved = in_array($tier, $known, true) ? $tier : \App\Domain\Licensing\PriceBook::FIELD;

        return (int) \App\Domain\Licensing\PriceBook::costToServe($resolved)['model_spend']['micros'];
    }

    public function suspend(Tenant $tenant, string $capabilityKey, ?int $actorUserId, ?string $reason = null): void
    {
        $this->transition($tenant, $capabilityKey, 'suspended', 'suspended', $actorUserId, $reason);
    }

    public function resume(Tenant $tenant, string $capabilityKey, ?int $actorUserId, ?string $reason = null): void
    {
        $this->transition($tenant, $capabilityKey, 'active', 'resumed', $actorUserId, $reason);
    }

    public function revoke(Tenant $tenant, string $capabilityKey, ?int $actorUserId, ?string $reason = null): void
    {
        $this->transition($tenant, $capabilityKey, 'revoked', 'revoked', $actorUserId, $reason);
    }

    /** Metered capabilities count each authorised use; the event chain keeps the tally honest. */
    public function recordUse(Tenant $tenant, string $capabilityKey, ?int $actorUserId = null): void
    {
        $grant = CapabilityGrant::query()
            ->where('tenant_id', $tenant->id)->where('capability_key', $capabilityKey)->first();
        if ($grant === null || ! $grant->metered) {
            return;
        }
        $grant->increment('usage_count');
        $this->record($tenant, $grant, $capabilityKey, 'usage_recorded', null, null, $actorUserId, null, null,
            ['usage_count' => $grant->usage_count - 1], ['usage_count' => $grant->usage_count]);
    }

    private function transition(Tenant $tenant, string $capabilityKey, string $status, string $action, ?int $actorUserId, ?string $reason): void
    {
        $grant = CapabilityGrant::query()
            ->where('tenant_id', $tenant->id)->where('capability_key', $capabilityKey)->first();
        if ($grant === null) {
            throw new LicensingRefused("No licence exists for '{$capabilityKey}' on this account.");
        }
        $before = $grant->only(['status']);
        $grant->update(['status' => $status]);
        $this->record($tenant, $grant, $capabilityKey, $action, $grant->starts_at, $grant->ends_at,
            $actorUserId, null, $reason, $before, ['status' => $status]);
    }

    private function record(
        Tenant $tenant, ?CapabilityGrant $grant, string $capabilityKey, string $action,
        ?\DateTimeInterface $from, ?\DateTimeInterface $until, ?int $actorUserId, ?int $actorTenantId,
        ?string $reason, ?array $before, ?array $after,
    ): void {
        $previous = CapabilityGrantEvent::query()
            ->where('tenant_id', $tenant->id)->orderByDesc('id')->first();
        $payload = [
            'tenant_id' => $tenant->id,
            'capability_grant_id' => $grant?->id,
            'capability_key' => $capabilityKey,
            'action' => $action,
            'effective_from' => $from,
            'effective_until' => $until,
            'actor_user_id' => $actorUserId,
            'actor_tenant_id' => $actorTenantId,
            'reason' => $reason,
            'before' => $before,
            'after' => $after,
            'correlation_id' => (string) Str::uuid(),
            'previous_event_hash' => $previous?->event_hash,
            'created_at' => now(),
        ];
        $payload['event_hash'] = hash('sha256', json_encode($payload + ['n' => $previous?->id ?? 0], JSON_THROW_ON_ERROR));
        CapabilityGrantEvent::create($payload);
    }
}
