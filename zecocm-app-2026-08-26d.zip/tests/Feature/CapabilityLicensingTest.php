<?php

namespace Tests\Feature;

use App\Domain\Licensing\CapabilityLicense;
use App\Domain\Licensing\HelpAssistant;
use App\Domain\Licensing\LicensingRefused;
use App\Domain\Licensing\LicenseState;
use App\Models\CapabilityGrantEvent;
use App\Models\Tenant;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Capability licensing: per-account activation, time windows, metering, the
 * sponsor delegation ceiling, and the free/paid AI boundary.
 */
class CapabilityLicensingTest extends TestCase
{
    use RefreshDatabase;

    private CapabilityLicense $license;

    protected function setUp(): void
    {
        parent::setUp();
        $this->license = new CapabilityLicense;
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function tenant(string $name, string $role = 'cm_firm', bool $owner = true, ?int $parent = null): Tenant
    {
        return Tenant::create([
            'name' => $name, 'type' => 'CM firm', 'entitlements' => [], 'status' => 'active',
            'sponsor_role' => $role, 'is_account_owner' => $owner, 'parent_tenant_id' => $parent,
        ]);
    }

    public function test_an_unlicensed_account_is_refused_and_a_licensed_one_is_allowed(): void
    {
        $t = $this->tenant('Acme CM');
        $this->assertSame(LicenseState::NOT_LICENSED, $this->license->state($t, 'schedule_intelligence')->state);
        $this->assertFalse($this->license->allows($t, 'schedule_intelligence'));

        $this->license->grant($t, 'schedule_intelligence', planReference: 'Annual');
        $this->assertTrue($this->license->allows($t, 'schedule_intelligence'));
    }

    public function test_a_time_window_expires_on_its_own_and_days_remaining_are_reported(): void
    {
        $t = $this->tenant('Two Month Pilot');

        // "we need it for two months"
        $this->license->grant($t, 'ai.assist',
            startsAt: new \DateTimeImmutable('-1 day'),
            endsAt: new \DateTimeImmutable('+60 days'),
            planReference: 'AI Assist - 2 month pilot');

        $state = $this->license->state($t, 'ai.assist');
        $this->assertTrue($state->allows());
        $this->assertEqualsWithDelta(59, $state->daysRemaining, 1.5);

        // A window that has already closed refuses without anyone touching it.
        $this->license->grant($t, 'ai.assist',
            startsAt: new \DateTimeImmutable('-30 days'),
            endsAt: new \DateTimeImmutable('-1 day'));
        $this->assertSame(LicenseState::EXPIRED, $this->license->state($t, 'ai.assist')->state);
        $this->assertFalse($this->license->allows($t, 'ai.assist'));
    }

    public function test_a_ten_day_window_is_active_today_and_dead_after_it(): void
    {
        $t = $this->tenant('Ten Day Trial');
        $this->license->grant($t, 'ai.assist',
            startsAt: new \DateTimeImmutable('now'),
            endsAt: (new \DateTimeImmutable('now'))->modify('+10 days'));
        $this->assertTrue($this->license->allows($t, 'ai.assist'));

        $this->travel(11)->days();
        $this->assertSame(LicenseState::EXPIRED, $this->license->state($t, 'ai.assist')->state);
    }

    public function test_suspend_resume_and_revoke_are_all_audited(): void
    {
        $t = $this->tenant('Audited Co');
        $this->license->grant($t, 'submittals', actorUserId: 7, reason: 'Initial sale');

        $this->license->suspend($t, 'submittals', 7, 'Non-payment');
        $this->assertSame(LicenseState::SUSPENDED, $this->license->state($t, 'submittals')->state);

        $this->license->resume($t, 'submittals', 7, 'Payment cleared');
        $this->assertTrue($this->license->allows($t, 'submittals'));

        $this->license->revoke($t, 'submittals', 7, 'Contract ended');
        $this->assertSame(LicenseState::NOT_LICENSED, $this->license->state($t, 'submittals')->state);

        $actions = CapabilityGrantEvent::where('tenant_id', $t->id)->pluck('action')->all();
        $this->assertSame(['granted', 'suspended', 'resumed', 'revoked'], $actions);

        // The chain links and cannot be rewritten.
        $events = CapabilityGrantEvent::where('tenant_id', $t->id)->orderBy('id')->get();
        $this->assertSame($events[0]->event_hash, $events[1]->previous_event_hash);
        $this->expectException(\LogicException::class);
        $events[0]->update(['reason' => 'tampered']);
    }

    public function test_metered_ai_stops_at_its_allowance(): void
    {
        $t = $this->tenant('Metered Co');
        $this->license->grant($t, 'ai.assist', usageLimit: 2);

        $this->license->recordUse($t, 'ai.assist');
        $this->assertTrue($this->license->allows($t, 'ai.assist'));
        $this->license->recordUse($t, 'ai.assist');
        $this->assertSame(LicenseState::LIMIT_REACHED, $this->license->state($t, 'ai.assist')->state);
    }

    public function test_a_licensed_but_unbuilt_capability_is_not_sold_as_available(): void
    {
        // pay_apps used to be the example here and has since shipped. The rule
        // under test is the catalogue's, not any one module's: a capability an
        // account has PAID for is still refused while it is unbuilt.
        $t = $this->tenant('Roadmap Co');
        $this->license->grant($t, 'closeout');   // catalogued, operational = false
        $state = $this->license->state($t, 'closeout');
        $this->assertSame(LicenseState::NOT_OPERATIONAL, $state->state);
        $this->assertFalse($state->allows());
    }

    public function test_free_capabilities_can_never_be_licensed_or_switched_off(): void
    {
        $t = $this->tenant('Anyone');
        $this->assertSame(LicenseState::FREE, $this->license->state($t, 'ai.help')->state);
        $this->assertTrue($this->license->allows($t, 'ai.help'));

        $this->expectException(LicensingRefused::class);
        $this->license->grant($t, 'ai.help');
    }

    public function test_a_sponsor_cannot_grant_a_portal_more_than_it_holds_itself(): void
    {
        // A contractor buys the system and creates a City portal beneath itself.
        $contractor = $this->tenant('Zeco Inc.', 'contractor', owner: true);
        $cityPortal = $this->tenant('City portal', 'owner_agency', owner: false, parent: $contractor->id);

        // The sponsor is not licensed for schedule intelligence, so it cannot pass it on.
        try {
            $this->license->grant($cityPortal, 'schedule_intelligence', grantorTenant: $contractor);
            $this->fail('Delegation above the sponsor ceiling should be refused.');
        } catch (LicensingRefused $e) {
            $this->assertStringContainsString('not licensed', $e->getMessage());
        }

        // Once the sponsor holds it, delegation succeeds.
        $this->license->grant($contractor, 'schedule_intelligence');
        $this->license->grant($cityPortal, 'schedule_intelligence', grantorTenant: $contractor);
        $this->assertTrue($this->license->allows($cityPortal, 'schedule_intelligence'));
    }

    public function test_a_sponsor_may_only_license_portals_it_actually_sponsors(): void
    {
        $cm = $this->tenant('CM Firm', 'cm_firm');
        $stranger = $this->tenant('Unrelated Co', 'contractor');
        $this->license->grant($cm, 'rfis');

        $this->expectException(LicensingRefused::class);
        $this->license->grant($stranger, 'rfis', grantorTenant: $cm);
    }

    public function test_whoever_buys_defines_the_counterparties_they_may_create(): void
    {
        // Nothing is hard-wired to City -> CM -> contractor. The buyer sits at the top
        // and may create a portal for every seat except the one it occupies itself.
        $contractor = $this->tenant('Contractor buys', 'contractor');
        $this->assertArrayHasKey('owner_agency', $contractor->assignableRoles());
        $this->assertArrayHasKey('cm_firm', $contractor->assignableRoles());
        $this->assertArrayNotHasKey('contractor', $contractor->assignableRoles());

        $city = $this->tenant('City buys', 'owner_agency');
        $this->assertArrayHasKey('cm_firm', $city->assignableRoles());
        $this->assertArrayHasKey('contractor', $city->assignableRoles());
        $this->assertArrayNotHasKey('owner_agency', $city->assignableRoles());
    }

    public function test_the_free_help_assistant_answers_about_the_system_and_never_touches_project_evidence(): void
    {
        $t = $this->tenant('Free Tier Co');
        $answer = (new HelpAssistant)->answer('how does the schedule comparison work?', $t);

        $this->assertSame('help', $answer['kind']);
        $this->assertSame('free_help', $answer['tier']);
        $this->assertStringContainsString('does not read your project records', $answer['boundary']);
        $this->assertNotEmpty($answer['capabilities']);

        // It reports honestly that the paid tier is not licensed for this account.
        $unknown = (new HelpAssistant)->answer('what were the actual dates on activity A120', $t);
        $this->assertContains($unknown['kind'], ['help', 'no_match']);
    }

    /**
     * Granting ai.assist with no explicit budget_limit_micros must never
     * silently land as unlimited (BudgetGate::UNLIMITED) - PriceBook already
     * models a real monthly AI-spend line per tier, and that number has to
     * actually reach the grant it prices, or the whole table is decorative.
     */
    public function test_granting_ai_assist_with_no_explicit_budget_defaults_from_the_tenants_priced_tier(): void
    {
        $t = $this->tenant('Riverside Public Works');

        $this->license->grant($t, 'ai.assist', planReference: 'project');

        $grant = \App\Models\CapabilityGrant::query()
            ->where('tenant_id', $t->id)->where('capability_key', 'ai.assist')->firstOrFail();

        $this->assertSame(
            \App\Domain\Licensing\PriceBook::costToServe(\App\Domain\Licensing\PriceBook::PROJECT)['model_spend']['micros'],
            $grant->budget_limit_micros,
        );
        $this->assertNotNull($grant->budget_limit_micros);
    }

    /** A plan_reference that names no known PriceBook tier still gets a real cap, not an unlimited one. */
    public function test_granting_ai_assist_with_an_unrecognized_plan_reference_still_gets_a_real_cap(): void
    {
        $t = $this->tenant('Some Legacy Pilot Co');

        $this->license->grant($t, 'ai.assist', planReference: 'Legacy pilot deal from 2025');

        $grant = \App\Models\CapabilityGrant::query()
            ->where('tenant_id', $t->id)->where('capability_key', 'ai.assist')->firstOrFail();

        $this->assertSame(
            \App\Domain\Licensing\PriceBook::costToServe(\App\Domain\Licensing\PriceBook::FIELD)['model_spend']['micros'],
            $grant->budget_limit_micros,
        );
    }

    /** An admin who explicitly sets a budget - including a deliberately generous one - is never overridden. */
    public function test_an_explicit_budget_limit_is_never_overridden_by_the_tier_default(): void
    {
        $t = $this->tenant('City of Irvine');

        $this->license->grant($t, 'ai.assist', planReference: 'agency', budgetLimitMicros: 999_000_000);

        $grant = \App\Models\CapabilityGrant::query()
            ->where('tenant_id', $t->id)->where('capability_key', 'ai.assist')->firstOrFail();

        $this->assertSame(999_000_000, $grant->budget_limit_micros);
    }
}
