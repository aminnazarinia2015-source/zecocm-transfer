<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Project;
use App\Models\Signature;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Generic per-party document templates + signatures - the audit's fourth
 * gap: "the capability of adding each party's template and sign." Pins the
 * two properties that matter most: a signature binds to the exact values it
 * covered (content_hash), and neither a signature nor a completed
 * assignment's history is ever rewritten - only voided and re-signed.
 */
class DocumentTemplateSignatureTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private User $pm;

    private User $subForeman;

    private User $viewerOnly;

    private Project $project;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate Builders', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor', 'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->pm = User::create(['tenant_id' => $this->tenant->id, 'name' => 'PM', 'email' => 'pm@northgate.test', 'password' => bcrypt('password')]);
        $this->subForeman = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Sub Foreman', 'email' => 'foreman@cdm.test', 'password' => bcrypt('password')]);
        $this->viewerOnly = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Viewer', 'email' => 'viewer@northgate.test', 'password' => bcrypt('password')]);

        $this->project = Project::create(['number' => 'P-500', 'name' => 'Riverbend Pump Station', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true], 'status' => 'active']);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->subForeman->id,
            'organization' => 'CDM Fencing', 'seat' => 'contractor', 'capabilities' => ['template.sign' => true, 'template.view' => true], 'status' => 'active']);
        Membership::create(['project_id' => $this->project->id, 'user_id' => $this->viewerOnly->id,
            'organization' => 'Northgate Builders', 'seat' => 'viewer', 'capabilities' => ['template.view' => true], 'status' => 'active']);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    private function safetyPlanFields(): array
    {
        return [
            ['key' => 'acknowledged_by', 'label' => 'Acknowledged by', 'type' => 'text', 'required' => true],
            ['key' => 'notes', 'label' => 'Notes', 'type' => 'textarea', 'required' => false],
        ];
    }

    public function test_a_pm_can_create_a_project_template(): void
    {
        Sanctum::actingAs($this->pm);

        $body = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan',
            'document_type' => 'safety', 'party_role' => 'subcontractor',
            'fields' => $this->safetyPlanFields(),
        ])->assertCreated()->json();

        $this->assertSame('Site Safety Plan', $body['name']);
        $this->assertCount(2, $body['fields']);
    }

    public function test_a_viewer_without_template_manage_cannot_create_a_template(): void
    {
        Sanctum::actingAs($this->viewerOnly);

        $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'X', 'document_type' => 'x',
            'fields' => $this->safetyPlanFields(),
        ])->assertStatus(403);
    }

    public function test_a_pm_can_assign_a_template_to_a_party(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();

        $body = $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'],
            'party_label' => 'CDM Fencing', 'assigned_to_user_id' => $this->subForeman->id,
        ])->assertCreated()->json();

        $this->assertSame('pending', $body['status']);
        $this->assertSame('CDM Fencing', $body['party_label']);
    }

    public function test_the_assigned_party_can_fill_in_and_sign_the_assignment(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();
        $assignment = $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'],
            'party_label' => 'CDM Fencing', 'assigned_to_user_id' => $this->subForeman->id,
        ])->json();

        Sanctum::actingAs($this->subForeman);
        $signed = $this->postJson('/api/template-assignments/' . $assignment['id'] . '/sign', [
            'values' => ['acknowledged_by' => 'J. Alvarez', 'notes' => 'Reviewed with crew.'],
        ])->assertOk()->json();

        $this->assertSame('completed', $signed['status']);
        $this->assertSame('Sub Foreman', $signed['signed_by']);
        $this->assertNotEmpty($signed['content_hash']);

        TenantContext::set($this->tenant->id);
        $this->assertDatabaseHas('signatures', ['signable_id' => $assignment['id'], 'signer_id' => $this->subForeman->id]);
        TenantContext::clear();
    }

    public function test_signing_requires_every_required_field(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();
        $assignment = $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'], 'party_label' => 'CDM Fencing',
        ])->json();

        Sanctum::actingAs($this->pm);
        $this->postJson('/api/template-assignments/' . $assignment['id'] . '/sign', [
            'values' => ['notes' => 'Missing the required field.'],
        ])->assertStatus(422);
    }

    public function test_an_already_signed_assignment_cannot_be_signed_again(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();
        $assignment = $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'], 'party_label' => 'CDM Fencing',
        ])->json();
        $this->postJson('/api/template-assignments/' . $assignment['id'] . '/sign', [
            'values' => ['acknowledged_by' => 'PM'],
        ])->assertOk();

        $this->postJson('/api/template-assignments/' . $assignment['id'] . '/sign', [
            'values' => ['acknowledged_by' => 'PM again'],
        ])->assertStatus(422);
    }

    public function test_voiding_a_signature_never_deletes_it_only_marks_it_void_and_reopens_the_assignment(): void
    {
        Sanctum::actingAs($this->pm);
        $template = $this->postJson('/api/document-templates', [
            'project_id' => $this->project->id, 'name' => 'Site Safety Plan', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();
        $assignment = $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $template['id'], 'party_label' => 'CDM Fencing',
        ])->json();
        $this->postJson('/api/template-assignments/' . $assignment['id'] . '/sign', [
            'values' => ['acknowledged_by' => 'PM'],
        ])->assertOk();

        $reopened = $this->postJson('/api/template-assignments/' . $assignment['id'] . '/void', [
            'reason' => 'Wrong person signed - redo with the actual foreman.',
        ])->assertOk()->json();

        $this->assertSame('pending', $reopened['status']);

        TenantContext::set($this->tenant->id);
        $this->assertDatabaseHas('signatures', ['signable_id' => $assignment['id'], 'void_reason' => 'Wrong person signed - redo with the actual foreman.']);
        $original = Signature::where('signable_id', $assignment['id'])->first();
        TenantContext::clear();
        $this->assertNotNull($original->void_at);

        // The old signature row is untouched history, not deleted - and it
        // stays immutable even after being voided.
        $this->expectException(\LogicException::class);
        $original->update(['signer_name' => 'Tampered']);
    }

    public function test_a_template_from_another_project_cannot_be_assigned_here(): void
    {
        Sanctum::actingAs($this->pm);
        TenantContext::set($this->tenant->id);
        $otherProject = Project::create(['number' => 'P-501', 'name' => 'Other Job', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        Membership::create(['project_id' => $otherProject->id, 'user_id' => $this->pm->id,
            'organization' => 'Northgate Builders', 'seat' => 'project_manager', 'capabilities' => ['*' => true], 'status' => 'active']);
        TenantContext::clear();

        $otherTemplate = $this->postJson('/api/document-templates', [
            'project_id' => $otherProject->id, 'name' => 'Other Project Template', 'document_type' => 'safety',
            'fields' => $this->safetyPlanFields(),
        ])->json();

        $this->postJson('/api/template-assignments', [
            'project_id' => $this->project->id, 'document_template_id' => $otherTemplate['id'], 'party_label' => 'CDM Fencing',
        ])->assertStatus(422);
    }
}
