<?php

namespace Tests\Feature;

use App\Domain\Trace\ProgressEvidenceCrossCheckService;
use App\Models\AiFinding;
use App\Models\DailyReport;
use App\Models\DailyReportActivity;
use App\Models\MediaItem;
use App\Models\PayApplication;
use App\Models\PayApplicationLine;
use App\Models\Project;
use App\Models\ScheduleActivity;
use App\Models\ScheduleOfValueItem;
use App\Models\ScheduleVersion;
use App\Models\SovScheduleLink;
use App\Models\Tenant;
use App\Models\User;
use App\Tenancy\TenantContext;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * TRACE-01 ("Missing expected progress record") and TRACE-02 ("Recorded
 * progress outside scheduled window") - the first two rules of the closed
 * Progress Evidence Cross-Check design
 * (claude/trace-progress-vs-schedule-deviation-design-brief.md). TRACE-03 is
 * intentionally not implemented (it needs a pay-application field that does
 * not exist yet).
 *
 * Every assertion here checks the CONSERVATIVE side of Codex's ruling: a
 * finding only ever fires when the service can actually support it from
 * verified, structured data, and it is worded as an observation/data-gap,
 * never a conclusion about delay or fault.
 */
class ProgressEvidenceCrossCheckServiceTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    private Project $project;

    private User $user;

    private MediaItem $media;

    private PayApplication $payApplication;

    private ScheduleOfValueItem $sovItem;

    private PayApplicationLine $line;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tenant = Tenant::create(['name' => 'Northgate', 'type' => 'Contractor', 'status' => 'active',
            'entitlements' => Tenant::defaultEntitlements('Contractor'), 'sponsor_role' => 'contractor',
            'is_account_owner' => true]);
        TenantContext::set($this->tenant->id);
        $this->user = User::create(['tenant_id' => $this->tenant->id, 'name' => 'Rita Salas',
            'email' => 'rita@northgate.test', 'password' => bcrypt('password')]);
        $this->project = Project::create(['number' => 'P-410', 'name' => 'Riverbend', 'sector' => 'public',
            'owner_name' => 'City of Riverbend', 'state' => 'CA', 'funding_source' => 'local',
            'org_structure' => [], 'contract_clocks' => []]);
        $this->media = MediaItem::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'sha256' => hash('sha256', 'schedule.xer'), 'storage_path' => 'test/schedule.xer',
            'original_name' => 'schedule.xer', 'mime' => 'application/octet-stream', 'bytes' => 10,
            'provenance' => [], 'provenance_signature' => hash('sha256', 'prov'), 'confidence' => 'strong',
            'captured_by' => $this->user->id]);
        $this->sovItem = ScheduleOfValueItem::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'item_number' => '03-200',
            'description' => 'Concrete Improvements', 'scheduled_value_cents' => 18000000,
            'original_value_cents' => 18000000]);
        $this->payApplication = PayApplication::create(['tenant_id' => $this->tenant->id,
            'project_id' => $this->project->id, 'number' => 6, 'period_from' => '2026-07-01',
            'period_to' => '2026-07-31']);
        $this->line = PayApplicationLine::create(['tenant_id' => $this->tenant->id,
            'pay_application_id' => $this->payApplication->id,
            'schedule_of_value_item_id' => $this->sovItem->id, 'this_period_cents' => 5000000]);
        TenantContext::clear();
    }

    protected function tearDown(): void
    {
        TenantContext::clear();
        parent::tearDown();
    }

    public function test_an_unmapped_sov_line_produces_a_mapping_gap_finding(): void
    {
        TenantContext::set($this->tenant->id);
        $this->scheduleVersion(); // a schedule exists, but no SovScheduleLink at all

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('MAPPING_GAP', $findings[0]->category);
        $this->assertSame('DATA_GAP', $findings[0]->finding_class);
        $this->assertStringContainsString('No verified schedule-activity mapping', $findings[0]->summary);
    }

    public function test_a_link_pending_verification_is_treated_as_unmapped(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION');
        SovScheduleLink::create(['tenant_id' => $this->tenant->id,
            'schedule_of_value_item_id' => $this->sovItem->id, 'schedule_activity_id' => $activity->id,
            'schedule_version_id' => $version->id, 'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_AI_SUGGESTED,
            // mapping_status defaults to UNVERIFIED - never verified by a human
        ]);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('MAPPING_GAP', $findings[0]->category);
    }

    public function test_an_unclassified_activity_type_produces_a_mapping_gap_not_a_silent_skip(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, null); // unclassified, e.g. imported before activity_type existed
        $this->verifiedLink($version, $activity);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('MAPPING_GAP', $findings[0]->category);
        $this->assertStringContainsString('not classified as field-production work', $findings[0]->summary);
    }

    public function test_a_procurement_activity_is_excluded_from_corroboration_checks(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'PROCUREMENT');
        $this->verifiedLink($version, $activity);
        // No daily report at all - would trip TRACE-01 if this activity were eligible.

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('MAPPING_GAP', $findings[0]->category, 'A procurement activity was cross-checked as if it were field work.');
    }

    public function test_trace01_fires_when_a_planned_activity_has_no_daily_report_in_period(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);
        // No DailyReportActivity created at all.

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('TRACE-01', $findings[0]->rule_id);
        $this->assertSame('CORROBORATION_GAP', $findings[0]->category);
        $this->assertSame('DATA_GAP', $findings[0]->finding_class);
        $this->assertStringContainsString('Expected corroboration not located', $findings[0]->summary);
        $this->assertStringNotContainsString('deviation', strtolower($findings[0]->summary));
    }

    public function test_trace01_does_not_fire_when_a_finalized_daily_report_covers_the_activity(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);
        $this->linkedDailyReport($activity, '2026-07-15', locked: true);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertSame([], $findings);
    }

    public function test_trace01_does_not_count_an_unlocked_draft_report_as_corroboration(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);
        $this->linkedDailyReport($activity, '2026-07-15', locked: false); // still a draft

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('CORROBORATION_GAP', $findings[0]->category);
    }

    public function test_trace02_fires_when_a_daily_report_is_materially_outside_the_planned_window(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $link = $this->verifiedLink($version, $activity);
        // Also gives TRACE-01 corroboration (a report exists in-period)...
        $this->linkedDailyReport($activity, '2026-07-15', locked: true);
        // ...but this second report is 30 days before the planned window starts.
        $this->linkedDailyReport($activity, '2026-06-10', locked: true);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertCount(1, $findings);
        $this->assertSame('TRACE-02', $findings[0]->rule_id);
        $this->assertSame('RECORD_MISMATCH', $findings[0]->category);
        $this->assertSame('OBSERVATION', $findings[0]->finding_class);
        $this->assertStringContainsString('2026-06-10', $findings[0]->summary);
        // Never a conclusion - only what the records say.
        $this->assertStringNotContainsString('delay', strtolower($findings[0]->summary));
        $this->assertStringNotContainsString('fault', strtolower($findings[0]->summary));
    }

    public function test_trace02_does_not_fire_for_a_report_within_the_buffer_of_the_planned_window(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);
        // 5 days before start - within the buffer, normal schedule slack.
        $this->linkedDailyReport($activity, '2026-07-05', locked: true);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        TenantContext::clear();

        $this->assertSame([], $findings);
    }

    public function test_every_finding_carries_real_evidence_rows_and_a_searched_universe(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);

        $findings = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        $finding = AiFinding::with('evidence')->find($findings[0]->id);
        $evidenceCount = $finding->evidence->count();
        $searchedUniverse = $finding->searched_universe;
        TenantContext::clear();

        $this->assertGreaterThan(0, $evidenceCount, 'A finding was created with no citation trail at all.');
        $this->assertNotEmpty($searchedUniverse, 'A finding did not record what it actually searched.');
    }

    public function test_evaluating_the_same_pay_application_twice_reuses_one_review_context(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);

        (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        $contextCount = \App\Models\PayApplicationReviewContext::where('pay_application_id', $this->payApplication->id)->count();
        TenantContext::clear();

        $this->assertSame(1, $contextCount, 'Re-evaluating against the same schedule version created a second context row.');
    }

    public function test_evaluating_twice_does_not_duplicate_a_still_open_finding(): void
    {
        // TRACE-01/02 must be safe to re-run on every read of the Pay
        // Application Review screen - a second run finding the exact same
        // gap must not create a second row.
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);

        (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        $count = AiFinding::where('pay_application_id', $this->payApplication->id)->count();
        TenantContext::clear();

        $this->assertSame(1, $count, 'Re-running the cross-check duplicated an already-open finding.');
    }

    public function test_a_dismissed_finding_is_not_resurrected_by_a_later_run(): void
    {
        TenantContext::set($this->tenant->id);
        $version = $this->scheduleVersion();
        $activity = $this->activity($version, 'CONSTRUCTION', '2026-07-10', '2026-07-20');
        $this->verifiedLink($version, $activity);

        $first = (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        $first[0]->update(['status' => AiFinding::STATUS_DISMISSED, 'resolved_by' => $this->user->id,
            'resolved_at' => now(), 'resolution_note' => 'Confirmed via inspection photo; float absorbed the gap.']);

        (new ProgressEvidenceCrossCheckService)->evaluate($this->payApplication->fresh());
        $finding = AiFinding::where('pay_application_id', $this->payApplication->id)->first();
        $count = AiFinding::where('pay_application_id', $this->payApplication->id)->count();
        TenantContext::clear();

        $this->assertSame(1, $count);
        $this->assertSame(AiFinding::STATUS_DISMISSED, $finding->status);
    }

    private function scheduleVersion(): ScheduleVersion
    {
        return ScheduleVersion::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'kind' => 'lookahead', 'label' => 'Update #4', 'data_date' => '2026-07-31',
            'submitted_by_org' => 'Northgate', 'submitted_at' => now(), 'source_file_media_id' => $this->media->id,
            'source_format' => 'xer', 'parser_name' => 'primavera', 'parser_version' => '1.0',
            'source_sha256' => hash('sha256', 'schedule.xer'), 'ingest_assumptions' => [], 'security_scan' => [],
            'created_by' => $this->user->id]);
    }

    private function activity(ScheduleVersion $version, ?string $activityType, ?string $start = null, ?string $finish = null): ScheduleActivity
    {
        return ScheduleActivity::create(['tenant_id' => $this->tenant->id, 'schedule_version_id' => $version->id,
            'activity_code' => 'A1220', 'name' => 'Pour sidewalk', 'activity_type' => $activityType,
            'start_planned' => $start, 'finish_planned' => $finish]);
    }

    private function verifiedLink(ScheduleVersion $version, ScheduleActivity $activity): SovScheduleLink
    {
        $link = SovScheduleLink::create(['tenant_id' => $this->tenant->id,
            'schedule_of_value_item_id' => $this->sovItem->id, 'schedule_activity_id' => $activity->id,
            'schedule_version_id' => $version->id, 'relationship_type' => SovScheduleLink::RELATIONSHIP_DIRECT,
            'mapping_source' => SovScheduleLink::SOURCE_PM]);
        $link->update(['mapping_status' => SovScheduleLink::STATUS_VERIFIED, 'verified_by' => $this->user->id,
            'verified_at' => now()]);

        return $link->fresh();
    }

    private function linkedDailyReport(ScheduleActivity $activity, string $date, bool $locked): DailyReportActivity
    {
        $report = DailyReport::create(['tenant_id' => $this->tenant->id, 'project_id' => $this->project->id,
            'report_date' => $date, 'foreman_id' => $this->user->id, 'work_performed' => 'Poured sidewalk sections.',
            'cost_code_notes' => [], 'locked' => $locked, 'corrections' => []]);

        return DailyReportActivity::create(['tenant_id' => $this->tenant->id, 'daily_report_id' => $report->id,
            'schedule_activity_id' => $activity->id]);
    }
}
