<?php

namespace Tests\Feature;

use App\Domain\Onboarding\PaymentProvider;
use App\Domain\Onboarding\RegistrationProvisioner;
use App\Domain\Onboarding\StripePaymentProvider;
use App\Models\ContractorRegistration;
use App\Models\PaymentWebhookEvent;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Covers the closed self-serve onboarding design in
 * claude/payment-gateway-and-contractor-onboarding-design-brief.md: step-1 registration, starting
 * checkout, webhook-driven (never browser-redirect-driven) payment confirmation, idempotent
 * provisioning, and the no-mailed-password first-login flow.
 *
 * Both real payment providers make outbound HTTP calls to Stripe/PayPal — never something a test
 * should do. Tests fake the PaymentProvider contract by binding a FakePaymentProvider onto the
 * concrete provider class names the controllers resolve, so the HTTP boundary is the only thing
 * faked; every other line of this app's own code runs for real.
 */
class ContractorSelfServeOnboardingTest extends TestCase
{
    use RefreshDatabase;

    private function fakeRegistration(array $overrides = []): array
    {
        return array_merge([
            'legal_name' => 'Rivera Concrete Works LLC',
            'business_name' => 'Rivera Concrete',
            'entity_type' => 'llc',
            'country' => 'US',
            'admin_first_name' => 'Maria',
            'admin_last_name' => 'Rivera',
            'phone' => '555-0142',
            'address' => [
                'line1' => '48 Industrial Way',
                'city' => 'Fresno',
                'region' => 'CA',
                'postal_code' => '93706',
            ],
            'email' => 'maria@riveraconcrete.test',
        ], $overrides);
    }

    public function test_step_one_registration_creates_a_pending_registration_without_any_payment_or_tenant(): void
    {
        $response = $this->postJson('/api/onboarding/register', $this->fakeRegistration());

        $response->assertCreated();
        $response->assertJson(['status' => ContractorRegistration::STATUS_PENDING_PAYMENT]);

        $registration = ContractorRegistration::where('registration_id', $response->json('registration_id'))->firstOrFail();
        $this->assertSame('Rivera Concrete Works LLC', $registration->legal_name);
        $this->assertNull($registration->tenant_id);
        $this->assertNull($registration->payment_provider);
    }

    public function test_resubmitting_step_one_with_the_same_registration_id_updates_the_same_row_not_a_duplicate(): void
    {
        $payload = $this->fakeRegistration(['registration_id' => (string) \Illuminate\Support\Str::uuid()]);

        $this->postJson('/api/onboarding/register', $payload)->assertCreated();
        $corrected = array_merge($payload, ['phone' => '555-9999']);
        $this->postJson('/api/onboarding/register', $corrected)->assertCreated();

        $this->assertSame(1, ContractorRegistration::where('registration_id', $payload['registration_id'])->count());
        $this->assertSame('555-9999', ContractorRegistration::where('registration_id', $payload['registration_id'])->first()->phone);
    }

    public function test_license_and_dir_fields_are_not_part_of_registration_and_no_tax_id_field_exists_anywhere(): void
    {
        // LIB/onboarding closure: license/DIR are optional and collected later, tied to a
        // project's jurisdiction - never part of this step. Tax ID/SSN was explicitly dropped
        // from the design entirely (Amin confirmed ZecoCM never pays contractors, so there is no
        // 1099/TIN-reporting reason to collect one). Asserting the columns don't exist is the
        // strongest guarantee this can't silently creep back in.
        $columns = \Illuminate\Support\Facades\Schema::getColumnListing('contractor_registrations');

        foreach (['license_number', 'dir_number', 'tax_id', 'ssn'] as $forbidden) {
            $this->assertNotContains($forbidden, $columns, "Column '{$forbidden}' should never exist on contractor_registrations.");
        }
    }

    public function test_checkout_calls_the_selected_provider_and_returns_its_url(): void
    {
        $this->app->bind(StripePaymentProvider::class, fn () => new FakePaymentProvider('stripe', 'https://checkout.stripe.test/session/abc'));

        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');

        $response = $this->postJson("/api/onboarding/register/{$registrationId}/checkout", ['provider' => 'stripe']);

        $response->assertOk();
        $response->assertJson(['checkout_url' => 'https://checkout.stripe.test/session/abc']);
    }

    public function test_checkout_refuses_a_registration_that_already_moved_past_payment(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');
        ContractorRegistration::where('registration_id', $registrationId)->update(['status' => ContractorRegistration::STATUS_PAYMENT_CONFIRMED]);

        $this->app->bind(StripePaymentProvider::class, fn () => new FakePaymentProvider('stripe', 'https://irrelevant.test'));

        $response = $this->postJson("/api/onboarding/register/{$registrationId}/checkout", ['provider' => 'stripe']);

        $response->assertStatus(409);
    }

    public function test_an_unverifiable_webhook_never_confirms_payment_or_provisions_anything(): void
    {
        $this->app->bind(StripePaymentProvider::class, fn () => new FakePaymentProvider('stripe', 'irrelevant', verifiesAs: null));

        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');

        $response = $this->postJson('/api/onboarding/webhooks/stripe', ['anything' => 'not a real stripe payload']);

        $response->assertOk();
        $this->assertSame(
            ContractorRegistration::STATUS_PENDING_PAYMENT,
            ContractorRegistration::where('registration_id', $registrationId)->first()->status,
        );
        $this->assertSame(0, PaymentWebhookEvent::count());
    }

    public function test_a_verified_successful_webhook_confirms_payment_and_provisions_a_real_tenant(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');

        $event = [
            'event_id' => 'evt_test_1',
            'type' => 'checkout.session.completed',
            'registration_id' => $registrationId,
            'customer_id' => 'cus_test_1',
            'subscription_id' => 'sub_test_1',
        ];
        $this->app->bind(StripePaymentProvider::class, fn () => new FakePaymentProvider('stripe', 'irrelevant', verifiesAs: $event));

        $response = $this->postJson('/api/onboarding/webhooks/stripe', ['id' => 'evt_test_1']);
        $response->assertOk();

        $registration = ContractorRegistration::where('registration_id', $registrationId)->first();
        $this->assertSame(ContractorRegistration::STATUS_PROVISIONED, $registration->status);
        $this->assertNotNull($registration->payment_confirmed_at);
        $this->assertSame('cus_test_1', $registration->payment_provider_customer_id);

        $tenant = Tenant::find($registration->tenant_id);
        $this->assertNotNull($tenant);
        $this->assertSame('Rivera Concrete', $tenant->name);
        $this->assertSame('active', $tenant->status);

        $admin = User::where('tenant_id', $tenant->id)->where('email', 'maria@riveraconcrete.test')->first();
        $this->assertNotNull($admin, 'The admin user should be provisioned with the registration email.');
        $this->assertFalse(\Illuminate\Support\Facades\Hash::check('anything-guessable', $admin->password), 'Password must be an unusable random hash, never a predictable or mailed value.');
    }

    public function test_a_retried_webhook_delivery_never_provisions_a_second_tenant(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');

        $event = [
            'event_id' => 'evt_test_retry',
            'type' => 'checkout.session.completed',
            'registration_id' => $registrationId,
            'customer_id' => 'cus_1',
            'subscription_id' => 'sub_1',
        ];
        $this->app->bind(StripePaymentProvider::class, fn () => new FakePaymentProvider('stripe', 'irrelevant', verifiesAs: $event));

        $this->postJson('/api/onboarding/webhooks/stripe', ['id' => 'evt_test_retry'])->assertOk();
        $tenantCountAfterFirst = Tenant::count();

        // Stripe/PayPal both legitimately redeliver webhooks - this must be a guaranteed no-op.
        $this->postJson('/api/onboarding/webhooks/stripe', ['id' => 'evt_test_retry'])->assertOk();

        $this->assertSame($tenantCountAfterFirst, Tenant::count(), 'A retried webhook must never create a second tenant.');
        $this->assertSame(1, PaymentWebhookEvent::where('provider_event_id', 'evt_test_retry')->count());
    }

    public function test_provisioning_is_idempotent_when_called_directly_twice(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');
        $registration = ContractorRegistration::where('registration_id', $registrationId)->first();

        $provisioner = app(RegistrationProvisioner::class);
        $provisioner->markPaymentConfirmed($registration, 'stripe', 'cus_x', 'sub_x');
        $registration->refresh();

        $first = $provisioner->provision($registration);
        $second = $provisioner->provision($registration->fresh());

        $this->assertSame($first['tenant']->id, $second['tenant']->id);
        $this->assertSame(1, Tenant::count());
    }

    public function test_password_setup_link_requires_a_valid_signature(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');
        $registration = ContractorRegistration::where('registration_id', $registrationId)->first();
        app(RegistrationProvisioner::class)->markPaymentConfirmed($registration, 'stripe', 'cus_1', 'sub_1');
        ['admin_user' => $admin, 'password_setup_token' => $signedUrl] = app(RegistrationProvisioner::class)->provision($registration->fresh());

        // Tampered link (wrong user id in an otherwise-valid-looking URL) must be rejected.
        $tampered = str_replace((string) $admin->id, (string) ($admin->id + 999), $signedUrl);
        $this->get($tampered)->assertForbidden();

        // The real signed link works.
        $this->get($signedUrl)->assertOk()->assertJson(['email' => 'maria@riveraconcrete.test']);
    }

    public function test_setting_the_password_via_the_signed_link_allows_login_afterward(): void
    {
        $registrationId = $this->postJson('/api/onboarding/register', $this->fakeRegistration())->json('registration_id');
        $registration = ContractorRegistration::where('registration_id', $registrationId)->first();
        app(RegistrationProvisioner::class)->markPaymentConfirmed($registration, 'stripe', 'cus_1', 'sub_1');
        ['admin_user' => $admin, 'password_setup_token' => $signedUrl] = app(RegistrationProvisioner::class)->provision($registration->fresh());

        $path = parse_url($signedUrl, PHP_URL_PATH).'?'.parse_url($signedUrl, PHP_URL_QUERY);
        $this->postJson($path, ['password' => 'a-real-strong-password-1', 'password_confirmation' => 'a-real-strong-password-1'])
            ->assertOk();

        $this->assertTrue(\Illuminate\Support\Facades\Hash::check('a-real-strong-password-1', $admin->fresh()->password));
    }
}

/**
 * Test double satisfying PaymentProvider without any outbound HTTP call. `verifiesAs` controls
 * what verifyWebhook() returns - null to simulate an unverifiable/forged payload, or a normalized
 * event array to simulate a genuine, verified provider event.
 */
class FakePaymentProvider implements PaymentProvider
{
    public function __construct(
        private string $providerName,
        private string $checkoutUrl,
        private ?array $verifiesAs = null,
    ) {
    }

    public function name(): string
    {
        return $this->providerName;
    }

    public function startCheckout(ContractorRegistration $registration): string
    {
        return $this->checkoutUrl;
    }

    public function verifyWebhook(string $rawPayload, array $headers): ?array
    {
        return $this->verifiesAs;
    }
}
