<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContractorRegistration extends Model
{
    // Deliberately NOT tenant-scoped — see the migration's docblock. A registration exists before
    // any tenant does.

    public const STATUS_PENDING_PAYMENT = 'pending_payment';

    public const STATUS_PAYMENT_CONFIRMED = 'payment_confirmed';

    public const STATUS_PROVISIONING = 'provisioning';

    public const STATUS_PROVISIONED = 'provisioned';

    public const STATUS_PAYMENT_FAILED = 'payment_failed';

    protected $fillable = [
        'registration_id', 'legal_name', 'business_name', 'entity_type', 'country',
        'admin_first_name', 'admin_last_name', 'phone', 'address', 'email',
        'payment_provider', 'payment_provider_customer_id', 'payment_provider_subscription_id',
        'status', 'payment_confirmed_at', 'tenant_id',
    ];

    protected $casts = [
        'address' => 'array',
        'payment_confirmed_at' => 'datetime',
    ];

    public static function entityTypes(): array
    {
        return [
            'sole_proprietorship' => 'Sole proprietorship',
            'llc' => 'LLC',
            'corporation' => 'Corporation',
            'partnership' => 'Partnership',
            'other' => 'Other',
        ];
    }

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function isProvisioned(): bool
    {
        return $this->status === self::STATUS_PROVISIONED && $this->tenant_id !== null;
    }
}
