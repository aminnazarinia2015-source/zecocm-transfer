<?php

namespace App\Domain\Onboarding;

use App\Models\ContractorRegistration;
use Illuminate\Support\Facades\Http;

/**
 * Talks to Stripe's plain REST API directly (no stripe-php SDK dependency — this environment
 * can't reach packagist to install one, and Stripe's API is a stable, well-documented HTTP API,
 * so a thin client is a reasonable substitute, not a compromise). Cards only; PayPal is a
 * separate provider per the closed design brief (Stripe's own PayPal support doesn't cover US
 * merchants). No crypto — dropped from scope entirely.
 *
 * Never touches a raw card number: Checkout Sessions render Stripe's own hosted payment page,
 * so this class only ever sees a session ID/URL and, later, webhook events.
 */
class StripePaymentProvider implements PaymentProvider
{
    public function name(): string
    {
        return 'stripe';
    }

    public function startCheckout(ContractorRegistration $registration): string
    {
        $secret = config('services.stripe.secret_key');
        $priceId = config('services.stripe.price_id');

        if ($secret === '' || $priceId === '') {
            throw new \RuntimeException(
                'Stripe is not configured (STRIPE_SECRET_KEY / STRIPE_PRICE_ID) — cannot start checkout.'
            );
        }

        // Idempotency key is the registration's own stable id, so retrying this call (a double
        // form submit, a client retry) can never create two Checkout Sessions/subscriptions for
        // the same registration — Stripe deduplicates on this key for ~24h.
        $response = Http::withToken($secret)
            ->asForm()
            ->withHeaders(['Idempotency-Key' => 'checkout-'.$registration->registration_id])
            ->post('https://api.stripe.com/v1/checkout/sessions', [
                'mode' => 'subscription',
                'line_items' => [['price' => $priceId, 'quantity' => 1]],
                'customer_email' => $registration->email,
                'client_reference_id' => $registration->registration_id,
                'success_url' => config('app.url').'/onboarding/success?registration_id='.$registration->registration_id,
                'cancel_url' => config('app.url').'/onboarding/payment?registration_id='.$registration->registration_id,
                // Never trust success_url alone — see verifyWebhook(). This is UX-only, per both
                // design reviews' explicit call-out that a browser redirect is never the source
                // of payment truth.
                'metadata' => ['registration_id' => $registration->registration_id],
            ])
            ->throw();

        return $response->json('url');
    }

    public function verifyWebhook(string $rawPayload, array $headers): ?array
    {
        $signatureHeader = $headers['stripe-signature'][0] ?? $headers['Stripe-Signature'][0] ?? null;
        if ($signatureHeader === null) {
            return null; // not a Stripe webhook at all
        }

        $secret = config('services.stripe.webhook_secret');
        if ($secret === '') {
            throw new \RuntimeException('STRIPE_WEBHOOK_SECRET is not configured — refusing to trust an unverifiable webhook.');
        }

        // Stripe's documented signature format: "t=<timestamp>,v1=<hex hmac>[,v1=<hex hmac>...]"
        $parts = [];
        foreach (explode(',', $signatureHeader) as $pair) {
            [$key, $value] = array_pad(explode('=', $pair, 2), 2, null);
            $parts[$key][] = $value;
        }
        $timestamp = $parts['t'][0] ?? null;
        $signatures = $parts['v1'] ?? [];

        if ($timestamp === null || $signatures === []) {
            return null;
        }

        $expected = hash_hmac('sha256', $timestamp.'.'.$rawPayload, $secret);

        $verified = false;
        foreach ($signatures as $sig) {
            if (hash_equals($expected, (string) $sig)) {
                $verified = true;
                break;
            }
        }

        if (! $verified) {
            return null; // fails closed — an unverified webhook is treated as not Stripe's
        }

        $event = json_decode($rawPayload, true);
        if (! is_array($event) || ! isset($event['id'], $event['type'])) {
            return null;
        }

        $object = $event['data']['object'] ?? [];

        return [
            'event_id' => $event['id'],
            'type' => $event['type'],
            'registration_id' => $object['client_reference_id'] ?? $object['metadata']['registration_id'] ?? null,
            'customer_id' => $object['customer'] ?? null,
            'subscription_id' => $object['subscription'] ?? null,
        ];
    }
}
