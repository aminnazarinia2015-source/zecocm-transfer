<?php

namespace App\Domain\Onboarding;

use App\Domain\Licensing\CapabilityCatalog;
use App\Domain\Licensing\CapabilityLicense;
use App\Models\ContractorRegistration;
use App\Models\PaymentWebhookEvent;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Turns a payment-confirmed ContractorRegistration into a real, working Tenant + admin User.
 * Idempotent by design: safe to call twice for the same registration (a retried webhook, a
 * re-queued job) — the second call is a guaranteed no-op that returns the already-provisioned
 * tenant rather than creating a second one. This is the concrete implementation of the
 * "idempotent saga" both design reviews (Gemini, Codex) required.
 *
 * Deliberately mirrors the platform's own existing manual account-creation pattern in
 * PlatformController@createAccount (Tenant::defaultEntitlements + CapabilityLicense::grant) so a
 * self-serve-provisioned account looks and behaves exactly like a platform-admin-provisioned one
 * — no second, divergent code path for "how a tenant gets set up."
 */
class RegistrationProvisioner
{
    /**
     * Records that a specific provider webhook event has already been processed. Returns false
     * (do nothing further) if this exact event_id was already recorded — the idempotency
     * guarantee against a retried/duplicated webhook delivery.
     */
    public function recordWebhookEventOnce(string $provider, string $eventId, string $eventType, array $payload): bool
    {
        try {
            PaymentWebhookEvent::create([
                'provider' => $provider,
                'provider_event_id' => $eventId,
                'event_type' => $eventType,
                'payload' => $payload,
                'processed_at' => now(),
            ]);

            return true;
        } catch (\Illuminate\Database\QueryException $e) {
            // Unique constraint on provider_event_id — already processed. Not an error, a no-op.
            return false;
        }
    }

    public function markPaymentConfirmed(
        ContractorRegistration $registration,
        string $provider,
        ?string $customerId,
        ?string $subscriptionId,
    ): ContractorRegistration {
        if ($registration->status !== ContractorRegistration::STATUS_PENDING_PAYMENT) {
            // Already confirmed (or further along) — idempotent no-op, not an error.
            return $registration;
        }

        $registration->update([
            'payment_provider' => $provider,
            'payment_provider_customer_id' => $customerId,
            'payment_provider_subscription_id' => $subscriptionId,
            'status' => ContractorRegistration::STATUS_PAYMENT_CONFIRMED,
            'payment_confirmed_at' => now(),
        ]);

        return $registration;
    }

    /**
     * @return array{tenant:Tenant,admin_user:User,password_setup_token:string}
     */
    public function provision(ContractorRegistration $registration): array
    {
        if ($registration->isProvisioned()) {
            // Idempotent: already done. Return the existing tenant/admin rather than re-creating.
            $tenant = $registration->tenant;
            $admin = User::where('tenant_id', $tenant->id)->where('email', $registration->email)->firstOrFail();

            return ['tenant' => $tenant, 'admin_user' => $admin, 'password_setup_token' => null];
        }

        if ($registration->status !== ContractorRegistration::STATUS_PAYMENT_CONFIRMED) {
            throw new \RuntimeException(
                "Refusing to provision registration {$registration->registration_id}: payment is not confirmed (status={$registration->status})."
            );
        }

        return DB::transaction(function () use ($registration) {
            $registration->update(['status' => ContractorRegistration::STATUS_PROVISIONING]);

            $entitlements = Tenant::defaultEntitlements('Contractor');

            $tenant = Tenant::create([
                'name' => $registration->business_name ?: $registration->legal_name,
                'legal_name' => $registration->legal_name,
                'type' => 'Contractor',
                'entitlements' => $entitlements,
                'status' => 'active',
                'sponsor_role' => 'contractor',
                'is_account_owner' => true,
                'address_lines' => $registration->address,
            ]);

            // No mailed password — see the design brief's correction. The admin sets their own
            // password via a signed, time-limited link; until then the account has an unusable
            // random hash and cannot log in.
            $admin = User::create([
                'tenant_id' => $tenant->id,
                'name' => trim($registration->admin_first_name.' '.$registration->admin_last_name),
                'email' => $registration->email,
                'password' => bcrypt(Str::random(40)),
            ]);

            $licenses = app(CapabilityLicense::class);
            foreach ($entitlements as $capability) {
                if (CapabilityCatalog::has($capability) && ! CapabilityCatalog::isFree($capability)) {
                    $licenses->grant(
                        $tenant,
                        $capability,
                        planReference: 'contractor_self_serve',
                        reason: "Self-serve registration {$registration->registration_id}",
                    );
                }
            }

            $registration->update([
                'status' => ContractorRegistration::STATUS_PROVISIONED,
                'tenant_id' => $tenant->id,
            ]);

            $token = $this->passwordSetupToken($admin);

            return ['tenant' => $tenant, 'admin_user' => $admin, 'password_setup_token' => $token];
        });
    }

    /**
     * A signed, expiring URL is issued instead of a mailed password. Verified by
     * SetPasswordController against the user's id + email — standard Laravel signed-URL
     * mechanism, not a custom token table, kept deliberately simple for v1.
     */
    private function passwordSetupToken(User $user): string
    {
        return \Illuminate\Support\Facades\URL::temporarySignedRoute(
            'onboarding.password.show',
            now()->addDays(7),
            ['user' => $user->id],
        );
    }
}
