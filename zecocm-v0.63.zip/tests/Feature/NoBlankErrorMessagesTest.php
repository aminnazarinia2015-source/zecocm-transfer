<?php

namespace Tests\Feature;

use Tests\TestCase;

/**
 * Found during a real-world, every-role walkthrough: an ordinary customer
 * (project manager) hitting a platform-only endpoint like GET /platform/customers
 * got back {"message": "", ...} - a blank error message. Eleven abort_unless()
 * calls across PlatformController, CapabilityGapController and
 * HomepageContentController passed only a status code with no message string,
 * so Laravel's HttpException rendered with an empty "message" - the one part
 * of a refusal a person actually reads. Five more abort_unless() 404s (two
 * controllers) had the same gap. This statically guards every abort_unless/
 * abort_if call in app/Http/Controllers that ends in a bare 3-digit status
 * code with no message argument - the exact shape of the bug found.
 */
class NoBlankErrorMessagesTest extends TestCase
{
    public function test_no_controller_aborts_with_a_status_code_and_no_message(): void
    {
        $offenders = [];
        foreach (glob(base_path('app/Http/Controllers/*.php')) as $file) {
            $php = file_get_contents($file);
            if (preg_match_all('/abort(?:_if|_unless)?\([^;]*,\s*[0-9]{3}\);/', $php, $matches)) {
                foreach ($matches[0] as $match) {
                    $offenders[] = basename($file).': '.trim($match);
                }
            }
        }

        $this->assertSame([], $offenders,
            "Every abort()/abort_if()/abort_unless() call in a controller must carry a human-readable message ".
            "as its last argument - found bare status-code-only calls that would render as {\"message\":\"\"}: \n".
            implode("\n", $offenders));
    }
}
