<?php

namespace Tests\Feature;

use Tests\TestCase;

class VisibleActionContractTest extends TestCase
{
    public function test_primary_account_actions_expose_busy_and_accessible_feedback_contracts(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertIsString($html);
        $this->assertStringContainsString('id="login-submit"', $html);
        $this->assertStringContainsString('id="account-name-save"', $html);
        $this->assertStringContainsString('id="account-password-save"', $html);
        $this->assertStringContainsString('id="account-signout"', $html);
        $this->assertStringContainsString('role="status" aria-live="polite"', $html);
        $this->assertStringContainsString('role="dialog" aria-modal="true"', $html);
        $this->assertStringContainsString("setActionBusy('login-submit', true", $html);
        $this->assertStringContainsString("setActionBusy('account-name-save',true", $html);
        $this->assertStringContainsString("setActionBusy('account-password-save',true", $html);
        $this->assertStringContainsString("if(e.key!=='Escape')return", $html);
        $this->assertStringContainsString('id="modal-submit"', $html);
        $this->assertStringContainsString('id="schedule-version-submit"', $html);
        $this->assertStringContainsString('id="schedule-analysis-submit"', $html);
        // A schedule-version upload with an unusable file type (e.g. a PDF) must say so
        // out loud rather than silently doing nothing but update small state-panel text.
        $this->assertStringContainsString('be used as a schedule version', $html);
        // A knowledge-source upload (a real PDF/spec file, sometimes tens of MB) must show
        // a visible busy state - found "doing nothing" from the user's side while it was,
        // in fact, uploading, with the only feedback being a toast several seconds later.
        $this->assertStringContainsString('id="ks-submit"', $html);
        $this->assertStringContainsString("setActionBusy('ks-submit', true, 'Uploading", $html);
        // System Settings must let an admin actually set a key, not just see
        // whether one is configured - found live: the only way to change
        // ANTHROPIC_API_KEY was an SSH console, .env, and config:cache.
        $this->assertStringContainsString('id="secrets-body"', $html);
        $this->assertStringContainsString('ZAPI.loadPlatformSecrets', $html);
        $this->assertStringContainsString('ZAPI.savePlatformSecret', $html);
        $this->assertStringContainsString("setActionBusy('secret-save-' + key, true, 'Saving", $html);
        $this->assertStringContainsString('Nothing was sealed - the decision service is unreachable.', $html);
        $this->assertStringContainsString('Nothing was issued - the document service is unreachable.', $html);
        $this->assertStringContainsString('Customer service is unreachable.', $html);
        $this->assertStringContainsString('id="action-intelligence"', $html);
        $this->assertStringContainsString('Verified scope', $html);
        $this->assertStringContainsString('Your authority', $html);
        $this->assertStringContainsString('Next safe action', $html);
        $this->assertStringContainsString('formal disposition requires a decision envelope', $html);
        $this->assertStringContainsString('id="view-docs"', $html);
        $this->assertStringContainsString('id="doc-breadcrumbs"', $html);
        $this->assertStringContainsString('Scripts, executables, archives and active web content are refused.', $html);
        $this->assertStringContainsString('ZAPI.loadDocumentLibrary', $html);
        $this->assertStringContainsString('ZAPI.chooseDocumentVersion', $html);
        $this->assertStringContainsString('id="view-inspections"', $html);
        $this->assertStringContainsString('Create accountable record', $html);
        $this->assertStringContainsString('Verify &amp; close', $html);
        $this->assertStringContainsString('ZAPI.transitionQuality', $html);
    }

    public function test_unwired_modules_route_to_an_explicit_honest_state_without_false_global_toasts(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertIsString($html);
        $this->assertStringContainsString("name='unavailable'", $html);
        $this->assertStringNotContainsString('var label=(b.textContent', $html);
        $this->assertStringNotContainsString("'payapps','docs','inspections','meetings'", $html);
        $this->assertStringContainsString('Open project (Support Mode)', $html);
        $this->assertStringContainsString('audited support mode', $html);
        $this->assertStringContainsString('var WIRED_VIEWS=', $html);
        $this->assertStringContainsString('My action items', $html);
        $this->assertStringContainsString('Quality &amp; Punch List', $html);
        $this->assertStringContainsString('Knowledge Library · ZecoCM Atlas', $html);
        $this->assertStringContainsString('AI Activity &amp; Audit Log', $html);
        $this->assertStringContainsString('Project Team &amp; Routing', $html);
        $this->assertStringContainsString('var WIRED_VIEWS=', $html);
    }

    /**
     * A module that HAS a live server source must never be listed as prototype-only.
     *
     * This is a real defect that reached production: the document library (v0.21) and
     * quality/punch (v0.22) both shipped with working, licensed, tested APIs, and both
     * showed "not a live module" in the interface for seven releases because the honesty
     * guard in openView() still named their views. The guard is correct; leaving a built
     * module inside it is the bug, and it is invisible to every server-side test.
     */
    public function test_no_module_with_a_live_loader_is_still_marked_prototype_only(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertMatchesRegularExpression('/var prototypeOnly = \[(.*?)\];/s', $html);
        preg_match('/var prototypeOnly = \[(.*?)\];/s', $html, $m);
        $blocked = array_map(
            fn ($v) => trim($v, " '\""),
            explode(',', $m[1])
        );

        // view => the loader that proves a tenant-authorised source exists for it.
        $live = [
            'docs' => 'ZAPI.loadDocumentLibrary',
            'inspections' => 'ZAPI.loadQualityItems',
            'knowledge' => 'ZAPI.loadKnowledge',
            'airuns' => 'ZAPI.loadAiRuns',
            'payapps' => 'ZAPI.loadPayApplications',
            'changeorders' => 'ZAPI.loadChangeOrders',
            'sysettings' => 'ZAPI.loadSystemSettings',
            'timesheets' => 'ZAPI.loadTimeCards',
            'photos' => 'ZAPI.loadMedia',
        ];

        foreach ($live as $view => $loader) {
            if (! str_contains($html, $loader.' = function')) {
                continue;   // not built yet; being blocked is correct
            }
            $this->assertNotContains($view, $blocked,
                "The '{$view}' module has a live loader ({$loader}) but is still listed as ".
                'prototype-only, so the interface will show it as unavailable.');
        }
    }

    /**
     * Multipart uploads must carry the same context headers as every other request.
     *
     * Found live: callForm() built its own header set and omitted X-Browse-Tenant, so in
     * Support Mode every upload - document library, knowledge sources, schedule versions,
     * media, photos, company logo - resolved against the wrong tenant and failed closed
     * with a 404. A platform administrator could not place one file into the customer
     * project they were there to help with. Invisible to server-side tests, because the
     * server was behaving correctly: it was told the wrong tenant.
     */
    public function test_multipart_uploads_carry_the_same_context_headers_as_every_other_call(): void
    {
        $html = file_get_contents(public_path('app.html'));

        $this->assertMatchesRegularExpression(
            '/ZAPI\.callForm = function \(path, formData\) \{.*?var h = ZAPI\.headers\(\);.*?delete h\[.Content-Type.\];/s',
            $html,
            'callForm must derive its headers from ZAPI.headers() so X-Browse-Tenant and any '.
            'future context header are always present; it may drop only Content-Type.'
        );

        preg_match('/ZAPI\.callForm = function \(path, formData\) \{(.*?)\n\};/s', $html, $m);
        $this->assertStringNotContainsString("var h = {'Accept': 'application/json'}", $m[1] ?? '',
            'callForm must not hand-build its header set.');
    }

    /**
     * The pay application screen is a state machine, and the states are the
     * server's to decide. What the interface may never do is invent the words on
     * the control, or put a submission blocker and a payment withholding in the
     * same pile - one means the request is improper and starts no clock, the
     * other means the request is fine and the money may be reduced.
     */
    public function test_the_payment_screen_reads_its_state_from_the_server_and_keeps_the_two_findings_apart(): void
    {
        $html = file_get_contents(public_path('app.html'));

        // The control's words come from the envelope, not from a lookup here.
        $this->assertStringContainsString("(sub.control || 'Review for submission')", $html);

        // Two sections, and the withholding one says out loud that it is not the
        // reason submission is blocked.
        $this->assertStringContainsString('id="payapp-blockers"', $html);
        $this->assertStringContainsString('id="payapp-withholdings"', $html);
        $this->assertStringContainsString('are not the reason submission is blocked', $html);

        // The certification shows the half most software leaves out.
        $this->assertStringContainsString('not_verified', $html);

        // And the certifier names the version they are signing, so the server
        // can refuse with 409 if it moved.
        $this->assertStringContainsString('content_hash_seen', $html);
        $this->assertStringContainsString('res.status === 409', $html);
    }
}
