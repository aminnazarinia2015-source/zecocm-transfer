<?php

namespace App\Providers;

use App\Domain\Ai\AiAssistant;
use App\Domain\Ai\ClaudeAssistant;
use App\Domain\Ai\JurisdictionScope;
use App\Domain\Ai\HybridKnowledgeRetriever;
use App\Domain\Ai\RetrievalClient;
use App\Domain\Ai\RetrievedPassage;
use App\Tenancy\TenantContext;
use Illuminate\Support\ServiceProvider;

class AiServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Phase 1 retrieval: the project's OWN uploaded documents (specs,
        // plans, contract) indexed in MySQL fulltext. Licensed external
        // corpora (Greenbook, ICC) plug in behind this same interface
        // once the data licenses are signed - no code change upstream.
        $this->app->singleton(RetrievalClient::class, HybridKnowledgeRetriever::class);

        $this->app->singleton(AiAssistant::class, fn ($app) => new ClaudeAssistant(
            apiKey: (string) env('ANTHROPIC_API_KEY', ''),
            retrieval: $app->make(RetrievalClient::class),
            model: (string) config('zecocm_ai.models.standard'),
        ));
    }
}
