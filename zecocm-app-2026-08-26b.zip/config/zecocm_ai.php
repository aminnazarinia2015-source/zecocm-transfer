<?php

return [
    'provider' => env('ZECOCM_AI_PROVIDER', 'anthropic'),
    'models' => [
        'standard' => env('ZECOCM_AI_MODEL_STANDARD', 'claude-sonnet-4-5'),
        'premium' => env('ZECOCM_AI_MODEL_PREMIUM', 'claude-sonnet-4-5'),
        'private' => env('ZECOCM_AI_MODEL_PRIVATE', 'claude-sonnet-4-5'),
    ],
    'approved_providers' => ['anthropic'],

    /*
     * Micros (millionths of a dollar) per million tokens, per model.
     *
     * A model that is NOT in this table is not a free model. TokenSpend returns
     * null rather than zero for an unpriced call with tokens on it, and the
     * budget records that as a hole in the total instead of quietly adding
     * nothing. Adding a new model to `models` above without adding it here will
     * therefore make the account's spend read as a lower bound - which is the
     * correct and visible failure, not a silent undercount.
     */
    'pricing' => [
        'claude-sonnet-4-5' => ['input_micros_per_mtok' => 3_000_000, 'output_micros_per_mtok' => 15_000_000],
    ],
    'prompt_version' => 'zecocm-grounded-v2',
    'retrieval_version' => 'hybrid-structured-lexical-v1',
    'policy_version' => 'refusal-v1',
];
