<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('labor_compliance_profiles', function (Blueprint $t) {
            $t->id(); $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->string('jurisdiction', 120)->default('California');
            $t->boolean('public_works')->default(true); $t->boolean('federal_funding')->default(false);
            $t->boolean('dir_ecpr_required')->default(true); $t->boolean('apprenticeship_required')->default(true);
            $t->string('agreement_type', 24)->default('none'); // none | pla | cwa | custom
            $t->string('agreement_title', 255)->nullable(); $t->string('agreement_version', 96)->nullable();
            $t->foreignId('agreement_document_id')->nullable();
            $t->json('local_hire_rules')->nullable(); $t->json('targeted_hire_rules')->nullable();
            $t->json('core_worker_rules')->nullable(); $t->json('custom_rules')->nullable();
            $t->foreignId('configured_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestampsTz(); $t->unique('project_id');
        });

        Schema::create('labor_compliance_requirements', function (Blueprint $t) {
            $t->id(); $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->string('requirement_key', 96); $t->string('title', 255); $t->string('category', 48);
            $t->string('frequency', 32)->default('once'); $t->string('responsible_party', 160)->nullable();
            $t->string('authority_citation', 500)->nullable(); $t->text('instructions')->nullable();
            $t->json('required_fields')->nullable(); $t->boolean('blocks_payment')->default(false);
            $t->boolean('active')->default(true); $t->timestampsTz();
            $t->unique(['project_id', 'requirement_key']);
        });

        Schema::create('labor_compliance_submissions', function (Blueprint $t) {
            $t->id(); $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('labor_compliance_requirement_id')->constrained()->cascadeOnDelete();
            $t->foreignId('trade_partner_id')->nullable()->constrained()->nullOnDelete();
            $t->string('employer_name', 255); $t->date('period_start')->nullable(); $t->date('period_end')->nullable();
            $t->string('status', 32)->default('submitted');
            $t->json('reported_data')->nullable(); $t->foreignId('document_id')->nullable();
            $t->string('external_receipt', 255)->nullable(); $t->timestampTz('submitted_at');
            $t->foreignId('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestampTz('reviewed_at')->nullable(); $t->text('review_note')->nullable();
            $t->string('content_sha256', 64); $t->timestampsTz();
            $t->index(['project_id', 'status', 'period_end']);
        });

        Schema::create('labor_compliance_findings', function (Blueprint $t) {
            $t->id(); $t->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $t->foreignId('project_id')->constrained()->cascadeOnDelete();
            $t->foreignId('labor_compliance_submission_id')->constrained()->cascadeOnDelete();
            $t->string('code', 96); $t->string('severity', 24); $t->string('eligibility', 32)->nullable();
            $t->string('release_condition', 32)->nullable(); $t->text('message');
            $t->string('authority_citation', 500)->nullable(); $t->bigInteger('exposure_cents')->nullable();
            $t->string('status', 24)->default('open'); $t->json('evidence')->nullable();
            $t->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestampTz('resolved_at')->nullable(); $t->text('resolution')->nullable();
            $t->timestampsTz(); $t->index(['project_id', 'status', 'severity']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('labor_compliance_findings');
        Schema::dropIfExists('labor_compliance_submissions');
        Schema::dropIfExists('labor_compliance_requirements');
        Schema::dropIfExists('labor_compliance_profiles');
    }
};
