<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('integration_connections', function (Blueprint $table) {
            $table->timestampTz('last_verified_at')->nullable()->after('last_synced_at');
            $table->timestampTz('last_successful_transfer_at')->nullable()->after('last_verified_at');
            $table->timestampTz('last_health_check_at')->nullable()->after('last_successful_transfer_at');
            $table->unsignedInteger('consecutive_failures')->default(0)->after('last_health_check_at');
            $table->index(['tenant_id', 'status', 'last_successful_transfer_at'], 'integration_live_health_idx');
        });
    }

    public function down(): void
    {
        Schema::table('integration_connections', function (Blueprint $table) {
            $table->dropIndex('integration_live_health_idx');
            $table->dropColumn(['last_verified_at', 'last_successful_transfer_at', 'last_health_check_at', 'consecutive_failures']);
        });
    }
};
