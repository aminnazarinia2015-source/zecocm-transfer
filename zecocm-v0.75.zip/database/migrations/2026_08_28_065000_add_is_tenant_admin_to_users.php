<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Adds the "primary account administrator" flag the enterprise integration
 * marketplace gates configuration/authorization on. Split out of the
 * candidate's combined tenant-domains-and-branding migration: this app
 * already has its own tenant-domain implementation (TenantDomainController /
 * TenantDomainResolver / DomainVerifier) so only the users.is_tenant_admin
 * column and its backfill are ported here.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('is_tenant_admin')->default(false)->after('tenant_id');
        });

        // Existing installations already have one customer administrator per
        // tenant. Preserve that authority during rollout by selecting the
        // oldest account in each tenant; new provisioning writes the flag.
        DB::table('users')->whereNotNull('tenant_id')->orderBy('id')->get()
            ->groupBy('tenant_id')->each(function ($users) {
                DB::table('users')->where('id', $users->first()->id)
                    ->update(['is_tenant_admin' => true]);
            });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('is_tenant_admin');
        });
    }
};
