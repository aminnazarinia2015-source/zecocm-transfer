<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('integration_field_mappings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('integration_connection_id')->constrained()->cascadeOnDelete();
            $table->string('object_type', 48);
            $table->string('direction', 16);
            $table->string('source_field', 128);
            $table->string('target_field', 128);
            $table->json('transform')->nullable();
            $table->boolean('required')->default(false);
            $table->boolean('active')->default(true);
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('approved_at')->nullable();
            $table->timestampsTz();
            $table->unique(['integration_connection_id', 'object_type', 'direction', 'source_field'], 'integration_mapping_unique');
        });

        Schema::create('integration_exchange_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('integration_connection_id')->constrained()->cascadeOnDelete();
            $table->foreignId('integration_sync_run_id')->nullable()->constrained('integration_sync_runs')->nullOnDelete();
            $table->string('direction', 16);
            $table->string('object_type', 48);
            $table->string('local_type', 128)->nullable();
            $table->string('local_id', 128)->nullable();
            $table->string('external_id', 255)->nullable();
            $table->string('idempotency_key', 128);
            $table->string('status', 32)->default('proposed');
            $table->json('normalized_payload');
            $table->json('provider_payload')->nullable();
            $table->json('provider_response')->nullable();
            $table->string('payload_sha256', 64);
            $table->unsignedInteger('attempts')->default(0);
            $table->timestampTz('next_retry_at')->nullable();
            $table->string('error_code', 96)->nullable();
            $table->text('error_message')->nullable();
            $table->text('trace_diagnosis')->nullable();
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('approved_at')->nullable();
            $table->timestampTz('completed_at')->nullable();
            $table->timestampsTz();
            $table->unique(['integration_connection_id', 'idempotency_key'], 'integration_exchange_idempotency_unique');
            $table->index(['tenant_id', 'status', 'next_retry_at'], 'integration_exchange_retry_idx');
        });

        Schema::create('integration_reconciliation_findings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('project_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('integration_connection_id')->constrained()->cascadeOnDelete();
            $table->string('object_type', 48);
            $table->string('local_reference', 255)->nullable();
            $table->string('external_reference', 255)->nullable();
            $table->string('finding_type', 64);
            $table->string('severity', 16);
            $table->decimal('local_amount', 18, 4)->nullable();
            $table->decimal('external_amount', 18, 4)->nullable();
            $table->decimal('variance', 18, 4)->nullable();
            $table->text('explanation');
            $table->text('recommended_action');
            $table->json('evidence')->nullable();
            $table->string('status', 24)->default('open');
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestampTz('resolved_at')->nullable();
            $table->timestampsTz();
            $table->index(['tenant_id', 'status', 'severity'], 'integration_reconciliation_queue_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('integration_reconciliation_findings');
        Schema::dropIfExists('integration_exchange_items');
        Schema::dropIfExists('integration_field_mappings');
    }
};
