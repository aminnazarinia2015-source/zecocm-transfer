<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens;

    protected $fillable = ['tenant_id', 'is_tenant_admin', 'name', 'email', 'password', 'platform_role', 'platform_permissions'];

    protected $hidden = ['password'];

    protected $casts = ['platform_permissions' => 'array', 'password_set_at' => 'datetime', 'is_tenant_admin' => 'boolean'];

    public function isPlatformAdmin(): bool
    {
        return $this->platform_role === 'admin';
    }

    public function isPlatformStaff(): bool
    {
        return $this->platform_role !== null;
    }

    public function can_(string $permission): bool
    {
        if ($this->isPlatformAdmin()) {
            return true;
        }

        return (bool) ($this->platform_permissions[$permission] ?? false);
    }

    public function isTenantAdministrator(): bool
    {
        if ($this->tenant_id === null || $this->isPlatformStaff()) {
            return false;
        }

        if ($this->is_tenant_admin) {
            return true;
        }

        // Compatibility for freshly-created test fixtures and installations
        // before the migration backfill: the original tenant user is the
        // account administrator until authority is explicitly transferred.
        return (int) self::query()->where('tenant_id', $this->tenant_id)->min('id') === (int) $this->id;
    }

    public function memberships()
    {
        return $this->hasMany(Membership::class);
    }
}
