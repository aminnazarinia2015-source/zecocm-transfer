<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IntegrationOauthState extends Model
{
    protected $fillable = ['tenant_id', 'user_id', 'provider', 'state_hash', 'expires_at', 'used_at'];
    protected $casts = ['expires_at' => 'immutable_datetime', 'used_at' => 'immutable_datetime'];
}
