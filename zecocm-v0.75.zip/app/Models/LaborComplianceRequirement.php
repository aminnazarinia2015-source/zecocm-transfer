<?php
namespace App\Models;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
class LaborComplianceRequirement extends Model { use BelongsToTenant; protected $guarded=[]; protected $casts=['required_fields'=>'array','blocks_payment'=>'boolean','active'=>'boolean']; }
