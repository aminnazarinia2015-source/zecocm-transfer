<?php
namespace App\Models;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
class LaborComplianceSubmission extends Model { use BelongsToTenant; protected $guarded=[]; protected $casts=['reported_data'=>'array','period_start'=>'date','period_end'=>'date','submitted_at'=>'immutable_datetime','reviewed_at'=>'immutable_datetime']; public function findings(){return $this->hasMany(LaborComplianceFinding::class);} public function requirement(){return $this->belongsTo(LaborComplianceRequirement::class);} }
