<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class IntegrationFieldMapping extends Model
{
    use BelongsToTenant;

    protected $fillable = ['tenant_id', 'integration_connection_id', 'object_type', 'direction', 'source_field', 'target_field', 'transform', 'required', 'active', 'approved_by', 'approved_at'];
    protected $casts = ['transform' => 'array', 'required' => 'boolean', 'active' => 'boolean', 'approved_at' => 'immutable_datetime'];
}
