<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class TenantIntegrationConfiguration extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'provider', 'environment', 'status', 'settings',
        'validated_at', 'validation_summary', 'configured_by',
    ];

    protected $hidden = ['credentials_ciphertext'];

    protected $casts = ['settings' => 'array', 'validated_at' => 'immutable_datetime'];

    public function setCredentials(array $credentials): void
    {
        $this->credentials_ciphertext = Crypt::encryptString(json_encode($credentials, JSON_THROW_ON_ERROR));
    }

    public function credentials(): array
    {
        return json_decode(Crypt::decryptString($this->credentials_ciphertext), true, flags: JSON_THROW_ON_ERROR);
    }
}
