<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class IntegrationReconciliationFinding extends Model
{
    use BelongsToTenant;

    protected $fillable = ['tenant_id', 'project_id', 'integration_connection_id', 'object_type', 'local_reference', 'external_reference', 'finding_type', 'severity', 'local_amount', 'external_amount', 'variance', 'explanation', 'recommended_action', 'evidence', 'status', 'resolved_by', 'resolved_at'];
    protected $casts = ['evidence' => 'array', 'local_amount' => 'decimal:4', 'external_amount' => 'decimal:4', 'variance' => 'decimal:4', 'resolved_at' => 'immutable_datetime'];
}
