<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class IntegrationConnection extends Model
{
    use BelongsToTenant;

    protected $fillable = [
        'tenant_id', 'project_id', 'provider', 'status', 'external_account_id',
        'external_account_name', 'scopes', 'token_expires_at', 'sync_cursor',
        'settings', 'last_synced_at', 'last_error', 'authorized_by',
        'last_verified_at', 'last_successful_transfer_at', 'last_health_check_at',
        'consecutive_failures',
    ];

    protected $hidden = ['access_token_ciphertext', 'refresh_token_ciphertext', 'sync_cursor'];

    protected $casts = [
        'scopes' => 'array',
        'settings' => 'array',
        'token_expires_at' => 'immutable_datetime',
        'last_synced_at' => 'immutable_datetime',
        'last_verified_at' => 'immutable_datetime',
        'last_successful_transfer_at' => 'immutable_datetime',
        'last_health_check_at' => 'immutable_datetime',
        'consecutive_failures' => 'integer',
    ];

    public function setTokens(string $accessToken, ?string $refreshToken): void
    {
        $this->access_token_ciphertext = Crypt::encryptString($accessToken);
        $this->refresh_token_ciphertext = $refreshToken !== null ? Crypt::encryptString($refreshToken) : null;
    }

    public function accessToken(): ?string
    {
        return $this->access_token_ciphertext ? Crypt::decryptString($this->access_token_ciphertext) : null;
    }

    public function refreshToken(): ?string
    {
        return $this->refresh_token_ciphertext ? Crypt::decryptString($this->refresh_token_ciphertext) : null;
    }

    /**
     * A saved secret or completed OAuth redirect is not proof of live exchange.
     * Green is reserved for a verified account with a recent successful transfer.
     */
    public function publicHealth(): array
    {
        $settings = $this->settings ?? [];
        $expectedMinutes = max(5, min(1440, (int) ($settings['expected_sync_minutes'] ?? 60)));
        $staleAfter = now()->subMinutes($expectedMinutes * 3);

        if ($this->status !== 'connected') {
            return ['state' => 'disconnected', 'color' => 'red', 'label' => 'Disconnected', 'live' => false,
                'detail' => 'No verified provider account is currently connected.'];
        }
        if ($this->last_error !== null || $this->consecutive_failures > 0) {
            return ['state' => 'error', 'color' => 'red', 'label' => 'Connection error', 'live' => false,
                'detail' => $this->last_error ?: 'The latest provider health check or transfer failed.'];
        }
        if ($this->last_verified_at === null || $this->last_successful_transfer_at === null) {
            return ['state' => 'verification_pending', 'color' => 'amber', 'label' => 'Connected — test pending', 'live' => false,
                'detail' => 'Authorization exists, but ZecoCM has not yet verified a successful data transfer.'];
        }
        if ($this->last_successful_transfer_at->lt($staleAfter)) {
            return ['state' => 'stale', 'color' => 'amber', 'label' => 'Connected — data stale', 'live' => false,
                'detail' => 'No successful transfer within the configured freshness window.'];
        }

        return ['state' => 'live', 'color' => 'green', 'label' => 'Live connection', 'live' => true,
            'detail' => 'Provider identity verified and data transferred successfully within the freshness window.'];
    }

    public function markVerified(): void
    {
        $this->forceFill(['last_verified_at' => now(), 'last_health_check_at' => now(), 'last_error' => null])->save();
    }

    public function markTransferSucceeded(): void
    {
        $this->forceFill(['last_synced_at' => now(), 'last_successful_transfer_at' => now(),
            'last_health_check_at' => now(), 'consecutive_failures' => 0, 'last_error' => null])->save();
    }

    public function markTransferFailed(string $safeSummary): void
    {
        $this->forceFill(['last_health_check_at' => now(), 'consecutive_failures' => $this->consecutive_failures + 1,
            'last_error' => mb_substr($safeSummary, 0, 2000)])->save();
    }
}
