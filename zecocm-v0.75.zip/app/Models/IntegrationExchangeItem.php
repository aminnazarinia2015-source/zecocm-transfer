<?php

namespace App\Models;

use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class IntegrationExchangeItem extends Model
{
    use BelongsToTenant;

    protected $fillable = ['tenant_id', 'project_id', 'integration_connection_id', 'integration_sync_run_id', 'direction', 'object_type', 'local_type', 'local_id', 'external_id', 'idempotency_key', 'status', 'normalized_payload', 'provider_payload', 'provider_response', 'payload_sha256', 'attempts', 'next_retry_at', 'error_code', 'error_message', 'trace_diagnosis', 'approved_by', 'approved_at', 'completed_at'];
    protected $casts = ['normalized_payload' => 'array', 'provider_payload' => 'array', 'provider_response' => 'array', 'next_retry_at' => 'immutable_datetime', 'approved_at' => 'immutable_datetime', 'completed_at' => 'immutable_datetime'];
}
