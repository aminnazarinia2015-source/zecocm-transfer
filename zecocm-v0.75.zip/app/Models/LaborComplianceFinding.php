<?php
namespace App\Models;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
class LaborComplianceFinding extends Model { use BelongsToTenant; protected $guarded=[]; protected $casts=['evidence'=>'array','resolved_at'=>'immutable_datetime']; }
