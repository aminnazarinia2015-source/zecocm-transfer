<?php
namespace App\Models;
use App\Tenancy\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
class LaborComplianceProfile extends Model { use BelongsToTenant; protected $guarded=[]; protected $casts=['public_works'=>'boolean','federal_funding'=>'boolean','dir_ecpr_required'=>'boolean','apprenticeship_required'=>'boolean','local_hire_rules'=>'array','targeted_hire_rules'=>'array','core_worker_rules'=>'array','custom_rules'=>'array']; }
