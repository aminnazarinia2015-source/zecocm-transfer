<?php

namespace App\Domain\Integrations;

use App\Models\IntegrationConnection;
use App\Models\IntegrationExchangeItem;
use App\Models\IntegrationFieldMapping;
use App\Models\IntegrationReconciliationFinding;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class AccountingIntegrationEngine
{
    public function saveMappings(IntegrationConnection $connection, array $mappings, int $userId): int
    {
        return DB::transaction(function () use ($connection, $mappings, $userId) {
            $count = 0;
            foreach ($mappings as $mapping) {
                IntegrationFieldMapping::query()->updateOrCreate([
                    'tenant_id' => $connection->tenant_id,
                    'integration_connection_id' => $connection->id,
                    'object_type' => $mapping['object_type'],
                    'direction' => $mapping['direction'],
                    'source_field' => $mapping['source_field'],
                ], [
                    'target_field' => $mapping['target_field'],
                    'transform' => $mapping['transform'] ?? null,
                    'required' => (bool) ($mapping['required'] ?? false),
                    'active' => true,
                    'approved_by' => $userId,
                    'approved_at' => now(),
                ]);
                $count++;
            }
            return $count;
        });
    }

    public function dryRun(IntegrationConnection $connection, string $direction, string $objectType, array $records): array
    {
        $mappings = IntegrationFieldMapping::query()->where('integration_connection_id', $connection->id)
            ->where('object_type', $objectType)->where('direction', $direction)->where('active', true)->get();
        if ($mappings->isEmpty()) {
            throw ValidationException::withMessages(['mappings' => 'Approve at least one field mapping before a dry run.']);
        }

        $items = [];
        foreach ($records as $record) {
            $providerPayload = [];
            foreach ($mappings as $mapping) {
                $value = Arr::get($record, $mapping->source_field);
                if ($mapping->required && ($value === null || $value === '')) {
                    throw ValidationException::withMessages(['records' => "Required source field {$mapping->source_field} is missing."]);
                }
                Arr::set($providerPayload, $mapping->target_field, $this->transform($value, $mapping->transform));
            }
            $normalized = Arr::only($record, ['local_type', 'local_id', 'external_id', 'amount', 'currency', 'status', 'reference', 'data']);
            $hash = hash('sha256', json_encode([$direction, $objectType, $normalized, $providerPayload], JSON_THROW_ON_ERROR));
            $item = IntegrationExchangeItem::query()->firstOrCreate([
                'tenant_id' => $connection->tenant_id,
                'integration_connection_id' => $connection->id,
                'idempotency_key' => $hash,
            ], [
                'project_id' => $connection->project_id,
                'direction' => $direction,
                'object_type' => $objectType,
                'local_type' => $record['local_type'] ?? null,
                'local_id' => isset($record['local_id']) ? (string) $record['local_id'] : null,
                'external_id' => $record['external_id'] ?? null,
                'status' => 'dry_run_ready',
                'normalized_payload' => $normalized,
                'provider_payload' => $providerPayload,
                'payload_sha256' => $hash,
            ]);
            $items[] = $item;
        }
        return $items;
    }

    public function approve(IntegrationExchangeItem $item, int $userId): IntegrationExchangeItem
    {
        if ($item->status !== 'dry_run_ready') {
            throw ValidationException::withMessages(['item' => 'Only a completed dry-run item can be approved for exchange.']);
        }
        $item->update(['status' => 'approved', 'approved_by' => $userId, 'approved_at' => now()]);
        return $item->fresh();
    }

    public function reconcile(IntegrationConnection $connection, string $objectType, array $pairs): array
    {
        $findings = [];
        foreach ($pairs as $pair) {
            $local = round((float) $pair['local_amount'], 4);
            $external = round((float) $pair['external_amount'], 4);
            $variance = round($local - $external, 4);
            if (abs($variance) < 0.0001) {
                continue;
            }
            $findings[] = IntegrationReconciliationFinding::query()->create([
                'tenant_id' => $connection->tenant_id,
                'project_id' => $connection->project_id,
                'integration_connection_id' => $connection->id,
                'object_type' => $objectType,
                'local_reference' => $pair['local_reference'] ?? null,
                'external_reference' => $pair['external_reference'] ?? null,
                'finding_type' => 'amount_variance',
                'severity' => abs($variance) >= 1000 ? 'high' : 'medium',
                'local_amount' => $local,
                'external_amount' => $external,
                'variance' => $variance,
                'explanation' => 'TRACE detected a difference between the ZecoCM approved amount and the accounting-system amount.',
                'recommended_action' => 'Review the cited records and mapping. Correct the source or approve an explicit adjustment; TRACE will not overwrite either record.',
                'evidence' => Arr::only($pair, ['local_reference', 'external_reference']),
            ]);
        }
        return $findings;
    }

    public function diagnoseFailure(IntegrationExchangeItem $item, ?int $status, string $message): IntegrationExchangeItem
    {
        $transient = $status === null || $status === 408 || $status === 429 || ($status >= 500 && $status <= 599);
        $code = $status === 401 ? 'authorization_expired' : ($status === 403 ? 'permission_refused' : ($status === 429 ? 'rate_limited' : ($transient ? 'provider_unavailable' : 'record_rejected')));
        $diagnosis = match ($code) {
            'authorization_expired' => 'Reconnect the provider account. No transaction was posted.',
            'permission_refused' => 'The connected account lacks the provider permission required for this object.',
            'rate_limited' => 'The provider rate limit was reached. ZecoCM scheduled a safe retry.',
            'provider_unavailable' => 'The provider is temporarily unavailable. ZecoCM scheduled a safe retry using the same idempotency key.',
            default => 'The provider rejected this record. Review its required fields and approved mapping before resubmission.',
        };
        $item->update([
            'status' => $transient ? 'retry_scheduled' : 'needs_review',
            'attempts' => $item->attempts + 1,
            'next_retry_at' => $transient ? now()->addMinutes(min(60, 2 ** min(5, $item->attempts + 1))) : null,
            'error_code' => $code,
            'error_message' => Str::limit($message, 4000),
            'trace_diagnosis' => $diagnosis,
        ]);
        return $item->fresh();
    }

    private function transform(mixed $value, ?array $transform): mixed
    {
        return match ($transform['type'] ?? 'identity') {
            'uppercase' => is_string($value) ? mb_strtoupper($value) : $value,
            'lowercase' => is_string($value) ? mb_strtolower($value) : $value,
            'prefix' => (string) ($transform['value'] ?? '').(string) $value,
            'default' => ($value === null || $value === '') ? ($transform['value'] ?? null) : $value,
            default => $value,
        };
    }
}
