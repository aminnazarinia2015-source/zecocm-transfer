<?php

namespace App\Domain\Compliance;

final class LaborRequirementCatalog
{
    /** Baseline California public-works controls; project agreements can add or override, never silently remove. */
    public static function baseline(bool $pla = false): array
    {
        $requirements = [
            self::r('dir_registration', 'DIR contractor registration verification', 'registration', 'annual', 'California Labor Code § 1725.5', ['registration_number', 'effective_from', 'expires_on']),
            self::r('prevailing_wage_determination', 'Governing prevailing-wage determination', 'wage', 'once', 'California Labor Code §§ 1771, 1773', ['craft', 'classification', 'determination', 'base_rate_cents', 'fringe_cents', 'effective_from']),
            self::r('certified_payroll_weekly', 'Certified payroll record and statement of compliance', 'payroll', 'weekly', 'California Labor Code § 1776; 8 CCR § 16401', ['week_ending', 'employer', 'records', 'dir_submission_receipt'], true),
            self::r('das_140', 'DAS 140 public-works contract award information by craft', 'apprenticeship', 'per_craft', 'California Labor Code § 1777.5; 8 CCR § 230', ['craft', 'committee', 'sent_on', 'delivery_evidence']),
            self::r('das_142', 'DAS 142 apprentice dispatch request by craft', 'apprenticeship', 'as_needed', 'California Labor Code § 1777.5; 8 CCR § 230.1', ['craft', 'committee', 'apprentices_requested', 'needed_on', 'sent_on', 'delivery_evidence']),
            self::r('apprentice_ratio', 'Apprentice-to-journey-level hour tracking', 'apprenticeship', 'weekly', 'California Labor Code § 1777.5', ['craft', 'journey_hours', 'apprentice_hours', 'required_ratio']),
            self::r('training_fund', 'Apprenticeship training-fund contribution evidence', 'apprenticeship', 'monthly', 'California Labor Code § 1777.5; 8 CCR § 230.2', ['month', 'craft', 'hours', 'amount_cents', 'recipient', 'receipt']),
            self::r('fringe_benefit_statement', 'Fringe-benefit credit statement', 'wage', 'on_change', 'California Labor Code § 1773.1', ['employer', 'plan_name', 'hourly_credit_cents', 'supporting_document']),
            self::r('worker_interview', 'Worker interview / payroll verification', 'monitoring', 'as_needed', 'Labor-compliance program requirement', ['worker_reference', 'classification', 'observed_work', 'interviewed_on', 'interviewer']),
        ];
        if ($pla) {
            $requirements = array_merge($requirements, [
                self::r('letter_of_assent', 'PLA/CWA letter of assent', 'agreement', 'per_contractor', 'Project-specific PLA/CWA', ['contractor', 'tier', 'signed_by', 'signed_on']),
                self::r('prejob_conference', 'Pre-job conference form', 'agreement', 'per_contractor', 'Project-specific PLA/CWA', ['contractor', 'trades', 'work_scope', 'start_date', 'union_contacts']),
                self::r('craft_request', 'Craft employee dispatch request', 'agreement', 'as_needed', 'Project-specific PLA/CWA', ['craft', 'union', 'workers_requested', 'qualifications', 'needed_on', 'sent_on']),
                self::r('core_worker_list', 'Core-worker designation and sequence', 'agreement', 'per_contractor', 'Project-specific PLA/CWA', ['contractor', 'workers', 'sequence', 'eligibility_evidence']),
                self::r('monthly_workforce', 'Monthly local/targeted workforce report', 'workforce', 'monthly', 'Project-specific PLA/CWA', ['month', 'total_hours', 'local_hours', 'targeted_hours', 'apprentice_hours', 'worker_residency_evidence']),
                self::r('jobs_coordinator', 'Jobs coordinator activity report', 'workforce', 'monthly', 'Project-specific PLA/CWA', ['coordinator', 'referrals', 'placements', 'barriers', 'follow_up']),
                self::r('grievance_jurisdiction', 'Grievance or jurisdictional-dispute notice', 'agreement', 'as_needed', 'Project-specific PLA/CWA', ['issue', 'parties', 'filed_on', 'step', 'deadline', 'resolution']),
            ]);
        }
        return $requirements;
    }

    private static function r(string $key, string $title, string $category, string $frequency, string $citation, array $fields, bool $blocks = false): array
    {
        return ['requirement_key' => $key, 'title' => $title, 'category' => $category, 'frequency' => $frequency,
            'authority_citation' => $citation, 'required_fields' => array_map(fn ($field) => ['key' => $field, 'label' => ucwords(str_replace('_', ' ', $field)), 'type' => str_contains($field, 'date') || str_ends_with($field, '_on') ? 'date' : 'text', 'required' => true], $fields),
            'blocks_payment' => $blocks, 'instructions' => 'Upload the governing form/receipt and enter its searchable fields. TRACE reviews the submitted record but does not represent filing with DIR, DAS, a union, or an agency.'];
    }
}
