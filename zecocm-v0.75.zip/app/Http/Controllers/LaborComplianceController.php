<?php

namespace App\Http\Controllers;

use App\Domain\Compliance\CertifiedPayrollCheck;
use App\Domain\Compliance\LaborRequirementCatalog;
use App\Domain\Compliance\PrevailingWageDetermination;
use App\Domain\Schedule\ProjectAccess;
use App\Models\LaborComplianceFinding;
use App\Models\LaborComplianceProfile;
use App\Models\LaborComplianceRequirement;
use App\Models\LaborComplianceSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class LaborComplianceController
{
    public function __construct(private readonly ProjectAccess $access) {}

    public function index(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'labor.view')->project;
        $profile = LaborComplianceProfile::query()->where('project_id', $project->id)->first();
        $requirements = LaborComplianceRequirement::query()->where('project_id', $project->id)->where('active', true)->orderBy('category')->orderBy('title')->get();
        $submissions = LaborComplianceSubmission::query()->where('project_id', $project->id)->with(['requirement', 'findings'])->latest('submitted_at')->limit(250)->get();
        return response()->json(['profile' => $profile, 'requirements' => $requirements, 'submissions' => $submissions,
            'counts' => ['requirements' => $requirements->count(), 'submitted' => $submissions->count(), 'needs_review' => $submissions->whereIn('status', ['submitted', 'exceptions_found'])->count(), 'open_findings' => $submissions->sum(fn ($s) => $s->findings->where('status', 'open')->count())],
            'notice' => 'ZecoCM checks records and deadlines; it does not replace mandatory filing with DIR, DAS, an awarding body, union, or labor-compliance program.']);
    }

    public function configure(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer', 'jurisdiction' => 'required|string|max:120',
            'public_works' => 'required|boolean', 'federal_funding' => 'required|boolean', 'dir_ecpr_required' => 'required|boolean', 'apprenticeship_required' => 'required|boolean',
            'agreement_type' => ['required', Rule::in(['none', 'pla', 'cwa', 'custom'])], 'agreement_title' => 'nullable|string|max:255', 'agreement_version' => 'nullable|string|max:96', 'agreement_document_id' => 'nullable|integer',
            'local_hire_rules' => 'nullable|array', 'targeted_hire_rules' => 'nullable|array', 'core_worker_rules' => 'nullable|array', 'custom_rules' => 'nullable|array']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'labor.manage', write: true)->project;
        $profile = DB::transaction(function () use ($data, $project, $request) {
            $profile = LaborComplianceProfile::query()->updateOrCreate(['tenant_id' => $project->tenant_id, 'project_id' => $project->id], $data + ['configured_by' => $request->user()->id]);
            foreach (LaborRequirementCatalog::baseline($data['agreement_type'] !== 'none') as $definition) {
                LaborComplianceRequirement::query()->updateOrCreate(['tenant_id' => $project->tenant_id, 'project_id' => $project->id, 'requirement_key' => $definition['requirement_key']], $definition);
            }
            return $profile;
        });
        return response()->json(['profile' => $profile, 'message' => 'Labor-compliance profile and requirement templates generated. Review the project agreement and customize before relying on them.']);
    }

    public function storeRequirement(Request $request)
    {
        $data = $request->validate(['project_id' => 'required|integer', 'requirement_key' => 'required|string|max:96', 'title' => 'required|string|max:255', 'category' => 'required|string|max:48', 'frequency' => 'required|string|max:32', 'responsible_party' => 'nullable|string|max:160', 'authority_citation' => 'nullable|string|max:500', 'instructions' => 'nullable|string|max:10000', 'required_fields' => 'nullable|array|max:100', 'blocks_payment' => 'required|boolean']);
        $project = $this->access->authorize($request->user(), (int) $data['project_id'], 'labor.manage', write: true)->project;
        $requirement = LaborComplianceRequirement::query()->updateOrCreate(['tenant_id' => $project->tenant_id, 'project_id' => $project->id, 'requirement_key' => $data['requirement_key']], $data + ['active' => true]);
        return response()->json(['requirement' => $requirement], 201);
    }

    public function submit(Request $request, LaborComplianceRequirement $requirement)
    {
        $this->access->authorize($request->user(), (int) $requirement->project_id, 'labor.submit', write: true);
        $data = $request->validate(['employer_name' => 'required|string|max:255', 'trade_partner_id' => 'nullable|integer', 'period_start' => 'nullable|date', 'period_end' => 'nullable|date|after_or_equal:period_start', 'reported_data' => 'required|array|max:200', 'document_id' => 'nullable|integer', 'external_receipt' => 'nullable|string|max:255']);
        foreach ($requirement->required_fields ?? [] as $field) {
            if (($field['required'] ?? false) && ! data_get($data['reported_data'], $field['key'])) {
                return response()->json(['message' => 'Complete every required field.', 'missing_field' => $field['key']], 422);
            }
        }
        $hash = hash('sha256', json_encode([$requirement->id, $data], JSON_THROW_ON_ERROR));
        $submission = LaborComplianceSubmission::query()->create($data + ['tenant_id' => $requirement->tenant_id, 'project_id' => $requirement->project_id, 'labor_compliance_requirement_id' => $requirement->id, 'submitted_at' => now(), 'submitted_by' => $request->user()->id, 'content_sha256' => $hash]);
        $this->reviewDeterministically($submission, $requirement);
        return response()->json(['submission' => $submission->fresh()->load('findings'), 'message' => 'Submission sealed and reviewed. External filing receipts remain separately required.'], 201);
    }

    public function resolve(Request $request, LaborComplianceFinding $finding)
    {
        $this->access->authorize($request->user(), (int) $finding->project_id, 'labor.manage', write: true);
        $data = $request->validate(['resolution' => 'required|string|max:5000']);
        $finding->update(['status' => 'resolved', 'resolved_by' => $request->user()->id, 'resolved_at' => now(), 'resolution' => $data['resolution']]);
        return response()->json(['finding' => $finding->fresh(), 'message' => 'Finding resolved by an accountable user; the original finding remains in history.']);
    }

    private function reviewDeterministically(LaborComplianceSubmission $submission, LaborComplianceRequirement $requirement): void
    {
        // Use the route-bound, already-authorized requirement. Resolving the
        // relationship here can legitimately return null when a queue/runtime
        // has not yet established TenantContext for the model global scope.
        if ($requirement->requirement_key !== 'certified_payroll_weekly') return;
        $data = $submission->reported_data ?? []; $determinations = [];
        foreach (($data['determinations'] ?? []) as $d) {
            if (! isset($d['classification'], $d['source'])) continue;
            $determinations[$d['classification']] = new PrevailingWageDetermination($d['craft'] ?? $d['classification'], $d['classification'], (int) ($d['base_rate_cents'] ?? 0), (int) ($d['fringe_cents'] ?? 0), $d['source'], $d['effective_from'] ?? null, $d['expires_after'] ?? null);
        }
        $findings = CertifiedPayrollCheck::findings($data['records'] ?? [], $determinations, ($data['context'] ?? []) + ['employer' => $submission->employer_name]);
        foreach ($findings as $f) LaborComplianceFinding::query()->create(['tenant_id' => $submission->tenant_id, 'project_id' => $submission->project_id, 'labor_compliance_submission_id' => $submission->id, 'code' => $f['code'], 'severity' => $f['severity'], 'eligibility' => $f['eligibility'] ?? null, 'release_condition' => $f['release'] ?? null, 'message' => $f['message'], 'authority_citation' => $f['citation'] ?? null, 'exposure_cents' => $f['exposure_cents'] ?? null, 'evidence' => ['submission_sha256' => $submission->content_sha256]]);
        $submission->update(['status' => $findings === [] ? 'rules_passed' : 'exceptions_found', 'reviewed_at' => now(), 'review_note' => $findings === [] ? 'Deterministic checks found no exception in the submitted structured data.' : count($findings).' deterministic exception(s) require human review.']);
    }
}
