<?php

namespace Tests\Feature;

use App\Mail\DemoAccountProvisioned;
use App\Models\DemoRequest;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * The two demo paths Amin asked for (2026-08-27): an instant, self-serve, limited demo anyone
 * can get on the spot, and a "request a full demo" lead queue for entities/contractors that a
 * human follows up on and schedules manually.
 */
class DemoAccountTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::create(['name' => 'Amin', 'email' => 'amin@zecocm.test', 'password' => bcrypt('x'), 'platform_role' => 'admin']);
    }

    public function test_instant_demo_provisions_a_limited_time_boxed_tenant_and_emails_the_password_link(): void
    {
        Mail::fake();

        $response = $this->postJson('/api/demo/instant', [
            'company' => 'Fresno Paving Co',
            'admin_first_name' => 'Luis',
            'admin_last_name' => 'Ortega',
            'email' => 'luis@fresnopaving.test',
        ]);

        $response->assertCreated();

        $tenant = Tenant::where('name', 'Fresno Paving Co (Demo)')->firstOrFail();
        $this->assertTrue($tenant->is_demo);
        $this->assertNotNull($tenant->demo_expires_at);
        $this->assertTrue($tenant->demo_expires_at->isFuture());
        $this->assertEqualsCanonicalizing(
            ['daily_reports', 'rfis', 'submittals', 'photos', 'documents', 'documents.transmittal', 'ai.assist'],
            $tenant->entitlements,
        );

        $admin = User::where('tenant_id', $tenant->id)->where('email', 'luis@fresnopaving.test')->first();
        $this->assertNotNull($admin);

        // Returned directly in the response, not just emailed - production mail delivery isn't a
        // confirmed dependency yet, so this is the fallback that keeps the instant demo from
        // being a dead end if that email never lands.
        $this->assertStringContainsString('onboarding/password/', $response->json('password_setup_url'));

        Mail::assertSent(DemoAccountProvisioned::class, fn ($mail) => $mail->hasTo('luis@fresnopaving.test'));
    }

    public function test_instant_demo_requires_the_basic_fields(): void
    {
        $this->postJson('/api/demo/instant', ['company' => 'X'])->assertStatus(422);
    }

    public function test_requesting_a_full_demo_creates_a_pending_lead_not_an_account(): void
    {
        $response = $this->postJson('/api/demo/request', [
            'company' => 'Metro Water District',
            'contact_name' => 'Dana Kim',
            'email' => 'dana@metrowater.test',
            'phone' => '555-0111',
            'entity_type' => 'agency',
            'note' => 'Interested in the full commercial + evidence set for a 12-project program.',
        ]);

        $response->assertCreated();
        $this->assertSame(0, Tenant::count(), 'A full-demo request must never itself create an account.');

        $demoRequest = DemoRequest::firstOrFail();
        $this->assertSame('pending', $demoRequest->status);
        $this->assertSame('Metro Water District', $demoRequest->company);
    }

    public function test_platform_staff_can_list_and_update_demo_requests(): void
    {
        $demoRequest = DemoRequest::create([
            'company' => 'ACME', 'contact_name' => 'Jo', 'email' => 'jo@acme.test', 'status' => 'pending',
        ]);
        Sanctum::actingAs($this->admin());

        $this->getJson('/api/platform/demo-requests')->assertOk()->assertJsonFragment(['company' => 'ACME']);

        $this->putJson("/api/platform/demo-requests/{$demoRequest->id}", ['status' => 'scheduled'])
            ->assertOk()->assertJson(['status' => 'scheduled']);
    }

    public function test_an_unauthenticated_request_cannot_see_demo_requests(): void
    {
        $this->getJson('/api/platform/demo-requests')->assertStatus(401);
    }
}
